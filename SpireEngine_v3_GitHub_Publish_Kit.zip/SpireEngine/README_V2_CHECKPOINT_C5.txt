SPIRE ENGINE v2.0 — CHECKPOINT C5 (October 13, 2026)

This checkpoint supersedes C1, C2, C3 and C4 and is cumulative over
Milestone B. It is SOURCE CODE, not a compiled Windows executable.

WHAT'S IMPLEMENTED:
- Experimental local spherical terrain editor demo (--game sandbox --demo planet)
- Radial editor camera up vector, with original Y-up flat mode intact
- Precise sector-local chunk-address helper and tests (not active chunk key yet)
- Manual .vxplanet experimental save/load (flat .vxworld is preserved)
- Double-precision-origin cube-sphere surface patch mesh builder
- Optional surface skirts as a placeholder for future mixed-LOD seams
- Adaptive CPU quadtree LOD tile selection with hard budget and horizon culling
- 2 new experimental marketing screenshot demo modes

VERIFICATION:
7 headless CPU test suites pass on GCC/C++20. The new LOD selector test also
passes with Clang. See docs/PLANETARY_MILESTONE_C1.md ... C5.md.

IMPORTANT LIMITATIONS:
- Full Windows editor compile/link, runtime and graphics remain unverified.
- LOD tiles are not connected to the OpenGL renderer. This is not yet an
  Earth-sized planet you can fly around.
- Save format is experimental. No planet autosave; do not use as sole backup.
- Live streaming still keys chunks with legacy int3 and float world positions.

INSTALL:
Save a copy of your current project first. Merge the patch SpireEngine/
folder over Milestone B. C5 contains all changed files from C1 through C5.
A consolidated source overlay is also provided; it excludes fonts, binaries,
package dependencies, build outputs, and therefore is not a standalone app.
