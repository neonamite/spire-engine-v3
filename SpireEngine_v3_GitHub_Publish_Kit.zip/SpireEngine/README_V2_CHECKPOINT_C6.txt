SPIRE ENGINE 2.0 -- CHECKPOINT C6

This checkpoint follows the C5 consolidated source overlay. The cumulative patch
contains every file changed after the C5 baseline; the consolidated source overlay
contains the project source, assets, and marketing material.

C6 adds an ASYNCHRONOUS CPU surface tile mesh streamer (with tests) and does not
yet integrate the meshes into OpenGL draws.

Apply the consolidated overlay to a backup of your engine project, or merge the
cumulative patch onto the previously installed C5 checkpoint.

Read docs/PLANETARY_MILESTONE_C6.md for verification and remaining gaps.
