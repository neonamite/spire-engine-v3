SPIRE ENGINE v2.0 PREVIEW — CHECKPOINT C8
========================================
THIS IS UPDATED SOURCE CODE, NOT A PREBUILT WINDOWS EXECUTABLE.

Recommended: back up your current Spire Engine folder first.

To apply the consolidated overlay:
  Extract SpireEngine_v2.0_C8_Consolidated_Source_Overlay.zip at the
  directory CONTAINING your SpireEngine folder. Merge the folders.

To apply the incremental patch:
  Extract SpireEngine_v2.0_Checkpoint_C8_Patch_2026-10-13.zip at the
  directory CONTAINING your *C7* SpireEngine folder. Merge the folders.
  Do NOT apply C8 incremental on raw v1.6 without earlier checkpoints.

Then rebuild with Visual Studio / vcpkg using the project README.
C8 added Hub: "Create Planet... (Experimental)", File->Create Planet,
and Open Planet. These launch a small local spherical voxel editor prototype.
Ctrl+S saves a distinct named .vxplanet under worlds/sandbox/planets.
The legacy world.vxworld is never overwritten by creating a planet.

Test limits: 48-512 m prototype radius, editor flight only. Not yet a
planetary-scale renderer, orbital view, radial-play physics, or true biomes.
Do not assume a Windows editor build or a rendered screenshot was verified.

Detailed notes: docs/PLANETARY_MILESTONE_C8.md
