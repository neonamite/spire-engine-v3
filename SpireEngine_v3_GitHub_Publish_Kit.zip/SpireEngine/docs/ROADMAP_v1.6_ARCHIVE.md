# Spire Engine — Engine Roadmap

Every feature here is **engine** work: every game built on Spire Engine gets it.
Game-specific plans live with each game (e.g. `games/vanguard/README.md`).

**Priority** P1 = next, P2 = soon after, P3 = later
**Size** S = a day or two · M = about a week · L = several weeks
**★** = a "feels complete" pick: high impact on how polished the engine feels.

How people, buildings and weapons get made is designed in detail in
[CREATION.md](CREATION.md).

---

## 1. Rendering and visuals (1–28)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 1 | ★ **Sky & atmosphere** ✅ *done v0.6* | Physically based sky that changes colour with the sun; horizon haze; sun disc | P1 | M |
| 2 | ★ **Day/night cycle** ✅ *done v0.6* | Moving sun and moon, stars, time-of-day slider and speed, sunrise/sunset light | P1 | M |
| 3 | ★ **Volumetric clouds** | Drifting cloud layer that casts soft shadows; coverage and wind controls | P2 | L |
| 4 | ★ **Textured terrain (triplanar)** ✅ *done v0.7* | Real rock, grass, dirt, sand textures that wrap any voxel shape without stretching | P1 | M |
| 5 | **Normal & detail maps** 🟡 *normal maps done v0.7; custom images next* | Surface bumps and fine detail up close | P2 | S |
| 6 | **PBR materials** 🟡 *glow and shine per material done v0.15 (lava, lamp, crystal glow; tile and ice are glossy); full roughness / metalness maps next* | Roughness, metalness and emissive per material, so metal shines and lava glows | P2 | M |
| 7 | ★ **Water** ✅ *done v0.8 (sea level, waves, refraction, foam, swimming; rivers and terrain reflections next)* | Oceans, lakes and rivers with waves, reflections, refraction, foam and underwater fog | P1 | L |
| 8 | ★ **Grass & foliage** ✅ *done v0.8 (grass and flowers; bushes and trees come with #9)* | Millions of instanced grass blades and plants that sway in the wind and part around the player | P1 | M |
| 9 | ★ **Procedural trees** | Tree generator (trunk, branches, leaves) with presets: oak, pine, palm, dead, alien | P2 | M |
| 10 | ★ **Post-processing stack** ✅ *done v0.6* | HDR, tonemapping, bloom, colour grading, vignette | P1 | M |
| 11 | **Screen-space AO** | Contact shadows on top of the baked voxel AO | P2 | S |
| 12 | **Anti-aliasing** ✅ *done v0.6* | FXAA/TAA so edges stop shimmering | P1 | S |
| 13 | **Cascaded shadow maps** | Sharp shadows up close and shadows all the way to the horizon | P2 | M |
| 14 | **Point & spot lights** | Torches, lamps, neon, flashlights; hundreds per scene (clustered lighting) | P1 | M |
| 15 | **Emissive glow** 🟡 *the materials glow and bloom since v0.15; lighting the area around them comes with point lights (14)* | Glowing crystals, screens and lava that light the area around them | P2 | S |
| 16 | **Volumetric fog & light shafts** | God rays through trees and cave openings; fog that pools in valleys | P2 | M |
| 17 | **Screen-space reflections** | Wet floors, glass and water reflect the world | P3 | M |
| 18 | **Weather** | Rain, snow, sandstorms, lightning, wet surfaces, puddles, snow buildup | P2 | L |
| 19 | **Decals** | Scorch marks, bullet holes, blood, paint, graffiti on any surface | P2 | M |
| 20 | **Particles system** | GPU particles for fire, smoke, sparks, dust, magic (powers the VFX editor) | P1 | M |
| 21 | **Depth of field & motion blur** | Cinematic camera effects, mainly for cutscenes and photo mode | P3 | S |
| 22 | **Chunk LOD** | Distant terrain at lower detail, so view distance can be 5–10x further | P1 | L |
| 23 | **Frustum & occlusion culling** | Only draw what the camera can see; big FPS gains in caves and cities | P1 | M |
| 24 | **GPU meshing (compute shaders)** | Generate and remesh chunks on the graphics card for instant streaming | P3 | L |
| 25 | **Dual Contouring** | Sharp corners and flat walls for buildings, alongside smooth terrain | P2 | L |
| 26 | **Graphics quality presets** ✅ *done v0.11 (Low / Medium / High / Ultra / Custom: 3D resolution, shadows, bloom, FXAA, grass, view distance)* | Low / Medium / High / Ultra plus per-setting control | P1 | S |
| 27 | **Vulkan / DX12 backend** | Modern graphics API for better performance on big worlds | P3 | L |
| 28 | **Photo mode** | Free camera, filters, depth of field and hide-UI for screenshots | P2 | S |

## 2. World and terrain (29–46)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 29 | ★ **Biomes** | Forest, desert, tundra, swamp, mountains, each with its own terrain shape, materials, plants and weather | P1 | M |
| 30 | **Biome painter** | Paint which biome goes where instead of leaving it to noise | P2 | M |
| 31 | **Rivers & lakes generation** | Water that flows downhill and carves real valleys | P2 | L |
| 32 | **Cave systems** | Long connected tunnels, caverns and underground lakes, separate from surface noise | P2 | M |
| 33 | **Rock strata & ores** | Layered rock underground; ore and crystal veins for mining and crafting games | P2 | M |
| 34 | **Erosion simulation** | Natural-looking mountains with ridges and gullies | P3 | L |
| 35 | **Terrain stamps library** | Drop in mountains, craters, mesas, canyons and islands as brushes | P1 | S |
| 36 | **Heightmap import** | Turn any greyscale image (or real-world map) into terrain | P2 | S |
| 37 | **Spline roads & paths** | Draw a road; the terrain flattens and paves under it | P2 | M |
| 38 | **Procedural settlements** | Generate villages and towns with roads and buildings (uses building kits) | P3 | L |
| 39 | **Finite world option** | Fixed-size islands or arenas with edges, as well as infinite worlds | P1 | S |
| 40 | **World templates** | Start from Flat, Islands, Mountains, Desert, Caves, Space Rock | P1 | S |
| 41 | **Multiple worlds per game** | Levels, dimensions, interiors; travel between them | P2 | M |
| 42 | **Planets** | Spherical worlds with gravity toward the centre and orbital view | P3 | L |
| 43 | **64-bit coordinates / floating origin** | Precision stays perfect thousands of km from the start | P3 | M |
| 44 | **World map & minimap generation** | Auto-generated top-down map of the world for editor and game | P2 | M |
| 45 | **Region copy / paste / move** | Select a box of world, then copy it, move it, rotate it or save it as a prefab | P1 | M |
| 46 | **Voxel import (MagicaVoxel .vox) & mesh voxelizer (.obj)** | Bring in existing voxel art or models and turn them into editable voxels | P2 | M |

## 3. Sculpting and creation tools (47–66)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 47 | ★ **Smooth brush** ✅ *done v0.7* | Soften lumpy sculpting | P1 | S |
| 48 | ★ **Material paint brush** ✅ *done v0.7, grown in v0.15 (24 materials: building, glowing and nine paint colours; glass and your own images come with the material editor)* | Paint stone, wood, metal, glass, glow onto existing terrain | P1 | M |
| 49 | **Noise / roughen brush** | Add natural bumps and rocky detail | P1 | S |
| 50 | **Terrace & cliff brush** | Stepped cliffs and rice-terrace shapes | P2 | S |
| 51 | **Shape tools** | Box, cylinder, cone, wedge, arch, stairs: drag out exact shapes, add or carve | P1 | M |
| 52 | **Scatter brush** | Paint trees, rocks, grass or any prefab across an area | P1 | M |
| 53 | **Symmetry / mirror** | Mirror edits across an axis for buildings and statues | P2 | S |
| 54 | **Grid & snap settings** | Snap edits and objects to 0.25 / 0.5 / 1 / 2 m grids | P1 | S |
| 55 | **Measure tool** | Distances, heights, areas | P2 | S |
| 56 | ★ **Asset Workshop** ✅ *done v0.13 (own screen with orbit camera and floor; fine voxels 3 cm to 50 cm; Add / Carve / Paint / Smooth / Socket tools; box, sphere, cylinder, cone, ramp; rounding, soft blend, turn, snap; mirror on X / Y / Z; material palette and fill; named sockets with a direction; 6 templates; .pxasset files; undo; edit a built-in asset as your own)* | Separate build space with 4x finer detail for making objects | P1 | L |
| 57 | ★ **Asset Browser** *(thin version done v0.12 and v0.13: thumbnails, search, click to place, a New button and Edit in the Workshop, a badge on your own assets; folders, tags and favourites still to do)* | Thumbnails, folders, tags, search, favourites, drag into the world | P1 | M |
| 58 | **Item & Weapon Builder** ✅ *done v0.14 (an Item tab in the Workshop: five behaviours, stats, what it does to the world, sounds and feel, hold pose; a firing range with targets, a dentable wall and sand; `.pxitem` files; a hotbar and the item in your hand in play mode; six built-in items; Save and try it in the world)* | Model + behaviour + stats + sockets + firing range | P1 | L |
| 59 | **Building Kits** ✅ *done v0.16 (five kits of seven pieces: wall, window, doorway, floor, roof, stairs, pillar; snapping on a 2 m grid with storeys; click, drag a run, replace, remove, rotate; restyle a selection or whole building; a Kits panel; kit pieces from the Workshop template; no grass through floors)* | Snap-together walls, floors, roofs, doors, windows, stairs | P2 | M |
| 60 | **Blueprint Tool** ✅ *done v0.17 (rooms on a floor plan up to 16 x 16 cells and four storeys; walls, spaced windows, a front door, doors between rooms, floors, automatic stairs with the floor above left open, pitched roofs with ridges, lean-tos and closed gables, or flat ones; edges and stairs by hand; warnings; seven ready-made plans; `.pxblueprint` files; edit and rebuild in place)* | Draw a floor plan; a full building with interiors is generated | P2 | L |
| 61 | **Character Creator** ✅ *done v0.18 (the Character Studio: six body sliders, skin, hair and clothes colours, five hair styles, any part swapped for one made in the Workshop, six ready-made people, `.pxcharacter` files, place them in the world, play as them)* | Body sliders plus sculpted parts on a skeleton | P2 | L |
| 62 | **Vehicle Builder** | Chassis, wheels, thrusters, seats, turrets as parts | P3 | L |
| 63 | **Prefab nesting & variants** | Prefabs inside prefabs; variants that update with the original | P2 | M |
| 64 | **Smart prefabs (randomise)** | One prefab, many looks: random rotation, scale, colour, part swaps | P2 | S |
| 65 | **Texture & decal importer** | Bring in your own PNGs as materials and decals | P2 | S |
| 66 | **Colour palettes** | Shared palettes per game so everything matches | P2 | S |

## 4. Objects and scene (67–78)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 67 | ★ **Movable objects** ✅ *done v0.12 (assets from prefabs placed as objects with position, rotation, size; Spin / Bob / Sway / Slide motion; solid to the player; saved in the world)* | Things that move, rotate and animate (not melted into terrain) | P1 | L |
| 68 | ★ **Transform gizmos** ✅ *done v0.12 (W / E / R, world or local axes, snapping, Esc cancels)* | Move / rotate / scale handles with snapping | P1 | M |
| 69 | **Multi-select & box select** *(multi-select done v0.12: Ctrl/Shift-click, Select All, group edits; box select still to do)* | Select many things, then edit, duplicate or delete them together | P1 | S |
| 70 | ★ **Outliner** ✅ *done v0.12 (tree, search, groups, drag to re-parent, rename, hide / lock / solid)* | Tree list of every object, with search, groups, hide and lock | P1 | M |
| 71 | **Layers** | Organise the world (Terrain, Props, Lighting, Gameplay) and toggle each | P2 | S |
| 72 | **Parenting & attachments** ✅ *done v0.12 (drag in the Outliner; children follow, spin and bob with their parent)* | Attach objects to each other (a lamp on a cart, a sword on a back) | P1 | S |
| 73 | **Properties panel** ✅ *done v0.12 (name, asset, position, rotation, size, flags, motion; edits are undoable)* | Every object's settings in the Inspector, edited live | P1 | M |
| 74 | **Light objects** | Place point, spot and area lights with colour, range and flicker | P1 | S |
| 75 | **Camera objects & cutscenes** | Place cameras, animate them on a timeline for intros and cutscenes | P2 | M |
| 76 | **Trigger volumes** | Boxes and spheres that detect who enters and leaves | P1 | S |
| 77 | **Spawn points** | Where players and NPCs appear, per team | P1 | S |
| 78 | **Timeline / sequencer** | Animate any property over time (doors, lights, cameras, events) | P3 | L |

## 5. Physics (79–90)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 79 | ★ **Physics engine (Jolt)** | Rigid bodies that tumble, stack and collide with the voxel world | P1 | L |
| 80 | ★ **Destruction & debris** | Blown-off chunks of terrain become physical rubble | P2 | L |
| 81 | **Structural integrity** | Undermined buildings and overhangs collapse realistically | P2 | L |
| 82 | **Explosions** | Crater + force + debris + effects from one call | P1 | M |
| 83 | **Ragdolls** | Characters go limp and tumble when knocked out | P2 | M |
| 84 | **Vehicles physics** | Wheels, suspension, hovering, flying | P2 | L |
| 85 | **Joints & ropes** | Hinges, sliders, chains, rope bridges, grappling hooks | P2 | M |
| 86 | **Buoyancy & swimming** | Things float, players swim and dive | P2 | M |
| 87 | **Wind & forces** | Wind zones, jump pads, gravity zones, conveyor belts | P2 | S |
| 88 | **Projectiles** | Fast, accurate bullets and arcs that hit voxels and objects | P1 | M |
| 89 | **Character controller upgrades** | Crouch, slide, ladders, ledge climbing, step-up, moving platforms | P1 | M |
| 90 | **Collision layers** | Choose what collides with what (players, NPCs, debris, triggers) | P1 | S |

## 6. Characters and AI (91–100)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 91 | **Skeletons & skinned rendering** 🟡 *16-bone skeleton with rigid voxel parts per bone done v0.18; smooth skinning later* | Animated characters made of voxel parts on bones | P2 | L |
| 92 | **Procedural animation & IK** ✅ *done v0.18 (idle, walk, run, jump, land, turn; two-bone foot IK on terrain and objects; look-at; two-handed, one-handed and melee holds with arm IK)* | Feet on real ground, aiming, holding items, looking at things | P2 | L |
| 93 | **Animation clips & blending** | Custom keyframed moves blended with procedural motion | P3 | M |
| 94 | ★ **Pathfinding on voxels** | NPCs find their way over hills, through caves and up stairs, and adapt when terrain changes | P1 | L |
| 95 | **NPC behaviour presets** ✅ *done v0.20 (stand, wander, patrol, guard, follow, work; friendly, shy and scared reactions; fighting comes with health and damage)* | Wander, patrol, guard, work, follow, flee, fight | P2 | M |
| 96 | **Behaviour trees** | Advanced AI logic for coders and power users | P3 | M |
| 97 | **Perception** | NPCs see (line of sight) and hear (noise from footsteps, gunfire) | P2 | M |
| 98 | **Schedules & needs** 🟡 *daily schedules done v0.20 (a role by the hour); needs later* | Daily routines (home, work, eat, sleep) for living worlds | P3 | M |
| 99 | **Crowds** 🟡 *Make a Crowd v0.19 (everyone different), people keep apart v0.20; hundreds at once needs instancing* | Hundreds of simple background people that avoid each other | P3 | L |
| 100 | **Third-person camera** ✅ *done v0.18 (V in play mode: over the shoulder, pulled in by walls; your item in your hand)* | Over-the-shoulder and orbit cameras with collision, as well as first-person | P1 | S |

## 7. Gameplay building blocks (101–116)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 101 | ★ **Trigger + When/Then rules** ✅ *done v0.21 (7 triggers, 14 actions, delays, once; written as sentences in Properties)* | No-code gameplay: "When player enters → open door, add points" | P1 | L |
| 102 | ★ **Game rules panel + templates** | Score, teams, timers, lives, win/lose; Parkour, CTF, Survival, Sandbox templates | P1 | M |
| 103 | **Health & damage system** | Health, armour, damage types, death, respawn; works on players, NPCs and objects | P1 | M |
| 104 | **Interaction system** | "Press E to open / pick up / talk / sit" on any object | P1 | S |
| 105 | **Inventory system** | Slots, stacking, hotbar, drag and drop UI | P1 | M |
| 106 | **Equipment & holding items** | Hold, aim and use items; equip armour to body slots | P2 | M |
| 107 | **Crafting** | Recipes, workbenches, resource gathering from the voxel world | P2 | M |
| 108 | **Currency & shops** | Money, prices, buy/sell, vendors | P2 | S |
| 109 | **Quests & objectives** | Objective chains, markers, rewards, journal | P2 | M |
| 110 | **Dialogue** | Branching conversations with conditions and choices | P2 | M |
| 111 | **Save games & checkpoints** | Player progress saved separately from the world design | P1 | M |
| 112 | **Teams & factions** | Membership, friendly fire, relations between factions | P2 | S |
| 113 | **Doors, keys & locks** ✅ *v0.21 gadgets: door, gate, plate, button, key (locks with conditions later)* | Ready-made door/lever/button/key logic | P1 | S |
| 114 | **Pickups & collectibles** 🟡 *v0.21: coins, gems, keys with points; health and ammo with v0.22's game rules* | Coins, health packs, ammo, power-ups, respawning | P1 | S |
| 115 | **Day/night gameplay events** | Run rules at times of day (shops close, monsters spawn) | P2 | S |
| 116 | **Achievements & stats** | Track player stats and unlock achievements | P3 | S |

## 8. Scripting and logic (117–124)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 117 | **Lua scripting** | Scripts on objects and games; safe, so errors never crash the engine | P2 | L |
| 118 | **Visual node graph** | Wire events to actions; compiles to the same runtime as rules | P2 | L |
| 119 | **Hot reload** | Edit scripts, assets and materials while the game runs | P2 | M |
| 120 | **Script debugger** | Breakpoints, step through, watch variables | P3 | M |
| 121 | **Event bus** | One system for "something happened" that rules, scripts and C++ all share | P1 | S |
| 122 | **API docs, generated** | Always-current scripting docs in-editor with examples | P2 | S |
| 123 | **Developer console** | Type commands (`spawn`, `teleport`, `time 18:00`, `god`) and tweak settings live | P1 | S |
| 124 | **Data tables** | Spreadsheet-style editing of items, enemies and stats inside the editor | P2 | M |

## 9. Audio (125–132)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 125 | ★ **Audio engine** ✅ *done v0.9 (SDL3 device + own mixer: 64 voices, buses, fades, looping, .wav loading; streaming music next)* | Sound playback, mixing and streaming music | P1 | M |
| 126 | ★ **3D positional sound** ✅ *done v0.9 (pan, distance falloff, treble loss with distance, muffled under water)* | Sounds come from where they happen, and fade with distance | P1 | S |
| 127 | **Footsteps by material** ✅ *done v0.9 (8 materials + water; landing, jumping, splashing, swimming)* | Different steps on grass, stone, wood, metal, snow | P1 | S |
| 128 | **Cave reverb** | Echo that comes from how enclosed the space is, measured from voxels | P2 | M |
| 129 | **Ambient zones** ✅ *done v0.9 (wind by altitude, shore water, cave drone and drips, crickets at night, birdsong by day; games add their own `AmbientZone`s)* | Birds in forests, wind on peaks, drips in caves, city hum | P1 | S |
| 130 | **Music system** | Playlists and adaptive music that changes with combat or location | P2 | M |
| 131 | **Sound effects library** ✅ *done v0.9 (71 generated sounds, no files to ship; `SpireEngine --export-sounds dir` writes them as .wav)* | Built-in starter pack of common sounds | P1 | S |
| 132 | **Audio mixer** ✅ *done v0.9 (master, effects, ambience, music, interface sliders in Settings)* | Volume groups (music, effects, voice, UI) with settings sliders | P1 | S |

## 10. Game UI and menus (133–140)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 133 | **HUD designer** | Drag health bars, counters, text, icons onto the screen; bind to game values | P2 | L |
| 134 | **Menu designer** | Main menu, settings, game over and pause screens without code | P2 | M |
| 135 | **Minimap & compass** | Ready-made, using the generated world map | P2 | S |
| 136 | **Floating text & markers** | Damage numbers, name tags, objective markers | P2 | S |
| 137 | **Localization** | Translate a game's text into other languages | P3 | M |
| 138 | **Subtitles & captions** | For dialogue and important sounds | P2 | S |
| 139 | **Gamepad support** | Controllers for play mode and for the editor | P1 | M |
| 140 | **Rebindable controls** | Players remap every key | P1 | S |

## 11. Editor experience (141–162)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 141 | ★ **Dockable panels & saved layouts** ✅ *done v0.10 (every panel is a window you can tab, split, float and close; 3 presets + your own saved layouts; the 3D view fills the free space)* | Drag panels anywhere, tab them, save layouts per task | P1 | M |
| 142 | ★ **Command palette (Ctrl+P)** ✅ *done v0.10 (fuzzy search over 65+ commands; games add their own)* | Search and run any action or setting by typing | P1 | S |
| 143 | **Search everything** | Find assets, objects, settings and docs from one box | P2 | S |
| 144 | **Keybinding editor** | Change every editor shortcut | P2 | S |
| 145 | **Themes & UI scale** | Dark, darker, light, high-contrast; scale slider | P2 | S |
| 146 | **History panel** | Every undo step by name; jump to any point | P2 | S |
| 147 | ★ **Autosave & crash recovery** ✅ *done v0.10 (rotating autosaves when something changed, atomic saves, a crash lock that offers the autosave back next start)* | Never lose work | P1 | S |
| 148 | **Snapshots** | Named restore points of a world ("before the big flood") | P2 | S |
| 149 | **Play from here** | Start playing at the cursor, instantly | P1 | S |
| 150 | **Live inspect while playing** | Pause, select and tweak objects mid-game, then resume | P2 | M |
| 151 | **Time controls** | Slow motion, pause and step frame-by-frame while playing | P2 | S |
| 152 | **Camera bookmarks** ✅ *done v0.10 (Ctrl+1..9 fly there, Ctrl+Shift+1..9 save; named, kept with the world)* | Save viewpoints and jump between them with 1–9 | P1 | S |
| 153 | **Split viewports** | Top / side / perspective views at once | P3 | M |
| 154 | **Top-down map view** | Navigate huge worlds from a map; click to teleport | P2 | S |
| 155 | ★ **Guided tutorials** | First-run tour and step-by-step lessons inside the editor | P1 | M |
| 156 | **Help on every panel** | "?" buttons that explain each setting | P1 | S |
| 157 | **Sample worlds** | Example projects that show off each feature | P1 | S |
| 158 | **Notifications centre** | History of messages, warnings and errors | P2 | S |
| 159 | **Video capture** | Record clips straight from the editor or game | P3 | M |
| 160 | **Recent projects & pinning** | Project Hub shows recent worlds with thumbnails | P1 | S |
| 161 | **Project settings** | Per-game settings page: name, icon, default world, input map, physics | P1 | S |
| 162 | **Asset dependency view** | See what uses what before deleting or changing it | P3 | S |

## 12. Debugging and performance (163–170)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 163 | **Profiler overlay** | Frame time broken down (render, world, physics, scripts, UI) | P1 | S |
| 164 | **Debug views** | Chunk borders, collision, normals, lighting only, overdraw, LOD levels | P1 | S |
| 165 | **Log console** | Filterable engine and game log inside the editor | P1 | S |
| 166 | **Memory & streaming stats** | Chunk memory, GPU memory, queue sizes, timings | P2 | S |
| 167 | **Crash reporter** | Saves a report and the last autosave if the engine crashes | P2 | S |
| 168 | **Benchmark mode** | Fly a fixed path and report FPS, for comparing settings and PCs | P2 | S |
| 169 | **Automated tests in editor** | Run engine and game tests from a panel | P3 | S |
| 170 | **Job system** | One shared multi-core task system for streaming, physics, AI and meshing | P2 | M |

## 13. Multiplayer and online (171–178)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 171 | **Networking core** | Dedicated and listen servers, connections, replication | P2 | L |
| 172 | **Replicated voxel edits** | Everyone sees digging and building instantly (uses the edit log) | P2 | M |
| 173 | **Client prediction** | Smooth movement and shooting despite lag | P2 | L |
| 174 | **Co-op editing** | Several creators build the same world together, live | P3 | L |
| 175 | **Live director permissions** | Zeus-style game master over a running server | P3 | M |
| 176 | **Lobbies & matchmaking** | Join friends, server browser | P3 | M |
| 177 | **Local multiplayer test** | Launch 2–4 clients from the editor to test multiplayer | P2 | S |
| 178 | **Voice & text chat** | Proximity voice, team chat | P3 | M |

## 14. Platform and distribution (179–188)

| # | Feature | What it adds | P | Size |
|---|---|---|---|---|
| 179 | ★ **One-click export** ✅ *done v0.23 (File > Share Game: a folder with the program, the world, what you made, game.pxgame and Play launchers; installers later)* | Package a game as a runnable folder or installer | P2 | M |
| 180 | **Asset packs (.pxpack)** | Share buildings, characters and weapons between projects | P2 | S |
| 181 | **Mod support** | Players add content to shipped games | P3 | L |
| 182 | **Workshop / marketplace** | Browse and download community assets and templates | P3 | L |
| 183 | **Display settings** ✅ *done v0.11 (window mode, monitor, resolution, V-Sync, frame limit, UI scale; saved between runs)* | Fullscreen, borderless, resolution, monitor, frame cap | P1 | S |
| 184 | **Accessibility pack** | Colour-blind modes, text size, hold-to-toggle, reduced motion, screen shake off | P1 | S |
| 185 | **Steam integration** | Achievements, cloud saves, workshop | P3 | M |
| 186 | **Linux & macOS builds** | Run the engine and exported games on other platforms | P3 | M |
| 187 | **Game icons & splash screens** | Per-game branding for exported builds | P2 | S |
| 188 | **Engine updater** | Check for and install new engine versions from the hub | P3 | M |

---

## "Feels complete" sprint (recommended next)

The engine feels basic mainly because of flat colours, an empty sky, no water,
silence, and nothing moving. These 12 items change that most per hour of work:

| Order | Items | Result |
|---|---|---|
| 1 ✅ | Sky & atmosphere (1), day/night (2), post-processing (10), anti-aliasing (12) | **Done in v0.6** |
| 2 ✅ | Textured terrain (4), material paint brush (48), smooth brush (47) | **Done in v0.7** |
| 3 ✅ | Grass & foliage (8), water (7) | **Done in v0.8** |
| 4 ✅ | Audio engine (125), 3D sound (126), footsteps (127), ambient zones (129) | **Done in v0.9** |
| 5 ✅ | Dockable panels (141), command palette (142), autosave (147), camera bookmarks (152) | **Done in v0.10** |
| 6 ✅ | Graphics presets (26), display settings (183) | **Done in v0.11**: it behaves like real software |
| 7 ✅ | Objects (67, 68, 70, 72, 73), thin Asset Browser (57) | **Done in v0.12**: things you place, move, group and animate |
| 8 ✅ | Asset Workshop (56) | **Done in v0.13**: you can make the things to place |
| 9 ✅ | Item & Weapon Builder (58) | **Done in v0.14**: you can make the things to hold, and test them |
| 10 ✅ | Richer materials (48, 6 and 15 in part) | **Done in v0.15**: paint colours, glow, tile, cloth, ice, plaster; makes everything after it look good |
| 11 ✅ | Building Kits (59) | **Done in v0.16**: snap-together houses in five styles, with storeys, stairs and one-click restyle |
| 12 ✅ | Blueprint Tool (60) | **Done in v0.17**: draw the rooms, get the whole house |
| 13 ✅ | Character Creator (61), procedural animation (92), third person (100) | **Done in v0.18**: people to fill the world, and you can see yourself |
| 14 ✅ | People with personality (61, 92) | **Done in v0.19**: faces, clothes and accessories, move styles and habits, crowds where everyone is different |
| 15 ✅ | NPCs that live (95, 98) | **Done in v0.20**: roles, reactions, what they say, daily schedules, patrol paths and work spots, name tags |

**The sprint is complete.** **v0.12 added objects** (67, 68, 70, 72, 73 and a thin 57): things you place, move,
turn, resize, group and animate, saved in the world. **v0.13 added the Asset Workshop (56)**: a screen for building
your own assets out of fine voxels, with sockets and templates, saved as `.pxasset` files. **v0.14 added the Item &
Weapon Builder (58)**: give a model a behaviour (sword, gun, launcher, grenade, digging tool), tune it on a firing range,
and play with it. **v0.15 added richer materials**: paint colours, glowing lava, lamps and crystals, plaster, tile, cloth and ice. **v0.16 added Building Kits (59)**: five styles of snap-together walls, windows, doors, floors, roofs, stairs and pillars, built by clicking or dragging. **v0.17 added the Blueprint Tool (60)**: draw rooms on a floor plan and the whole building is generated from a kit, walls, windows, doors, stairs and roof included, and can be opened again and rebuilt in place. **v0.18 added characters (61, 92, 100)**: the Character Studio, procedurally animated people with their feet on the real ground, placed in the world, and a third-person view of yourself. **v0.19 gave people personality**: faces that blink and show moods, 34 clothes and accessories, move styles and idle habits, and Make a Crowd. **v0.20 brought them to life**: roles (wander, patrol, guard, follow, work), reactions, speech bubbles, name tags and daily schedules. **v0.21 made worlds into games**: "When this happens → do that" rules on any object, and ten gadgets (doors, gates, plates, buttons, coins, gems, keys, signs, teleporters, finish flags). **v0.22 added game rules and templates**: goals, a clock, lives, falling and checkpoints, and five starter games (Parkour, Coin Hunt, Capture the Flag, Survival, Sandbox). **v0.23 added Share**: File > Share Game packs a game into a folder that runs on its own, straight into the game. **v0.24 polished it**: a first-run tutorial, rebindable keys, and accessibility settings (colour-blind friendly colours, a bigger HUD, captions, reduce motion). **1.0** is the stable release: sanitizer-clean, fuzzed file readers, a soak test, and the final docs.

**After 1.0**, the most wanted next steps: pathfinding on voxels (94) so people find their way round walls and through buildings; conditions in rules ("only if you have the key") and variables; health and damage (103) so guards and hunters can fight; multiplayer; smooth-skinned characters (91); installers and icons for shared games; and opening the rules up as Lua for coders.
