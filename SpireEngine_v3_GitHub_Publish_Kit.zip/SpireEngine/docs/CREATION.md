# Spire Engine — Creation Tools Design

How developers make the things in their game: **people, buildings, weapons and
items**, all inside the engine, without Blender, without code, without an
animator. This is engine work; every game gets it.

## 1. One idea underneath everything

Today the only thing you can make is **terrain**: prefabs get melted into the
ground and can't move. Characters, doors, cars and guns all need to move, so
the foundation is two new engine concepts.

**Asset.** A thing you designed, saved as a `.pxasset` file:
- a voxel model at **much finer detail** than terrain (0.125 m by default; 3 cm to 50 cm, chosen per asset)
- a **material** per voxel (stone, wood, metal, cloth, glass, glow...)
- **sockets**: named points such as `grip`, `muzzle`, `seat`, `head`, `hand_r`
- a **type** (Prop, Building Piece, Character Part, Item, Vehicle Part), tags and a thumbnail
- type-specific **settings** (a weapon's damage, a door's swing angle...)

**Object.** One placed copy of an asset in a world, with a position, rotation
and scale. Objects move, collide, can be picked up, and are saved with the world.
Ten thousand identical trees still share one asset (instanced rendering).

```
            Asset Workshop                       World
  sculpt + paint + sockets + settings   →   place objects from the Asset Browser
          saved as  .pxasset                 move / rotate / animate / script them
```

Because assets are still voxels, **everything stays destructible**: a bullet
can chip a statue and a wall can be blown open. Assets can be **baked down into
terrain** (today's prefab behaviour) when they never need to move.

## 2. The Asset Workshop *(built in v0.13)*

A separate editing mode: the world is swapped for a clean, lit **build bubble**
with a grid floor. It uses the same tools you already know, plus:

- **Fine detail**: voxels from 50 cm down to 3 cm, chosen when you start an asset
- **Primitives**: box, sphere, cylinder, wedge, cone; add or carve, with soft or hard edges
- **Mirror** on X / Y / Z, for faces, characters and vehicles
- **Paint**: material brush, fill, and a palette per asset
- **Sockets**: click to drop a named attachment point and set its direction
- **Templates** to start from: humanoid mannequin, sword blank, pistol blank,
  wall segment, door frame
- **Preview**: orbit camera, time-of-day light, a person for scale, wireframe. *(The in-hand view is the firing range in the Item tab; Spin and an in-world view come later.)*

**What v0.13 ships:** everything above except the in-hand / in-world preview buttons, plus a New Asset
dialog, a side panel (name, type, tags, brush, material, mirror, sockets, view), unsaved-changes
protection, an undo history of its own, and `Save and Place in the World`. Asset names become file names:
`assets/<name>.pxasset`.

## 3. Buildings *(Building Kits built in v0.16, the Blueprint Tool in v0.17)*

Three ways to build, from freeform to fast. All produce normal, editable,
destructible geometry.

| Method | For | How it works |
|---|---|---|
| **Sculpt** (works today) | One-off structures, ruins, caves | Carve, Build and Flatten straight in the world |
| **Building Kits** ✅ | Towns and cities fast | Snap-together pieces (walls, windows, doorways, floors, roofs, stairs, pillars) on a 2 m grid with 2.5 m storeys; click or drag a run, R rotates, the wheel changes storey. Each kit is a set of assets tagged `kit:<Style>` and `role:<role>`, so you can make your own in the Workshop (New asset → Building kit piece). Swap a building's style in one click. |
| **Blueprint Tool** ✅ | Whole buildings in seconds | Draw rooms on a floor plan, choose storeys and a style; the engine generates the building with interiors using a kit: outside walls with windows, a front door, doorways between rooms, floors, stairs (the floor above left open) and a pitched or flat roof. Set any edge by hand (door, window, wall, open) or place stairs yourself. The plan is kept on the building, so you can open it again and rebuild, or hand-edit the pieces with the kit tools. |

Doors and windows are **objects** (they open, break and lock); walls and floors
are terrain-style density (cheap, destructible). Games can mark buildings as
ownable property later, which is what Vanguard's safehouses will use.

## 4. People (characters and NPCs) *(Character Studio and procedural animation built in v0.18; personality and crowds in v0.19)*

**Character Creator** (an editor tab plus a Workshop template):

1. **Body.** A standard humanoid skeleton (~16 bones) with sliders for height,
   build, shoulder width, leg length and head size.
2. **Parts.** Heads, hair, torsos, arms, legs, armour and clothing are assets
   sculpted in the Workshop and attached to bones via sockets. Start from the
   default parts, or make your own.
3. **Style.** Skin, hair and clothing colours; material painting for detail.
4. **Saved** as a `.pxcharacter` that the player or any NPC can use.

**Animation without an animator.** Characters move with **procedural animation**:
- Walk, run, crouch, jump, climb: feet plant on the actual voxel ground (IK),
  so slopes, stairs and rubble just work
- Look-at, aim, hold an item by its `grip` socket, reach for ladders
- Hit reactions and ragdoll when the physics engine lands
- Optional **Pose & Clip Editor** for custom emotes, attacks and cutscenes

**NPC behaviour** is built from **presets** (wander, patrol, guard, work, follow,
flee, fight) and **daily schedules** (home 22:00–07:00, work 08:00–17:00). They
react through the same When/Then rules as everything else, so a beginner can make
a shopkeeper and a coder can override it in Lua.

**What v0.18 ships:** the **Character Studio** (Tools > Character Studio, Ctrl+Shift+C): a 16-bone skeleton
(pelvis, chest, neck, head, and three bones in each arm and leg), six body sliders (height, build, shoulders, legs,
arms, head), skin, hair and clothes colours, five hair styles, six ready-made people (Explorer, Builder, Agent,
Scientist, Kid, Giant) and a Parts tab where any part can be swapped for an asset tagged `part:<slot>` made in the
Workshop (its socket `joint` is where it attaches). The preview stands, walks, runs, jumps and looks around, holding
any item. Procedural animation drives everything: a gait cycle from the distance travelled, turning, jumping and
landing, look-at, arm IK for one-handed, two-handed and melee holds, and **foot IK** on terrain and on objects (the
pelvis drops, each leg bends, the feet lie along the slope). Characters are placed in the world (they breathe and look
at you), saved as `.pxcharacter`, and **V** in play mode shows you in third person as the character you chose. Still
to come: NPC behaviour and schedules, ladders and climbing, ragdolls, the pose and clip editor, smooth skinning.

**What v0.19 adds: people who stand out.** Silhouette first: hats, glasses, beards and things on the back are their own
slots, outfits change the shape (coats, skirts, robes, armour, bare arms, shorts, boots). Faces are built into the head
(eyes, brows, nose, mouth) and a blinking copy of each is made on demand. Movement carries personality: a `MoveStyle`
per character, and idle habits picked by a seeded random so no two people fidget in step. A crowd is made from numbers:
`crowd:<style>:<seed>` always makes the same person, so a world with a hundred villagers stores a hundred short names.

First version: rigid parts per bone (like Roblox R15). It's simple, looks
clean, and it's fully voxel. Smooth-skinned bodies can come later.

## 5. Weapons and items

The **Item Builder** *(built in v0.14)* is a model, a behaviour and some numbers. In the Workshop, an asset whose type is
Item gets an **Item** tab beside the Model tab:

| Step | What you do |
|---|---|
| **Model** | Sculpt it in the Workshop, or start from a template blank |
| **Sockets** | Mark `grip` (and `muzzle`, `blade_tip`, `sight` as needed) |
| **Behaviour** | Pick one: Melee, Hitscan gun, Projectile launcher, Thrown, Tool (dig/build). *(Consumable and Placeable come later.)* |
| **Stats** | Sliders: damage, fire rate, magazine, reload time, spread, recoil, range, projectile speed, gravity, swing arc |
| **World effect** | What a hit does to the world: dig a hole or build a lump, its size and material, blast push (uses the engine's CSG, so weapons really dig and rocket jumps really work) |
| **Feel** | Fire and hit sounds, volume and pitch, muzzle flash, tracer and its colour, camera shake, and the hold pose (offset, turn, tilt, roll, size) |
| **Test** | A built-in **firing range** in the Workshop: target plates, dummies and drums, a wall and a block of sand that dent, distance marks, damage numbers, accuracy and damage-per-second, live stat tweaking |

Items are saved as `.pxitem` (asset + behaviour + stats) beside the model. In the sandbox the whole kit is on a hotbar
(keys 1-9, mouse wheel); the item you were just building comes first. Giving items to the player from a rule ("When
player enters armoury → give Pistol") comes with the rules system.

Known limits for now: there is no health system yet, so damage is reported to the game (`onItemHit`) and counted by the
range, not applied to anything in the sandbox; reserve ammo is unlimited (you reload, you never run out); scene objects
are told they were hit but are not dented; craters dug in play mode are recorded as world edits like any other digging;
and items are off in a game unless it opts in with `app.inventory.enabled = true` (Vanguard keeps its powers).

Games can add **their own behaviours**. Vanguard could register a "Power"
behaviour so new powers get built with the same tool.

## 6. Build order

| Step | Delivers | Why this order |
|---|---|---|
| 1 ✅ | **Assets + Objects + Workshop + Asset Browser** *(done v0.12 and v0.13)* | The foundation; nothing else works without it |
| 2 ✅ | **Material painting** *(done v0.15: plaster, tile, cloth, ice, lava, lamp, crystal, nine paint colours)* | Makes everything after it look good |
| 3 ✅ | **Item & Weapon Builder** *(done v0.14)* | Smallest complete flow from making a thing to playing with it; proves sockets, behaviours and stats |
| 4 ✅ | **Building Kits** *(done v0.16)*, then the **Blueprint Tool** *(done v0.17)* | Reuses objects + snapping; fast world building |
| 5 ✅ | **Character Creator + procedural animation** *(done v0.18)* | The biggest piece; reuses sockets, parts and items (characters hold weapons) |
| 6 ✅ | **NPC presets + schedules** *(done v0.20)* | Characters come alive: roles, reactions, lines, schedules |

## 7. File formats (planned)

| File | Contents |
|---|---|
| `.pxasset` ✅ v0.13 | `PXAS`, version, readable JSON (name, type, tags, voxel size, grid size, pivot, sockets), run-length-coded density and material data. Type-specific settings and an embedded thumbnail come later (thumbnails are drawn from the model today) |
| `.pxcharacter` ✅ v0.18 (v0.19 additions) | readable JSON: `format`, `version`, name, `body` (height, build, shoulders, legs, arms, head), `colours` (skin, hair, top, bottoms, shoes, accent as `#rrggbb`), `hair` style, `face` ([eyes, brows, nose, mouth]), `move` (stride, swagger, armSwing, bounce, posture, fidget), `parts` (slot → asset name, including clothes and the hat, glasses, beard and back slots) and `partColours` (slot → `#rrggbb`). Older files load with the defaults |
| `.pxblueprint` ✅ v0.17 | readable JSON: `format`, `version`, name, kit style, size in cells, roof, windows, the switches (front door, doors inside, stairs for me, corner posts), room names, and per storey the room grid as rows of characters (`.` outside, `1`-`9`, `A`-`W`), edges set by hand (`["x", 2, 3, "door"]`) and stairs (`[x, z, dir]`). A built building keeps the same JSON plus `origin` and `turns` |
| `.pxitem` ✅ v0.14 | readable JSON: `format`, `version`, name, asset, description, behaviour, stats, effect (kind, radius, material, push), feel, hold pose. Keys left out take the behaviour's defaults, numbers are brought into a safe range on load |
| `.pxcharacter` | body sliders + parts per bone + colours |
| `.pxkit` | not needed so far: a kit is the set of assets tagged `kit:<Style>`, found by tag. May come back as a way to share a kit as one file |

Metadata is stored as readable JSON next to the binary voxel data, so rules,
scripts and other tools can read and edit it easily.
