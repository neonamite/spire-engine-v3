# WB16 Linux test environment report

Project: consolidated WB15 extracted to Linux test workspace.

Connected GitHub API could read SDL upstream CMakeLists.txt; container DNS still does not resolve github.com or deb.debian.org. This is not a downloaded Linux dependency distribution.

## cpu mode — initially exit 1 (corrected)

````text
[WB16] Configuring CPU validation target
-- The CXX compiler identification is GNU 14.2.0
-- Detecting CXX compiler ABI info
-- Detecting CXX compiler ABI info - done
-- Check for working CXX compiler: /usr/bin/c++ - skipped
-- Detecting CXX compile features
-- Detecting CXX compile features - done
CMake Error at tests/cpu_only/CMakeLists.txt:16 (message):
  GLM unavailable.  Supply -DSPIRE_GLM_INCLUDE_DIR=/path/to/include


-- Configuring incomplete, errors occurred!

````

## graphics mode — exit 1

````text
[WB16] Configuring complete Linux graphics application
-- The CXX compiler identification is GNU 14.2.0
-- Detecting CXX compiler ABI info
-- Detecting CXX compiler ABI info - done
-- Check for working CXX compiler: /usr/bin/c++ - skipped
-- Detecting CXX compile features
-- Detecting CXX compile features - done
CMake Error at engine/CMakeLists.txt:2 (find_package):
  Could not find a package configuration file provided by "glm" with any of
  the following names:

    glmConfig.cmake
    glm-config.cmake

  Add the installation prefix of "glm" to CMAKE_PREFIX_PATH or set "glm_DIR"
  to a directory containing one of the above files.  If "glm" provides a
  separate development package or SDK, be sure it has been installed.


-- Configuring incomplete, errors occurred!

````

Windows x64 dependency files are retained only for Windows building, and MUST NOT be treated as Linux binaries. No complete graphics executable was produced unless the graphics command above exited 0.

## Corrected CPU-only validation
The Linux test harness initially used the wrong CMake variable `GLM_INCLUDE_DIR`; corrected it to `SPIRE_GLM_INCLUDE_DIR`. Reran `bash tools/validate_linux_full.sh cpu`: configure succeeded, compile/link succeeded, CTest **12/12 passed**. See tool log from actual execution.

## Outstanding full graphics integration
`bash tools/validate_linux_full.sh graphics` failed at `find_package(glm CONFIG REQUIRED)` because no native Linux GLM CMake package is installed. Full SDL3, glad and ImGui Linux libraries also remain uninstalled. The connected GitHub repository reader successfully fetched source text but cannot automatically install all required native dependencies in this network-isolated container.
