# WB8 — CPU-only CMake build integration

This opt-in build mode compiles independent geometry, planet and blank-canvas tests with **no SDL3, glad, ImGui, or engine renderer**. It does not produce or test SpireEngine.exe.

## Example Linux commands

```sh
cmake -S . -B build-cpu -DSPIRE_CPU_ONLY=ON -DSPIRE_GLM_INCLUDE_DIR=/path/to/vcpkg_installed/x64-windows/include
cmake --build build-cpu --parallel 2
ctest --test-dir build-cpu --output-on-failure
```

GLM is header-only for these tests; using headers found in a Windows dependency tree does **not** constitute a Linux application build. A normal full build remains the default when `SPIRE_CPU_ONLY=OFF`.

## Scope

CPU-only mode intentionally excludes tests requiring the full engine library, including runtime persistence and editor tests. Build these in a fully provisioned native toolchain before declaring the application integrated.
