# Spire Engine v3 — WB6 Build Integration Recovery

Date: 2026-10-13

## Verified source fix

`engine/editor/EditorUI.cpp`: closed the Advanced Procedural Terrain tree-node conditional before the separate Streaming settings. WB5 omitted this brace, leaving `Application::drawEditorUI()` unclosed and causing the compiler to parse the later `Application::buildLayout()` definition inside the previous method.

After correcting the scope, this translation unit completed a GCC 14 C++20 syntax-only compilation successfully using dependency headers extracted from the project's earlier vcpkg Windows installation. This validates parsing only, not linking or the graphics runtime.

## Full build blocker

`cmake -S SpireEngine -B build -DPROJECTX_BUILD_TESTS=ON` fails during configure at `engine/CMakeLists.txt:2` because a local Linux GLM CMake config package is unavailable. The engine also requires SDL3, glad, and Dear ImGui; a previous Windows-vcpkg include tree has headers but is **not** a usable Linux linkage environment. Full application binary and Windows runtime remain UNVERIFIED.

## Next actions

1. Configure with the Windows vcpkg toolchain on the intended platform (see root CMakeLists.txt and vcpkg.json).
2. Compile the entire engine and games, not just modified files; fix any additional compiler/linker errors.
3. Launch the editor and verify Project Hub > New Project > Blank Construction Canvas, generated-world opt-in, and experimental planet setup.
4. Test World inspector tabs and road/construction controls, especially the restored advanced procedural/settings tree.
5. Test saving/reloading scenes and validate GPU resources are released on world switching.

## Package usage

WB6 consolidated source includes all files from the WB5 consolidated source plus the scoped EditorUI.cpp repair and these notes. WB6 incremental patch includes only this repair and notes. Archive integrity can be validated by running `unzip -t <archive>`.
