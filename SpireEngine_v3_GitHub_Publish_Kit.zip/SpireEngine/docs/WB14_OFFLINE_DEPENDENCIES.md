# WB14 — Offline Windows graphics dependencies

This archive includes the latest WB13 engine source and the **existing prebuilt Windows x64** dependency tree found in an earlier Spire Engine build directory. It includes headers, CMake configs, import libraries, debug libraries, SDL3.dll, and upstream license notices for GLM, SDL3, glad, and Dear ImGui. These binaries were **not downloaded in this session** and their exact compiler/ABI compatibility with your PC has not been independently verified.

## Build on Windows without downloading these four libraries

Requirements: Visual Studio 2022 (Desktop development with C++), CMake, and Windows SDK.

From PowerShell in the `SpireEngine` project directory:

```powershell
powershell -ExecutionPolicy Bypass -File tools/build_windows_offline.ps1
```

Only configure:

```powershell
powershell -ExecutionPolicy Bypass -File tools/build_windows_offline.ps1 -ConfigureOnly
```

This uses `external/windows/x64-windows` as `CMAKE_PREFIX_PATH` and a fresh `build-windows-offline` directory; it does not need GitHub or vcpkg for these prebuilt four packages. If CMake chooses a vcpkg toolchain due to `VCPKG_ROOT` being set, unset that environment variable for the PowerShell session before building (`Remove-Item Env:VCPKG_ROOT -ErrorAction SilentlyContinue`).

### Limitations

- Only **Windows x64**, not Linux, binary libraries are included. Linux still needs native Linux builds of SDL3/glad/ImGui; copying `.lib` or `.dll` files will not work.
- The upstream libraries may require extra Windows SDK/system facilities supplied by Visual Studio.
- The Windows executable has **not** been compiled, linked, or run in this environment. This is a dependency bundle and build attempt script, not a verified application release.
- To use current pinned reproducible versions in the future, prefer vcpkg when connectivity is working.
- License notices are preserved in `external/windows/x64-windows/share/*/copyright`.
