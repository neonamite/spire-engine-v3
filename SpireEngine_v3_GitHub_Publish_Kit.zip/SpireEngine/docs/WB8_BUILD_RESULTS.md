# WB8 verified build results

- Date: 2026-10-13
- Baseline: WB7 consolidated source.
- New option: `-DSPIRE_CPU_ONLY=ON`; default remains OFF.
- First attempt failed: C++20 project setting was below early return. Corrected.
- CMake configuration: passed (CPU-only) with external GLM headers.
- Build: passed with GCC.
- CTest: **11/11 passed**, 0 failures.
- GLM headers taken from an existing Windows vcpkg include tree, used only as platform-independent headers.
- Full editor configure/link, Windows runtime, OpenGL viewport, UI behavior: **not verified**.
- Work remains: native graphics dependencies, full application link, real editor smoke tests.
