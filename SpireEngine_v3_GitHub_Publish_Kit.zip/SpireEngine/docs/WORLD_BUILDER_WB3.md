# WB3 — Manual Road Builder

Implemented in the World Inspector under **Manual Road Builder**; also reachable from the command palette.

1. Start or load a flat World Builder canvas.
2. Point the camera toward loaded ground and click **Pick Road Start**.
3. Move or rotate camera to look at the endpoint and click **Build Road**.
4. Save using the existing World Save action.

Roads are realized as ordinary voxel **Flatten** and **Paint** edits. Width is adjustable (2–16 meters), dirt and cobblestone are selectable, and grading can be disabled. Each segment is capped at 160 meters. Undo currently removes one individual terrain edit per invocation, **not the entire road**; grouped undo, road spline editing, junctions and native planetary roads remain future work. The surface follows a linear endpoint interpolation, not terrain-aware surveying. No new custom save format was introduced.

## Verification scope

Source changes: `engine/core/Application.h/.cpp`, `engine/editor/EditorUI.cpp`, `engine/editor/EditorCommands.cpp`. Full build/runtime verification is pending.
