> **Creator-first direction update — 2026-10-13:** Spire Engine is now prioritized as a **manual World Builder**, not a procedural-terrain showcase. A creator's primary workflow is to sculpt terrain and place roads, homes, cities, prefabs, and gameplay objects; procedural generation is a secondary, opt-in authoring tool. See [WORLD_BUILDER_FIRST.md](WORLD_BUILDER_FIRST.md) for revised implementation order and acceptance criteria. The original feature IDs #1–200 remain preserved.

> **Implementation update — 2026-10-13:** v2.0 Sprint C has an opt-in CPU prototype connecting radial terrain density to `VoxelChunk` and asynchronous `ChunkManager` workers. Headless tests pass. The authoritative high-precision chunk registry, cube-face quadtree runtime, planet movement/editor controls, GPU-relative rendering, and planet save format are **not yet implemented**. See [PLANETARY_MILESTONE_B.md](PLANETARY_MILESTONE_B.md) and [BUILD_VERIFICATION_MILESTONE_B.md](BUILD_VERIFICATION_MILESTONE_B.md).

# SPIRE ENGINE — NEW MASTER DEVELOPMENT ROADMAP

**Version:** Roadmap revision 2026-10-13  
**Baseline project:** Spire Engine v1.6 + uploaded Planetary Foundation A working copy  
**Source of goals:** 200 user-authored features, numbered 1–200 across five phases  
**Document role:** Implementation priorities, dependencies, acceptance gates, and truthful progress reporting

> **Status warning:** A phase label (v2.0, v3.0, v4.0, v5.0, v5.5) expresses the *target release*, not work that has already shipped. This document has not changed, built, or tested engine source. The checked-off features in the legacy v1.6 roadmap are historical project claims; no fresh runtime verification is implied.

## 0. Current baseline and evidence levels

The inspected archive contains a real C++20/CMake game-engine workspace with voxel chunks, Marching Cubes, procedural terrain, edit operations, a flat-world `ChunkManager`, OpenGL rendering, an editor, asset/scene systems, and an included Vanguard game. The original historical roadmap remains preserved at [`ROADMAP_v1.6_ARCHIVE.md`](ROADMAP_v1.6_ARCHIVE.md).

The **Planetary Foundation A** archive also contains the following **isolated prototypes**:

| Code | What it supplies | Integration / verification status |
|---|---|---|
| `engine/world/PlanetCoordinates.h` | `WorldPosition`, 64-bit `SectorCoord`, canonical local offsets and error-returning conversion helpers | Exists as an additive API; production camera/world ownership not migrated |
| `engine/world/PlanetDefinition.h` | Planet radius, seed, gravity, projection, terrain settings | Data definition only |
| `engine/world/SpherifiedCube.h` | Six-face projection helpers | Prototype; not a rendered global quadtree |
| `engine/world/CubeTile.h` | Face/level/tile addressing and seam-neighbor helpers | Prototype with source-level tests; gameplay integration unverified |
| `engine/world/TerrainProvider.h` | Flat provider adapter and radial planet density provider | Isolated; `ChunkManager` still directly uses flat terrain generator |
| `tests/PlanetaryFoundationTests.cpp` | Coordinate/edge/density tests | Tests are included; Windows pass is stated in the uploaded prototype documentation, but not independently rerun here |

**Evidence tags** used below: **Existing / historically documented** = source and prior documentation present; **Prototype** = isolated new code, not integrated; **Planned** = not established as implemented; **Gate met** = tested, built, and demonstrated on the target configuration. Do not substitute one tag for another.

## 1. Architectural principles (apply to every phase)

1. **Preserve flat-world compatibility.** Existing `TerrainGenerator`, `ChunkManager`, scene files, `.vxworld` saves, editing and Vanguard interactions must keep working while planetary systems are added behind explicit modes/adapters.
2. **Separate coordinates by purpose.** Store canonical absolute positions as sector-local values or other documented high-precision representation. Render/physics operate in nearby float coordinates. Avoid using raw planet-scale float vertices or float noise coordinates.
3. **Put worlds behind stable interfaces.** Planet/flat definitions, terrain samplers, chunk addresses, neighbors, gravity providers, persistence and content streaming must be versionable and independently testable.
4. **Keep jobs self-contained.** Workers do not mutate live chunks or upload OpenGL buffers. Prioritize, cancel, profile, and publish immutable mesh results; upload GPU resources on the owner thread.
5. **Design for 64-bit save IDs, not temporary memory addresses.** World/planet IDs, face IDs, sector keys, instance transforms, and edit operations must have stable serialization and migration tests.
6. **No unbounded simulation work.** Economy, fluids, thermodynamics, structural collapse, navmesh rebuilding and multiplayer replication need relevance/interest budgets and deterministic or reproducible state transitions.
7. **Profile before swapping algorithms.** Marching Cubes, Dual Contouring, dense chunks, SVOs, and GPU compute solve different jobs. Benchmarks—not aspirations—decide runtime migration.
8. **Prove a playable slice before scaling.** Real gameplay, edit persistence, robust seams, and recovery are release gates. A header-only prototype is not a completed feature.

## 2. Release track at a glance

| Release target | Catalog scope | Playable/creator value | Critical gate |
|---|---:|---|---|
| **v2.0 — Planetary Foundation & Core Math** | #001–040 | One stable editable spherical planet, surface and orbit views, radial up/gravity | Walk and sculpt across all cube-face seams; save, reload and revisit without visible cracks or precision drift |
| **v3.0 — Rendering & Micro-Detail** | #041–070 | Higher fidelity, scalable LOD, sharp architectural edits, configurable production renderer | Benchmark CPU/GPU cost; stable SVO/LOD/meshing topology with reproducible scene captures |
| **v4.0 — Physics, Sculpting & Assets** | #071–100 | Robust digital clay, destructible prefabs, polygonal characters, localized Jolt-based physics | Edits update collision correctly; structures and actors stay stable across origin shifts |
| **v5.0 — Zero-Code Platform & Spire Hub** | #101–140 | A creator can start a project, build UI, wire gameplay, test and package a game | First-time creator completes a scripted playable mini-game and exports it without editing C++ |
| **v5.5 — Living Sandbox & Differentiators** | #141–200 | Persistent faction economy, director mode, tactical PvP, moving ship worlds, bounded reactive matter | Authoritative multiplayer sessions; save/recover correctness; simulation budgets and permissions verified |

The catalog assignments mirror the user's original phase numbering. **Work sequencing can cross phase boundaries** when required: e.g. cross-chunk CSG (#72), camera/editor usability, test harnesses, crash reporting, and saves are foundational blockers for v2.0, not issues to ignore until their catalog phases.

## 3. Implementation path: immediate delivery order

### Sprint A — Baseline freeze and reproducible build (Gate A0)

- Confirm the intended Windows/MSVC + vcpkg build, tests, and sample launch from the uploaded source. Keep a build log with compiler and dependency versions.
- Separate generated `build/` and `vcpkg_installed/` outputs from distributable source. Never treat an archived build cache as proof of a clean build.
- Inventory active save formats (`.vxworld`, `.vxprefab`, `.pxasset`, project files), coordinate assumptions, and test coverage. Preserve fixtures for backward compatibility.
- Add source-change smoke tests: flat terrain generation, chunk-streaming order, editing/undo, save/reload, play-mode movement, and viewport captures.

**Done when:** a clean checkout can configure, build, launch, and pass selected tests on a documented target machine; historical worlds load.

### Sprint B — Coordinate authority and camera-relative rendering (Gate A1)

- Adopt the sector-local `WorldPosition` as the high-precision authority in new planetary components (#1–3), while preserving local `glm::vec3` adapters for legacy modules.
- Specify normalized 64-bit sector math, negative boundaries, overflow rejection, and cross-sector interpolation for velocities (#6, #9).
- Introduce an explicit `RenderOrigin` and relative-to-eye object transforms (#2), with one defined owner for origin shifts (#4, #10).
- Add stable world-to-local conversions and explicit units (meters, kilometers, AU, light-seconds) (#7).
- Evaluate reversed-Z (#5) only where the selected GL/depth configuration supports it; verify occlusion, transparency, and shadow interactions.

**Done when:** 1-mm nearby relative offsets remain distinct at huge sector indices, origin shifts preserve visual alignment, and the unmodified flat demo still works.

### Sprint C — Planet samples, tile topology, and terrain-provider integration (Gate A2)

- Finish `CubeTile` face-edge/corner reciprocal mappings, and add inverse world-direction-to-tile addressing and deterministic orientation tests (#11–13, #19).
- Preserve the flat generator behind a terrain-provider interface; integrate the radial provider into chunk generation without breaking edit snapshots (#20, #31–40).
- Implement planet-bound identifiers, six-face quadtree address types, tile LOD, adjacent-level seam policy, and precise sample domains (#14–16).
- Generate landmass noise in normalized or sector-local coordinates; avoid passing huge 32-bit x/y/z coordinates into FastNoiseLite. Start with smooth noise, then introduce domain warp/caves/continental masks under deterministic seeds (#31–37).
- Define explicit planet-center, radius, sea level and shell depth; enforce material/air density conventions and solid/air interpolation (#20, #38–39).

**Done when:** six faces meet without mesh gaps, tile neighbors are reciprocal, terrain is deterministic at tile boundaries, and a single planet can be streamed as data without a character controller.

### Sprint D — Walkable planet and orbit proof (Gate A3)

- Adapt the camera, movement, raycasts and character controller to planet-relative 'up' (#17), while retaining flat Y-up mode.
- Implement radial gravity, ground-contact stability at slopes, a surface/orbit camera switch, and a separate long-distance planet representation rather than a huge far plane.
- Add frustum, horizon, and distance culling (#18), guarded against culling large mountains or high-altitude viewpoints incorrectly.
- Add edit persistence and priority-based asynchronous chunk streaming (#21–30). Validate cancel/reprioritize after rapid teleportation and across face seams.

**Done when:** a character can traverse multiple tile boundaries, carve/build, save and reload the same changes, fly to orbit and return, without observable physics or render-origin jumps.

### Sprint E — Release hardening (Gate v2.0)

- Profile streaming budgets, meshing throughput, frame-time spikes, RAM growth, edit-regeneration, and extreme movement.
- Test with multiple planets *as data* to prove identity separation before promising simultaneous continuous multi-planet gameplay.
- Capture real v2.0 editor/planet screenshots from a verified build into `marketing/screenshots/captured/`. Replace concept-art claims only after acceptance tests pass.
- Publish migration notes and known limitations for v1.6 world compatibility.

**Done when:** Gate A0 through A3 are measured on agreed target hardware, persistence regression tests pass, and release artifacts are reproducible.

## 4. v3.0 — Rendering pipeline & micro-detail (#41–070)

**Mission:** make the voxel surface expressive without sacrificing scale or reliability.

| Workstream | IDs | Dependencies and proof |
|---|---|---|
| Sharp and organic meshing | 41–42, 44–46, 50 | Implement QEF-based Dual Contouring as a separate mesher; non-manifold cases, sealed topology and seam-stitching must pass |
| Adaptive detail storage | 43, 47–49 | Build a small proof-of-concept SVO for close-range props; test compact persistence and memory limits before replacing 32³ terrain chunks |
| Lighting and shading | 51–60 | Add or extend PBR, triplanar mapping, biome blending, shadows, AO, GI and atmosphere; flag any features already present at simpler quality levels |
| GPU & postprocess | 61–70 | Benchmark compute meshing vs CPU, TAA, tone mapping, fog, exposure, bloom, indirect drawing and DRS on representative workloads |

**Scope guard:** *1-mm detail* is for localized asset editing and select high-detail volumes, **not** a planet-wide 1-mm voxel allocation. Existing renderer features (e.g. triplanar mapping, glow, tone mapping) should be upgraded, not rewritten solely because they also appear in this target catalog.

**Release acceptance:** sharp 90° structures, organic terrain, chunk-LOD seams, artist-friendly materials, and stable frame-time on at least one published reference GPU. Preserve the CPU mesher as a fallback.

## 5. v4.0 — Physics, sculpting & hybrid assets (#71–100)

**Mission:** let creators reshape the environment and have the physical world react coherently.

| Workstream | IDs | Dependencies and proof |
|---|---|---|
| Digital clay and editing | 71–80 | Robust smin, cross-sector CSG, 3D gizmos, snapping, shape library, clipboard, reversible edits; reuse working v1.6 tools where possible |
| Hybrid content pipeline | 81–90 | Assimp import, voxelization, `.vxprefab`, asset registry, rigs and skinned rendering; explicit asset licenses and stable import artifacts |
| Jolt and rigid bodies | 91–94, 98–100 | Physics/local origin contract, collision cooking, CCD, controller, ragdolls and vehicles; rollback/cancellation on chunk remesh |
| Structural simulation | 95–97 | Connectivity graph, strength rules and detached-island budgets; deterministic collapse triggers and safe recovery on save/load |

**Early required backport:** #72 cross-chunk editing is a v2.0 foundation gate despite appearing under v4.0 in the numbered catalog.

**Release acceptance:** a player cuts a load-bearing support; relevant chunk meshes/colliders update without gaps; only disconnected regions fall; motion and save/reload remain stable.

## 6. v5.0 — Zero-code platform & Spire Hub (#101–140)

**Mission:** make game creation accessible without external code or 3D tools for common scenarios.

| Workstream | IDs | Dependencies and proof |
|---|---|---|
| Spire Hub and universe creator | 101–110 | Project wizard, `.vxplanet` manifest, multi-world hierarchy, planet-generation inspector, orbit painting, reusable templates |
| Logic system | 111–120 | Lua sandbox + visual-node runtime contract; hot reload, guarded API bindings, diagnostics, prefab events |
| Standalone UI canvas | 121–130 | Custom in-game UI separate from ImGui; responsive layout, HUD widgets, scene tree, inspector, unified undo/redo and inputs |
| Production tooling | 131–140 | Audio upgrade, virtual file system, deterministic packager, crash logs and honest per-platform support matrix |

**Important architecture decision:** Authoring UI may use Dear ImGui, but shipped games need an independent runtime UI renderer. Node graphs and Lua should target a **shared runtime event/action model**; editable Lua should not be forcibly regenerated from nodes unless round-trip preservation can be proven.

**Release acceptance:** a new user creates a planet-enabled project, places assets, writes a basic quest using nodes, builds a menu, plays it, and exports a reproducible release on a supported platform.

## 7. v5.5 — Living sandbox & differentiators (#141–200)

**Mission:** introduce bounded, authoritative simulations without losing world-editing reliability.

| Workstream | IDs | Dependencies and proof |
|---|---|---|
| NPCs, careers and economy | 141–150 | Deterministic ledger, time-stepped regions, durable jobs/property rights and state recovery |
| Bounty PvP and exactly two powers | 151–165 | Server ownership of player stats, enforce exactly one primary mobility and one secondary disruption slot, griefing protections and PvP-zone permissions |
| Eden / RTS Game Master | 166–175 | Role-based administration, audit trails, safe spawning and economy controls, client permission validation |
| Moving voxel micro-worlds | 176–177, 186–187 | Ship-local voxel/physics frame, parent transforms, docking, smooth gravity handoff and replication |
| Tactical acoustics and infection | 178–181 | Limited rays/portals and active simulation cells; bounded update cost and safe interest scheduling |
| Voxel fluids, heat and rewind | 182–185, 190–191 | Local tiles/regions, deterministic interactions, versioned delta snapshots; explicit multiplayer time-rewind semantics |
| Portals and universe mechanics | 188–189, 192–200 | Render-target gateways, target-world streaming, persistent terrain scars, adaptive AI navmesh and integrated runtime packaging |

**Release acceptance:** a dedicated server can safely host a persistent session; live edits persist; player/GM permissions are enforced; budgets are fixed for fluids, fracture and sound; reconnect and save recovery work without duplicating assets or currency.

## 8. Risk register and decisions to document

| Severity | Risk | Mitigation / decision gate |
|---|---|---|
| Critical | `glm::ivec3` chunk keys and float `glm::vec3` coordinates lose precision outside local range | Make high-precision positions authoritative for planetary objects; adapt rendering/physics at defined boundaries |
| Critical | Planetary density sampled with `float` at millions-of-meter positions loses noise detail | Planet-relative or sector-local normalized noise sampling; deterministic seam tests |
| Critical | Existing edit logs and `.vxworld` contain local float positions | Version migrations and legacy-load fixtures before writing planet saves |
| Critical | Cube-face quadtree seams and mismatched LOD produce holes | Edge/corner reciprocal lookup and conservative mesh seam solution verified at all 12 cube edges |
| High | Physics origin moves while worker/main snapshots use old transforms | Frame-barrier origin event with generation IDs; no live-worker coordinate mutation |
| High | Planet-local up conflicts with global Y-up camera/character/gameplay | Explicit `GravityContext` and flat-world fallback |
| High | Portal + temporal rewind + multiplayer combinations break authority | Prototype separately; server-authoritative ledger and explicit exclusion/integration rules |
| High | Global SVO/detail increases memory unpredictably | Benchmark sparse props first; cap editable local-resolution budget |
| High | GPU meshing/compiler/driver portability | Preserve CPU fallback; maintain per-GPU benchmark matrix |
| Medium | Marketing presents planned systems as shipping | Every image has a verified capture ID or a visible concept disclaimer |

## 9. Engineering acceptance matrix

| Test area | Required scenario |
|---|---|
| Coordinates | Negative and extreme 64-bit sectors; mm-scale local displacement; no overflow or drift |
| Topology | All 6 faces, 12 edges and 8 corners at multiple LODs; reciprocal neighbor tiles |
| World edits | Add/subtract across same-face and cross-face boundaries; undo/redo survives unload/reload |
| Origin shifts | Camera, collider, raycast and prefab stay aligned while changing active origin |
| Planet physics | Contact + jump + fall + fast travel with radial gravity, including boundary crossings |
| Streaming | Teleport/orbit/surface traversal cancels obsolete jobs and does not block render thread |
| Persistence | Load v1.6 flat world; save/reload planetary edit; recover after interrupted save |
| Rendering | Float near-plane stability, far horizon visibility and no cracks under tested LOD |
| Production | CI build and headless tests plus interactive smoke run on declared target setup |
| Marketing | Real captures stored with exact build IDs; concepts never labeled gameplay screenshots |

## 10. Scope and traceability

The original list of 200 goals is kept **without renumbering** in [`MASTER_FEATURE_CATALOG_200.md`](MASTER_FEATURE_CATALOG_200.md). The phase assignments in that source are:

- **v2.0:** #1–40 (coordinate math, spherical geometry, streaming, density/noise)
- **v3.0:** #41–70 (Dual Contouring/SVO, shading, compute/postprocess)
- **v4.0:** #71–100 (sculpting, assets, Jolt/structural physics)
- **v5.0:** #101–140 (Spire Hub, Lua/nodes, UI, production)
- **v5.5:** #141–200 (economy, PvP, Eden, ships, fluids, portals, temporal effects)

Feature numbers convey scope, **not completion**. Some original ideas require design correction or dependency-driven resequencing; those choices are explained above, while the source catalog remains untouched. Marketing capture milestones are tracked in [`../marketing/screenshots/SHOT_LIST.md`](../marketing/screenshots/SHOT_LIST.md).

### Next unblocked engineering action

Keep the upgraded planetary math prototype as-is until a clean build/test baseline is recorded. Then wire `ITerrainProvider` into `ChunkManager` using an adapter for existing flat worlds, before activating any planet save format or changing the legacy coordinate fields globally.
