# Spire Engine v2.0 Milestone B — Build and Test Verification

**Date:** 2026-10-13. **Scope:** CPU-side planetary pipeline, not full graphics/editor executable.

## Verified

The headless tests were compiled from the modified source with **g++**, C++20, pthread, and GLM headers supplied by the uploaded project archive's Windows/vcpkg build tree. The packaged project does **not** redistribute those GLM headers. Tests were run on Linux.

1. `PlanetaryFoundationTests`: **PASS** — coordinate sectors, cube-face tile mapping, radial terrain provider.
2. `PlanetaryStreamingTests`: **PASS** — legacy flat generator parity; planetary VoxelChunk density/material/mesh; 3D worker-streamed chunks; adjacent padded chunk continuity; CSG carve and undo; gravity up vector; flat/planet edit separation; and version-3 flat `.vxworld` save/load regression.
3. **AddressSanitizer-only** run of the streaming integration test: **PASS** with leak detection enabled, no diagnostics reported.
4. Combined AddressSanitizer + UndefinedBehaviorSanitizer run: **test assertions PASS, process exit 0**, but **UBSan reported signed-integer-overflow diagnostics in third-party `FastNoiseLite.h`** at its noise/hash arithmetic. Those warnings are **not** a clean combined-sanitizer pass; the vendor code was left unchanged.

Reproduce on a Linux toolchain with GLM installed:

```bash
./tools/test_planetary_cpu.sh /tmp/spire-planet-tests
```

If GLM is not in a standard include directory:

```bash
GLM_INCLUDE_DIR=/path/to/glm/include ./tools/test_planetary_cpu.sh /tmp/spire-planet-tests
```

For Visual Studio / vcpkg, the existing CMake test target `PlanetaryStreamingTests` is added alongside `PlanetaryFoundationTests` and `EngineTests`.

## Not verified

- **Complete `SpireEngine` application build, Windows linker, and runtime UI**. SDL3, glad and ImGui dependencies are unavailable in this Linux environment as native development packages.
- Gameplay and camera motion over planetary terrain; no editor switch to planetary mode is wired yet.
- Performance at large world radii or beyond legacy float-world/32-bit chunk limits.
- Planet world saving: this intentionally returns `false` until format/version design is implemented.
- Clean UBSan run: third-party FastNoiseLite overflow diagnostics must be assessed separately before a clean sanitizer claim.

## ZIP source policy

This patch includes the project source, roadmap and marketing files, but excludes generated `build/`, vcpkg-installed dependencies, and test binaries. Existing `.vxworld` format/version remains unchanged. The previously uploaded Windows build artifacts were **not** treated as evidence of a clean v2.0 build.
