# Planetary Foundation A — additive prototype

This patch adds a first, deliberately isolated layer for planetary-world development.

## Added files

- `engine/world/PlanetCoordinates.h`
  - `SectorCoord` uses signed 64-bit sector indices.
  - `WorldPosition` stores a small double-precision local offset per sector.
  - `CoordError` reports `Ok`, `NonFinite`, `SectorOverflow`, and `ImpreciseOffset`.
  - `tryNormalize` / `tryAddOffset` / `tryWorldPositionFromMeters` are transactional:
    on failure the input `WorldPosition` is left unchanged.
  - Bool helpers `normalize` / `addOffset` wrap the try-* API for call sites that
    only need success/failure.
  - Canonical local components are in `[0, WORLD_SECTOR_SIZE)` (1024 m sectors).
  - Offsets whose absolute sector-carry exceeds `2^53` are rejected as imprecise
    rather than silently mis-canonicalized in double arithmetic.
- `engine/world/PlanetDefinition.h`
  - Data-only planet ID, name, radius, seed, gravity, projection, terrain amplitude, and sea level.
  - Radial up helper.
- `engine/world/SpherifiedCube.h`
  - Six-face spherified-cube direction mapping and surface-point helper.
  - This is a mapping prototype, not yet a complete cube-sphere chunk/quadtree system.
- `engine/world/CubeTile.h`
  - `CubeTileCoord` addresses a face / LOD level / (x,y) tile.
  - `tryNeighborTile` steps East/West/North/South with deterministic face-edge remaps.
  - `neighborIsReciprocal` checks that some reverse step returns home (UV flips mean
    the return dir is not always `oppositeTileDir`).
- `engine/world/TerrainProvider.h`
  - `ITerrainProvider` with `density` and `referenceSurfaceY`.
  - `FlatTerrainProvider` wraps existing `TerrainGenerator` unchanged.
  - `PlanetaryTerrainProvider` radial shell density around the origin (prototype).
- `tests/PlanetaryFoundationTests.cpp`
  - Headless tests for coordinates, tiles, terrain providers, and spherical mapping.
- `tests/CMakeLists.txt`
  - Adds `PlanetaryFoundationTests` as a separate test target.

## Compatibility approach

The existing `glm::vec3` flat-world interfaces, `TerrainGenerator`, `ChunkManager`, camera, renderer, and save format are not rewritten by this patch. This is intentional: the new API can be tested before migrating production systems. It does not yet make the engine generate or walk on a spherical planet.

## Validation status

`PlanetaryFoundationTests` builds and passes with vcpkg (glm) and MSVC Build Tools on Windows.

## Known limitations to address next

1. ~~Make sector normalization and range limits a fully specified API with explicit failure handling at int64 extremes.~~ **Done** — see `CoordError` and transactional try-* helpers above.
2. ~~Add cube-face tile addresses, deterministic edge/corner neighbor mapping, and reciprocal-neighbor tests.~~ **Done** — see `CubeTile.h`.
3. ~~Add a terrain-provider interface and a spherical density prototype while preserving flat terrain.~~ **Done** — see `TerrainProvider.h` (ChunkManager still uses `TerrainGenerator` directly).
4. Integrate camera-relative rendering and planet-local gravity only after the new coordinate API is tested.
5. Add versioned world serialization and migration before storing planetary positions in saved projects.
