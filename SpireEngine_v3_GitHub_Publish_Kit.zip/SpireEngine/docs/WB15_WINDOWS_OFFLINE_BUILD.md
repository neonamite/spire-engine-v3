# WB15 — Offline Windows graphics-build corrections

This checkpoint builds on WB14, using the bundled `external/windows/x64-windows` graphics dependency tree.

## Changes

- Improved `tools/build_windows_offline.ps1` to support multi-configuration generators and non-Visual Studio generators without forcibly passing `-A x64`.
- Runtime DLL staging now occurs **before** CTest, and DLLs are copied beside every produced `.exe` under the build tree.
- Explicitly checks for a produced `SpireEngine.exe` and fails rather than implying success when only test executables exist.
- Added `-SkipTests` and `-ConfigureOnly` switches.
- All CMake, compile, and CTest errors stop the script.

## Build commands (Windows x64)

From the extracted `SpireEngine` directory, with Visual Studio 2022 C++ tools installed:

```powershell
powershell -ExecutionPolicy Bypass -File tools/build_windows_offline.ps1
```

To diagnose the CMake dependency discovery stage only:

```powershell
powershell -ExecutionPolicy Bypass -File tools/build_windows_offline.ps1 -ConfigureOnly
```

## Verification status

The bundled Windows package folders and SDL3 DLL were inspected in this Linux environment. The script was changed and inspected, but PowerShell and MSVC were not present, so the script was **not executed on Windows**. No Windows graphics build, launch, or test pass is claimed.

The independent Linux CPU-only CMake tests are useful regression coverage, not graphical application verification. The bundled Windows libraries cannot be linked into Linux.
