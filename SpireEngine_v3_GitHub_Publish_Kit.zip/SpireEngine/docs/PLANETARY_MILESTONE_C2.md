# Spire Engine v2.0 — Checkpoint C2 (October 13, 2026)

## What changed beyond C1

1. `engine/core/Camera.h`: the editor camera has a configurable `up` vector and stable local tangent basis for facing, strafing and look-at. The default +Y-up front/right/yaw convention matches v1.6.
2. `engine/core/Application.cpp`: while in the experimental planetary editor, the camera adopts the radial-up direction each frame. E/Q ascend and descend along local up, rather than global Y. The ordinary flat-world editor resets to +Y up automatically. The experimental editor window is visibly labeled and its water plane is disabled.
3. `engine/world/PlanetChunkAddress.h`: sector differences use unsigned **integer subtraction before conversion**, preserving adjacent sector offsets beyond 2^53 on Windows/MSVC (where `long double` is only 64-bit). Range checks prevent inappropriate far-distance GPU conversions.
4. `tests/PlanetCameraTests.cpp`: headless checks for legacy flat orientation, radial basis orthogonality, local look-at, center-screen cursor ray and Z-axis pole basis.
5. `tools/capture_marketing.py`: adds `planet` and `planetclean` capture modes, with at least 300 frames before capture; the shots are explicitly labeled **experimental**.

## Verified tests

- `PlanetaryFoundationTests` — PASS on GCC and Clang.
- `PlanetChunkAddressTests` — PASS on GCC and Clang.
- `PlanetCameraTests` — PASS on GCC and Clang.
- `PlanetaryStreamingTests` — PASS on GCC and Clang.

Both toolchains used C++20 and GLM headers recovered from the user-supplied Windows/vcpkg project cache. These are **headless CPU tests**. SDL3/OpenGL/ImGui executable build, editor behavior and screenshot appearance remain unverified.

## How to test later

1. Build your engine on Windows with the existing CMake/vcpkg configuration; leave existing sandbox project saves backed up.
2. Run `SpireEngine.exe --game sandbox --demo planet --no-audio --no-settings` to view the prototype in the editor.
3. Fly with the normal editor controls; E and Q move along planetary local up. Editing is experimental; legacy planet persistence is **disabled**.
4. Optionally run `python tools/capture_marketing.py --select planet planetclean --exe build/Release/SpireEngine.exe` to take real screenshots (replace the executable path if different). The tool records failures and never labels concept art as engine screenshots.
5. For CPU regression on Linux: `GLM_INCLUDE_DIR=/path/to/glm/include ./tools/test_planetary_cpu.sh`.

## Explicitly not ready

- Planet-based character physics or vehicles; do not use game play mode to test radial gravity.
- A real sector-local active chunk registry; current `PlanetChunkAddress` is a tested API, but `ChunkManager` still keys active chunks using `glm::ivec3`.
- Camera-relative GPU vertex uploads / true planet-scale rendering; current visual prototype works at a small radius only.
- Quadtree/LOD streaming and face seam stitching in the active renderer; existing `CubeTile` only provides addressing.
- v4 save schema and planetary worlds persisted to disk. Planet worlds intentionally cannot be saved in legacy v1.6 format.

This checkpoint changes source files but is not a certified full game/editor build. It is intended as a reversible, opt-in prototype for tonight's testing.
