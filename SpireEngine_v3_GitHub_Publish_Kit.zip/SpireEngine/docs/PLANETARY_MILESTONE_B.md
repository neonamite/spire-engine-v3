# Spire Engine v2.0 — Milestone B: Planetary Voxel Streaming Prototype

## Status

This is an **opt-in, locally scaled spherical terrain prototype** connected to the real CPU voxel chunk generation and streaming workers. It is not a complete planet editor or a planet-scale rendering solution. The v1.6 flat-world entry point and save format remain unchanged.

## Implemented

- `VoxelChunk::generate(const ITerrainProvider&)` can fill existing padded 39³ density/material grids from a spherical radial SDF; the existing flat overload is unchanged.
- `ChunkManager::startPlanetaryPrototype(PlanetaryTerrainSettings, workers)` enables spherical terrain on the existing asynchronous worker pipeline. Call `update()` with a camera near the small test planet; `planetLoadRadius` defaults to 2 and is capped at 4 to bound prototype memory cost.
- Planetary mode queues 3D neighborhoods (rather than horizontal flat X/Z columns), preserving generation IDs, edit snapshots, remeshing, mesh results, and flat/planet switching.
- Outward radial terrain topsoil receives explicit material IDs; Y-up grass and tree instances are disabled in the radial prototype until radial vegetation support exists.
- Planetary `saveWorld()` returns `false` rather than writing an invalid legacy save. Legacy flat save and load formats are untouched.
- New headless tests cover radial surface shape, mesh generation, 3D streaming, cross-chunk density consistency, editing and undo, and returning to flat mode.

## How to use from engine C++

```cpp
px::PlanetaryTerrainSettings s;
s.planet.radiusMeters = 64.0;
s.planet.terrainAmplitudeMeters = 0.0;
s.caveAmplitude = 0.0f;
px::ChunkManager world(prefabLibrary);
world.planetLoadRadius = 1;
world.startPlanetaryPrototype(s, 2);
world.update(glm::vec3(0.0f, 64.0f, 0.0f)); // camera near +Y pole
```

## Known limitations / intentional gates

1. **Not enabled in the application/editor launcher**: there is not yet planet-relative camera/player movement, physics, or orbit rendering. Shipping the mode as a default would break existing gameplay.
2. **The active chunks are still `glm::ivec3` / world `glm::vec3` with unshifted GPU coordinates.** The 64-bit `WorldPosition` primitive exists separately, but rendering and chunk registry have not been migrated to it. Use a small prototype planet only.
3. **Streaming is 3D world-space local radius, not cube-face quadtree LOD.** `CubeTile` edge topology exists as an independent tested primitive and is not the active chunk key.
4. **Planet worlds cannot be saved**; the existing legacy `.vxworld` binary contains no planet identifier/precision policy. We explicitly refuse saving, avoiding silent data corruption.
5. **No radial vegetation, radial-ground physics, horizon culling, GPU compute meshing or planet UI yet.**
6. **World edit operations still use float world coordinates**, so only local prototypes are reliable.

## Next milestone — C

Integrate high-precision sector-local chunk identities and camera-relative renderer transforms, then connect cube-face quadtree tile addresses to deterministic LOD terrain samples and seam-safe mesh transitions. Versioned persistence comes after coordinate authority is proven.

### Edit isolation while switching modes

Starting the planet prototype snapshots the flat-world edit/redo history and uses a fresh experimental history. Returning to flat mode restores the flat history; the planet edit history is discarded. This avoids leaking planet edits into legacy saves. Loading a flat `.vxworld` intentionally replaces all current state and invalidates the backup. Keep real flat-world saves before experimenting.

### Local radial up API

`ChunkManager::localUp(position)` returns radial-up in planet mode and `(0,1,0)` in flat mode. This is a **query for a future controller integration**; it does not change the existing camera or physics solver.
