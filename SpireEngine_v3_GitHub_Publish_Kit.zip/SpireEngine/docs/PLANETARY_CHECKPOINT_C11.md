# Spire Engine v2.0 — Checkpoint C11: Experimental orbital preview integration
Date: 2026-10-13

## Changes
- `Renderer.h/.cpp`: renderer-owned indexed VAO/VBO/IBO cache for immutable C6/C10 patch meshes; upload cap 6/frame; unused mesh cleanup; dedicated forward planet pass.
- `Shaders.h`: minimal normal-lit orbital preview material (not PBR).
- `Application.h/.cpp`: C10 quadtree streamer driven in editor mode at orbital altitude; sampled relief uses the active immutable planetary noise settings; draw packets passed to renderer using sector/offset coordinates; resets on world changes.
- `EditorUI.cpp`: new Orbital Preview button and disclosure that the orbital surface does not incorporate voxel CSG edits yet.
- `Application.h`: version label now C11.

## Verification actually performed
- GCC C++20 syntax-only compile succeeded for `Renderer.cpp`, `Application.cpp`, `EditorUI.cpp` using existing bundled vcpkg headers.
- `PlanetSurfaceRuntimeTests`: GCC C++20 passed.
- No successful link of the whole editor, Windows run, live shader validation, or rendered screenshot. **Experimental and unverified in a graphics context.**

## Constraints and known gaps
1. Orbital preview turns on automatically beyond 1.3 planet radii in editor mode; its generated patches do NOT include player voxel edits/caves. It must not replace the interactive sculpting world near the surface.
2. A separate orbital material is deliberately simpler than the normal engine lighting pipeline. No shadow integration, PBR, adaptive morphing, precise face-edge stitching, radial gameplay gravity, orbital depth regime, multi-planet scene, or GPU compute meshing yet.
3. Rendering a planet beyond the existing camera far clip of 1000 m is not solved. Preview is intended for the small creator prototype planets only.
4. CPU high-precision patch origins are used but the editor camera is still `glm::vec3`; true 64-bit orbital navigation is not finished.
5. No claim of v2.0 release completion, much less v3.0 release. Continue with rendering correctness, planet save compatibility, and then sharp-edge meshing/QEF.
