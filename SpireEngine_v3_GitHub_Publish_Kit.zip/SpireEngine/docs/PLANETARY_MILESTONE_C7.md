# Spire Engine v2.0 — Checkpoint C7: Camera-Relative Planet Draw Packets
**Date:** 2026-10-13

## What changed

- New `engine/render/PlanetSurfaceDrawPackets.h`: links the C6 ready patch cache to a renderer-neutral, zero-OpenGL draw submission format.
- Uses sector/local `WorldPosition` for both planet center and camera. It subtracts sector deltas *before* float conversion; does not construct huge absolute float coordinates.
- Each draw packet holds its own immutable patch via `shared_ptr`, its cube-tile address, and a camera-relative float patch origin suitable for future GPU uniform/model translation.
- Validates input and prevents duplicate tile submissions transactionally. Skips incomplete tiles and patch origins outside a configurable render-distance bound.
- Added `tests/PlanetSurfaceDrawPacketTests.cpp` for billion-scale sector IDs, millimetre camera translation, cache handoff, missing tiles, render-distance culling, and invalid input rollback.
- Hardened C6 streamer configuration against non-finite planet radius/amplitude/gravity/sea-level and added regression test.

## Verification

- GCC/C++20: surface draw packet and surface streamer suites passed.
- Clang/C++20: surface draw packet suite passed.
- GCC/C++20 with AddressSanitizer + UndefinedBehaviorSanitizer: both surface draw packet and surface streamer suites passed against the final C7 source.
- Five C5 standalone tests passed during C6: foundation, chunk address, camera, surface patch, and LOD selector.
- Full Windows/editor build and live OpenGL planet rendering still unverified.

## Critical integration warning

Use draw packet translation with a **rotation-only view matrix**; do NOT also apply the old absolute `Camera::view()` translation, or the camera offset will be applied twice. GPU code should upload local patch-space vertices and apply a per-draw model translation using `cameraRelativeOrigin`.

Render-distance filtering currently checks patch origins, not whole tile bounds. Very large root tiles must be subdivided before using this as a final visibility test. There is no cache-preserving parent LOD fallback, no GPU uploader, and no render-pass integration yet. This is a CPU precision/handoff component only.

## Next steps

1. Add renderer-owned indexed GPU buffers for completed surface patches with main-thread upload budgets and cleanup on invalidation.
2. Wire draw packets into a dedicated orbital/planet preview shader or compatible material shader path; use consistent depth, shadows, picking and culling.
3. Add parent-tile fallback/hysteresis and seam stitching before enabling quadtree LOD live.
4. Integrate into opt-in planetary editor; verify Windows full build and screenshot capture.
