# Spire Engine v2.0 — Checkpoint C6: Asynchronous Surface Mesh Streaming
**Date:** 2026-10-13

## Implementation

- `engine/world/PlanetSurfaceStreamer.h` and `.cpp`: thread-pool producer/consumer that accepts C5 cube-tile selections and builds C4 surface patches off the render thread. Completed meshes have double-precision origins and camera-relative float vertices.
- A new planet configuration invalidates old generation epochs, including pending results; a changed LOD selection retains valid ready tiles and drops irrelevant queued/ready entries.
- Immutable `shared_ptr<const PlanetSurfacePatch>` output allows an uploader to retain a mesh across CPU cache eviction safely.
- Bounded completed-result queue (configurable) and main-thread `collect(maxCount)` provide backpressure; selection caps at 4096 tiles to bound allocations. Jobs are prioritized in caller-provided input order.
- Bad samplers and failed mesh generation cannot terminate the worker pool; failures are tracked.
- `tests/PlanetSurfaceStreamerTests.cpp` tests generation, reuse, invalid-input safety, queue backpressure, stale epochs, worker exception handling, recovery, and input from the existing LOD selector.
- `tests/CMakeLists.txt` adds the headless `PlanetSurfaceStreamerTests` target.

## Verified

- GCC C++20: new surface-streamer suite passed.
- Clang C++20: new surface-streamer suite passed.
- GCC C++20 + AddressSanitizer/UndefinedBehaviorSanitizer: new suite passed.
- GCC C++20: five independently linkable existing tests passed: PlanetaryFoundation, PlanetChunkAddress, PlanetCamera, PlanetSurfacePatch, PlanetLodSelector.
- Did not rerun the two engine-linked integration tests (PlanetaryStreaming and PlanetPersistence) in this checkpoint; previously available test binaries are not a substitute for rebuilding against this exact source.
- Did not verify complete editor build, GPU drawing, or Windows runtime.

## Integration plan

1. Add render-owned GPU surface-patch buffers; the `PlanetSurfaceStreamer` itself must never call OpenGL.
2. Render each patch by applying `(patch.originMeters - camera.absoluteMeters)` in double precision on CPU, converting only the relative offset to `glm::vec3`.
3. Give the renderer a safe transition policy for selected tiles that are not yet ready (parent/coarser fallback and LOD hysteresis) to prevent holes/pop-in.
4. Define distinct visual range rules so close-range editable volumetric chunks take precedence over distant surface-only patches.
5. Verify Windows/SDL3/ImGui/OpenGL build and real rendered terrain before advertising live planetary LOD.

## Risks

- Surface patches are geometry-only and omit editable volumetric caves: never use them as authoritative voxel terrain.
- C5 uses a proxy error metric and a conservative skirt approach; face seams and resolution changes need GPU validation.
- Planetary tile selection is not yet hooked to editor render loop. CPU worker output has no upload yet.
- Sampler callbacks MUST be pure and thread-safe.
