# WB18 — Linux graphics build via GitHub Actions

The local container cannot resolve github.com, so complete Linux graphics dependencies remain unavailable here. This workflow is an **unexecuted build attempt configuration**, not a passing build.

## How to execute

1. Upload the contents of the `SpireEngine/` folder (including `.github/workflows/linux-graphics-build.yml`) to a GitHub repository. Upload the *contents*, so `CMakeLists.txt` is at the repository root.
2. Open the repository's **Actions** tab, choose **Spire Engine Linux graphics build**, and click **Run workflow**.
3. Review Configure, Build and Test logs. If successful, retrieve `spire-linux-graphics-build` under workflow artifacts.
4. When a step fails, preserve its log and error messages to identify the first genuine compiler/linker issue.

## Dependencies

The workflow checks out upstream Microsoft vcpkg and installs the exact manifest in `vcpkg.json`: GLM, SDL3, glad, ImGui with SDL3/OpenGL3/docking features. Ubuntu's X11/Wayland, OpenGL, Vulkan, audio, and input development prerequisites are installed separately.

## Scope and limitations

- This tests compiling/linking on Ubuntu, not launching the editor with a display or proving Windows compatibility.
- Linux graphics libraries are not embedded into this ZIP; the runner builds them through vcpkg.
- The workflow's vcpkg revision is currently not pinned, and network installation may take time. Lock versions before a release.
- Do not commit `external/windows` or local build outputs to GitHub unless needed: they are not Linux dependencies and consume repository space.
- The full application has not been built successfully in this session.
