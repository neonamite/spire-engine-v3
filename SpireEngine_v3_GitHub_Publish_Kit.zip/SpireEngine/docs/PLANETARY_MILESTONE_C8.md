# Spire Engine v2.0 Preview — Checkpoint C8: Planet Creator UI
**Date:** October 13, 2026

## What changed

This checkpoint adds an *experimental, actually wired* planet-creation UI atop C7's existing local spherical voxel rendering path. It does not enable Earth-scale quadtree rendering, planetary gravity for play mode, or a complete Universe Manager.

- **Hub:** a new `Create Planet... (Experimental)` button. The `Open saved planet` combo lists named `.vxplanet` files from `worlds/sandbox/planets/`.
- **File menu:** `Create Planet... (Experimental)` and `Open Planet` submenu.
- **Planet Creator:** editable name, starting preset (Rocky/Desert/Ice/Moon/Custom), 64-bit seed, radius, relief, surface gravity, and an expandable noise/sea-level section.
- **Safety rules:** UI limits the local prototype to 48–512 m radius; this is not a whole-Earth renderer. Preset labels are generation presets; full biome/material shading is NOT implemented. New files use a filename-safe, distinct suffix rather than overwriting `.vxplanet` files.
- **Real handoff:** creating a planet starts `ChunkManager::startPlanetaryPrototype`, assigns a matching camera orientation, opens the existing Editor in fly mode, and writes the initial `.vxplanet` save. Ctrl+S later saves that same named file.
- **Open saved planet:** chooses a saved VXPL, loads serialized settings and edits, restores the scene blob, and repositions the camera to the loaded radius. Switching away from an active editor asks the user for confirmation and offers a Save Current World button.
- **Legacy isolation:** no `.vxworld` file is overwritten by a planet creation; flat-world save/load and its autosave remain separate. The planet editor does not autosave using the flat-world format.
- **Play-mode restriction:** intentionally refuses Enter Play on a planet until radial character physics is implemented. Flight/editor sculpting remains available.
- **No engine graphic UI framework replacement:** integrates with existing Dear ImGui rather than introducing a second library.

## Source modifications

- `engine/world/PlanetCreatorModel.h` — data model, presets, validation, safe filename helpers and starter camera position.
- `engine/editor/PlanetCreatorUI.cpp` — ImGui create/switch modals.
- `engine/core/PlanetCreation.cpp` — deferred creation/opening, save paths, camera setup and safe project transition.
- `engine/core/Application.h` and `.cpp` — request state, per-frame dispatch, planet-aware save path, and play-mode safety.
- `engine/editor/HubUI.cpp` and `Shell.cpp` — Hub and File menu entries.
- `engine/world/ChunkManager.h` — read-only access to the active prototype's settings for reopening/camera positioning.
- `tests/PlanetCreatorModelTests.cpp`, `tests/PlanetCreatorIntegrationTests.cpp` and `tests/CMakeLists.txt` — new tests.
- `CHANGELOG.md`, `README_V2_CHECKPOINT_C8.txt`, this note.

## Verification performed (headless)

- All five changed/added UI and main application translation units passed Clang `-fsyntax-only` with the SDL3/ImGui/GLM headers in the user-supplied Windows vcpkg include bundle. **This is not a linked editor build or a live UI runtime test.**
- `PlanetCreatorModelTests`: **PASS** on GCC and Clang, including invalid settings, numeric bounds, filename normalization, and duplicate-safe save naming.
- `PlanetCreatorIntegrationTests`: **PASS** on GCC and Clang, creating a planet with the backend, writing VXPL, switching to flat, and reopening it to recover the seed, name, ID, gravity, and radius.
- Existing `PlanetPersistenceTests`: **PASS** after the C8 modifications.
- Clang AddressSanitizer + UndefinedBehaviorSanitizer: **PASS** for the C8 creator-model test.
- The complete Windows engine/editor was **not** linked, launched, or visually validated in this environment.

## Tonight's test — suggested sequence

1. Apply the **C8 consolidated source overlay** to a backup of your current project. Build using the project vcpkg/Visual Studio setup.
2. Start the engine and select **Create Planet... (Experimental)** from the Project Hub.
3. Enter a name, choose a preset, select a valid radius (48–512 m), seed, gravity, and click **Create Planet**.
4. Fly around in the editor; give the chunk workers a moment to generate the spherical terrain. Sculpt a small patch; use Ctrl+S.
5. Return to the Hub, use **Open saved planet**, reopen your named file, and check that your terrain edits remain.
6. From the File menu, create a second planet with the same display name and confirm a `-2.vxplanet` file is created instead of overwriting the first.
7. Check that you can reopen an ordinary flat sandbox world; its `.vxworld` remains intact.
8. Verify that trying to switch to Play on a planet displays the intentional restriction message.

## Known limitations / next engineering step

1. The new C8 UI has only been **syntax-checked**, not tested in a running Windows editor. Compile/link errors or visual layout issues could still surface on Windows.
2. Small local planets use existing 32-cell Marching Cubes chunks near the camera. The C4–C7 quadtree and camera-relative draw packets are **not yet integrated into OpenGL**.
3. Gravity is a planet metadata setting only; no radial character controller, vehicles, or orbital transitions.
4. Planet saves use the experimental VXPL version 1, not the future multi-planet universe manifest; autosave remains disabled for planets.
5. Presets choose geometry/noise/gravity, not distinct planet materials; no ocean/atmosphere/biome painting yet.
6. Opening a new project from an active editor requires care with unsaved objects/edits. The UI offers Save Current World and confirms switching, but there is no in-engine multi-document tab system yet.
7. Next: upload/draw C7's planet surface tiles through the renderer, preserve near-field editable chunk details, and capture genuine in-editor planet screenshots.
