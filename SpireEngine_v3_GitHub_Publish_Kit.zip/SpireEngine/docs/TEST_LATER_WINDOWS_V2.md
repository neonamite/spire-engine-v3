# Windows smoke-test checklist (when ready)

The C6/C7 code is in the source but is not yet plugged into the OpenGL planetary renderer. These instructions verify that the new standalone tests build and that the previous experimental planet mode still works.

1. **Back up your original v1.6 project and `.vxworld` saves.** Keep `.vxplanet` experimental saves separate. Extract the C7 consolidated source overlay into a separate project folder, restoring your existing third-party packages/build environment as needed.
2. Configure CMake using your Windows Visual Studio + vcpkg setup described in `README.md`. If reusing a build directory from a different path, clear the CMake cache first.
3. Build `PlanetSurfaceStreamerTests` and `PlanetSurfaceDrawPacketTests` (and, if possible, all other project targets).
4. Run `ctest --test-dir build -C Release --output-on-failure` (adapt the configuration and build directory to your CMake generator).
5. If the full editor builds, launch `SpireEngine.exe --game sandbox --demo planetclean`. This checks the **existing C1 local spherical voxel mode**, not C5-C7 orbital quadtree rendering.
6. If screenshot capture is available, run `SpireEngine.exe --game sandbox --demo planetclean --screenshot-and-exit 240` from the project root and retain any console logs or failed screenshots for debugging.
7. Check ordinary flat sandbox editing, loading, and save/undo after planet demo. Do not overwrite your only world save during testing.

**Report back:** MSVC compiler errors (file/line), CTest output, visible planet demo behavior, and any screenshots. Do not infer success from earlier Linux headless results.
