# Spire Engine v2.0 — Checkpoint C3: Experimental Planet Persistence
**Date:** October 13, 2026

## Scope

Adds a separate, opt-in planetary save format (`VXPL`, version 1, `.vxplanet`) without touching the legacy `VXWD`, version 3, flat-world serializer. This checkpoint builds on Milestones B, C1, and C2.

### Implementation

- `engine/world/PlanetSave.cpp`: saves/loads planet ID, display name, seed, radius, gravity, relief, sea level, projection, procedural frequencies, edit log, and optional scene data.
- Uses explicit little-endian fixed-width fields and IEEE-754 float/double bit patterns, rather than serializing padded C++ structs.
- Validates bounded strings, terrain fields, edit kinds, materials, CSG modes, radii, smooth deltas, record counts and overall file size (64 MiB).
- Reads and validates the entire file before mutating the running world. Truncated/corrupt input leaves existing edits untouched.
- `engine/core/Application.cpp`: Save/Load in experimental planet mode uses `worlds/sandbox/local-planet.vxplanet` (for the sandbox). Legacy Save/Load is unchanged in flat mode. Planet autosave stays disabled.
- `tests/PlanetPersistenceTests.cpp`: version/magic, edit-log replay, scene blob, corrupt-file rejection, repeated save, and flat/planet isolation.

### Verification

The following five **headless CPU test suites** pass on Linux with GCC using C++20 and GLM:

1. PlanetaryFoundationTests
2. PlanetChunkAddressTests
3. PlanetCameraTests
4. PlanetaryStreamingTests
5. PlanetPersistenceTests

The full application, GUI Save/Load hotkeys, OpenGL renderer, SDL3 window, and Windows binary remain **untested** in this environment. Do not assume the editor was visually or end-to-end verified.

### Remaining restrictions

- This save format is version 1 **experimental**, and isn't a promise of future compatibility yet. Do not use it as your only backup.
- Terrain edits still use local `glm::vec3` / floating coordinates: small prototype planets only, not Earth-scale.
- Scene object mechanics, prefab and smooth-edit rendering are not end-to-end tested in the Windows editor; avoid relying on this as a production save format.
- Manual save: launch `--game sandbox --demo planet`, then use the editor's normal Save/Load commands. Autosave is intentionally off for planets.
- Launching `--demo planet` starts a fresh experimental planet; load your `.vxplanet` manually to restore the previous sculpted world.
- Use `--demo planetclean` with the screenshot runner if you want an unedited raw engine capture. No engine screenshot has been generated or reviewed by this package.

### Safety

Keep your original v1.6 `.vxworld` backups. The file formats have different headers and independent load functions, so a planetary edit log won't be accidentally saved as a legacy flat world.
