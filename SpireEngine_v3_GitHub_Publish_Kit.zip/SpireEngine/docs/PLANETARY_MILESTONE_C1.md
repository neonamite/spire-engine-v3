# Spire Engine v2.0 — Checkpoint C1 (October 13, 2026)

**Purpose:** First editor-accessible local spherical terrain demonstration, and precise sector-local chunk identity helpers. These changes are additive and retain the default v1.6 flat editor workflow.

## Code changes

- `engine/core/Application.cpp`: `--demo planet` or `--demo planetclean` now opens a sandbox editor and invokes `ChunkManager::startPlanetaryPrototype` with a small (96-meter radius) world. It positions the camera near the +Y hemisphere. Planetary prototype disables sea-plane rendering and autosave, since the old `.vxworld` serializer has no planetary format.
- `engine/world/PlanetChunkAddress.h`: high-precision `(int64 sector, local chunk)` identity, plus validated neighbor stepping and camera-relative chunk-origin calculations without casting huge global positions to float.
- `tests/PlanetChunkAddressTests.cpp`: regression coverage for negative millimeter positions, exact boundaries, near-2^54 sector coordinates, transactional overflow, and render-relative range checks.
- `tests/CMakeLists.txt`, `tools/test_planetary_cpu.sh`: new CMake test target and headless test runner.

## Verified

- Compiled and executed `PlanetaryFoundationTests`, `PlanetChunkAddressTests`, and `PlanetaryStreamingTests` with g++/C++20 on Linux using GLM headers from the user-supplied archive's vcpkg build cache. **All three passed.**
- No claim is made that the full SDL3/OpenGL/ImGui application builds or can run in this environment, and the new editor demo was not visually tested.

## Limitations

- The renderer and live `ChunkManager` still use 32-bit float world coordinates for the prototype. The high-precision address abstraction is tested independently but not yet the active registry key.
- The orbital camera, radial character controller, quadtree LOD, planetary save format, planet UI, and large planet support are not implemented.
- `--demo planet` intentionally runs an experimental editor session only. Do **not** overwrite a valuable world with an experimental save. The planetary save guard rejects legacy saves.

## How to use after a verified full Windows build

```
SpireEngine.exe --demo planet --no-settings --no-audio
SpireEngine.exe --demo planetclean --no-settings --no-audio --screenshot-and-exit 300 --size 1600x900
```

The screenshot option has not been tested in a real editor build at this checkpoint.
