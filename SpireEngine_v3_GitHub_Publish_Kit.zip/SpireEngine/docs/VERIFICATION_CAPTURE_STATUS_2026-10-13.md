# Spire Engine v1.6 — capture and test status (2026-10-13)

**Starting source:** `SpireEngine_v1.6_PlanetaryFoundation_A(1).zip` (user-supplied project archive, including existing Windows build artifacts).

**Read-only code inspection:** checked `engine/core/Application.cpp` for reproducible screenshot CLI and 12 demo setups. No C++ code changes made.

**Test executed on Linux:**

```bash
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic \
  -I engine -I engine/third_party \
  -I build/vcpkg_installed/x64-windows/include \
  tests/PlanetaryFoundationTests.cpp -o PlanetaryFoundationTests
./PlanetaryFoundationTests
# All planetary foundation tests passed
```

This test uses header-only GLM from the Windows vcpkg tree and does not link Windows libraries. It validates only what `PlanetaryFoundationTests.cpp` tests, not the complete engine.

**Full CMake configuration:** attempted with Ninja and `-DPROJECTX_BUILD_TESTS=ON`; it failed because `glmConfig.cmake` was unavailable. No GUI compilation, full engine tests, runtime/editor validation, or screenshot rendering is claimed.

**Capture deliverable:** `tools/capture_marketing.py` (plus Windows batch launcher), instructions in `marketing/screenshots/CAPTURE_RUNBOOK.md`. It creates authentic captures **only when run against an actual compiled engine executable**. The `marketing/screenshots/captured` folder must remain empty until then; the concept images remain distinctly labeled.
