# WB2 — Creator-first application workflow (source checkpoint)

## Implemented in source

- Project Hub: **Blank World Builder** starts a new flat construction canvas, not noise-generated hills.
- New `Application::cmdNewBlankCanvas()` reuses existing terrain, chunk streaming, sculpting, paint, prefabs and legacy flat saves.
- Blank canvas parameters: base Y=32 m, no hills, no cave modulation, no water, no scattered prefabs. Below the surface is solid, so terrain add/subtract tools still work.
- File menu distinguishes **New Blank Construction Canvas** from **New Generated Terrain (Advanced)**.
- Command palette offers blank and generated workflows.
- World Inspector offers direct buttons for Carve, Add, Paint, Flatten, Object Placement and Blank Canvas.
- Planet Creator remains experimental and accessible.
- Procedural terrain options remain available under the existing collapsed Advanced Procedural Terrain section.

## Compatibility and limitations

- Legacy world file serialization is unmodified. A blank canvas uses existing `TerrainSettings`; no new file format required.
- New Canvas resets unsaved editor work, like the existing New World command. Save first.
- This is a **flat blank construction surface**, not an empty 3D vacuum. Existing prefab and manual sculpt tools are reused.
- Roads, modular houses, scene project wizard, GPU orbital rendering and runtime scripting require separate implementation.
- Full editor build/runtime still must be verified on a machine with the project's graphics dependencies.

## Follow-up checkpoints

1. WB3: manual road path tools and configurable modular construction kit.
2. WB4: proper non-destructive New World wizard with save warnings and blank/planet selection.
3. WB5: contextual tool palette and categorized prefab browser.
4. GPU planetary preview integration and v3.0 renderer work proceed alongside creator UX.
