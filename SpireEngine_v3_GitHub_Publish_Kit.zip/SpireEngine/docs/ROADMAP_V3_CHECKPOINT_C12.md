# Spire Engine v3.0 Preview — Checkpoint C12: Dual Contouring/QEF

Roadmap items addressed experimentally: #41 Dual Contouring, #42 QEF, #44 Hermite edge data. Adds `engine/world/DualContouring.h/.cpp` and `tests/DualContouringTests.cpp`; registered in `tests/CMakeLists.txt`.

## Implementation
- Samples an arbitrary SDF over a bounded uniform cubic grid; sign convention is identical to Marching Cubes (negative=solid).
- Finds sign-changing edges, interpolates isosurface crossing positions, derives Hermite normals from centered density gradients.
- Solves a regularized 3x3 quadratic error function with mass-point bias to keep sharp corners. Vertices are confined to their corresponding cell.
- Generates indexed quads (two triangles each) around signed interior grid edges, with winding corrected against the surface gradient.
- Validates grid arguments and nonfinite SDF values. No mutation of output on invalid arguments/density failures.

## Verification
- GCC C++20 headless mesher tests: passed (plane, sharp corner, sphere, invalid args, NaN rejection, indexed triangles).
- Clang C++20: passed.
- GCC AddressSanitizer + UndefinedBehaviorSanitizer: passed (test binary).
- **Not linked to the existing `VoxelChunk` renderer/asset pipeline** and does not replace Marching Cubes. Full Windows engine/editor build not yet verified.

## Remaining before switching geometry backends
- Neighbor halo sampling, crack-free chunk seams, manifold ambiguity resolution, adaptive SVO/DC transition stitching, runtime mesh ownership and voxel edit integration, and scene benchmarks.
- `DcSettings::origin` is a double vector; for huge planetary sector IDs future code must sample sector/local SDF instead of first accumulating astronomical doubles.
