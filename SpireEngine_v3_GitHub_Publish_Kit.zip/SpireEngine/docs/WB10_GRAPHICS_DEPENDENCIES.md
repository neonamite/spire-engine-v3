# WB10 — Native graphics dependency integration

This is a **build-enablement** checkpoint, not a successful full application build.

## Root cause on current Linux host

The full engine CMake project calls `find_package(glm CONFIG REQUIRED)`, followed by SDL3, glad, and ImGui. The environment lacks discoverable **native Linux** development packages. A previously available `x64-windows` vcpkg tree contains Windows-targeted dependency files, which cannot be used to link a Linux editor. `apt-get update` was attempted but timed out (network/package mirror unavailable).

## New commands

- `python3 tools/graphics_dependency_check.py` diagnoses required tools and platform mismatch without installing anything.
- On Windows, in a Visual Studio 2022 Developer PowerShell with a working vcpkg installation and `VCPKG_ROOT` set: `powershell -ExecutionPolicy Bypass -File tools/bootstrap_graphics_windows.ps1`
- `-SkipBuild` allows dependency installation plus configuration only.

The script uses the existing manifest for GLM, SDL3, glad, and ImGui docking/SDL3/OpenGL3. It stops on every nonzero error; it does **not** create or claim a runnable executable unless compilation and linking actually finish.

## Acceptance criteria for the next checkpoint

1. Native packages install and resolve in CMake on the actual build host.
2. Full `SpireEngine` executable compiles and links.
3. Launch and verify Project Hub, blank-world startup, object/road UI, saves and reopen.
4. Create a small planet; verify camera, inspector, and scene transitions. Capture crashes/logs.

**Unverified:** complete graphics application compilation, linking, startup and rendering.
