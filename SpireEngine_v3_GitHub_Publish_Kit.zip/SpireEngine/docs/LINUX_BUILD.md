# Spire Engine v3 — Linux graphics dependency and full-build guide

## Dependency approach

Use the **same project `vcpkg.json`** on Windows and Linux. The manifest requests `glm`, `sdl3`, `glad`, and `imgui` with SDL3, OpenGL3, and experimental docking bindings. On Linux, select `x64-linux` (or explicitly set `VCPKG_DEFAULT_TRIPLET`). Do not reuse `x64-windows` libraries on Linux.

The system also needs a native compiler/build system and X11/Wayland, OpenGL/EGL, and audio development headers. The helper supports Debian/Ubuntu package installation; Fedora/Arch users should install equivalent packages manually.

## Quick start (Ubuntu/Debian)

From the extracted `SpireEngine` root:

```bash
bash tools/bootstrap_graphics_linux.sh --install-system
```

The script asks for sudo access for system packages if needed, clones/bootstrap-installs vcpkg into `.tools/vcpkg` if `VCPKG_ROOT` is not provided, invokes vcpkg via CMake toolchain in manifest mode, configures Ninja/Release, builds the full editor, and runs CTest. It **stops on any failure**. It does not assert the editor's graphical behavior is correct; launch and inspect the resulting `SpireEngine` executable in a desktop session.

For an existing vcpkg installation:

```bash
export VCPKG_ROOT="$HOME/vcpkg"    # the folder containing scripts/buildsystems/vcpkg.cmake
bash tools/bootstrap_graphics_linux.sh --configure-only --no-download
bash tools/bootstrap_graphics_linux.sh --no-download
```

For a custom output path: `SPIRE_LINUX_BUILD_DIR=/absolute/path/build bash tools/bootstrap_graphics_linux.sh`.

## Manual configuration

```bash
cmake -S . -B build-v3-linux -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" \
  -DVCPKG_TARGET_TRIPLET=x64-linux -DPROJECTX_BUILD_TESTS=ON
cmake --build build-v3-linux --parallel 2
ctest --test-dir build-v3-linux --output-on-failure
```

If package downloads fail, verify DNS/network access to the vcpkg upstream, and check the errors in the CMake output. If the `imgui` features in the manifest are unavailable for the selected vcpkg port version, the actual error must be resolved before building; do not silently remove docking support. The project currently does not pin a vcpkg baseline, so exact package versions can change. Pin a tested baseline once a complete build has been verified.

## Headless tests (does not build graphics editor)

Run the existing CPU-only testing workflow documented in `tests/cpu_only`, or configure with `-DSPIRE_CPU_ONLY=ON` using the available GLM headers. Passing headless tests does not prove a graphics build succeeds.

## Known validation limit for this checkpoint

The creation environment could not access GitHub (DNS resolution failed) and has no native SDL3, glad, ImGui, or GLM CMake packages installed. Linux dependency downloads, the full CMake configure, linking, and graphical startup have **not** been verified here. This checkpoint adds an executable setup procedure, not precompiled Linux libraries.
