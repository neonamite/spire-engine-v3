# WB17 — Linux dependency progress (2026-10-13)

- Vendored the complete GLM headers (header-only) under `external/common/include/glm`; included its copyright/license.
- `engine/CMakeLists.txt` now uses an existing `glm::glm` package when available or a GLM header-only interface fallback.
- Full CMake configuration now passes GLM discovery and stops at missing native `SDL3Config.cmake`.
- SDL3, glad, and ImGui have not been replaced or installed. Do not use Windows binaries for Linux linking.
- CPU-only Ninja build and all **12/12** CTest suites passed on Linux.
- Graphics editor compile/link/launch not verified.

Next: supply a compatible native Linux SDL3 build (and later glad/ImGui) via vcpkg or distro packages, then retry full CMake.
