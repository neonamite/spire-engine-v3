# C13 — Creator-first editor navigation checkpoint

## Modified
- `engine/editor/HubUI.cpp`: World Builder is first tile; generation is described as optional; saved planet route retained.
- `engine/editor/EditorUI.cpp`: World Builder instructions lead; flat-world terrain generation controls are collapsed in Advanced Procedural Terrain.
- `engine/editor/Shell.cpp`: rename File > New World to New World Builder Session (same legacy action).
- `engine/editor/PlanetCreatorUI.cpp`: clarify editing purpose and optional generation settings.
- `docs/ROADMAP.md`: top-level direction notice.
- `docs/WORLD_BUILDER_FIRST.md`: revised dependencies, priorities, compatibility policy, and acceptance gates.

## Scope / limitations
No save formats, world sampling, terrain-generation defaults, or renderer behavior were changed. Current sandbox **still generates starting hills**; truly empty base terrain, road splines, and modular house authoring are future milestones. A full editor build is not claimed.
