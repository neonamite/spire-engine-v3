# WB9 Build integration and World Builder road regression

This checkpoint integrates a pure, deterministic road-path sampler into the editor road command, and adds a CPU-only CMake regression test for endpoint coverage, spacing, finite input validation, and width clamps. Manual roads remain flat-world-only and are still recorded as multiple voxel edit operations.

## Full build limitations
The native Linux CMake configure stops at `find_package(glm CONFIG REQUIRED)`; this environment has no Linux GLM/SDL3/glad/ImGui installations. Windows vcpkg headers in earlier project copies are not a native Linux linkable toolchain. A Windows executable has not been built or tested here.

## CPU verification
`cmake -S . -B build-cpu -DSPIRE_CPU_ONLY=ON -DSPIRE_GLM_INCLUDE_DIR=/path/to/glm/include && cmake --build build-cpu && ctest --test-dir build-cpu --output-on-failure`

## Next
Install or provide native dependencies with a matching CMake toolchain, configure/link the full application, then test Hub/New Project, World Builder roads, persistence, and planet editor interactions in a real graphics runtime.
