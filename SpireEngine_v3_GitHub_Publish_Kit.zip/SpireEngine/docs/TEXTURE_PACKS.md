# Texture packs

A texture pack swaps any of Spire Engine's built-in materials for your own pictures: photo-scanned textures from
[Poly Haven](https://polyhaven.com/textures) or [ambientCG](https://ambientcg.com) (both free, CC0), something you
photographed, or something you painted.

## Making one

1. Make a folder for the pack inside `textures/` next to the program, for example `textures/My Pack/`.
2. Inside it, make one folder per material you want to replace, named like the material:

   ```
   textures/
     My Pack/
       grass/
       brick/
       cobblestone/
       roof tiles/
   ```

   Names: `grass`, `dirt`, `stone`, `sand`, `snow`, `wood`, `metal`, `brick`, `plaster`, `tile`, `cloth`, `ice`,
   `lava`, `lamp`, `crystal`, `moss`, `gravel`, `mud`, `cobblestone`, `marble`, `concrete`, `sandstone`, `slate`,
   `bark`, `rust`, `roof tiles`, `leaves`, `glass`, `skin`, `hair`, `leather`, `polished` (gold and steel).
   Plurals (`bricks`) and a few everyday words work too: `rock` = stone, `ground` / `soil` = dirt, `planks` = wood,
   `roof` = roof tiles, `cobbles` = cobblestone, `foliage` = leaves, `fabric` = cloth.
3. Put the material's pictures in its folder. Which picture is which comes from the file name:

   | Map | Words in the file name |
   |---|---|
   | Colour (needed) | `albedo`, `basecolor`, `diffuse`, `diff`, `color`, `col` |
   | Normal (bumps) | `normal`, `nrm`, `nor_gl`, `nor_dx` (`dx` = DirectX style: the green channel is flipped for you) |
   | Roughness | `rough` (or `gloss`, which is turned round) |
   | Height | `height`, `disp`, `displacement`, `bump` |
   | Ambient occlusion | `ao`, `occlusion` |
   | Metalness | `metal` |
   | AO + roughness + metal in one | `arm` (Poly Haven's packed map: red = AO, green = roughness, blue = metal) |

   PNG, JPG, TGA and BMP are read; 16-bit PNGs are fine. EXR is not read: download the PNG or JPG version.
4. In the engine: **Settings > Graphics > Surfaces > Texture pack**, and pick your pack.

The first time, the pack is loaded and scaled to the **Texture detail** setting in the background (the old look keeps
drawing meanwhile); after that it is cached in `cache/textures/` and loads instantly. Change any file in the pack and it
is loaded again.

## Tips

- Pictures should **tile** (repeat without a visible seam) and be **square**. Anything else is stretched to a square.
- Any size works. 2K pictures with Texture detail on High (2K) are the sweet spot; Ultra (4K) needs about 2 GB of video
  memory.
- Only the colour is needed. Without a normal map the bumps are worked out from the height (or from how dark each spot
  is); without ambient occlusion, crevices are darkened from the height.
- Materials you leave out keep the built-in look, so a pack can be one folder.
- How big one repeat of the picture is in the world is the built-in material's size (a brick is brick-sized); the
  **Environment > Materials** tint still works on pack textures.
- **Settings** lists any folder whose name it did not recognise, and any picture it could not read.
