# WB4 — Construction workspace UI

The World Inspector now directly offers the existing Blueprint Building Editor, modular building Kits, asset shelf, and Asset Workshop. This makes the tools reachable without searching unrelated menus. All four entry points use existing engine functions, rather than duplicate asset formats or placement systems.

The new road endpoint selection is cleared when a blank or procedural flat world is created.

## Limitations

These are integrations of existing functionality, not entirely rewritten building tools. A running Windows/OpenGL build is needed to validate docking behavior, UI focus, live placement, and saving. Project wizard and unified scene manipulation remain planned.
