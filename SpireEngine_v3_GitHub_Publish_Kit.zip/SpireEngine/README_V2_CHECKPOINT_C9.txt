SPIRE ENGINE v2.0 PREVIEW — CHECKPOINT C9
========================================
Source code overlay or incremental patch; not a Windows executable.

C9 builds upon C8 and improves the editor World inspector for planetary mode:
planet metadata, return-to-surface/local-aerial camera controls, planet
streaming slider, safe edit clearing, and protection from flat-only commands.

For a FULL source overlay, extract the consolidated ZIP into the parent
folder containing SpireEngine; back up existing files first.

For the small INCREMENTAL patch, start with C8 source and extract the patch
at the same parent directory. Do not put it into an unrelated v1.6 tree.

Verified: headless planet editor safety, save/load, streaming and creator
integration regression tests. Not verified: linked/running Windows editor.

See docs/PLANETARY_MILESTONE_C9.md for the actual changes and test guidance.
