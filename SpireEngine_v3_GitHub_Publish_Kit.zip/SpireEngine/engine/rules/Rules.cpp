#include "rules/Rules.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>

namespace px {

namespace {
struct Named { const char* name; const char* label; };
const Named kWhen[] = {
    { "start", "the game starts" },
    { "touch", "you touch it" },
    { "leave", "you step off it" },
    { "near", "you come near" },
    { "use", "you press E on it" },
    { "every", "every few seconds" },
    { "hears", "it hears a message" },
};
const Named kDo[] = {
    { "message", "show a message" },
    { "open", "open" },
    { "close", "close" },
    { "toggle", "open or close" },
    { "hide", "hide" },
    { "show", "show" },
    { "collect", "collect it" },
    { "sound", "play a sound" },
    { "teleport", "teleport you to" },
    { "send", "send a message" },
    { "say", "make someone say" },
    { "score", "add points" },
    { "win", "win the game" },
    { "lose", "lose the game" },
    { "lifelost", "lose a life" },
    { "checkpoint", "save a checkpoint" },
    { "time", "add time" },
};
const Named kOpen[] = { { "swing", "Swing" }, { "slide", "Slide" }, { "lift", "Lift" }, { "sink", "Sink" } };

std::string lower(std::string s) {
    for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    while (!s.empty() && s.back() == ' ') s.pop_back();
    size_t i = 0;
    while (i < s.size() && s[i] == ' ') ++i;
    return s.substr(i);
}
std::string fmtNum(float v) {
    char b[32];
    std::snprintf(b, sizeof b, "%g", double(v));
    return b;
}
} // namespace

const char* ruleWhenName(RuleWhen w) { return size_t(w) < std::size(kWhen) ? kWhen[size_t(w)].name : "touch"; }
const char* ruleWhenLabel(RuleWhen w) { return size_t(w) < std::size(kWhen) ? kWhen[size_t(w)].label : ""; }
const char* ruleDoName(RuleDo d) { return size_t(d) < std::size(kDo) ? kDo[size_t(d)].name : "message"; }
const char* ruleDoLabel(RuleDo d) { return size_t(d) < std::size(kDo) ? kDo[size_t(d)].label : ""; }
const char* openStyleName(OpenStyle s) { return size_t(s) < std::size(kOpen) ? kOpen[size_t(s)].name : "swing"; }
const char* openStyleLabel(OpenStyle s) { return size_t(s) < std::size(kOpen) ? kOpen[size_t(s)].label : "Swing"; }
bool ruleWhenTakesNumber(RuleWhen w) { return w == RuleWhen::Near || w == RuleWhen::Every; }
bool ruleWhenTakesText(RuleWhen w) { return w == RuleWhen::Hears; }
bool ruleDoTakesText(RuleDo d) { return d == RuleDo::Message || d == RuleDo::Sound || d == RuleDo::Send || d == RuleDo::Say || d == RuleDo::Win || d == RuleDo::Lose; }
bool ruleDoTakesNumber(RuleDo d) { return d == RuleDo::AddScore || d == RuleDo::Collect || d == RuleDo::AddTime; }
bool ruleDoTakesTarget(RuleDo d) {
    return d == RuleDo::Open || d == RuleDo::Close || d == RuleDo::Toggle || d == RuleDo::Hide || d == RuleDo::Show || d == RuleDo::Collect
        || d == RuleDo::Teleport || d == RuleDo::Say;
}

void RuleSet::clamp() {
    if (rules.size() > 32) rules.resize(32);
    for (Rule& r : rules) {
        if (int(r.when) >= int(RuleWhen::Count)) r.when = RuleWhen::Touch;
        if (!std::isfinite(r.number)) r.number = 3.0f;
        r.number = r.when == RuleWhen::Every ? std::clamp(r.number, 0.1f, 3600.0f) : std::clamp(r.number, 0.5f, 100.0f);
        if (r.text.size() > 64) r.text.resize(64);
        if (r.actions.size() > 16) r.actions.resize(16);
        for (RuleAction& a : r.actions) {
            if (int(a.what) >= int(RuleDo::Count)) a.what = RuleDo::Message;
            if (a.text.size() > 200) a.text.resize(200);
            if (!std::isfinite(a.number)) a.number = 0.0f;
            a.number = std::clamp(a.number, -100000.0f, 100000.0f);
            a.delay = std::isfinite(a.delay) ? std::clamp(a.delay, 0.0f, 3600.0f) : 0.0f;
        }
    }
    if (int(open) >= int(OpenStyle::Count)) open = OpenStyle::Swing;
    openSeconds = std::isfinite(openSeconds) ? std::clamp(openSeconds, 0.05f, 20.0f) : 0.8f;
}

bool RuleSet::usable() const {
    for (const Rule& r : rules) if (r.when == RuleWhen::Use) return true;
    return false;
}

// ---------------------------------------------------------------- files

Json rulesToJson(const RuleSet& rs) {
    Json j = Json::object();
    Json arr = Json::array();
    for (const Rule& r : rs.rules) {
        Json jr = Json::object();
        jr.set("when", ruleWhenName(r.when));
        if (ruleWhenTakesNumber(r.when)) jr.set("number", r.number);
        if (ruleWhenTakesText(r.when)) jr.set("text", r.text);
        if (r.once) jr.set("once", true);
        Json acts = Json::array();
        for (const RuleAction& a : r.actions) {
            Json ja = Json::object();
            ja.set("do", ruleDoName(a.what));
            if (a.target == kRulePlayer) ja.set("target", "player");
            else if (a.target != kRuleSelf) ja.set("target", double(a.target));
            if (!a.text.empty()) ja.set("text", a.text);
            if (a.number != 0.0f) ja.set("number", a.number);
            if (a.delay > 0.0f) ja.set("delay", a.delay);
            acts.push(ja);
        }
        jr.set("do", acts);
        arr.push(jr);
    }
    j.set("rules", arr);
    if (rs.open != OpenStyle::Swing) j.set("open", openStyleName(rs.open));
    if (rs.openSeconds != 0.8f) j.set("openSeconds", rs.openSeconds);
    if (rs.startsOpen) j.set("startsOpen", true);
    if (rs.startsHidden) j.set("startsHidden", true);
    return j;
}

bool rulesFromJson(const Json& j, RuleSet& out) {
    if (!j.isObject()) return false;
    RuleSet rs;
    const Json& arr = j.get("rules");
    for (size_t i = 0; i < arr.size(); ++i) {
        const Json& jr = arr.at(i);
        Rule r;
        const std::string w = jr.get("when").str();
        bool known = false;
        for (int k = 0; k < int(RuleWhen::Count); ++k) if (w == ruleWhenName(RuleWhen(k))) { r.when = RuleWhen(k); known = true; }
        if (!known) continue;                                // a rule from a newer engine: skipped, the rest still load
        r.number = float(jr.get("number").num(r.when == RuleWhen::Every ? 5.0 : 3.0));
        r.text = jr.get("text").str();
        r.once = jr.get("once").boolean(false);
        const Json& acts = jr.get("do");
        for (size_t k = 0; k < acts.size(); ++k) {
            const Json& ja = acts.at(k);
            RuleAction a;
            const std::string d = ja.get("do").str();
            bool ok = false;
            for (int m = 0; m < int(RuleDo::Count); ++m) if (d == ruleDoName(RuleDo(m))) { a.what = RuleDo(m); ok = true; }
            if (!ok) continue;
            const Json& t = ja.get("target");
            if (t.isString() && t.str() == "player") a.target = kRulePlayer;
            else if (t.isNumber() && t.num() > 0.0 && t.num() < 4294967295.0) a.target = RuleObjectId(t.num());
            a.text = ja.get("text").str();
            a.number = float(ja.get("number").num(0.0));
            a.delay = float(ja.get("delay").num(0.0));
            r.actions.push_back(a);
        }
        rs.rules.push_back(std::move(r));
    }
    const std::string o = j.get("open").str("swing");
    for (int k = 0; k < int(OpenStyle::Count); ++k) if (o == openStyleName(OpenStyle(k))) rs.open = OpenStyle(k);
    rs.openSeconds = float(j.get("openSeconds").num(0.8));
    rs.startsOpen = j.get("startsOpen").boolean(false);
    rs.startsHidden = j.get("startsHidden").boolean(false);
    rs.clamp();
    out = std::move(rs);
    return true;
}

std::string rulesToText(const RuleSet& r) { return rulesToJson(r).dump(-1); }
bool rulesFromText(const std::string& text, RuleSet& out) {
    Json j;
    return !text.empty() && Json::parse(text, j) && rulesFromJson(j, out);
}

std::string ruleSentence(const Rule& r, const std::function<std::string(RuleObjectId)>& nameOf) {
    std::string s = "When ";
    switch (r.when) {
    case RuleWhen::Near: s += "you come within " + fmtNum(r.number) + " m"; break;
    case RuleWhen::Every: s += "every " + fmtNum(r.number) + " s"; break;
    case RuleWhen::Hears: s += "it hears \"" + r.text + "\""; break;
    default: s += ruleWhenLabel(r.when); break;
    }
    if (r.once) s += " (the first time)";
    s += ": ";
    if (r.actions.empty()) return s + "nothing yet.";
    for (size_t i = 0; i < r.actions.size(); ++i) {
        const RuleAction& a = r.actions[i];
        if (i) s += i + 1 == r.actions.size() ? ", then " : ", ";
        const std::string who = a.target == kRuleSelf ? "it" : a.target == kRulePlayer ? "you" : nameOf ? nameOf(a.target) : "something";
        switch (a.what) {
        case RuleDo::Message: s += "show \"" + a.text + "\""; break;
        case RuleDo::Sound: s += "play \"" + a.text + "\""; break;
        case RuleDo::Send: s += "send \"" + a.text + "\""; break;
        case RuleDo::Say: s += (a.target == kRuleSelf ? std::string("say") : who + " says") + " \"" + a.text + "\""; break;
        case RuleDo::AddScore: s += "add " + fmtNum(a.number) + " points"; break;
        case RuleDo::Collect: s += "collect " + who + (a.number != 0.0f ? " (+" + fmtNum(a.number) + ")" : std::string()); break;
        case RuleDo::Win: s += "win"; break;
        case RuleDo::LoseLife: s += "lose a life"; break;
        case RuleDo::Checkpoint: s += "save a checkpoint"; break;
        case RuleDo::AddTime: s += (a.number >= 0.0f ? "add " : "take away ") + fmtNum(std::fabs(a.number)) + " s"; break;
        case RuleDo::Lose: s += "lose"; break;
        case RuleDo::Teleport: s += "teleport you to " + who; break;
        default: s += std::string(ruleDoLabel(a.what)) + " " + who; break;
        }
        if (a.delay > 0.0f) s += " after " + fmtNum(a.delay) + " s";
    }
    return s + ".";
}

// ---------------------------------------------------------------- playing

void RuleEngine::reset() {
    state.clear(); pending.clear(); pendingSignals.clear(); history.clear();
    clock = 0.0f; started = false; points = 0;
}

float RuleEngine::openAmount(RuleObjectId id) const { auto it = state.find(id); return it == state.end() ? 0.0f : it->second.amount; }
bool RuleEngine::isOpen(RuleObjectId id) const { auto it = state.find(id); return it != state.end() && it->second.open; }
bool RuleEngine::hidden(RuleObjectId id) const { auto it = state.find(id); return it != state.end() && it->second.hidden; }

void RuleEngine::note(const std::string& s) {
    history.push_back(s);
    if (history.size() > 200) history.erase(history.begin(), history.begin() + 50);
}

const RuleObject* RuleEngine::find(const RuleInput& in, RuleObjectId id) const {
    for (const RuleObject& o : in.objects) if (o.id == id) return &o;
    return nullptr;
}

void RuleEngine::act(const RuleInput& in, RuleObjectId from, const RuleAction& a, RuleEffects& out) {
    const RuleObjectId tgt = a.target == kRuleSelf ? from : a.target;
    const RuleObject* to = tgt == kRulePlayer ? nullptr : find(in, tgt);
    const glm::vec3 where = to ? (to->boundsMin + to->boundsMax) * 0.5f : in.player;
    ObjState* ts = to ? &state[tgt] : nullptr;
    if (ts && !ts->init && to->rules) {                          // first touched by another's rule: start it as it starts
        ts->open = to->rules->startsOpen; ts->amount = ts->open ? 1.0f : 0.0f; ts->hidden = to->rules->startsHidden; ts->init = true;
    }
    switch (a.what) {
    case RuleDo::Message: out.messages.push_back({ a.text, a.number > 0.0f ? a.number : 3.0f }); break;
    case RuleDo::Open: case RuleDo::Close: case RuleDo::Toggle:
        if (!ts) break;
        ts->open = a.what == RuleDo::Open ? true : a.what == RuleDo::Close ? false : !ts->open;
        out.sounds.push_back({ ts->open ? "door open" : "door close", where });
        break;
    case RuleDo::Hide: if (ts) ts->hidden = true; break;
    case RuleDo::Show: if (ts) ts->hidden = false; break;
    case RuleDo::Collect:
        if (!ts || ts->hidden) break;
        ts->hidden = true;
        points += int(a.number); out.score += int(a.number);
        out.collected.push_back(tgt);
        out.sounds.push_back({ "pickup", where });
        break;
    case RuleDo::Sound: out.sounds.push_back({ a.text.empty() ? std::string("chime") : a.text, where }); break;
    case RuleDo::Teleport:
        if (!to) break;
        out.teleport = true;
        out.teleportTo = glm::vec3((to->boundsMin.x + to->boundsMax.x) * 0.5f, to->boundsMax.y + 0.05f, (to->boundsMin.z + to->boundsMax.z) * 0.5f);
        out.sounds.push_back({ "teleport", out.teleportTo });
        break;
    case RuleDo::Send: if (!a.text.empty()) pendingSignals.push_back(a.text); break;
    case RuleDo::Say: if (tgt != kRulePlayer) out.says.push_back({ tgt, a.text }); break;
    case RuleDo::AddScore: points += int(a.number); out.score += int(a.number); break;
    case RuleDo::Win: out.won = true; out.endText = a.text; break;
    case RuleDo::LoseLife: out.livesLost += 1; out.sounds.push_back({ "lose", where }); break;
    case RuleDo::Checkpoint:
        out.checkpoint = true;
        out.checkpointAt = to ? glm::vec3((to->boundsMin.x + to->boundsMax.x) * 0.5f, to->boundsMax.y + 0.05f, (to->boundsMin.z + to->boundsMax.z) * 0.5f) : in.player;
        out.sounds.push_back({ "chime", where });
        break;
    case RuleDo::AddTime: out.addTime += a.number; break;
    case RuleDo::Lose: out.lost = true; out.endText = a.text; break;
    case RuleDo::Count: break;
    }
    note(std::string(ruleDoName(a.what)) + " " + (tgt == kRulePlayer ? std::string("player") : std::to_string(tgt)) + (a.text.empty() ? "" : " \"" + a.text + "\""));
}

void RuleEngine::fire(const RuleInput& in, const RuleObject& o, int i, RuleEffects& out) {
    ObjState& st = state[o.id];
    const Rule& r = o.rules->rules[size_t(i)];
    if (r.once && st.fired[size_t(i)]) return;
    st.fired[size_t(i)] = 1;
    note(std::string("when ") + ruleWhenName(r.when) + " on " + std::to_string(o.id));
    for (const RuleAction& a : r.actions) {
        if (a.delay > 0.0f) pending.push_back({ clock + a.delay, o.id, a });
        else act(in, o.id, a, out);
    }
}

void RuleEngine::tick(const RuleInput& in, RuleEffects& out) {
    const float dt = std::clamp(in.dt, 0.0f, 0.25f);
    clock += dt;
    // everyone's starting state
    for (const RuleObject& o : in.objects) {
        if (!o.rules) continue;
        ObjState& st = state[o.id];
        if (st.timers.size() != o.rules->rules.size()) { st.timers.assign(o.rules->rules.size(), 0.0f); st.fired.assign(o.rules->rules.size(), 0); }
        if (!st.init) { st.open = o.rules->startsOpen; st.amount = st.open ? 1.0f : 0.0f; st.hidden = o.rules->startsHidden; st.init = true; }
    }
    if (!started) {
        started = true;
        for (const RuleObject& o : in.objects)
            if (o.rules) for (int i = 0; i < int(o.rules->rules.size()); ++i) if (o.rules->rules[size_t(i)].when == RuleWhen::PlayStarts) fire(in, o, i, out);
    }
    // what you are doing to things
    const glm::vec3 feet = in.player, head = in.player + glm::vec3(0.0f, in.playerHeight, 0.0f);
    for (const RuleObject& o : in.objects) {
        if (!o.rules || o.rules->rules.empty()) continue;
        ObjState& st = state[o.id];
        const float r = in.playerRadius + 0.05f;
        const bool inside = !st.hidden && feet.x > o.boundsMin.x - r && feet.x < o.boundsMax.x + r && feet.z > o.boundsMin.z - r && feet.z < o.boundsMax.z + r
                            && head.y > o.boundsMin.y - 0.05f && feet.y < o.boundsMax.y + 0.25f;
        const glm::vec3 closest = glm::clamp(feet + glm::vec3(0.0f, 0.9f, 0.0f), o.boundsMin, o.boundsMax);
        const float dist = glm::length(closest - (feet + glm::vec3(0.0f, 0.9f, 0.0f)));
        const bool entered = inside && !st.inside, left = !inside && st.inside;
        st.inside = inside;
        for (int i = 0; i < int(o.rules->rules.size()); ++i) {
            const Rule& rule = o.rules->rules[size_t(i)];
            switch (rule.when) {
            case RuleWhen::Touch: if (entered) fire(in, o, i, out); break;
            case RuleWhen::Leave: if (left) fire(in, o, i, out); break;
            case RuleWhen::Use: if (in.used == o.id && !st.hidden) fire(in, o, i, out); break;
            case RuleWhen::Near: {
                // timers[i] doubles as "was near" for this rule (0 / 1), so each Near rule has its own distance
                const bool nearNow = !st.hidden && dist < rule.number;
                if (nearNow && st.timers[size_t(i)] < 0.5f) fire(in, o, i, out);
                st.timers[size_t(i)] = nearNow ? 1.0f : 0.0f;
                break;
            }
            case RuleWhen::Every:
                st.timers[size_t(i)] += dt;
                if (st.timers[size_t(i)] >= rule.number) { st.timers[size_t(i)] -= rule.number; fire(in, o, i, out); }
                break;
            default: break;
            }
        }
    }
    // things that were waiting
    for (size_t k = 0; k < pending.size();) {
        if (pending[k].at <= clock) { const Pending p = pending[k]; pending.erase(pending.begin() + long(k)); act(in, p.from, p.action, out); }
        else ++k;
    }
    // messages: whoever is listening hears them (a few rounds, so one message can set off another, but never forever)
    for (int round = 0; round < 8 && !pendingSignals.empty(); ++round) {
        std::vector<std::string> now;
        now.swap(pendingSignals);
        for (const std::string& sig : now) {
            const std::string key = lower(sig);
            note("message \"" + sig + "\"");
            for (const RuleObject& o : in.objects) {
                if (!o.rules) continue;
                for (int i = 0; i < int(o.rules->rules.size()); ++i) {
                    const Rule& rule = o.rules->rules[size_t(i)];
                    if (rule.when == RuleWhen::Hears && lower(rule.text) == key) fire(in, o, i, out);
                }
            }
        }
    }
    // doors move
    for (auto& [id, st] : state) {
        const RuleObject* o = find(in, id);
        const float secs = o && o->rules ? o->rules->openSeconds : 0.8f;
        const float target = st.open ? 1.0f : 0.0f;
        const float step = dt / std::max(0.05f, secs);
        st.amount = st.amount < target ? std::min(target, st.amount + step) : std::max(target, st.amount - step);
    }
}

} // namespace px
