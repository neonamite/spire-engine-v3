#pragma once
// "When this happens -> do that" (v0.21): rules on objects, made without code. A rule is a sentence:
//
//     When  [you touch it]          ->  [show a message] "You found the old well!"
//     When  [you press E on it]     ->  [open / close it]
//     When  [it hears "gate"]       ->  [open it] (the gate)  after 0.5 s
//
// Each object keeps its own rules (JSON in SceneObject::rules). While you play, the RuleEngine watches what happens -
// you touching, leaving, coming near, pressing E on things, timers, messages one object sends another - and does what
// the rules say. Pure: no window, no world; the editor hands it the player and the objects each tick and applies what
// comes back (doors swinging, things hidden, messages, sounds, a teleport, points). Every rule is unit tested.
#include <cstdint>
#include <functional>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>
#include "core/Json.h"

namespace px {

using RuleObjectId = std::uint32_t;                  // the scene's ObjectId
inline constexpr RuleObjectId kRuleSelf = 0;         // an action's target: the object the rule is on
inline constexpr RuleObjectId kRulePlayer = 0xFFFFFFFFu;

enum class RuleWhen : std::uint8_t { PlayStarts, Touch, Leave, Near, Use, Every, Hears, Count };   // append only (saved)
enum class RuleDo : std::uint8_t { Message, Open, Close, Toggle, Hide, Show, Collect, Sound, Teleport, Send, Say, AddScore, Win, Lose,
                                   LoseLife, Checkpoint, AddTime, Count };   // append only
const char* ruleWhenName(RuleWhen w);        // "touch" (files)
const char* ruleWhenLabel(RuleWhen w);       // "you touch it"
const char* ruleDoName(RuleDo d);
const char* ruleDoLabel(RuleDo d);           // "show a message"
bool ruleWhenTakesNumber(RuleWhen w);        // Near (metres), Every (seconds)
bool ruleWhenTakesText(RuleWhen w);          // Hears (the message)
bool ruleDoTakesText(RuleDo d);              // Message, Sound, Send, Say, Win, Lose
bool ruleDoTakesNumber(RuleDo d);            // AddScore (points), Message (seconds)
bool ruleDoTakesTarget(RuleDo d);            // Open .. Show, Collect, Teleport, Say

// How a door-like object opens.
enum class OpenStyle : std::uint8_t { Swing, Slide, Lift, Sink, Count };
const char* openStyleName(OpenStyle s);
const char* openStyleLabel(OpenStyle s);

struct RuleAction {
    RuleDo what = RuleDo::Message;
    RuleObjectId target = kRuleSelf;
    std::string text;
    float number = 0.0f;                     // points; message seconds (0 = the default)
    float delay = 0.0f;                      // seconds after the rule fires
    bool operator==(const RuleAction&) const = default;
};

struct Rule {
    RuleWhen when = RuleWhen::Touch;
    float number = 3.0f;                     // Near: metres; Every: seconds
    std::string text;                        // Hears: which message
    bool once = false;                       // only the first time
    std::vector<RuleAction> actions;
    bool operator==(const Rule&) const = default;
};

struct RuleSet {
    std::vector<Rule> rules;
    OpenStyle open = OpenStyle::Swing;
    float openSeconds = 0.8f;                // how long opening takes
    bool startsOpen = false;
    bool startsHidden = false;
    void clamp();
    bool empty() const { return rules.empty() && !startsOpen && !startsHidden; }
    bool usable() const;                     // has a "press E" rule
    bool operator==(const RuleSet&) const = default;
};

Json rulesToJson(const RuleSet& r);
bool rulesFromJson(const Json& j, RuleSet& out);
std::string rulesToText(const RuleSet& r);
bool rulesFromText(const std::string& text, RuleSet& out);

// "When you touch it: show a message "Hello", then open the gate." (names come from `nameOf`)
std::string ruleSentence(const Rule& r, const std::function<std::string(RuleObjectId)>& nameOf);

// ---------------------------------------------------------------- playing

struct RuleObject {
    RuleObjectId id = 0;
    const RuleSet* rules = nullptr;          // may be null: an object others act on
    glm::vec3 boundsMin{ 0.0f }, boundsMax{ 0.0f };   // where it is (world box, at rest)
    glm::vec3 position{ 0.0f };              // its origin (teleports land on top of it)
    std::string name;
};

struct RuleInput {
    float dt = 1.0f / 60.0f;
    glm::vec3 player{ 0.0f };                // the feet
    float playerHeight = 1.8f, playerRadius = 0.4f;
    RuleObjectId used = 0;                   // E was pressed on this object this tick (0: no)
    std::vector<RuleObject> objects;
};

struct RuleEffects {
    struct Message { std::string text; float seconds; };
    std::vector<Message> messages;
    struct Sound { std::string name; glm::vec3 at; };
    std::vector<Sound> sounds;
    bool teleport = false;
    glm::vec3 teleportTo{ 0.0f };
    std::vector<std::pair<RuleObjectId, std::string>> says;
    int score = 0;                           // points added this tick
    bool won = false, lost = false;
    std::string endText;
    int livesLost = 0;                       // v0.22: a life lost
    bool checkpoint = false;                 // you will start again here
    glm::vec3 checkpointAt{ 0.0f };
    float addTime = 0.0f;                    // seconds added to (or taken off) the clock
    std::vector<RuleObjectId> collected;
};

class RuleEngine {
public:
    void reset();                                            // a new game: nothing has happened yet
    void tick(const RuleInput& in, RuleEffects& out);
    float openAmount(RuleObjectId id) const;                 // 0 shut .. 1 open (moving smoothly)
    bool isOpen(RuleObjectId id) const;                      // where it is heading
    bool hidden(RuleObjectId id) const;
    int score() const { return points; }
    void addScore(int n) { points += n; }
    const std::vector<std::string>& log() const { return history; }   // what happened, most recent last (tests, the debug panel)
    void send(const std::string& message) { pendingSignals.push_back(message); }   // as if an object had sent it

private:
    struct ObjState { bool inside = false, near = false, open = false, hidden = false, init = false; float amount = 0.0f; std::vector<float> timers; std::vector<char> fired; };
    struct Pending { float at; RuleObjectId from; RuleAction action; };
    std::unordered_map<RuleObjectId, ObjState> state;
    std::vector<Pending> pending;
    std::vector<std::string> pendingSignals;
    std::vector<std::string> history;
    float clock = 0.0f;
    bool started = false;
    int points = 0;
    void fire(const RuleInput& in, const RuleObject& o, int ruleIndex, RuleEffects& out);
    void act(const RuleInput& in, RuleObjectId from, const RuleAction& a, RuleEffects& out);
    const RuleObject* find(const RuleInput& in, RuleObjectId id) const;
    void note(const std::string& s);
};

} // namespace px
