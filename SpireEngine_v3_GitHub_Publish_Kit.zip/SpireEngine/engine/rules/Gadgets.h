#pragma once
// Gadgets (v0.21): ready-made objects that come with their rules - a door that opens when you press E, a gate that lifts
// when it hears "open the gate", a pressure plate and a button that send it, coins and gems to collect, a key, a sign
// that talks when you come near, a teleporter pad and a finish flag. They are ordinary generated assets; placing one
// gives the object its rules (and a spin for coins), which you can then change in Properties > Rules.
#include <string>
#include <vector>
#include "rules/Rules.h"
#include "scene/Asset.h"
#include "scene/Scene.h"

namespace px {

struct GadgetPreset {
    const char* asset;          // "gadget coin"
    const char* label;          // "Coin"
    const char* hint;
    RuleSet rules;
    MotionSettings motion;
};

const std::vector<GadgetPreset>& gadgetPresets();
const GadgetPreset* gadgetFor(const std::string& asset);         // nullptr: not a gadget
void registerGadgets(AssetLibrary& lib);

} // namespace px
