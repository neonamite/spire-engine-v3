#include "rules/GameRules.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace px {

namespace {
struct G { const char* name; const char* label; const char* hint; };
const G kGoals[] = {
    { "none", "Just play", "No goal: explore, build, have fun (rules can still win or lose)" },
    { "finish", "Reach the finish", "Win by touching something with a \"win\" rule, like the finish flag" },
    { "collect", "Collect everything", "Win when every collectable (coins, gems, keys...) is collected" },
    { "points", "Get points", "Win when you have enough points" },
    { "survive", "Survive", "Win by lasting until the time runs out" },
};
} // namespace

const char* gameGoalName(GameGoal g) { return size_t(g) < std::size(kGoals) ? kGoals[size_t(g)].name : "none"; }
const char* gameGoalLabel(GameGoal g) { return size_t(g) < std::size(kGoals) ? kGoals[size_t(g)].label : ""; }
const char* gameGoalHint(GameGoal g) { return size_t(g) < std::size(kGoals) ? kGoals[size_t(g)].hint : ""; }

void GameRules::clamp() {
    if (int(goal) >= int(GameGoal::Count)) goal = GameGoal::None;
    points = std::clamp(points, 1, 100000);
    timeLimit = std::isfinite(timeLimit) ? std::clamp(timeLimit, 0.0f, 24.0f * 3600.0f) : 0.0f;
    if (goal == GameGoal::Survive && timeLimit <= 0.0f) timeLimit = 60.0f;
    lives = std::clamp(lives, 0, 99);
    fallLimit = std::isfinite(fallLimit) ? std::clamp(fallLimit, 0.0f, 500.0f) : 0.0f;
    if (!std::isfinite(spawn.x) || !std::isfinite(spawn.y) || !std::isfinite(spawn.z)) { spawn = glm::vec3(0.0f); hasSpawn = false; }
    for (std::string* s : { &startText, &winText, &loseText }) if (s->size() > 200) s->resize(200);
}

Json gameRulesToJson(const GameRules& g) {
    Json j = Json::object();
    j.set("goal", gameGoalName(g.goal));
    if (g.goal == GameGoal::Points) j.set("points", g.points);
    if (g.timeLimit > 0.0f) j.set("timeLimit", g.timeLimit);
    if (g.lives > 0) j.set("lives", g.lives);
    if (g.fallLimit > 0.0f) j.set("fallLimit", g.fallLimit);
    if (g.hasSpawn) { j.set("spawn", Json::array({ g.spawn.x, g.spawn.y, g.spawn.z })); j.set("spawnYaw", g.spawnYaw); }
    if (!g.startText.empty()) j.set("start", g.startText);
    if (!g.winText.empty()) j.set("win", g.winText);
    if (!g.loseText.empty()) j.set("lose", g.loseText);
    return j;
}

bool gameRulesFromJson(const Json& j, GameRules& out) {
    if (!j.isObject()) return false;
    GameRules g;
    const std::string goal = j.get("goal").str("none");
    for (int i = 0; i < int(GameGoal::Count); ++i) if (goal == gameGoalName(GameGoal(i))) g.goal = GameGoal(i);
    g.points = j.get("points").integer(10);
    g.timeLimit = float(j.get("timeLimit").num(0.0));
    g.lives = j.get("lives").integer(0);
    g.fallLimit = float(j.get("fallLimit").num(0.0));
    const Json& sp = j.get("spawn");
    if (sp.size() == 3) { g.hasSpawn = true; g.spawn = glm::vec3(float(sp.at(0).num()), float(sp.at(1).num()), float(sp.at(2).num())); }
    g.spawnYaw = float(j.get("spawnYaw").num(0.0));
    g.startText = j.get("start").str();
    g.winText = j.get("win").str();
    g.loseText = j.get("lose").str();
    g.clamp();
    out = g;
    return true;
}

std::string gameRulesToText(const GameRules& g) { return g.active() || g.hasSpawn ? gameRulesToJson(g).dump(-1) : std::string(); }
bool gameRulesFromText(const std::string& text, GameRules& out) {
    Json j;
    return !text.empty() && Json::parse(text, j) && gameRulesFromJson(j, out);
}

std::string gameClock(float seconds) {
    const int s = int(std::ceil(std::max(0.0f, seconds) - 1e-4f));
    char b[32];
    if (s >= 3600) std::snprintf(b, sizeof b, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    else std::snprintf(b, sizeof b, "%d:%02d", s / 60, s % 60);
    return b;
}

void gameStart(const GameRules& g, GameState& st, const glm::vec3& start, int collectables) {
    st = GameState();
    st.lives = g.lives;
    st.collectTotal = collectables;
    st.restart = g.hasSpawn ? g.spawn : start;
}

GameEvents gameUpdate(const GameRules& g, GameState& st, const GameTick& t) {
    GameEvents ev;
    if (st.over) return ev;
    st.time += std::max(0.0f, t.dt);
    st.bonus += t.addTime;
    st.collected += t.collectedNow;
    if (t.checkpoint) st.restart = t.checkpointAt;
    auto end = [&](bool won, const std::string& ruleText) {
        st.over = true; st.won = won;
        st.text = !ruleText.empty() ? ruleText : won ? (g.winText.empty() ? std::string("You win!") : g.winText) : (g.loseText.empty() ? std::string("Game over") : g.loseText);
        ev.ended = true;
    };
    // what the rules said comes first
    if (t.ruleLost) { end(false, t.ruleText); return ev; }
    if (t.ruleWon) { end(true, t.ruleText); return ev; }
    // losing lives: from rules, or falling
    const int lost = t.livesLost + (t.fell ? 1 : 0);
    if (lost > 0) {
        ev.lifeLost = true;
        ev.respawn = true;
        if (g.lives > 0) {
            st.lives = std::max(0, st.lives - lost);
            if (st.lives == 0) { end(false, std::string()); return ev; }
        }
    }
    // the goal
    switch (g.goal) {
    case GameGoal::CollectAll: if (st.collectTotal > 0 && st.collected >= st.collectTotal) end(true, std::string()); break;
    case GameGoal::Points: if (t.score >= g.points) end(true, std::string()); break;
    default: break;
    }
    if (st.over) return ev;
    // the clock
    if (g.timeLimit > 0.0f && st.timeLeft(g) <= 0.0f) end(g.goal == GameGoal::Survive, std::string(g.goal == GameGoal::Survive ? "" : (g.loseText.empty() ? "Out of time!" : "")));
    return ev;
}

} // namespace px
