#pragma once
// Game rules (v0.22): what the whole game is about - the goal (reach the finish, collect everything, get some points,
// survive), a time limit, lives, falling, where you start, and what it says at the start and the end. One set per
// world, kept with the scene (and undone with it). Pure: the editor tells it what happened each tick (points, things
// collected, lives lost, a fall) and it says whether the game is won or lost and whether you start again somewhere.
// Every rule is unit tested.
#include <algorithm>
#include <cstdint>
#include <string>
#include <glm/glm.hpp>
#include "core/Json.h"

namespace px {

enum class GameGoal : std::uint8_t { None, Finish, CollectAll, Points, Survive, Count };     // append only (saved)
const char* gameGoalName(GameGoal g);
const char* gameGoalLabel(GameGoal g);       // "Reach the finish"
const char* gameGoalHint(GameGoal g);

struct GameRules {
    GameGoal goal = GameGoal::None;
    int points = 10;                         // Points: how many to win
    float timeLimit = 0.0f;                  // seconds; 0 = no limit. Survive: how long to last
    int lives = 0;                           // 0 = you can't run out
    float fallLimit = 0.0f;                  // metres below where you started that count as a fall (0 = off)
    bool hasSpawn = false;
    glm::vec3 spawn{ 0.0f };                 // where you start (otherwise: where the camera is)
    float spawnYaw = 0.0f;
    std::string startText, winText, loseText;
    void clamp();
    bool active() const { return goal != GameGoal::None || timeLimit > 0.0f || lives > 0 || fallLimit > 0.0f || !startText.empty(); }
    bool operator==(const GameRules&) const = default;
};

Json gameRulesToJson(const GameRules& g);
bool gameRulesFromJson(const Json& j, GameRules& out);
std::string gameRulesToText(const GameRules& g);
bool gameRulesFromText(const std::string& text, GameRules& out);

struct GameState {
    float time = 0.0f;                       // seconds played
    float bonus = 0.0f;                      // seconds added by rules
    int lives = 0;
    int collected = 0, collectTotal = 0;
    glm::vec3 restart{ 0.0f };               // where you start again after a fall or a lost life
    bool over = false, won = false;
    std::string text;                        // the end message
    float timeLeft(const GameRules& g) const { return g.timeLimit > 0.0f ? std::max(0.0f, g.timeLimit + bonus - time) : 0.0f; }
};

struct GameTick {
    float dt = 0.0f;
    int score = 0;                           // the points now
    int collectedNow = 0;                    // things collected this tick
    int livesLost = 0;                       // lives lost this tick (rules)
    bool fell = false;                       // fell past the fall limit this tick
    bool ruleWon = false, ruleLost = false;  // a rule said so
    std::string ruleText;
    bool checkpoint = false;
    glm::vec3 checkpointAt{ 0.0f };
    float addTime = 0.0f;
};

struct GameEvents {
    bool respawn = false;                    // put the player at state.restart
    bool lifeLost = false;
    bool ended = false;
};

void gameStart(const GameRules& g, GameState& st, const glm::vec3& start, int collectables);
GameEvents gameUpdate(const GameRules& g, GameState& st, const GameTick& t);
std::string gameClock(float seconds);        // "1:05"

} // namespace px
