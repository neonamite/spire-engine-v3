#include "rules/Gadgets.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include <glm/glm.hpp>
#include "workshop/Workshop.h"

namespace px {

namespace {
using Sdf = std::function<float(const glm::vec3&)>;
float box(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
float cylY(const glm::vec3& q, float r, float halfH) {               // a cylinder standing on end
    const glm::vec2 d = glm::abs(glm::vec2(glm::length(glm::vec2(q.x, q.z)), q.y)) - glm::vec2(r, halfH);
    return std::min(std::max(d.x, d.y), 0.0f) + glm::length(glm::max(d, glm::vec2(0.0f)));
}
float cylZ(const glm::vec3& q, float r, float halfH) { return cylY(glm::vec3(q.x, q.z, q.y), r, halfH); }   // lying along z (a coin facing you)

struct Maker {
    Workshop w;
    Maker(const std::string& name, const glm::vec3& metres, float voxel) {
        NewAssetSpec spec; spec.name = name; spec.voxelSize = voxel; spec.sizeMetres = metres;
        w.create(spec);
        w.beginStroke("Build gadget");
    }
    void add(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m, float blend = 0.0f) { w.stampSdf(f, lo - glm::vec3(0.04f), hi + glm::vec3(0.04f), StampMode::Add, m, blend); }
    void carve(const Sdf& f, glm::vec3 lo, glm::vec3 hi) { w.stampSdf(f, lo - glm::vec3(0.04f), hi + glm::vec3(0.04f), StampMode::Carve, MAT_STONE, 0.0f); }
    void paint(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m) { w.stampSdf(f, lo - glm::vec3(0.04f), hi + glm::vec3(0.04f), StampMode::Paint, m, 0.0f); }
    void cube(glm::vec3 c, glm::vec3 h, float r, MaterialId m) { add([=](const glm::vec3& p) { return box(p - c, h, r); }, c - h, c + h, m); }
    AssetPtr finish() {
        w.endStroke();
        w.remesh();
        auto a = std::make_shared<Asset>(w.asset);
        a->type = AssetType::Prop;
        a->tags = { "gadget" };
        a->userMade = false;
        return a;
    }
};

AssetPtr makeDoor() {
    Maker m("gadget door", { 1.1f, 2.3f, 0.3f }, 0.025f);
    m.cube({ 0.0f, 1.05f, 0.0f }, { 0.48f, 1.04f, 0.05f }, 0.01f, MAT_WOOD);
    for (float y : { 0.55f, 1.45f }) m.cube({ 0.0f, y, 0.0f }, { 0.34f, 0.32f, 0.062f }, 0.02f, MAT_WOOD);          // panels
    m.carve([](const glm::vec3& p) { return box(p - glm::vec3(0.0f, 0.55f, 0.075f), { 0.28f, 0.26f, 0.02f }, 0.01f); }, { -0.3f, 0.28f, 0.05f }, { 0.3f, 0.82f, 0.1f });
    m.carve([](const glm::vec3& p) { return box(p - glm::vec3(0.0f, 1.45f, 0.075f), { 0.28f, 0.26f, 0.02f }, 0.01f); }, { -0.3f, 1.18f, 0.05f }, { 0.3f, 1.72f, 0.1f });
    for (float z : { 0.075f, -0.075f }) m.add([=](const glm::vec3& p) { return glm::length(p - glm::vec3(0.36f, 1.0f, z)) - 0.035f; }, { 0.32f, 0.96f, z - 0.04f }, { 0.4f, 1.04f, z + 0.04f }, MAT_GOLD);   // brass handles
    return m.finish();
}
AssetPtr makeGate() {
    Maker m("gadget gate", { 2.2f, 2.4f, 0.3f }, 0.04f);
    for (int i = 0; i < 9; ++i) {
        const float x = -0.9f + float(i) * 0.225f;
        m.add([=](const glm::vec3& p) { return cylY(p - glm::vec3(x, 1.05f, 0.0f), 0.03f, 1.0f); }, { x - 0.04f, 0.0f, -0.04f }, { x + 0.04f, 2.1f, 0.04f }, MAT_METAL);
        m.add([=](const glm::vec3& p) { return glm::length(glm::vec2(p.x - x, p.z)) + std::max(0.0f, p.y - 2.05f) * 2.5f - 0.05f; }, { x - 0.06f, 2.0f, -0.06f }, { x + 0.06f, 2.2f, 0.06f }, MAT_METAL);   // spikes
    }
    for (float y : { 0.25f, 1.0f, 1.8f }) m.cube({ 0.0f, y, 0.0f }, { 1.0f, 0.05f, 0.035f }, 0.01f, MAT_METAL);
    return m.finish();
}
AssetPtr makePlate() {
    Maker m("gadget pressure plate", { 1.2f, 0.3f, 1.2f }, 0.025f);
    m.cube({ 0.0f, 0.04f, 0.0f }, { 0.55f, 0.04f, 0.55f }, 0.01f, MAT_STONE);
    m.cube({ 0.0f, 0.09f, 0.0f }, { 0.42f, 0.03f, 0.42f }, 0.015f, MAT_METAL);
    m.paint([](const glm::vec3& p) { return std::fabs(box(p - glm::vec3(0.0f, 0.12f, 0.0f), { 0.3f, 0.05f, 0.3f }, 0.0f)) - 0.02f; }, { -0.35f, 0.08f, -0.35f }, { 0.35f, 0.14f, 0.35f }, MAT_PAINT_YELLOW);
    return m.finish();
}
AssetPtr makeButton() {
    Maker m("gadget button", { 0.6f, 1.3f, 0.6f }, 0.02f);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(0.0f, 0.5f, 0.0f), 0.13f, 0.5f) - 0.01f; }, { -0.15f, 0.0f, -0.15f }, { 0.15f, 1.0f, 0.15f }, MAT_STONE);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(0.0f, 1.02f, 0.0f), 0.18f, 0.03f) - 0.01f; }, { -0.2f, 0.98f, -0.2f }, { 0.2f, 1.06f, 0.2f }, MAT_STEEL);
    m.add([](const glm::vec3& p) { return glm::length((p - glm::vec3(0.0f, 1.06f, 0.0f)) * glm::vec3(1.0f, 1.8f, 1.0f)) - 0.1f; }, { -0.11f, 1.03f, -0.11f }, { 0.11f, 1.13f, 0.11f }, MAT_PAINT_RED);
    return m.finish();
}
AssetPtr makeCoin() {
    // A gold coin: a raised rim, a five-pointed star struck in relief on both faces, a milled edge.
    Maker m("gadget coin", { 0.5f, 0.75f, 0.2f }, 0.008f);
    m.add([](const glm::vec3& p) {
              const glm::vec2 q(p.x, p.y - 0.45f);
              const float ang = std::atan2(q.y, q.x);
              const float milled = 0.0025f * std::max(0.0f, std::cos(ang * 90.0f));             // the reeded edge
              return cylZ(p - glm::vec3(0.0f, 0.45f, 0.0f), 0.172f + milled, 0.018f) - 0.004f;
          }, { -0.19f, 0.26f, -0.04f }, { 0.19f, 0.64f, 0.04f }, MAT_GOLD);
    m.add([](const glm::vec3& p) { return std::max(std::fabs(glm::length(glm::vec2(p.x, p.y - 0.45f)) - 0.158f) - 0.012f, std::fabs(p.z) - 0.027f); },
          { -0.19f, 0.26f, -0.04f }, { 0.19f, 0.64f, 0.04f }, MAT_GOLD, 0.003f);
    m.add([](const glm::vec3& p) {                                                            // the star, in relief
              const glm::vec2 q(p.x, p.y - 0.45f);
              const float ang = std::atan2(q.x, q.y), r = glm::length(q);
              const float seg = 6.2831853f / 5.0f;
              const float a = std::fabs(std::fmod(ang + 6.2831853f + seg * 0.5f, seg) - seg * 0.5f) / (seg * 0.5f);   // 0 at a point, 1 between
              const float edge = glm::mix(0.105f, 0.045f, std::pow(a, 0.8f));
              return std::max((r - edge) * 0.6f, std::fabs(p.z) - 0.026f);
          }, { -0.12f, 0.33f, -0.04f }, { 0.12f, 0.57f, 0.04f }, MAT_GOLD, 0.002f);
    return m.finish();
}
AssetPtr makeGem() {
    Maker m("gadget gem", { 0.5f, 0.9f, 0.5f }, 0.015f);
    m.add([](const glm::vec3& p) {                                                          // an octahedron, taller than wide
        const glm::vec3 q = glm::abs(p - glm::vec3(0.0f, 0.5f, 0.0f));
        return (q.x + q.y * 0.55f + q.z - 0.2f) * 0.57f;
    }, { -0.22f, 0.12f, -0.22f }, { 0.22f, 0.88f, 0.22f }, MAT_CRYSTAL);
    return m.finish();
}
AssetPtr makeKey() {
    Maker m("gadget key", { 0.6f, 0.75f, 0.2f }, 0.008f);
    m.add([](const glm::vec3& p) { return std::max(std::fabs(glm::length(glm::vec2(p.x + 0.13f, p.y - 0.45f)) - 0.07f) - 0.022f, std::fabs(p.z) - 0.02f); }, { -0.25f, 0.33f, -0.03f }, { 0.0f, 0.57f, 0.03f }, MAT_GOLD);
    m.cube({ 0.08f, 0.45f, 0.0f }, { 0.15f, 0.022f, 0.02f }, 0.008f, MAT_GOLD);
    for (float x : { 0.16f, 0.21f }) m.cube({ x, 0.40f, 0.0f }, { 0.018f, 0.04f, 0.02f }, 0.005f, MAT_GOLD);
    return m.finish();
}
AssetPtr makeSign() {
    Maker m("gadget sign", { 1.3f, 1.9f, 0.4f }, 0.025f);
    m.cube({ 0.0f, 0.65f, -0.03f }, { 0.05f, 0.65f, 0.05f }, 0.015f, MAT_WOOD);
    m.cube({ 0.0f, 1.4f, 0.0f }, { 0.55f, 0.3f, 0.04f }, 0.02f, MAT_WOOD);
    for (float y : { 1.5f, 1.4f, 1.3f })
        m.paint([=](const glm::vec3& p) { return box(p - glm::vec3(-0.05f + (y == 1.3f ? -0.1f : 0.0f), y, 0.04f), { y == 1.3f ? 0.28f : 0.38f, 0.018f, 0.02f }, 0.0f); }, { -0.45f, y - 0.03f, 0.0f }, { 0.4f, y + 0.03f, 0.07f }, MAT_PAINT_BLACK);
    return m.finish();
}
AssetPtr makeTeleporter() {
    Maker m("gadget teleporter", { 1.6f, 0.4f, 1.6f }, 0.025f);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(0.0f, 0.06f, 0.0f), 0.72f, 0.06f) - 0.01f; }, { -0.74f, 0.0f, -0.74f }, { 0.74f, 0.13f, 0.74f }, MAT_METAL);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(0.0f, 0.13f, 0.0f), 0.55f, 0.02f); }, { -0.56f, 0.1f, -0.56f }, { 0.56f, 0.16f, 0.56f }, MAT_LAMP);
    m.paint([](const glm::vec3& p) { return std::fabs(glm::length(glm::vec2(p.x, p.z)) - 0.35f) - 0.04f; }, { -0.4f, 0.12f, -0.4f }, { 0.4f, 0.17f, 0.4f }, MAT_CRYSTAL);
    return m.finish();
}
AssetPtr makeFlag() {
    Maker m("gadget finish flag", { 1.2f, 3.1f, 0.4f }, 0.03f);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(-0.45f, 1.45f, 0.0f), 0.04f, 1.45f); }, { -0.5f, 0.0f, -0.05f }, { -0.4f, 2.9f, 0.05f }, MAT_METAL);
    m.add([](const glm::vec3& p) { return glm::length(p - glm::vec3(-0.45f, 2.94f, 0.0f)) - 0.07f; }, { -0.53f, 2.86f, -0.08f }, { -0.37f, 3.02f, 0.08f }, MAT_GOLD);
    // a chequered flag
    m.add([](const glm::vec3& p) { return box(p - glm::vec3(0.05f, 2.45f, 0.0f), { 0.48f, 0.32f, 0.02f }, 0.0f); }, { -0.45f, 2.12f, -0.03f }, { 0.55f, 2.78f, 0.03f }, MAT_SNOW);
    m.paint([](const glm::vec3& p) {
        const int cx = int(std::floor((p.x + 0.43f) / 0.16f)), cy = int(std::floor((p.y - 2.13f) / 0.16f));
        return ((cx + cy) & 1) ? -1.0f : 1.0f;
    }, { -0.43f, 2.13f, -0.03f }, { 0.53f, 2.77f, 0.03f }, MAT_PAINT_BLACK);
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(-0.45f, 0.04f, 0.0f), 0.25f, 0.04f); }, { -0.71f, 0.0f, -0.26f }, { -0.19f, 0.09f, 0.26f }, MAT_STONE);
    return m.finish();
}

RuleAction act(RuleDo d, std::string text = {}, float number = 0.0f, float delay = 0.0f) {
    RuleAction a; a.what = d; a.text = std::move(text); a.number = number; a.delay = delay;
    return a;
}
Rule rule(RuleWhen w, std::vector<RuleAction> acts, float number = 3.0f, std::string text = {}, bool once = false) {
    Rule r; r.when = w; r.actions = std::move(acts); r.number = number; r.text = std::move(text); r.once = once;
    return r;
}
} // namespace

const std::vector<GadgetPreset>& gadgetPresets() {
    static const std::vector<GadgetPreset> list = [] {
        std::vector<GadgetPreset> v;
        auto add = [&](const char* asset, const char* label, const char* hint, std::vector<Rule> rules, OpenStyle open = OpenStyle::Swing, float openSeconds = 0.8f,
                       MotionSettings::Kind motion = MotionSettings::Kind::None) {
            GadgetPreset g{ asset, label, hint, {}, {} };
            g.rules.rules = std::move(rules);
            g.rules.open = open; g.rules.openSeconds = openSeconds;
            g.motion.kind = motion;
            if (motion == MotionSettings::Kind::Spin) { g.motion.speed = 120.0f; g.motion.axis = glm::vec3(0, 1, 0); }
            v.push_back(std::move(g));
        };
        add("gadget door", "Door", "Opens and shuts when you press E on it",
            { rule(RuleWhen::Use, { act(RuleDo::Toggle) }) });
        add("gadget gate", "Gate", "Lifts when it hears \"open the gate\" (from a plate, a button or a key)",
            { rule(RuleWhen::Hears, { act(RuleDo::Open) }, 3.0f, "open the gate") }, OpenStyle::Lift, 2.0f);
        add("gadget pressure plate", "Pressure plate", "Sends \"open the gate\" when you step on it",
            { rule(RuleWhen::Touch, { act(RuleDo::Sound, "chime"), act(RuleDo::Send, "open the gate") }) });
        add("gadget button", "Button", "Sends \"open the gate\" when you press E on it",
            { rule(RuleWhen::Use, { act(RuleDo::Sound, "chime"), act(RuleDo::Send, "open the gate") }) });
        add("gadget coin", "Coin", "Collect it for a point",
            { rule(RuleWhen::Touch, { act(RuleDo::Collect, {}, 1.0f) }) }, OpenStyle::Swing, 0.8f, MotionSettings::Kind::Spin);
        add("gadget gem", "Gem", "Collect it for five points",
            { rule(RuleWhen::Touch, { act(RuleDo::Collect, {}, 5.0f), act(RuleDo::Message, "A gem! +5") }) }, OpenStyle::Swing, 0.8f, MotionSettings::Kind::Spin);
        add("gadget key", "Key", "Pick it up; it sends \"open the gate\"",
            { rule(RuleWhen::Touch, { act(RuleDo::Collect), act(RuleDo::Message, "You found a key!"), act(RuleDo::Send, "open the gate") }) },
            OpenStyle::Swing, 0.8f, MotionSettings::Kind::Spin);
        add("gadget sign", "Sign", "Shows its message when you come near",
            { rule(RuleWhen::Near, { act(RuleDo::Message, "Welcome! Write your own message in Properties > Rules.") }, 3.0f) });
        add("gadget teleporter", "Teleporter", "Sends you to another object (choose which in its rules)",
            { rule(RuleWhen::Touch, { act(RuleDo::Message, "Choose where this teleporter goes: Properties > Rules > teleport you to...") }) });
        add("gadget finish flag", "Finish flag", "You win when you reach it",
            { rule(RuleWhen::Touch, { act(RuleDo::Win, "You made it!") }, 3.0f, {}, true) });
        for (GadgetPreset& g : v) g.rules.clamp();
        return v;
    }();
    return list;
}

const GadgetPreset* gadgetFor(const std::string& asset) {
    for (const GadgetPreset& g : gadgetPresets()) if (asset == g.asset) return &g;
    return nullptr;
}

void registerGadgets(AssetLibrary& lib) {
    lib.addGenerated("gadget door", { "gadget" }, makeDoor);
    lib.addGenerated("gadget gate", { "gadget" }, makeGate);
    lib.addGenerated("gadget pressure plate", { "gadget" }, makePlate);
    lib.addGenerated("gadget button", { "gadget" }, makeButton);
    lib.addGenerated("gadget coin", { "gadget" }, makeCoin);
    lib.addGenerated("gadget gem", { "gadget" }, makeGem);
    lib.addGenerated("gadget key", { "gadget" }, makeKey);
    lib.addGenerated("gadget sign", { "gadget" }, makeSign);
    lib.addGenerated("gadget teleporter", { "gadget" }, makeTeleporter);
    lib.addGenerated("gadget finish flag", { "gadget" }, makeFlag);
}

} // namespace px
