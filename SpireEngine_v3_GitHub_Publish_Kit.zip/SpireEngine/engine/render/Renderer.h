#pragma once
// Owns every OpenGL object. Chunks stay pure CPU data; each frame the renderer
// syncs its GPU copies, then renders:
//
//   shadow cascades  ->  depth prepass  ->  ambient occlusion (half res, blurred)
//   ->  HDR scene (physically based terrain + objects, grass, atmospheric sky, water)  ->  bloom
//   ->  composite (exposure, ACES tonemap, colour grading, vignette)  ->  FXAA  ->  screen
//
// Everything before the composite is linear HDR, so the sun, sky and glowing
// things can be brighter than "white" and bloom naturally.
#include <atomic>
#include <cstdint>
#include <thread>
#include <unordered_map>
#include <vector>
#include <glad/glad.h>
#include <glm/glm.hpp>
#include "Shader.h"
#include "world/WorldTypes.h"
#include "world/Materials.h"
#include "scene/Asset.h"
#include "render/TextureSet.h"
#include "render/TexturePack.h"
#include "render/SkinnedMesh.h"
#include "render/PlanetSurfaceDrawPackets.h"

namespace px {

class ChunkManager;
class VoxelChunk;
struct Camera;

struct RenderSettings {
    // ---- light & sky (sunDirection = the direction sunlight travels; set by the day/night cycle)
    glm::vec3 sunDirection = glm::normalize(glm::vec3(-0.4f, -1.0f, -0.3f));
    float     sunIntensity    = 2.2f;
    float     skyIntensity    = 1.0f;
    float     haze            = 0.30f;    // 0 = crisp blue sky, 1 = hazy/white horizon
    float     nightBrightness = 0.35f;    // how visible the world stays at night
    float     starBrightness  = 1.0f;
    float     fogDensity      = 0.6f;     // 0 = no fog
    float     fogDistance     = 260.0f;

    // ---- surfaces
    struct MaterialTints {                       // multiplies each material's colour on top of its own tint (white = as designed)
        glm::vec3 v[kMaterialSlots];
        MaterialTints() { for (glm::vec3& t : v) t = glm::vec3(1.0f); }
        glm::vec3& operator[](int i) { return v[i]; }
        const glm::vec3& operator[](int i) const { return v[i]; }
    } materialTint;
    float textureScale   = 4.0f;    // metres covered by one repeat of a texture
    float normalStrength = 1.0f;    // surface bumpiness, 0 = flat

    // ---- grass & wind
    bool      grass          = true;
    float     grassDensity   = 1.0f;     // 0..1 of the blades the world has planted
    float     grassDistance  = 70.0f;    // metres until blades have thinned out completely
    float     grassHeight    = 1.0f;
    // ---- trees (1.3): planted by the world on grass
    bool      trees          = true;
    float     treeDensity    = 1.0f;     // 0..1 of the trees the world has planted
    float     treeDistance   = 200.0f;   // metres; farther ones are not drawn
    float     windStrength   = 1.0f;
    float     windSpeed      = 1.0f;
    float     windHeading    = 40.0f;    // degrees, the direction the wind blows toward
    glm::vec4 interactor { 0.0f, -1e5f, 0.0f, 0.0f };   // xyz = something that parts the grass, w = its radius
    // Patches where no grass grows (the floors of buildings). Two vec4 per patch:
    //   (minX, minZ, maxX, maxZ) and (lowY, highY, 0, 0): blades rooted inside the box are not drawn.
    static constexpr int kMaxGrassClearings = 48;
    std::vector<glm::vec4> grassClear;

    // ---- water (the level itself is a world setting: TerrainSettings::waterLevel)
    bool      water         = true;
    float     waterLevel    = 31.0f;
    float     waterRadius   = 200.0f;                       // how far the sea is drawn
    glm::vec3 waterShallow  { 0.10f, 0.52f, 0.52f };
    glm::vec3 waterDeep     { 0.015f, 0.12f, 0.24f };
    float     waterClarity  = 12.0f;                        // metres you can see through
    float     waveStrength  = 1.0f;
    float     waveSpeed     = 1.0f;
    float     foam          = 0.6f;

    // ---- shadows
    bool  shadows     = true;
    float shadowRange = 90.0f;   // half-size of the shadow box around the camera
    int   shadowSize  = 4096;    // shadow map resolution in pixels (1024 / 2048 / 4096): quality, not look

    // ---- quality
    float renderScale = 1.0f;    // 3D resolution relative to the view: 0.5 = half (fast), 1.5 = supersampled (sharp)
    int   textureSize = 2048;    // pixels per material texture: 512 / 1024 / 2048 / 4096 (built in the background, then cached)
    bool  ssao        = true;    // screen-space ambient occlusion

    // ---- camera & post-processing
    float exposure        = 0.9f;
    bool  bloom           = true;
    float bloomIntensity  = 0.35f;
    float bloomThreshold  = 1.1f;
    float contrast        = 1.10f;
    float saturation      = 1.0f;
    float temperature     = 0.0f;    // -1 cool .. +1 warm
    float vignette        = 0.25f;
    bool  fxaa            = true;

    // ---- what to draw (the Asset Workshop turns the world off and shows only its own objects)
    bool  drawWorld = true;      // terrain, grass and water

    // ---- debug
    bool  wireframe = false;
};

// One placed object to draw this frame (the scene hands these over; the renderer keeps the GPU copies
// of the asset meshes and forgets the ones nobody has drawn for a while).
struct ObjectDraw {
    AssetPtr  asset;
    glm::mat4 model{ 1.0f };
    float     scale = 1.0f;            // the uniform scale inside model; textures keep their real-world size
    glm::vec4 highlight{ 0.0f };       // rgb glow colour, a = strength (selected, or a placement preview)
    glm::vec3 tint{ 1.0f };            // multiplies the object's colours (a character's skin and clothes)
    glm::vec4 hairTint{ 0.0f };        // rgb = the colour of any hair on it (a = 1 to use it): a character's eyebrows take their hair colour
    // A skinned body instead of an asset: the mesh in its bind pose and where each bone is now (1.2).
    std::shared_ptr<const SkinnedMesh> skin{};
    std::shared_ptr<const SkinBones> bones{};
    Expressions expr{};                // a realistic body's face this frame (blink, smile...): how much of each
    glm::vec3 eyeColour{ 0.30f, 0.20f, 0.12f };   // its iris (sRGB)
    glm::vec3 sway{ 0.0f };            // 1.6: how far loose parts (hair ends, a hem) swing this frame, world metres
    bool cards = false;                // see-through cards (hair): cut out by their texture, left out of the depth prepass
    bool foliage = false;              // a tree or bush: left out of the shadow map beyond shadow range
};

class Renderer {
public:
    bool init();
    void shutdown();

    void sync(const ChunkManager& world);
    // Opt-in v2 orbital preview. Main thread only; source patches are immutable.
    // Empty selection releases unused GPU buffers on the next render call.
    void setPlanetSurfacePackets(std::vector<PlanetSurfaceDrawPacket> packets) {
        planetPackets = std::move(packets);
    }
    size_t orbitalTriangleCount() const { return planetTriangles; }
    // The objects to draw in the next render() call (replaces the previous list).
    void setObjects(std::vector<ObjectDraw> list) { objects = std::move(list); }
    void addObject(ObjectDraw d) { objects.push_back(std::move(d)); }       // on top of the list, for this frame (the item in the hand)
    // width x height is the size of the 3D view in pixels. The finished picture lands in the
    // window at (screenX, screenY), measured from the bottom-left like OpenGL: the editor uses
    // this to render only into the free area between its docked panels.
    void render(const Camera& camera, int width, int height, const RenderSettings& rs, int screenX = 0, int screenY = 0);

    size_t gpuChunkCount() const { return meshes.size(); }
    size_t triangleCount() const { return triangles; }
    size_t objectTriangleCount() const { return objectTriangles; }
    size_t grassBladeCount() const { return grassBlades; }
    // Small preview of a material's texture for UI swatches (an OpenGL texture
    // name, usable as an ImTextureID). 0 for Natural / unknown ids.
    unsigned materialPreview(MaterialId id) const;

    // ---- material textures: built (or read from the cache) on a background thread at the size RenderSettings asks for,
    // swapped in when ready. Until then the last set keeps drawing.
    int  textureSize() const { return loadedTextureSize; }
    bool texturesBuilding() const { return textureJob.joinable(); }
    float textureProgressHint() const { return texturesBuilding() ? 0.5f : 1.0f; }
    bool texturesCompressed() const { return canCompress; }
    // Blocks until the set being built is in (screenshots and tests that must show the final look).
    void finishTextures();
    // A texture pack's pictures replace the built-in materials it has (nullptr: all built-in). Loads in the background.
    void useTexturePack(std::shared_ptr<const TexturePack> pack);
    const TexturePack* texturePack() const { return pack.get(); }
    // What went wrong loading the pack (pictures that could not be read), from the last finished build.
    const std::vector<std::string>& texturePackProblems() const { return packProblems; }

private:
    struct GpuMesh {
        GLuint vao = 0, vbo = 0;
        GLsizei vertexCount = 0;
        GLuint grassVao = 0, grassVbo = 0;
        GLsizei grassCount = 0;
        glm::vec3 center{ 0.0f };
        const VoxelChunk* source = nullptr;
        std::uint32_t version = 0, generation = 0;
    };
    struct GpuPlanet {
        GLuint vao=0, vbo=0, ibo=0;
        GLsizei indices=0;
        const PlanetSurfacePatch* source=nullptr;
    };
    static void release(GpuPlanet& m);
    void syncPlanetGpu();
    void drawPlanetOrbit(const Camera& camera, const RenderSettings& rs) const;
    struct GpuObject {               // an asset's mesh on the GPU
        GLuint vao = 0, vbo = 0;
        GLsizei vertexCount = 0;
        AssetPtr asset;              // keeps the asset alive while it is cached
        std::uint32_t version = 0;
        std::uint64_t lastUsed = 0;
    };
    struct GpuSkin {                 // a skinned body's mesh on the GPU
        GLuint vao = 0, vbo = 0, ebo = 0, xbo = 0;   // xbo: a realistic body's UVs and surface modes
        GLsizei vertexCount = 0;     // indices
        std::shared_ptr<const SkinnedMesh> mesh;
        std::uint64_t lastUsed = 0;
    };
    struct Target {                  // a colour texture you can render into
        GLuint fbo = 0, tex = 0;
        int w = 0, h = 0;
    };

    void upload(GpuMesh& m, const VoxelChunk& c, std::uint32_t generation);
    static void release(GpuMesh& m);
    void drawAll() const;
    void prepareObjects();                          // upload new meshes, forget unused ones
    void drawObjects(const Shader& s, bool lit, float foliageReach = 1e9f) const;
    glm::vec3 drawCameraPos{ 0.0f };   // where the camera is in the frame being drawn
    void drawGrass(const glm::vec3& cameraPos, const glm::mat4& viewProj, const RenderSettings& rs) const;
    void resizeTargets(int w, int h);
    static void createTarget(Target& t, int w, int h, GLenum internalFormat, GLenum type);
    static void destroyTarget(Target& t);
    void drawFullscreen() const;

    std::unordered_map<glm::ivec3, GpuMesh, IVec3Hash> meshes;
    std::unordered_map<CubeTileCoord, GpuPlanet, CubeTileHash> planetGpu;
    std::vector<PlanetSurfaceDrawPacket> planetPackets;
    size_t planetTriangles = 0;
    Shader planetOrbitShader;
    Shader terrainShader, depthShader, skyShader, waterShader, grassShader;
    Shader bloomDownShader, bloomUpShader, compositeShader, fxaaShader;

    void createMaterialTextures();
    void requestTextures(int size);
    void pollTextures();
    void uploadTextureSet(const TextureSet& set);
    GLuint albedoArray = 0, normalArray = 0, surfaceArray = 0;      // one layer per texture
    GLuint previews[kMaterialSlots] = {};
    bool canCompress = false;                      // the driver takes S3TC (BC3); BC5 is core
    int loadedTextureSize = 0, requestedTextureSize = 0;
    std::thread textureJob;
    std::atomic<bool> textureCancel{ false }, textureDone{ false };
    TextureSet textureResult;
    std::shared_ptr<const TexturePack> pack;           // the texture pack in use, if any
    std::vector<std::string> packProblems, jobProblems;

    GLuint shadowFbo = 0, shadowMap = 0;
    int shadowRes = 0;                                 // current size of shadowMap (four cascades, 2 x 2 tiles)
    void resizeShadowMap(int size);

    Shader prepassShader, ssaoShader, ssaoBlurShader;
    Target ssaoRaw, ssaoBlur;                          // half resolution: occlusion in r, depth in g

    // HDR scene + bloom chain + LDR result for FXAA
    Target scene;
    GLuint sceneDepth = 0;           // a texture, so ambient occlusion can read the prepass
    Target sceneCopy;                // colour + depth snapshot of the scene, read by the water pass
    GLuint sceneCopyDepth = 0;
    std::vector<Target> bloomMips;
    static constexpr int kBloomLevels = 6;
    Target ldr;
    GLuint emptyVao = 0;             // core profile needs a VAO even for vertex-less draws
    int targetW = 0, targetH = 0;

    std::vector<ObjectDraw> objects;
    std::unordered_map<const Asset*, GpuObject> objectMeshes;
    std::unordered_map<const SkinnedMesh*, GpuSkin> skinMeshes;
    // What realistic bodies share (1.5): their detail maps, the eyes, the expression shapes.
    GLuint humanMap0 = 0, humanMap1 = 0, humanEye = 0, humanHair = 0, morphBuffer = 0, morphTexture = 0;
    int morphVerts = 0;
    std::uint32_t humanVersion = 0;
    float frameTime = 0.0f;                    // this frame's time, the same in every pass
    void uploadHumanData();
    std::uint64_t frameNumber = 0;

    size_t triangles = 0;
    size_t objectTriangles = 0;
    size_t grassBlades = 0;
};

} // namespace px
