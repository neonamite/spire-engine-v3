#pragma once
// GLSL sources for the renderer. Kept in one place so the lighting model is
// easy to read and tweak. All lighting is in linear HDR; the composite pass
// tonemaps and converts to display gamma.
#include <string>
#include "world/Materials.h"

namespace px::shaders {

// C11 experimental orbital preview (separate from sculptable volumetric SDF).
// A rotation-only view is essential: uOffset is already camera-relative.
inline constexpr const char* kPlanetOrbitVS = R"(#version 330 core
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
uniform mat4 uRotationProjection;
uniform vec3 uOffset;
out vec3 vNormal;
void main() {
    vNormal = normalize(aNormal);
    gl_Position = uRotationProjection * vec4(aPosition + uOffset, 1.0);
}
)";
inline constexpr const char* kPlanetOrbitFS = R"(#version 330 core
in vec3 vNormal;
out vec4 fragColor;
uniform vec3 uToSun;
uniform float uSunIntensity;
void main() {
    vec3 n = normalize(vNormal);
    float lat = abs(n.y);
    vec3 ground = mix(vec3(0.17,0.27,0.14), vec3(0.40,0.38,0.31),
                      smoothstep(0.33,0.67,lat));
    ground = mix(ground, vec3(0.74,0.78,0.79), smoothstep(0.79,0.95,lat));
    float light = 0.14 + max(dot(n, normalize(uToSun)),0.0) * uSunIntensity * 0.62;
    fragColor = vec4(ground*light, 1.0);
}
)";

// ------------------------------------------------------------------ shared atmosphere
// One analytic sky model used by BOTH the sky and the terrain (ambient light and
// fog), so distant terrain always fades into exactly the sky behind it.
inline const char* kAtmosphere = R"(
uniform vec3  uToSun;          // unit vector pointing at the sun
uniform float uSkyIntensity;
uniform float uSunIntensity;
uniform float uHaze;
uniform float uNight;          // night brightness 0..1
uniform float uFogDist, uFogDensity;
uniform float uUnder;          // 1 when the camera is under water
uniform vec3  uWaterDeep;
uniform float uWaterAbsorb;    // how quickly water swallows light (per metre)

float dayFactor()    { return smoothstep(-0.12, 0.22, uToSun.y); }
float sunsetFactor() { return 1.0 - smoothstep(0.0, 0.32, abs(uToSun.y + 0.02)); }

vec3 sunLightColor() {
    vec3 warm = vec3(1.0, 0.50, 0.22), white = vec3(1.0, 0.95, 0.88);
    return mix(warm, white, smoothstep(0.02, 0.45, uToSun.y)) * smoothstep(-0.06, 0.06, uToSun.y) * uSunIntensity;
}

vec3 moonLightColor() {
    return vec3(0.55, 0.65, 1.0) * smoothstep(0.05, -0.15, uToSun.y) * 0.35 * (0.3 + uNight);
}

vec3 skyColor(vec3 dir) {
    float day = dayFactor(), sunset = sunsetFactor();
    vec3 zenithDay    = mix(vec3(0.07, 0.20, 0.62), vec3(0.30, 0.42, 0.70), uHaze * 0.6);
    vec3 horizonDay   = mix(vec3(0.36, 0.55, 0.85), vec3(0.70, 0.76, 0.86), uHaze);
    vec3 zenithNight  = vec3(0.006, 0.010, 0.030) * (0.6 + uNight);
    vec3 horizonNight = vec3(0.020, 0.032, 0.065) * (0.6 + uNight);

    float up = clamp(dir.y, 0.0, 1.0);
    float t = pow(1.0 - up, 3.0);
    vec3 col = mix(mix(zenithNight, zenithDay, day), mix(horizonNight, horizonDay, day), t);

    // Sunrise / sunset band, strongest on the side of the sky the sun is on.
    vec2 sf = normalize(uToSun.xz + vec2(1e-4));
    vec2 df = normalize(dir.xz + vec2(1e-4));
    float toward = max(dot(sf, df), 0.0);
    vec3 glowCol = mix(vec3(1.0, 0.36, 0.12), vec3(1.0, 0.62, 0.32), toward);
    col = mix(col, glowCol, clamp(sunset * t * (0.25 + 0.75 * pow(toward, 2.5)), 0.0, 0.9));

    // Below the horizon: fade to a dim ground haze.
    float below = clamp(-dir.y * 3.0, 0.0, 1.0);
    col = mix(col, mix(horizonNight, horizonDay * 0.55, day), below);

    // Forward scattering glow around the sun.
    float c = max(dot(dir, uToSun), 0.0);
    col += vec3(1.0, 0.72, 0.42) * (pow(c, 8.0) * 0.18 + pow(c, 64.0) * 0.5) * (day * 0.7 + sunset) * (1.0 - below);
    return col * uSkyIntensity;
}
)";

// Light that reaches the water body, used to tint it (so lakes go dark at night).
inline const char* kWaterLight = R"(
vec3 waterBodyLight() {
    return skyColor(vec3(0.0, 1.0, 0.0)) * 0.9 + sunLightColor() * 0.12 * clamp(uToSun.y, 0.0, 1.0) + vec3(0.004, 0.006, 0.012);
}
vec3 underColor() { return uWaterDeep * waterBodyLight(); }

// Distance fog toward the sky; under water the world dissolves into the water colour instead.
vec3 applyFog(vec3 color, float dist, vec3 dir) {
    if (uUnder > 0.5) {
        vec3 transmit = exp(-dist * vec3(0.45, 0.12, 0.06) * uWaterAbsorb);
        return color * transmit + underColor() * (1.0 - exp(-dist * 0.05 * uWaterAbsorb));
    }
    float fog = 1.0 - exp(-pow(dist / uFogDist, 2.0) * 3.0 * uFogDensity);
    return mix(color, skyColor(dir), clamp(fog, 0.0, 1.0));
}

// Light patterns that dance on the sea floor.
float caustics(vec2 p, float t) {
    float a = sin(p.x * 0.9 + sin(p.y * 0.7 + t * 0.8) * 1.7 + t * 0.5);
    float b = sin(p.y * 1.1 + sin(p.x * 0.8 - t * 0.6) * 1.7 - t * 0.4);
    float c = sin((p.x + p.y) * 0.6 + sin((p.x - p.y) * 0.5 + t * 0.3) * 2.0);
    float v = 1.0 - abs(a * 0.5 + b * 0.5);
    float w = 1.0 - abs(c);
    return pow(clamp(v * w, 0.0, 1.0), 3.0) * 2.2;
}
)";


// ------------------------------------------------------------------ smooth skinning (shared by the object vertex shaders)
// A skinned vertex follows up to four bones; uSkinned = 0 for everything else (the attributes are then unset).
inline const char* kSkinVS = R"(
layout (location = 5) in vec4 aBones;
layout (location = 6) in vec4 aWeights;
layout (location = 7) in vec4 aTint;
layout (location = 8) in vec4 aExtra;     // realistic bodies (1.5): u, v, expression vertex (-1: none), surface mode
uniform int uSkinned;
uniform mat4 uBones[16];
// Expressions: shared shapes (blink, smile...) mixed per draw, each an offset per shared vertex in a buffer texture.
uniform int uMorphOn;
uniform float uExpr[8];
uniform float uExprScale;
uniform int uMorphVerts;
uniform samplerBuffer uMorphs;
// Sway (1.6): a realistic body's loose vertices (hair ends, a skirt's hem; how loose is in aExtra.z below -1) follow the
// character's sway, and flutter a little.
uniform vec3 uSway;
uniform float uSwayTime;
vec3 swayOffset(vec3 w) {
    if (uSkinned == 0 || aExtra.z > -1.001) return vec3(0.0);
    float amt = -aExtra.z - 1.0;
    vec3 flutter = vec3(sin(uSwayTime * 2.3 + w.y * 7.0 + w.x * 3.0), 0.3 * sin(uSwayTime * 1.7 + w.z * 5.0), cos(uSwayTime * 1.9 + w.y * 6.0 + w.z * 2.0));
    return (uSway + flutter * 0.004) * amt;
}
vec3 morphPos(vec3 p) {
    if (uMorphOn == 0 || aExtra.z < -0.5) return p;
    int i = int(aExtra.z + 0.5);
    for (int k = 0; k < 8; ++k)
        if (uExpr[k] != 0.0) p += uExpr[k] * uExprScale * texelFetch(uMorphs, k * uMorphVerts + i).xyz;
    return p;
}
mat4 skinMatrix() {
    if (uSkinned == 0) return mat4(1.0);
    float sum = max(aWeights.x + aWeights.y + aWeights.z + aWeights.w, 1e-4);
    return (uBones[int(aBones.x)] * aWeights.x + uBones[int(aBones.y)] * aWeights.y +
            uBones[int(aBones.z)] * aWeights.z + uBones[int(aBones.w)] * aWeights.w) / sum;
}
)";

// ------------------------------------------------------------------ fullscreen triangle
inline const char* kFullscreenVS = R"(
#version 330 core
out vec2 vUv;
void main() {
    vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    vUv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 1.0, 1.0);   // depth 1.0: the sky only fills empty pixels
}
)";

// ------------------------------------------------------------------ terrain
// Each triangle carries the texture layers of its three corners plus
// barycentric weights, so the fragment shader can blend up to three materials.
// Textures are projected along the three world axes (triplanar), so the
// sculpted, UV-less voxel surface never stretches, even on cliffs and caves.
inline const std::string kTerrainVS = std::string(R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aNormal;
layout (location = 2) in float aAO;
layout (location = 3) in vec4 aLayers;
layout (location = 4) in vec4 aBary;
)") + kSkinVS + R"(
uniform mat4 uViewProj;
// Placed objects are drawn with the same shader: the model matrix puts them in the world, while the
// texture projection stays in the object's own space (so a moved or turned object keeps its look).
uniform mat4 uModel;
uniform mat3 uNormalMat;
uniform float uTexMul;
out vec3 vPos; out vec3 vNormal; out float vAO;
out vec3 vTexPos; out vec3 vTexNormal;
flat out vec3 vLayers; out vec3 vBary;
out vec3 vTint;
out vec2 vUv;
flat out float vMode;
invariant gl_Position;                 // the depth prepass draws exactly the same depths
void main() {
    mat4 S = skinMatrix();
    vec3 p = morphPos(aPos);
    vec4 world = uModel * (S * vec4(p, 1.0));
    world.xyz += swayOffset(world.xyz);
    vPos = world.xyz; vNormal = uNormalMat * (mat3(S) * aNormal); vAO = aAO;
    vTexPos = p * uTexMul; vTexNormal = aNormal;                  // a skinned body's texture stays on the body (bind pose)
    vUv = uSkinned == 1 ? aExtra.xy : vec2(0.0);
    vMode = uSkinned == 1 ? aExtra.w : 0.0;
    vLayers = aLayers.xyz; vBary = aBary.xyz;
    vTint = uSkinned == 1 ? pow(aTint.rgb, vec3(2.2)) : vec3(1.0);
    gl_Position = uViewProj * world;
}
)";

// The depth prepass (for ambient occlusion, and so the expensive lighting runs once per pixel): positions only.
inline const std::string kPrepassVS = std::string(R"(
#version 330 core
layout (location = 0) in vec3 aPos;
)") + kSkinVS + R"(
uniform mat4 uViewProj;
uniform mat4 uModel;
invariant gl_Position;
void main() {
    mat4 S = skinMatrix();
    vec4 world = uModel * (S * vec4(morphPos(aPos), 1.0));
    world.xyz += swayOffset(world.xyz);
    gl_Position = uViewProj * world;
}
)";
inline const char* kPrepassFS = R"(
#version 330 core
void main() {}

)";

// ------------------------------------------------------------------ shadows (shared)
// Four cascades in one depth texture (2 x 2 tiles): sharp near the camera, reaching far. Each is filtered with a
// rotated Poisson disc of hardware-compared taps, so edges are soft and never stair-stepped, and the normal offset
// keeps surfaces from shadowing themselves.
inline const char* kShadows = R"(
uniform sampler2DShadow uShadowMap;
uniform mat4  uCascade[4];
uniform vec4  uCascadeFar;      // how far from the camera each cascade reaches
uniform vec4  uCascadeTexel;    // the world size of one shadow texel in each
uniform int   uShadows;

float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
const vec2 kPoisson[12] = vec2[](vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696, 0.457), vec2(-0.203, 0.621),
                                 vec2(0.962, -0.195), vec2(0.473, -0.480), vec2(0.519, 0.767), vec2(0.185, -0.893),
                                 vec2(0.507, 0.064), vec2(0.896, 0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598));

float cascadeShadow(int i, vec3 wpos, vec3 n, vec3 toLight) {
    float slope = 1.0 - clamp(dot(n, toLight), 0.0, 1.0);
    vec3 p = wpos + n * uCascadeTexel[i] * (1.2 + 2.0 * slope) + toLight * uCascadeTexel[i] * 0.6;
    vec4 lp = uCascade[i] * vec4(p, 1.0);
    vec3 q = lp.xyz / lp.w * 0.5 + 0.5;
    if (q.z > 1.0 || q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) return 0.0;
    vec2 tile = vec2(float(i & 1), float(i >> 1)) * 0.5;
    float texel = 1.0 / float(textureSize(uShadowMap, 0).x);
    vec2 lo = tile + vec2(texel), hi = tile + vec2(0.5 - texel);
    float radius = texel * (1.6 + float(i) * 0.4);
    float a = ign(gl_FragCoord.xy) * 6.2831853;
    mat2 rot = mat2(cos(a), sin(a), -sin(a), cos(a));
    float lit = 0.0;
    for (int k = 0; k < 12; ++k)
        lit += texture(uShadowMap, vec3(clamp(tile + q.xy * 0.5 + rot * kPoisson[k] * radius, lo, hi), q.z - 0.0002));
    return 1.0 - lit / 12.0;
}

// How much of the light is blocked here (0 = lit, 1 = in shadow). Cascades cross-fade, and shadows fade out at the end.
float shadowAt(vec3 wpos, vec3 n, vec3 toLight, vec3 camPos) {
    if (uShadows != 1) return 0.0;
    float d = length(wpos - camPos);
    for (int i = 0; i < 4; ++i) {
        if (d < uCascadeFar[i]) {
            float s = cascadeShadow(i, wpos, n, toLight);
            float edge = smoothstep(uCascadeFar[i] * 0.88, uCascadeFar[i], d);
            if (edge > 0.0) s = mix(s, i < 3 ? cascadeShadow(i + 1, wpos, n, toLight) : 0.0, edge);
            return s;
        }
    }
    return 0.0;
}
)";

// ------------------------------------------------------------------ physically based light (shared)
// GGX microfacets with Smith visibility and Schlick Fresnel; image-based light from the analytic sky.
inline const char* kPbr = R"(
const float PI = 3.14159265;
float D_GGX(float NoH, float a) { float a2 = a * a; float d = NoH * NoH * (a2 - 1.0) + 1.0; return a2 / (PI * d * d); }
float V_Smith(float NoV, float NoL, float a) {
    float a2 = a * a;
    float gv = NoL * sqrt(NoV * NoV * (1.0 - a2) + a2), gl = NoV * sqrt(NoL * NoL * (1.0 - a2) + a2);
    return 0.5 / max(gv + gl, 1e-5);
}
vec3 F_Schlick(vec3 f0, float VoH) { return f0 + (1.0 - f0) * pow(1.0 - VoH, 5.0); }
// Split-sum environment term without a lookup texture (Karis' analytic fit).
vec2 envBRDF(float NoV, float rough) {
    const vec4 c0 = vec4(-1.0, -0.0275, -0.572, 0.022), c1 = vec4(1.0, 0.0425, 1.04, -0.04);
    vec4 r = rough * c0 + c1;
    float a004 = min(r.x * r.x, exp2(-9.28 * NoV)) * r.x + r.y;
    return vec2(-1.04, 1.04) * a004 + r.zw;
}
// One light (sun or moon): the light reflected toward the eye.
vec3 pbrLight(vec3 albedo, float metal, float rough, vec3 n, vec3 v, vec3 l, vec3 radiance) {
    float NoL = max(dot(n, l), 0.0);
    if (NoL <= 0.0) return vec3(0.0);
    vec3 h = normalize(l + v);
    float NoV = max(dot(n, v), 1e-4), NoH = max(dot(n, h), 0.0), VoH = max(dot(v, h), 0.0);
    float a = max(rough * rough, 0.002);
    vec3 f0 = mix(vec3(0.04), albedo, metal);
    vec3 F = F_Schlick(f0, VoH);
    vec3 spec = D_GGX(NoH, a) * V_Smith(NoV, NoL, a) * F * PI;
    vec3 kd = (1.0 - F) * (1.0 - metal);
    return (kd * albedo + spec) * radiance * NoL;
}
// What the sky (and the ground under it) shows in a direction, blurred toward its average the rougher the surface.
vec3 skyReflection(vec3 r, float rough, vec3 groundTint) {
    vec3 sharp = skyColor(normalize(vec3(r.x, max(r.y, 0.02), r.z)));
    vec3 dull = mix(skyColor(vec3(0.0, 1.0, 0.0)), skyColor(normalize(vec3(r.x, 0.1, r.z) + vec3(1e-3))), 0.5);
    vec3 sky = mix(sharp, dull, smoothstep(0.1, 0.9, rough));
    vec3 ground = groundTint * (skyColor(vec3(0.0, 1.0, 0.0)) * 0.5 + sunLightColor() * 0.08 * max(uToSun.y, 0.0));
    return mix(sky, ground, smoothstep(0.05, -0.25, r.y));          // below the horizon you see the ground, not more sky
}
)";

inline std::string terrainFS() {
    const std::string slots = std::to_string(kMaterialSlots);
    return std::string("#version 330 core\n") + "#define SLOTS " + slots + "\n" + kAtmosphere + kWaterLight + kShadows + kPbr + R"(
in vec3 vPos; in vec3 vNormal; in float vAO;
in vec3 vTexPos; in vec3 vTexNormal;
flat in vec3 vLayers; in vec3 vBary;
in vec3 vTint;
in vec2 vUv;
flat in float vMode;                   // a realistic body's surface (1.5): 0 materials, 1 skin, 2 eye, 3 teeth, 4 tongue, 5 lashes
uniform int uSkinned;                  // 1: a skinned body, whose colours come per vertex (skin, top, trousers...)
uniform sampler2D uSkinMap0;           // the body's detail maps, on its UV layout: albedo detail, redness, brows, nails
uniform sampler2D uSkinMap1;           // detail normal x, y, roughness, cavity
uniform sampler2D uEyeMap;             // the eyes (sRGB)
uniform vec3 uEyeColour;               // the iris colour (linear)
uniform float uSkinSlot;               // the material slot of Skin (its pores and their roughness, laid over the maps)
uniform sampler2D uHairMap;            // a hair card: strands along v (brightness, which strand, coverage)
out vec4 FragColor;
uniform vec3 uCameraPos;
uniform mat3 uNormalMat;               // object -> world for normals (identity for terrain)
uniform vec4 uHighlight;               // rgb glow colour, a = how much (selected / being placed)
uniform vec3 uObjTint;                 // multiplies the colour of a whole object (a character's skin and clothes); white = as made
uniform vec4 uHairTint;                // a = 1: hair on this object takes this colour (eyebrows on a head)
uniform vec3 uShadowLightDir;          // unit vector toward whichever light casts shadows
uniform int uWaterOn;
uniform float uWaterLevel;
uniform float uTime;
uniform sampler2DArray uAlbedo;        // rgb = sRGB colour, a = height
uniform sampler2DArray uNormals;       // rg = tangent normal x, y (z is rebuilt)
uniform sampler2DArray uSurface;       // r = occlusion, g = metalness, a = roughness
uniform sampler2D uAO;                 // screen-space ambient occlusion (1 = open)
uniform int   uAOOn;
uniform vec2  uViewSize;
uniform float uTexLayer[SLOTS];        // which texture each material slot is drawn with
uniform float uLayerScale[SLOTS];      // repeats per texture-metre: bricks brick-sized, pebbles pebble-sized
uniform vec3  uTint[SLOTS];            // its tint
uniform float uObjTintable[SLOTS];     // 1: the object's tint colours this material (plaster, cloth, metal); 2: replaces its own (skin, hair)
uniform float uScatter[SLOTS];         // light that passes into the surface and out again (skin, leaves): 0..1
uniform vec2  uEmit[SLOTS];            // x = how much it glows, y = glow only where the texture is bright (0..1)
uniform float uTexScale;               // texture repeats per metre
uniform float uNormalStrength;

// Triplanar state, computed once per pixel in uniform control flow (so the
// texture derivatives stay valid when only some materials are sampled).
vec3 N, W, S;
vec2 uvX, uvY, uvZ;
vec2 dxX, dyX, dxY, dyY, dxZ, dyZ;

struct Surface { vec4 albedo; vec3 normal; float rough; float metal; float occl; vec3 emit; float scatter; };

vec3 unpackNormal(vec2 xy) { vec2 t = xy * 2.0 - 1.0; return vec3(t, sqrt(max(1.0 - dot(t, t), 0.0))); }

Surface sampleLayer(float slot) {
    int si = int(slot + 0.5);
    float layer = uTexLayer[si];
    float k = uLayerScale[si];
    vec2 ux = uvX * k, uy = uvY * k, uz = uvZ * k;
    vec4 ax = textureGrad(uAlbedo, vec3(ux, layer), dxX * k, dyX * k);
    vec4 ay = textureGrad(uAlbedo, vec3(uy, layer), dxY * k, dyY * k);
    vec4 az = textureGrad(uAlbedo, vec3(uz, layer), dxZ * k, dyZ * k);
    vec3 tx = unpackNormal(textureGrad(uNormals, vec3(ux, layer), dxX * k, dyX * k).rg);
    vec3 ty = unpackNormal(textureGrad(uNormals, vec3(uy, layer), dxY * k, dyY * k).rg);
    vec3 tz = unpackNormal(textureGrad(uNormals, vec3(uz, layer), dxZ * k, dyZ * k).rg);
    vec4 sx = textureGrad(uSurface, vec3(ux, layer), dxX * k, dyX * k);
    vec4 sy = textureGrad(uSurface, vec3(uy, layer), dxY * k, dyY * k);
    vec4 sz = textureGrad(uSurface, vec3(uz, layer), dxZ * k, dyZ * k);
    tx.xy *= uNormalStrength; ty.xy *= uNormalStrength; tz.xy *= uNormalStrength;
    tx.x *= S.x; ty.x *= S.y; tz.x *= -S.z;
    // Whiteout blend: tangent normals onto the surface normal, per projection.
    tx = vec3(tx.xy + N.zy, abs(tx.z) * N.x);
    ty = vec3(ty.xy + N.xz, abs(ty.z) * N.y);
    tz = vec3(tz.xy + N.xy, abs(tz.z) * N.z);
    Surface s;
    s.albedo = ax * W.x + ay * W.y + az * W.z;
    vec3 tint = uTint[si];
    vec3 objTint = uSkinned == 1 ? vTint : uObjTint;
    bool personTint = uObjTintable[si] > 1.5 && any(notEqual(objTint, vec3(1.0)));
    tint = personTint ? objTint : tint * mix(vec3(1.0), objTint, min(uObjTintable[si], 1.0));
    if (uObjTintable[si] > 2.5 && uHairTint.a > 0.5) tint = uHairTint.rgb;
    s.albedo.rgb *= tint;
    s.scatter = uScatter[si];
    s.normal = tx.zyx * W.x + ty.xzy * W.y + tz.xyz * W.z;
    vec4 sf = sx * W.x + sy * W.y + sz * W.z;
    s.occl = sf.r; s.metal = sf.g; s.rough = sf.a;
    // Glowing materials: lit by themselves, so they stay bright at night and bloom. Lava glows only where its cracks are.
    float luma = dot(s.albedo.rgb, vec3(0.2126, 0.7152, 0.0722));
    float lit = mix(1.0, smoothstep(0.03, 0.2, luma), uEmit[si].y);
    s.emit = s.albedo.rgb * uEmit[si].x * lit;
    if (uEmit[si].y > 0.5) s.emit *= 0.85 + 0.15 * sin(uTime * 1.6 + dot(vTexPos, vec3(0.9, 0.4, 0.7)));
    return s;
}

// A realistic body's own surface (1.5): the person's colour, laid over the body's detail maps (UV), with the Skin
// material's pores on top (triplanar, so they stay fine however close you come).
Surface humanSurface(int mode) {
    Surface s;
    s.emit = vec3(0.0); s.metal = 0.0; s.occl = 1.0; s.scatter = 0.0;
    vec3 baseN = normalize(vTexNormal);
    if (mode == 2) {                                                   // the eye: white, iris, pupil; wet
        vec4 e = texture(uEyeMap, vUv);
        vec3 c = pow(e.rgb, vec3(2.2));
        // the iris (the saturated ring) takes the person's eye colour, keeping its fibres
        float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
        float iris = smoothstep(0.06, 0.16, sat) * (1.0 - smoothstep(0.55, 0.8, c.r + c.g + c.b));
        float lum = dot(c, vec3(0.3, 0.55, 0.15));
        c = mix(c, uEyeColour * (lum / 0.11), iris * 0.85);
        s.albedo = vec4(c, 0.5); s.normal = baseN; s.rough = 0.06; s.scatter = 0.2;
        return s;
    }
    if (mode == 3 || mode == 4) {                                      // teeth, tongue
        s.albedo = vec4(mode == 3 ? vec3(0.78, 0.74, 0.64) : vec3(0.62, 0.22, 0.22), 0.5);
        s.normal = baseN; s.rough = mode == 3 ? 0.25 : 0.35; s.scatter = 0.5; s.occl = 0.6;
        return s;
    }
    if (mode == 6) {                                                   // a hair card: strands, cut out, in the hair colour
        vec4 h = texture(uHairMap, vUv);
        if (h.a < 0.5) discard;
        vec3 hc = uHairTint.a > 0.5 ? uHairTint.rgb : vec3(0.06, 0.045, 0.035);
        // each strand a shade of its own; roots darker; a lighter sheen near the tips
        vec3 c = hc * mix(0.65, 1.25, h.g) * mix(0.55, 1.0, h.r) * mix(0.75, 1.1, smoothstep(0.0, 0.6, vUv.y));
        s.albedo = vec4(c, 0.5);
        s.normal = baseN;
        s.rough = 0.58; s.scatter = 0.35; s.occl = mix(0.4, 0.8, smoothstep(0.0, 0.35, vUv.y));   // (dull: the sky barely shows in it)
        return s;
    }
    if (mode == 5) {                                                   // lashes: the hair colour, dark
        vec3 hc = uHairTint.a > 0.5 ? uHairTint.rgb : vec3(0.05);
        s.albedo = vec4(hc * 0.35, 0.5); s.normal = baseN; s.rough = 0.5;
        return s;
    }
    vec4 m0 = texture(uSkinMap0, vUv);
    vec4 m1 = texture(uSkinMap1, vUv);
    Surface pores = sampleLayer(uSkinSlot);                            // the Skin material in the person's colour, its pores
    vec3 skin = vTint;
    vec3 col = pores.albedo.rgb * mix(0.8, 1.2, m0.r);
    // lips and flushed parts (cheeks, nose, ears, knuckles): redder and a little darker, more so on fair skin
    float fair = clamp(dot(skin, vec3(0.33)) * 2.2, 0.35, 1.0);
    col = mix(col, col * vec3(1.05, 0.62, 0.6), m0.g * fair);
    col = mix(col, col * vec3(0.78, 0.5, 0.48), m0.g * m0.g * (1.0 - fair) * 1.2);
    // nails: paler, pinker
    col = mix(col, mix(col, vec3(0.62, 0.48, 0.46), 0.55), m0.a);
    // brows: the hair colour, strand by strand
    vec3 hair = uHairTint.a > 0.5 ? uHairTint.rgb : vec3(0.06, 0.045, 0.035);
    col = mix(col, hair * 0.75, m0.b);
    // detail normal from the map (in the UV frame, rebuilt from screen derivatives of the bind-pose surface)
    vec3 dp1 = dFdx(vTexPos), dp2 = dFdy(vTexPos);
    vec2 du1 = dFdx(vUv), du2 = dFdy(vUv);
    vec3 dp2perp = cross(dp2, baseN), dp1perp = cross(baseN, dp1);
    vec3 T = dp2perp * du1.x + dp1perp * du2.x, B = dp2perp * du1.y + dp1perp * du2.y;
    float invmax = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-20));
    vec2 nt = (m1.rg * 2.0 - 1.0) * 1.4;
    vec3 n = normalize(baseN + (T * invmax) * nt.x + (B * invmax) * nt.y);
    // pores from the Skin material, very fine
    vec3 pn = normalize(pores.normal);
    n = normalize(n + (pn - baseN * dot(pn, baseN)) * 0.55);
    s.albedo = vec4(col * mix(1.0, 0.82, m1.a), 0.5);
    s.normal = n;
    s.rough = clamp(m1.b * 0.75 + pores.rough * 0.25, 0.22, 0.9);
    s.occl = mix(1.0, 0.75, m1.a);
    s.scatter = 1.0 - m0.b * 0.8;
    return s;
}

void main() {
    vec3 Nw = normalize(vNormal);          // surface normal in the world: lighting, shadows
    N = normalize(vTexNormal);             // the same normal in the texture projection's space
    W = pow(abs(N), vec3(4.0));
    W /= (W.x + W.y + W.z);
    S = vec3(N.x < 0.0 ? -1.0 : 1.0, N.y < 0.0 ? -1.0 : 1.0, N.z < 0.0 ? -1.0 : 1.0);
    vec3 p = vTexPos * uTexScale;
    uvX = vec2(p.z * S.x, p.y); uvY = vec2(p.x * S.y, p.z); uvZ = vec2(-p.x * S.z, p.y);
    dxX = dFdx(uvX); dyX = dFdy(uvX); dxY = dFdx(uvY); dyY = dFdy(uvY); dxZ = dFdx(uvZ); dyZ = dFdy(uvZ);

    // Large-scale brightness variation hides texture repetition at a distance.
    float macro = texture(uAlbedo, vec3(vTexPos.xz * 0.019, 2.0)).a * 0.6
                + texture(uAlbedo, vec3(vTexPos.xz * 0.0053 + 0.37, 4.0)).a * 0.4;

    Surface surf;
    int mode = int(vMode + 0.5);
    if (mode > 0) {
        surf = humanSurface(mode);
        macro = 0.68;                                                  // (no ground-style patches on people)
    } else if (vLayers.x == vLayers.y && vLayers.x == vLayers.z) {
        surf = sampleLayer(vLayers.x);                 // most triangles: one material
    } else {
        // Height-based blend: the taller texture wins near borders, so stones
        // and bricks poke through grass instead of a blurry crossfade.
        Surface a = sampleLayer(vLayers.x), b = sampleLayer(vLayers.y), c = sampleLayer(vLayers.z);
        // Low-frequency noise per corner bends the borders, so patches follow the ground instead of the triangle grid.
        vec2 q = vTexPos.xz;
        vec3 wob = vec3(texture(uAlbedo, vec3(q * 0.11 + vec2(0.13, 0.71), 2.0)).a,
                        texture(uAlbedo, vec3(q * 0.09 + vec2(0.57, 0.29), 4.0)).a,
                        texture(uAlbedo, vec3(q * 0.13 + vec2(0.91, 0.43), 2.0)).a) - 0.5;
        vec3 t = vBary + vec3(a.albedo.a, b.albedo.a, c.albedo.a) * 0.55 + wob * 0.9;
        float m = max(t.x, max(t.y, t.z)) - 0.18;
        vec3 w = max(t - m, 0.0);
        w /= (w.x + w.y + w.z);
        surf.albedo = a.albedo * w.x + b.albedo * w.y + c.albedo * w.z;
        surf.normal = a.normal * w.x + b.normal * w.y + c.normal * w.z;
        surf.rough  = a.rough * w.x + b.rough * w.y + c.rough * w.z;
        surf.metal  = a.metal * w.x + b.metal * w.y + c.metal * w.z;
        surf.occl   = a.occl * w.x + b.occl * w.y + c.occl * w.z;
        surf.emit   = a.emit * w.x + b.emit * w.y + c.emit * w.z;
        surf.scatter = a.scatter * w.x + b.scatter * w.y + c.scatter * w.z;
    }
    // Large patches drift in brightness and a touch in hue (sun-bleached, damp), like real ground seen from afar.
    vec3 albedo = surf.albedo.rgb * mix(0.74, 1.12, macro);
    albedo *= mix(vec3(1.04, 1.0, 0.94), vec3(0.95, 1.0, 1.05), texture(uAlbedo, vec3(vTexPos.xz * 0.0081 + 0.61, 2.0)).a);
    float rough = clamp(surf.rough, 0.04, 1.0);
    float metal = clamp(surf.metal, 0.0, 1.0);
    vec3 n = normalize(uNormalMat * normalize(surf.normal));
    if (uSkinned == 1) {
        // a skinned body's textures are laid out on its rest pose: turn the detailed normal the way the body has turned here
        vec3 a = normalize(vTexNormal), b = Nw;
        vec3 axis = cross(a, b);
        float sn = length(axis), cs = dot(a, b);
        if (sn > 1e-4) {
            axis /= sn;
            n = n * cs + cross(axis, n) * sn + axis * dot(axis, n) * (1.0 - cs);
        } else if (cs < 0.0) n = -n;
        n = normalize(n);
    }
    vec3 V = normalize(uCameraPos - vPos);
    // Normals facing away from the eye (steep bumps at grazing angles) are pulled back so they never go black.
    n = normalize(n + V * max(0.0, -dot(n, V) + 0.05));

    float ssao = uAOOn == 1 ? texture(uAO, gl_FragCoord.xy / uViewSize).r : 1.0;
    float occl = surf.occl * mix(0.35, 1.0, vAO) * ssao;   // texture crevices x voxel corners x screen-space

    vec3 sunC = sunLightColor(), moonC = moonLightColor();
    float shadow = shadowAt(vPos, Nw, uShadowLightDir, uCameraPos);
    bool sunUp = uToSun.y > 0.0;
    float sunVis  = (sunUp ? 1.0 - shadow : 1.0) * mix(1.0, ssao, 0.35);
    float moonVis = (sunUp ? 1.0 : 1.0 - shadow) * mix(1.0, ssao, 0.35);
    vec3 direct = pbrLight(albedo, metal, rough, n, V, uToSun, sunC * sunVis) +
                  pbrLight(albedo, metal, rough, n, V, -uToSun, moonC * moonVis);
    direct *= mix(1.0, surf.occl, 0.5);                    // deep texture crevices barely see the sun either
    // Skin and leaves: light soaks in and comes out a little further on, reddened (skin) - soft terminator, no plastic look.
    if (surf.scatter > 0.0 && sunUp) {
        float NoL = dot(n, uToSun);
        float wrap = max(0.0, (NoL + 0.45) / 1.45) - max(0.0, NoL);
        float back = pow(clamp(dot(V, -uToSun), 0.0, 1.0), 4.0) * 0.35;      // light shining through thin parts (ears, leaves)
        vec3 tintSS = mix(vec3(1.0), vec3(1.0, 0.38, 0.22), step(0.9, surf.scatter));
        direct += albedo * tintSS * sunC * (wrap + back) * surf.scatter * (1.0 - shadow * 0.85) * 0.8;
    }

    // Sky light: diffuse from the sky dome (plus a little bounce from the sunlit ground), and the sky's reflection.
    float NoV = max(dot(n, V), 1e-4);
    vec3 skyUp  = skyColor(vec3(0.0, 1.0, 0.0));
    vec3 skyHor = skyColor(normalize(vec3(n.x, 0.05, n.z) + vec3(1e-3)));
    vec3 irradiance = mix(skyHor, skyUp, n.y * 0.5 + 0.5) * 0.52;
    irradiance += vec3(0.020, 0.025, 0.040) * uNight;
    irradiance += albedo * sunC * 0.07 * clamp(0.5 - n.y * 0.5, 0.0, 1.0);
    vec3 f0 = mix(vec3(0.04), albedo, metal);
    vec2 ab = envBRDF(NoV, rough);
    vec3 specColor = f0 * ab.x + ab.y;
    vec3 R = reflect(-V, n);
    float specOcc = clamp(pow(NoV + occl, exp2(-16.0 * rough - 1.0)) - 1.0 + occl, 0.0, 1.0);
    vec3 ambient = albedo * (1.0 - metal) * (1.0 - specColor) * irradiance * occl
                 + skyReflection(R, rough, albedo * 0.5 + 0.1) * specColor * specOcc;

    vec3 color = direct + ambient + surf.emit;

    // Sunlight wobbling through the surface onto the sea floor.
    if (uWaterOn == 1 && vPos.y < uWaterLevel) {
        float depth = uWaterLevel - vPos.y;
        color += albedo * sunC * caustics(vPos.xz * 0.9, uTime) * max(n.y * 0.7 + 0.3, 0.0) * exp(-depth * 0.25) * sunVis * 0.55;
    }

    // Fog fades into the exact sky colour behind the terrain (or the water colour, under water).
    float dist = length(vPos - uCameraPos);
    color = applyFog(color, dist, normalize(vPos - uCameraPos));
    if (uHighlight.a > 0.0) {              // a soft rim glow marks the selected object
        float rim = pow(1.0 - max(dot(Nw, V), 0.0), 2.0);
        color += uHighlight.rgb * uHighlight.a * (0.10 + 0.95 * rim);
    }
    FragColor = vec4(color, 1.0);
}
)";
}

// ------------------------------------------------------------------ sky
inline std::string skyFS() {
    return std::string("#version 330 core\n") + kAtmosphere + kWaterLight + R"(
in vec2 vUv;
out vec4 FragColor;
uniform mat4  uInvViewProj;
uniform vec3  uCameraPos;
uniform float uStars;
uniform float uTime;

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

void main() {
    vec4 far = uInvViewProj * vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
    vec3 dir = normalize(far.xyz / far.w - uCameraPos);
    if (uUnder > 0.5) { FragColor = vec4(underColor(), 1.0); return; }
    vec3 col = skyColor(dir);
    float day = dayFactor();

    // Sun disc (HDR, so it blooms)
    float c = dot(dir, uToSun);
    col += sunLightColor() * smoothstep(0.99955, 0.99975, c) * 12.0;

    // Moon opposite the sun
    float mc = dot(dir, -uToSun);
    col += vec3(0.90, 0.93, 1.00) * smoothstep(0.9993, 0.9996, mc) * 2.5 * (1.0 - day);
    col += vec3(0.50, 0.60, 1.00) * pow(max(mc, 0.0), 200.0) * 0.15 * (1.0 - day);

    // Stars
    if (dir.y > 0.0) {
        vec3 d = dir * 220.0;
        vec3 cell = floor(d);
        float h = hash13(cell);
        if (h > 0.9965) {
            float s = smoothstep(0.32, 0.0, length(fract(d) - 0.5));
            float twinkle = 0.7 + 0.3 * sin(uTime * 3.0 + h * 400.0);
            col += vec3(0.85, 0.92, 1.0) * s * twinkle * (1.0 - day) * uStars * smoothstep(0.0, 0.15, dir.y) * 1.6;
        }
    }
    FragColor = vec4(col, 1.0);
}
)";
}

// ------------------------------------------------------------------ grass
// Each blade is one instance of a 7-vertex tapered strip generated from gl_VertexID, so
// there is no blade mesh to store. The vertex shader plants it, bends it in the wind and
// away from whatever is walking through it, and thins it out with distance.
inline const char* kGrassVS = R"(
#version 330 core
layout (location = 0) in vec3 aRoot;
layout (location = 1) in vec4 aData;      // seed, size, kind/255 (normalised), unused
layout (location = 2) in vec2 aNormal;    // ground normal x, z (normalised bytes)
uniform mat4  uViewProj;
uniform vec3  uCameraPos;
uniform float uTime, uGrassDist, uDensity, uHeight, uWindStrength, uWindSpeed;
uniform vec2  uWindDir;
uniform vec4  uInteract;                  // xyz = position of whatever parts the grass, w = radius
uniform int   uClearCount;                // patches without grass (building floors): 2 vec4 each
uniform vec4  uClear[96];
uniform vec3  uTint;
uniform float uTexScale;
uniform sampler2DArray uAlbedo;
out vec3 vColor; out float vHeightT; out vec3 vGroundN; out vec3 vWorld; out vec3 vShadowPos;

vec3 flowerColor(int k) {
    if (k == 1) return vec3(0.90, 0.90, 0.86);
    if (k == 2) return vec3(0.95, 0.72, 0.10);
    if (k == 3) return vec3(0.90, 0.28, 0.45);
    if (k == 4) return vec3(0.52, 0.32, 0.85);
    return vec3(0.95, 0.42, 0.12);
}

void main() {
    float seed = aData.x, size = aData.y;
    int kind = int(aData.z * 255.0 + 0.5);
    bool flower = kind > 0;

    float d = distance(aRoot, uCameraPos);
    float vis = step(seed, uDensity) * (1.0 - smoothstep(0.45 * uGrassDist, uGrassDist, d));
    for (int i = 0; i < uClearCount; ++i) {
        vec4 a = uClear[i * 2], b = uClear[i * 2 + 1];
        if (aRoot.x > a.x && aRoot.z > a.y && aRoot.x < a.z && aRoot.z < a.w && aRoot.y > b.x && aRoot.y < b.y) vis = 0.0;
    }
    if (vis < 0.02) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vColor = vec3(0.0); vHeightT = 0.0; vGroundN = vec3(0, 1, 0); vWorld = aRoot; vShadowPos = aRoot; return; }

    int row = gl_VertexID >> 1;                       // 0..3 (3 = the tip)
    float side = ((gl_VertexID & 1) == 0) ? -1.0 : 1.0;
    float t = float(row) / 3.0;

    float H = mix(0.45, 1.05, size) * uHeight * vis * (flower ? 0.7 : 1.0);
    float baseW = flower ? 0.012 : 0.024;
    float w = baseW * (1.0 - t * t * 0.9) * (row == 3 ? 0.0 : 1.0);
    if (flower && row == 2) w = 0.055;                 // the flower head
    if (flower && row == 3) w = 0.0;

    float a = seed * 6.2831 * 7.0;
    vec3 along = vec3(cos(a), 0.0, sin(a));            // blade width direction
    vec2 lean = vec2(-sin(a), cos(a)) * (0.10 + 0.25 * fract(seed * 13.0));

    // Wind: slow travelling gusts plus per-blade flutter.
    float gust = 0.5 + 0.5 * sin(dot(aRoot.xz, uWindDir) * 0.11 - uTime * uWindSpeed * 1.2 + sin(aRoot.x * 0.05) * 2.0);
    float flutter = sin(uTime * uWindSpeed * 3.3 + aRoot.x * 1.9 + aRoot.z * 2.3 + seed * 40.0);
    vec2 sway = uWindDir * (0.25 + 0.75 * gust) * uWindStrength + vec2(-uWindDir.y, uWindDir.x) * flutter * 0.12 * uWindStrength;

    // Parting around the player (or anything else the game passes in).
    vec2 away = aRoot.xz - uInteract.xz;
    float ad = length(away);
    float push = (1.0 - smoothstep(0.0, uInteract.w, ad)) * (1.0 - smoothstep(1.2, 2.2, abs(aRoot.y - uInteract.y)));
    vec2 pushDir = away / max(ad, 0.001);

    float bend = t * t;                                  // blades bend mostly near the tip
    vec2 off = lean * t * H * 0.6 + sway * bend * H * 0.5 + pushDir * push * bend * H * 1.6;
    float len = length(off);
    float up = sqrt(max(H * H * t * t * (1.0 - 0.5 * push) - len * len * 0.5, 0.0));
    vec3 pos = aRoot + along * (side * w) + vec3(off.x, up, off.y);

    // Colour: the ground texture's average colour, so blades melt into the terrain.
    vec3 ground = textureLod(uAlbedo, vec3(aRoot.xz * uTexScale, 0.0), 5.0).rgb * uTint;
    float tone = 0.78 + 0.45 * fract(seed * 91.0);
    vec3 tip = mix(ground * 1.12 + vec3(0.025, 0.035, 0.0), ground * vec3(1.25, 1.12, 0.78), step(0.86, fract(seed * 37.0)) * 0.7);
    vec3 col = mix(ground * 0.45, tip, t) * tone;                       // dark roots, lighter tips, a few dry yellowed blades
    if (flower) col = mix(col, flowerColor(kind) * 0.9, smoothstep(0.4, 0.7, t));

    vColor = col; vHeightT = t;
    vGroundN = normalize(vec3(aNormal.x, sqrt(max(1.0 - dot(aNormal, aNormal), 0.04)), aNormal.y));
    vWorld = pos;
    vShadowPos = mix(aRoot + vec3(0.0, 0.15, 0.0), pos, 0.5);           // shadow is looked up halfway up the blade
    gl_Position = uViewProj * vec4(pos, 1.0);
}
)";

inline std::string grassFS() {
    return std::string("#version 330 core\n") + kAtmosphere + kWaterLight + kShadows + R"(
in vec3 vColor; in float vHeightT; in vec3 vGroundN; in vec3 vWorld; in vec3 vShadowPos;
out vec4 FragColor;
uniform vec3 uCameraPos;
uniform vec3 uShadowLightDir;

void main() {
    vec3 n = normalize(mix(vGroundN, vec3(0.0, 1.0, 0.0), 0.35));
    vec3 albedo = vColor;
    vec3 sunC = sunLightColor(), moonC = moonLightColor();
    float shadow = shadowAt(vShadowPos, vGroundN, uShadowLightDir, uCameraPos);
    bool sunUp = uToSun.y > 0.0;
    float ao = mix(0.35, 1.0, smoothstep(0.0, 0.7, vHeightT));

    // Wrapped lighting: blades are thin, so light shines through them from behind.
    float wrapSun  = clamp(dot(n,  uToSun) * 0.5 + 0.5, 0.0, 1.0);
    float wrapMoon = clamp(dot(n, -uToSun) * 0.5 + 0.5, 0.0, 1.0);
    vec3 direct = albedo * ao * (sunC * wrapSun * wrapSun * (sunUp ? 1.0 - shadow : 1.0) +
                                 moonC * wrapMoon * wrapMoon * (sunUp ? 1.0 : 1.0 - shadow));
    vec3 skyUp  = skyColor(vec3(0.0, 1.0, 0.0));
    vec3 skyHor = skyColor(normalize(vec3(n.x, 0.05, n.z) + vec3(1e-3)));
    vec3 ambient = albedo * mix(skyHor, skyUp, n.y * 0.5 + 0.5) * ao * 0.5;
    ambient += albedo * vec3(0.020, 0.025, 0.040) * uNight * ao;

    vec3 color = applyFog(direct + ambient, length(vWorld - uCameraPos), normalize(vWorld - uCameraPos));
    FragColor = vec4(color, 1.0);
}
)";
}

// ------------------------------------------------------------------ water
// The sea is an analytic plane: every pixel intersects its view ray with the plane
// y = water level, so there is no mesh, no LOD and no edge to the ocean. The result is
// blended over the already-rendered scene (terrain + sky), which is also what we
// refract and read the depth of for colour, foam and the soft shoreline.
inline std::string waterFS() {
    return std::string("#version 330 core\n") + kAtmosphere + kWaterLight + R"(
in vec2 vUv;
out vec4 FragColor;
uniform mat4  uInvViewProj;
uniform mat4  uViewProj;
uniform vec3  uCameraPos;
uniform float uWaterLevel, uTime, uWaveStrength, uWaveSpeed, uRadius, uFoam;
uniform vec3  uShallow;
uniform sampler2D uSceneColor;
uniform sampler2D uSceneDepth;

float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1, 0)), f.x), mix(hash21(i + vec2(0, 1)), hash21(i + vec2(1, 1)), f.x), f.y);
}

// Sum of travelling waves (deep-water dispersion), fading out the small ones with
// distance so the far sea doesn't shimmer.
vec3 waveNormal(vec2 p, float dist) {
    vec2 grad = vec2(0.0);
    float pix = dist * 0.003;
    for (int i = 0; i < 7; ++i) {
        float len = 30.0 * pow(0.6, float(i));
        float k = 6.28318 / len;
        float a = float(i) * 2.399 + 0.5;
        vec2 d = vec2(cos(a), sin(a));
        float amp = len * 0.011 * uWaveStrength;
        float fade = smoothstep(pix * 2.0, pix * 7.0, len);
        float ph = dot(d, p) * k + sqrt(9.81 * k) * uTime * uWaveSpeed;
        grad += d * amp * k * cos(ph) * fade;
    }
    return normalize(vec3(-grad.x, 1.0, -grad.y));
}

vec3 worldFromDepth(vec2 uv, float d) {
    vec4 w = uInvViewProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return w.xyz / w.w;
}

void main() {
    vec4 far = uInvViewProj * vec4(vUv * 2.0 - 1.0, 1.0, 1.0);
    vec3 dir = normalize(far.xyz / far.w - uCameraPos);
    if (abs(dir.y) < 1e-4) discard;
    float t = (uWaterLevel - uCameraPos.y) / dir.y;
    if (t <= 0.0 || t > uRadius) discard;
    vec3 P = uCameraPos + dir * t;
    vec4 clip = uViewProj * vec4(P, 1.0);
    gl_FragDepth = clip.z / clip.w * 0.5 + 0.5;

    bool under = uUnder > 0.5;
    vec3 N = waveNormal(P.xz, t);
    if (under) N = -N;
    vec3 V = -dir;
    vec3 col; float alpha = 1.0;

    if (!under) {
        float ndv = clamp(dot(N, V), 0.0, 1.0);
        float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
        vec3 refl = reflect(dir, N);
        refl.y = max(refl.y, 0.015);
        vec3 skyRefl = skyColor(normalize(refl));

        // What is behind the surface: sea floor, or open sea where no terrain is loaded.
        float sd = texelFetch(uSceneDepth, ivec2(gl_FragCoord.xy), 0).r;
        bool hasFloor = sd < 1.0;
        vec3 T = worldFromDepth(vUv, sd);
        float floorDepth = hasFloor ? max(uWaterLevel - T.y, 0.0) : 60.0;
        float thick = hasFloor ? distance(T, P) : 60.0;

        vec2 uv2 = vUv + N.xz * 0.05 * clamp(thick * 0.5, 0.0, 1.0) / (1.0 + t * 0.02);
        float d2 = texture(uSceneDepth, uv2).r;
        if (d2 < 1.0 && worldFromDepth(uv2, d2).y > uWaterLevel) uv2 = vUv;     // don't smear in terrain in front of the water
        vec3 behind = texture(uSceneColor, uv2).rgb;

        vec3 light = waterBodyLight();
        vec3 transmit = exp(-thick * vec3(0.45, 0.12, 0.06) * uWaterAbsorb);
        float body = 1.0 - exp(-thick * 0.25 * uWaterAbsorb);
        vec3 bodyCol = mix(uShallow, uWaterDeep, clamp(body * 1.4, 0.0, 1.0)) * light;
        col = behind * transmit + bodyCol * body;
        col = mix(col, skyRefl, fres);

        // Sun and moon glints (HDR, so they bloom).
        vec3 H = normalize(uToSun + V);
        float nh = max(dot(N, H), 0.0);
        col += sunLightColor() * (pow(nh, 1200.0) * 14.0 + pow(nh, 90.0) * 0.10);
        vec3 Hm = normalize(-uToSun + V);
        col += moonLightColor() * pow(max(dot(N, Hm), 0.0), 600.0) * 60.0;

        // Foam along the shore and on steep wave crests.
        float n1 = vnoise(P.xz * 1.7 + uTime * 0.25), n2 = vnoise(P.xz * 4.3 - uTime * 0.18);
        float foamN = n1 * 0.6 + n2 * 0.4;
        float shore = hasFloor ? 1.0 - smoothstep(0.0, 0.40 + 0.18 * sin(uTime * 1.3 + P.x * 0.4 + P.z * 0.3), floorDepth + (foamN - 0.5) * 0.5) : 0.0;
        float crest = smoothstep(0.04, 0.09, 1.0 - N.y) * foamN;
        float foam = clamp(shore * 0.85 + crest * 0.5, 0.0, 1.0) * (0.35 + 0.65 * foamN) * uFoam;
        vec3 foamLit = skyColor(vec3(0.0, 1.0, 0.0)) * 0.9 + sunLightColor() * 0.55 * max(dot(N, uToSun), 0.0) + vec3(0.01);
        col = mix(col, foamLit * 0.92, foam);

        alpha = hasFloor ? max(smoothstep(0.0, 0.12, floorDepth), foam) : 1.0;
        alpha *= 1.0 - smoothstep(uRadius * 0.78, uRadius, t);
        col = applyFog(col, t, dir);
    } else {
        // Seen from below: a bright window onto the sky, a mirror outside it.
        vec3 uc = underColor();
        vec3 rd = refract(dir, N, 1.33);
        if (dot(rd, rd) < 1e-4) col = uc * 1.4;
        else col = skyColor(normalize(vec3(rd.x, max(rd.y, 0.02), rd.z))) * 0.85 * exp(-vec3(0.45, 0.12, 0.06) * uWaterAbsorb * 0.8);
        col = mix(col, uc, 1.0 - exp(-t * 0.03 * uWaterAbsorb));
    }
    FragColor = vec4(col, alpha);
}
)";
}

// ------------------------------------------------------------------ shadow depth
inline const std::string kDepthVS = std::string(R"(
#version 330 core
layout (location = 0) in vec3 aPos;
)") + kSkinVS + R"(
uniform mat4 uLightSpace;
uniform mat4 uModel;
out vec2 vUv;
void main() {
    vUv = aExtra.xy;
    vec4 world = uModel * (skinMatrix() * vec4(morphPos(aPos), 1.0));
    world.xyz += swayOffset(world.xyz);
    gl_Position = uLightSpace * world;
}
)";
inline const char* kDepthFS = R"(
#version 330 core
in vec2 vUv;
uniform int uCards;             // hair cards: only their strands cast shadows
uniform sampler2D uHairMap;
void main() { if (uCards == 1 && texture(uHairMap, vUv).a < 0.5) discard; }
)";

// ------------------------------------------------------------------ bloom
inline const char* kBloomDownFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uSrc;
uniform vec2  uTexel;       // texel size of the source
uniform int   uFirst;       // first pass applies the brightness threshold
uniform float uThreshold;
void main() {
    vec3 c = texture(uSrc, vUv + uTexel * vec2(-1.0, -1.0)).rgb
           + texture(uSrc, vUv + uTexel * vec2( 1.0, -1.0)).rgb
           + texture(uSrc, vUv + uTexel * vec2(-1.0,  1.0)).rgb
           + texture(uSrc, vUv + uTexel * vec2( 1.0,  1.0)).rgb;
    c = c * 0.125 + texture(uSrc, vUv).rgb * 0.5;
    if (uFirst == 1) {
        c = min(c, vec3(64.0));                             // no fireflies
        float b = max(c.r, max(c.g, c.b));
        float soft = clamp(b - uThreshold + 0.5, 0.0, 1.0);
        soft = soft * soft * 0.5;
        c *= max(soft, b - uThreshold) / max(b, 1e-4);
    }
    FragColor = vec4(c, 1.0);
}
)";

inline const char* kBloomUpFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uSrc;
uniform vec2 uTexel;
void main() {    // 3x3 tent filter; blended additively onto the larger mip
    vec3 c = texture(uSrc, vUv).rgb * 4.0;
    c += (texture(uSrc, vUv + vec2(uTexel.x, 0)).rgb + texture(uSrc, vUv - vec2(uTexel.x, 0)).rgb +
          texture(uSrc, vUv + vec2(0, uTexel.y)).rgb + texture(uSrc, vUv - vec2(0, uTexel.y)).rgb) * 2.0;
    c += texture(uSrc, vUv + uTexel).rgb + texture(uSrc, vUv - uTexel).rgb +
         texture(uSrc, vUv + vec2(uTexel.x, -uTexel.y)).rgb + texture(uSrc, vUv + vec2(-uTexel.x, uTexel.y)).rgb;
    FragColor = vec4(c / 16.0, 1.0);
}
)";

// ------------------------------------------------------------------ ambient occlusion
// From the depth prepass alone: each pixel's position is rebuilt, its normal taken from its neighbours, and a few
// points in the half-sphere above it are tested against the depth buffer. Done at half resolution, then blurred
// without bleeding across edges.
inline const char* kSsaoFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uDepth;
uniform mat4 uProj, uInvProj;
uniform vec2 uTexel;            // one pixel of the depth buffer
uniform float uRadius;          // metres
uniform float uStrength;

vec3 viewPos(vec2 uv) {
    float d = texture(uDepth, uv).r;
    vec4 p = uInvProj * vec4(uv * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

void main() {
    float d = texture(uDepth, vUv).r;
    if (d >= 1.0) { FragColor = vec4(1.0); return; }               // the sky
    vec3 P = viewPos(vUv);
    // the normal from whichever neighbours are on the same surface (smaller depth jump)
    vec3 r = viewPos(vUv + vec2(uTexel.x, 0.0)), l = viewPos(vUv - vec2(uTexel.x, 0.0));
    vec3 t = viewPos(vUv + vec2(0.0, uTexel.y)), b = viewPos(vUv - vec2(0.0, uTexel.y));
    vec3 dx = abs(r.z - P.z) < abs(P.z - l.z) ? r - P : P - l;
    vec3 dy = abs(t.z - P.z) < abs(P.z - b.z) ? t - P : P - b;
    vec3 N = normalize(cross(dx, dy));
    float a = ign(gl_FragCoord.xy) * 6.2831853;
    vec3 rnd = vec3(cos(a), sin(a), 0.0);
    vec3 T = normalize(rnd - N * dot(rnd, N));
    vec3 B = cross(N, T);
    float radius = uRadius * clamp(-P.z / 12.0 + 0.6, 0.6, 2.5);  // a little wider far away, so distant shapes still read
    float occ = 0.0;
    const int K = 12;
    for (int i = 0; i < K; ++i) {
        float fi = float(i) + 0.5;
        float r2 = fi / float(K);
        float phi = fi * 2.39996323;                                // golden angle
        vec3 h = vec3(cos(phi) * sqrt(1.0 - r2 * 0.9), sin(phi) * sqrt(1.0 - r2 * 0.9), sqrt(r2 * 0.9 + 0.1));
        vec3 S = P + (T * h.x + B * h.y + N * h.z) * radius * mix(0.2, 1.0, r2 * r2);
        vec4 c = uProj * vec4(S, 1.0);
        vec2 uv = c.xy / c.w * 0.5 + 0.5;
        if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) continue;
        float sceneZ = viewPos(uv).z;
        float range = smoothstep(0.0, 1.0, radius / max(abs(P.z - sceneZ), 1e-3));
        // the depth buffer's own precision falls off with distance: a fixed bias makes bands of false shadow far away
        float bias = 0.02 + 0.0035 * -P.z;
        occ += (sceneZ >= S.z + bias ? 1.0 : 0.0) * range;
    }
    float ao = 1.0 - occ / float(K) * uStrength;
    FragColor = vec4(clamp(ao, 0.0, 1.0), d, 0.0, 1.0);             // depth in g, for the blur
}
)";

inline const char* kSsaoBlurFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uSrc;
uniform vec2 uStep;              // one texel along the blur direction
void main() {
    vec2 c = texture(uSrc, vUv).rg;
    float sum = c.r, w = 1.0;
    for (int i = -3; i <= 3; ++i) {
        if (i == 0) continue;
        vec2 s = texture(uSrc, vUv + uStep * float(i)).rg;
        float k = exp(-abs(s.g - c.g) * 4000.0) * (1.0 - abs(float(i)) / 4.0);   // same surface only
        sum += s.r * k; w += k;
    }
    FragColor = vec4(sum / w, c.g, 0.0, 1.0);
}
)";

// ------------------------------------------------------------------ composite
inline const char* kCompositeFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uScene;
uniform sampler2D uBloom;
uniform int   uBloomOn;
uniform float uBloomIntensity;
uniform float uExposure;
uniform float uContrast;
uniform float uSaturation;
uniform float uTemperature;
uniform float uVignette;

vec3 aces(vec3 x) {   // Narkowicz ACES filmic fit
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec3 c = texture(uScene, vUv).rgb;
    if (uBloomOn == 1) c += texture(uBloom, vUv).rgb * uBloomIntensity;
    c *= uExposure;
    c *= vec3(1.0 + uTemperature * 0.10, 1.0, 1.0 - uTemperature * 0.10);   // white balance
    c = aces(c);
    c = pow(c, vec3(1.0 / 2.2));                                            // to display gamma

    float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
    c = mix(vec3(l), c, uSaturation);
    c = clamp((c - 0.5) * uContrast + 0.5, 0.0, 1.0);

    float v = smoothstep(0.95, 0.30, length(vUv - 0.5) * 1.15);
    c *= mix(1.0, v, uVignette);

    FragColor = vec4(c, dot(c, vec3(0.299, 0.587, 0.114)));                // luma in alpha for FXAA
}
)";

// ------------------------------------------------------------------ FXAA
inline const char* kFxaaFS = R"(
#version 330 core
in vec2 vUv;
out vec4 FragColor;
uniform sampler2D uTex;
uniform vec2 uTexel;
#define SPAN_MAX   8.0
#define REDUCE_MUL (1.0 / 8.0)
#define REDUCE_MIN (1.0 / 128.0)
void main() {
    float lNW = texture(uTex, vUv + vec2(-1.0, -1.0) * uTexel).a;
    float lNE = texture(uTex, vUv + vec2( 1.0, -1.0) * uTexel).a;
    float lSW = texture(uTex, vUv + vec2(-1.0,  1.0) * uTexel).a;
    float lSE = texture(uTex, vUv + vec2( 1.0,  1.0) * uTexel).a;
    vec4  m   = texture(uTex, vUv);
    float lM  = m.a;
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));

    vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
    float reduce = max((lNW + lNE + lSW + lSE) * 0.25 * REDUCE_MUL, REDUCE_MIN);
    float rcpMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + reduce);
    dir = clamp(dir * rcpMin, vec2(-SPAN_MAX), vec2(SPAN_MAX)) * uTexel;

    vec3 a = 0.5 * (texture(uTex, vUv + dir * (1.0 / 3.0 - 0.5)).rgb + texture(uTex, vUv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(uTex, vUv + dir * -0.5).rgb + texture(uTex, vUv + dir * 0.5).rgb);
    float lB = dot(b, vec3(0.299, 0.587, 0.114));
    FragColor = vec4((lB < lMin || lB > lMax) ? a : b, 1.0);
}
)";

} // namespace px::shaders
