#pragma once
// Texture packs: your own photos (or anything from Poly Haven, ambientCG and the like) in place of the built-in
// materials. A pack is a folder under textures/ with one folder per material, named like the material:
//
//   textures/
//     My Pack/
//       grass/        Grass_Color.jpg   Grass_NormalGL.png   Grass_Roughness.jpg   Grass_AO.jpg   Grass_Height.png
//       brick/        bricks_diff_4k.jpg   bricks_nor_gl_4k.png   bricks_arm_4k.png
//       cobblestone/  ...
//
// Which picture is which comes from its file name (colour / albedo / basecolor / diff, normal / nor_gl / nor_dx,
// rough / gloss, height / disp, ao / occlusion, metal, and "arm" = AO + roughness + metalness in one). Only the colour
// is needed: missing normals and occlusion are worked out from the height (or from the colour's brightness), and any
// material without a folder keeps its built-in texture. Pictures should tile and be square; any size works (they are
// scaled to the Texture detail setting).
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "render/MaterialTextures.h"

namespace px {

struct TexturePackLayer {
    std::string albedo, normal, rough, gloss, height, ao, metal, arm;   // full file paths; empty = not in the pack
    bool normalDirectX = false;                                         // green channel points down (nor_dx)
    bool present() const { return !albedo.empty(); }
};

struct TexturePack {
    std::string name;                         // the folder's name
    std::string folder;                       // its full path
    std::vector<TexturePackLayer> layers;     // one per texture layer (world/Materials.h kTextureImages)
    std::vector<std::string> unknownFolders;  // folders that are not a material name (shown so a typo is easy to spot)
    std::string key;                          // changes whenever a file in the pack changes (for the disk cache)

    int count() const { int n = 0; for (const TexturePackLayer& l : layers) n += l.present() ? 1 : 0; return n; }
};

// The texture-pack root, next to config/ and worlds/.
std::string texturePackRoot();
// The packs found there (folder names, sorted).
std::vector<std::string> listTexturePacks(const std::string& root = texturePackRoot());
// Looks through one pack folder. Never reads the pictures themselves (that happens on the texture thread).
TexturePack scanTexturePack(const std::string& folder);

// Which texture layer a folder name means ("bricks" and "brick" both mean brick), or -1.
int textureLayerFromName(const std::string& name);

// Decodes one material's pictures into a full image at `size` pixels. Missing maps are derived. False (with a reason)
// when the colour picture cannot be read; the caller then falls back to the built-in texture.
bool loadPackLayer(const TexturePackLayer& files, int layer, int size, MaterialImage& out, std::string* error = nullptr);

} // namespace px
