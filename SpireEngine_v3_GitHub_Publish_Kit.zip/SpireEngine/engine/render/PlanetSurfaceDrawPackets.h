#pragma once
// CPU render handoff for streaming spherical surface meshes.
// Mesh vertices are already float values around the double-precision patch
// origin. This computes the ONLY per-draw translation by subtracting camera
// and planet centre in sector/local precision *before* float downcast.
//
// The GPU must use a rotation-only camera view with these translations;
// applying the legacy world-space camera translation a second time is wrong.
// No OpenGL calls occur here. GPU ownership/uploader and LOD fallback are
// separate follow-up work.
#include "world/PlanetCoordinates.h"
#include "world/PlanetSurfaceStreamer.h"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <memory>
#include <unordered_set>
#include <vector>

namespace px {

struct PlanetSurfaceDrawPacket {
    CubeTileCoord tile;
    glm::vec3 cameraRelativeOrigin{0.0f};
    std::shared_ptr<const PlanetSurfacePatch> mesh;
};

// maxOriginDistanceMeters is the maximum distance permitted for *patch origins*.
// Final visibility tests must consider patch extents and frustum on the GPU.
// A conservative 8 km limit avoids excessive local-position float error;
// use several LOD levels for orbital views rather than raising this blindly.
inline bool makePlanetSurfaceDrawPackets(
        const PlanetSurfaceStreamer& streamer,
        const std::vector<CubeTileCoord>& selected,
        const WorldPosition& planetCenter,
        const WorldPosition& camera,
        double maxOriginDistanceMeters,
        std::vector<PlanetSurfaceDrawPacket>& out) {
    if (!planetCenter.isCanonical() || !camera.isCanonical() ||
        !std::isfinite(maxOriginDistanceMeters) || maxOriginDistanceMeters <= 0.0 ||
        maxOriginDistanceMeters > 1.0e8 || selected.size() > 4096) return false;
    // Reject invalid and duplicate selection without mutating output.
    std::unordered_set<CubeTileCoord, CubeTileHash> seen;
    seen.reserve(selected.size());
    for (const auto& tile : selected)
        if (validateTile(tile) != TileError::Ok || !seen.insert(tile).second) return false;

    // Long double protects the sector subtraction even near int64 limits.
    // Never form huge absolute glm::dvec3 positions before subtracting.
    const glm::dvec3 centerToCamera(
        static_cast<double>(static_cast<long double>(planetCenter.sector.x) - camera.sector.x) * WORLD_SECTOR_SIZE +
            (planetCenter.local.x - camera.local.x),
        static_cast<double>(static_cast<long double>(planetCenter.sector.y) - camera.sector.y) * WORLD_SECTOR_SIZE +
            (planetCenter.local.y - camera.local.y),
        static_cast<double>(static_cast<long double>(planetCenter.sector.z) - camera.sector.z) * WORLD_SECTOR_SIZE +
            (planetCenter.local.z - camera.local.z));
    std::vector<PlanetSurfaceDrawPacket> result;
    result.reserve(selected.size());
    for (const auto& tile : selected) {
        auto patch = streamer.findReady(tile);
        if (!patch) continue; // not generated yet; renderer needs LOD fallback
        if (!(patch->tile == tile)) return false;
        const glm::dvec3 offset = centerToCamera + patch->originMeters;
        if (!std::isfinite(offset.x) || !std::isfinite(offset.y) ||
            !std::isfinite(offset.z)) return false;
        if (glm::length(offset) > maxOriginDistanceMeters) continue;
        result.push_back({tile, glm::vec3(offset), std::move(patch)});
    }
    out = std::move(result);
    return true;
}

} // namespace px
