#include "Shader.h"
#include <iostream>
#include <vector>

namespace px {

static GLuint compileStage(GLenum type, const char* src, const char* name) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetShaderiv(s, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(size_t(len) + 1);
        glGetShaderInfoLog(s, len, nullptr, log.data());
        std::cerr << "[Shader] " << name << (type == GL_VERTEX_SHADER ? " (vertex)" : " (fragment)") << " failed:\n" << log.data() << "\n";
    }
    return s;
}

bool Shader::build(const char* vs, const char* fs, const char* name) {
    GLuint v = compileStage(GL_VERTEX_SHADER, vs, name);
    GLuint f = compileStage(GL_FRAGMENT_SHADER, fs, name);
    program = glCreateProgram();
    glAttachShader(program, v);
    glAttachShader(program, f);
    glLinkProgram(program);
    glDeleteShader(v);
    glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetProgramiv(program, GL_INFO_LOG_LENGTH, &len);
        std::vector<char> log(size_t(len) + 1);
        glGetProgramInfoLog(program, len, nullptr, log.data());
        std::cerr << "[Shader] " << name << " link failed:\n" << log.data() << "\n";
        return false;
    }
    return true;
}

void Shader::destroy() {
    if (program) glDeleteProgram(program);
    program = 0;
}

} // namespace px
