#pragma once
// Builds the engine's material textures procedurally, so there are no image files to ship or lose, at any size
// (512 up to 4096). Every material gets a full physically based set:
//   * albedo:  sRGB colour, with its height in alpha (used to blend materials so stones poke through grass)
//   * normal:  tangent-space normal (xyz) from the height, scaled to how deep the surface really is
//   * surface: roughness, ambient occlusion (crevices), metalness
// All maps tile seamlessly. A texture pack (render/TexturePack.*) can replace any material with your own images.
#include <atomic>
#include <cstdint>
#include <string>
#include <vector>

namespace px {

struct MaterialImage {
    int size = 0;
    std::vector<std::uint8_t> albedo;   // RGBA8: sRGB colour + height
    std::vector<std::uint8_t> normal;   // RGBA8: tangent-space normal (x, y, z), a unused
    std::vector<std::uint8_t> surface;  // RGBA8: r = ambient occlusion, g = metalness, b unused, a = roughness
};

// One image per texture layer (see world/Materials.h), generated in parallel on `threads` threads (0 = all cores).
std::vector<MaterialImage> generateMaterialImages(int size, int threads = 0, const std::atomic<bool>* cancel = nullptr);
// Just one layer (for tests, previews and texture-pack fallbacks).
MaterialImage generateMaterialImage(int layer, int size, const std::atomic<bool>* cancel = nullptr);
// The texture layers' names, as a texture pack's folders are called ("grass", "cobblestone"...).
const char* textureLayerName(int layer);
// How many metres of the world one repeat of the layer covers at the default texture size (bricks are brick-sized).
float textureLayerMetres(int layer);

// Fills in what can be worked out from the others: normals from the height (strength = how deep the relief is,
// as a fraction of the texture's width) and ambient occlusion from the height's hollows.
void deriveNormalFromHeight(MaterialImage& im, float strength);
void deriveOcclusionFromHeight(MaterialImage& im, float strength);
// The same image at another size (bilinear, wrapping at the edges so it still tiles; normals renormalised).
MaterialImage resizeMaterialImage(const MaterialImage& im, int size);

} // namespace px
