#include "render/TextureSet.h"
#include "world/Materials.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <thread>

#define STB_DXT_IMPLEMENTATION
#include "stb/stb_dxt.h"

namespace px {

namespace {

// ---------------------------------------------------------------- colour maths
const float* srgbToLinearTable() {
    static float t[256];
    static bool done = [] {
        for (int i = 0; i < 256; ++i) {
            const float c = float(i) / 255.0f;
            t[i] = c <= 0.04045f ? c / 12.92f : std::pow((c + 0.055f) / 1.055f, 2.4f);
        }
        return true;
    }();
    (void)done;
    return t;
}
std::uint8_t linearToSrgb(float l) {
    l = std::clamp(l, 0.0f, 1.0f);
    const float c = l <= 0.0031308f ? l * 12.92f : 1.055f * std::pow(l, 1.0f / 2.4f) - 0.055f;
    return std::uint8_t(std::lround(c * 255.0f));
}

enum class Kind { Albedo, Normal, Surface };

// One mip step: n x n RGBA8 -> n/2 x n/2, done the right way for the kind of map.
std::vector<std::uint8_t> halve(const std::vector<std::uint8_t>& src, int n, Kind kind) {
    const int h = n / 2;
    std::vector<std::uint8_t> dst(size_t(h) * h * 4);
    const float* lin = srgbToLinearTable();
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < h; ++x) {
            const std::uint8_t* p[4] = { &src[(size_t(2 * y) * n + 2 * x) * 4], &src[(size_t(2 * y) * n + 2 * x + 1) * 4],
                                         &src[(size_t(2 * y + 1) * n + 2 * x) * 4], &src[(size_t(2 * y + 1) * n + 2 * x + 1) * 4] };
            std::uint8_t* d = &dst[(size_t(y) * h + x) * 4];
            if (kind == Kind::Albedo) {                       // colour averaged as light, height as a number
                for (int c = 0; c < 3; ++c) d[c] = linearToSrgb((lin[p[0][c]] + lin[p[1][c]] + lin[p[2][c]] + lin[p[3][c]]) * 0.25f);
                d[3] = std::uint8_t((p[0][3] + p[1][3] + p[2][3] + p[3][3] + 2) / 4);
            } else if (kind == Kind::Normal) {                // directions averaged, then made unit length again
                float v[3] = { 0, 0, 0 };
                for (int k = 0; k < 4; ++k) for (int c = 0; c < 3; ++c) v[c] += float(p[k][c]) / 127.5f - 1.0f;
                const float len = std::max(1e-5f, std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]));
                for (int c = 0; c < 3; ++c) d[c] = std::uint8_t(std::lround((v[c] / len * 0.5f + 0.5f) * 255.0f));
                d[3] = 255;
            } else {
                for (int c = 0; c < 4; ++c) d[c] = std::uint8_t((p[0][c] + p[1][c] + p[2][c] + p[3][c] + 2) / 4);
            }
        }
    return dst;
}

// One level of one map, packed: BC3 (colour + alpha) or BC5 (two channels), or left plain.
std::vector<std::uint8_t> pack(const std::vector<std::uint8_t>& rgba, int n, Kind kind, bool compress) {
    if (!compress) {
        if (kind != Kind::Normal) return rgba;
        std::vector<std::uint8_t> rg(size_t(n) * n * 2);                  // RG8: the shader rebuilds z
        for (size_t i = 0, j = 0; i < rgba.size(); i += 4, j += 2) { rg[j] = rgba[i]; rg[j + 1] = rgba[i + 1]; }
        return rg;
    }
    const int blocks = n / 4;
    std::vector<std::uint8_t> out(size_t(blocks) * blocks * 16);           // BC3 and BC5 are both 16 bytes per 4x4 block
    std::uint8_t block[64], rg[32];
    for (int by = 0; by < blocks; ++by)
        for (int bx = 0; bx < blocks; ++bx) {
            for (int y = 0; y < 4; ++y)
                for (int x = 0; x < 4; ++x) {
                    const std::uint8_t* p = &rgba[(size_t(by * 4 + y) * n + size_t(bx * 4 + x)) * 4];
                    std::memcpy(&block[(y * 4 + x) * 4], p, 4);
                    rg[(y * 4 + x) * 2] = p[0]; rg[(y * 4 + x) * 2 + 1] = p[1];
                }
            std::uint8_t* d = &out[(size_t(by) * blocks + bx) * 16];
            if (kind == Kind::Normal) stb_compress_bc5_block(d, rg);
            else stb_compress_dxt_block(d, block, 1, STB_DXT_HIGHQUAL);
        }
    return out;
}

struct PackedLayer { std::vector<std::vector<std::uint8_t>> albedo, normal, surface; };

PackedLayer packLayer(const MaterialImage& im, bool compress) {
    PackedLayer out;
    auto chain = [&](std::vector<std::uint8_t> level, int n, Kind kind, std::vector<std::vector<std::uint8_t>>& dst) {
        while (true) {
            dst.push_back(pack(level, n, kind, compress));
            if (n <= 4) break;                                            // compressed blocks are 4 x 4: stop there
            level = halve(level, n, kind);
            n /= 2;
        }
    };
    chain(im.albedo, im.size, Kind::Albedo, out.albedo);
    chain(im.normal, im.size, Kind::Normal, out.normal);
    // roughness and occlusion change slowly: half the resolution is plenty
    chain(im.size >= 8 ? halve(im.surface, im.size, Kind::Surface) : im.surface, std::max(4, im.size / 2), Kind::Surface, out.surface);
    return out;
}

template <class F> void parallelFor(int count, F&& f) {
    const int n = std::clamp(int(std::thread::hardware_concurrency()), 1, 64);
    std::atomic<int> next{ 0 };
    std::vector<std::thread> pool;
    for (int t = 0; t < n; ++t) pool.emplace_back([&] { for (int i = next++; i < count; i = next++) f(i); });
    for (auto& t : pool) t.join();
}

} // namespace

std::vector<std::uint8_t> makeMaterialPreview(const MaterialImage& im, const float tint[3], int previewSize) {
    std::vector<std::uint8_t> small(size_t(previewSize) * previewSize * 4, 255);
    if (im.size <= 0) return small;
    const int step = std::max(1, im.size / previewSize);
    float gain[3];
    for (int c = 0; c < 3; ++c) gain[c] = std::pow(std::clamp(tint[c], 0.0f, 1.0f), 1.0f / 2.2f);   // the shader tints in linear light
    for (int y = 0; y < previewSize; ++y)
        for (int x = 0; x < previewSize; ++x)
            for (int c = 0; c < 3; ++c) {
                int sum = 0, cnt = 0;
                for (int j = 0; j < step; ++j)
                    for (int i = 0; i < step; ++i) {
                        const int sx = std::min(im.size - 1, x * step + i), sy = std::min(im.size - 1, y * step + j);
                        sum += im.albedo[(size_t(sy) * im.size + sx) * 4 + c]; ++cnt;
                    }
                small[(size_t(y) * previewSize + x) * 4 + c] = std::uint8_t(std::clamp(float(sum) / float(cnt) * gain[c], 0.0f, 255.0f));
            }
    return small;
}

TextureSet packTextureSet(std::vector<MaterialImage>& images, bool compress, const std::atomic<bool>* cancel) {
    TextureSet set;
    if (images.empty() || images[0].size < 4) return set;
    const int size = images[0].size;
    for (const MaterialImage& im : images)
        if (im.size != size || im.albedo.size() != size_t(size) * size * 4 || im.normal.size() != im.albedo.size() || im.surface.size() != im.albedo.size())
            return set;                                                   // every layer must match (a texture pack is resized first)
    std::vector<PackedLayer> layers(images.size());
    parallelFor(int(images.size()), [&](int l) { if (!(cancel && cancel->load())) layers[size_t(l)] = packLayer(images[size_t(l)], compress); });
    if (cancel && cancel->load()) return set;

    auto join = [&](TextureSet::Map& map, int base, std::vector<std::vector<std::uint8_t>> PackedLayer::*field) {
        map.baseSize = base;
        const size_t levels = (layers[0].*field).size();
        map.levels.resize(levels);
        for (size_t lv = 0; lv < levels; ++lv)
            for (const PackedLayer& pl : layers) map.levels[lv].insert(map.levels[lv].end(), (pl.*field)[lv].begin(), (pl.*field)[lv].end());
    };
    join(set.albedo, size, &PackedLayer::albedo);
    join(set.normal, size, &PackedLayer::normal);
    join(set.surface, std::max(4, size / 2), &PackedLayer::surface);
    set.previews.resize(kMaterialSlots);
    for (int slot = 0; slot < kMaterialSlots; ++slot) {
        const MaterialInfo& info = materialInfo(MaterialId(slot + 1));
        set.previews[size_t(slot)] = makeMaterialPreview(images[size_t(std::clamp(info.texture, 0, int(images.size()) - 1))], info.tint, TextureSet::kPreview);
    }
    set.size = size;
    set.compressed = compress;
    return set;
}

TextureSet buildTextureSet(int size, bool compress, const std::atomic<bool>* cancel, std::vector<MaterialImage>* images) {
    std::vector<MaterialImage> own;
    std::vector<MaterialImage>& imgs = images ? *images : own;
    if (!images) imgs = generateMaterialImages(size, 0, cancel);
    if (cancel && cancel->load()) return {};
    return packTextureSet(imgs, compress, cancel);
}

// ---------------------------------------------------------------- the cache

std::string textureCachePath(int size, bool compressed, const std::string& key) {
    char name[96];
    std::snprintf(name, sizeof name, "materials_%d_%s_v%u%s.bin", size, compressed ? "bc" : "raw", unsigned(TextureSet::kVersion), key.empty() ? "" : "_pack");
    return std::string("cache/textures/") + name;
}

namespace {
constexpr char kMagic[4] = { 'S', 'P', 'T', 'X' };
template <class T> void put(std::ofstream& f, const T& v) { f.write(reinterpret_cast<const char*>(&v), sizeof v); }
template <class T> bool get(std::ifstream& f, T& v) { return bool(f.read(reinterpret_cast<char*>(&v), sizeof v)); }
void putBytes(std::ofstream& f, const std::vector<std::uint8_t>& b) { const std::uint64_t n = b.size(); put(f, n); f.write(reinterpret_cast<const char*>(b.data()), std::streamsize(n)); }
bool getBytes(std::ifstream& f, std::vector<std::uint8_t>& b, std::uint64_t limit) {
    std::uint64_t n = 0;
    if (!get(f, n) || n > limit) return false;
    b.resize(size_t(n));
    return bool(f.read(reinterpret_cast<char*>(b.data()), std::streamsize(n)));
}
} // namespace

bool saveTextureSet(const TextureSet& set, const std::string& path, const std::string& key) {
    if (!set.valid()) return false;
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(path).parent_path(), ec);
    const std::string tmp = path + ".part";
    {
        std::ofstream f(tmp, std::ios::binary);
        if (!f) return false;
        f.write(kMagic, 4);
        put(f, TextureSet::kVersion);
        std::vector<std::uint8_t> k(key.begin(), key.end());
        putBytes(f, k);
        put(f, std::int32_t(set.size));
        put(f, std::int32_t(set.compressed ? 1 : 0));
        put(f, std::int32_t(kTextureImages));
        for (const TextureSet::Map* m : { &set.albedo, &set.normal, &set.surface }) {
            put(f, std::int32_t(m->baseSize));
            put(f, std::int32_t(m->levels.size()));
            for (const auto& lv : m->levels) putBytes(f, lv);
        }
        put(f, std::int32_t(set.previews.size()));
        for (const auto& p : set.previews) putBytes(f, p);
        if (!f) return false;
    }
    std::filesystem::rename(tmp, path, ec);                                // whole or not at all
    return !ec;
}

bool loadTextureSet(TextureSet& set, const std::string& path, const std::string& key) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    char magic[4];
    std::uint32_t version = 0;
    if (!f.read(magic, 4) || std::memcmp(magic, kMagic, 4) != 0 || !get(f, version) || version != TextureSet::kVersion) return false;
    std::vector<std::uint8_t> k;
    if (!getBytes(f, k, 4096) || std::string(k.begin(), k.end()) != key) return false;
    std::int32_t size = 0, compressed = 0, layers = 0;
    if (!get(f, size) || !get(f, compressed) || !get(f, layers) || layers != kTextureImages || size < 4 || size > 16384) return false;
    TextureSet s;
    s.size = size; s.compressed = compressed != 0;
    const std::uint64_t limit = std::uint64_t(size) * size * 4 * std::uint64_t(kTextureImages) + 1024;
    for (TextureSet::Map* m : { &s.albedo, &s.normal, &s.surface }) {
        std::int32_t base = 0, levels = 0;
        if (!get(f, base) || !get(f, levels) || base < 4 || base > size || levels < 1 || levels > 16) return false;
        m->baseSize = base;
        m->levels.resize(size_t(levels));
        for (auto& lv : m->levels) if (!getBytes(f, lv, limit)) return false;
    }
    std::int32_t previews = 0;
    if (!get(f, previews) || previews != kMaterialSlots) return false;
    s.previews.resize(size_t(previews));
    for (auto& p : s.previews) if (!getBytes(f, p, TextureSet::kPreview * TextureSet::kPreview * 4) || p.size() != size_t(TextureSet::kPreview * TextureSet::kPreview * 4)) return false;
    set = std::move(s);
    return true;
}

} // namespace px
