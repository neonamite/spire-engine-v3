#include "MaterialTextures.h"
#include "world/Materials.h"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <thread>
#include <glm/glm.hpp>

namespace px {

namespace {

// ================================================================== tileable noise
// Everything is a function of u, v in [0, 1) that wraps at 1, so every texture tiles, at any resolution.

constexpr float kTau = 6.28318530718f;

std::uint32_t hashU(int x, int y, std::uint32_t seed) {
    std::uint32_t h = std::uint32_t(x) * 0x8da6b343u ^ std::uint32_t(y) * 0xd8163841u ^ seed * 0xcb1ab31fu;
    h ^= h >> 15; h *= 0x2c1b3c6du; h ^= h >> 12; h *= 0x297a2d39u; h ^= h >> 15;
    return h;
}
float hashF(int x, int y, std::uint32_t seed) { return float(hashU(x, y, seed) & 0xFFFFFFu) / float(0x1000000u); }
int wrap(int i, int p) { return ((i % p) + p) % p; }
float sat(float x) { return std::clamp(x, 0.0f, 1.0f); }
float sstep(float a, float b, float x) { const float t = sat((x - a) / (b - a)); return t * t * (3 - 2 * t); }
float lerp(float a, float b, float t) { return a + (b - a) * t; }
glm::vec3 rgb(int r, int g, int b) { return glm::vec3(r, g, b) / 255.0f; }
float fractf(float x) { return x - std::floor(x); }

// 64 evenly spread unit gradients: no sin / cos per lookup.
struct Gradients {
    glm::vec2 g[64];
    Gradients() { for (int i = 0; i < 64; ++i) g[i] = glm::vec2(std::cos(kTau * (float(i) + 0.5f) / 64.0f), std::sin(kTau * (float(i) + 0.5f) / 64.0f)); }
};
const Gradients& gradients() { static const Gradients G; return G; }

// Periodic gradient (Perlin) noise with px by py cells over the unit square. About -1..1.
float pnoise(float u, float v, int px, int py, std::uint32_t seed) {
    const float x = u * float(px), y = v * float(py);
    const int ix = int(std::floor(x)), iy = int(std::floor(y));
    const float fx = x - float(ix), fy = y - float(iy);
    const glm::vec2* G = gradients().g;
    auto dotg = [&](int cx, int cy, float dx, float dy) {
        const glm::vec2 g = G[hashU(wrap(cx, px), wrap(cy, py), seed) & 63u];
        return g.x * dx + g.y * dy;
    };
    const float n00 = dotg(ix, iy, fx, fy), n10 = dotg(ix + 1, iy, fx - 1, fy);
    const float n01 = dotg(ix, iy + 1, fx, fy - 1), n11 = dotg(ix + 1, iy + 1, fx - 1, fy - 1);
    const float sx = fx * fx * fx * (fx * (fx * 6 - 15) + 10), sy = fy * fy * fy * (fy * (fy * 6 - 15) + 10);
    return lerp(lerp(n00, n10, sx), lerp(n01, n11, sx), sy) * 1.41f;
}

// Fractal sums. fbm: -1..1 roughly. Anisotropy: stretch with px != py.
float fbm(float u, float v, int period, int octaves, std::uint32_t seed, float gain = 0.5f) {
    float sum = 0, amp = 1, norm = 0;
    for (int o = 0; o < octaves; ++o) {
        sum += pnoise(u, v, period, period, seed + std::uint32_t(o) * 131u) * amp;
        norm += amp; amp *= gain; period *= 2;
    }
    return sum / norm;
}
float fbmA(float u, float v, int px, int py, int octaves, std::uint32_t seed, float gain = 0.5f) {
    float sum = 0, amp = 1, norm = 0;
    for (int o = 0; o < octaves; ++o) {
        sum += pnoise(u, v, px, py, seed + std::uint32_t(o) * 131u) * amp;
        norm += amp; amp *= gain; px *= 2; py *= 2;
    }
    return sum / norm;
}
float fbm01(float u, float v, int period, int octaves, std::uint32_t seed, float gain = 0.5f) { return sat(fbm(u, v, period, octaves, seed, gain) * 0.5f + 0.5f); }
// Ridged: sharp crests, like eroded rock and cracks. 0..1.
float ridged(float u, float v, int period, int octaves, std::uint32_t seed) {
    float sum = 0, amp = 1, norm = 0;
    for (int o = 0; o < octaves; ++o) {
        float n = 1.0f - std::fabs(pnoise(u, v, period, period, seed + std::uint32_t(o) * 977u));
        sum += n * n * amp; norm += amp; amp *= 0.5f; period *= 2;
    }
    return sum / norm;
}

struct Cell { float f1, f2; std::uint32_t id; glm::vec2 toPoint; glm::vec2 point; };
// Worley / cellular noise: distance to the nearest and second-nearest jittered points (in cell units).
Cell worley(float u, float v, int period, std::uint32_t seed, float jitter = 0.85f) {
    const float x = u * float(period), y = v * float(period);
    const int ix = int(std::floor(x)), iy = int(std::floor(y));
    Cell c{ 9, 9, 0, {}, {} };
    for (int j = -1; j <= 1; ++j)
        for (int i = -1; i <= 1; ++i) {
            const int cx = wrap(ix + i, period), cy = wrap(iy + j, period);
            const glm::vec2 pt(float(ix + i) + 0.5f + (hashF(cx, cy, seed) - 0.5f) * jitter,
                               float(iy + j) + 0.5f + (hashF(cx, cy, seed + 7) - 0.5f) * jitter);
            const glm::vec2 dv = pt - glm::vec2(x, y);
            const float d = glm::length(dv);
            if (d < c.f1) { c.f2 = c.f1; c.f1 = d; c.id = hashU(cx, cy, seed + 3); c.toPoint = dv; c.point = pt; }
            else if (d < c.f2) c.f2 = d;
        }
    return c;
}
// Distance to the border between cells (the real one, not F2 - F1): crisp cracks and grout of even width.
float cellBorder(float u, float v, int period, std::uint32_t seed, float jitter, Cell* out = nullptr) {
    const Cell c = worley(u, v, period, seed, jitter);
    if (out) *out = c;
    const float x = u * float(period), y = v * float(period);
    const int ix = int(std::floor(x)), iy = int(std::floor(y));
    float best = 9.0f;
    const glm::vec2 p(x, y), a = c.point;
    for (int j = -2; j <= 2; ++j)
        for (int i = -2; i <= 2; ++i) {
            const int cx = wrap(ix + i, period), cy = wrap(iy + j, period);
            const glm::vec2 b(float(ix + i) + 0.5f + (hashF(cx, cy, seed) - 0.5f) * jitter,
                              float(iy + j) + 0.5f + (hashF(cx, cy, seed + 7) - 0.5f) * jitter);
            const glm::vec2 ab = b - a;
            const float len = glm::length(ab);
            if (len < 1e-4f) continue;
            const glm::vec2 n = ab / len;
            best = std::min(best, glm::dot((a + b) * 0.5f - p, n));
        }
    return best;
}

float idF(std::uint32_t id, std::uint32_t salt = 0) { return float((id ^ (salt * 0x9E3779B9u)) % 10007u) / 10007.0f; }

// Running-bond courses (bricks, planks, roof tiles): which piece, and how far from its edges (0 at the edge, in units of the
// piece's height). cols per row, rows; odd rows shifted by `offset` of a piece.
struct Piece { int row, col; float edge; float ex, ey; glm::vec2 local; std::uint32_t id; };
Piece course(float u, float v, int cols, int rows, float offset) {
    const float aspect = float(rows) / float(cols);                   // a piece's width in units of its height
    Piece p;
    const float y = v * float(rows);
    p.row = int(std::floor(y));
    const float shift = (wrap(p.row, 2) == 1) ? offset : 0.0f;
    const float x = u * float(cols) + shift;
    p.col = int(std::floor(x));
    p.local = glm::vec2(x - float(p.col), y - float(p.row));
    p.ey = std::min(p.local.y, 1.0f - p.local.y);
    p.ex = std::min(p.local.x, 1.0f - p.local.x) * aspect;               // in units of the piece's height
    p.edge = std::min(p.ex, p.ey);
    p.id = hashU(wrap(p.col, cols), wrap(p.row, rows), 1234);
    return p;
}

// A texel of one material: colour (sRGB), height 0..1, roughness 0..1, metalness 0..1.
struct Texel { glm::vec3 color; float height; float rough; float metal; };


// ================================================================== the materials

Texel grass(float u, float v) {
    // Turf seen from above: clumps, a thatch of thin blades in every direction, some dry stalks and soil between.
    const float clump = fbm01(u, v, 6, 4, 11);
    const Cell tuft = worley(u, v, 40, 15, 0.9f);
    const float blade1 = 0.5f + 0.5f * pnoise(u, v, 900, 70, 13), blade2 = 0.5f + 0.5f * pnoise(u, v, 70, 900, 14);
    const float blade3 = 0.5f + 0.5f * pnoise(u + v * 0.6f, v - u * 0.6f, 600, 600, 16);
    const float blades = std::max({ blade1 * blade1, blade2 * blade2, blade3 * blade3 });
    const float soilPeek = sstep(0.62f, 0.85f, fbm01(u, v, 20, 3, 17)) * (1.0f - blades) * 0.8f;
    const float dry = sstep(0.55f, 0.8f, fbm01(u, v, 5, 3, 18));
    glm::vec3 lush = glm::mix(rgb(44, 72, 22), rgb(86, 120, 36), clump);
    glm::vec3 c = glm::mix(lush, rgb(128, 126, 66), dry * 0.55f);
    c = glm::mix(c * 0.55f, c * 1.15f + glm::vec3(0.02f, 0.03f, 0.0f), blades);
    c = glm::mix(c, rgb(72, 56, 38), soilPeek);
    c *= 0.85f + 0.3f * sat(1.0f - tuft.f1);
    const float h = sat(0.25f + 0.45f * blades + 0.25f * clump * (1.0f - tuft.f1 * 0.5f) - soilPeek * 0.3f);
    return { c, h, 0.86f + 0.1f * (1.0f - blades), 0.0f };
}

Texel dirt(float u, float v) {
    // Packed earth: clods, crumbly detail, a few half-buried pebbles, roots of darkness where it is damp.
    const glm::vec2 w(u + fbm(u, v, 5, 3, 21) * 0.04f, v + fbm(u, v, 5, 3, 22) * 0.04f);
    const float base = fbm01(w.x, w.y, 6, 5, 23);
    const float fine = fbm01(u, v, 120, 3, 24);
    const float crumbs = sstep(0.55f, 0.8f, fbm01(u, v, 60, 2, 28));
    const float clods = ridged(w.x, w.y, 10, 4, 25);
    const Cell pc = worley(u, v, 24, 26, 1.0f);
    const float pr = 0.18f + 0.22f * idF(pc.id, 2);
    const float pebble = idF(pc.id) < 0.16f ? std::sqrt(sat(1.0f - (pc.f1 / pr) * (pc.f1 / pr))) : 0.0f;
    const float damp = sstep(0.55f, 0.78f, fbm01(u, v, 4, 3, 27));
    glm::vec3 c = glm::mix(rgb(80, 58, 40), rgb(116, 88, 60), base);
    c *= 0.78f + 0.3f * fine + 0.08f * crumbs;
    c = glm::mix(c, c * 0.62f, damp * 0.65f);
    const glm::vec3 stoneC = glm::mix(rgb(92, 86, 78), rgb(132, 124, 112), idF(pc.id, 5)) * (0.8f + 0.3f * fine);
    c = glm::mix(c, stoneC, sstep(0.0f, 0.25f, pebble));
    const float h = sat(0.28f + 0.25f * base + 0.22f * clods + 0.12f * fine + 0.06f * crumbs + pebble * 0.35f);
    return { c, h, glm::mix(0.93f, 0.6f, damp * 0.7f) - pebble * 0.1f, 0.0f };
}

Texel stone(float u, float v) {
    // Weathered rock: broad eroded relief, flaking plates, a few long irregular cracks, mineral speckle, lichen.
    const glm::vec2 w(u + fbm(u, v, 3, 4, 31) * 0.10f, v + fbm(u, v, 3, 4, 32) * 0.10f);
    const float big = fbm01(w.x, w.y, 3, 6, 33);
    const float relief = ridged(w.x, w.y, 5, 6, 34);
    const float plates = fbm01(w.x * 1.0f, w.y, 10, 4, 39);
    const float plateStep = std::floor(plates * 5.0f) / 5.0f;                        // terraced flakes
    // cracks: borders of a strongly warped cell pattern, shown only in places, thin and uneven
    const glm::vec2 w2(u + fbm(u, v, 6, 4, 36) * 0.06f, v + fbm(u, v, 6, 4, 37) * 0.06f);
    const float border = cellBorder(w2.x, w2.y, 5, 35, 1.0f);
    const float showCrack = sstep(0.45f, 0.65f, fbm01(u, v, 4, 3, 30));
    const float crack = (1.0f - sstep(0.0f, 0.018f + 0.012f * fbm01(u, v, 40, 2, 29), border)) * showCrack;
    const float speck = fbm01(u, v, 300, 2, 37);
    const float lichen = sstep(0.70f, 0.80f, fbm01(u, v, 9, 4, 38)) * sstep(0.45f, 0.75f, big);
    const float stain = sstep(0.35f, 0.75f, fbm01(w.x, w.y * 0.35f, 4, 4, 40));       // rain-streaked darker weathering
    glm::vec3 c = glm::mix(rgb(78, 76, 72), rgb(156, 151, 142), sstep(0.15f, 0.85f, big * 0.65f + relief * 0.35f));
    c = glm::mix(c, c * glm::vec3(0.72f, 0.70f, 0.68f), stain * 0.6f);
    c *= 0.84f + 0.24f * speck + 0.10f * (plateStep - 0.5f);
    c = glm::mix(c, glm::mix(rgb(128, 132, 96), rgb(168, 160, 112), speck), lichen * 0.6f);
    c *= 1.0f - crack * 0.6f;
    const float h = sat(0.25f + 0.35f * relief + 0.2f * big + 0.12f * plateStep + 0.05f * speck - crack * 0.35f);
    return { c, h, 0.74f + 0.16f * (1.0f - speck) + lichen * 0.08f, 0.0f };
}

Texel sand(float u, float v) {
    // Wind ripples that wander, fine grains, a few darker shell and mineral flecks.
    const float wander = fbm(u, v, 3, 3, 41) * 0.12f;
    const float ripple = 0.5f + 0.5f * std::sin((u * 14.0f + v * 6.0f + wander * 6.0f + fbm(u, v, 8, 2, 42) * 0.4f) * kTau);
    const float ripple2 = 0.5f + 0.5f * std::sin((u * 31.0f - v * 9.0f + wander * 9.0f) * kTau);
    const float grain = fbm01(u, v, 320, 2, 43);
    const float fleck = sstep(0.8f, 0.9f, fbm01(u, v, 180, 1, 44));
    const float tone = fbm01(u, v, 5, 3, 45);
    glm::vec3 c = glm::mix(rgb(176, 150, 104), rgb(214, 190, 142), tone);
    c *= 0.9f + 0.12f * grain + 0.06f * (ripple * ripple);
    c = glm::mix(c, rgb(110, 96, 78), fleck * 0.5f);
    const float h = sat(0.30f + 0.40f * std::pow(ripple, 1.6f) + 0.12f * ripple2 + 0.10f * grain);
    return { c, h, 0.93f, 0.0f };
}

Texel snow(float u, float v) {
    // Soft drifts with gentle wind scallops; ice crystals glint (lower roughness in tiny specks).
    const float drift = fbm01(u, v, 4, 5, 51);
    const Cell scallop = worley(u, v, 7, 52, 0.9f);
    const float sc = sstep(0.0f, 0.9f, scallop.f1);
    const float sparkle = sstep(0.95f, 0.995f, hashF(int(u * 2048.0f), int(v * 2048.0f), 53));
    const float h = sat(0.35f + 0.4f * drift + 0.12f * sc + 0.05f * fbm01(u, v, 100, 2, 55));
    glm::vec3 c = glm::mix(rgb(178, 190, 210), rgb(220, 226, 236), sstep(0.2f, 0.7f, h));
    c *= 0.98f + 0.04f * fbm01(u, v, 120, 2, 54);
    return { c, h, 0.6f - sparkle * 0.4f, 0.0f };
}

Texel wood(float u, float v) {
    // Planks of different boards: grain lines warped around knots, sawn ends, nails, gaps between boards.
    const Piece p = course(u, v, 2, 10, 0.43f);
    const float board = idF(p.id);
    const float lx = p.local.x, ly = p.local.y;
    // knots: one or two per board, the grain bends round them
    const Cell knot = worley(u * 0.5f, v, 5, 61 + p.row, 0.8f);
    const bool hasKnot = idF(knot.id) < 0.35f;
    const float bend = hasKnot ? sstep(0.45f, 0.0f, knot.f1) * 0.35f : 0.0f;
    const float grainPos = ly * 11.0f + board * 13.0f + fbm(u * 0.5f, v, 3, 3, 62 + p.row) * 1.8f + bend * std::sin(knot.toPoint.x * 4.0f);
    const float rings = std::pow(0.5f + 0.5f * std::sin(grainPos * kTau), 3.0f);
    const float fibre = 0.5f + 0.5f * pnoise(u, v, 24, 900, 63);
    const float knotDark = hasKnot ? sstep(0.10f, 0.03f, knot.f1) : 0.0f;
    const float gap = 1.0f - sstep(0.0f, 0.035f, p.ey) * sstep(0.0f, 0.012f, std::min(lx, 1.0f - lx));
    const float nail = (sstep(0.03f, 0.018f, glm::length(glm::vec2((lx - 0.05f) * 6.0f, ly - 0.3f))) +
                        sstep(0.03f, 0.018f, glm::length(glm::vec2((lx - 0.05f) * 6.0f, ly - 0.7f))));
    glm::vec3 base = glm::mix(rgb(112, 80, 52), rgb(160, 120, 80), board);
    base = glm::mix(base, rgb(140, 120, 100), sstep(0.6f, 0.9f, idF(p.id, 3)) * 0.35f);        // a weathered board now and then
    glm::vec3 c = base * (0.95f - 0.22f * rings + 0.1f * fibre);
    c = glm::mix(c, rgb(66, 40, 22), knotDark * 0.8f);
    c = glm::mix(c, rgb(28, 20, 14), gap);
    c = glm::mix(c, rgb(80, 80, 84), sat(nail));
    const float h = sat(0.6f + 0.12f * rings + 0.08f * fibre - gap * 0.55f - sstep(0.08f, 0.0f, p.ey) * 0.15f + 0.05f * board);
    return { c, h, glm::mix(0.72f, 0.55f, sat(nail)) + 0.06f * fibre, sat(nail) * 0.9f };
}

Texel metal(float u, float v) {
    // Brushed steel panels: seams, rivets along the edges, fine brushing, a few scratches and smudges.
    const int panels = 2;
    const float x = u * panels, y = v * panels;
    const float lx = fractf(x), ly = fractf(y);
    const std::uint32_t pid = hashU(int(std::floor(x)), int(std::floor(y)), 71);
    const float seam = 1.0f - sstep(0.004f, 0.012f, std::min({ lx, 1 - lx, ly, 1 - ly }));
    float rivet = 0.0f;
    for (int i = 1; i < 8; ++i) {
        const float t = float(i) / 8.0f;
        for (const glm::vec2 c : { glm::vec2(t, 0.04f), glm::vec2(t, 0.96f), glm::vec2(0.04f, t), glm::vec2(0.96f, t) })
            rivet = std::max(rivet, sstep(0.016f, 0.008f, glm::length(glm::vec2(lx, ly) - c)));
    }
    const float brush = pnoise(u, v, 4, 1600, 72 + pid % 4) * 0.5f + 0.5f;
    const float scratch = sstep(0.985f, 1.0f, 1.0f - std::fabs(pnoise(u * 3.0f + v, v * 0.2f, 60, 6, 73)));
    const float smudge = fbm01(u, v, 4, 4, 74);
    glm::vec3 c = glm::mix(rgb(150, 154, 160), rgb(186, 190, 196), idF(pid));
    c *= 0.92f + 0.08f * brush;
    c = glm::mix(c, rgb(90, 92, 96), seam);
    c *= 1.0f - 0.12f * sstep(0.5f, 0.9f, smudge);
    const float h = sat(0.55f + 0.03f * brush - seam * 0.4f + rivet * 0.35f - scratch * 0.08f);
    const float rough = sat(0.30f + 0.18f * smudge + 0.12f * (1.0f - brush) + seam * 0.4f - scratch * 0.15f);
    return { c, h, rough, 1.0f - seam * 0.7f };
}

Texel brick(float u, float v) {
    // Red bricks, each its own shade, chipped corners and worn faces, recessed mortar with grit, soot near the base of some.
    const Piece p = course(u, v, 8, 24, 0.5f);                          // 225 x 75 mm courses over 1.8 m
    const float b = idF(p.id), b2 = idF(p.id, 9);
    const float chip = fbm01(u, v, 64, 3, 81);
    const float edge = p.edge - (chip - 0.5f) * 0.08f;                  // ragged edges
    const float mortar = 1.0f - sstep(0.05f, 0.09f, edge);
    const float bevel = sstep(0.05f, 0.18f, edge);
    const float face = fbm01(u, v, 48, 4, 82);
    const float pits = sstep(0.72f, 0.82f, fbm01(u, v, 160, 2, 83));
    glm::vec3 brickC = glm::mix(rgb(122, 48, 34), rgb(170, 78, 52), b);
    brickC = glm::mix(brickC, rgb(92, 56, 46), sstep(0.8f, 1.0f, b2) * 0.7f);            // a few dark, overfired ones
    brickC *= 0.82f + 0.25f * face;
    brickC *= 1.0f - pits * 0.25f;
    const glm::vec3 mortarC = rgb(168, 160, 146) * (0.8f + 0.3f * fbm01(u, v, 200, 2, 84));
    glm::vec3 c = glm::mix(brickC, mortarC, mortar);
    c *= 1.0f - 0.18f * sstep(0.55f, 0.95f, fbm01(u, v, 3, 3, 85)) * (1.0f - v);       // grime from the ground up
    const float h = sat(mortar > 0.5f ? 0.12f + 0.08f * chip : 0.55f + 0.25f * bevel + 0.12f * face - pits * 0.2f);
    return { c, h, mortar > 0.5f ? 0.95f : 0.82f + 0.1f * pits, 0.0f };
}

Texel plaster(float u, float v) {
    // Hand-troweled render: soft broad swirls, fine sand texture, faint hairline cracks.
    const float trowel = fbm01(u, v, 5, 4, 91);
    const float swirl = 0.5f + 0.5f * pnoise(u + trowel * 0.2f, v, 12, 12, 92);
    const float sandy = fbm01(u, v, 380, 2, 93);
    const float hair = 1.0f - sstep(0.0f, 0.01f, cellBorder(u, v, 5, 94, 0.9f));
    const float hairMask = sstep(0.6f, 0.75f, fbm01(u, v, 6, 2, 95));
    glm::vec3 c = rgb(222, 216, 204) * (0.94f + 0.06f * trowel + 0.04f * sandy);
    c *= 1.0f - hair * hairMask * 0.25f;
    const float h = sat(0.5f + 0.15f * swirl + 0.1f * trowel + 0.08f * sandy - hair * hairMask * 0.2f);
    return { c, h, 0.86f + 0.08f * sandy, 0.0f };
}

Texel tile(float u, float v) {
    // Glazed square tiles: each glaze slightly different, a bit of waviness in the glaze, grout lines with dirt.
    const int n = 8;
    const float x = u * n, y = v * n;
    const float lx = fractf(x), ly = fractf(y);
    const std::uint32_t id = hashU(int(std::floor(x)), int(std::floor(y)), 101);
    const float e = std::min({ lx, 1 - lx, ly, 1 - ly });
    const float grout = 1.0f - sstep(0.025f, 0.04f, e);
    const float bevel = sstep(0.03f, 0.10f, e);
    const float glaze = fbm01(u, v, 40, 3, 102);
    glm::vec3 c = glm::mix(rgb(196, 210, 214), rgb(220, 230, 232), idF(id)) * (0.97f + 0.05f * glaze);
    c = glm::mix(c, rgb(120, 116, 108) * (0.85f + 0.3f * fbm01(u, v, 200, 2, 103)), grout);
    const float h = sat(grout > 0.5f ? 0.18f : 0.6f + 0.25f * bevel + 0.03f * glaze);
    return { c, h, grout > 0.5f ? 0.9f : 0.08f + 0.08f * glaze, 0.0f };
}

Texel cloth(float u, float v) {
    // A twill weave: threads over and under in a diagonal rhythm, fuzz and slight colour variation per thread.
    const float n = 160.0f;
    const float x = u * n, y = v * n;
    const int ix = int(std::floor(x)), iy = int(std::floor(y));
    const bool warpUp = wrap(ix + iy, 4) < 2;                               // 2/2 twill
    const float fx = fractf(x), fy = fractf(y);
    const float across = warpUp ? std::sin(fx * 3.14159f) : std::sin(fy * 3.14159f);
    const float along = warpUp ? std::sin(fy * 3.14159f) : std::sin(fx * 3.14159f);
    const float thread = idF(hashU(warpUp ? ix : iy, warpUp ? 0 : 1, 111));
    const float fuzz = fbm01(u, v, 512, 2, 112);
    glm::vec3 c = rgb(176, 162, 136) * (0.82f + 0.12f * thread + 0.12f * across * (0.7f + 0.3f * along));
    c *= 0.95f + 0.08f * fuzz;
    const float h = sat(0.3f + 0.45f * across * (0.6f + 0.4f * along) + 0.1f * fuzz);
    return { c, h, 0.92f, 0.0f };
}

Texel ice(float u, float v) {
    // Clear ice: fractures that catch the light, trapped bubbles, deep blue below.
    const float deep = fbm01(u, v, 4, 4, 121);
    const float cr = cellBorder(u, v, 6, 122, 0.95f);
    const float cr2 = cellBorder(u + 0.37f, v + 0.11f, 15, 123, 0.9f);
    const float crack = std::max(1.0f - sstep(0.0f, 0.02f, cr), (1.0f - sstep(0.0f, 0.012f, cr2)) * 0.6f);
    const Cell bub = worley(u, v, 70, 124, 0.95f);
    const float bubble = idF(bub.id) < 0.3f ? sstep(0.25f, 0.12f, bub.f1) : 0.0f;
    glm::vec3 c = glm::mix(rgb(88, 140, 178), rgb(170, 210, 232), deep * 0.7f + 0.15f);
    c = glm::mix(c, rgb(232, 244, 250), crack * 0.8f + bubble * 0.5f);
    const float h = sat(0.6f + 0.2f * deep - crack * 0.25f + bubble * 0.1f);
    return { c, h, 0.05f + 0.25f * crack + 0.05f * deep, 0.0f };
}

Texel lava(float u, float v) {
    // Cooled crust plates, glowing where they split; the glow is brightest deep in the cracks.
    const glm::vec2 w(u + fbm(u, v, 4, 3, 131) * 0.06f, v + fbm(u, v, 4, 3, 132) * 0.06f);
    const float border = cellBorder(w.x, w.y, 6, 133, 0.9f);
    const float glow = 1.0f - sstep(0.0f, 0.12f, border);
    const float crust = fbm01(u, v, 24, 4, 134);
    const float rope = ridged(w.x, w.y, 16, 3, 135);
    glm::vec3 c = rgb(36, 28, 26) * (0.7f + 0.6f * crust);
    const glm::vec3 hot = glm::mix(rgb(255, 120, 20), rgb(255, 214, 120), glow * glow);
    c = glm::mix(c, hot, glow);
    const float h = sat(0.55f + 0.25f * rope + 0.15f * crust - glow * 0.5f);
    return { c, h, glm::mix(0.88f, 0.4f, glow), 0.0f };
}

Texel lamp(float u, float v) {
    // A frosted light panel in a thin frame: even glow, a faint grid of diffuser cells.
    const float n = 6.0f;
    const float lx = fractf(u * n), ly = fractf(v * n);
    const float e = std::min({ lx, 1 - lx, ly, 1 - ly });
    const float frame = 1.0f - sstep(0.02f, 0.05f, e);
    const float frost = fbm01(u, v, 96, 2, 141);
    glm::vec3 c = glm::mix(rgb(250, 240, 220) * (0.94f + 0.06f * frost), rgb(80, 76, 70), frame);
    return { c, sat(0.6f - frame * 0.3f), 0.35f + frame * 0.3f, frame * 0.8f };
}

Texel crystal(float u, float v) {
    // Faceted crystal: flat facets with sharp ridges, brighter where light gathers in the middle.
    Cell c;
    const float border = cellBorder(u, v, 9, 151, 0.95f, &c);
    const float facet = idF(c.id);
    const float ridge = 1.0f - sstep(0.0f, 0.04f, border);
    glm::vec3 col = glm::mix(rgb(120, 190, 240), rgb(210, 240, 255), facet * 0.7f + 0.3f * sstep(0.6f, 0.0f, c.f1));
    col = glm::mix(col, rgb(255, 255, 255), ridge * 0.6f);
    const float h = sat(0.4f + 0.4f * facet + 0.3f * sstep(0.0f, 0.3f, border));
    return { col, h, 0.1f + ridge * 0.2f, 0.0f };
}

// ---------------------------------------------------------------- added in 1.2

Texel moss(float u, float v) {
    // Deep cushiony moss: rounded clumps, tiny fronds, damp dark gaps.
    const Cell cl = worley(u, v, 18, 161, 0.9f);
    const float clump = sstep(0.95f, 0.2f, cl.f1);
    const float fronds = fbm01(u, v, 400, 2, 162);
    const float tone = fbm01(u, v, 6, 4, 163);
    glm::vec3 c = glm::mix(rgb(52, 78, 26), rgb(108, 132, 44), tone * 0.6f + clump * 0.4f);
    c *= 0.6f + 0.5f * clump * (0.7f + 0.3f * fronds);
    c = glm::mix(c, rgb(150, 140, 70), sstep(0.75f, 0.9f, fbm01(u, v, 30, 2, 164)) * 0.35f);   // fruiting tips
    const float h = sat(0.2f + 0.6f * clump + 0.15f * fronds);
    return { c, h, 0.95f, 0.0f };
}

Texel gravel(float u, float v) {
    // Loose gravel: rounded pebbles of mixed stone and size, lying over each other, dust and grit in the gaps.
    float bestH = 0.0f; glm::vec3 col(0.0f); float rough = 0.9f;
    for (int layer = 0; layer < 3; ++layer) {
        const Cell c = worley(u + 0.31f * float(layer), v + 0.17f * float(layer), 22 + layer * 6, 171 + std::uint32_t(layer) * 31, 1.0f);
        const float r = 0.32f + 0.26f * idF(c.id, 1);
        const float d = c.f1 / r;
        if (d >= 1.0f) continue;
        const float dome = std::sqrt(1.0f - d * d);
        const float h = dome * (0.55f + 0.25f * idF(c.id, 2)) + 0.1f * float(layer) * 0.0f;
        if (h <= bestH) continue;
        bestH = h;
        const float k = idF(c.id, 3), k2 = idF(c.id, 4);
        glm::vec3 sc = k < 0.45f ? glm::mix(rgb(118, 114, 108), rgb(170, 164, 154), k2)
                     : k < 0.75f ? glm::mix(rgb(126, 104, 84), rgb(168, 138, 108), k2)
                                 : glm::mix(rgb(70, 70, 72), rgb(104, 104, 106), k2);
        col = sc * (0.75f + 0.3f * dome);
        rough = 0.72f + 0.15f * k2;
    }
    const float grit = fbm01(u, v, 300, 2, 172);
    if (bestH <= 0.0f) { col = rgb(78, 70, 60) * (0.8f + 0.3f * grit); rough = 0.95f; }
    else col *= 0.9f + 0.15f * grit;
    return { col, sat(0.08f + 0.85f * bestH + 0.04f * grit), rough, 0.0f };
}

Texel mud(float u, float v) {
    // Wet mud: churned ridges, glossy puddles in the low parts, a few stones and footprints of water.
    const glm::vec2 w(u + fbm(u, v, 4, 3, 181) * 0.08f, v + fbm(u, v, 4, 3, 182) * 0.08f);
    const float churn = ridged(w.x, w.y, 8, 4, 183);
    const float base = fbm01(w.x, w.y, 5, 4, 184);
    const float h = sat(0.3f + 0.4f * churn + 0.3f * base);
    const float wet = sstep(0.42f, 0.34f, h);
    glm::vec3 c = glm::mix(rgb(62, 46, 32), rgb(102, 80, 58), base) * (0.85f + 0.2f * fbm01(u, v, 120, 2, 185));
    c = glm::mix(c, c * 0.55f, wet);
    return { c, h, glm::mix(0.8f, 0.12f, wet), 0.0f };
}

Texel cobblestone(float u, float v) {
    // Rounded cobbles set in a grid-ish street pattern, worn smooth on top, dirt and moss in the joints.
    Cell c;
    const float border = cellBorder(u + 0.0f, v, 10, 191, 0.55f, &c);
    const float dome = sstep(0.0f, 0.45f, border);
    const float joint = 1.0f - sstep(0.04f, 0.09f, border);
    const float r = idF(c.id), r2 = idF(c.id, 3);
    const float face = fbm01(u, v, 60, 4, 192);
    glm::vec3 sc = glm::mix(rgb(104, 100, 96), rgb(150, 144, 136), r) * (0.85f + 0.2f * face);
    sc = glm::mix(sc, rgb(120, 104, 90), sstep(0.7f, 1.0f, r2) * 0.5f);
    const float mossy = sstep(0.55f, 0.75f, fbm01(u, v, 8, 3, 193));
    glm::vec3 jointC = glm::mix(rgb(70, 58, 44), rgb(70, 92, 40), mossy);
    glm::vec3 col = glm::mix(sc, jointC, joint);
    const float h = sat(joint > 0.5f ? 0.1f + 0.1f * face : 0.35f + 0.55f * std::sqrt(dome) + 0.06f * face);
    return { col, h, joint > 0.5f ? 0.95f : glm::mix(0.8f, 0.55f, dome), 0.0f };
}

Texel marble(float u, float v) {
    // Polished white marble: the classic turbulent veining, soft grey clouds, a few fine dark veins.
    float turb = 0.0f, amp = 1.0f;
    for (int o = 0; o < 6; ++o) { turb += std::fabs(pnoise(u, v, 2 << o, 2 << o, 201 + std::uint32_t(o))) * amp; amp *= 0.5f; }
    const float band = std::sin((u * 2.0f + v * 1.0f + turb * 1.6f) * kTau);
    const float vein = std::pow(1.0f - std::fabs(band), 10.0f);
    float turb2 = 0.0f; amp = 1.0f;
    for (int o = 0; o < 5; ++o) { turb2 += std::fabs(pnoise(u, v, 3 << o, 3 << o, 211 + std::uint32_t(o))) * amp; amp *= 0.5f; }
    const float fine = std::pow(1.0f - std::fabs(std::sin((u * 1.0f - v * 3.0f + turb2 * 2.4f) * kTau)), 40.0f);
    const float cloud = fbm01(u, v, 5, 5, 203);
    glm::vec3 c = glm::mix(rgb(222, 219, 214), rgb(244, 242, 238), cloud);
    c = glm::mix(c, rgb(150, 148, 150), vein * 0.55f);
    c = glm::mix(c, rgb(84, 84, 92), fine * 0.65f);
    return { c, sat(0.6f + 0.02f * cloud - fine * 0.03f), 0.10f + 0.06f * vein + 0.04f * cloud, 0.0f };
}

Texel concrete(float u, float v) {
    // Cast concrete: grey with air pores, faint formwork board lines, water streaks and patches of wear.
    const float tone = fbm01(u, v, 5, 5, 211);
    const float fine = fbm01(u, v, 256, 2, 212);
    const Cell pc = worley(u, v, 140, 213, 0.95f);
    const float pore = idF(pc.id) < 0.22f ? sstep(0.25f, 0.1f, pc.f1) : 0.0f;
    const float board = 1.0f - sstep(0.0f, 0.004f, std::fabs(fractf(v * 4.0f) - 0.5f) - 0.495f + 0.004f);
    const float streak = sstep(0.55f, 0.85f, fbm01(u * 1.0f, v, 30, 6, 214) * 0.5f + 0.5f * fbm01(u, v * 0.1f, 40, 2, 215));
    glm::vec3 c = glm::mix(rgb(126, 126, 122), rgb(168, 166, 160), tone) * (0.92f + 0.12f * fine);
    c *= 1.0f - 0.18f * streak;
    c *= 1.0f - pore * 0.45f - board * 0.15f;
    const float h = sat(0.55f + 0.08f * fine + 0.05f * tone - pore * 0.4f - board * 0.2f);
    return { c, h, 0.88f + 0.06f * fine, 0.0f };
}

Texel sandstone(float u, float v) {
    // Layered sandstone: warm bands of different hardness, the soft ones eroded back, cross-bedding swirls.
    const float warp = fbm(u, v, 3, 4, 221) * 0.08f;
    const float band = v * 18.0f + warp * 18.0f + fbm(u, v, 2, 3, 222) * 1.5f;
    const float layer = fractf(band);
    const float hard = idF(hashU(int(std::floor(band)), 0, 223));
    const float grain = fbm01(u, v, 300, 2, 224);
    const float erode = sstep(0.0f, 0.25f, layer) * sstep(1.0f, 0.75f, layer);
    glm::vec3 c = glm::mix(rgb(176, 120, 76), rgb(222, 172, 118), hard);
    c = glm::mix(c, rgb(200, 150, 110), sstep(0.7f, 0.95f, fbm01(u, v, 8, 3, 225)) * 0.4f);
    c *= 0.88f + 0.14f * grain;
    const float h = sat(0.3f + 0.35f * hard * erode + 0.2f * erode + 0.1f * grain);
    return { c, h, 0.9f, 0.0f };
}

Texel slate(float u, float v) {
    // Split slate flagstones: irregular rectangles of layered dark grey-blue stone, chipped edges, flaky surface.
    const Piece p = course(u + fbm(u, v, 6, 2, 231) * 0.01f, v, 3, 6, 0.37f);
    const float edge = p.edge + (fbm01(u, v, 48, 3, 232) - 0.5f) * 0.06f;
    const float joint = 1.0f - sstep(0.03f, 0.06f, edge);
    const float flake = ridged(u, v, 30, 3, 233 + p.row);
    const float r = idF(p.id);
    glm::vec3 c = glm::mix(rgb(62, 66, 74), rgb(96, 100, 108), r) * (0.82f + 0.25f * flake);
    c = glm::mix(c, rgb(46, 42, 38), joint);
    const float h = sat(joint > 0.5f ? 0.1f : 0.5f + 0.25f * flake * 0.5f + 0.15f * r + 0.15f * sstep(0.03f, 0.15f, edge));
    return { c, h, 0.7f + 0.15f * flake, 0.0f };
}

Texel bark(float u, float v) {
    // Tree bark: long vertical fissures between thick ridged plates, grey-brown, with green algae on the ridges.
    const glm::vec2 w(u + fbm(u, v, 3, 3, 241) * 0.04f, v);
    const float f = std::fabs(pnoise(w.x, w.y, 9, 2, 242)) + 0.5f * std::fabs(pnoise(w.x, w.y, 18, 3, 246));
    const float fissure = 1.0f - sstep(0.0f, 0.22f, f);                    // deep, narrow cracks running up the trunk
    const float plate = fbmA(w.x, w.y, 10, 3, 4, 243) * 0.5f + 0.5f;
    const float fine = fbmA(u, v, 160, 24, 3, 244) * 0.5f + 0.5f;
    const float algae = sstep(0.62f, 0.78f, fbm01(u, v, 6, 3, 245)) * (1.0f - fissure);
    glm::vec3 c = glm::mix(rgb(84, 70, 58), rgb(128, 116, 102), plate) * (0.82f + 0.25f * fine);
    c = glm::mix(c, rgb(30, 24, 20), fissure);
    c = glm::mix(c, rgb(96, 112, 64), algae * 0.5f);
    const float h = sat(0.75f - 0.65f * fissure + 0.12f * plate + 0.08f * fine);
    return { c, h, 0.9f, 0.0f };
}

Texel rust(float u, float v) {
    // Rusting steel: bare metal where it's been rubbed, orange-brown rust blooming in patches, flaking scale.
    const float patch = fbm01(u, v, 4, 6, 251);
    const float rustAmt = sstep(0.38f, 0.62f, patch);
    const float flake = ridged(u, v, 40, 3, 252);
    const float pit = sstep(0.75f, 0.85f, fbm01(u, v, 200, 2, 253));
    const float brush = pnoise(u, v, 4, 900, 254) * 0.5f + 0.5f;
    glm::vec3 steel = rgb(128, 130, 134) * (0.9f + 0.1f * brush);
    glm::vec3 rustC = glm::mix(rgb(110, 50, 24), rgb(176, 96, 44), flake) * (0.8f + 0.3f * fbm01(u, v, 60, 3, 255));
    glm::vec3 c = glm::mix(steel, rustC, rustAmt);
    c = glm::mix(c, rgb(60, 32, 20), pit * rustAmt);
    const float h = sat(0.5f + rustAmt * (0.15f + 0.2f * flake) - pit * 0.2f);
    return { c, h, glm::mix(0.38f, 0.92f, rustAmt), 1.0f - rustAmt };
}

Texel roofTiles(float u, float v) {
    // Clay roof tiles: overlapping rows, each tile curved across, darker under the lip of the row above.
    const Piece p = course(u, v, 8, 10, 0.5f);
    const float r = idF(p.id);
    const float across = std::sin(p.local.x * 3.14159f);
    const float down = p.local.y;                                           // 0 at the top of the tile (under the row above)
    const float lip = sstep(0.0f, 0.18f, down);
    const float gap = 1.0f - sstep(0.0f, 0.025f, std::min(p.local.x, 1.0f - p.local.x));
    const float weather = fbm01(u, v, 30, 4, 261);
    glm::vec3 c = glm::mix(rgb(150, 66, 40), rgb(196, 104, 62), r) * (0.75f + 0.25f * across) * (0.55f + 0.45f * lip);
    c = glm::mix(c, rgb(110, 110, 90), sstep(0.7f, 0.9f, weather) * 0.3f);
    c = glm::mix(c, rgb(40, 24, 18), gap * 0.8f);
    const float h = sat(0.25f + 0.45f * across * lip + 0.25f * down - gap * 0.3f);
    return { c, h, 0.78f + 0.12f * weather, 0.0f };
}

Texel leaves(float u, float v) {
    // A canopy of leaves: overlapping pointed ovals at every angle, each its own green, shade in between.
    float bestH = 0.0f; glm::vec3 col = rgb(24, 40, 14);
    float rough = 0.7f;
    for (int layer = 0; layer < 3; ++layer) {
        const Cell c = worley(u, v, 22 + layer * 7, 271 + std::uint32_t(layer) * 13, 0.95f);
        const float a = idF(c.id) * kTau;
        const glm::vec2 d(-c.toPoint.x, -c.toPoint.y);
        const glm::vec2 q(d.x * std::cos(a) + d.y * std::sin(a), -d.x * std::sin(a) + d.y * std::cos(a));
        const float leaf = 1.0f - (q.x * q.x / 0.22f + q.y * q.y / 0.05f) - std::fabs(q.x) * 0.6f;
        if (leaf > 0.0f) {
            const float h = 0.3f + 0.25f * float(layer) + 0.3f * leaf;
            if (h > bestH) {
                bestH = h;
                const float vein = 1.0f - sstep(0.0f, 0.02f, std::fabs(q.y));
                const float t = idF(c.id, 4);
                col = glm::mix(rgb(46, 84, 26), rgb(104, 140, 44), t) * (0.75f + 0.35f * leaf);
                col = glm::mix(col, col * 1.25f, vein * 0.5f);
                rough = 0.55f + 0.2f * t;
            }
        }
    }
    return { col, bestH, rough, 0.0f };
}


Texel glass(float u, float v) {
    // Window glass: dark (you see mostly the reflection and a dim room behind), faint wipe marks, dust in the corners
    // of the pane, and very slightly wavy so reflections are not dead flat.
    const float wipe = fbmA(u, v, 3, 9, 3, 701);
    const float dust = sstep(0.55f, 0.85f, fbm01(u, v, 24, 3, 702));
    const float wave = fbm01(u, v, 2, 3, 703);
    glm::vec3 c = glm::mix(rgb(18, 22, 26), rgb(30, 34, 38), wave);
    c = glm::mix(c, rgb(92, 90, 84), dust * 0.25f);
    const float h = sat(0.5f + 0.04f * wave);
    return { c, h, sat(0.03f + 0.05f * (wipe * 0.5f + 0.5f) + dust * 0.35f), 0.0f };
}

Texel skin(float u, float v) {
    // Human skin, near white so a person's skin colour tints it: pores, fine creases, faint blotches of redness
    // and freckle-scale variation. Slightly oily (rougher in the pores).
    const Cell pore = worley(u, v, 90, 711, 0.95f);
    const float poreD = 1.0f - sstep(0.0f, 0.22f, pore.f1);
    const float crease = 1.0f - sstep(0.0f, 0.03f, std::fabs(fbmA(u, v, 4, 30, 3, 712)));
    const float blotch = fbm01(u, v, 5, 4, 713);
    const float fine = fbm01(u, v, 160, 2, 714);
    glm::vec3 c = glm::mix(rgb(236, 222, 214), rgb(240, 210, 200), sstep(0.4f, 0.8f, blotch));   // a touch of redness
    c *= 0.96f + 0.06f * fine - 0.05f * poreD - 0.03f * crease;
    const float h = sat(0.55f + 0.08f * fine - 0.25f * poreD - 0.12f * crease);
    return { c, h, sat(0.48f + 0.12f * poreD + 0.08f * (1.0f - fine)), 0.0f };
}

Texel hair(float u, float v) {
    // Hair: thousands of strands running one way, clumped, with lighter and darker strands and a slight wave.
    const float wave = fbm(u, v, 3, 3, 721) * 0.04f;
    const float uu = u + wave;
    const float strand = 0.5f + 0.5f * pnoise(uu, v, 260, 6, 722);
    const float strand2 = 0.5f + 0.5f * pnoise(uu, v, 520, 10, 723);
    const float clump = 0.5f + 0.5f * pnoise(uu, v, 24, 2, 724);
    const float tone = fbm01(u, v, 6, 3, 725);
    const float s = strand * 0.6f + strand2 * 0.4f;
    glm::vec3 c = glm::vec3(0.86f) * (0.62f + 0.38f * s) * (0.82f + 0.18f * clump) * (0.9f + 0.1f * tone);
    const float h = sat(0.25f + 0.45f * s + 0.25f * clump);
    return { c, h, sat(0.38f + 0.2f * (1.0f - s)), 0.0f };
}

Texel leather(float u, float v) {
    // Tanned leather: a pebbled grain of tiny cells, creases where it bends, worn lighter on the high spots.
    const Cell grain = worley(u, v, 70, 731, 0.9f);
    const float g = sstep(0.0f, 0.45f, grain.f2 - grain.f1);
    const float crease = 1.0f - sstep(0.0f, 0.04f, std::fabs(fbm(u, v, 5, 3, 732)));
    const float wear = sstep(0.55f, 0.85f, fbm01(u, v, 6, 3, 733));
    glm::vec3 c = rgb(200, 188, 176) * (0.84f + 0.16f * g) * (1.0f - 0.18f * crease);
    c = glm::mix(c, c * 1.12f, wear * g);
    const float h = sat(0.35f + 0.3f * g - 0.2f * crease);
    return { c, h, sat(0.55f - 0.15f * wear * g + 0.15f * crease), 0.0f };
}


Texel polished(float u, float v) {
    // Polished metal (gold, brass, steel - the tint decides): fine scratches in every direction, a few fingerprints'
    // worth of smudge, otherwise a clean mirror-ish surface.
    float scratch = 0.0f;
    for (int i = 0; i < 3; ++i) {
        const float a = 0.7f + 1.3f * float(i);
        const float uu = u * std::cos(a) - v * std::sin(a);
        scratch = std::max(scratch, sstep(0.82f, 0.98f, 0.5f + 0.5f * pnoise(uu + float(i) * 0.31f, v * 0.02f + u * 0.01f, 300, 4, 741 + std::uint32_t(i))));
    }
    const float smudge = sstep(0.5f, 0.85f, fbm01(u, v, 6, 3, 745));
    const float tone = fbm01(u, v, 4, 3, 746);
    glm::vec3 c = glm::vec3(0.92f) * (0.94f + 0.06f * tone);
    return { c, 0.5f + 0.02f * scratch, sat(0.16f + 0.14f * scratch + 0.18f * smudge), 1.0f };
}

// ================================================================== the layer table

using Gen = Texel (*)(float, float);
struct Layer { const char* name; Gen gen; float bump; float occlusion; float metres; };
// bump: how deep the relief is, as a fraction of the texture's width. metres: how much of the world one repeat covers,
// so a brick is the size of a brick and a pebble the size of a pebble.
const Layer kLayers[kTextureImages] = {
    { "grass",       grass,       0.018f, 0.9f, 2.0f },
    { "dirt",        dirt,        0.012f, 0.9f, 2.5f },
    { "stone",       stone,       0.022f, 1.0f, 4.0f },
    { "sand",        sand,        0.006f, 0.6f, 3.0f },
    { "snow",        snow,        0.016f, 0.6f, 4.0f },
    { "wood",        wood,        0.010f, 0.8f, 2.0f },
    { "metal",       metal,       0.006f, 0.6f, 2.0f },
    { "brick",       brick,       0.016f, 1.0f, 1.8f },
    { "plaster",     plaster,     0.006f, 0.6f, 3.0f },
    { "tile",        tile,        0.008f, 0.7f, 2.4f },
    { "cloth",       cloth,       0.008f, 0.7f, 0.6f },
    { "ice",         ice,         0.006f, 0.4f, 3.0f },
    { "lava",        lava,        0.018f, 0.8f, 4.0f },
    { "lamp",        lamp,        0.004f, 0.3f, 1.2f },
    { "crystal",     crystal,     0.012f, 0.5f, 2.0f },
    { "moss",        moss,        0.014f, 1.0f, 1.5f },
    { "gravel",      gravel,      0.016f, 1.0f, 1.0f },
    { "mud",         mud,         0.022f, 0.9f, 3.0f },
    { "cobblestone", cobblestone, 0.022f, 1.0f, 2.5f },
    { "marble",      marble,      0.002f, 0.2f, 2.0f },
    { "concrete",    concrete,    0.008f, 0.8f, 3.0f },
    { "sandstone",   sandstone,   0.016f, 0.9f, 4.0f },
    { "slate",       slate,       0.016f, 0.9f, 2.4f },
    { "bark",        bark,        0.026f, 1.0f, 1.5f },
    { "rust",        rust,        0.012f, 0.8f, 2.0f },
    { "roof tiles",  roofTiles,   0.022f, 1.0f, 2.4f },
    { "leaves",      leaves,      0.018f, 1.0f, 1.5f },
    { "glass",       glass,       0.001f, 0.1f, 2.0f },
    { "skin",        skin,        0.006f, 0.4f, 0.9f },
    { "hair",        hair,        0.014f, 0.9f, 0.9f },
    { "leather",     leather,     0.008f, 0.6f, 0.9f },
    { "polished",    polished,    0.001f, 0.1f, 1.0f },
};

std::uint8_t toByte(float x) { return std::uint8_t(std::lround(sat(x) * 255.0f)); }

} // namespace

const char* textureLayerName(int layer) { return layer >= 0 && layer < kTextureImages ? kLayers[layer].name : ""; }
float textureLayerMetres(int layer) { return layer >= 0 && layer < kTextureImages ? kLayers[layer].metres : 4.0f; }

void deriveNormalFromHeight(MaterialImage& im, float strength) {
    const int n = im.size;
    if (n <= 0 || im.albedo.size() < size_t(n) * n * 4) return;
    im.normal.assign(size_t(n) * n * 4, 0);
    auto H = [&](int x, int y) { return float(im.albedo[(size_t(wrap(y, n)) * n + size_t(wrap(x, n))) * 4 + 3]) / 255.0f; };
    // The slope per texture width (Sobel), times how deep the relief is: the same bumps at any resolution.
    const float k = strength * float(n) * 0.125f;
    for (int y = 0; y < n; ++y)
        for (int x = 0; x < n; ++x) {
            const float dx = (H(x + 1, y - 1) + 2 * H(x + 1, y) + H(x + 1, y + 1)) - (H(x - 1, y - 1) + 2 * H(x - 1, y) + H(x - 1, y + 1));
            const float dy = (H(x - 1, y + 1) + 2 * H(x, y + 1) + H(x + 1, y + 1)) - (H(x - 1, y - 1) + 2 * H(x, y - 1) + H(x + 1, y - 1));
            const glm::vec3 nrm = glm::normalize(glm::vec3(-dx * k, dy * k, 1.0f));   // +y up in the image is -y in texels
            std::uint8_t* px = &im.normal[(size_t(y) * n + x) * 4];
            px[0] = toByte(nrm.x * 0.5f + 0.5f); px[1] = toByte(nrm.y * 0.5f + 0.5f); px[2] = toByte(nrm.z * 0.5f + 0.5f); px[3] = 255;
        }
}

void deriveOcclusionFromHeight(MaterialImage& im, float strength) {
    const int n = im.size;
    if (n <= 0 || im.albedo.size() < size_t(n) * n * 4) return;
    if (im.surface.size() != size_t(n) * n * 4) { im.surface.assign(size_t(n) * n * 4, 0); for (size_t i = 0; i < im.surface.size(); i += 4) im.surface[i + 3] = 200; }
    // Hollows are darker than what is around them: the height against its blur, at two scales.
    std::vector<float> h(size_t(n) * n), tmp(size_t(n) * n), blur(size_t(n) * n), blur2(size_t(n) * n);
    for (size_t i = 0; i < h.size(); ++i) h[i] = float(im.albedo[i * 4 + 3]) / 255.0f;
    auto boxBlur = [&](const std::vector<float>& src, std::vector<float>& dst, int r) {
        const float inv = 1.0f / float(2 * r + 1);
        for (int y = 0; y < n; ++y) {
            float acc = 0; for (int i = -r; i <= r; ++i) acc += src[size_t(y) * n + size_t(wrap(i, n))];
            for (int x = 0; x < n; ++x) {
                tmp[size_t(y) * n + x] = acc * inv;
                acc += src[size_t(y) * n + size_t(wrap(x + r + 1, n))] - src[size_t(y) * n + size_t(wrap(x - r, n))];
            }
        }
        for (int x = 0; x < n; ++x) {
            float acc = 0; for (int i = -r; i <= r; ++i) acc += tmp[size_t(wrap(i, n)) * n + x];
            for (int y = 0; y < n; ++y) {
                dst[size_t(y) * n + x] = acc * inv;
                acc += tmp[size_t(wrap(y + r + 1, n)) * n + x] - tmp[size_t(wrap(y - r, n)) * n + x];
            }
        }
    };
    boxBlur(h, blur, std::max(1, n / 128));
    boxBlur(h, blur2, std::max(2, n / 32));
    for (size_t i = 0; i < h.size(); ++i) {
        const float cav = std::max(0.0f, blur[i] - h[i]) * 3.0f + std::max(0.0f, blur2[i] - h[i]) * 1.5f;
        im.surface[i * 4 + 0] = toByte(1.0f - sat(cav * strength));
    }
}

MaterialImage resizeMaterialImage(const MaterialImage& src, int size) {
    MaterialImage out;
    out.size = size;
    const int n = src.size;
    auto resample = [&](const std::vector<std::uint8_t>& in, std::vector<std::uint8_t>& dst, bool normal) {
        dst.assign(size_t(size) * size * 4, 0);
        if (n <= 0 || in.size() < size_t(n) * n * 4) return;
        const float k = float(n) / float(size);
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x) {
                // Going down in size, average the footprint; going up, blend the four nearest.
                float acc[4] = { 0, 0, 0, 0 }, wsum = 0.0f;
                const int span = std::max(1, int(std::ceil(k)));
                const float fx = (float(x) + 0.5f) * k - 0.5f, fy = (float(y) + 0.5f) * k - 0.5f;
                const int x0 = int(std::floor(fx - float(span - 1) * 0.5f)), y0 = int(std::floor(fy - float(span - 1) * 0.5f));
                for (int j = 0; j <= span; ++j)
                    for (int i = 0; i <= span; ++i) {
                        const float wx = std::max(0.0f, 1.0f - std::fabs(float(x0 + i) - fx) / float(span));
                        const float wy = std::max(0.0f, 1.0f - std::fabs(float(y0 + j) - fy) / float(span));
                        const float w = wx * wy;
                        if (w <= 0.0f) continue;
                        const std::uint8_t* p = &in[(size_t(wrap(y0 + j, n)) * n + size_t(wrap(x0 + i, n))) * 4];
                        for (int c = 0; c < 4; ++c) acc[c] += float(p[c]) * w;
                        wsum += w;
                    }
                std::uint8_t* d = &dst[(size_t(y) * size + x) * 4];
                for (int c = 0; c < 4; ++c) acc[c] /= std::max(wsum, 1e-6f);
                if (normal) {
                    glm::vec3 v(acc[0] / 127.5f - 1.0f, acc[1] / 127.5f - 1.0f, acc[2] / 127.5f - 1.0f);
                    v = glm::length(v) > 1e-5f ? glm::normalize(v) : glm::vec3(0, 0, 1);
                    acc[0] = (v.x * 0.5f + 0.5f) * 255.0f; acc[1] = (v.y * 0.5f + 0.5f) * 255.0f; acc[2] = (v.z * 0.5f + 0.5f) * 255.0f; acc[3] = 255.0f;
                }
                for (int c = 0; c < 4; ++c) d[c] = std::uint8_t(std::lround(std::clamp(acc[c], 0.0f, 255.0f)));
            }
    };
    resample(src.albedo, out.albedo, false);
    resample(src.normal, out.normal, true);
    resample(src.surface, out.surface, false);
    return out;
}

MaterialImage generateMaterialImage(int layer, int size, const std::atomic<bool>* cancel) {
    MaterialImage im;
    im.size = size;
    im.albedo.resize(size_t(size) * size * 4);
    im.surface.resize(size_t(size) * size * 4);
    if (layer < 0 || layer >= kTextureImages) return im;
    const Gen gen = kLayers[layer].gen;
    const float inv = 1.0f / float(size);
    for (int y = 0; y < size; ++y) {
        if (cancel && cancel->load(std::memory_order_relaxed)) return im;
        for (int x = 0; x < size; ++x) {
            const Texel t = gen((float(x) + 0.5f) * inv, (float(y) + 0.5f) * inv);
            std::uint8_t* a = &im.albedo[(size_t(y) * size + x) * 4];
            a[0] = toByte(t.color.r); a[1] = toByte(t.color.g); a[2] = toByte(t.color.b); a[3] = toByte(t.height);
            std::uint8_t* s = &im.surface[(size_t(y) * size + x) * 4];
            s[0] = 255; s[1] = toByte(t.metal); s[2] = 0; s[3] = toByte(t.rough);
        }
    }
    deriveNormalFromHeight(im, kLayers[layer].bump);
    deriveOcclusionFromHeight(im, kLayers[layer].occlusion);
    return im;
}

std::vector<MaterialImage> generateMaterialImages(int size, int threads, const std::atomic<bool>* cancel) {
    std::vector<MaterialImage> out(kTextureImages);
    const int hw = int(std::thread::hardware_concurrency());
    const int n = std::clamp(threads > 0 ? threads : hw, 1, 64);
    std::atomic<int> next{ 0 };
    std::vector<std::thread> pool;
    for (int t = 0; t < n; ++t)
        pool.emplace_back([&] {
            for (int l = next++; l < kTextureImages; l = next++) out[size_t(l)] = generateMaterialImage(l, size, cancel);
        });
    for (auto& t : pool) t.join();
    return out;
}

} // namespace px
