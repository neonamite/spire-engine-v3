#pragma once
#include <string>
#include <glad/glad.h>
#include <glm/glm.hpp>

namespace px {

// Small wrapper that compiles a program and reports GLSL errors to the console
// (the old code silently ignored shader errors, which made bugs invisible).
class Shader {
public:
    bool build(const char* vertexSrc, const char* fragmentSrc, const char* debugName);
    void destroy();
    void use() const { glUseProgram(program); }

    void set(const char* name, int v) const        { glUniform1i(glGetUniformLocation(program, name), v); }
    void set(const char* name, float v) const      { glUniform1f(glGetUniformLocation(program, name), v); }
    void set(const char* name, const glm::vec2& v) const { glUniform2f(glGetUniformLocation(program, name), v.x, v.y); }
    void set(const char* name, const glm::vec4& v) const { glUniform4f(glGetUniformLocation(program, name), v.x, v.y, v.z, v.w); }
    void set(const char* name, const glm::vec3& v) const { glUniform3f(glGetUniformLocation(program, name), v.x, v.y, v.z); }
    void set(const char* name, const glm::mat3& m) const { glUniformMatrix3fv(glGetUniformLocation(program, name), 1, GL_FALSE, &m[0][0]); }
    void set(const char* name, const glm::mat4& m) const { glUniformMatrix4fv(glGetUniformLocation(program, name), 1, GL_FALSE, &m[0][0]); }

    GLuint program = 0;
};

} // namespace px
