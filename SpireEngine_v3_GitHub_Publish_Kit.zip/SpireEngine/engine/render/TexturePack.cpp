#include "render/TexturePack.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <filesystem>
#include <functional>
#include "world/Materials.h"

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_PSD
#define STBI_NO_GIF
#define STBI_NO_PIC
#define STBI_NO_PNM
#define STBI_NO_HDR
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmisleading-indentation"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic ignored "-Wsign-compare"
#pragma GCC diagnostic ignored "-Wconversion"
#endif
#include "third_party/stb/stb_image.h"
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic pop
#endif

namespace fs = std::filesystem;

namespace px {

namespace {

std::string lower(std::string s) {
    for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

bool isPicture(const fs::path& p) {
    const std::string e = lower(p.extension().string());
    return e == ".png" || e == ".jpg" || e == ".jpeg" || e == ".tga" || e == ".bmp";
}

// Is `word` in `name` as a word of its own (between separators), e.g. "ao" in "rock_ao_4k" but not in "chaos"?
bool hasWord(const std::string& name, const std::string& word) {
    size_t at = 0;
    while ((at = name.find(word, at)) != std::string::npos) {
        const bool startOk = at == 0 || !std::isalpha(static_cast<unsigned char>(name[at - 1]));
        const size_t end = at + word.size();
        const bool endOk = end >= name.size() || !std::isalpha(static_cast<unsigned char>(name[end]));
        if (startOk && endOk) return true;
        at = end;
    }
    return false;
}
bool hasAny(const std::string& n, std::initializer_list<const char*> words, bool wholeWord) {
    for (const char* w : words) if (wholeWord ? hasWord(n, w) : n.find(w) != std::string::npos) return true;
    return false;
}

// Files at the newest change time and their sizes, rolled into one number: the cache key changes when the pack does.
std::uint64_t mix64(std::uint64_t h, std::uint64_t v) { h ^= v + 0x9e3779b97f4a7c15ull + (h << 6) + (h >> 2); return h; }

struct Picture {
    int w = 0, h = 0;
    std::vector<std::uint8_t> px;     // RGBA8
    bool ok() const { return w > 0 && h > 0; }
};

Picture readPicture(const std::string& path, std::string* error) {
    Picture p;
    int comps = 0;
    stbi_uc* data = stbi_load(path.c_str(), &p.w, &p.h, &comps, 4);
    if (!data) {
        if (error) *error = fs::path(path).filename().string() + ": " + (stbi_failure_reason() ? stbi_failure_reason() : "could not be read");
        p.w = p.h = 0;
        return p;
    }
    p.px.assign(data, data + size_t(p.w) * size_t(p.h) * 4);
    stbi_image_free(data);
    return p;
}

// Scales a picture to size x size: halves with a box filter while it is at least twice too big (no shimmering
// from skipped pixels), then a bilinear pass that wraps at the edges (so a tiling picture still tiles).
Picture fitPicture(Picture p, int size) {
    while (p.w >= size * 2 && p.h >= size * 2) {
        Picture q;
        q.w = p.w / 2; q.h = p.h / 2;
        q.px.resize(size_t(q.w) * q.h * 4);
        for (int y = 0; y < q.h; ++y)
            for (int x = 0; x < q.w; ++x)
                for (int c = 0; c < 4; ++c) {
                    const auto at = [&](int xx, int yy) { return int(p.px[(size_t(yy) * p.w + xx) * 4 + c]); };
                    q.px[(size_t(y) * q.w + x) * 4 + c] = std::uint8_t((at(2 * x, 2 * y) + at(2 * x + 1, 2 * y) + at(2 * x, 2 * y + 1) + at(2 * x + 1, 2 * y + 1) + 2) / 4);
                }
        p = std::move(q);
    }
    if (p.w == size && p.h == size) return p;
    Picture q;
    q.w = q.h = size;
    q.px.resize(size_t(size) * size * 4);
    const float sx = float(p.w) / float(size), sy = float(p.h) / float(size);
    for (int y = 0; y < size; ++y)
        for (int x = 0; x < size; ++x) {
            const float fx = (float(x) + 0.5f) * sx - 0.5f, fy = (float(y) + 0.5f) * sy - 0.5f;
            const int x0 = int(std::floor(fx)), y0 = int(std::floor(fy));
            const float tx = fx - float(x0), ty = fy - float(y0);
            const int xa = ((x0 % p.w) + p.w) % p.w, xb = (xa + 1) % p.w, ya = ((y0 % p.h) + p.h) % p.h, yb = (ya + 1) % p.h;
            for (int c = 0; c < 4; ++c) {
                const auto at = [&](int xx, int yy) { return float(p.px[(size_t(yy) * p.w + xx) * 4 + c]); };
                const float v = (at(xa, ya) * (1 - tx) + at(xb, ya) * tx) * (1 - ty) + (at(xa, yb) * (1 - tx) + at(xb, yb) * tx) * ty;
                q.px[(size_t(y) * size + x) * 4 + c] = std::uint8_t(std::clamp(v + 0.5f, 0.0f, 255.0f));
            }
        }
    return q;
}

std::uint8_t luma(const std::uint8_t* px) { return std::uint8_t((54 * px[0] + 183 * px[1] + 19 * px[2]) >> 8); }

} // namespace

std::string texturePackRoot() { return "textures"; }

int textureLayerFromName(const std::string& nameIn) {
    const auto norm = [](std::string s) { s = lower(std::move(s)); for (char& c : s) if (c == ' ' || c == '-') c = '_'; return s; };
    const std::string n = norm(nameIn);
    for (int i = 0; i < kTextureImages; ++i) if (n == norm(textureLayerName(i))) return i;
    if (!n.empty() && n.back() == 's') {                                  // plurals: bricks, tiles, leaves stays itself
        const std::string one = n.substr(0, n.size() - 1);
        for (int i = 0; i < kTextureImages; ++i) if (one == norm(textureLayerName(i))) return i;
    }
    static const struct { const char* alias; const char* layer; } kAliases[] = {
        { "rock", "stone" }, { "rocks", "stone" }, { "ground", "dirt" }, { "soil", "dirt" }, { "earth", "dirt" },
        { "planks", "wood" }, { "wood_planks", "wood" }, { "floor", "wood" }, { "fabric", "cloth" }, { "carpet", "cloth" },
        { "roof", "roof_tiles" }, { "rooftiles", "roof_tiles" }, { "roof_tile", "roof_tiles" }, { "cobble", "cobblestone" },
        { "cobblestones", "cobblestone" }, { "paving", "cobblestone" }, { "pebbles", "gravel" }, { "foliage", "leaves" },
        { "tree_bark", "bark" }, { "rusty_metal", "rust" }, { "glass", "crystal" }, { "magma", "lava" },
    };
    for (const auto& a : kAliases)
        if (n == a.alias)
            for (int i = 0; i < kTextureImages; ++i) if (std::string(a.layer) == norm(textureLayerName(i))) return i;
    return -1;
}

std::vector<std::string> listTexturePacks(const std::string& root) {
    std::vector<std::string> out;
    std::error_code ec;
    if (!fs::is_directory(root, ec)) return out;
    for (fs::directory_iterator it(root, ec), end; !ec && it != end; it.increment(ec))
        if (it->is_directory(ec)) out.push_back(it->path().filename().string());
    std::sort(out.begin(), out.end());
    return out;
}

TexturePack scanTexturePack(const std::string& folder) {
    TexturePack pack;
    pack.folder = folder;
    pack.name = fs::path(folder).filename().string();
    pack.layers.resize(size_t(kTextureImages));
    std::uint64_t key = 1469598103934665603ull;
    std::error_code ec;
    if (!fs::is_directory(folder, ec)) return pack;

    std::vector<fs::path> dirs;
    for (fs::directory_iterator it(folder, ec), end; !ec && it != end; it.increment(ec))
        if (it->is_directory(ec)) dirs.push_back(it->path());
    std::sort(dirs.begin(), dirs.end());
    for (const fs::path& dir : dirs) {
        const int layer = textureLayerFromName(dir.filename().string());
        if (layer < 0) { pack.unknownFolders.push_back(dir.filename().string()); continue; }
        TexturePackLayer& L = pack.layers[size_t(layer)];
        std::vector<fs::path> files;
        std::error_code ec2;
        for (fs::directory_iterator it(dir, ec2), end; !ec2 && it != end; it.increment(ec2))
            if (it->is_regular_file(ec2) && isPicture(it->path())) files.push_back(it->path());
        std::sort(files.begin(), files.end());
        for (const fs::path& f : files) {
            const std::string n = lower(f.stem().string());
            const std::string path = f.string();
            // The order matters: "normal" before anything shorter, colour last (its words are the most generic).
            if (hasAny(n, { "normal", "nrm" }, false) || hasWord(n, "nor")) {
                if (L.normal.empty() || hasAny(n, { "gl" }, false)) { L.normal = path; L.normalDirectX = hasAny(n, { "dx", "directx" }, false); }
            } else if (hasWord(n, "arm")) L.arm = path;
            else if (hasAny(n, { "rough" }, false)) L.rough = path;
            else if (hasAny(n, { "gloss", "smooth" }, false)) L.gloss = path;
            else if (hasAny(n, { "height", "disp", "displacement", "bump" }, false)) L.height = path;
            else if (hasWord(n, "ao") || hasAny(n, { "occlusion", "ambientocclusion" }, false)) L.ao = path;
            else if (hasAny(n, { "metal" }, false)) L.metal = path;
            else if (hasAny(n, { "spec", "mask", "opacity", "alpha", "emission", "emissive", "preview", "thumb" }, false)) {}
            else if (hasAny(n, { "albedo", "basecolor", "base_color", "diffuse", "diff", "color", "colour" }, false) || hasWord(n, "col") || L.albedo.empty())
                L.albedo = path;
        }
        for (const fs::path& f : files) {
            std::error_code e3;
            key = mix64(key, std::hash<std::string>{}(f.string()));
            key = mix64(key, std::uint64_t(fs::file_size(f, e3)));
            key = mix64(key, std::uint64_t(fs::last_write_time(f, e3).time_since_epoch().count()));
        }
    }
    char hex[24];
    std::snprintf(hex, sizeof hex, "%016llx", static_cast<unsigned long long>(key));
    pack.key = pack.name + "#" + hex;
    return pack;
}

bool loadPackLayer(const TexturePackLayer& files, int layer, int size, MaterialImage& out, std::string* error) {
    if (!files.present() || size <= 0) return false;
    Picture colour = readPicture(files.albedo, error);
    if (!colour.ok()) return false;
    colour = fitPicture(std::move(colour), size);
    const auto optional = [&](const std::string& path) {
        Picture p;
        if (!path.empty()) { p = readPicture(path, nullptr); if (p.ok()) p = fitPicture(std::move(p), size); }
        return p;
    };
    const Picture height = optional(files.height), normal = optional(files.normal), rough = optional(files.rough),
                  gloss = optional(files.gloss), ao = optional(files.ao), metal = optional(files.metal), arm = optional(files.arm);
    const size_t n = size_t(size) * size;

    out = MaterialImage{};
    out.size = size;
    out.albedo.resize(n * 4);
    out.surface.resize(n * 4);
    // Height: the height map, or else the colour's brightness stretched to fill 0..1 (dark = low, which is
    // right for most real surfaces: mortar, cracks, the gaps between stones).
    std::uint8_t lo = 255, hi = 0;
    if (!height.ok()) for (size_t i = 0; i < n; ++i) { const std::uint8_t l = luma(&colour.px[i * 4]); lo = std::min(lo, l); hi = std::max(hi, l); }
    const float span = hi > lo ? 255.0f / float(hi - lo) : 1.0f;
    for (size_t i = 0; i < n; ++i) {
        std::uint8_t* a = &out.albedo[i * 4];
        a[0] = colour.px[i * 4]; a[1] = colour.px[i * 4 + 1]; a[2] = colour.px[i * 4 + 2];
        a[3] = height.ok() ? height.px[i * 4] : std::uint8_t(std::clamp((float(luma(&colour.px[i * 4])) - float(lo)) * span * 0.8f + 26.0f, 0.0f, 255.0f));
        std::uint8_t* s = &out.surface[i * 4];
        s[0] = ao.ok() ? ao.px[i * 4] : arm.ok() ? arm.px[i * 4] : 255;
        s[1] = metal.ok() ? metal.px[i * 4] : arm.ok() ? arm.px[i * 4 + 2] : 0;
        s[2] = 0;
        s[3] = rough.ok() ? rough.px[i * 4] : gloss.ok() ? std::uint8_t(255 - gloss.px[i * 4]) : arm.ok() ? arm.px[i * 4 + 1] : 204;
    }
    if (normal.ok()) {
        out.normal.resize(n * 4);
        for (size_t i = 0; i < n; ++i) {
            // Back to a unit vector (scaling and compression shorten them), flipping green for DirectX-style maps.
            float x = normal.px[i * 4] / 127.5f - 1.0f, y = normal.px[i * 4 + 1] / 127.5f - 1.0f, z = normal.px[i * 4 + 2] / 127.5f - 1.0f;
            if (files.normalDirectX) y = -y;
            z = std::max(z, 0.05f);
            const float len = std::sqrt(x * x + y * y + z * z);
            std::uint8_t* d = &out.normal[i * 4];
            d[0] = std::uint8_t(std::lround((x / len * 0.5f + 0.5f) * 255.0f));
            d[1] = std::uint8_t(std::lround((y / len * 0.5f + 0.5f) * 255.0f));
            d[2] = std::uint8_t(std::lround((z / len * 0.5f + 0.5f) * 255.0f));
            d[3] = 255;
        }
    } else {
        deriveNormalFromHeight(out, height.ok() ? 0.02f : 0.012f);
    }
    if (!ao.ok() && !arm.ok()) deriveOcclusionFromHeight(out, 0.6f);
    (void)layer;
    return true;
}

} // namespace px
