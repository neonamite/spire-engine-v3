#pragma once
// The material textures as the GPU wants them: every layer, every mip level, compressed (BC3 colour + height, BC5
// normals, BC3 surface: occlusion, metalness, roughness), plus a small preview per material for the palette.
//
// Building a set is pure CPU work with no GL calls, so it runs on a background thread while the editor keeps going
// with the set it already has. A finished set is cached on disk (cache/textures/), so it is built once per size.
#include <atomic>
#include <cstdint>
#include <string>
#include <vector>
#include "render/MaterialTextures.h"

namespace px {

struct TextureSet {
    static constexpr std::uint32_t kVersion = 7;     // bump when the generator or the layout changes: old caches are ignored
    int size = 0;                                    // colour and normal maps (pixels); the surface map is half this
    bool compressed = true;                          // false: plain RGBA8 / RG8 (drivers without S3TC)
    // levels[i] holds mip level i of every layer, one after the other (layer-major), ready for glCompressedTexImage3D.
    struct Map { int baseSize = 0; std::vector<std::vector<std::uint8_t>> levels; };
    Map albedo, normal, surface;
    static constexpr int kPreview = 64;
    std::vector<std::vector<std::uint8_t>> previews;  // one per material slot: kPreview x kPreview RGBA8 sRGB, tinted

    bool valid() const { return size > 0 && !albedo.levels.empty() && !normal.levels.empty() && !surface.levels.empty(); }
    int levelSize(const Map& m, int level) const { return std::max(1, m.baseSize >> level); }
};

// Generates (or takes from `images` when given: a texture pack's own pictures) and packs a set. `cancel` stops it early
// (the result is then not valid). Safe to call on any thread.
TextureSet buildTextureSet(int size, bool compress, const std::atomic<bool>* cancel = nullptr, std::vector<MaterialImage>* images = nullptr);

// The packed set of a list of finished images (texture packs; tests).
TextureSet packTextureSet(std::vector<MaterialImage>& images, bool compress, const std::atomic<bool>* cancel = nullptr);

// The disk cache. `key` says what made the set (the size, a texture pack's name and date...), so a stale file is ignored.
std::string textureCachePath(int size, bool compressed, const std::string& key = "");
bool saveTextureSet(const TextureSet& set, const std::string& path, const std::string& key);
bool loadTextureSet(TextureSet& set, const std::string& path, const std::string& key);

// The colour of one material's texture, box-filtered down to the preview size and tinted (its palette swatch).
std::vector<std::uint8_t> makeMaterialPreview(const MaterialImage& im, const float tint[3], int previewSize);

} // namespace px
