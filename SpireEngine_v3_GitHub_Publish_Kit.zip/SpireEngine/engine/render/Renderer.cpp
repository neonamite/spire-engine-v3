#include "Renderer.h"
#include "Shaders.h"
#include "MaterialTextures.h"
#include "TextureSet.h"
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <iostream>
#include "world/ChunkManager.h"
#include "core/Camera.h"
#include <algorithm>
#include <cstdlib>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {
float secondsSinceStart() {
    static const auto start = std::chrono::steady_clock::now();
    return std::chrono::duration<float>(std::chrono::steady_clock::now() - start).count();
}

// Uniforms every shader that includes kAtmosphere needs.
void setAtmosphere(const Shader& s, const glm::vec3& toSun, const RenderSettings& rs, bool under) {
    s.set("uToSun", toSun);
    s.set("uSkyIntensity", rs.skyIntensity);
    s.set("uSunIntensity", rs.sunIntensity);
    s.set("uHaze", rs.haze);
    s.set("uNight", rs.nightBrightness);
    s.set("uFogDist", rs.fogDistance);
    s.set("uFogDensity", rs.fogDensity);
    s.set("uUnder", under ? 1.0f : 0.0f);
    s.set("uWaterDeep", rs.waterDeep);
    s.set("uWaterAbsorb", 6.0f / std::max(rs.waterClarity, 1.0f));
}
} // namespace

// ------------------------------------------------------------------ setup

bool Renderer::init() {
    bool ok = true;
    ok &= planetOrbitShader.build(shaders::kPlanetOrbitVS, shaders::kPlanetOrbitFS, "planet-orbit");
    ok &= terrainShader.build(shaders::kTerrainVS.c_str(), shaders::terrainFS().c_str(), "terrain");
    ok &= depthShader.build(shaders::kDepthVS.c_str(), shaders::kDepthFS, "shadow-depth");
    ok &= skyShader.build(shaders::kFullscreenVS, shaders::skyFS().c_str(), "sky");
    ok &= waterShader.build(shaders::kFullscreenVS, shaders::waterFS().c_str(), "water");
    ok &= grassShader.build(shaders::kGrassVS, shaders::grassFS().c_str(), "grass");
    ok &= bloomDownShader.build(shaders::kFullscreenVS, shaders::kBloomDownFS, "bloom-down");
    ok &= bloomUpShader.build(shaders::kFullscreenVS, shaders::kBloomUpFS, "bloom-up");
    ok &= compositeShader.build(shaders::kFullscreenVS, shaders::kCompositeFS, "composite");
    ok &= fxaaShader.build(shaders::kFullscreenVS, shaders::kFxaaFS, "fxaa");
    ok &= prepassShader.build(shaders::kPrepassVS.c_str(), shaders::kPrepassFS, "depth-prepass");
    ok &= ssaoShader.build(shaders::kFullscreenVS, shaders::kSsaoFS, "ssao");
    ok &= ssaoBlurShader.build(shaders::kFullscreenVS, shaders::kSsaoBlurFS, "ssao-blur");
    if (!ok) return false;
    // Everything that is not a realistic body reads this for its body attributes: no UVs, no expression vertex, materials.
    glVertexAttrib4f(8, 0.0f, 0.0f, -1.0f, 0.0f);
    for (Shader* sh : { &terrainShader, &depthShader, &prepassShader }) {    // the expression shapes' unit, never the shadow map's
        sh->use();
        sh->set("uMorphs", 8);
        sh->set("uHairMap", 9);
    }
    glUseProgram(0);

    glGenFramebuffers(1, &shadowFbo);
    glGenTextures(1, &shadowMap);
    glBindTexture(GL_TEXTURE_2D, shadowMap);
    shadowRes = 4096;
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, shadowRes, shadowRes, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
    // Compared in hardware (sampler2DShadow) with bilinear filtering: every tap is already a little soft.
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);
    const float border[] = { 1, 1, 1, 1 };
    glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);
    glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowMap, 0);
    glDrawBuffer(GL_NONE);
    glReadBuffer(GL_NONE);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);

    createMaterialTextures();

    glGenVertexArrays(1, &emptyVao);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    return true;
}

// Quality presets pick the shadow map size; only the storage is replaced, the texture and its
// framebuffer attachment stay the same objects.
void Renderer::resizeShadowMap(int size) {
    size = std::clamp(size, 256, 8192);
    if (size == shadowRes || !shadowMap) return;
    shadowRes = size;
    glBindTexture(GL_TEXTURE_2D, shadowMap);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, shadowRes, shadowRes, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
}

// The driver takes S3TC (BC3) in sRGB if a tiny texture of it can be made without an error. BC5 (RGTC) is core in GL 3.
static bool driverTakesS3tc() {
    constexpr GLenum kSrgbDxt5 = 0x8C4F, kDxt5 = 0x83F3;
    while (glGetError() != GL_NO_ERROR) {}
    unsigned char block[16] = {};
    GLuint t = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D_ARRAY, t);
    glCompressedTexImage3D(GL_TEXTURE_2D_ARRAY, 0, kSrgbDxt5, 4, 4, 1, 0, 16, block);
    bool ok = glGetError() == GL_NO_ERROR;
    glCompressedTexImage3D(GL_TEXTURE_2D_ARRAY, 0, kDxt5, 4, 4, 1, 0, 16, block);
    ok = ok && glGetError() == GL_NO_ERROR;
    glDeleteTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D_ARRAY, 0);
    return ok;
}

void Renderer::createMaterialTextures() {
    canCompress = driverTakesS3tc();
    // Something to draw with straight away: a small set, built here in a moment. The real one follows in the background.
    TextureSet first = buildTextureSet(128, canCompress);
    uploadTextureSet(first);
}

void Renderer::uploadTextureSet(const TextureSet& set) {
    if (!set.valid()) return;
    constexpr GLenum kSrgbDxt5 = 0x8C4F, kDxt5 = 0x83F3, kRgtc2 = 0x8DBD;
    constexpr GLenum kMaxAniso = 0x84FF, kAniso = 0x84FE;
    GLfloat maxAniso = 0.0f;
    glGetFloatv(kMaxAniso, &maxAniso);
    while (glGetError() != GL_NO_ERROR) {}

    auto makeArray = [&](GLuint& tex, const TextureSet::Map& map, GLenum compressedFormat, GLenum plainFormat, GLenum plainLayout, int bytesPerTexel) {
        if (tex) glDeleteTextures(1, &tex);
        glGenTextures(1, &tex);
        glBindTexture(GL_TEXTURE_2D_ARRAY, tex);
        const int levels = int(map.levels.size());
        for (int lv = 0; lv < levels; ++lv) {
            const int n = set.levelSize(map, lv);
            if (set.compressed)
                glCompressedTexImage3D(GL_TEXTURE_2D_ARRAY, lv, compressedFormat, n, n, kTextureImages, 0, GLsizei(map.levels[size_t(lv)].size()), map.levels[size_t(lv)].data());
            else {
                (void)bytesPerTexel;
                glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
                glTexImage3D(GL_TEXTURE_2D_ARRAY, lv, GLint(plainFormat), n, n, kTextureImages, 0, plainLayout, GL_UNSIGNED_BYTE, map.levels[size_t(lv)].data());
            }
        }
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_BASE_LEVEL, 0);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAX_LEVEL, std::max(0, levels - 1));
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
        if (maxAniso > 1.0f) glTexParameterf(GL_TEXTURE_2D_ARRAY, kAniso, std::min(16.0f, maxAniso));   // sharp at grazing angles
        while (glGetError() != GL_NO_ERROR) {}
    };
    // Albedo is sRGB (the GPU linearises it when sampling); its alpha (height), the normals and the surface map stay linear.
    makeArray(albedoArray, set.albedo, kSrgbDxt5, GL_SRGB8_ALPHA8, GL_RGBA, 4);
    makeArray(normalArray, set.normal, kRgtc2, GL_RG8, GL_RG, 2);
    makeArray(surfaceArray, set.surface, kDxt5, GL_RGBA8, GL_RGBA, 4);

    // The palette's swatches: raw sRGB bytes, which is exactly what ImGui draws.
    for (int slot = 0; slot < kMaterialSlots && slot < int(set.previews.size()); ++slot) {
        if (!previews[slot]) glGenTextures(1, &previews[slot]);
        glBindTexture(GL_TEXTURE_2D, previews[slot]);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, TextureSet::kPreview, TextureSet::kPreview, 0, GL_RGBA, GL_UNSIGNED_BYTE, set.previews[size_t(slot)].data());
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    }
    glBindTexture(GL_TEXTURE_2D, 0);
    glBindTexture(GL_TEXTURE_2D_ARRAY, 0);
    loadedTextureSize = set.size;
}

void Renderer::requestTextures(int size) {
    size = size <= 768 ? 512 : size <= 1536 ? 1024 : size <= 3072 ? 2048 : 4096;
    if (size == requestedTextureSize) return;
    if (textureJob.joinable()) { textureCancel = true; textureJob.join(); }
    textureCancel = false; textureDone = false;
    requestedTextureSize = size;
    if (size == loadedTextureSize && !pack) return;
    const bool compress = canCompress;
    auto packNow = pack;
    textureJob = std::thread([this, size, compress, packNow] {
        // The cache first: building a set takes a while, reading one is quick.
        const std::string key = packNow ? packNow->key : std::string();
        const std::string path = textureCachePath(size, compress, key);
        std::vector<std::string> problems;
        TextureSet set;
        if (!loadTextureSet(set, path, key)) {
            if (packNow && packNow->count() > 0) {
                // The pack's pictures where it has them, the built-in textures everywhere else; all cores at once.
                std::vector<MaterialImage> images(static_cast<size_t>(kTextureImages));
                std::vector<std::string> errors(static_cast<size_t>(kTextureImages));
                std::atomic<int> next{ 0 };
                std::vector<std::thread> pool;
                const int n = std::clamp(int(std::thread::hardware_concurrency()), 1, 16);
                for (int t = 0; t < n; ++t)
                    pool.emplace_back([&] {
                        for (int i; (i = next++) < kTextureImages && !textureCancel;) {
                            const TexturePackLayer& L = packNow->layers[size_t(i)];
                            if (!L.present() || !loadPackLayer(L, i, size, images[size_t(i)], &errors[size_t(i)]))
                                images[size_t(i)] = generateMaterialImage(i, size, &textureCancel);
                        }
                    });
                for (std::thread& t : pool) t.join();
                for (int i = 0; i < kTextureImages; ++i)
                    if (!errors[size_t(i)].empty()) problems.push_back(std::string(textureLayerName(i)) + ": " + errors[size_t(i)]);
                if (!textureCancel) set = packTextureSet(images, compress, &textureCancel);
            } else {
                set = buildTextureSet(size, compress, &textureCancel);
            }
            if (set.valid() && !textureCancel) saveTextureSet(set, path, key);
        }
        if (!textureCancel) { textureResult = std::move(set); jobProblems = std::move(problems); textureDone = true; }
    });
}

void Renderer::pollTextures() {
    if (!textureJob.joinable() || !textureDone) return;
    textureJob.join();
    if (textureResult.valid()) uploadTextureSet(textureResult);
    textureResult = TextureSet{};
    packProblems = std::move(jobProblems);
    jobProblems.clear();
    textureDone = false;
}

void Renderer::finishTextures() {
    if (!textureJob.joinable()) return;
    textureJob.join();
    if (textureResult.valid()) uploadTextureSet(textureResult);
    textureResult = TextureSet{};
    packProblems = std::move(jobProblems);
    jobProblems.clear();
    textureDone = false;
}

void Renderer::useTexturePack(std::shared_ptr<const TexturePack> p) {
    if (p && p->count() == 0) p = nullptr;
    if ((!p && !pack) || (p && pack && p->key == pack->key)) return;
    pack = std::move(p);
    const int size = requestedTextureSize > 0 ? requestedTextureSize : 2048;
    requestedTextureSize = -1;                                           // make the request below happen
    loadedTextureSize = -1;
    requestTextures(size);
}

unsigned Renderer::materialPreview(MaterialId id) const {
    return (id >= 1 && id < MAT_COUNT) ? previews[id - 1] : 0u;
}

void Renderer::createTarget(Target& t, int w, int h, GLenum internalFormat, GLenum type) {
    t.w = std::max(1, w);
    t.h = std::max(1, h);
    glGenTextures(1, &t.tex);
    glBindTexture(GL_TEXTURE_2D, t.tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GLint(internalFormat), t.w, t.h, 0, GL_RGBA, type, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &t.fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, t.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t.tex, 0);
}

void Renderer::destroyTarget(Target& t) {
    if (t.fbo) glDeleteFramebuffers(1, &t.fbo);
    if (t.tex) glDeleteTextures(1, &t.tex);
    t = Target{};
}

void Renderer::resizeTargets(int w, int h) {
    if (w == targetW && h == targetH && scene.fbo) return;
    targetW = w; targetH = h;

    destroyTarget(scene);
    destroyTarget(sceneCopy);
    destroyTarget(ldr);
    for (auto& m : bloomMips) destroyTarget(m);
    bloomMips.clear();
    if (sceneDepth) glDeleteTextures(1, &sceneDepth);
    if (sceneCopyDepth) glDeleteTextures(1, &sceneCopyDepth);
    destroyTarget(ssaoRaw);
    destroyTarget(ssaoBlur);

    createTarget(sceneCopy, w, h, GL_RGBA16F, GL_FLOAT);
    glGenTextures(1, &sceneCopyDepth);
    glBindTexture(GL_TEXTURE_2D, sceneCopyDepth);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, sceneCopy.w, sceneCopy.h, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindFramebuffer(GL_FRAMEBUFFER, sceneCopy.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, sceneCopyDepth, 0);

    createTarget(scene, w, h, GL_RGBA16F, GL_FLOAT);
    glGenTextures(1, &sceneDepth);
    glBindTexture(GL_TEXTURE_2D, sceneDepth);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, scene.w, scene.h, 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindFramebuffer(GL_FRAMEBUFFER, scene.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, sceneDepth, 0);

    createTarget(ssaoRaw, std::max(1, w / 2), std::max(1, h / 2), GL_RG16F, GL_FLOAT);
    createTarget(ssaoBlur, std::max(1, w / 2), std::max(1, h / 2), GL_RG16F, GL_FLOAT);

    int bw = w, bh = h;
    for (int i = 0; i < kBloomLevels; ++i) {
        bw = std::max(1, bw / 2);
        bh = std::max(1, bh / 2);
        Target t;
        createTarget(t, bw, bh, GL_RGBA16F, GL_FLOAT);
        bloomMips.push_back(t);
    }
    createTarget(ldr, w, h, GL_RGBA8, GL_UNSIGNED_BYTE);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::shutdown() {
    if (textureJob.joinable()) { textureCancel = true; textureJob.join(); }
    for (auto& [_, m] : meshes) release(m);
    meshes.clear();
    for (auto& [_, g] : planetGpu) release(g);
    planetGpu.clear(); planetPackets.clear(); planetTriangles=0;
    for (auto& [_, g] : objectMeshes) { glDeleteBuffers(1, &g.vbo); glDeleteVertexArrays(1, &g.vao); }
    objectMeshes.clear();
    for (auto& [_, g] : skinMeshes) { glDeleteBuffers(1, &g.vbo); glDeleteBuffers(1, &g.ebo); glDeleteBuffers(1, &g.xbo); glDeleteVertexArrays(1, &g.vao); }
    skinMeshes.clear();
    GLuint texs[] = { humanMap0, humanMap1, humanEye, humanHair, morphTexture };
    glDeleteTextures(5, texs);
    glDeleteBuffers(1, &morphBuffer);
    humanMap0 = humanMap1 = humanEye = humanHair = morphTexture = morphBuffer = 0;
    humanVersion = 0;
    objects.clear();
    for (Shader* s : { &planetOrbitShader, &terrainShader, &depthShader, &skyShader, &waterShader, &grassShader, &bloomDownShader, &bloomUpShader, &compositeShader, &fxaaShader,
                       &prepassShader, &ssaoShader, &ssaoBlurShader })
        s->destroy();
    if (shadowMap) glDeleteTextures(1, &shadowMap);
    if (shadowFbo) glDeleteFramebuffers(1, &shadowFbo);
    shadowMap = shadowFbo = 0;
    destroyTarget(scene);
    destroyTarget(sceneCopy);
    destroyTarget(ldr);
    for (auto& m : bloomMips) destroyTarget(m);
    bloomMips.clear();
    destroyTarget(ssaoRaw);
    destroyTarget(ssaoBlur);
    if (sceneDepth) glDeleteTextures(1, &sceneDepth);
    if (sceneCopyDepth) glDeleteTextures(1, &sceneCopyDepth);
    sceneCopyDepth = 0;
    if (emptyVao) glDeleteVertexArrays(1, &emptyVao);
    if (albedoArray) glDeleteTextures(1, &albedoArray);
    if (normalArray) glDeleteTextures(1, &normalArray);
    if (surfaceArray) glDeleteTextures(1, &surfaceArray);
    glDeleteTextures(kMaterialSlots, previews);
    albedoArray = normalArray = surfaceArray = 0;
    for (auto& p : previews) p = 0;
    sceneDepth = emptyVao = 0;
    targetW = targetH = 0;
}

// ------------------------------------------------------------------ meshes

void Renderer::release(GpuMesh& m) {
    if (m.vbo) glDeleteBuffers(1, &m.vbo);
    if (m.vao) glDeleteVertexArrays(1, &m.vao);
    if (m.grassVbo) glDeleteBuffers(1, &m.grassVbo);
    if (m.grassVao) glDeleteVertexArrays(1, &m.grassVao);
    m = GpuMesh{};
}

void Renderer::upload(GpuMesh& m, const VoxelChunk& c, std::uint32_t generation) {
    if (!m.vao) {
        glGenVertexArrays(1, &m.vao);
        glGenBuffers(1, &m.vbo);
        glBindVertexArray(m.vao);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, ao));
        glEnableVertexAttribArray(2);
        glVertexAttribPointer(3, 4, GL_UNSIGNED_BYTE, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, layers));  // 0..7 as floats
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(4, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), (void*)offsetof(Vertex, bary));     // 0..1
        glEnableVertexAttribArray(4);
    }
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(c.mesh.size() * sizeof(Vertex)), c.mesh.data(), GL_STATIC_DRAW);
    m.vertexCount = GLsizei(c.mesh.size());

    // Grass instances (one 20-byte record per blade; the blade shape comes from gl_VertexID).
    if (!c.grass.empty() && !m.grassVao) {
        glGenVertexArrays(1, &m.grassVao);
        glGenBuffers(1, &m.grassVbo);
        glBindVertexArray(m.grassVao);
        glBindBuffer(GL_ARRAY_BUFFER, m.grassVbo);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(GrassBlade), (void*)offsetof(GrassBlade, x));
        glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(GrassBlade), (void*)offsetof(GrassBlade, seed));
        glVertexAttribPointer(2, 2, GL_BYTE, GL_TRUE, sizeof(GrassBlade), (void*)offsetof(GrassBlade, nx));
        for (GLuint i = 0; i < 3; ++i) { glEnableVertexAttribArray(i); glVertexAttribDivisor(i, 1); }
    }
    if (m.grassVao) {
        glBindBuffer(GL_ARRAY_BUFFER, m.grassVbo);
        glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(c.grass.size() * sizeof(GrassBlade)), c.grass.data(), GL_STATIC_DRAW);
    }
    m.grassCount = GLsizei(c.grass.size());
    m.center = glm::vec3(c.origin()) + glm::vec3(CHUNK_SIZE * 0.5f);
    m.source = &c;
    m.version = c.meshVersion;
    m.generation = generation;
}

void Renderer::sync(const ChunkManager& world) {
    const auto& chunks = world.chunks();
    for (auto it = meshes.begin(); it != meshes.end();) {
        if (!chunks.count(it->first)) { release(it->second); it = meshes.erase(it); }
        else ++it;
    }
    int uploads = 0;
    for (const auto& [coord, chunk] : chunks) {
        GpuMesh& m = meshes[coord];
        const bool stale = m.source != chunk.get() || m.version != chunk->meshVersion || m.generation != world.generation();
        if (!stale) continue;
        upload(m, *chunk, world.generation());
        if (++uploads > 64) break; // spread big bursts over several frames
    }
}

// C11: renderer owns ALL OpenGL buffers and uploads only a few immutable
// patches per frame. CPU patch vertices are local to a double patch origin.
void Renderer::release(GpuPlanet& m) {
    if (m.ibo) glDeleteBuffers(1,&m.ibo);
    if (m.vbo) glDeleteBuffers(1,&m.vbo);
    if (m.vao) glDeleteVertexArrays(1,&m.vao);
    m = GpuPlanet{};
}
void Renderer::syncPlanetGpu() {
    std::unordered_set<CubeTileCoord, CubeTileHash> selected;
    for (const auto& packet : planetPackets) selected.insert(packet.tile);
    for (auto it=planetGpu.begin(); it!=planetGpu.end();) {
        if (!selected.contains(it->first)) { release(it->second); it=planetGpu.erase(it); }
        else ++it;
    }
    int uploads=0;
    for (const auto& packet:planetPackets) {
        if (!packet.mesh || packet.mesh->vertices.empty() || packet.mesh->indices.empty()) continue;
        GpuPlanet& gpu=planetGpu[packet.tile];
        if (gpu.source==packet.mesh.get()) continue;
        if (uploads>=6) break;
        if (!gpu.vao) {
            glGenVertexArrays(1,&gpu.vao);
            glGenBuffers(1,&gpu.vbo);
            glGenBuffers(1,&gpu.ibo);
        }
        glBindVertexArray(gpu.vao);
        glBindBuffer(GL_ARRAY_BUFFER,gpu.vbo);
        glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(packet.mesh->vertices.size()*sizeof(PlanetPatchVertex)),
                     packet.mesh->vertices.data(), GL_STATIC_DRAW);
        glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(PlanetPatchVertex),(void*)offsetof(PlanetPatchVertex, localPosition));
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(PlanetPatchVertex),(void*)offsetof(PlanetPatchVertex, normal));
        glEnableVertexAttribArray(1);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,gpu.ibo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,GLsizeiptr(packet.mesh->indices.size()*sizeof(std::uint32_t)),
                     packet.mesh->indices.data(),GL_STATIC_DRAW);
        gpu.indices=GLsizei(packet.mesh->indices.size());
        gpu.source=packet.mesh.get();
        ++uploads;
    }
    glBindVertexArray(0);
}
void Renderer::drawPlanetOrbit(const Camera& camera, const RenderSettings& rs) const {
    if (!rs.drawWorld || planetPackets.empty()) return;
    planetOrbitShader.use();
    // Rotation-only camera matrix: translation was already subtracted at high
    // precision by C7's draw-packet builder. NEVER camera.view() here.
    const float aspect=targetH>0 ? float(targetW)/float(targetH) : 1.0f;
    const glm::mat4 rotationOnly=glm::mat4(glm::mat3(camera.view()));
    planetOrbitShader.set("uRotationProjection",camera.projection(aspect)*rotationOnly);
    planetOrbitShader.set("uToSun",glm::normalize(-rs.sunDirection));
    planetOrbitShader.set("uSunIntensity",rs.sunIntensity);
    const bool culling=glIsEnabled(GL_CULL_FACE)==GL_TRUE;
    glDisable(GL_CULL_FACE); // cube-face UV winding is not normalized yet
    for (const auto& packet:planetPackets) {
        const auto it=planetGpu.find(packet.tile);
        if (it==planetGpu.end() || it->second.source!=packet.mesh.get() || it->second.indices==0) continue;
        planetOrbitShader.set("uOffset",packet.cameraRelativeOrigin);
        glBindVertexArray(it->second.vao);
        glDrawElements(GL_TRIANGLES,it->second.indices,GL_UNSIGNED_INT,nullptr);
    }
    glBindVertexArray(0);
    if (culling) glEnable(GL_CULL_FACE);
}

void Renderer::drawAll() const {
    for (const auto& [_, m] : meshes) {
        if (m.vertexCount == 0) continue;
        glBindVertexArray(m.vao);
        glDrawArrays(GL_TRIANGLES, 0, m.vertexCount);
    }
}

void Renderer::prepareObjects() {
    ++frameNumber;
    for (const ObjectDraw& d : objects) {
        if (!d.asset || d.asset->mesh.empty()) continue;
        GpuObject& g = objectMeshes[d.asset.get()];
        g.lastUsed = frameNumber;
        if (g.vao && g.version == d.asset->version && g.asset == d.asset) continue;
        if (!g.vao) {
            glGenVertexArrays(1, &g.vao);
            glGenBuffers(1, &g.vbo);
            glBindVertexArray(g.vao);
            glBindBuffer(GL_ARRAY_BUFFER, g.vbo);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, ao));
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(3, 4, GL_UNSIGNED_BYTE, GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, layers));
            glEnableVertexAttribArray(3);
            glVertexAttribPointer(4, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), (void*)offsetof(Vertex, bary));
            glEnableVertexAttribArray(4);
        }
        glBindBuffer(GL_ARRAY_BUFFER, g.vbo);
        glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(d.asset->mesh.size() * sizeof(Vertex)), d.asset->mesh.data(), GL_STATIC_DRAW);
        g.vertexCount = GLsizei(d.asset->mesh.size());
        g.version = d.asset->version;
        g.asset = d.asset;
    }
    // Meshes not drawn for a few seconds go back to the driver.
    for (auto it = objectMeshes.begin(); it != objectMeshes.end();) {
        if (frameNumber - it->second.lastUsed > 600) {
            glDeleteBuffers(1, &it->second.vbo);
            glDeleteVertexArrays(1, &it->second.vao);
            it = objectMeshes.erase(it);
        } else ++it;
    }
    // Skinned bodies: their own vertex layout (bones, weights, a colour per vertex).
    for (const ObjectDraw& d : objects) {
        if (!d.skin || d.skin->vertices.empty() || d.skin->indices.empty()) continue;
        GpuSkin& g = skinMeshes[d.skin.get()];
        g.lastUsed = frameNumber;
        if (g.vao && g.mesh == d.skin) continue;
        if (!g.vao) {
            glGenVertexArrays(1, &g.vao);
            glGenBuffers(1, &g.vbo);
            glGenBuffers(1, &g.ebo);
            glBindVertexArray(g.vao);
            glBindBuffer(GL_ARRAY_BUFFER, g.vbo);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ebo);              // part of the VAO's state
            const GLsizei st = sizeof(SkinVertex);
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, st, (void*)(offsetof(SkinVertex, v) + offsetof(Vertex, position)));
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, st, (void*)(offsetof(SkinVertex, v) + offsetof(Vertex, normal)));
            glEnableVertexAttribArray(1);
            glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, st, (void*)(offsetof(SkinVertex, v) + offsetof(Vertex, ao)));
            glEnableVertexAttribArray(2);
            glVertexAttribPointer(3, 4, GL_UNSIGNED_BYTE, GL_FALSE, st, (void*)(offsetof(SkinVertex, v) + offsetof(Vertex, layers)));
            glEnableVertexAttribArray(3);
            glVertexAttribPointer(4, 4, GL_UNSIGNED_BYTE, GL_TRUE, st, (void*)(offsetof(SkinVertex, v) + offsetof(Vertex, bary)));
            glEnableVertexAttribArray(4);
            glVertexAttribPointer(5, 4, GL_UNSIGNED_BYTE, GL_FALSE, st, (void*)offsetof(SkinVertex, bones));
            glEnableVertexAttribArray(5);
            glVertexAttribPointer(6, 4, GL_UNSIGNED_BYTE, GL_TRUE, st, (void*)offsetof(SkinVertex, weights));
            glEnableVertexAttribArray(6);
            glVertexAttribPointer(7, 4, GL_UNSIGNED_BYTE, GL_TRUE, st, (void*)offsetof(SkinVertex, tint));
            glEnableVertexAttribArray(7);
        }
        glBindBuffer(GL_ARRAY_BUFFER, g.vbo);
        glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(d.skin->vertices.size() * sizeof(SkinVertex)), d.skin->vertices.data(), GL_STATIC_DRAW);
        glBindVertexArray(g.vao);
        if (d.skin->extra.size() == d.skin->vertices.size()) {             // a realistic body: UVs, expression vertex, surface mode
            if (!g.xbo) glGenBuffers(1, &g.xbo);
            glBindBuffer(GL_ARRAY_BUFFER, g.xbo);
            glBufferData(GL_ARRAY_BUFFER, GLsizeiptr(d.skin->extra.size() * sizeof(glm::vec4)), d.skin->extra.data(), GL_STATIC_DRAW);
            glVertexAttribPointer(8, 4, GL_FLOAT, GL_FALSE, sizeof(glm::vec4), nullptr);
            glEnableVertexAttribArray(8);
        } else {
            glDisableVertexAttribArray(8);
        }
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, GLsizeiptr(d.skin->indices.size() * sizeof(std::uint32_t)), d.skin->indices.data(), GL_STATIC_DRAW);
        glBindVertexArray(0);
        g.vertexCount = GLsizei(d.skin->indices.size());
        g.mesh = d.skin;
    }
    for (auto it = skinMeshes.begin(); it != skinMeshes.end();) {
        if (frameNumber - it->second.lastUsed > 600) {
            glDeleteBuffers(1, &it->second.vbo);
            glDeleteBuffers(1, &it->second.ebo);
            glDeleteBuffers(1, &it->second.xbo);
            glDeleteVertexArrays(1, &it->second.vao);
            it = skinMeshes.erase(it);
        } else ++it;
    }
    objectTriangles = 0;
    for (const ObjectDraw& d : objects) {
        if (d.asset) objectTriangles += d.asset->mesh.size() / 3;
        if (d.skin) objectTriangles += d.skin->indices.size() / 3;
    }
}

void Renderer::uploadHumanData() {
    const std::shared_ptr<const HumanRenderData>& h = humanRenderData();
    if (!h || h->version == humanVersion) return;
    humanVersion = h->version;
    auto tex2d = [](GLuint& t, int w, int hgt, const std::vector<std::uint8_t>& px) {
        if (w <= 0 || hgt <= 0 || px.size() != size_t(w) * size_t(hgt) * 4) return;
        if (!t) glGenTextures(1, &t);
        glBindTexture(GL_TEXTURE_2D, t);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, hgt, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    };
    tex2d(humanMap0, h->mapSize, h->mapSize, h->map0);
    tex2d(humanMap1, h->mapSize, h->mapSize, h->map1);
    tex2d(humanEye, h->eyeW, h->eyeH, h->eye);
    tex2d(humanHair, h->hairSize, h->hairSize, h->hair);
    if (humanHair) {                                                          // strands run along v: wrap across them
        glBindTexture(GL_TEXTURE_2D, humanHair);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    }
    glBindTexture(GL_TEXTURE_2D, 0);
    if (h->expressionVertices > 0 && h->expressions.size() == size_t(kMaxExpressions) * size_t(h->expressionVertices) * 3) {
        if (!morphBuffer) glGenBuffers(1, &morphBuffer);
        glBindBuffer(GL_TEXTURE_BUFFER, morphBuffer);
        glBufferData(GL_TEXTURE_BUFFER, GLsizeiptr(h->expressions.size() * sizeof(float)), h->expressions.data(), GL_STATIC_DRAW);
        if (!morphTexture) glGenTextures(1, &morphTexture);
        glBindTexture(GL_TEXTURE_BUFFER, morphTexture);
        glTexBuffer(GL_TEXTURE_BUFFER, GL_RGB32F, morphBuffer);
        glBindTexture(GL_TEXTURE_BUFFER, 0);
        glBindBuffer(GL_TEXTURE_BUFFER, 0);
        morphVerts = h->expressionVertices;
    }
}

void Renderer::drawObjects(const Shader& s, bool lit, float foliageReach) const {
    const GLint bonesLoc = glGetUniformLocation(s.program, "uBones");
    const GLint exprLoc = glGetUniformLocation(s.program, "uExpr");
    s.set("uMorphs", 8);
    s.set("uMorphVerts", morphVerts);
    s.set("uMorphOn", 0);
    s.set("uSwayTime", frameTime);                                       // one time for every pass (their depths must agree)
    const bool prepass = &s == &prepassShader;
    for (const ObjectDraw& d : objects) {
        if (d.foliage && glm::length(glm::vec3(d.model[3]) - drawCameraPos) > foliageReach) continue;
        if (d.cards && prepass) continue;                                    // see-through cards: their depth comes in the lit pass
        if (d.skin && d.bones) {
            s.set("uCards", d.cards ? 1 : 0);
            s.set("uSway", d.sway);
            auto it = skinMeshes.find(d.skin.get());
            if (it == skinMeshes.end() || it->second.vertexCount == 0) continue;
            s.set("uSkinned", 1);
            glUniformMatrix4fv(bonesLoc, kMaxSkinBones, GL_FALSE, &(*d.bones)[0][0][0]);
            const bool morph = morphTexture && !d.skin->extra.empty() && std::any_of(d.expr.begin(), d.expr.end(), [](float e) { return e != 0.0f; });
            s.set("uMorphOn", morph ? 1 : 0);
            if (morph) {
                glUniform1fv(exprLoc, kMaxExpressions, d.expr.data());
                s.set("uExprScale", d.skin->expressionScale);
            }
            s.set("uModel", d.model);
            if (lit) {
                s.set("uNormalMat", glm::transpose(glm::inverse(glm::mat3(d.model))));
                s.set("uTexMul", d.scale);
                s.set("uHighlight", d.highlight);
                s.set("uObjTint", glm::vec3(1.0f));
                s.set("uHairTint", glm::vec4(glm::pow(glm::clamp(glm::vec3(d.hairTint), glm::vec3(0.0f), glm::vec3(1.0f)), glm::vec3(2.2f)), d.hairTint.w));
                s.set("uEyeColour", glm::pow(glm::clamp(d.eyeColour, glm::vec3(0.0f), glm::vec3(1.0f)), glm::vec3(2.2f)));
            }
            glBindVertexArray(it->second.vao);
            glDrawElements(GL_TRIANGLES, it->second.vertexCount, GL_UNSIGNED_INT, nullptr);
            s.set("uSkinned", 0);
            s.set("uMorphOn", 0);
            s.set("uCards", 0);
            continue;
        }
        if (!d.asset) continue;
        auto it = objectMeshes.find(d.asset.get());
        if (it == objectMeshes.end() || it->second.vertexCount == 0) continue;
        s.set("uModel", d.model);
        if (lit) {
            s.set("uNormalMat", glm::transpose(glm::inverse(glm::mat3(d.model))));
            s.set("uTexMul", d.scale);
            s.set("uHighlight", d.highlight);
            s.set("uObjTint", glm::pow(glm::clamp(d.tint, glm::vec3(0.0f), glm::vec3(1.0f)), glm::vec3(2.2f)));   // colours are picked in sRGB; the shader tints in linear light
            s.set("uHairTint", glm::vec4(glm::pow(glm::clamp(glm::vec3(d.hairTint), glm::vec3(0.0f), glm::vec3(1.0f)), glm::vec3(2.2f)), d.hairTint.w));
        }
        glBindVertexArray(it->second.vao);
        glDrawArrays(GL_TRIANGLES, 0, it->second.vertexCount);
    }
    // Back to the identity, which is what terrain chunks are drawn with.
    s.set("uModel", glm::mat4(1.0f));
    if (lit) {
        s.set("uNormalMat", glm::mat3(1.0f));
        s.set("uTexMul", 1.0f);
        s.set("uHighlight", glm::vec4(0.0f));
        s.set("uObjTint", glm::vec3(1.0f));
        s.set("uHairTint", glm::vec4(0.0f));
    }
}

void Renderer::drawGrass(const glm::vec3& cam, const glm::mat4& vp, const RenderSettings& rs) const {
    // Frustum planes straight from the view-projection matrix.
    glm::vec4 plane[6];
    for (int i = 0; i < 3; ++i)
        for (int s = 0; s < 2; ++s) {
            glm::vec4 p;
            for (int k = 0; k < 4; ++k) p[k] = vp[k][3] + (s == 0 ? 1.0f : -1.0f) * vp[k][i];
            plane[i * 2 + s] = p / glm::length(glm::vec3(p));
        }
    const float reach = rs.grassDistance + 30.0f;
    for (const auto& [_, m] : meshes) {
        if (m.grassCount == 0 || glm::distance(m.center, cam) > reach) continue;
        bool inside = true;
        for (const auto& p : plane) if (glm::dot(glm::vec3(p), m.center) + p.w < -30.0f) { inside = false; break; }
        if (!inside) continue;
        glBindVertexArray(m.grassVao);
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 7, m.grassCount);
    }
}

void Renderer::drawFullscreen() const {
    glBindVertexArray(emptyVao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}

// ------------------------------------------------------------------ frame

void Renderer::render(const Camera& camera, int width, int height, const RenderSettings& rs, int screenX, int screenY) {
    if (width <= 0 || height <= 0) return;
    drawCameraPos = camera.position;
    syncPlanetGpu();
    frameTime = secondsSinceStart();
    // The 3D picture is drawn at renderScale x the view size and stretched to fit at the end.
    const float scale = std::clamp(rs.renderScale, 0.25f, 2.0f);
    const int iw = std::max(1, int(std::lround(float(width) * scale))), ih = std::max(1, int(std::lround(float(height) * scale)));
    resizeTargets(iw, ih);
    resizeShadowMap(rs.shadowSize);
    pollTextures();
    requestTextures(rs.textureSize);
    triangles = 0;
    grassBlades = 0;
    prepareObjects();
    uploadHumanData();
    glActiveTexture(GL_TEXTURE8);                                         // the expression shapes, for every object vertex shader
    glBindTexture(GL_TEXTURE_BUFFER, morphTexture);
    glActiveTexture(GL_TEXTURE9);                                         // hair cards' cut-out, for the lit and the shadow pass
    glBindTexture(GL_TEXTURE_2D, humanHair);
    glActiveTexture(GL_TEXTURE0);
    for (const auto& [_, m] : meshes) { triangles += size_t(m.vertexCount) / 3; grassBlades += size_t(m.grassCount); }
    planetTriangles=0;
    for (const auto& [_, g] : planetGpu) planetTriangles+=size_t(g.indices)/3;

    const glm::vec3 toSun = glm::normalize(-rs.sunDirection);
    const bool underwater = rs.water && camera.position.y < rs.waterLevel;
    // The sun casts shadows by day, the moon (opposite the sun) by night.
    const glm::vec3 toShadowLight = toSun.y > 0.0f ? toSun : -toSun;
    const float aspect = float(width) / float(height);
    const glm::mat4 viewProj = camera.projection(aspect) * camera.view();

    // ---- 1. shadow cascades: four boxes around slices of the view, each fitted with a sphere (so they do not swim
    // as the camera turns) and snapped to whole shadow texels (so they do not shimmer as it moves).
    const float shadowFar = std::max(30.0f, rs.shadowRange * 2.4f);
    const float camNear = 0.1f;
    float splitFar[4];
    for (int i = 0; i < 4; ++i) {
        const float t = float(i + 1) / 4.0f;
        const float logSplit = camNear * std::pow(shadowFar / camNear, t), uniSplit = camNear + (shadowFar - camNear) * t;
        splitFar[i] = 0.82f * logSplit + 0.18f * uniSplit;
    }
    const int tileRes = std::max(256, shadowRes / 2);
    glm::mat4 cascade[4];
    float cascadeTexel[4];
    {
        const glm::vec3 f = camera.front(), r = glm::normalize(glm::cross(f, glm::vec3(0, 1, 0))), u = glm::cross(r, f);
        const float tanHalf = std::tan(glm::radians(camera.fovDegrees) * 0.5f);
        const glm::vec3 lightUp = std::abs(toShadowLight.y) > 0.99f ? glm::vec3(0, 0, 1) : glm::vec3(0, 1, 0);
        float prev = camNear;
        for (int i = 0; i < 4; ++i) {
            const float n0 = prev, n1 = splitFar[i];
            const float mid = (n0 + n1) * 0.5f;
            const glm::vec3 centre = camera.position + f * mid;
            auto cornerDist = [&](float d) { return glm::length(camera.position + f * d + r * (d * tanHalf * aspect) + u * (d * tanHalf) - centre); };
            float radius = std::max(cornerDist(n0), cornerDist(n1));
            radius = std::ceil(radius * 2.0f) * 0.5f;                                   // steps of 0.5 m: stable from frame to frame
            const float texelWorld = radius * 2.0f / float(tileRes);
            const glm::mat4 lightView = glm::lookAt(glm::vec3(0.0f), -toShadowLight, lightUp);
            glm::vec3 c = glm::vec3(lightView * glm::vec4(centre, 1.0f));
            c.x = std::floor(c.x / texelWorld) * texelWorld; c.y = std::floor(c.y / texelWorld) * texelWorld;
            const glm::vec3 snapped = glm::vec3(glm::inverse(lightView) * glm::vec4(c, 1.0f));
            const float back = 300.0f;                                                  // far enough behind to catch tall casters
            cascade[i] = glm::ortho(-radius, radius, -radius, radius, 1.0f, back + radius * 2.0f) *
                         glm::lookAt(snapped + toShadowLight * back, snapped, lightUp);
            cascadeTexel[i] = texelWorld;
            prev = n1;
        }
    }
    const bool castShadows = rs.shadows && std::abs(toSun.y) > 0.03f;   // skip at the exact horizon
    if (castShadows) {
        glBindFramebuffer(GL_FRAMEBUFFER, shadowFbo);
        glViewport(0, 0, shadowRes, shadowRes);
        glClear(GL_DEPTH_BUFFER_BIT);
        glEnable(GL_SCISSOR_TEST);
        glCullFace(GL_FRONT);
        depthShader.use();
        depthShader.set("uModel", glm::mat4(1.0f));
        for (int i = 0; i < 4; ++i) {
            const int x = (i & 1) * tileRes, y = (i >> 1) * tileRes;
            glViewport(x, y, tileRes, tileRes);
            glScissor(x, y, tileRes, tileRes);
            depthShader.set("uLightSpace", cascade[i]);
            if (rs.drawWorld) drawAll();
            drawObjects(depthShader, false, splitFar[i] + 12.0f);           // trees beyond this cascade's reach cast nothing in it
        }
        glDisable(GL_SCISSOR_TEST);
        glCullFace(GL_BACK);
    }
    const glm::vec4 cascadeFar(splitFar[0], splitFar[1], splitFar[2], splitFar[3]);
    const glm::vec4 cascadeTexelV(cascadeTexel[0], cascadeTexel[1], cascadeTexel[2], cascadeTexel[3]);
    auto setShadowUniforms = [&](const Shader& sh) {
        glUniformMatrix4fv(glGetUniformLocation(sh.program, "uCascade"), 4, GL_FALSE, &cascade[0][0][0]);
        sh.set("uCascadeFar", cascadeFar);
        sh.set("uCascadeTexel", cascadeTexelV);
        sh.set("uShadows", castShadows ? 1 : 0);
        sh.set("uShadowMap", 0);
    };

    // ---- 2. HDR scene: a depth prepass (for ambient occlusion), then terrain and objects, then the sky in the empty pixels
    glBindFramebuffer(GL_FRAMEBUFFER, scene.fbo);
    glViewport(0, 0, scene.w, scene.h);
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    const glm::mat4 proj = camera.projection(aspect);
    const bool ao = rs.ssao && !rs.wireframe;
    if (ao) {
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        prepassShader.use();
        prepassShader.set("uViewProj", viewProj);
        prepassShader.set("uModel", glm::mat4(1.0f));
        if (rs.drawWorld) drawAll();
        drawObjects(prepassShader, false);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);

        // occlusion at half resolution, then a depth-aware blur both ways
        glDisable(GL_DEPTH_TEST);
        glBindFramebuffer(GL_FRAMEBUFFER, ssaoRaw.fbo);
        glViewport(0, 0, ssaoRaw.w, ssaoRaw.h);
        ssaoShader.use();
        ssaoShader.set("uDepth", 0);
        ssaoShader.set("uProj", proj);
        ssaoShader.set("uInvProj", glm::inverse(proj));
        glUniform2f(glGetUniformLocation(ssaoShader.program, "uTexel"), 1.0f / float(scene.w), 1.0f / float(scene.h));
        ssaoShader.set("uRadius", 0.55f);
        ssaoShader.set("uStrength", 1.1f);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneDepth);
        drawFullscreen();
        ssaoBlurShader.use();
        ssaoBlurShader.set("uSrc", 0);
        glBindFramebuffer(GL_FRAMEBUFFER, ssaoBlur.fbo);
        glBindTexture(GL_TEXTURE_2D, ssaoRaw.tex);
        glUniform2f(glGetUniformLocation(ssaoBlurShader.program, "uStep"), 1.0f / float(ssaoRaw.w), 0.0f);
        drawFullscreen();
        glBindFramebuffer(GL_FRAMEBUFFER, ssaoRaw.fbo);
        glBindTexture(GL_TEXTURE_2D, ssaoBlur.tex);
        glUniform2f(glGetUniformLocation(ssaoBlurShader.program, "uStep"), 0.0f, 1.0f / float(ssaoRaw.h));
        drawFullscreen();
        glEnable(GL_DEPTH_TEST);
        glBindFramebuffer(GL_FRAMEBUFFER, scene.fbo);
        glViewport(0, 0, scene.w, scene.h);
    }

    glPolygonMode(GL_FRONT_AND_BACK, rs.wireframe ? GL_LINE : GL_FILL);
    terrainShader.use();
    setAtmosphere(terrainShader, toSun, rs, underwater);
    setShadowUniforms(terrainShader);
    terrainShader.set("uViewProj", viewProj);
    terrainShader.set("uShadowLightDir", toShadowLight);
    terrainShader.set("uCameraPos", camera.position);
    {   // what each material is made of: its texture and its size in the world, its tint (and the Look panel's), how much it glows
        float layer[kMaterialSlots], emit[kMaterialSlots * 2], tintable[kMaterialSlots], layerScale[kMaterialSlots], scatter[kMaterialSlots];
        glm::vec3 tint[kMaterialSlots];
        for (int slot = 0; slot < kMaterialSlots; ++slot) {
            const MaterialInfo& info = materialInfo(MaterialId(slot + 1));
            layer[slot] = float(info.texture);
            layerScale[slot] = 4.0f / std::max(0.25f, textureLayerMetres(info.texture));
            tint[slot] = glm::vec3(info.tint[0], info.tint[1], info.tint[2]) * rs.materialTint[slot];
            emit[slot * 2] = info.glow; emit[slot * 2 + 1] = info.glowMask;
            const MaterialId id = MaterialId(slot + 1);           // an object's tint colours plaster, cloth and metal; paint, wood, glass... keep their own
            tintable[slot] = (id == MAT_PLASTER || id == MAT_CLOTH || id == MAT_METAL) ? 1.0f
                           : (id == MAT_SKIN || id == MAT_LEATHER) ? 2.0f : id == MAT_HAIR ? 3.0f : 0.0f;   // 2: a person's colour replaces the default; 3: their hair colour
            scatter[slot] = id == MAT_SKIN ? 1.0f : (id == MAT_LEAVES || id == MAT_NEEDLES) ? 0.45f : id == MAT_HAIR ? 0.3f : 0.0f;   // light passing through
        }
        glUniform1fv(glGetUniformLocation(terrainShader.program, "uTexLayer"), kMaterialSlots, layer);
        glUniform1fv(glGetUniformLocation(terrainShader.program, "uLayerScale"), kMaterialSlots, layerScale);
        glUniform3fv(glGetUniformLocation(terrainShader.program, "uTint"), kMaterialSlots, &tint[0].x);
        glUniform2fv(glGetUniformLocation(terrainShader.program, "uEmit"), kMaterialSlots, emit);
        glUniform1fv(glGetUniformLocation(terrainShader.program, "uObjTintable"), kMaterialSlots, tintable);
        glUniform1fv(glGetUniformLocation(terrainShader.program, "uScatter"), kMaterialSlots, scatter);
    }
    terrainShader.set("uTexScale", 1.0f / std::max(0.25f, rs.textureScale));
    terrainShader.set("uNormalStrength", rs.normalStrength);
    terrainShader.set("uAlbedo", 1);
    terrainShader.set("uNormals", 2);
    terrainShader.set("uSurface", 3);
    terrainShader.set("uAO", 4);
    terrainShader.set("uSkinMap0", 5);
    terrainShader.set("uSkinMap1", 6);
    terrainShader.set("uEyeMap", 7);
    terrainShader.set("uSkinSlot", float(MAT_SKIN - 1));
    terrainShader.set("uAOOn", ao ? 1 : 0);
    glUniform2f(glGetUniformLocation(terrainShader.program, "uViewSize"), float(scene.w), float(scene.h));
    terrainShader.set("uWaterOn", rs.water ? 1 : 0);
    terrainShader.set("uWaterLevel", rs.waterLevel);
    terrainShader.set("uTime", secondsSinceStart());
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D_ARRAY, albedoArray);
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D_ARRAY, normalArray);
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D_ARRAY, surfaceArray);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_2D, ao ? ssaoRaw.tex : 0);
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, humanMap0);
    glActiveTexture(GL_TEXTURE6);
    glBindTexture(GL_TEXTURE_2D, humanMap1);
    glActiveTexture(GL_TEXTURE7);
    glBindTexture(GL_TEXTURE_2D, humanEye);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, shadowMap);
    terrainShader.set("uModel", glm::mat4(1.0f));
    terrainShader.set("uNormalMat", glm::mat3(1.0f));
    terrainShader.set("uTexMul", 1.0f);
    terrainShader.set("uHighlight", glm::vec4(0.0f));
    terrainShader.set("uObjTint", glm::vec3(1.0f));
    terrainShader.set("uHairTint", glm::vec4(0.0f));
    if (rs.drawWorld) drawAll();
    drawObjects(terrainShader, true);
    drawPlanetOrbit(camera, rs); // experimental spherical orbital layer
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    if (rs.drawWorld && rs.grass && rs.grassDensity > 0.0f && !rs.wireframe) {
        grassShader.use();
        setAtmosphere(grassShader, toSun, rs, underwater);
        setShadowUniforms(grassShader);
        grassShader.set("uViewProj", viewProj);
        grassShader.set("uCameraPos", camera.position);
        grassShader.set("uShadowLightDir", toShadowLight);
        grassShader.set("uAlbedo", 1);
        grassShader.set("uTexScale", 1.0f / std::max(0.25f, rs.textureScale));
        grassShader.set("uTint", rs.materialTint[MAT_GRASS - 1]);
        grassShader.set("uTime", secondsSinceStart());
        grassShader.set("uGrassDist", rs.grassDistance);
        grassShader.set("uDensity", rs.grassDensity);
        grassShader.set("uHeight", rs.grassHeight);
        grassShader.set("uWindStrength", rs.windStrength);
        grassShader.set("uWindSpeed", rs.windSpeed);
        const float wh = glm::radians(rs.windHeading);
        grassShader.set("uWindDir", glm::vec2(std::cos(wh), std::sin(wh)));
        grassShader.set("uInteract", rs.interactor);
        {
            const int n = std::min<int>(int(rs.grassClear.size()) / 2, RenderSettings::kMaxGrassClearings);
            grassShader.set("uClearCount", n);
            if (n > 0) glUniform4fv(glGetUniformLocation(grassShader.program, "uClear"), n * 2, &rs.grassClear[0].x);
        }
        glDisable(GL_CULL_FACE);
        drawGrass(camera.position, viewProj, rs);
        glEnable(GL_CULL_FACE);
    }

    glDepthMask(GL_FALSE);
    skyShader.use();
    setAtmosphere(skyShader, toSun, rs, underwater);
    skyShader.set("uInvViewProj", glm::inverse(viewProj));
    skyShader.set("uCameraPos", camera.position);
    skyShader.set("uStars", rs.starBrightness);
    skyShader.set("uTime", secondsSinceStart());
    drawFullscreen();
    glDepthMask(GL_TRUE);

    // ---- 2b. water: blended over the scene we just drew
    if (rs.water && rs.drawWorld) {
        glBindFramebuffer(GL_READ_FRAMEBUFFER, scene.fbo);
        glBindFramebuffer(GL_DRAW_FRAMEBUFFER, sceneCopy.fbo);
        glBlitFramebuffer(0, 0, scene.w, scene.h, 0, 0, scene.w, scene.h, GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT, GL_NEAREST);
        glBindFramebuffer(GL_FRAMEBUFFER, scene.fbo);

        waterShader.use();
        setAtmosphere(waterShader, toSun, rs, underwater);
        waterShader.set("uInvViewProj", glm::inverse(viewProj));
        waterShader.set("uViewProj", viewProj);
        waterShader.set("uCameraPos", camera.position);
        waterShader.set("uWaterLevel", rs.waterLevel);
        waterShader.set("uTime", secondsSinceStart());
        waterShader.set("uWaveStrength", rs.waveStrength);
        waterShader.set("uWaveSpeed", rs.waveSpeed);
        waterShader.set("uRadius", rs.waterRadius);
        waterShader.set("uFoam", rs.foam);
        waterShader.set("uShallow", rs.waterShallow);
        waterShader.set("uSceneColor", 0);
        waterShader.set("uSceneDepth", 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, sceneCopyDepth);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneCopy.tex);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_CULL_FACE);
        drawFullscreen();
        glEnable(GL_CULL_FACE);
        glDisable(GL_BLEND);
    }

    // ---- 3. post-processing (no depth from here on)
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);

    if (rs.bloom) {
        bloomDownShader.use();
        bloomDownShader.set("uSrc", 0);
        bloomDownShader.set("uThreshold", rs.bloomThreshold);
        GLuint src = scene.tex;
        glm::vec2 srcTexel(1.0f / scene.w, 1.0f / scene.h);
        for (size_t i = 0; i < bloomMips.size(); ++i) {
            glBindFramebuffer(GL_FRAMEBUFFER, bloomMips[i].fbo);
            glViewport(0, 0, bloomMips[i].w, bloomMips[i].h);
            glBindTexture(GL_TEXTURE_2D, src);
            glUniform2f(glGetUniformLocation(bloomDownShader.program, "uTexel"), srcTexel.x, srcTexel.y);
            bloomDownShader.set("uFirst", i == 0 ? 1 : 0);
            drawFullscreen();
            src = bloomMips[i].tex;
            srcTexel = glm::vec2(1.0f / bloomMips[i].w, 1.0f / bloomMips[i].h);
        }
        bloomUpShader.use();
        bloomUpShader.set("uSrc", 0);
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE);
        for (size_t i = bloomMips.size() - 1; i > 0; --i) {
            glBindFramebuffer(GL_FRAMEBUFFER, bloomMips[i - 1].fbo);
            glViewport(0, 0, bloomMips[i - 1].w, bloomMips[i - 1].h);
            glBindTexture(GL_TEXTURE_2D, bloomMips[i].tex);
            glUniform2f(glGetUniformLocation(bloomUpShader.program, "uTexel"), 1.0f / bloomMips[i].w, 1.0f / bloomMips[i].h);
            drawFullscreen();
        }
        glDisable(GL_BLEND);
    }

    // Composite into the LDR target (for FXAA) or straight to the screen.
    if (!rs.fxaa) {                                    // straight to the window: clear it first, the view may not cover it all
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDisable(GL_SCISSOR_TEST);
        glClearColor(0.067f, 0.075f, 0.094f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, rs.fxaa ? ldr.fbo : 0);
    if (rs.fxaa) glViewport(0, 0, ldr.w, ldr.h);
    else         glViewport(screenX, screenY, width, height);
    compositeShader.use();
    compositeShader.set("uScene", 0);
    compositeShader.set("uBloom", 1);
    compositeShader.set("uBloomOn", rs.bloom ? 1 : 0);
    compositeShader.set("uBloomIntensity", rs.bloomIntensity);
    compositeShader.set("uExposure", rs.exposure);
    compositeShader.set("uContrast", rs.contrast);
    compositeShader.set("uSaturation", rs.saturation);
    compositeShader.set("uTemperature", rs.temperature);
    compositeShader.set("uVignette", rs.vignette);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, bloomMips.empty() ? 0 : bloomMips[0].tex);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, scene.tex);
    drawFullscreen();

    if (rs.fxaa) {
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDisable(GL_SCISSOR_TEST);
        glClearColor(0.067f, 0.075f, 0.094f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glViewport(screenX, screenY, width, height);
        fxaaShader.use();
        fxaaShader.set("uTex", 0);
        glUniform2f(glGetUniformLocation(fxaaShader.program, "uTexel"), 1.0f / ldr.w, 1.0f / ldr.h);
        glBindTexture(GL_TEXTURE_2D, ldr.tex);
        drawFullscreen();
    }

    // Restore state for the next frame / ImGui.
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glDepthFunc(GL_LESS);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

} // namespace px
