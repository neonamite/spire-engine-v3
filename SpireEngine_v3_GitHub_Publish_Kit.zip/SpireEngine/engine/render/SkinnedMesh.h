#pragma once
// A mesh that bends with a skeleton (smooth skinning): every vertex follows up to four bones, weighted, so a body is
// one continuous surface that stretches at the knees and elbows instead of rigid pieces that part at the joints.
// The renderer does the skinning on the graphics card (uBones in the object shaders).
#include <array>
#include <cstdint>
#include <memory>
#include <vector>
#include <glm/glm.hpp>
#include "world/VoxelChunk.h"      // Vertex

namespace px {

inline constexpr int kMaxSkinBones = 16;
inline constexpr int kMaxExpressions = 8;    // shape changes a face makes (blink, smile...), mixed per draw

struct SkinVertex {
    Vertex v;                      // position and normal in the bind pose, ao, materials (as any object vertex)
    std::uint8_t bones[4];         // which bones
    std::uint8_t weights[4];       // how much of each (they add up to 255)
    std::uint8_t tint[4];          // the colour this bit of the body takes (sRGB; a = 255): skin, top, trousers...
};
static_assert(sizeof(SkinVertex) == 48, "SkinVertex layout is mirrored in Renderer");

// How a vertex of a realistic body (1.5) is drawn: with the materials like everything else, or with the body's own
// texture maps (its UV layout).
enum class SurfaceMode : std::uint8_t { Materials = 0, Skin = 1, Eye = 2, Teeth = 3, Tongue = 4, Lashes = 5, HairCard = 6 };

struct SkinnedMesh {
    std::vector<SkinVertex> vertices;                       // each corner once (shared by the triangles round it)
    std::vector<std::uint32_t> indices;                     // triangles, three indices each
    std::array<glm::mat4, kMaxSkinBones> inverseBind{};     // each bone's bind-pose world transform, inverted
    // 1.5, realistic bodies only (empty otherwise): per vertex u, v, which shared expression vertex it follows (-1: none)
    // and its SurfaceMode.
    std::vector<glm::vec4> extra;
    float expressionScale = 1.0f;                           // the body's size against the shared expression shapes
};

using SkinBones = std::array<glm::mat4, kMaxSkinBones>;     // bone world transform x inverse bind, per bone
using Expressions = std::array<float, kMaxExpressions>;     // how much of each expression, this frame

// What every realistic body shares, made once (character/HumanBody) and uploaded once by the renderer: the skin's detail
// maps on the body's UV layout, the eye texture, and the expression shapes (one offset per shared vertex each).
struct HumanRenderData {
    int mapSize = 0;
    std::vector<std::uint8_t> map0;     // RGBA: albedo detail (0.5 = as is), redness (lips, cheeks), brow hair, nails
    std::vector<std::uint8_t> map1;     // RGBA: detail normal x, y (0.5 = flat), roughness, cavity
    int eyeW = 0, eyeH = 0;
    std::vector<std::uint8_t> eye;      // RGBA, sRGB
    int hairSize = 0;
    std::vector<std::uint8_t> hair;     // a hair card: R brightness along each strand, G which strand (for colour), A coverage
    int expressionVertices = 0;         // offsets per expression
    std::vector<float> expressions;     // kMaxExpressions x expressionVertices x (x, y, z), metres
    std::uint32_t version = 0;
};

// The shared data, once made (set by character/HumanBody, read by the renderer; main thread only).
inline std::shared_ptr<const HumanRenderData>& humanRenderData() { static std::shared_ptr<const HumanRenderData> p; return p; }

} // namespace px
