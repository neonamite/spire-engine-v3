// SpireEngine.exe - the engine. Opens the Project Hub, where you pick a game.
// Games are compiled in and register themselves (see core/GameRegistry.h).
//
//   SpireEngine.exe                      -> Project Hub
//   SpireEngine.exe --game vanguard      -> straight into a game's editor
//   SpireEngine.exe --game sandbox       -> empty sandbox
//   SpireEngine.exe --export-sounds dir  -> write the built-in sounds as .wav files
#include <cstdio>
#include <cstring>
#include "audio/AudioEngine.h"
#include "core/Application.h"

int main(int argc, char** argv) {
    // SpireEngine --export-sounds <folder>: writes every built-in sound as a .wav and exits.
    for (int i = 1; i + 1 < argc; ++i)
        if (std::strcmp(argv[i], "--export-sounds") == 0) {
            px::AudioEngine audio;
            audio.initOffline();
            std::printf("Wrote %d sounds to %s\n", audio.exportAll(argv[i + 1]), argv[i + 1]);
            return 0;
        }
    px::Application app;
    if (!app.init(argc, argv)) {
        app.shutdown();
        return 1;
    }
    app.run();
    app.shutdown();
    return 0;
}
