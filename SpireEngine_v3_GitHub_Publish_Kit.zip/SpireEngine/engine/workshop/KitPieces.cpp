#include "workshop/KitPieces.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include "workshop/Workshop.h"

namespace px {

const std::vector<KitStyle>& builtinKitStyles() {
    static const std::vector<KitStyle> styles = {
        //  name            blurb                                                                     wall              base             frame          floor        roof             stairs       pillar           accent       trim             glass
        { "Brick house",  "Red brick on a stone plinth, white-painted sash windows, a clay-tile roof.",   MAT_BRICK,     MAT_CONCRETE,    MAT_PLASTER,   MAT_WOOD,    MAT_ROOF_TILES,  MAT_WOOD,    MAT_CONCRETE,    MAT_NATURAL, MAT_CONCRETE,    MAT_GLASS },
        { "Timber cabin", "Plank walls on fieldstone, chunky wooden frames, a shingled roof.",             MAT_WOOD,      MAT_COBBLESTONE, MAT_WOOD,      MAT_WOOD,    MAT_SLATE,       MAT_WOOD,    MAT_WOOD,        MAT_NATURAL, MAT_WOOD,        MAT_GLASS },
        { "Stone keep",   "Heavy coursed stone, oak frames, a slate roof.",                                MAT_COBBLESTONE, MAT_STONE,     MAT_WOOD,      MAT_SLATE,   MAT_SLATE,       MAT_STONE,   MAT_STONE,       MAT_NATURAL, MAT_STONE,       MAT_GLASS },
        { "Modern",       "White render on a concrete base, slim metal frames, big panes, tiled floors.",   MAT_PLASTER,   MAT_CONCRETE,    MAT_METAL,     MAT_TILE,    MAT_METAL,       MAT_CONCRETE, MAT_METAL,      MAT_NATURAL, MAT_CONCRETE,    MAT_GLASS },
        { "Sci-fi",       "Metal panels with a glowing light strip.",                                      MAT_METAL,     MAT_METAL,       MAT_METAL,     MAT_METAL,   MAT_METAL,       MAT_METAL,   MAT_METAL,       MAT_LAMP,    MAT_METAL,       MAT_GLASS },
    };
    return styles;
}

const KitStyle* findKitStyle(const std::string& name) {
    for (const KitStyle& s : builtinKitStyles()) if (name == s.name) return &s;
    return nullptr;
}

const KitStyle& plainKitStyle() {
    static const KitStyle plain = { "Plain", "", MAT_PLASTER, MAT_CONCRETE, MAT_WOOD, MAT_WOOD, MAT_ROOF_TILES, MAT_WOOD, MAT_STONE, MAT_NATURAL, MAT_STONE, MAT_GLASS };
    return plain;
}

std::string kitPieceName(const std::string& style, KitRole role) {
    std::string n = style;
    n += ' ';
    n += kitRoleName(role);
    return n;
}

glm::vec3 kitPieceSize(KitRole role) {
    switch (role) {
    case KitRole::Wall: case KitRole::Window: case KitRole::Doorway: return glm::vec3(2.3f, 2.45f, 0.5f);
    case KitRole::Floor:  return glm::vec3(2.1f, 0.45f, 2.1f);
    case KitRole::Roof:   return glm::vec3(3.1f, 1.7f, 2.5f);
    case KitRole::Stairs: return glm::vec3(4.2f, 2.95f, 2.1f);
    case KitRole::Pillar: return glm::vec3(0.6f, 2.45f, 0.6f);
    case KitRole::None: break;
    }
    return glm::vec3(2.0f);
}

namespace {

float boxSdf(const glm::vec3& q, const glm::vec3& half) {
    const glm::vec3 d = glm::abs(q) - half;
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f);
}
float roundedBox(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
// A box whose four long edges along x are cut at 45 degrees (`c` metres): plinths, sills, caps, beams.
float chamferX(const glm::vec3& q, const glm::vec3& half, float c) {
    const float edge = (std::fabs(q.y) + std::fabs(q.z) - (half.y + half.z - c)) * 0.70710678f;
    return std::max(boxSdf(q, half), edge);
}
float chamferY(const glm::vec3& q, const glm::vec3& half, float c) {       // the four upright edges (posts)
    const float edge = (std::fabs(q.x) + std::fabs(q.z) - (half.x + half.z - c)) * 0.70710678f;
    return std::max(boxSdf(q, half), edge);
}
float cylinderY(const glm::vec3& q, float r, float halfH) {
    const glm::vec2 d = glm::abs(glm::vec2(glm::length(glm::vec2(q.x, q.z)), q.y)) - glm::vec2(r, halfH);
    return std::min(std::max(d.x, d.y), 0.0f) + glm::length(glm::max(d, glm::vec2(0.0f)));
}
float torusY(const glm::vec3& q, float R, float r) { return glm::length(glm::vec2(glm::length(glm::vec2(q.x, q.z)) - R, q.y)) - r; }

using Sdf = std::function<float(const glm::vec3&)>;

struct Builder {
    Workshop& w;
    void add(const Sdf& f, const glm::vec3& lo, const glm::vec3& hi, MaterialId mat, float blend = 0.0f) { w.stampSdf(f, lo, hi, StampMode::Add, mat, blend); }
    void carve(const Sdf& f, const glm::vec3& lo, const glm::vec3& hi) { w.stampSdf(f, lo, hi, StampMode::Carve, MAT_STONE, 0.0f); }
    void box(glm::vec3 c, glm::vec3 h, float r, MaterialId mat) {
        add([=](const glm::vec3& p) { return roundedBox(p - c, h, r); }, c - h - glm::vec3(0.1f), c + h + glm::vec3(0.1f), mat);
    }
    void beamX(glm::vec3 c, glm::vec3 h, float ch, MaterialId mat) {      // chamfered along x
        add([=](const glm::vec3& p) { return chamferX(p - c, h, ch); }, c - h - glm::vec3(0.1f), c + h + glm::vec3(0.1f), mat);
    }
    void postY(glm::vec3 c, glm::vec3 h, float ch, MaterialId mat) {      // chamfered upright
        add([=](const glm::vec3& p) { return chamferY(p - c, h, ch); }, c - h - glm::vec3(0.1f), c + h + glm::vec3(0.1f), mat);
    }
    // A box seen on the x/y plane with its edges cut at 45 degrees round the front, (a frame member, a jamb)
    void cut(glm::vec3 c, glm::vec3 h) {
        carve([=](const glm::vec3& p) { return boxSdf(p - c, h); }, c - h - glm::vec3(0.1f), c + h + glm::vec3(0.1f));
    }
};

// The plain wall every wall-like piece starts from: 2.2 m long so corners close, a plinth with a weathered top and a cap.
void wallBody(Builder& b, const KitStyle& st) {
    b.box({ 0, 1.135f, 0 }, { 1.1f, 1.165f, 0.1f }, 0.0f, st.wall);                         // y -0.03 .. 2.30
    b.beamX({ 0, 0.155f, 0 }, { 1.1f, 0.185f, 0.13f }, 0.035f, st.base);                   // plinth, y -0.03 .. 0.34, proud of the wall
    b.beamX({ 0, 2.25f, 0 },  { 1.1f, 0.055f, 0.135f }, 0.025f, st.trim);                  // cap / band course, y 2.195 .. 2.305
    b.beamX({ 0, 2.175f, 0 }, { 1.1f, 0.022f, 0.115f }, 0.01f, st.trim);                   // its bed moulding: a second, smaller step
    if (st.accent != MAT_NATURAL) b.box({ 0, 1.75f, 0 }, { 1.1f, 0.035f, 0.108f }, 0.0f, st.accent);   // light strip
}

void addEdgeSockets(Workshop& w, float half) {
    w.addSocket("edge_l", { -half, 0.0f, 0.0f }, { -1, 0, 0 });
    w.addSocket("edge_r", {  half, 0.0f, 0.0f }, {  1, 0, 0 });
}

// A rectangular ring in the x/y plane: an outer box minus an inner one (window frames, door linings).
Sdf ring(glm::vec2 lo, glm::vec2 hi, float border, float halfDepth) {
    const glm::vec3 c((lo.x + hi.x) * 0.5f, (lo.y + hi.y) * 0.5f, 0.0f);
    const glm::vec3 outer((hi.x - lo.x) * 0.5f, (hi.y - lo.y) * 0.5f, halfDepth);
    const glm::vec3 inner(outer.x - border, outer.y - border, halfDepth + 0.1f);
    return [=](const glm::vec3& p) { return std::max(boxSdf(p - c, outer), -boxSdf(p - c, inner)); };
}

// A glazed window filling the opening lo..hi: a frame, glazing bars, glass set back in the middle of the wall.
void glazedWindow(Builder& b, const KitStyle& st, glm::vec2 lo, glm::vec2 hi, bool modern) {
    const float border = modern ? 0.04f : 0.065f, depth = modern ? 0.035f : 0.05f, bar = modern ? 0.0f : 0.022f;
    b.add(ring(lo, hi, border, depth), glm::vec3(lo.x - 0.1f, lo.y - 0.1f, -0.2f), glm::vec3(hi.x + 0.1f, hi.y + 0.1f, 0.2f), st.frame);
    const glm::vec3 gc((lo.x + hi.x) * 0.5f, (lo.y + hi.y) * 0.5f, 0.0f);
    const glm::vec3 gh((hi.x - lo.x) * 0.5f - border + 0.01f, (hi.y - lo.y) * 0.5f - border + 0.01f, 0.022f);   // a voxel thick at least, so the pane never has holes
    b.box(gc, gh, 0.0f, st.glass);
    if (bar > 0.0f) {
        // a centre mullion and a transom two thirds up: four panes, the top two shorter (a sash window's look)
        const float ty = lo.y + (hi.y - lo.y) * 0.62f;
        b.box({ gc.x, gc.y, 0 }, { bar, gh.y, depth * 0.75f }, 0.006f, st.frame);
        b.box({ gc.x, ty, 0 }, { gh.x, bar, depth * 0.75f }, 0.006f, st.frame);
        // a sash rail in the middle of the frame's depth: the top sash sits in front of the bottom one
        b.box({ gc.x, ty - 0.03f, 0.02f }, { gh.x, 0.018f, 0.018f }, 0.004f, st.frame);
    } else {
        b.box({ gc.x, gc.y, 0 }, { 0.016f, gh.y, depth * 0.8f }, 0.004f, st.frame);   // one slim mullion
    }
}

} // namespace

void buildKitPiece(Workshop& w, KitRole role, const KitStyle& st) {
    Builder b{ w };
    const bool modern = st.wall == MAT_PLASTER && st.frame == MAT_METAL;
    const bool scifi = st.wall == MAT_METAL;
    const bool timber = st.frame == MAT_WOOD && st.wall == MAT_WOOD;
    w.beginStroke("Build kit piece");
    switch (role) {
    case KitRole::Wall:
        wallBody(b, st);
        if (timber) {                                                                          // log-cabin corner posts at each end
            for (float x : { -1.04f, 1.04f }) b.postY({ x, 1.13f, 0 }, { 0.07f, 1.1f, 0.12f }, 0.025f, st.frame);
        }
        addEdgeSockets(w, 1.0f);
        w.addSocket("top", { 0, 2.3f, 0 }, { 0, 1, 0 });
        break;

    case KitRole::Doorway: {
        wallBody(b, st);
        b.cut({ 0, 0.95f, 0 }, { 0.55f, 1.05f, 0.3f });                                        // 1.1 m wide, 2 m tall, down through the plinth
        // a lining in the reveal, an architrave round the opening on both faces, a cornice over it, a stone threshold
        b.add(ring({ -0.55f, -0.03f }, { 0.55f, 2.03f }, 0.035f, 0.1f), glm::vec3(-0.7f, -0.1f, -0.2f), glm::vec3(0.7f, 2.2f, 0.2f), st.frame);
        for (float sz : { -1.0f, 1.0f }) {
            const float z = sz * 0.112f;
            b.box({ -0.6f, 1.05f, z }, { 0.055f, 1.05f, 0.014f }, 0.008f, st.frame);           // architrave jambs
            b.box({  0.6f, 1.05f, z }, { 0.055f, 1.05f, 0.014f }, 0.008f, st.frame);
            b.box({ 0.0f, 2.08f, z }, { 0.655f, 0.05f, 0.014f }, 0.008f, st.frame);            // head
        }
        b.beamX({ 0.0f, 2.16f, 0 }, { 0.72f, 0.03f, 0.135f }, 0.015f, st.trim);                // cornice
        b.beamX({ 0.0f, 0.0f, 0 }, { 0.6f, 0.035f, 0.15f }, 0.012f, st.trim);                  // threshold
        addEdgeSockets(w, 1.0f);
        w.addSocket("door_centre", { 0, 1.0f, 0 }, { 0, 0, 1 });
        w.addSocket("hinge", { -0.55f, 0, 0 }, { 0, 1, 0 });
        break;
    }

    case KitRole::Window: {
        wallBody(b, st);
        const float halfW = modern ? 0.7f : 0.55f, sill = modern ? 0.6f : 0.85f, head = modern ? 2.05f : 1.85f;
        b.cut({ 0, (sill + head) * 0.5f, 0 }, { halfW, (head - sill) * 0.5f, 0.3f });
        glazedWindow(b, st, { -halfW, sill }, { halfW, head }, modern || scifi);
        // a stone sill, sloped to shed rain and sticking out on both faces, and a lintel over the opening
        b.beamX({ 0, sill - 0.035f, 0 }, { halfW + 0.1f, 0.045f, 0.155f }, 0.03f, st.trim);
        if (!modern && !scifi) b.beamX({ 0, head + 0.07f, 0 }, { halfW + 0.12f, 0.07f, 0.112f }, 0.012f, st.trim);
        addEdgeSockets(w, 1.0f);
        w.addSocket("sill", { 0, sill, 0 }, { 0, 1, 0 });
        break;
    }

    case KitRole::Floor:
        b.add([](const glm::vec3& p) { return chamferX(p - glm::vec3(0, 0.1f, 0), glm::vec3(1.0f, 0.1f, 1.0f), 0.015f); },
              glm::vec3(-1.1f, -0.1f, -1.1f), glm::vec3(1.1f, 0.3f, 1.1f), st.floor);
        w.addSocket("centre", { 0, 0.2f, 0 }, { 0, 1, 0 });
        break;

    case KitRole::Roof: {
        // The roof covers x -1 (the wall line) .. +1 (the ridge), 2.2 m along z, so two back to back make a gable roof.
        // Under the roof covering, a wedge in the wall's material fills the gable; the covering itself is a slab 12 cm
        // thick that runs out 30 cm past the wall as eaves, with tile courses stepped into it, a fascia, a gutter and
        // a ridge cap.
        const float k = 1.0f / std::sqrt(1.25f);
        auto topAt = [](float x) { return 0.3f + 0.5f * (x + 1.0f); };
        const bool tiles = st.roof == MAT_ROOF_TILES, slates = st.roof == MAT_SLATE, sheet = st.roof == MAT_METAL;
        const float course = tiles ? 0.30f : slates ? 0.22f : 0.0f;          // spacing of the courses along x
        const float step = tiles ? 0.035f : 0.022f;
        const MaterialId gable = st.wall;
        const Sdf wedge = [k, topAt](const glm::vec3& p) {
            const float bx = std::max(-1.0f - p.x, p.x - 1.0f);
            const float bz = std::fabs(p.z) - 1.1f;
            return std::max(std::max(bx, bz), std::max(-p.y, (p.y - (topAt(p.x) - 0.1f)) * k));
        };
        b.add(wedge, glm::vec3(-1.1f, -0.1f, -1.25f), glm::vec3(1.1f, 1.3f, 1.25f), gable);
        const Sdf slab = [=](const glm::vec3& p) {
            float ripple = 0.0f;
            if (course > 0.0f) {
                const float t = (p.x + 1.3f) / course;
                ripple = step * (1.0f - (t - std::floor(t)));                // each course's lower edge stands proud of the next
                if (tiles) ripple += 0.014f * std::fabs(std::sin(p.z * 3.14159265f / 0.21f));   // the barrel of each clay tile
            } else if (sheet) {
                ripple = 0.022f * std::max(0.0f, 1.0f - std::fabs(std::fmod(std::fabs(p.z) + 0.25f, 0.5f) - 0.25f) / 0.03f);   // standing seams
            }
            const float top = (p.y - topAt(p.x) - ripple) * k;
            const float bottom = (topAt(p.x) - 0.12f - p.y) * k;
            const float bx = std::max(-1.32f - p.x, p.x - 1.0f);
            const float bz = std::fabs(p.z) - 1.1f;
            return std::max(std::max(top, bottom), std::max(bx, bz));
        };
        b.add(slab, glm::vec3(-1.45f, -0.1f, -1.25f), glm::vec3(1.1f, 1.45f, 1.25f), st.roof);
        // ridge cap: a half-round along the ridge (two pieces back to back share it)
        b.add([](const glm::vec3& p) {
                  const float d = glm::length(glm::vec2(p.x - 1.0f, p.y - 1.27f)) - 0.085f;
                  return std::max(std::max(d, std::fabs(p.z) - 1.1f), 1.2f - p.y);
              }, glm::vec3(0.85f, 1.1f, -1.25f), glm::vec3(1.15f, 1.45f, 1.25f), st.roof);
        // fascia board along the eave, rafter tails under the overhang, a gutter
        const float eaveTop = topAt(-1.32f);
        b.box({ -1.335f, eaveTop - 0.1f, 0 }, { 0.02f, 0.1f, 1.1f }, 0.005f, st.frame);
        if (!sheet && !scifi)
            for (int i = 0; i < 4; ++i) {
                const float z = -0.825f + 0.55f * float(i);
                const float x0 = -1.32f, x1 = -0.98f;
                b.add([=](const glm::vec3& p) {
                          const float along = std::clamp((p.x - x0) / (x1 - x0), 0.0f, 1.0f);
                          const float y = topAt(x0 + (x1 - x0) * along) - 0.17f;
                          return std::max(std::max(std::fabs(p.z - z) - 0.035f, std::fabs(p.y - y) - 0.045f), std::max(x0 - p.x, p.x - x1));
                      }, glm::vec3(x0 - 0.1f, -0.1f, z - 0.15f), glm::vec3(x1 + 0.1f, 0.6f, z + 0.15f), st.frame == MAT_PLASTER ? MaterialId(MAT_WOOD) : st.frame);
            }
        b.add([eaveTop](const glm::vec3& p) {                                                  // an open half-pipe, hung under the tile edge
                  const glm::vec2 q(p.x + 1.43f, p.y - (eaveTop - 0.08f));
                  const float pipe = std::fabs(glm::length(q) - 0.065f) - 0.007f;
                  return std::max(std::max(pipe, q.y), std::fabs(p.z) - 1.1f);
              }, glm::vec3(-1.55f, eaveTop - 0.25f, -1.25f), glm::vec3(-1.3f, eaveTop + 0.05f, 1.25f), MAT_METAL);
        w.addSocket("ridge", { 1.0f, 1.3f, 0 }, { 0, 1, 0 });
        w.addSocket("eave", { -1.25f, 0.0f, 0 }, { -1, 0, 0 });
        break;
    }

    case KitRole::Stairs: {
        constexpr int steps = 12;
        const float run = 4.0f / float(steps), rise = kKitStorey / float(steps);
        for (int i = 0; i < steps; ++i) {
            const float x0 = -2.0f + run * float(i), top = rise * float(i + 1);
            b.box({ (x0 + 2.0f) * 0.5f, (top - 0.03f) * 0.5f, 0 }, { (2.0f - x0) * 0.5f, (top + 0.03f) * 0.5f, 0.88f }, 0.0f, st.stairs);   // solid down to the floor
            b.beamX({ x0 + 0.01f, top - 0.022f, 0 }, { 0.035f, 0.022f, 0.88f }, 0.01f, st.stairs);                                       // a rounded nosing
        }
        // stringers up both sides, following the pitch
        for (float sz : { -1.0f, 1.0f }) {
            const float z = sz * 0.92f;
            const float slope = kKitStorey / 4.0f, k = 1.0f / std::sqrt(1.0f + slope * slope);
            b.add([=](const glm::vec3& p) {
                      const float line = (p.y - (slope * (p.x + 2.0f) + 0.12f)) * k;
                      return std::max(std::max(std::max(line, -p.y), p.y - kKitStorey), std::max(std::max(-2.0f - p.x, p.x - 2.0f), std::fabs(p.z - z) - 0.04f));
                  }, glm::vec3(-2.1f, -0.1f, z - 0.15f), glm::vec3(2.1f, kKitStorey + 0.3f, z + 0.15f), st.frame == MAT_PLASTER ? st.stairs : st.frame);
        }
        w.addSocket("start", { -2.0f, 0.0f, 0 }, { -1, 0, 0 });
        w.addSocket("top", { 2.0f, kKitStorey, 0 }, { 0, 1, 0 });
        break;
    }

    case KitRole::Pillar:
        if (st.pillar == MAT_WOOD) {
            b.postY({ 0, 1.15f, 0 }, { 0.12f, 1.12f, 0.12f }, 0.03f, st.pillar);                  // a chamfered post
            b.box({ 0, 0.06f, 0 }, { 0.18f, 0.09f, 0.18f }, 0.02f, st.base);                       // on a stone pad
            b.beamX({ 0, 2.22f, 0 }, { 0.2f, 0.08f, 0.16f }, 0.03f, st.pillar);                    // a bolster under the beam
        } else if (st.pillar == MAT_METAL) {
            b.add([](const glm::vec3& p) { return cylinderY(p - glm::vec3(0, 1.15f, 0), 0.1f, 1.12f); }, glm::vec3(-0.2f, -0.05f, -0.2f), glm::vec3(0.2f, 2.35f, 0.2f), st.pillar);
            b.box({ 0, 0.02f, 0 }, { 0.17f, 0.025f, 0.17f }, 0.005f, st.pillar);                   // base plate
            b.box({ 0, 2.28f, 0 }, { 0.17f, 0.025f, 0.17f }, 0.005f, st.pillar);                   // cap plate
            if (st.accent != MAT_NATURAL) b.add([](const glm::vec3& p) { return cylinderY(p - glm::vec3(0, 1.75f, 0), 0.108f, 0.04f); }, glm::vec3(-0.2f, 1.6f, -0.2f), glm::vec3(0.2f, 1.9f, 0.2f), st.accent);
        } else {
            // a classical column: square plinth, a round moulding, a slightly tapering shaft, a moulded capital and an abacus
            b.box({ 0, 0.05f, 0 }, { 0.22f, 0.07f, 0.22f }, 0.01f, st.base);
            b.add([](const glm::vec3& p) { return torusY(p - glm::vec3(0, 0.15f, 0), 0.155f, 0.045f); }, glm::vec3(-0.25f, 0.05f, -0.25f), glm::vec3(0.25f, 0.25f, 0.25f), st.pillar);
            b.add([](const glm::vec3& p) {
                      const float t = std::clamp(p.y / 2.2f, 0.0f, 1.0f);
                      const float r = 0.145f - 0.02f * t * t;                              // entasis: thinner toward the top
                      return std::max(glm::length(glm::vec2(p.x, p.z)) - r, std::max(0.12f - p.y, p.y - 2.12f));
                  }, glm::vec3(-0.2f, 0.0f, -0.2f), glm::vec3(0.2f, 2.2f, 0.2f), st.pillar, 0.02f);
            b.add([](const glm::vec3& p) { return torusY(p - glm::vec3(0, 2.1f, 0), 0.135f, 0.035f); }, glm::vec3(-0.2f, 2.0f, -0.2f), glm::vec3(0.2f, 2.2f, 0.2f), st.pillar);
            b.box({ 0, 2.23f, 0 }, { 0.2f, 0.065f, 0.2f }, 0.012f, st.trim);
        }
        w.addSocket("top", { 0, 2.3f, 0 }, { 0, 1, 0 });
        break;

    case KitRole::None: break;
    }
    w.endStroke();
}

AssetPtr makeKitAsset(const std::string& styleName, KitRole role) {
    Workshop w;
    NewAssetSpec spec;
    spec.tmpl = WorkshopTemplate::KitPiece;
    spec.kitRole = role;
    spec.kitStyle = styleName;
    spec.name = kitPieceName(styleName, role);
    w.create(spec);
    auto a = std::make_shared<Asset>(w.asset);
    a->userMade = false;
    return a;
}

void registerBuiltinKits(AssetLibrary& lib) {
    for (const KitStyle& st : builtinKitStyles()) {
        for (int r = 1; r < kKitRoleCount; ++r) {
            const KitRole role = KitRole(r);
            const std::string style = st.name;
            lib.addGenerated(kitPieceName(style, role), kitTagList(style, role), [style, role] { return makeKitAsset(style, role); });
        }
    }
}

} // namespace px
