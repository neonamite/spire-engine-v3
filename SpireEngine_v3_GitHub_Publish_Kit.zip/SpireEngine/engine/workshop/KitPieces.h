#pragma once
// The built-in building kits: five looks (Brick house, Timber cabin, Stone keep, Modern, Sci-fi), each with
// the seven pieces of scene/BuildKit.h. Pieces are made with the Asset Workshop's own tools at 4 cm detail the
// first time something asks for them, and they are ordinary assets, so you can open any of them in the Workshop,
// change it and save your own version under the same name.
//
// Where a piece's origin is (asset space; x runs along the piece, y is up):
//   wall, window, doorway  centre of the bottom edge; 2.2 m long, 0.2 m thick, 2.3 m tall (a little of the
//                          foot goes below the origin so it sits into the floor without a seam)
//   floor                  centre of the bottom of the slab; 2 x 0.2 x 2 m
//   roof                   centre of the underside; low edge toward -x, rising 1 m over 2 m (toward +x)
//   stairs                 centre of the bottom step; 4 m long along x, 1.8 m wide, climbing 2.5 m toward +x
//   pillar                 centre of the foot; 0.3 m square, 2.3 m tall
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "scene/BuildKit.h"
#include "world/Materials.h"

namespace px {

class Workshop;

constexpr float kKitVoxel = 0.04f;      // 4 cm: sills, mouldings and roof-tile courses come out crisp

struct KitStyle {
    const char* name;
    const char* blurb;
    MaterialId wall, base, frame, floor, roof, stairs, pillar;
    MaterialId accent;          // a stripe along walls and pillars (0 = none)
    MaterialId trim = MAT_STONE;   // sills, lintels, wall caps, thresholds
    MaterialId glass = MAT_GLASS;  // window panes
};

const std::vector<KitStyle>& builtinKitStyles();
const KitStyle* findKitStyle(const std::string& name);       // nullptr when it is not a built-in one
const KitStyle& plainKitStyle();                              // the look a new kit piece from the Workshop starts with

std::string kitPieceName(const std::string& style, KitRole role);         // "Brick house wall"
glm::vec3 kitPieceSize(KitRole role);                                     // metres of space the Workshop needs for it

// Stamps one piece into a Workshop that was created with that role's size and kKitVoxel detail, adds its sockets.
void buildKitPiece(Workshop& w, KitRole role, const KitStyle& style);
// A finished asset: named, typed Building piece, tagged for its kit. Not marked as user-made.
AssetPtr makeKitAsset(const std::string& styleName, KitRole role);
// Lists every built-in piece in the library (they are built when first used).
void registerBuiltinKits(AssetLibrary& lib);

} // namespace px
