#pragma once
// The Asset Workshop's model: one asset being built, and everything you can do to it. No window,
// no OpenGL: the editor UI (editor/WorkshopUI.cpp) drives it, and the tests drive it too.
//
// The asset is a grid of fine voxels (density + material, like the world but 4x or more finer).
// Edits are "stamps": a shape (box, sphere, cylinder, cone, wedge) added, carved or painted
// into the grid, optionally mirrored across the model's middle. Every stroke is one undo step.
// Meshing is done per 16-cell block, so only the blocks an edit touched are rebuilt.
#include <array>
#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>
#include "scene/Asset.h"
#include "scene/BuildKit.h"

namespace px {

enum class Shape : std::uint8_t { Box, Sphere, Cylinder, Cone, Wedge };
constexpr int kShapeCount = 5;
const char* shapeName(Shape s);

enum class StampMode : std::uint8_t { Add, Carve, Paint };

struct Stamp {
    Shape      shape = Shape::Box;
    StampMode  mode = StampMode::Add;
    glm::vec3  centre{ 0.0f };           // asset space, metres
    glm::vec3  half{ 0.5f };             // half the size along each of the shape's own axes, metres
    float      yaw = 0.0f;               // degrees around Y
    float      round = 0.0f;             // rounds the shape's own edges (metres)
    float      blend = 0.0f;             // how softly it melts into what is already there (metres)
    MaterialId material = MAT_STONE;
};
// Signed distance from a point (asset space, metres) to the stamp's shape: negative inside, roughly metres.
float stampDistance(const Stamp& s, const glm::vec3& p);
// How far the shape reaches from its centre along a direction (used to rest it on a surface).
float stampReach(const Stamp& s, const glm::vec3& direction);

struct Mirror { bool x = false, y = false, z = false; bool any() const { return x || y || z; } };

struct WorkshopHit {
    bool      hit = false;
    bool      floor = false;             // the ray reached the floor (y = 0) rather than the model
    float     distance = 0.0f;
    glm::vec3 point{ 0.0f }, normal{ 0.0f, 1.0f, 0.0f };
};

enum class WorkshopTemplate { Blank, Mannequin, Sword, Pistol, Wall, DoorFrame, KitPiece, Count };
const char* templateName(WorkshopTemplate t);
const char* templateInfo(WorkshopTemplate t);

struct NewAssetSpec {
    std::string name = "New asset";
    WorkshopTemplate tmpl = WorkshopTemplate::Blank;
    float voxelSize = 0.125f;                        // Blank only: templates pick their own detail
    glm::vec3 sizeMetres{ 6.0f, 4.0f, 6.0f };        // Blank only
    KitRole kitRole = KitRole::Wall;                 // KitPiece only: which piece of a building kit
    std::string kitStyle = "My kit";                 // KitPiece only: the kit it belongs to (becomes the kit: tag)
};

class Workshop {
public:
    Asset asset;                                     // the working copy (its mesh is kept up to date by remesh())

    // ---- starting
    void create(const NewAssetSpec& spec);           // fresh asset (or a template); history cleared; not modified
    void adopt(const Asset& a);                      // edit a copy of an existing asset
    // A copy of an existing asset re-sampled onto a finer grid with room (marginMetres) all round, so a coarse
    // asset such as a prefab can be built onto. The grid gets coarser than asked only when it would be too big.
    void adoptResampled(const Asset& a, float voxelSize, float marginMetres);
    static glm::ivec3 gridFor(const glm::vec3& metres, float voxelSize);   // clamps to what the Workshop allows

    // ---- editing. Each returns how many voxels changed. Outside beginStroke/endStroke a call is its own undo step.
    int stamp(const Stamp& s, const Mirror& m = {});
    // A stamp described by any distance function (metres, asset space) inside a box. Templates use this for limbs and so on.
    int stampSdf(const std::function<float(const glm::vec3&)>& distance, const glm::vec3& boxMin, const glm::vec3& boxMax,
                 StampMode mode, MaterialId material, float blendMetres, const Mirror& m = {});
    // Repaints the connected patch of one material under `near`. Returns the voxels changed.
    int fill(const glm::vec3& near, MaterialId material, const Mirror& m = {});
    int smooth(const glm::vec3& centre, float radiusMetres, float strength, const Mirror& m = {});

    void beginStroke(const std::string& label);
    void endStroke();                                // records one step (nothing when no voxel changed)
    bool inStroke() const { return stroking; }

    // ---- sockets (each is one undo step)
    bool addSocket(const std::string& name, const glm::vec3& position, const glm::vec3& direction);   // false: name taken or empty
    bool moveSocket(const std::string& name, const glm::vec3& position, const glm::vec3& direction);
    bool renameSocket(const std::string& from, const std::string& to);
    bool removeSocket(const std::string& name);
    const Socket* findSocket(const std::string& name) const;
    std::string freeSocketName(const std::string& wanted) const;       // "grip" -> "grip 2" when taken

    // ---- description
    void setName(const std::string& n);
    void setType(AssetType t);
    void setTags(const std::vector<std::string>& t);

    // ---- history
    bool undo();
    bool redo();
    bool canUndo() const { return !undoSteps.empty(); }
    bool canRedo() const { return !redoSteps.empty(); }
    std::string undoLabel() const { return undoSteps.empty() ? std::string() : undoSteps.back().label; }
    std::string redoLabel() const { return redoSteps.empty() ? std::string() : redoSteps.back().label; }

    // "Modified" is about the state, not the clicks: undoing back to what was saved is not modified.
    bool modified() const { return topStepId() != savedStepId || infoEdits != savedInfoEdits; }
    void markSaved() { savedStepId = topStepId(); savedInfoEdits = infoEdits; }
    std::uint64_t revision() const { return editCount; }       // changes on every edit, undo and redo

    // ---- looking at it
    bool meshDirty() const { return !dirtyBlocks.empty(); }
    void remesh();                                   // rebuilds the blocks edits touched, then asset.mesh and its bounds
    WorkshopHit raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist = 200.0f) const;
    glm::vec3 mirrorPoint(const glm::vec3& p, const Mirror& m, int image) const;   // image bits: 1 = x, 2 = y, 4 = z
    glm::vec3 mirrorCentre() const;                  // the point the mirror planes pass through (asset space, metres)
    glm::vec3 gridMin() const;                       // asset-space corners of the grid, metres
    glm::vec3 gridMax() const;
    size_t solidVoxels() const;                      // voxels inside the model

    static constexpr int kBlock = 16;                // cells per mesh block along each axis
    static constexpr int kMaxAxis = 160;             // samples per axis
    static constexpr size_t kMaxCells = 2500000;     // samples in total

private:
    struct Change { std::uint32_t index; float oldDensity, newDensity; MaterialId oldMat, newMat; };
    struct Step {
        std::uint64_t id = 0;
        std::string label;
        std::vector<Change> changes;
        bool socketsChanged = false;
        std::vector<Socket> socketsBefore, socketsAfter;
    };

    void reset(Asset a);
    void noteChange(std::uint32_t index, float oldD, float newD, MaterialId oldM, MaterialId newM);
    void markDirtyVoxels(const glm::ivec3& lo, const glm::ivec3& hi);
    void apply(const Step& s, bool forward);
    void pushStep(Step s);
    void socketStep(const std::string& label, const std::vector<Socket>& before);
    void trimHistory();
    glm::ivec3 blockCounts() const;

    bool stroking = false;
    std::string strokeLabel;
    std::unordered_map<std::uint32_t, Change> strokeChanges;

    std::vector<Step> undoSteps, redoSteps;
    size_t historyChanges = 0;
    std::uint64_t editCount = 0;
    std::uint64_t nextStepId = 1, savedStepId = 0, infoEdits = 0, savedInfoEdits = 0;
    std::uint64_t topStepId() const { return undoSteps.empty() ? 0 : undoSteps.back().id; }

    std::vector<std::vector<Vertex>> blockMeshes;
    std::vector<std::uint8_t> dirtyFlags;            // per block
    std::vector<int> dirtyBlocks;
};

} // namespace px
