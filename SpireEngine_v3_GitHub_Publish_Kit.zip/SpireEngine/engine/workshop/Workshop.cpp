#include "workshop/Workshop.h"
#include "workshop/KitPieces.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace px {

const char* shapeName(Shape s) {
    switch (s) {
    case Shape::Box: return "Box";
    case Shape::Sphere: return "Sphere";
    case Shape::Cylinder: return "Cylinder";
    case Shape::Cone: return "Cone";
    case Shape::Wedge: return "Wedge";
    }
    return "Box";
}

const char* templateName(WorkshopTemplate t) {
    switch (t) {
    case WorkshopTemplate::Blank: return "Blank";
    case WorkshopTemplate::Mannequin: return "Humanoid mannequin";
    case WorkshopTemplate::Sword: return "Sword blank";
    case WorkshopTemplate::Pistol: return "Pistol blank";
    case WorkshopTemplate::Wall: return "Wall segment";
    case WorkshopTemplate::DoorFrame: return "Door frame";
    case WorkshopTemplate::KitPiece: return "Building kit piece";
    default: return "Blank";
    }
}
const char* templateInfo(WorkshopTemplate t) {
    switch (t) {
    case WorkshopTemplate::Blank: return "An empty space. You choose how fine the detail is and how big the space is.";
    case WorkshopTemplate::Mannequin: return "A 1.8 m person to dress, re-shape or use as a scale. Has head, hand and back sockets.";
    case WorkshopTemplate::Sword: return "A simple sword to make your own. Has grip and blade_tip sockets.";
    case WorkshopTemplate::Pistol: return "A simple pistol to make your own. Has grip, muzzle and sight sockets.";
    case WorkshopTemplate::Wall: return "A 5 m wall piece with a plinth and cap, ready to snap into a building.";
    case WorkshopTemplate::DoorFrame: return "A wall with a doorway and a wooden frame, with hinge and door sockets.";
    case WorkshopTemplate::KitPiece: return "A wall, window, doorway, floor, roof, stairs or pillar that snaps to the building grid. Make a set and they build houses together.";
    default: return "";
    }
}

// ------------------------------------------------------------------ shapes

namespace {
glm::vec3 toShape(const Stamp& s, const glm::vec3& p) {
    const glm::vec3 q = p - s.centre;
    const float r = glm::radians(s.yaw), c = std::cos(r), sn = std::sin(r);
    return glm::vec3(c * q.x - sn * q.z, q.y, sn * q.x + c * q.z);
}
float roundedBox(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
float capsule(const glm::vec3& p, const glm::vec3& a, const glm::vec3& b, float r) {
    const glm::vec3 pa = p - a, ba = b - a;
    const float h = std::clamp(glm::dot(pa, ba) / std::max(1e-9f, glm::dot(ba, ba)), 0.0f, 1.0f);
    return glm::length(pa - ba * h) - r;
}
float ellipsoid(const glm::vec3& q, const glm::vec3& half) {
    const float k0 = glm::length(q / half), k1 = glm::length(q / (half * half));
    return k1 < 1e-9f ? -std::min(half.x, std::min(half.y, half.z)) : k0 * (k0 - 1.0f) / k1;
}
// Round-edged combination of a radial distance and a height distance (cylinder, cone).
float roundedRevolve(float dr, float dy, float r) {
    dr += r; dy += r;
    return std::min(std::max(dr, dy), 0.0f) + glm::length(glm::vec2(std::max(dr, 0.0f), std::max(dy, 0.0f))) - r;
}
float smin(float a, float b, float k) {
    const float h = std::clamp(0.5f + 0.5f * (b - a) / k, 0.0f, 1.0f);
    return glm::mix(b, a, h) - k * h * (1.0f - h);
}
}

float stampDistance(const Stamp& s, const glm::vec3& p) {
    const glm::vec3 q = toShape(s, p);
    const glm::vec3 h = glm::max(s.half, glm::vec3(1e-4f));
    const float mn = std::min(h.x, std::min(h.y, h.z));
    const float r = std::clamp(s.round, 0.0f, mn * 0.999f);
    switch (s.shape) {
    case Shape::Box:    return roundedBox(q, h, r);
    case Shape::Sphere: return ellipsoid(q, h);
    case Shape::Cylinder: {
        const float dr = (glm::length(glm::vec2(q.x / h.x, q.z / h.z)) - 1.0f) * std::min(h.x, h.z);
        return roundedRevolve(dr, std::fabs(q.y) - h.y, std::min(r, std::min(h.x, h.z) * 0.999f));
    }
    case Shape::Cone: {
        const float t = std::clamp((q.y + h.y) / (2.0f * h.y), 0.0f, 1.0f);
        const float rad = std::min(h.x, h.z);
        const float slope = rad / (2.0f * h.y);
        const float dr = (glm::length(glm::vec2(q.x / h.x, q.z / h.z)) - (1.0f - t)) * rad / std::sqrt(1.0f + slope * slope);
        return roundedRevolve(dr, std::fabs(q.y) - h.y, std::min(r, rad * 0.5f));
    }
    case Shape::Wedge: {
        // A ramp: full height at the back (-z), nothing at the front (+z).
        const float len = std::sqrt(h.z * h.z + h.y * h.y);
        const float plane = ((q.y + h.y) * h.z + (q.z - h.z) * h.y) / std::max(1e-6f, len);
        return std::max(roundedBox(q, h, r), plane);
    }
    }
    return 1.0f;
}

float stampReach(const Stamp& s, const glm::vec3& dir) {
    const float r = glm::radians(s.yaw), c = std::cos(r), sn = std::sin(r);
    const glm::vec3 n(c * dir.x - sn * dir.z, dir.y, sn * dir.x + c * dir.z);
    if (s.shape == Shape::Sphere) return glm::length(n * s.half);
    return std::fabs(n.x) * s.half.x + std::fabs(n.y) * s.half.y + std::fabs(n.z) * s.half.z;
}

// ------------------------------------------------------------------ setup

glm::ivec3 Workshop::gridFor(const glm::vec3& metres, float voxelSize) {
    glm::vec3 n = glm::ceil(metres / std::max(voxelSize, 0.005f));
    n = glm::clamp(n, glm::vec3(8.0f), glm::vec3(float(kMaxAxis)));
    double cells = double(n.x) * n.y * n.z;
    if (cells > double(kMaxCells)) n = glm::max(glm::vec3(8.0f), glm::floor(n * float(std::cbrt(double(kMaxCells) / cells))));
    return glm::ivec3(n);
}

void Workshop::reset(Asset a) {
    asset = std::move(a);
    undoSteps.clear(); redoSteps.clear(); historyChanges = 0;
    strokeChanges.clear(); stroking = false;
    editCount = 0; savedStepId = 0; infoEdits = savedInfoEdits = 0;
    const glm::ivec3 bc = blockCounts();
    blockMeshes.assign(size_t(bc.x) * bc.y * bc.z, {});
    dirtyFlags.assign(blockMeshes.size(), 1);
    dirtyBlocks.clear();
    for (size_t i = 0; i < dirtyFlags.size(); ++i) dirtyBlocks.push_back(int(i));
    remesh();
}

glm::ivec3 Workshop::blockCounts() const {
    return glm::ivec3((asset.size.x + 1 + kBlock - 1) / kBlock, (asset.size.y + 1 + kBlock - 1) / kBlock, (asset.size.z + 1 + kBlock - 1) / kBlock);
}

void Workshop::adopt(const Asset& a) {
    Asset copy = a;
    if (copy.materials.size() != copy.grid.size()) copy.materials.assign(copy.grid.size(), MaterialId(MAT_STONE));
    copy.mesh.clear();
    reset(std::move(copy));
}

void Workshop::adoptResampled(const Asset& src, float voxelSize, float marginMetres) {
    const float margin = std::max(marginMetres, 0.0f);
    float vs = std::clamp(voxelSize, 0.01f, 2.0f);
    glm::vec3 lo = -src.pivot * src.voxelSize - glm::vec3(margin);
    const glm::vec3 hi = (glm::vec3(src.size) - glm::vec3(1.0f) - src.pivot) * src.voxelSize + glm::vec3(margin);
    lo.y = std::min(lo.y, -std::max(vs, 0.25f));                      // always room below the floor
    glm::ivec3 n(8);
    for (int guard = 0; guard < 60; ++guard) {
        n = glm::max(glm::ivec3(glm::ceil((hi - lo) / vs)) + glm::ivec3(1), glm::ivec3(8));
        if (n.x <= kMaxAxis && n.y <= kMaxAxis && n.z <= kMaxAxis && size_t(n.x) * size_t(n.y) * size_t(n.z) <= kMaxCells) break;
        vs *= 1.2f;
    }
    Asset a;
    a.name = src.name; a.type = src.type; a.tags = src.tags; a.sockets = src.sockets; a.userMade = true;
    a.voxelSize = vs;
    a.size = n;
    a.pivot = -lo / vs;
    const size_t cells = size_t(n.x) * size_t(n.y) * size_t(n.z);
    a.grid.assign(cells, DENSITY_CLAMP);
    a.materials.assign(cells, MaterialId(MAT_STONE));
    size_t i = 0;
    for (int z = 0; z < n.z; ++z)
        for (int y = 0; y < n.y; ++y)
            for (int x = 0; x < n.x; ++x, ++i) {
                const glm::vec3 p = (glm::vec3(float(x), float(y), float(z)) - a.pivot) * vs;
                const float d = src.density(p) / vs;
                a.grid[i] = std::clamp(d, -DENSITY_CLAMP, DENSITY_CLAMP);
                if (d < 1.5f) a.materials[i] = src.materialNear(p);
            }
    reset(std::move(a));
}

namespace {
void buildTemplate(Workshop& w, const NewAssetSpec& spec);
}

void Workshop::create(const NewAssetSpec& spec) {
    Asset a;
    a.name = spec.name.empty() ? std::string(templateName(spec.tmpl)) : spec.name;
    a.userMade = true;
    float vs = spec.voxelSize;
    glm::vec3 metres = spec.sizeMetres;
    switch (spec.tmpl) {
    case WorkshopTemplate::Mannequin: vs = 0.0625f;  metres = glm::vec3(3.0f, 2.5f, 2.0f); break;
    case WorkshopTemplate::Sword:     vs = 0.015625f; metres = glm::vec3(1.0f, 1.75f, 0.5f); break;
    case WorkshopTemplate::Pistol:    vs = 0.015625f; metres = glm::vec3(1.25f, 0.875f, 0.4375f); break;
    case WorkshopTemplate::Wall:      vs = 0.125f;   metres = glm::vec3(5.5f, 4.5f, 1.75f); break;
    case WorkshopTemplate::DoorFrame: vs = 0.125f;   metres = glm::vec3(5.0f, 4.0f, 1.75f); break;
    case WorkshopTemplate::KitPiece:  vs = kKitVoxel; metres = kitPieceSize(spec.kitRole); break;
    default: break;
    }
    a.voxelSize = std::clamp(vs, 0.01f, 1.0f);
    a.size = gridFor(metres, a.voxelSize);
    a.pivot = glm::vec3(float(a.size.x - 1) * 0.5f, 1.0f, float(a.size.z - 1) * 0.5f);
    a.grid.assign(size_t(a.size.x) * a.size.y * a.size.z, DENSITY_CLAMP);
    a.materials.assign(a.grid.size(), MaterialId(MAT_STONE));
    if (spec.tmpl == WorkshopTemplate::KitPiece) {
        a.type = AssetType::BuildingPiece;
        a.tags = kitTagList(spec.kitStyle.empty() ? std::string("My kit") : spec.kitStyle, spec.kitRole);
        if (spec.name.empty()) a.name = kitPieceName(spec.kitStyle.empty() ? std::string("My kit") : spec.kitStyle, spec.kitRole);
    } else if (spec.tmpl == WorkshopTemplate::Wall || spec.tmpl == WorkshopTemplate::DoorFrame) a.type = AssetType::BuildingPiece;
    else if (spec.tmpl == WorkshopTemplate::Sword || spec.tmpl == WorkshopTemplate::Pistol) a.type = AssetType::Item;
    else if (spec.tmpl == WorkshopTemplate::Mannequin) a.type = AssetType::CharacterPart;
    reset(std::move(a));
    buildTemplate(*this, spec);
    remesh();
    undoSteps.clear(); redoSteps.clear(); historyChanges = 0;
    editCount = 0; savedStepId = 0; infoEdits = savedInfoEdits = 0;
}

glm::vec3 Workshop::gridMin() const { return -asset.pivot * asset.voxelSize; }
glm::vec3 Workshop::gridMax() const { return (glm::vec3(asset.size) - glm::vec3(1.0f) - asset.pivot) * asset.voxelSize; }
glm::vec3 Workshop::mirrorCentre() const { return (gridMin() + gridMax()) * 0.5f; }

glm::vec3 Workshop::mirrorPoint(const glm::vec3& p, const Mirror& m, int image) const {
    const glm::vec3 c = mirrorCentre();
    glm::vec3 q = p;
    if ((image & 1) && m.x) q.x = 2.0f * c.x - q.x;
    if ((image & 2) && m.y) q.y = 2.0f * c.y - q.y;
    if ((image & 4) && m.z) q.z = 2.0f * c.z - q.z;
    return q;
}

size_t Workshop::solidVoxels() const {
    size_t n = 0;
    for (float d : asset.grid) if (d < 0.0f) ++n;
    return n;
}

// ------------------------------------------------------------------ strokes and history

void Workshop::beginStroke(const std::string& label) {
    if (stroking) endStroke();
    stroking = true;
    strokeLabel = label;
    strokeChanges.clear();
}

void Workshop::noteChange(std::uint32_t index, float oldD, float newD, MaterialId oldM, MaterialId newM) {
    auto it = strokeChanges.find(index);
    if (it == strokeChanges.end()) strokeChanges.emplace(index, Change{ index, oldD, newD, oldM, newM });
    else { it->second.newDensity = newD; it->second.newMat = newM; }
}

void Workshop::markDirtyVoxels(const glm::ivec3& lo, const glm::ivec3& hi) {
    // A changed sample alters the cells around it, their normals one further out, and the shading a few more.
    const glm::ivec3 bc = blockCounts();
    const glm::ivec3 c0 = glm::max(lo - glm::ivec3(3), glm::ivec3(-1)), c1 = glm::min(hi + glm::ivec3(3), asset.size - glm::ivec3(1));
    for (int bz = (c0.z + 1) / kBlock; bz <= (c1.z + 1) / kBlock; ++bz)
        for (int by = (c0.y + 1) / kBlock; by <= (c1.y + 1) / kBlock; ++by)
            for (int bx = (c0.x + 1) / kBlock; bx <= (c1.x + 1) / kBlock; ++bx) {
                if (bx >= bc.x || by >= bc.y || bz >= bc.z) continue;
                const size_t b = size_t(bx) + size_t(by) * bc.x + size_t(bz) * bc.x * bc.y;
                if (!dirtyFlags[b]) { dirtyFlags[b] = 1; dirtyBlocks.push_back(int(b)); }
            }
}

void Workshop::trimHistory() {
    auto total = [&] { size_t n = 0; for (const Step& s : undoSteps) n += s.changes.size(); for (const Step& s : redoSteps) n += s.changes.size(); return n; };
    while (!undoSteps.empty() && (undoSteps.size() > 200 || total() > 4000000)) undoSteps.erase(undoSteps.begin());
    historyChanges = total();
}

void Workshop::pushStep(Step s) {
    s.id = nextStepId++;
    undoSteps.push_back(std::move(s));
    redoSteps.clear();
    ++editCount;
    trimHistory();
}

void Workshop::endStroke() {
    if (!stroking) return;
    stroking = false;
    Step s;
    s.label = strokeLabel;
    s.changes.reserve(strokeChanges.size());
    for (const auto& [_, c] : strokeChanges)
        if (c.oldDensity != c.newDensity || c.oldMat != c.newMat) s.changes.push_back(c);
    strokeChanges.clear();
    if (s.changes.empty()) return;
    std::sort(s.changes.begin(), s.changes.end(), [](const Change& a, const Change& b) { return a.index < b.index; });
    pushStep(std::move(s));
}

void Workshop::apply(const Step& s, bool forward) {
    const int sx = asset.size.x, sxy = asset.size.x * asset.size.y;
    for (const Change& c : s.changes) {
        asset.grid[c.index] = forward ? c.newDensity : c.oldDensity;
        asset.materials[c.index] = forward ? c.newMat : c.oldMat;
        const int z = int(c.index) / sxy, y = (int(c.index) % sxy) / sx, x = int(c.index) % sx;
        markDirtyVoxels(glm::ivec3(x, y, z), glm::ivec3(x, y, z));
    }
    if (s.socketsChanged) asset.sockets = forward ? s.socketsAfter : s.socketsBefore;
}

bool Workshop::undo() {
    if (stroking) endStroke();
    if (undoSteps.empty()) return false;
    Step s = std::move(undoSteps.back());
    undoSteps.pop_back();
    apply(s, false);
    redoSteps.push_back(std::move(s));
    ++editCount;
    return true;
}

bool Workshop::redo() {
    if (redoSteps.empty()) return false;
    Step s = std::move(redoSteps.back());
    redoSteps.pop_back();
    apply(s, true);
    undoSteps.push_back(std::move(s));
    ++editCount;
    return true;
}

// ------------------------------------------------------------------ stamps

namespace {
struct VoxelBox { glm::ivec3 lo, hi; bool contains(const glm::ivec3& p) const { return p.x >= lo.x && p.y >= lo.y && p.z >= lo.z && p.x <= hi.x && p.y <= hi.y && p.z <= hi.z; } };
}

int Workshop::stampSdf(const std::function<float(const glm::vec3&)>& distance, const glm::vec3& boxMin, const glm::vec3& boxMax,
                       StampMode mode, MaterialId material, float blendMetres, const Mirror& m) {
    if (!asset.valid()) return 0;
    const bool own = !stroking;
    if (own) beginStroke(mode == StampMode::Add ? "Add" : mode == StampMode::Carve ? "Carve" : "Paint");

    const float vs = asset.voxelSize;
    const float bl = blendMetres / vs;
    const glm::vec3 c = mirrorCentre();
    struct Image { int bits; VoxelBox box; };
    std::vector<Image> images;
    for (int bits = 0; bits < 8; ++bits) {
        if (((bits & 1) && !m.x) || ((bits & 2) && !m.y) || ((bits & 4) && !m.z)) continue;
        glm::vec3 lo = boxMin, hi = boxMax;
        if (bits & 1) { lo.x = 2.0f * c.x - boxMax.x; hi.x = 2.0f * c.x - boxMin.x; }
        if (bits & 2) { lo.y = 2.0f * c.y - boxMax.y; hi.y = 2.0f * c.y - boxMin.y; }
        if (bits & 4) { lo.z = 2.0f * c.z - boxMax.z; hi.z = 2.0f * c.z - boxMin.z; }
        const float pad = std::max(blendMetres, 0.0f) + vs * 2.0f;
        const glm::ivec3 g0 = glm::ivec3(glm::floor((lo - glm::vec3(pad)) / vs + asset.pivot));
        const glm::ivec3 g1 = glm::ivec3(glm::ceil((hi + glm::vec3(pad)) / vs + asset.pivot));
        images.push_back({ bits, { glm::max(g0, glm::ivec3(0)), glm::min(g1, asset.size - glm::ivec3(1)) } });
    }

    int changed = 0;
    const int sx = asset.size.x, sxy = asset.size.x * asset.size.y;
    for (size_t i = 0; i < images.size(); ++i) {
        const VoxelBox& b = images[i].box;
        for (int z = b.lo.z; z <= b.hi.z; ++z)
            for (int y = b.lo.y; y <= b.hi.y; ++y)
                for (int x = b.lo.x; x <= b.hi.x; ++x) {
                    const glm::ivec3 g(x, y, z);
                    bool seen = false;
                    for (size_t j = 0; j < i && !seen; ++j) seen = images[j].box.contains(g);
                    if (seen) continue;                                  // already handled through an earlier mirror image

                    const glm::vec3 p = (glm::vec3(g) - asset.pivot) * vs;
                    float s = std::numeric_limits<float>::max();
                    for (const Image& im : images) s = std::min(s, distance(mirrorPoint(p, m, im.bits)));
                    const float sv = s / vs;
                    const size_t idx = size_t(x + y * sx + z * sxy);
                    const float d = asset.grid[idx];
                    const MaterialId oldM = asset.materials[idx];
                    float nd = d;
                    MaterialId nm = oldM;
                    switch (mode) {
                    case StampMode::Add:
                        nd = bl > 1e-4f ? smin(d, sv, bl) : std::min(d, sv);
                        // this stamp's material where it is close to the new shape, and wherever the blend made solid what was air
                        // (otherwise those voxels keep the grid's default and show as specks in the seams)
                        if (nd < 0.0f && (sv < std::max(0.5f, bl * 0.5f) || d >= 0.0f)) nm = material;
                        break;
                    case StampMode::Carve:
                        nd = bl > 1e-4f ? -smin(-d, sv, bl) : std::max(d, -sv);
                        break;
                    case StampMode::Paint:
                        if (sv < 0.5f && d < 0.5f) nm = material;
                        break;
                    }
                    nd = std::clamp(nd, -DENSITY_CLAMP, DENSITY_CLAMP);
                    if (nd == d && nm == oldM) continue;
                    asset.grid[idx] = nd;
                    asset.materials[idx] = nm;
                    noteChange(std::uint32_t(idx), d, nd, oldM, nm);
                    markDirtyVoxels(g, g);
                    ++changed;
                }
    }
    if (own) endStroke();
    return changed;
}

int Workshop::stamp(const Stamp& s, const Mirror& m) {
    const float reach = glm::length(s.half) + std::max(s.round, 0.0f);
    const glm::vec3 mn = s.centre - glm::vec3(reach), mx = s.centre + glm::vec3(reach);
    if (!stroking) {
        const char* what = s.mode == StampMode::Add ? "Add " : s.mode == StampMode::Carve ? "Carve " : "Paint ";
        beginStroke(std::string(what) + (s.mode == StampMode::Paint ? "" : shapeName(s.shape)));
        const int n = stampSdf([&](const glm::vec3& p) { return stampDistance(s, p); }, mn, mx, s.mode, s.material, s.blend, m);
        endStroke();
        return n;
    }
    return stampSdf([&](const glm::vec3& p) { return stampDistance(s, p); }, mn, mx, s.mode, s.material, s.blend, m);
}

int Workshop::fill(const glm::vec3& near, MaterialId material, const Mirror& m) {
    if (!asset.valid()) return 0;
    const bool own = !stroking;
    if (own) beginStroke("Fill");
    const int sx = asset.size.x, sxy = asset.size.x * asset.size.y;
    std::vector<bool> visited(asset.grid.size(), false);
    int changed = 0;
    for (int bits = 0; bits < 8; ++bits) {
        if (((bits & 1) && !m.x) || ((bits & 2) && !m.y) || ((bits & 4) && !m.z)) continue;
        const glm::vec3 p = mirrorPoint(near, m, bits);
        const glm::vec3 g = p / asset.voxelSize + asset.pivot;
        // The solid voxel closest to the point (the surface point itself usually lies between voxels).
        int best = -1; float bestDist = 1e9f;
        for (int dz = -1; dz <= 1; ++dz) for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
            const glm::ivec3 q(int(std::lround(g.x)) + dx, int(std::lround(g.y)) + dy, int(std::lround(g.z)) + dz);
            if (q.x < 0 || q.y < 0 || q.z < 0 || q.x >= asset.size.x || q.y >= asset.size.y || q.z >= asset.size.z) continue;
            const size_t idx = size_t(q.x + q.y * sx + q.z * sxy);
            if (asset.grid[idx] >= 0.0f || visited[idx]) continue;
            const float dist = glm::length(glm::vec3(q) - g);
            if (dist < bestDist) { bestDist = dist; best = int(idx); }
        }
        if (best < 0) continue;
        const MaterialId target = asset.materials[size_t(best)];
        if (target == material) continue;
        std::vector<int> stack{ best };
        visited[size_t(best)] = true;
        while (!stack.empty()) {
            const int idx = stack.back(); stack.pop_back();
            const float d = asset.grid[size_t(idx)];
            noteChange(std::uint32_t(idx), d, d, target, material);
            asset.materials[size_t(idx)] = material;
            const int z = idx / sxy, y = (idx % sxy) / sx, x = idx % sx;
            markDirtyVoxels(glm::ivec3(x, y, z), glm::ivec3(x, y, z));
            ++changed;
            const int nb[6][3] = { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 } };
            for (const auto& o : nb) {
                const int nx = x + o[0], ny = y + o[1], nz = z + o[2];
                if (nx < 0 || ny < 0 || nz < 0 || nx >= asset.size.x || ny >= asset.size.y || nz >= asset.size.z) continue;
                const size_t ni = size_t(nx + ny * sx + nz * sxy);
                if (visited[ni] || asset.grid[ni] >= 0.0f || asset.materials[ni] != target) continue;
                visited[ni] = true;
                stack.push_back(int(ni));
            }
        }
    }
    if (own) endStroke();
    return changed;
}

int Workshop::smooth(const glm::vec3& centre, float radiusMetres, float strength, const Mirror& m) {
    if (!asset.valid()) return 0;
    const bool own = !stroking;
    if (own) beginStroke("Smooth");
    const float vs = asset.voxelSize;
    const float R = std::max(radiusMetres, vs);
    const int sx = asset.size.x, sxy = asset.size.x * asset.size.y;
    int changed = 0;
    std::vector<glm::vec3> done;
    for (int bits = 0; bits < 8; ++bits) {
        if (((bits & 1) && !m.x) || ((bits & 2) && !m.y) || ((bits & 4) && !m.z)) continue;
        const glm::vec3 c = mirrorPoint(centre, m, bits);
        bool dup = false;
        for (const glm::vec3& d : done) if (glm::length(d - c) < vs * 0.5f) dup = true;
        if (dup) continue;                                   // on a mirror plane: the same spot again
        done.push_back(c);
        const glm::ivec3 g0 = glm::max(glm::ivec3(glm::floor((c - glm::vec3(R)) / vs + asset.pivot)) - glm::ivec3(1), glm::ivec3(0));
        const glm::ivec3 g1 = glm::min(glm::ivec3(glm::ceil((c + glm::vec3(R)) / vs + asset.pivot)) + glm::ivec3(1), asset.size - glm::ivec3(1));
        const glm::ivec3 ext = g1 - g0 + glm::ivec3(1);
        std::vector<float> src(size_t(ext.x) * ext.y * ext.z);
        auto at = [&](int x, int y, int z) -> float {
            x = std::clamp(x, 0, asset.size.x - 1); y = std::clamp(y, 0, asset.size.y - 1); z = std::clamp(z, 0, asset.size.z - 1);
            return asset.grid[size_t(x + y * sx + z * sxy)];
        };
        for (int z = 0; z < ext.z; ++z) for (int y = 0; y < ext.y; ++y) for (int x = 0; x < ext.x; ++x)
            src[size_t(x + y * ext.x + z * ext.x * ext.y)] = at(g0.x + x, g0.y + y, g0.z + z);
        auto sampleSrc = [&](int x, int y, int z) {
            x = std::clamp(x, g0.x, g1.x) - g0.x; y = std::clamp(y, g0.y, g1.y) - g0.y; z = std::clamp(z, g0.z, g1.z) - g0.z;
            return src[size_t(x + y * ext.x + z * ext.x * ext.y)];
        };
        for (int z = g0.z; z <= g1.z; ++z) for (int y = g0.y; y <= g1.y; ++y) for (int x = g0.x; x <= g1.x; ++x) {
            const glm::vec3 p = (glm::vec3(x, y, z) - asset.pivot) * vs;
            const float dist = glm::length(p - c);
            if (dist >= R) continue;
            const float fall = 1.0f - dist / R;
            const float w = std::clamp(strength, 0.0f, 1.0f) * fall * fall * (3.0f - 2.0f * fall);
            const float avg = (sampleSrc(x + 1, y, z) + sampleSrc(x - 1, y, z) + sampleSrc(x, y + 1, z) + sampleSrc(x, y - 1, z) + sampleSrc(x, y, z + 1) + sampleSrc(x, y, z - 1)) / 6.0f;
            const size_t idx = size_t(x + y * sx + z * sxy);
            const float d = asset.grid[idx];
            const float nd = std::clamp(d + (avg - d) * w, -DENSITY_CLAMP, DENSITY_CLAMP);
            if (std::fabs(nd - d) < 1e-4f) continue;
            asset.grid[idx] = nd;
            noteChange(std::uint32_t(idx), d, nd, asset.materials[idx], asset.materials[idx]);
            markDirtyVoxels(glm::ivec3(x, y, z), glm::ivec3(x, y, z));
            ++changed;
        }
    }
    if (own) endStroke();
    return changed;
}

// ------------------------------------------------------------------ sockets and description

const Socket* Workshop::findSocket(const std::string& name) const {
    for (const Socket& s : asset.sockets) if (s.name == name) return &s;
    return nullptr;
}

std::string Workshop::freeSocketName(const std::string& wanted) const {
    const std::string base = wanted.empty() ? std::string("socket") : wanted;
    if (!findSocket(base)) return base;
    for (int i = 2;; ++i) {
        const std::string n = base + " " + std::to_string(i);
        if (!findSocket(n)) return n;
    }
}

void Workshop::socketStep(const std::string& label, const std::vector<Socket>& before) {
    Step s;
    s.label = label;
    s.socketsChanged = true;
    s.socketsBefore = before;
    s.socketsAfter = asset.sockets;
    pushStep(std::move(s));
}

namespace {
glm::vec3 unitOr(const glm::vec3& d, const glm::vec3& fallback) { return glm::length(d) > 1e-4f ? glm::normalize(d) : fallback; }
}

bool Workshop::addSocket(const std::string& name, const glm::vec3& position, const glm::vec3& direction) {
    if (name.empty() || findSocket(name)) return false;
    const auto before = asset.sockets;
    asset.sockets.push_back({ name, position, unitOr(direction, glm::vec3(0, 1, 0)) });
    socketStep("Add socket " + name, before);
    return true;
}

bool Workshop::moveSocket(const std::string& name, const glm::vec3& position, const glm::vec3& direction) {
    for (Socket& s : asset.sockets) {
        if (s.name != name) continue;
        const auto before = asset.sockets;
        s.position = position;
        s.direction = unitOr(direction, s.direction);
        socketStep("Move socket " + name, before);
        return true;
    }
    return false;
}

bool Workshop::renameSocket(const std::string& from, const std::string& to) {
    if (to.empty() || from == to || findSocket(to)) return false;
    for (Socket& s : asset.sockets) {
        if (s.name != from) continue;
        const auto before = asset.sockets;
        s.name = to;
        socketStep("Rename socket " + from, before);
        return true;
    }
    return false;
}

bool Workshop::removeSocket(const std::string& name) {
    for (size_t i = 0; i < asset.sockets.size(); ++i) {
        if (asset.sockets[i].name != name) continue;
        const auto before = asset.sockets;
        asset.sockets.erase(asset.sockets.begin() + std::ptrdiff_t(i));
        socketStep("Remove socket " + name, before);
        return true;
    }
    return false;
}

void Workshop::setName(const std::string& n) { if (n != asset.name) { asset.name = n; ++editCount; ++infoEdits; } }
void Workshop::setType(AssetType t) { if (t != asset.type) { asset.type = t; ++editCount; ++infoEdits; } }
void Workshop::setTags(const std::vector<std::string>& t) { if (t != asset.tags) { asset.tags = t; ++editCount; ++infoEdits; } }

// ------------------------------------------------------------------ meshing and picking

namespace {
std::uint32_t& versionCounter() { static std::uint32_t v = 1000000; return v; }
}

void Workshop::remesh() {
    if (!asset.valid()) return;
    const glm::ivec3 bc = blockCounts();
    if (blockMeshes.size() != size_t(bc.x) * bc.y * bc.z) {
        blockMeshes.assign(size_t(bc.x) * bc.y * bc.z, {});
        dirtyFlags.assign(blockMeshes.size(), 1);
        dirtyBlocks.clear();
        for (size_t i = 0; i < dirtyFlags.size(); ++i) dirtyBlocks.push_back(int(i));
    }
    if (dirtyBlocks.empty() && !asset.mesh.empty()) return;
    for (int b : dirtyBlocks) {
        const int bx = b % bc.x, by = (b / bc.x) % bc.y, bz = b / (bc.x * bc.y);
        const glm::ivec3 from(bx * kBlock - 1, by * kBlock - 1, bz * kBlock - 1);
        blockMeshes[size_t(b)].clear();
        asset.meshCells(from, from + glm::ivec3(kBlock - 1), blockMeshes[size_t(b)]);
        dirtyFlags[size_t(b)] = 0;
    }
    dirtyBlocks.clear();
    size_t total = 0;
    for (const auto& bm : blockMeshes) total += bm.size();
    asset.mesh.clear();
    asset.mesh.reserve(total);
    for (const auto& bm : blockMeshes) asset.mesh.insert(asset.mesh.end(), bm.begin(), bm.end());
    asset.version = ++versionCounter();         // never reused, so the renderer always notices a new mesh
    asset.updateBounds();
}

WorkshopHit Workshop::raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist) const {
    WorkshopHit out;
    float tModel = 0.0f;
    const bool hitModel = asset.raycast(origin, dir, maxDist, tModel);
    float tFloor = std::numeric_limits<float>::max();
    if (dir.y < -1e-6f) {
        const float t = -origin.y / dir.y;
        const glm::vec3 p = origin + dir * t;
        const glm::vec3 lo = gridMin(), hi = gridMax();
        if (t >= 0.0f && t <= maxDist && p.x >= lo.x && p.x <= hi.x && p.z >= lo.z && p.z <= hi.z) tFloor = t;
    }
    if (hitModel && tModel <= tFloor) {
        out.hit = true; out.distance = tModel; out.point = origin + dir * tModel;
        out.normal = asset.gradient(out.point);
    } else if (tFloor < std::numeric_limits<float>::max()) {
        out.hit = true; out.floor = true; out.distance = tFloor; out.point = origin + dir * tFloor;
        out.point.y = 0.0f;
        out.normal = glm::vec3(0, 1, 0);
    }
    return out;
}

// ------------------------------------------------------------------ templates

namespace {
void buildTemplate(Workshop& w, const NewAssetSpec& spec) {
    const WorkshopTemplate t = spec.tmpl;
    const Mirror mx{ true, false, false };
    const Mirror mz{ false, false, true };
    auto add = [&](const std::function<float(const glm::vec3&)>& f, const glm::vec3& lo, const glm::vec3& hi, MaterialId mat, float blend = 0.0f, const Mirror& m = {}) {
        w.stampSdf(f, lo, hi, StampMode::Add, mat, blend, m);
    };
    auto carve = [&](const std::function<float(const glm::vec3&)>& f, const glm::vec3& lo, const glm::vec3& hi, const Mirror& m = {}) {
        w.stampSdf(f, lo, hi, StampMode::Carve, MAT_STONE, 0.0f, m);
    };
    auto box = [](glm::vec3 c, glm::vec3 h, float r) { return [=](const glm::vec3& p) { return roundedBox(p - c, h, r); }; };
    auto cap = [](glm::vec3 a, glm::vec3 b, float r) { return [=](const glm::vec3& p) { return capsule(p, a, b, r); }; };
    auto ell = [](glm::vec3 c, glm::vec3 h) { return [=](const glm::vec3& p) { return ellipsoid(p - c, h); }; };
    auto region = [](glm::vec3 c, glm::vec3 h) { return std::make_pair(c - h - glm::vec3(0.05f), c + h + glm::vec3(0.05f)); };
    auto addBox = [&](glm::vec3 c, glm::vec3 h, float r, MaterialId mat, const Mirror& m = {}, float blend = 0.0f) {
        const auto [lo, hi] = region(c, h); add(box(c, h, r), lo, hi, mat, blend, m);
    };
    auto addCap = [&](glm::vec3 a, glm::vec3 b, float r, MaterialId mat, const Mirror& m, float blend) {
        const glm::vec3 lo = glm::min(a, b) - glm::vec3(r + 0.05f), hi = glm::max(a, b) + glm::vec3(r + 0.05f);
        add(cap(a, b, r), lo, hi, mat, blend, m);
    };
    auto addEll = [&](glm::vec3 c, glm::vec3 h, MaterialId mat, const Mirror& m, float blend) {
        const auto [lo, hi] = region(c, h); add(ell(c, h), lo, hi, mat, blend, m);
    };
    auto addStamp = [&](Shape sh, glm::vec3 c, glm::vec3 h, float round, MaterialId mat, const Mirror& m = {}) {
        Stamp s; s.shape = sh; s.centre = c; s.half = h; s.round = round; s.material = mat;
        w.stamp(s, m);
    };

    switch (t) {
    case WorkshopTemplate::Blank: break;

    case WorkshopTemplate::Mannequin: {
        const MaterialId wood = MAT_WOOD;
        const float k = 0.025f;
        addEll({ 0, 1.69f, 0.01f }, { 0.092f, 0.115f, 0.105f }, wood, {}, k);                  // head
        addCap({ 0, 1.52f, 0 }, { 0, 1.60f, 0 }, 0.045f, wood, {}, k);                       // neck
        addBox({ 0, 1.33f, 0 }, { 0.19f, 0.20f, 0.10f }, 0.07f, wood, {}, k);                 // chest
        addBox({ 0, 1.10f, 0 }, { 0.15f, 0.10f, 0.09f }, 0.05f, wood, {}, k);                 // belly
        addBox({ 0, 0.93f, 0 }, { 0.17f, 0.09f, 0.10f }, 0.06f, wood, {}, k);                 // hips
        addEll({ 0.23f, 1.45f, 0 }, { 0.065f, 0.065f, 0.065f }, wood, mx, k);                 // shoulders
        addCap({ 0.24f, 1.44f, 0 }, { 0.31f, 1.15f, 0 }, 0.050f, wood, mx, k);                // upper arms
        addCap({ 0.31f, 1.15f, 0 }, { 0.36f, 0.90f, 0.03f }, 0.042f, wood, mx, k);            // forearms
        addEll({ 0.375f, 0.83f, 0.03f }, { 0.035f, 0.06f, 0.025f }, wood, mx, k);             // hands
        addCap({ 0.10f, 0.90f, 0 }, { 0.11f, 0.50f, 0.01f }, 0.075f, wood, mx, k);            // thighs
        addCap({ 0.11f, 0.50f, 0.01f }, { 0.105f, 0.10f, 0 }, 0.055f, wood, mx, k);           // shins
        addBox({ 0.105f, 0.04f, 0.05f }, { 0.05f, 0.04f, 0.11f }, 0.03f, wood, mx, k);        // feet
        w.addSocket("head",   { 0, 1.80f, 0 },            { 0, 1, 0 });
        w.addSocket("hand_r", { -0.375f, 0.83f, 0.03f },  { 0, -1, 0 });
        w.addSocket("hand_l", { 0.375f, 0.83f, 0.03f },   { 0, -1, 0 });
        w.addSocket("back",   { 0, 1.35f, -0.11f },       { 0, 0, -1 });
        break;
    }
    case WorkshopTemplate::Sword: {
        addBox({ 0, 0.66f, 0 }, { 0.030f, 0.36f, 0.011f }, 0.005f, MAT_STEEL);               // blade
        addStamp(Shape::Cone, { 0, 1.06f, 0 }, { 0.030f, 0.045f, 0.011f }, 0.0f, MAT_STEEL); // tip
        addBox({ 0, 0.285f, 0 }, { 0.11f, 0.016f, 0.02f }, 0.008f, MAT_GOLD);                 // brass guard
        addStamp(Shape::Cylinder, { 0, 0.16f, 0 }, { 0.017f, 0.11f, 0.017f }, 0.0f, MAT_LEATHER);// leather-wrapped grip
        addStamp(Shape::Sphere, { 0, 0.035f, 0 }, { 0.03f, 0.03f, 0.03f }, 0.0f, MAT_GOLD);   // pommel
        { const auto [lo, hi] = region({ 0, 0.65f, 0.012f }, { 0.007f, 0.30f, 0.005f }); carve(box({ 0, 0.65f, 0.012f }, { 0.007f, 0.30f, 0.005f }, 0.003f), lo, hi, mz); }   // fuller on both faces
        w.addSocket("grip",       { 0, 0.16f, 0 },   { 0, 1, 0 });
        w.addSocket("blade_tip",  { 0, 1.105f, 0 },  { 0, 1, 0 });
        break;
    }
    case WorkshopTemplate::Pistol: {
        addBox({ 0.0f, 0.205f, 0 }, { 0.115f, 0.021f, 0.0145f }, 0.005f, MAT_STEEL);          // a stainless slide
        addBox({ -0.01f, 0.168f, 0 }, { 0.10f, 0.016f, 0.0135f }, 0.004f, MAT_PAINT_BLACK);   // a black frame
        addCap({ -0.056f, 0.158f, 0 }, { -0.086f, 0.068f, 0 }, 0.0175f, MAT_PAINT_BLACK, {}, 0.0f);   // grip, raked back like a real one
        addBox({ -0.089f, 0.058f, 0 }, { 0.022f, 0.006f, 0.0165f }, 0.003f, MAT_METAL);       // magazine base
        addBox({ 0.02f, 0.14f, 0 }, { 0.035f, 0.006f, 0.011f }, 0.003f, MAT_METAL);           // trigger guard
        addBox({ 0.052f, 0.152f, 0 }, { 0.006f, 0.02f, 0.011f }, 0.003f, MAT_METAL);
        addBox({ 0.0f, 0.15f, 0 }, { 0.005f, 0.014f, 0.007f }, 0.002f, MAT_METAL);            // trigger
        addCap({ 0.115f, 0.205f, 0 }, { 0.14f, 0.205f, 0 }, 0.0095f, MAT_METAL, {}, 0.0f);    // barrel
        w.addSocket("grip",   { -0.068f, 0.115f, 0 }, { 0, 1, 0 });
        w.addSocket("muzzle", { 0.145f, 0.205f, 0 },  { 1, 0, 0 });
        w.addSocket("sight",  { 0.0f, 0.232f, 0 },    { 0, 1, 0 });
        break;
    }
    case WorkshopTemplate::Wall: {
        addBox({ 0, 1.5f, 0 }, { 2.5f, 1.5f, 0.15f }, 0.03f, MAT_BRICK);
        addBox({ 0, 0.15f, 0 }, { 2.55f, 0.15f, 0.20f }, 0.03f, MAT_STONE);                   // plinth
        addBox({ 0, 3.03f, 0 }, { 2.55f, 0.06f, 0.20f }, 0.02f, MAT_STONE);                   // cap
        w.addSocket("edge_l", { -2.5f, 0, 0 }, { -1, 0, 0 });
        w.addSocket("edge_r", { 2.5f, 0, 0 },  { 1, 0, 0 });
        w.addSocket("top",    { 0, 3.1f, 0 },  { 0, 1, 0 });
        break;
    }
    case WorkshopTemplate::DoorFrame: {
        addBox({ 0, 1.5f, 0 }, { 2.0f, 1.5f, 0.15f }, 0.03f, MAT_BRICK);
        { const auto [lo, hi] = region({ 0, 1.0f, 0 }, { 0.6f, 1.2f, 0.5f }); carve(box({ 0, 1.0f, 0 }, { 0.6f, 1.2f, 0.5f }, 0.0f), lo, hi); }   // the doorway (goes down through the floor level)
        addBox({ 0.65f, 1.15f, 0 }, { 0.07f, 1.15f, 0.19f }, 0.02f, MAT_WOOD, mx);            // jambs
        addBox({ 0, 2.32f, 0 }, { 0.72f, 0.07f, 0.19f }, 0.02f, MAT_WOOD);                    // lintel
        w.addSocket("hinge",       { -0.6f, 0, 0 },    { 0, 1, 0 });
        w.addSocket("door_centre", { 0, 1.1f, 0 },     { 0, 0, 1 });
        w.addSocket("edge_l",      { -2.0f, 0, 0 },    { -1, 0, 0 });
        w.addSocket("edge_r",      { 2.0f, 0, 0 },     { 1, 0, 0 });
        break;
    }
    case WorkshopTemplate::KitPiece: {
        const KitStyle* st = findKitStyle(spec.kitStyle);
        buildKitPiece(w, spec.kitRole, st ? *st : plainKitStyle());
        break;
    }
    default: break;
    }
}
} // namespace

} // namespace px
