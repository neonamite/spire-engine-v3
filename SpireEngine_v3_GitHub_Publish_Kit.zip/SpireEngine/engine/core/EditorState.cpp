#include "core/EditorState.h"
#include <cmath>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace px {

bool EditorState::save(const std::string& path) const {
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(path).parent_path(), ec);
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp);
        if (!f) return false;
        f.precision(6);
        f << "projectx-editor-state 1\n";
        if (hasCamera) f << "camera " << cameraPosition.x << ' ' << cameraPosition.y << ' ' << cameraPosition.z << ' ' << cameraYaw << ' ' << cameraPitch << '\n';
        if (hasTime) f << "time " << timeOfDay << '\n';
        f << "tool " << tool << '\n';
        f << "brush " << brushRadius << ' ' << brushMaterial << '\n';
        f << "flyspeed " << flySpeed << '\n';
        if (!playerCharacter.empty()) f << "player " << playerCharacter << '\n';
        for (int i = 0; i < kBookmarks; ++i) {
            const CameraBookmark& b = bookmarks[size_t(i)];
            if (!b.used) continue;
            f << "bookmark " << (i + 1) << ' ' << b.position.x << ' ' << b.position.y << ' ' << b.position.z << ' ' << b.yaw << ' ' << b.pitch << ' ' << b.name << '\n';
        }
        if (!f) return false;
    }
    std::filesystem::rename(tmp, path, ec);
    return !ec;
}

bool EditorState::load(const std::string& path, EditorState& out) {
    std::ifstream f(path);
    if (!f) return false;
    std::string line;
    if (!std::getline(f, line) || line.rfind("projectx-editor-state", 0) != 0) return false;
    EditorState s;
    while (std::getline(f, line)) {
        std::istringstream in(line);
        std::string key;
        in >> key;
        if (key == "camera") {
            in >> s.cameraPosition.x >> s.cameraPosition.y >> s.cameraPosition.z >> s.cameraYaw >> s.cameraPitch;
            s.hasCamera = !in.fail() && std::isfinite(s.cameraPosition.x + s.cameraPosition.y + s.cameraPosition.z + s.cameraYaw + s.cameraPitch);
        } else if (key == "time") {
            in >> s.timeOfDay; s.hasTime = !in.fail() && std::isfinite(s.timeOfDay);
        } else if (key == "tool") {
            in >> s.tool;
        } else if (key == "brush") {
            in >> s.brushRadius >> s.brushMaterial;
        } else if (key == "flyspeed") {
            in >> s.flySpeed;
        } else if (key == "player") {
            std::string rest; std::getline(in, rest);
            while (!rest.empty() && (rest.front() == ' ' || rest.front() == '\t')) rest.erase(rest.begin());
            while (!rest.empty() && (rest.back() == '\r' || rest.back() == ' ')) rest.pop_back();
            s.playerCharacter = rest.substr(0, 64);
        } else if (key == "bookmark") {
            int slot = 0; CameraBookmark b;
            in >> slot >> b.position.x >> b.position.y >> b.position.z >> b.yaw >> b.pitch;
            if (in.fail() || slot < 1 || slot > kBookmarks) continue;
            std::getline(in, b.name);
            if (!b.name.empty() && b.name.front() == ' ') b.name.erase(0, 1);
            b.used = true;
            s.bookmarks[size_t(slot - 1)] = std::move(b);
        }
    }
    out = std::move(s);
    return true;
}

} // namespace px
