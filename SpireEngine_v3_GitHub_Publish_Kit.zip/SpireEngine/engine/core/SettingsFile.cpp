#include "core/SettingsFile.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>
#include <system_error>

namespace px {

namespace {

// One list of fields drives both writing and reading.
template <class V>
void visit(UserSettings& s, GraphicsValues& g, V& v) {
    v.f("mouse_sensitivity", s.mouseSensitivity, 0.03f, 0.4f);
    v.b("invert_y", s.invertY);
    v.f("fov", s.fov, 50.0f, 110.0f);
    v.b("vsync", s.vsync);

    int mode = int(s.display.mode);
    v.i("window_mode", mode, 0, 2);
    s.display.mode = WindowMode(mode);
    v.i("monitor", s.display.monitor, 0, 15);
    v.i("window_width", s.display.width, 640, 16384);
    v.i("window_height", s.display.height, 360, 16384);
    v.i("fullscreen_width", s.display.fullscreenWidth, 0, 16384);
    v.i("fullscreen_height", s.display.fullscreenHeight, 0, 16384);
    v.i("fps_cap", s.display.fpsCap, 0, 1000);
    v.b("slow_in_background", s.display.reduceInBackground);
    v.f("ui_scale", s.display.uiScale, 0.75f, 2.0f);

    v.f("gfx_render_scale", g.renderScale, 0.5f, 2.0f);
    v.b("gfx_shadows", g.shadows);
    v.i("gfx_shadow_size", g.shadowSize, 256, 8192);
    v.f("gfx_shadow_range", g.shadowRange, 40.0f, 200.0f);
    v.b("gfx_bloom", g.bloom);
    v.b("gfx_fxaa", g.fxaa);
    v.b("gfx_grass", g.grass);
    v.f("gfx_grass_density", g.grassDensity, 0.05f, 1.0f);
    v.f("gfx_grass_distance", g.grassDistance, 20.0f, 160.0f);
    v.i("gfx_view_distance", g.viewDistance, 2, 10);
    v.i("gfx_texture_size", g.textureSize, 256, 8192);
    v.b("gfx_ssao", g.ssao);
    v.b("gfx_trees", g.trees);
    v.f("gfx_tree_distance", g.treeDistance, 40.0f, 400.0f);

    v.f("vol_master", s.volMaster, 0.0f, 1.0f);
    v.f("vol_sfx", s.volSfx, 0.0f, 1.0f);
    v.f("vol_ambient", s.volAmbient, 0.0f, 1.0f);
    v.f("vol_music", s.volMusic, 0.0f, 1.0f);
    v.f("vol_ui", s.volUi, 0.0f, 1.0f);
    v.b("mute", s.muteAudio);
    v.b("mute_in_background", s.muteUnfocused);
    v.b("ambience_in_editor", s.ambienceInEditor);

    v.f("autosave_minutes", s.autosaveMinutes, 0.0f, 60.0f);
    v.s("texture_pack", s.texturePack);

    for (int i = 0; i < kActionCount; ++i) v.i((std::string("key_") + actionName(Action(i))).c_str(), s.keys.key[size_t(i)], 1, 511);
    if (!bindingConflicts(s.keys).empty()) s.keys = KeyBindings();     // a hand-edited file with clashes: back to the usual keys
    v.b("toggle_run", s.toggleRun);
    v.b("colour_blind", s.colourBlind);
    v.b("big_hud", s.bigHud);
    v.b("reduce_motion", s.reduceMotion);
    v.b("captions", s.captions);
    v.b("tutorial_done", s.tutorialDone);
}

struct Writer {
    std::ostringstream out;
    void f(const char* k, float& x, float, float) { char b[48]; std::snprintf(b, sizeof b, "%.6g", double(x)); out << k << " = " << b << "\n"; }
    void i(const char* k, int& x, int, int)        { out << k << " = " << x << "\n"; }
    void b(const char* k, bool& x)                 { out << k << " = " << (x ? "true" : "false") << "\n"; }
    void s(const char* k, std::string& x)          { out << k << " = " << x << "\n"; }
};

struct Reader {
    std::map<std::string, std::string> kv;
    int found = 0;
    const std::string* get(const char* k) { auto it = kv.find(k); if (it == kv.end()) return nullptr; ++found; return &it->second; }
    void f(const char* k, float& x, float lo, float hi) {
        const std::string* v = get(k);
        if (!v) return;
        char* end = nullptr;
        const float r = std::strtof(v->c_str(), &end);
        if (end != v->c_str() && std::isfinite(r)) x = std::clamp(r, lo, hi);
    }
    void i(const char* k, int& x, int lo, int hi) {
        const std::string* v = get(k);
        if (!v) return;
        char* end = nullptr;
        const long r = std::strtol(v->c_str(), &end, 10);
        if (end != v->c_str()) x = int(std::clamp<long>(r, lo, hi));
    }
    void b(const char* k, bool& x) {
        const std::string* v = get(k);
        if (!v) return;
        if (*v == "true" || *v == "1" || *v == "yes" || *v == "on") x = true;
        else if (*v == "false" || *v == "0" || *v == "no" || *v == "off") x = false;
    }
    void s(const char* k, std::string& x) {
        const std::string* v = get(k);
        if (!v) return;
        // A folder name only: no paths, nothing that could reach outside textures/.
        std::string clean;
        for (char c : *v) if (c != '/' && c != '\\' && c != ':' && static_cast<unsigned char>(c) >= 32) clean += c;
        x = (clean == "." || clean == "..") ? std::string() : clean.substr(0, 120);
    }
};

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

} // namespace

std::string settingsToText(const UserSettings& sIn, const GraphicsValues& gIn) {
    UserSettings s = sIn;
    GraphicsValues g = gIn;
    Writer w;
    w.out << "# Spire Engine settings. Safe to edit by hand; delete this file to go back to the defaults.\n";
    w.out << "settings_version = 1\n";
    visit(s, g, w);
    return w.out.str();
}

int settingsFromText(const std::string& text, UserSettings& s, GraphicsValues& g) {
    Reader r;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        const size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        r.kv[trim(line.substr(0, eq))] = trim(line.substr(eq + 1));
    }
    visit(s, g, r);
    clampGraphics(g);
    clampSettings(s);
    return r.found;
}

void clampSettings(UserSettings& s) {
    s.display.mode = WindowMode(std::clamp(int(s.display.mode), 0, 2));
    // Settings that were never meant to be a half-set pair.
    if ((s.display.fullscreenWidth == 0) != (s.display.fullscreenHeight == 0)) s.display.fullscreenWidth = s.display.fullscreenHeight = 0;
    // Autosave only offers a few steps; round to the nearest.
    static const float kMinutes[] = { 0.0f, 1.0f, 2.0f, 3.0f, 5.0f, 10.0f };
    float best = kMinutes[3], bestD = 1e9f;
    for (float m : kMinutes) if (std::fabs(m - s.autosaveMinutes) < bestD) { bestD = std::fabs(m - s.autosaveMinutes); best = m; }
    s.autosaveMinutes = best;
}

bool saveSettingsFile(const std::string& path, const UserSettings& s, const GraphicsValues& g) {
    std::error_code ec;
    const std::filesystem::path p(path);
    if (p.has_parent_path()) std::filesystem::create_directories(p.parent_path(), ec);
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f << settingsToText(s, g);
        if (!f) return false;
    }
    std::filesystem::rename(tmp, path, ec);
    if (ec) { std::filesystem::remove(tmp, ec); return false; }
    return true;
}

bool loadSettingsFile(const std::string& path, UserSettings& s, GraphicsValues& g) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    settingsFromText(ss.str(), s, g);
    return true;
}

} // namespace px
