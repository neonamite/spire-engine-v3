// --demo mat_...: screenshots of the richer materials (v0.15) in the world and in the Workshop, and a self test
// that paints every material into the real world and checks the table the renderer and the tools share.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "render/MaterialTextures.h"
#include <cstdio>
#include <iostream>
#include <set>
#include <string>

namespace px {

namespace {

// Balls floating in rows in front of the viewer, one per material, so the lay of the land never hides them.
void buildGallery(ChunkManager& world, const glm::vec3& spot, const std::vector<MaterialId>& materials, int perRow, float radius, float spacing, float firstRow, float rowGap) {
    for (size_t i = 0; i < materials.size(); ++i) {
        const int row = int(i) / perRow, col = int(i) % perRow;
        const int inRow = std::min(perRow, int(materials.size()) - row * perRow);
        const float x = spot.x + (float(col) - float(inRow - 1) * 0.5f) * spacing;
        const float z = spot.z - firstRow - float(row) * rowGap;
        const glm::vec3 c(x, spot.y + 6.0f + float(row) * 4.5f, z);
        world.applySphere(c, radius, CsgMode::Union, materials[i]);
        world.paint(c, radius + 0.6f, materials[i]);
    }
}

std::vector<MaterialId> newMaterials() {
    std::vector<MaterialId> m;
    for (int id = MAT_PLASTER; id < MAT_COUNT; ++id) m.push_back(MaterialId(id));
    return m;
}

} // namespace

void Application::setupMaterialDemo() {
    if (demo == "mat_selftest") { runMaterialSelfTest(); return; }

    // mat_gallery: every new material on a ball, in daylight. mat_dusk: the same at twilight, so the glow shows.
    const glm::vec3 spot = demospot::calmSpot(world);
    buildGallery(world, spot, newMaterials(), 8, 1.45f, 3.1f, 12.0f, 7.0f);
    camera.position = spot + glm::vec3(0.0f, 2.3f, 0.0f);
    camera.yaw = -90.0f; camera.pitch = 9.0f;
    timeOfDay = demo == "mat_dusk" ? 18.0f : demo == "mat_night" ? 22.5f : 11.5f;
    timeFlowing = false;
    setMode(Mode::Editor);
    if (demo == "mat_palette") {                                   // the editor with the Paint tool: the palette with its four groups
        tool = Tool::Paint;
        brushMaterial = MAT_LAMP;
        brushRadius = 2.5f;
        timeOfDay = 18.0f;
        return;
    }
    uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
}

void Application::runMaterialSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[mattest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    setMode(Mode::Editor);

    // ---- the table
    std::set<std::string> names;
    bool tableOk = true, glowOk = true, tintOk = true, textureOk = true;
    for (int id = 1; id < MAT_COUNT; ++id) {
        const MaterialInfo& m = materialInfo(MaterialId(id));
        tableOk &= names.insert(m.name).second && m.name[0] != 0 && m.blurb[0] != 0;
        textureOk &= m.texture >= 0 && m.texture < kTextureImages;
        for (int c = 0; c < 3; ++c) tintOk &= m.tint[c] >= 0.0f && m.tint[c] <= 1.0f && m.flat[c] >= 0.0f && m.flat[c] <= 1.0f;
        glowOk &= (m.glow > 0.0f) == (m.group == MaterialGroup::Glowing);
    }
    check(tableOk, "every material has its own name and a description");
    check(textureOk, "every material points at a texture that exists");
    check(tintOk, "tints and thumbnail colours are in range");
    check(glowOk, "exactly the glowing materials glow");
    check(materialInfo(MAT_STONE).texture == 2 && materialInfo(MAT_BRICK).group == MaterialGroup::Building, "the original eight keep their meaning");
    check(MAT_NEEDLES == MAT_COUNT - 1 && kMaterialSlots == MAT_COUNT - 1, "the slot count follows the table");

    // ---- the textures behind them
    const std::vector<MaterialImage> imgs = generateMaterialImages(64);
    bool imagesOk = int(imgs.size()) == kTextureImages;
    for (const MaterialImage& im : imgs) imagesOk &= im.size == 64 && im.albedo.size() == 64u * 64u * 4u && im.normal.size() == im.albedo.size();
    check(imagesOk, "a texture is built for every image slot");
    auto average = [&](const MaterialImage& im, int c) { double s = 0; for (size_t i = 0; i < im.albedo.size(); i += 4) s += im.albedo[i + size_t(c)]; return s / double(im.albedo.size() / 4); };
    const MaterialImage& lava = imgs[size_t(materialInfo(MAT_LAVA).texture)];
    const MaterialImage& plaster = imgs[size_t(materialInfo(MAT_PLASTER).texture)];
    check(average(lava, 0) < average(plaster, 0) * 0.7, "lava is darker overall than plaster (its glow comes only from the cracks)");
    int hot = 0;
    for (size_t i = 0; i < lava.albedo.size(); i += 4) if (lava.albedo[i] > 200 && lava.albedo[i + 2] < 140) ++hot;
    check(hot > 40, "...but it has bright cracks");

    // ---- painting them into the world
    const glm::vec3 spot = demospot::calmSpot(world);
    bool allThere = true;
    for (int id = MAT_PLASTER; id < MAT_COUNT; ++id) {
        const glm::vec3 c = spot + glm::vec3(float(id - MAT_PLASTER) * 2.6f - 20.0f, 10.0f, 6.0f);
        world.applySphere(c, 1.4f, CsgMode::Union, MaterialId(id));
        allThere &= world.materialAt(c) == id;
    }
    check(allThere, "a ball of every new material can be built into the world");
    {
        const glm::vec3 c = spot + glm::vec3(0.0f, 14.0f, 10.0f);
        world.applySphere(c, 2.0f, CsgMode::Union, MAT_STONE);
        world.paint(c, 2.6f, MAT_PAINT_PURPLE);
        check(world.materialAt(c + glm::vec3(0.0f, 1.8f, 0.0f)) == MAT_PAINT_PURPLE, "the paint brush can use a paint colour");
        world.paint(c, 2.6f, MAT_LAMP);
        check(world.materialAt(c + glm::vec3(1.8f, 0.0f, 0.0f)) == MAT_LAMP, "...and paint over it with a glowing one");
    }

    // ---- they come back from the edit log (what a save is made of)
    {
        const size_t edits = world.editCount();
        const glm::vec3 c = spot + glm::vec3(8.0f, 16.0f, 10.0f);
        world.applySphere(c, 1.5f, CsgMode::Union, MAT_CRYSTAL);
        check(world.editCount() == edits + 1 && world.materialAt(c) == MAT_CRYSTAL, "a crystal ball is one edit");
        world.undo();
        check(world.materialAt(c) != MAT_CRYSTAL, "...and undo takes it away");
        world.redo();
        check(world.materialAt(c) == MAT_CRYSTAL, "...and redo brings it back");
    }

    std::cerr << "[mattest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
