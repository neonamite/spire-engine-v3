// Engine-side play-mode UI: lets the game draw its HUD, then adds the parts
// every game shares: toasts and the pause menu. With no game loaded, draws a
// plain crosshair so the bare engine is still walkable.
#include "core/Application.h"
#include "ui/UiKit.h"
#include <cfloat>

namespace px {

using namespace ui;

void Application::drawPlayUI() {
    const ImGuiIO& io = ImGui::GetIO();
    const float s = scale();
    const ImVec2 ds = io.DisplaySize;

    drawNpcOverlay();
    drawRulesHUD();
    drawCaptions();
    drawTutorial();
    if (game) {
        game->drawPlayHUD(*this);
    } else if (!paused && !inventory.enabled) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        dl->AddCircleFilled(ImVec2(ds.x * 0.5f, ds.y * 0.5f), 2.5f * s * hudScale(), IM_COL32(255, 255, 255, 220));
        if (settings.bigHud) dl->AddCircle(ImVec2(ds.x * 0.5f, ds.y * 0.5f), 7.0f * s, IM_COL32(0, 0, 0, 160), 0, 1.5f * s);
    }
    if (inventory.enabled) drawItemHUD();

    drawToasts(toasts, 110 * s);

    // Playing from the editor: the screen's edge glows fuse orange, so it is never mistaken for editing.
    if (!playerMode && !paused) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const ImU32 a = withAlpha(col::fuse, 0.30f), z = withAlpha(col::fuse, 0.0f);
        const float g = 26 * s;
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(ds.x, g), a, a, z, z);
        dl->AddRectFilledMultiColor(ImVec2(0, ds.y - g), ds, z, z, a, a);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(g, ds.y), a, z, z, a);
        dl->AddRectFilledMultiColor(ImVec2(ds.x - g, 0), ds, z, a, a, z);
        dl->AddRect(ImVec2(1, 1), ImVec2(ds.x - 1, ds.y - 1), col::fuse, 0.0f, 0, 2.0f * s);
        pushFont(fonts.small);
        const char* label = "PLAYING";
        const float kw = keyCapWidth("Tab");
        const ImVec2 ts = ImGui::CalcTextSize(label);
        const ImVec2 hint = ImGui::CalcTextSize("to stop");
        const float w = 12 * s + 8 * s + 8 * s + ts.x + 14 * s + kw + 6 * s + hint.x + 12 * s;
        const ImVec2 p(14 * s, 12 * s);                            // top-left: the games' HUDs use the top centre and right
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 28 * s), IM_COL32(16, 18, 23, 225), 14 * s);
        dl->AddRect(p, ImVec2(p.x + w, p.y + 28 * s), withAlpha(col::fuse, 0.6f), 14 * s);
        dl->AddCircleFilled(ImVec2(p.x + 16 * s, p.y + 14 * s), 4 * s, col::fuse);
        dl->AddText(ImVec2(p.x + 28 * s, p.y + (28 * s - ts.y) * 0.5f), col::fuse, label);
        float x = p.x + 28 * s + ts.x + 14 * s;
        keyCap(dl, ImVec2(x, p.y + 5 * s), "Tab", col::text);
        dl->AddText(ImVec2(x + kw + 6 * s, p.y + (28 * s - hint.y) * 0.5f), col::textDim, "to stop");
        popFont();
    }

    if (!paused) return;

    // ---- pause menu
    ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), ds, IM_COL32(8, 10, 14, 170));
    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(380 * s, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(28 * s, 26 * s));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 14 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8 * s, 10 * s));
    if (ImGui::Begin("##pause", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) {
        pushFont(fonts.display);
        ImGui::TextUnformatted("Paused");
        popFont();
        ImGui::TextDisabled("%s", playerMode ? playerManifest.name.c_str() : game ? game->name() : "Spire Engine");
        ImGui::Dummy(ImVec2(0, 8 * s));

        auto bigButton = [&](const char* label, bool primary) {
            if (primary) return primaryButton(label, ImVec2(-FLT_MIN, 42 * s));
            pushFont(fonts.bold);
            const bool r = ImGui::Button(label, ImVec2(-FLT_MIN, 42 * s));
            popFont();
            return r;
        };
        if (bigButton("Resume", true)) setPaused(false);
        if (bigButton("Settings", false)) openSettings = true;
        if (playerMode) { if (bigButton("Play Again", false)) { setPaused(false); restartPlay(); } }
        else if (bigButton("Back to Editor", false)) setMode(Mode::Editor);
        ImGui::Dummy(ImVec2(0, 2 * s));
        ImGui::PushStyleColor(ImGuiCol_Text, col::danger);
        if (bigButton("Quit to Desktop", false)) cmdQuit();
        ImGui::PopStyleColor();
        drawSettingsModal(*this);
    }
    ImGui::End();
    ImGui::PopStyleVar(3);
}

} // namespace px
