#pragma once
// Every game compiled into SpireEngine.exe registers itself here with one line:
//
//     PX_REGISTER_GAME(MyGame, "mygame", "My Game", "One-line pitch", IM_COL32(r, g, b, 255))
//
// The Project Hub lists everything registered, and opening a game creates a
// fresh instance through the factory. The engine never names a game directly.
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <imgui.h>
#include "core/Game.h"

namespace px {

struct GameInfo {
    std::string id;            // folder-safe, used for saves: worlds/<id>/
    std::string name;
    std::string tagline;
    ImU32       accent = IM_COL32(77, 141, 255, 255);
    std::function<std::unique_ptr<Game>()> create;
};

std::vector<GameInfo>& gameRegistry();
const GameInfo* findGame(const std::string& id);

struct GameRegistrar {
    explicit GameRegistrar(GameInfo info) { gameRegistry().push_back(std::move(info)); }
};

} // namespace px

#define PX_REGISTER_GAME(Class, id, name, tagline, accent)                                  \
    static ::px::GameRegistrar s_pxRegistrar_##Class({ id, name, tagline, accent,          \
        [] { return std::unique_ptr<::px::Game>(new Class()); } })
