// Display, quality and settings-file parts of the Application: window mode and monitor, UI scale,
// quality presets, and keeping config/settings.cfg up to date.
#include "core/Application.h"
#include "core/SettingsFile.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>

namespace px {

namespace {
constexpr const char* kSettingsPath = "config/settings.cfg";
}

// ---------------------------------------------------------------- settings file

void Application::loadUserSettings(GraphicsValues& gfx) {
    gfx = graphics();
    if (!persistSettings) return;
    if (loadSettingsFile(kSettingsPath, settings, gfx)) lastSettingsText = settingsToText(settings, gfx);
}

void Application::saveUserSettingsIfChanged(bool force) {
    if (!persistSettings) return;
    clampSettings(settings);
    const std::string text = settingsToText(settings, graphics());
    if (!force && text == lastSettingsText) return;
    if (saveSettingsFile(kSettingsPath, settings, graphics())) lastSettingsText = text;
}

// ---------------------------------------------------------------- quality

void Application::setQuality(Quality q) {
    if (q == Quality::Custom) return;
    setGraphics(qualityPreset(q));
    toast(std::string("Graphics quality: ") + qualityName(q), Toast::Kind::Success);
}

// ---------------------------------------------------------------- display

void Application::noteWindowResized(int w, int h) {
    if (!window || frameCounter < ignoreResizeUntil) return;
    if (settings.display.mode != WindowMode::Windowed) return;
    if (SDL_GetWindowFlags(window) & (SDL_WINDOW_FULLSCREEN | SDL_WINDOW_MAXIMIZED | SDL_WINDOW_MINIMIZED)) return;
    if (w >= 640 && h >= 360) { settings.display.width = w; settings.display.height = h; }
}

void Application::applyDisplay() {
    if (!window) return;
    SDL_GL_SetSwapInterval(settings.vsync ? 1 : 0);

    DisplaySettings& d = settings.display;
    const std::vector<MonitorInfo> mons = listMonitors();
    d.monitor = mons.empty() ? 0 : std::clamp(d.monitor, 0, int(mons.size()) - 1);
    const SDL_DisplayID target = mons.empty() ? SDL_GetPrimaryDisplay() : mons[size_t(d.monitor)].id;
    const bool onTarget = SDL_GetDisplayForWindow(window) == target;
    ignoreResizeUntil = frameCounter + 12;                    // the window will report sizes while it switches

    auto moveToTarget = [&] {
        SDL_SetWindowPosition(window, SDL_WINDOWPOS_CENTERED_DISPLAY(target), SDL_WINDOWPOS_CENTERED_DISPLAY(target));
        SDL_SyncWindow(window);
    };

    switch (d.mode) {
    case WindowMode::Windowed:
        SDL_SetWindowFullscreen(window, false);
        SDL_SyncWindow(window);
        SDL_SetWindowSize(window, d.width, d.height);
        if (!onTarget) moveToTarget();
        break;
    case WindowMode::Borderless:
    case WindowMode::Fullscreen: {
        if (!onTarget) { SDL_SetWindowFullscreen(window, false); SDL_SyncWindow(window); moveToTarget(); }
        SDL_DisplayMode mode;
        if (d.mode == WindowMode::Fullscreen && d.fullscreenWidth > 0 &&
            SDL_GetClosestFullscreenDisplayMode(target, d.fullscreenWidth, d.fullscreenHeight, 0.0f, false, &mode))
            SDL_SetWindowFullscreenMode(window, &mode);       // a real video mode change
        else
            SDL_SetWindowFullscreenMode(window, nullptr);     // the desktop's own mode: no flicker, alt-tab friendly
        SDL_SetWindowFullscreen(window, true);
        break;
    }
    }
    SDL_SyncWindow(window);
}

void Application::applyUiScale() {
    settings.display.uiScale = std::clamp(settings.display.uiScale, 0.75f, 2.0f);
    ui::setUiScale(settings.display.uiScale);
}

void Application::nudgeUiScale(float delta) {
    float v = delta == 0.0f ? 1.0f : std::round((settings.display.uiScale + delta) * 20.0f) / 20.0f;   // 5% steps
    v = std::clamp(v, 0.75f, 2.0f);
    settings.display.uiScale = v;
    applyUiScale();
    toast("Interface size: " + std::to_string(int(std::lround(v * 100.0f))) + "%");
}

void Application::toggleFullscreen() {
    DisplaySettings& d = settings.display;
    d.mode = d.mode == WindowMode::Windowed ? WindowMode::Borderless : WindowMode::Windowed;
    applyDisplay();
}

void Application::cycleFpsCap() {
    const auto& c = fpsCapChoices();
    size_t i = 0;
    for (size_t k = 0; k < c.size(); ++k) if (c[k] == settings.display.fpsCap) i = k;
    settings.display.fpsCap = c[(i + 1) % c.size()];
    toast(settings.display.fpsCap == 0 ? "Frame rate limit: off" : "Frame rate limit: " + std::to_string(settings.display.fpsCap) + " FPS");
}

} // namespace px
