#pragma once
// The first-run tutorial (v0.24): a few steps that each wait for you to actually do the thing - look around, shape the
// ground, place a gadget, give it a rule, play it - and move on by themselves when you have. Pure: the editor reports
// what happened (TutorialSignals) and this decides which step you are on. Unit tested.
#include <cstdint>

namespace px {

enum class TutorialStep : std::uint8_t { Welcome, LookAround, ShapeGround, PlaceGadget, AddRule, PlayIt, BackToEditor, Done, Count };

struct TutorialSignals {
    float cameraMoved = 0.0f;                // metres the camera has moved, plus degrees turned / 10, since the step began
    int terrainEdits = 0;                    // edits to the ground since the step began
    int objectsAdded = 0;                    // objects placed since the step began
    bool anyRules = false;                   // some object in the world has rules
    bool playing = false;
};

struct Tutorial {
    TutorialStep step = TutorialStep::Welcome;
    bool active = false;
    float stepTime = 0.0f;                   // seconds on this step
    float doneFlash = 0.0f;                  // a moment of "Done!" before moving on

    void start() { step = TutorialStep::Welcome; active = true; stepTime = 0.0f; doneFlash = 0.0f; }
    void skip() { active = false; step = TutorialStep::Done; }
    void next();                             // the Next button (on the steps that have one)
    // One frame: true when the step changed (the editor then measures the next step's signals from now).
    bool update(const TutorialSignals& s, float dt);
    bool finished() const { return step == TutorialStep::Done; }
    int index() const { return int(step); }
    static constexpr int kSteps = int(TutorialStep::Count);
};

const char* tutorialTitle(TutorialStep s);
const char* tutorialText(TutorialStep s);
bool tutorialHasNext(TutorialStep s);        // a Next button (rather than waiting for you to do it)

} // namespace px
