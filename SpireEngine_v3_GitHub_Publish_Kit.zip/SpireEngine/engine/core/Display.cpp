#include "core/Display.h"
#include <algorithm>

namespace px {

std::vector<MonitorInfo> listMonitors() {
    std::vector<MonitorInfo> out;
    int n = 0;
    SDL_DisplayID* ids = SDL_GetDisplays(&n);
    for (int i = 0; ids && i < n; ++i) {
        MonitorInfo m;
        m.id = ids[i];
        const char* name = SDL_GetDisplayName(ids[i]);
        m.name = name && *name ? name : "Display " + std::to_string(i + 1);
        if (const SDL_DisplayMode* dm = SDL_GetDesktopDisplayMode(ids[i])) {
            m.width = dm->w; m.height = dm->h; m.refresh = dm->refresh_rate;
        }
        out.push_back(m);
    }
    SDL_free(ids);
    return out;
}

std::vector<Resolution> fullscreenResolutions(SDL_DisplayID monitor) {
    std::vector<Resolution> out;
    int n = 0;
    SDL_DisplayMode** modes = SDL_GetFullscreenDisplayModes(monitor, &n);
    for (int i = 0; modes && i < n; ++i) {
        const Resolution r(modes[i]->w, modes[i]->h);
        if (r.first < 800 || r.second < 600) continue;               // nobody wants to play in 640x480
        if (std::find(out.begin(), out.end(), r) == out.end()) out.push_back(r);
    }
    SDL_free(modes);
    std::sort(out.begin(), out.end(), [](const Resolution& a, const Resolution& b) {
        return a.first != b.first ? a.first > b.first : a.second > b.second;
    });
    return out;
}

std::vector<Resolution> windowSizesFor(int monitorW, int monitorH) {
    static const Resolution kSizes[] = {
        { 3840, 2160 }, { 2560, 1440 }, { 2048, 1152 }, { 1920, 1080 }, { 1600, 900 }, { 1366, 768 }, { 1280, 720 }, { 1024, 576 } };
    std::vector<Resolution> out;
    for (const Resolution& r : kSizes)
        if (r.first <= monitorW && r.second <= monitorH - 80) out.push_back(r);     // leave room for the title bar and taskbar
    if (out.empty()) out.push_back({ 1024, 576 });
    return out;
}

const std::vector<int>& fpsCapChoices() {
    static const std::vector<int> kChoices = { 0, 30, 45, 60, 75, 90, 120, 144, 165, 240 };
    return kChoices;
}

double frameWaitSeconds(double elapsedSeconds, int fpsCap) {
    if (fpsCap <= 0) return 0.0;
    return std::max(0.0, 1.0 / double(fpsCap) - elapsedSeconds);
}

int effectiveFpsCap(int userCap, bool reduceInBackground, bool focused, bool minimised) {
    if (minimised) return userCap > 0 ? std::min(userCap, 10) : 10;
    if (reduceInBackground && !focused) return userCap > 0 ? std::min(userCap, 30) : 30;
    return userCap;
}

} // namespace px
