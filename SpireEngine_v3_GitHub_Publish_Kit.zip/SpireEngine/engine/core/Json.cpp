#include "core/Json.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace px {

namespace {
const Json kNull;
}

const Json& Json::at(size_t i) const { return type_ == Type::Array && i < items_.size() ? items_[i] : kNull; }

Json& Json::push(Json v) {
    if (type_ == Type::Null) type_ = Type::Array;
    if (type_ != Type::Array) return const_cast<Json&>(kNull);        // wrong type: ignored (never happens in our own code)
    items_.push_back(std::move(v));
    return items_.back();
}

const Json& Json::get(const std::string& key) const {
    if (type_ == Type::Object)
        for (const auto& m : members_) if (m.first == key) return m.second;
    return kNull;
}

bool Json::has(const std::string& key) const {
    if (type_ == Type::Object)
        for (const auto& m : members_) if (m.first == key) return true;
    return false;
}

Json& Json::set(const std::string& key, Json v) {
    if (type_ == Type::Null) type_ = Type::Object;
    if (type_ != Type::Object) return const_cast<Json&>(kNull);
    for (auto& m : members_) if (m.first == key) { m.second = std::move(v); return m.second; }
    members_.emplace_back(key, std::move(v));
    return members_.back().second;
}

// ------------------------------------------------------------------ writing

namespace {
void writeString(std::string& out, const std::string& s) {
    out += '"';
    for (unsigned char c : s) {
        switch (c) {
        case '"':  out += "\\\""; break;
        case '\\': out += "\\\\"; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default:
            if (c < 0x20) { char b[8]; std::snprintf(b, sizeof b, "\\u%04x", c); out += b; }
            else out += char(c);
        }
    }
    out += '"';
}
void writeNumber(std::string& out, double v) {
    if (!std::isfinite(v)) { out += "0"; return; }
    char b[40];
    if (v == std::floor(v) && std::fabs(v) < 1e15) std::snprintf(b, sizeof b, "%.0f", v);
    else std::snprintf(b, sizeof b, "%.9g", v);
    out += b;
}
}

void Json::write(std::string& out, int indent, int depth) const {
    const bool pretty = indent >= 0;
    auto newline = [&](int d) { if (pretty) { out += '\n'; out.append(size_t(d * indent), ' '); } };
    switch (type_) {
    case Type::Null:   out += "null"; break;
    case Type::Bool:   out += bool_ ? "true" : "false"; break;
    case Type::Number: writeNumber(out, num_); break;
    case Type::String: writeString(out, str_); break;
    case Type::Array: {
        if (items_.empty()) { out += "[]"; break; }
        // Short arrays of plain numbers stay on one line: [1, 2, 3]
        bool flat = true;
        for (const Json& i : items_) if (i.type_ == Type::Array || i.type_ == Type::Object) flat = false;
        out += '[';
        for (size_t i = 0; i < items_.size(); ++i) {
            if (i) out += pretty && flat ? ", " : ",";
            if (!flat) newline(depth + 1);
            items_[i].write(out, indent, depth + 1);
        }
        if (!flat) newline(depth);
        out += ']';
        break;
    }
    case Type::Object: {
        if (members_.empty()) { out += "{}"; break; }
        out += '{';
        for (size_t i = 0; i < members_.size(); ++i) {
            if (i) out += ',';
            newline(depth + 1);
            writeString(out, members_[i].first);
            out += pretty ? ": " : ":";
            members_[i].second.write(out, indent, depth + 1);
        }
        newline(depth);
        out += '}';
        break;
    }
    }
}

std::string Json::dump(int indent) const {
    std::string out;
    write(out, indent, 0);
    return out;
}

// ------------------------------------------------------------------ reading

namespace {
struct Parser {
    const std::string& s;
    size_t i = 0;
    int line = 1;
    std::string err;
    int depth = 0;

    explicit Parser(const std::string& text) : s(text) {}

    bool fail(const std::string& why) { if (err.empty()) err = "line " + std::to_string(line) + ": " + why; return false; }
    void skip() {
        while (i < s.size()) {
            const char c = s[i];
            if (c == '\n') { ++line; ++i; }
            else if (c == ' ' || c == '\t' || c == '\r') ++i;
            else break;
        }
    }
    bool literal(const char* word) {
        size_t n = 0; while (word[n]) ++n;
        if (s.compare(i, n, word) == 0) { i += n; return true; }
        return false;
    }
    static void utf8(std::string& out, unsigned cp) {
        if (cp < 0x80) out += char(cp);
        else if (cp < 0x800) { out += char(0xC0 | (cp >> 6)); out += char(0x80 | (cp & 0x3F)); }
        else if (cp < 0x10000) { out += char(0xE0 | (cp >> 12)); out += char(0x80 | ((cp >> 6) & 0x3F)); out += char(0x80 | (cp & 0x3F)); }
        else { out += char(0xF0 | (cp >> 18)); out += char(0x80 | ((cp >> 12) & 0x3F)); out += char(0x80 | ((cp >> 6) & 0x3F)); out += char(0x80 | (cp & 0x3F)); }
    }
    bool string(std::string& out) {
        if (i >= s.size() || s[i] != '"') return fail("expected a string");
        ++i;
        out.clear();
        while (i < s.size()) {
            const char c = s[i++];
            if (c == '"') return true;
            if (c == '\n') return fail("a string runs over the end of the line");
            if (c != '\\') { out += c; continue; }
            if (i >= s.size()) break;
            const char e = s[i++];
            switch (e) {
            case '"': out += '"'; break;
            case '\\': out += '\\'; break;
            case '/': out += '/'; break;
            case 'b': out += '\b'; break;
            case 'f': out += '\f'; break;
            case 'n': out += '\n'; break;
            case 'r': out += '\r'; break;
            case 't': out += '\t'; break;
            case 'u': {
                if (i + 4 > s.size()) return fail("bad \\u escape");
                unsigned cp = 0;
                for (int k = 0; k < 4; ++k) {
                    const char h = s[i++];
                    cp <<= 4;
                    if (h >= '0' && h <= '9') cp |= unsigned(h - '0');
                    else if (h >= 'a' && h <= 'f') cp |= unsigned(h - 'a' + 10);
                    else if (h >= 'A' && h <= 'F') cp |= unsigned(h - 'A' + 10);
                    else return fail("bad \\u escape");
                }
                utf8(out, cp);
                break;
            }
            default: return fail("unknown escape in a string");
            }
        }
        return fail("a string is not closed");
    }
    bool value(Json& out) {
        skip();
        if (i >= s.size()) return fail("the text ends too soon");
        if (++depth > 64) return fail("nested too deeply");
        struct Pop { int& d; ~Pop() { --d; } } pop{ depth };
        const char c = s[i];
        if (c == '{') {
            ++i;
            out = Json::object();
            skip();
            if (i < s.size() && s[i] == '}') { ++i; return true; }
            for (;;) {
                skip();
                std::string key;
                if (!string(key)) return false;
                skip();
                if (i >= s.size() || s[i] != ':') return fail("expected ':' after a name");
                ++i;
                Json v;
                if (!value(v)) return false;
                out.set(key, std::move(v));
                skip();
                if (i < s.size() && s[i] == ',') { ++i; continue; }
                if (i < s.size() && s[i] == '}') { ++i; return true; }
                return fail("expected ',' or '}'");
            }
        }
        if (c == '[') {
            ++i;
            out = Json::array();
            skip();
            if (i < s.size() && s[i] == ']') { ++i; return true; }
            for (;;) {
                Json v;
                if (!value(v)) return false;
                out.push(std::move(v));
                skip();
                if (i < s.size() && s[i] == ',') { ++i; continue; }
                if (i < s.size() && s[i] == ']') { ++i; return true; }
                return fail("expected ',' or ']'");
            }
        }
        if (c == '"') { std::string t; if (!string(t)) return false; out = Json(std::move(t)); return true; }
        if (literal("true"))  { out = Json(true); return true; }
        if (literal("false")) { out = Json(false); return true; }
        if (literal("null"))  { out = Json(); return true; }
        if (c == '-' || (c >= '0' && c <= '9')) {
            const char* begin = s.c_str() + i;
            char* end = nullptr;
            const double v = std::strtod(begin, &end);
            if (end == begin) return fail("a number was expected");
            i += size_t(end - begin);
            out = Json(v);
            return true;
        }
        return fail(std::string("unexpected '") + c + "'");
    }
};
}

bool Json::parse(const std::string& text, Json& out, std::string* error) {
    Parser p(text);
    Json v;
    if (!p.value(v)) { if (error) *error = p.err; return false; }
    p.skip();
    if (p.i != text.size()) { p.fail("extra text after the end"); if (error) *error = p.err; return false; }
    out = std::move(v);
    return true;
}

} // namespace px
