#pragma once
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

struct Camera {
    glm::vec3 position{ 0.0f, 80.0f, 0.0f };
    float yaw   = -90.0f;   // degrees
    float pitch = -20.0f;
    float fovDegrees = 70.0f;
    float sensitivity = 0.12f;
    // Local vertical: fixed global Y for existing flat worlds, radial in the
    // experimental planet editor. Player/physics remain Y-up until migrated.
    glm::vec3 up{0.0f, 1.0f, 0.0f};

    bool setUpVector(const glm::vec3& candidate) {
        if (!std::isfinite(candidate.x) || !std::isfinite(candidate.y) ||
            !std::isfinite(candidate.z)) return false;
        const float lengthSq = glm::dot(candidate, candidate);
        if (!std::isfinite(lengthSq) || lengthSq <= 1e-12f) return false;
        up = glm::normalize(candidate);
        return true;
    }

    // Tangent axes chosen to retain the original yaw convention for +Y-up:
    // yaw 0 points +X; yaw -90 points -Z. Reference switches near the poles.
    void tangentAxes(glm::vec3& east, glm::vec3& north) const {
        const glm::vec3 reference = std::abs(up.z) < 0.95f
            ? glm::vec3(0.0f, 0.0f, 1.0f) : glm::vec3(0.0f, 1.0f, 0.0f);
        east = glm::normalize(glm::cross(up, reference));
        north = glm::normalize(glm::cross(east, up));
    }

    glm::vec3 flatFront() const {
        glm::vec3 east, north;
        tangentAxes(east, north);
        return glm::normalize(east * std::cos(glm::radians(yaw)) +
                              north * std::sin(glm::radians(yaw)));
    }
    glm::vec3 front() const {
        return glm::normalize(flatFront() * std::cos(glm::radians(pitch)) +
                              up * std::sin(glm::radians(pitch)));
    }
    glm::vec3 right() const { return glm::normalize(glm::cross(front(), up)); }

    // Turn to face a point in the camera's current local tangent frame.
    void lookAt(const glm::vec3& target) {
        const glm::vec3 delta = target - position;
        if (glm::dot(delta, delta) <= 1e-12f) return;
        const glm::vec3 d = glm::normalize(delta);
        glm::vec3 east, north;
        tangentAxes(east, north);
        const float e = glm::dot(d, east), n = glm::dot(d, north);
        if (e * e + n * n > 1e-10f)
            yaw = glm::degrees(std::atan2(n, e));
        pitch = glm::degrees(std::asin(glm::clamp(glm::dot(d, up), -1.0f, 1.0f)));
        pitch = glm::clamp(pitch, -89.0f, 89.0f);
    }

    void look(float dx, float dy) {
        yaw += dx * sensitivity;
        pitch = glm::clamp(pitch - dy * sensitivity, -89.0f, 89.0f);
    }

    glm::mat4 view() const { return glm::lookAt(position, position + front(), up); }
    glm::mat4 projection(float aspect) const { return glm::perspective(glm::radians(fovDegrees), aspect, 0.1f, 1000.0f); }

    // Ray through a pixel (for clicking on the world with a free cursor).
    glm::vec3 rayThroughPixel(float px, float py, float width, float height) const {
        const glm::vec4 ndc((2.0f * px) / width - 1.0f, 1.0f - (2.0f * py) / height, 1.0f, 1.0f);
        const glm::mat4 inv = glm::inverse(projection(width / height) * view());
        glm::vec4 world = inv * ndc;
        world /= world.w;
        return glm::normalize(glm::vec3(world) - position);
    }
};

// A smooth glide to a saved view (camera bookmarks): ease-in/out, takes the short way round.
struct CameraFly {
    bool active = false;
    glm::vec3 fromPos{ 0.0f }, toPos{ 0.0f };
    float fromYaw = 0, toYaw = 0, fromPitch = 0, toPitch = 0, t = 0, duration = 1;

    void start(const Camera& c, const glm::vec3& pos, float yaw, float pitch) {
        fromPos = c.position; toPos = pos;
        fromYaw = c.yaw;
        float dy = std::fmod(yaw - c.yaw, 360.0f);
        if (dy > 180.0f) dy -= 360.0f;
        if (dy < -180.0f) dy += 360.0f;
        toYaw = c.yaw + dy;
        fromPitch = c.pitch; toPitch = pitch;
        t = 0.0f;
        duration = glm::clamp(0.45f + glm::length(pos - c.position) / 160.0f, 0.5f, 1.5f);
        active = true;
    }
    // Advances the camera; returns true while still flying.
    bool update(Camera& c, float dt) {
        if (!active) return false;
        t += dt;
        const float u = glm::clamp(t / duration, 0.0f, 1.0f);
        const float e = u * u * u * (u * (u * 6.0f - 15.0f) + 10.0f);        // smootherstep
        c.position = glm::mix(fromPos, toPos, e);
        c.yaw = glm::mix(fromYaw, toYaw, e);
        c.pitch = glm::mix(fromPitch, toPitch, e);
        if (u >= 1.0f) active = false;
        return active;
    }
    void cancel() { active = false; }
};

} // namespace px
