#include "core/GameRegistry.h"

namespace px {

std::vector<GameInfo>& gameRegistry() {
    static std::vector<GameInfo> registry;   // function-local: safe during static init
    return registry;
}

const GameInfo* findGame(const std::string& id) {
    for (const auto& g : gameRegistry())
        if (g.id == id) return &g;
    return nullptr;
}

} // namespace px
