#pragma once
// The command registry behind the command palette (Ctrl+P). Every action worth having
// (tools, save, time of day, layouts, bookmarks, game powers...) is a Command; the palette
// searches them by typing a few letters of the title. Games add their own:
//
//     app.commands.add({ "game.reset", "Vanguard: Reset energy", "Vanguard", "", [&] { ... } });
#include <functional>
#include <string>
#include <vector>

namespace px {

struct Command {
    std::string id;                          // unique, e.g. "tool.carve"; ids starting "game." are cleared when a game closes
    std::string title;                       // what you see and search: "Tool: Carve"
    std::string category;                    // grouping / extra search words: "Tools"
    std::string shortcut;                    // display only: "Ctrl+Z"
    std::function<void()> run;
    std::function<bool()> enabled;           // optional: greyed out and not runnable when false
};

class CommandRegistry {
public:
    void add(Command c);                                   // same id replaces
    void removeWithPrefix(const std::string& prefix);
    const std::vector<Command>& all() const { return commands; }
    const Command* find(const std::string& id) const;

    // Indices into all(), best match first. Typing "crv" finds "Tool: Carve"; letters must
    // appear in order, word starts and runs score higher. An empty query lists recently used
    // commands first, then everything in registration order.
    std::vector<int> search(const std::string& query) const;
    bool run(const std::string& id);                       // false if unknown or disabled
    bool isEnabled(const Command& c) const { return !c.enabled || c.enabled(); }

    // -1 = no match. Exposed for tests.
    static int fuzzyScore(const std::string& text, const std::string& query);

private:
    std::vector<Command> commands;
    std::vector<std::string> recent;                       // most recent last
};

} // namespace px
