#pragma once
// Where you left off: camera, time of day, tool and the nine camera bookmarks. Saved next
// to the world (worlds/<game>/editor.state) as plain text, so it is easy to read and diff.
#include <array>
#include <string>
#include <glm/glm.hpp>

namespace px {

struct CameraBookmark {
    bool        used = false;
    std::string name;
    glm::vec3   position{ 0.0f };
    float       yaw = -90.0f, pitch = -20.0f;
};

struct EditorState {
    static constexpr int kBookmarks = 9;

    bool      hasCamera = false;
    glm::vec3 cameraPosition{ 0.0f };
    float     cameraYaw = -90.0f, cameraPitch = -20.0f;
    bool      hasTime = false;
    float     timeOfDay = 10.0f;
    int       tool = 0;
    float     brushRadius = 3.0f;
    int       brushMaterial = 3;
    float     flySpeed = 30.0f;
    std::string playerCharacter;          // what you look like in third person (empty: the default)
    std::array<CameraBookmark, kBookmarks> bookmarks;

    bool save(const std::string& path) const;
    static bool load(const std::string& path, EditorState& out);
};

} // namespace px
