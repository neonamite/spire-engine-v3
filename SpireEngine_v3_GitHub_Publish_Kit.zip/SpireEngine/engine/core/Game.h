#pragma once
// ============================================================================
//  px::Game - the ONE interface between Spire Engine and a game.
//
//  The engine owns the window, the world, rendering, saving, the editor and the
//  basic first-person walker. A game is a class that implements this interface
//  and adds its own rules, HUD and editor panels on top. The engine never
//  includes game headers; games only include engine headers.
//
//  To make a new game: copy games/template, implement the hooks you need,
//  register it with PX_REGISTER_GAME (core/GameRegistry.h) and add the folder
//  to the root CMakeLists.txt. It then appears in the Project Hub.
// ============================================================================
#include <SDL3/SDL_events.h>

namespace px {

class Application;
struct ItemHit;

class Game {
public:
    virtual ~Game() = default;

    // Shown in the window title, editor menu bar and About box.
    virtual const char* name() const = 0;

    // ---- lifetime
    virtual void onStart(Application&) {}                  // engine is ready, world is streaming
    virtual void onShutdown(Application&) {}

    // ---- play mode (the player is walking around)
    virtual void onEnterPlay(Application&) {}
    virtual void onExitPlay(Application&) {}
    // Input the engine didn't use itself (WASD/Space/Shift/Esc/Tab are the engine's).
    // Return true if the game handled it.
    virtual bool onPlayEvent(Application&, const SDL_Event&) { return false; }
    virtual void onPlayUpdate(Application&, float /*dt*/) {}
    virtual void drawPlayHUD(Application&) {}               // ImGui draw calls; engine adds toasts + pause menu
    // An item the player used hit something or went off (items/ItemSystem.h). Only called when engine items are on.
    virtual void onItemHit(Application&, const ItemHit&) {}

    // ---- editor (Director mode)
    // Add extra Inspector tabs with ImGui::BeginTabItem(...). Use
    // app.tabFlags(i) so the engine can select your tab programmatically.
    virtual void drawInspectorTabs(Application&) {}
    // Add entries to the editor's "Game" menu.
    virtual void drawGameMenu(Application&) {}

    // ---- test/screenshot hook (--demo <name>), optional
    virtual void onDemo(Application&, const char* /*demo*/) {}
};

} // namespace px
