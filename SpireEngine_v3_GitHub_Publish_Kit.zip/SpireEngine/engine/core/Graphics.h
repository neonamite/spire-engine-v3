#pragma once
// Graphics quality (roadmap #26). The knobs that cost the most frame time live in
// GraphicsValues; a preset is just a named set of values, and "Custom" is whatever matches none.
// The values themselves are stored where they are used: RenderSettings and the world's view
// distance, so the Environment panel, Settings and the command palette all see the same thing.
#include <cstddef>
#include "render/Renderer.h"

namespace px {

enum class Quality { Low, Medium, High, Ultra, Custom };

struct GraphicsValues {
    float renderScale   = 1.0f;     // 3D resolution relative to the view
    bool  shadows       = true;
    int   shadowSize    = 4096;     // pixels: 1024 / 2048 / 4096
    float shadowRange   = 90.0f;    // metres around the camera that get shadows
    bool  bloom         = true;
    bool  fxaa          = true;
    bool  grass         = true;
    float grassDensity  = 1.0f;
    float grassDistance = 70.0f;
    int   viewDistance  = 5;        // chunks
    int   textureSize   = 2048;     // texture detail: 512 / 1024 / 2048 / 4096 pixels per material
    bool  ssao          = true;     // ambient occlusion: soft shade in corners, under things and in creases
    bool  trees         = true;     // the trees and bushes the world plants
    float treeDistance  = 200.0f;   // metres
};

const char* qualityName(Quality q);
const char* qualityBlurb(Quality q);              // one line for the Settings window
GraphicsValues qualityPreset(Quality q);          // Low..Ultra; Custom returns High
Quality detectQuality(const GraphicsValues& g);   // the preset these values equal, else Custom

GraphicsValues readGraphics(const RenderSettings& rs, int viewDistance);
void writeGraphics(const GraphicsValues& g, RenderSettings& rs, int& viewDistance);
void clampGraphics(GraphicsValues& g);            // forces every value into its legal range

// A rough "how heavy is this" number for the Settings window (High = 1.0). Not a benchmark.
float relativeCost(const GraphicsValues& g);

} // namespace px
