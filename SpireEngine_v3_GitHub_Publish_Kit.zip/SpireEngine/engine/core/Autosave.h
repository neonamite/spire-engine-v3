#pragma once
// Autosave and crash recovery for the world you have open.
//
//   <worldDir>/autosave/autosave_0..N.vxworld   rotating copies; the oldest is overwritten
//   <worldDir>/.session                         exists while the world is open in the editor
//
// Closing a game normally removes .session. If it is still there next time, the editor
// died (crash, power cut, killed process) and the newest autosave may hold work that was
// never saved: recoverable() tells you, and the editor offers to restore it.
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace px {

class ChunkManager;

struct AutosaveInfo {
    std::string path;
    std::string label;                           // "14:32"
    std::filesystem::file_time_type time;
    std::uintmax_t bytes = 0;
};

class Autosave {
public:
    int   keep = 5;                              // copies kept
    float intervalMinutes = 3.0f;                // 0 = off

    // Starts watching a world folder (e.g. "worlds/vanguard"). Returns true if the previous
    // session of that world did NOT end cleanly.
    bool beginSession(const std::string& worldDir);
    void endSession();                           // clean exit: removes the lock
    bool active() const { return !dir.empty(); }

    // Call every frame. Writes an autosave when the interval has passed AND the world has
    // changed since the last save of any kind. Returns true when it wrote one.
    bool update(const ChunkManager& world, float dt);
    bool saveNow(const ChunkManager& world);
    // Tells autosave the world is already safe on disk (after a manual save or a load).
    void markSaved(const ChunkManager& world);

    std::vector<AutosaveInfo> list() const;      // newest first
    // The newest autosave, if it is newer than the saved world file (or the file is missing).
    std::optional<AutosaveInfo> recoverable(const std::string& worldFile) const;

    static std::string clockLabel(std::filesystem::file_time_type t);

private:
    std::string dir;                             // worldDir
    float timer = 0.0f;
    std::uint64_t savedRevision = 0;
    bool haveRevision = false;
};

} // namespace px
