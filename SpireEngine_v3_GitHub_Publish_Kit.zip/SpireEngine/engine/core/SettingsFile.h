#pragma once
// Reads and writes config/settings.cfg: plain text, one "key = value" per line, so it can be
// edited by hand or shared. Unknown keys are ignored and bad values keep their default, so a
// file from an older or newer version never stops the engine from starting.
#include <string>
#include "core/Graphics.h"
#include "core/Settings.h"

namespace px {

std::string settingsToText(const UserSettings& s, const GraphicsValues& g);
// Applies every value found in `text` over s and g (clamped to legal ranges). Returns how many were read.
int settingsFromText(const std::string& text, UserSettings& s, GraphicsValues& g);

bool saveSettingsFile(const std::string& path, const UserSettings& s, const GraphicsValues& g);   // atomic (tmp + rename)
bool loadSettingsFile(const std::string& path, UserSettings& s, GraphicsValues& g);               // false: no file

void clampSettings(UserSettings& s);

} // namespace px
