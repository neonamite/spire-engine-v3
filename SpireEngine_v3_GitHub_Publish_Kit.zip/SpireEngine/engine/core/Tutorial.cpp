#include "core/Tutorial.h"
#include <cstddef>
#include <iterator>

namespace px {

namespace {
struct StepInfo { const char* title; const char* text; bool next; };
const StepInfo kSteps[] = {
    { "Welcome to Spire Engine", "This is your world. A few quick steps show you how to make it into a game. You can skip at any time.", true },
    { "Look around", "Hold the right mouse button and move the mouse to look. While holding it, W A S D fly, Q and E go down and up.", false },
    { "Shape the ground", "Click Shape at the top, pick Carve (1) or Add (2) on the left, then click and hold on the ground. Ctrl+Z undoes anything.", false },
    { "Place a gadget", "Click Logic at the top, pick the Coin on the shelf at the bottom, then click on the ground to put it there.", false },
    { "Give it a rule", "A coin already has one: select it and click Rules just above it. Add one of your own with + Add a rule.", false },
    { "Play it", "Press Tab (or the orange Play button at the top) to play your world. Walk into the coin!", false },
    { "Back to the editor", "Press Tab again to come back and keep building.", false },
    { "You're ready", "Next: Logic > Starters for a ready-made game, People for characters, and Share (top right) to send it to friends. Hold Space any time for the quick wheel.", true },
};
} // namespace

const char* tutorialTitle(TutorialStep s) { return size_t(s) < std::size(kSteps) ? kSteps[size_t(s)].title : ""; }
const char* tutorialText(TutorialStep s) { return size_t(s) < std::size(kSteps) ? kSteps[size_t(s)].text : ""; }
bool tutorialHasNext(TutorialStep s) { return size_t(s) < std::size(kSteps) && kSteps[size_t(s)].next; }

void Tutorial::next() {
    if (!active) return;
    if (step == TutorialStep::Done || int(step) + 1 >= kSteps) { active = false; step = TutorialStep::Done; return; }
    step = TutorialStep(int(step) + 1);
    stepTime = 0.0f; doneFlash = 0.0f;
}

bool Tutorial::update(const TutorialSignals& s, float dt) {
    if (!active) return false;
    stepTime += dt;
    if (doneFlash > 0.0f) {                  // showing "Done!": move on when it is over
        doneFlash -= dt;
        if (doneFlash <= 0.0f) { next(); return true; }
        return false;
    }
    bool done = false;
    switch (step) {
    case TutorialStep::LookAround: done = s.cameraMoved > 6.0f; break;
    case TutorialStep::ShapeGround: done = s.terrainEdits > 0; break;
    case TutorialStep::PlaceGadget: done = s.objectsAdded > 0; break;
    case TutorialStep::AddRule: done = s.anyRules && stepTime > 4.0f; break;      // a moment to read it
    case TutorialStep::PlayIt: done = s.playing; break;
    case TutorialStep::BackToEditor: done = !s.playing; break;
    default: break;
    }
    if (done) doneFlash = 1.2f;
    return false;
}

} // namespace px
