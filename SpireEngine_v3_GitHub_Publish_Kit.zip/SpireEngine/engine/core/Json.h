#pragma once
// A small JSON value, reader and writer. Engine files keep their settings and descriptions as
// readable JSON next to binary data (assets, later items and characters), so people and other
// tools can open and edit them. Nothing here depends on the rest of the engine.
//
//   Json j = Json::object();
//   j.set("name", "Sword");
//   j.set("size", Json::array({ 1, 2, 3 }));
//   std::string text = j.dump();
//   Json back; std::string err; if (!Json::parse(text, back, &err)) ...
//   back["name"].str("?");  back.get("size").num(0)...
#include <cstdint>
#include <initializer_list>
#include <string>
#include <utility>
#include <vector>

namespace px {

class Json {
public:
    enum class Type { Null, Bool, Number, String, Array, Object };

    Json() = default;
    Json(bool b) : type_(Type::Bool), bool_(b) {}
    Json(int n) : type_(Type::Number), num_(n) {}
    Json(unsigned n) : type_(Type::Number), num_(n) {}
    Json(std::int64_t n) : type_(Type::Number), num_(double(n)) {}
    Json(std::uint64_t n) : type_(Type::Number), num_(double(n)) {}
    Json(float n) : type_(Type::Number), num_(n) {}
    Json(double n) : type_(Type::Number), num_(n) {}
    Json(const char* s) : type_(Type::String), str_(s) {}
    Json(std::string s) : type_(Type::String), str_(std::move(s)) {}

    static Json object() { Json j; j.type_ = Type::Object; return j; }
    static Json array() { Json j; j.type_ = Type::Array; return j; }
    static Json array(std::initializer_list<Json> items) { Json j = array(); for (const Json& i : items) j.push(i); return j; }

    Type type() const { return type_; }
    bool isNull() const { return type_ == Type::Null; }
    bool isBool() const { return type_ == Type::Bool; }
    bool isNumber() const { return type_ == Type::Number; }
    bool isString() const { return type_ == Type::String; }
    bool isArray() const { return type_ == Type::Array; }
    bool isObject() const { return type_ == Type::Object; }

    // Reading never throws: a missing key or the wrong type gives the fallback.
    double num(double fallback = 0.0) const { return type_ == Type::Number ? num_ : fallback; }
    int    integer(int fallback = 0) const { return type_ == Type::Number ? int(num_) : fallback; }
    bool   boolean(bool fallback = false) const { return type_ == Type::Bool ? bool_ : fallback; }
    std::string str(const std::string& fallback = std::string()) const { return type_ == Type::String ? str_ : fallback; }

    // Arrays
    size_t size() const { return type_ == Type::Array ? items_.size() : type_ == Type::Object ? members_.size() : 0; }
    const Json& at(size_t i) const;                       // a null Json when out of range
    Json& push(Json v);                                   // makes this an array if it is null

    // Objects (members keep the order they were added in)
    const Json& get(const std::string& key) const;        // a null Json when missing
    bool has(const std::string& key) const;
    Json& set(const std::string& key, Json v);            // makes this an object if it is null; replaces an existing key
    const std::vector<std::pair<std::string, Json>>& members() const { return members_; }

    std::string dump(int indent = 2) const;               // indent < 0: one line
    // Parses text. On failure returns false, leaves `out` untouched and fills *error ("line 3: ...") when given.
    static bool parse(const std::string& text, Json& out, std::string* error = nullptr);

private:
    void write(std::string& out, int indent, int depth) const;

    Type type_ = Type::Null;
    bool bool_ = false;
    double num_ = 0.0;
    std::string str_;
    std::vector<Json> items_;
    std::vector<std::pair<std::string, Json>> members_;
};

} // namespace px
