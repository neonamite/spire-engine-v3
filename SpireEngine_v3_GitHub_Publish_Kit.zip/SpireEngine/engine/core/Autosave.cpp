#include "core/Autosave.h"
#include "world/ChunkManager.h"
#include <algorithm>
#include <chrono>
#include <ctime>
#include <fstream>

namespace px {

namespace fs = std::filesystem;

namespace {
fs::path autosaveDir(const std::string& worldDir) { return fs::path(worldDir) / "autosave"; }
fs::path slotPath(const std::string& worldDir, int slot) { return autosaveDir(worldDir) / ("autosave_" + std::to_string(slot) + ".vxworld"); }
fs::path lockPath(const std::string& worldDir) { return fs::path(worldDir) / ".session"; }
}

std::string Autosave::clockLabel(fs::file_time_type t) {
    // file_clock -> system_clock without C++20 clock_cast (not in every standard library yet).
    const auto sys = std::chrono::time_point_cast<std::chrono::system_clock::duration>(
        t - fs::file_time_type::clock::now() + std::chrono::system_clock::now());
    const std::time_t tt = std::chrono::system_clock::to_time_t(sys);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &tt);
#else
    localtime_r(&tt, &tm);
#endif
    char buf[16];
    std::strftime(buf, sizeof buf, "%H:%M", &tm);
    return buf;
}

bool Autosave::beginSession(const std::string& worldDir) {
    if (!dir.empty()) endSession();
    dir = worldDir;
    timer = 0.0f;
    haveRevision = false;
    std::error_code ec;
    fs::create_directories(dir, ec);
    const bool crashed = fs::exists(lockPath(dir), ec);
    std::ofstream(lockPath(dir)) << "Spire Engine session lock. If this file exists when the editor starts, the last session did not close cleanly.\n";
    return crashed;
}

void Autosave::endSession() {
    if (dir.empty()) return;
    std::error_code ec;
    fs::remove(lockPath(dir), ec);
    dir.clear();
}

void Autosave::markSaved(const ChunkManager& world) {
    savedRevision = world.revision();
    haveRevision = true;
    timer = 0.0f;
}

bool Autosave::saveNow(const ChunkManager& world) {
    if (dir.empty()) return false;
    std::error_code ec;
    fs::create_directories(autosaveDir(dir), ec);
    // Overwrite the oldest slot (an empty slot counts as oldest).
    int best = 0;
    fs::file_time_type bestTime = fs::file_time_type::max();
    for (int i = 0; i < std::max(keep, 1); ++i) {
        const fs::path p = slotPath(dir, i);
        if (!fs::exists(p, ec)) { best = i; bestTime = fs::file_time_type::min(); break; }
        const auto t = fs::last_write_time(p, ec);
        if (t < bestTime) { bestTime = t; best = i; }
    }
    if (!world.saveWorld(slotPath(dir, best).string())) return false;
    savedRevision = world.revision();
    haveRevision = true;
    return true;
}

bool Autosave::update(const ChunkManager& world, float dt) {
    if (dir.empty() || intervalMinutes <= 0.0f) return false;
    timer += dt;
    if (timer < intervalMinutes * 60.0f) return false;
    timer = 0.0f;
    if (haveRevision && world.revision() == savedRevision) return false;     // nothing new to protect
    return saveNow(world);
}

std::vector<AutosaveInfo> Autosave::list() const {
    std::vector<AutosaveInfo> out;
    if (dir.empty()) return out;
    std::error_code ec;
    for (int i = 0; i < std::max(keep, 1); ++i) {
        const fs::path p = slotPath(dir, i);
        if (!fs::exists(p, ec)) continue;
        AutosaveInfo a;
        a.path = p.string();
        a.time = fs::last_write_time(p, ec);
        a.bytes = fs::file_size(p, ec);
        a.label = clockLabel(a.time);
        out.push_back(std::move(a));
    }
    std::sort(out.begin(), out.end(), [](const AutosaveInfo& a, const AutosaveInfo& b) { return a.time > b.time; });
    return out;
}

std::optional<AutosaveInfo> Autosave::recoverable(const std::string& worldFile) const {
    const auto all = list();
    if (all.empty()) return std::nullopt;
    std::error_code ec;
    if (!fs::exists(worldFile, ec)) return all.front();
    if (all.front().time > fs::last_write_time(worldFile, ec)) return all.front();
    return std::nullopt;
}

} // namespace px
