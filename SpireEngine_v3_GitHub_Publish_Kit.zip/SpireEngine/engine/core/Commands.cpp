#include "core/Commands.h"
#include <algorithm>
#include <cctype>

namespace px {

namespace {
bool isBoundary(char c) { return c == ' ' || c == ':' || c == '-' || c == '_' || c == '/' || c == '.'; }
std::string lower(std::string s) { for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c))); return s; }
}

int CommandRegistry::fuzzyScore(const std::string& textIn, const std::string& queryIn) {
    const std::string text = lower(textIn), query = lower(queryIn);
    if (query.empty()) return 0;
    size_t qi = 0;
    int score = 0, prev = -2;
    for (size_t ti = 0; ti < text.size() && qi < query.size(); ++ti) {
        if (text[ti] != query[qi]) continue;
        score += 10;
        if (int(ti) == prev + 1) score += 15;                                // runs of letters
        if (ti == 0) score += 25;                                            // starts the title
        else if (isBoundary(text[ti - 1])) score += 20;                      // starts a word
        prev = int(ti);
        ++qi;
    }
    if (qi < query.size()) return -1;
    const size_t pos = text.find(query);
    if (pos != std::string::npos) score += 40 + (pos == 0 ? 30 : 0);          // the whole query appears as typed
    score -= int(text.size() / 6);                                           // prefer short titles
    return score;
}

void CommandRegistry::add(Command c) {
    for (auto& e : commands) if (e.id == c.id) { e = std::move(c); return; }
    commands.push_back(std::move(c));
}

void CommandRegistry::removeWithPrefix(const std::string& prefix) {
    commands.erase(std::remove_if(commands.begin(), commands.end(), [&](const Command& c) { return c.id.rfind(prefix, 0) == 0; }), commands.end());
}

const Command* CommandRegistry::find(const std::string& id) const {
    for (auto& c : commands) if (c.id == id) return &c;
    return nullptr;
}

std::vector<int> CommandRegistry::search(const std::string& query) const {
    std::vector<int> out;
    if (query.empty()) {
        for (auto it = recent.rbegin(); it != recent.rend(); ++it)
            for (size_t i = 0; i < commands.size(); ++i) if (commands[i].id == *it && isEnabled(commands[i])) out.push_back(int(i));
        for (size_t i = 0; i < commands.size(); ++i)
            if (std::find(out.begin(), out.end(), int(i)) == out.end() && isEnabled(commands[i])) out.push_back(int(i));   // nothing typed: only what you can do right now
        return out;
    }
    std::vector<std::pair<int, int>> scored;                                  // score, index
    for (size_t i = 0; i < commands.size(); ++i) {
        const Command& c = commands[i];
        int s = fuzzyScore(c.title, query);
        const int s2 = fuzzyScore(c.category + " " + c.title, query) - 20;    // category words count a little less
        s = std::max(s, s2);
        if (s < 0) continue;
        if (!isEnabled(c)) s -= 30;
        scored.emplace_back(s, int(i));
    }
    std::stable_sort(scored.begin(), scored.end(), [](auto& a, auto& b) { return a.first > b.first; });
    for (auto& [s, i] : scored) out.push_back(i);
    return out;
}

bool CommandRegistry::run(const std::string& id) {
    const Command* c = find(id);
    if (!c || !c->run || !isEnabled(*c)) return false;
    recent.erase(std::remove(recent.begin(), recent.end(), id), recent.end());
    recent.push_back(id);
    if (recent.size() > 8) recent.erase(recent.begin());
    c->run();                                                                 // may add/remove commands: don't touch c after this
    return true;
}

} // namespace px
