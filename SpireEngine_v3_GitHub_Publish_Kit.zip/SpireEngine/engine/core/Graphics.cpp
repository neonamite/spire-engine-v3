#include "core/Graphics.h"
#include <algorithm>
#include <cmath>

namespace px {

const char* qualityName(Quality q) {
    switch (q) {
    case Quality::Low:    return "Low";
    case Quality::Medium: return "Medium";
    case Quality::High:   return "High";
    case Quality::Ultra:  return "Ultra";
    case Quality::Custom: return "Custom";
    }
    return "Custom";
}

const char* qualityBlurb(Quality q) {
    switch (q) {
    case Quality::Low:    return "For laptops and integrated graphics: no shadows or bloom, smaller 3D picture, thin grass.";
    case Quality::Medium: return "Balanced: soft shadows, bloom, medium grass and view distance.";
    case Quality::High:   return "The default look: sharp shadows, bloom, edge smoothing and full grass.";
    case Quality::Ultra:  return "For strong graphics cards: supersampled picture, long grass and view distance.";
    case Quality::Custom: return "Your own mix. Pick a preset to start over from one.";
    }
    return "";
}

GraphicsValues qualityPreset(Quality q) {
    GraphicsValues g;                       // defaults are High
    switch (q) {
    case Quality::Low:
        g.renderScale = 0.75f;
        g.shadows = false; g.shadowSize = 1024; g.shadowRange = 60.0f;
        g.bloom = false; g.fxaa = false;
        g.grassDensity = 0.30f; g.grassDistance = 35.0f;
        g.viewDistance = 3;
        g.textureSize = 512; g.ssao = false; g.treeDistance = 90.0f;
        break;
    case Quality::Medium:
        g.renderScale = 1.0f;
        g.shadows = true; g.shadowSize = 2048; g.shadowRange = 70.0f;
        g.bloom = true; g.fxaa = false;
        g.grassDensity = 0.60f; g.grassDistance = 50.0f;
        g.viewDistance = 4;
        g.textureSize = 1024; g.treeDistance = 140.0f;
        break;
    case Quality::High:
    case Quality::Custom:
        break;
    case Quality::Ultra:
        g.renderScale = 1.5f;
        g.grassDensity = 1.0f; g.grassDistance = 110.0f;
        g.viewDistance = 8;
        g.textureSize = 4096; g.treeDistance = 300.0f;
        break;
    }
    return g;
}

namespace {
bool near(float a, float b) { return std::fabs(a - b) < 0.005f; }
bool same(const GraphicsValues& a, const GraphicsValues& b) {
    return near(a.renderScale, b.renderScale) && a.shadows == b.shadows && a.shadowSize == b.shadowSize &&
           near(a.shadowRange, b.shadowRange) && a.bloom == b.bloom && a.fxaa == b.fxaa && a.grass == b.grass &&
           near(a.grassDensity, b.grassDensity) && near(a.grassDistance, b.grassDistance) && a.viewDistance == b.viewDistance &&
           a.textureSize == b.textureSize && a.ssao == b.ssao && a.trees == b.trees && near(a.treeDistance, b.treeDistance);
}
} // namespace

Quality detectQuality(const GraphicsValues& g) {
    for (Quality q : { Quality::Low, Quality::Medium, Quality::High, Quality::Ultra })
        if (same(g, qualityPreset(q))) return q;
    return Quality::Custom;
}

GraphicsValues readGraphics(const RenderSettings& rs, int viewDistance) {
    GraphicsValues g;
    g.renderScale = rs.renderScale;
    g.shadows = rs.shadows; g.shadowSize = rs.shadowSize; g.shadowRange = rs.shadowRange;
    g.bloom = rs.bloom; g.fxaa = rs.fxaa;
    g.grass = rs.grass; g.grassDensity = rs.grassDensity; g.grassDistance = rs.grassDistance;
    g.viewDistance = viewDistance;
    g.textureSize = rs.textureSize; g.ssao = rs.ssao; g.trees = rs.trees; g.treeDistance = rs.treeDistance;
    return g;
}

void writeGraphics(const GraphicsValues& in, RenderSettings& rs, int& viewDistance) {
    GraphicsValues g = in;
    clampGraphics(g);
    rs.renderScale = g.renderScale;
    rs.shadows = g.shadows; rs.shadowSize = g.shadowSize; rs.shadowRange = g.shadowRange;
    rs.bloom = g.bloom; rs.fxaa = g.fxaa;
    rs.grass = g.grass; rs.grassDensity = g.grassDensity; rs.grassDistance = g.grassDistance;
    viewDistance = g.viewDistance;
    rs.textureSize = g.textureSize; rs.ssao = g.ssao; rs.trees = g.trees; rs.treeDistance = g.treeDistance;
}

void clampGraphics(GraphicsValues& g) {
    g.renderScale   = std::clamp(g.renderScale, 0.5f, 2.0f);
    g.shadowSize    = g.shadowSize <= 1536 ? 1024 : g.shadowSize <= 3072 ? 2048 : 4096;     // only the three sizes
    g.shadowRange   = std::clamp(g.shadowRange, 40.0f, 200.0f);
    g.grassDensity  = std::clamp(g.grassDensity, 0.05f, 1.0f);
    g.grassDistance = std::clamp(g.grassDistance, 20.0f, 160.0f);
    g.viewDistance  = std::clamp(g.viewDistance, 2, 10);
    g.treeDistance  = std::clamp(g.treeDistance, 40.0f, 400.0f);
    g.textureSize   = g.textureSize <= 768 ? 512 : g.textureSize <= 1536 ? 1024 : g.textureSize <= 3072 ? 2048 : 4096;
}

float relativeCost(const GraphicsValues& g) {
    // Pixel work scales with the square of the render scale; shadows, bloom and grass add on top.
    const float pixels = g.renderScale * g.renderScale;
    float extra = 1.0f;
    if (g.shadows) extra += 0.30f * float(g.shadowSize) / 4096.0f + 0.10f;
    if (g.bloom)   extra += 0.12f;
    if (g.fxaa)    extra += 0.05f;
    if (g.ssao)    extra += 0.10f;
    if (g.grass)   extra += 0.25f * g.grassDensity * (g.grassDistance / 70.0f);
    if (g.trees)   extra += 0.2f * (g.treeDistance / 200.0f);
    const float reach = float(g.viewDistance * g.viewDistance) / 25.0f;                       // chunks drawn
    const float high = 1.0f + 0.40f + 0.12f + 0.05f + 0.10f + 0.25f + 0.20f;   // the High preset: costs are relative to it
    return (pixels * extra * (0.6f + 0.4f * reach)) / high;
}

} // namespace px
