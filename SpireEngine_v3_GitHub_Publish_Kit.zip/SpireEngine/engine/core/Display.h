#pragma once
// Monitors, resolutions and frame pacing for the display settings (roadmap #183).
#include <string>
#include <utility>
#include <vector>
#include <SDL3/SDL.h>

namespace px {

struct MonitorInfo {
    SDL_DisplayID id = 0;
    std::string name;
    int   width = 0, height = 0;      // the desktop resolution
    float refresh = 0.0f;
};

using Resolution = std::pair<int, int>;

std::vector<MonitorInfo> listMonitors();
// Resolutions the monitor can switch to in exclusive fullscreen: unique sizes, largest first.
std::vector<Resolution> fullscreenResolutions(SDL_DisplayID monitor);

// Window sizes worth offering on a monitor that is w x h: the common ones that fit, with room
// for a title bar. Always contains at least one entry.
std::vector<Resolution> windowSizesFor(int monitorW, int monitorH);

// The frame-rate limits in the Settings window (0 = unlimited).
const std::vector<int>& fpsCapChoices();

// Seconds still to wait so a frame lasts 1/fpsCap; 0 when there is no cap or the frame is already long enough.
double frameWaitSeconds(double elapsedSeconds, int fpsCap);

// The cap that is really used: the user's cap, lowered while the window is in the background or minimised.
int effectiveFpsCap(int userCap, bool reduceInBackground, bool focused, bool minimised);

} // namespace px
