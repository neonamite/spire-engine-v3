#include "core/Controls.h"
#include <SDL3/SDL_scancode.h>

namespace px {

namespace {
struct Info { const char* name; const char* label; int key; };
const Info kInfo[kActionCount] = {
    { "forward", "Move forward", SDL_SCANCODE_W },
    { "back", "Move back", SDL_SCANCODE_S },
    { "left", "Move left", SDL_SCANCODE_A },
    { "right", "Move right", SDL_SCANCODE_D },
    { "jump", "Jump", SDL_SCANCODE_SPACE },
    { "run", "Run", SDL_SCANCODE_LSHIFT },
    { "dive", "Dive (swimming)", SDL_SCANCODE_LCTRL },
    { "use", "Use / talk", SDL_SCANCODE_E },
    { "view", "First / third person", SDL_SCANCODE_V },
};
} // namespace

const char* actionName(Action a) { return size_t(a) < size_t(kActionCount) ? kInfo[size_t(a)].name : ""; }
const char* actionLabel(Action a) { return size_t(a) < size_t(kActionCount) ? kInfo[size_t(a)].label : ""; }

KeyBindings::KeyBindings() { for (int i = 0; i < kActionCount; ++i) key[size_t(i)] = kInfo[i].key; }

bool bindable(int sc) {
    if (sc <= SDL_SCANCODE_UNKNOWN || sc >= SDL_SCANCODE_COUNT) return false;
    return sc != SDL_SCANCODE_ESCAPE && sc != SDL_SCANCODE_TAB && sc != SDL_SCANCODE_F11 && sc != SDL_SCANCODE_F12;
}

bool rebind(KeyBindings& k, Action a, int sc, Action* swapped) {
    if (swapped) *swapped = Action::Count;
    if (size_t(a) >= size_t(kActionCount) || !bindable(sc)) return false;
    const int old = k.key[size_t(a)];
    for (int i = 0; i < kActionCount; ++i)
        if (Action(i) != a && k.key[size_t(i)] == sc) { k.key[size_t(i)] = old; if (swapped) *swapped = Action(i); }
    k.key[size_t(a)] = sc;
    return true;
}

std::vector<std::pair<Action, Action>> bindingConflicts(const KeyBindings& k) {
    std::vector<std::pair<Action, Action>> out;
    for (int i = 0; i < kActionCount; ++i)
        for (int j = i + 1; j < kActionCount; ++j)
            if (k.key[size_t(i)] == k.key[size_t(j)]) out.push_back({ Action(i), Action(j) });
    return out;
}

} // namespace px
