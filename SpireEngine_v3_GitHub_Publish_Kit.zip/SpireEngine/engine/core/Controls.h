#pragma once
// Controls (v0.24): which key does what while playing, so anyone can change them (Settings > Controls). Keys are SDL
// scancodes (the key's place on the keyboard, so WASD stays WASD on any layout). Changing one key to a key another
// action already uses swaps the two, so two actions never share a key. Pure, unit tested.
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace px {

enum class Action : std::uint8_t { Forward, Back, Left, Right, Jump, Run, Dive, Use, View, Count };   // append only (saved)
inline constexpr int kActionCount = int(Action::Count);
const char* actionName(Action a);        // "forward" (settings file: key_forward)
const char* actionLabel(Action a);       // "Move forward"

struct KeyBindings {
    std::array<int, kActionCount> key{};
    KeyBindings();                       // the usual: WASD, Space, Shift, Ctrl, E, V
    int operator[](Action a) const { return key[size_t(a)]; }
    bool operator==(const KeyBindings&) const = default;
};

// Bind `a` to `scancode`. If another action had that key it gets `a`'s old key instead (returned in *swapped, or
// Action::Count when nothing had to move). False (and no change) for keys that can't be bound: Escape and Tab
// (the menu and the editor), F11 / F12, or no key.
bool rebind(KeyBindings& k, Action a, int scancode, Action* swapped = nullptr);
bool bindable(int scancode);
std::vector<std::pair<Action, Action>> bindingConflicts(const KeyBindings& k);   // pairs sharing a key (none after rebind)

} // namespace px
