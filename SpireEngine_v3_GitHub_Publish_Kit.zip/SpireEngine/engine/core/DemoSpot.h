#pragma once
// Where demos and self tests stand: ground that is level and dry, so pictures and shots come out the same
// whatever the world generator did with the seed.
#include <cmath>
#include <glm/glm.hpp>
#include "world/ChunkManager.h"

namespace px::demospot {

// The real surface under (x, z): what a ray from above reaches (it can differ from the generator's height under trees and rocks).
inline float groundHeight(const ChunkManager& world, float x, float z) {
    RayHit h;
    const float guess = world.terrain().surfaceHeight(x, z);
    if (world.raycast(glm::vec3(x, guess + 40.0f, z), glm::vec3(0, -1, 0), 120.0f, h)) return h.position.y;
    return guess;
}

// A calm patch of ground to stand on: level around you and level for forty metres ahead (towards -Z),
// so shots land where the picture says they will.
inline glm::vec3 calmSpot(const ChunkManager& world) {
    glm::vec3 best(0.0f, groundHeight(world, 0.0f, 0.0f), 0.0f);
    float bestScore = 1e9f;
    for (int ix = -6; ix <= 6; ++ix)
        for (int iz = -3; iz <= 3; ++iz) {
            const float x = float(ix) * 8.0f, z = float(iz) * 8.0f;
            const float c = groundHeight(world, x, z);
            if (world.settings().water && c < world.settings().waterLevel + 3.5f) continue;     // dry land, not the beach or the sea bed
            float score = std::fabs(c - world.terrain().surfaceHeight(x, z)) * 3.0f;
            for (int k = 0; k < 8; ++k) {
                const float a = float(k) * 0.785398f;
                score += std::fabs(groundHeight(world, x + std::cos(a) * 5.0f, z + std::sin(a) * 5.0f) - c);
            }
            for (float d : { 10.0f, 20.0f, 30.0f, 40.0f }) score += std::fabs(groundHeight(world, x, z - d) - c) * 0.7f;
            if (score < bestScore) { bestScore = score; best = glm::vec3(x, c, z); }
        }
    return best;
}

} // namespace px::demospot
