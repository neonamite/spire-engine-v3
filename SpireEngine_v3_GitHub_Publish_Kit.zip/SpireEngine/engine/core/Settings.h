#pragma once
// Settings that belong to the person and the machine, not to a world or a game. They are
// saved in config/settings.cfg whenever they change (core/SettingsFile.cpp) and loaded at start-up.
#include <string>
#include "core/Controls.h"

namespace px {

enum class WindowMode { Windowed, Borderless, Fullscreen };    // Borderless = fullscreen at the desktop's resolution

struct DisplaySettings {
    WindowMode mode            = WindowMode::Windowed;
    int   monitor              = 0;          // index in the system's display list
    int   width = 1600, height = 900;        // size of the window when windowed (remembered as you resize it)
    int   fullscreenWidth = 0, fullscreenHeight = 0;   // resolution for exclusive Fullscreen; 0 = the desktop's
    int   fpsCap               = 0;          // 0 = unlimited
    bool  reduceInBackground   = true;       // drop to 30 FPS while the window is not in front
    float uiScale              = 1.0f;       // 0.75 .. 2.0, on top of the system's own DPI scale
};

struct UserSettings {
    float mouseSensitivity = 0.12f;
    bool  invertY          = false;
    float fov              = 70.0f;
    bool  vsync            = true;
    DisplaySettings display;
    // ---- audio (0..1 sliders; ambience has its own so wind can be quiet while effects stay loud)
    float volMaster        = 0.8f;
    float volSfx           = 1.0f;
    float volAmbient       = 0.8f;
    float volMusic         = 0.7f;
    float volUi            = 0.8f;
    bool  muteAudio        = false;
    bool  muteUnfocused    = true;
    bool  ambienceInEditor = true;
    // ---- safety
    float autosaveMinutes  = 3.0f;    // 0 = off
    std::string texturePack;          // folder name under textures/ whose pictures replace the built-in materials; empty = built-in
    // ---- controls and accessibility (v0.24)
    KeyBindings keys;
    bool  toggleRun        = false;   // tap Run to start and stop running, instead of holding it
    bool  colourBlind      = false;   // colours that work with red-green colour blindness
    bool  bigHud           = false;   // a bigger crosshair, prompts and messages
    bool  reduceMotion     = false;   // no screen shake, no camera glides
    bool  captions         = false;   // words on screen for game sounds
    bool  tutorialDone     = false;   // the first-run tutorial has been seen
};

} // namespace px
