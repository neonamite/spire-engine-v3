// Items in play mode: the hotbar, the item in the hand, what a shot does to the real world, and the HUD.
// The item rules themselves are in items/ItemSystem.cpp; this file connects them to the application.
#include "core/Application.h"
#include <algorithm>
#include <cstdio>
#include "editor/Panels.h"
#include "ui/UiKit.h"

namespace px {

using namespace ui;

namespace {

// What items need from the real world: terrain and objects to hit, craters to dig, a player to shove.
class PlayItemWorld : public ItemWorld {
public:
    explicit PlayItemWorld(Application& a) : app(a) {}

    bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDistance, ItemRayHit& hit) override {
        RayHit th;
        const bool terrain = app.world.raycast(origin, dir, maxDistance, th);
        Scene::Hit oh;
        const bool object = app.scene.raycast(origin, dir, terrain ? th.distance : maxDistance, oh, true);
        if (object) {
            hit.point = oh.point; hit.normal = oh.normal; hit.distance = oh.distance; hit.object = oh.id; hit.target = -1;
            hit.material = MAT_STONE;
            if (const Evaluated* e = app.scene.evaluatedFor(oh.id))
                if (e->asset) hit.material = e->asset->materialNear(glm::vec3(e->inverse * glm::vec4(oh.point, 1.0f)));
            if (hit.material == MAT_NATURAL) hit.material = MAT_STONE;
            return true;
        }
        if (terrain) {
            hit.point = th.position; hit.normal = th.normal; hit.distance = th.distance; hit.object = 0; hit.target = -1;
            hit.material = app.world.surfaceMaterialAt(th.position + th.normal * 0.2f);
            if (hit.material == MAT_NATURAL) hit.material = MAT_STONE;
            return true;
        }
        return false;
    }

    void crater(const glm::vec3& centre, float radius, bool build, MaterialId material) override {
        app.world.applySphere(centre, radius, build ? CsgMode::Union : CsgMode::Subtract, material);
    }

    void blast(const glm::vec3& centre, float radius, float push) override {
        const glm::vec3 body = app.player.position + glm::vec3(0.0f, app.player.height * 0.5f, 0.0f);
        glm::vec3 d = body - centre;
        const float dist = glm::length(d);
        const float reach = radius * 2.5f + 1.0f;
        if (dist >= reach) return;
        d = dist > 1e-3f ? d / dist : glm::vec3(0, 1, 0);
        const glm::vec3 dir = glm::normalize(d + glm::vec3(0.0f, 0.35f, 0.0f));
        const float fall = 1.0f - dist / reach;
        app.player.addImpulse(dir * push * fall * fall * 1.6f);
    }

    void sound(const std::string& clip, const glm::vec3& at, float volume, float pitch) override { app.playSfxAt(clip, at, volume, pitch); }
    void hit(const ItemHit& h) override { app.itemHit(h); }

private:
    Application& app;
};

} // namespace

// ------------------------------------------------------------------ setup

void Application::registerItems() {
    registerBuiltinItems(itemLibrary, assets);
    itemLibrary.loadDirectory(assets.directory);
    inventory.library = &itemLibrary;
    inventory.assets = &assets;
}

bool Application::itemNameProblem(const std::string& name, std::string* why) const {
    auto fail = [&](const char* m) { if (why) *why = m; return true; };
    if (name.empty()) return fail("Give it a name first");
    const ItemDef* d = itemLibrary.find(name);
    if (d && !d->userMade) return fail("A built-in item already has that name. Pick another.");
    return false;
}

void Application::prepareHotbar() {
    // The hotbar is every item you have: yours first (the one you just made at the very front), then the built-in kit.
    std::vector<std::string> want = itemLibrary.names();
    if (!preferredItem.empty()) {
        auto it = std::find(want.begin(), want.end(), preferredItem);
        if (it != want.end()) std::rotate(want.begin(), it, it + 1);
    }
    if (int(want.size()) > ItemSystem::kMaxSlots) want.resize(ItemSystem::kMaxSlots);

    std::vector<std::string> have;
    for (const ItemSystem::Slot& s : inventory.slots) have.push_back(s.item);
    std::string keep;
    if (const ItemDef* d = inventory.currentDef()) keep = d->name;

    if (want != have) {
        int pick = 0;
        const std::string& wanted = !preferredItem.empty() ? preferredItem : keep;
        for (int i = 0; i < int(want.size()); ++i) if (want[i] == wanted) pick = i;
        inventory.setHotbar(want, pick);
    } else if (!preferredItem.empty()) {
        for (int i = 0; i < int(want.size()); ++i) if (want[i] == preferredItem) { inventory.select(i); inventory.give(preferredItem, true); }
    }
    preferredItem.clear();
    inventory.reset();
}

void Application::startPlayingWith(const std::string& item) {
    if (ws.active) leaveWorkshop();
    inventory.enabled = true;
    preferredItem = item;
    if (mode == Mode::Play) prepareHotbar();
    else setMode(Mode::Play);
}

// ------------------------------------------------------------------ input

bool Application::itemEvent(const SDL_Event& e) {
    if (!inventory.enabled) return false;
    switch (e.type) {
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (e.button.button == SDL_BUTTON_LEFT)  { inventory.pressTrigger(0); return true; }
        if (e.button.button == SDL_BUTTON_RIGHT) { inventory.pressTrigger(1); return true; }
        break;
    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (e.button.button == SDL_BUTTON_LEFT)  { inventory.releaseTrigger(0); return true; }
        if (e.button.button == SDL_BUTTON_RIGHT) { inventory.releaseTrigger(1); return true; }
        break;
    case SDL_EVENT_KEY_DOWN:
        if (e.key.repeat) break;
        if (e.key.key >= SDLK_1 && e.key.key <= SDLK_9) {
            const int slot = int(e.key.key - SDLK_1);
            if (slot < int(inventory.slots.size()) && slot != inventory.current) { inventory.select(slot); playUiSound("ui_click", 0.25f, 1.7f); }
            return true;
        }
        if (e.key.key == SDLK_R) { inventory.reload(); return true; }
        break;
    case SDL_EVENT_MOUSE_WHEEL:
        if (e.wheel.y != 0.0f && inventory.slots.size() > 1) { inventory.cycle(e.wheel.y > 0.0f ? -1 : 1); playUiSound("ui_click", 0.25f, 1.7f); return true; }
        break;
    default: break;
    }
    return false;
}

// ------------------------------------------------------------------ per frame

ItemView Application::itemView() const {
    return ItemView::fromAngles(camera.position, camera.yaw, camera.pitch, player.grounded ? glm::length(glm::vec2(player.velocity.x, player.velocity.z)) : 0.0f);
}

void Application::stepItems(float dt) {
    PlayItemWorld w(*this);
    inventory.update(dt, w, itemView());
    camera.pitch = glm::clamp(camera.pitch + inventory.takeViewKick(), -89.0f, 89.0f);
}

void Application::updateItems(float dt) {
    if (!inventory.enabled) return;
    if (!paused && !itemsFrozen) stepItems(dt);
    const ItemView view = itemView();
    ObjectDraw d;
    if (!thirdPerson && inventory.heldDraw(view, d)) renderer.addObject(std::move(d));     // in third person it is in your hand instead
}

void Application::itemHit(const ItemHit& h) {
    if (game) game->onItemHit(*this, h);
    if (onItemHit) onItemHit(h);
}

// ------------------------------------------------------------------ HUD

// The crosshair: opens up with the weapon's spread, flashes on a hit.
void drawItemCrosshair(ImDrawList* dl, const ItemSystem& inv, ImVec2 centre, float viewHeight, float s) {
    {
        const ImVec2 c = centre;
        const ItemDef* def = inv.currentDef();
        const float spread = def ? inv.crosshairSpread() : 0.0f;
        const float pixelsPerDegree = viewHeight / 70.0f;
        const float g = (4.0f * s) + spread * pixelsPerDegree, l = 7.0f * s;
        for (int pass = 0; pass < 2; ++pass) {
            const ImU32 colr = pass == 0 ? IM_COL32(0, 0, 0, 120) : IM_COL32(255, 255, 255, 225);
            const float th = pass == 0 ? 3.5f * s : 1.6f * s;
            dl->AddLine(ImVec2(c.x - g - l, c.y), ImVec2(c.x - g, c.y), colr, th);
            dl->AddLine(ImVec2(c.x + g, c.y), ImVec2(c.x + g + l, c.y), colr, th);
            dl->AddLine(ImVec2(c.x, c.y - g - l), ImVec2(c.x, c.y - g), colr, th);
            dl->AddLine(ImVec2(c.x, c.y + g), ImVec2(c.x, c.y + g + l), colr, th);
        }
        dl->AddCircleFilled(c, 1.6f * s, IM_COL32(255, 255, 255, 230));
        if (inv.hitmarker() > 0.0f) {
            const float a = inv.hitmarker();
            const float in = 7.0f * s, out = 15.0f * s;
            const ImU32 colr = IM_COL32(255, 90, 80, int(230 * a));
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sy = -1; sy <= 1; sy += 2)
                    dl->AddLine(ImVec2(c.x + sx * in, c.y + sy * in), ImVec2(c.x + sx * out, c.y + sy * out), colr, 2.4f * s);
        }
    }
}

// The item in the hand: its name, the ammo in the magazine, the reload bar.
void drawItemPanel(ImDrawList* dl, const ItemSystem& inv, ImVec2 topLeft, float s) {
    const ItemDef* def = inv.currentDef();
    if (def) {
        const float w = 250.0f * s;
        const ImVec2 p = topLeft;
        dl->AddRectFilled(p, ImVec2(p.x + w, p.y + 82.0f * s), IM_COL32(11, 12, 16, 205), 11.0f * s);
        pushFont(fonts.bold);
        dl->AddText(ImVec2(p.x + 14.0f * s, p.y + 9.0f * s), col::text, def->name.c_str());
        popFont();
        pushFont(fonts.small);
        dl->AddText(ImVec2(p.x + 14.0f * s, p.y + 31.0f * s), col::textDim, behaviourName(def->behaviour));
        popFont();

        const bool usesAmmo = def->stats.magazine > 0 && def->behaviour != Behaviour::Melee && def->behaviour != Behaviour::Tool;
        if (usesAmmo) {
            char t[16]; std::snprintf(t, sizeof t, "%d", inv.ammo());
            pushFont(fonts.display);
            const ImVec2 ts = ImGui::CalcTextSize(t);
            dl->AddText(ImVec2(p.x + w - ts.x - 66.0f * s, p.y + 18.0f * s), inv.ammo() == 0 ? col::danger : col::text, t);
            popFont();
            char m[16]; std::snprintf(m, sizeof m, "/ %d", def->stats.magazine);
            pushFont(fonts.body);
            dl->AddText(ImVec2(p.x + w - 58.0f * s, p.y + 40.0f * s), col::textDim, m);
            popFont();
        } else if (def->behaviour == Behaviour::Tool) {
            pushFont(fonts.small);
            dl->AddText(ImVec2(p.x + 14.0f * s, p.y + 47.0f * s), col::textDim, def->effect.kind == WorldEffect::Carve ? "Left: dig   Right: build" : "Left: build   Right: dig");
            popFont();
        }
        const float barY = p.y + 66.0f * s;
        dl->AddRectFilled(ImVec2(p.x + 14.0f * s, barY), ImVec2(p.x + w - 14.0f * s, barY + 4.0f * s), IM_COL32(50, 55, 68, 255), 2.0f * s);
        if (inv.reloading()) {
            dl->AddRectFilled(ImVec2(p.x + 14.0f * s, barY), ImVec2(p.x + 14.0f * s + (w - 28.0f * s) * inv.reloadProgress(), barY + 4.0f * s), col::warning, 2.0f * s);
            pushFont(fonts.small);
            dl->AddText(ImVec2(p.x + 14.0f * s, p.y + 47.0f * s), col::warning, "Reloading");
            popFont();
        } else if (usesAmmo && inv.ammo() == 0) {
            pushFont(fonts.small);
            dl->AddText(ImVec2(p.x + 14.0f * s, p.y + 47.0f * s), col::danger, "Press R to reload");
            popFont();
        }
    }
}

void Application::drawItemHUD() {
    const float s = scale();
    const ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const ItemView view = itemView();

    inventory.drawFx(dl, viewProj, view, 0.0f, 0.0f, ds.x, ds.y, s);
    if (paused) return;

    drawItemCrosshair(dl, inventory, ImVec2(ds.x * 0.5f, ds.y * 0.5f), ds.y, s);

    // ---- hotbar
    const int n = int(inventory.slots.size());
    if (n > 0) {
        const float cell = 60.0f * s, gap = 8.0f * s;
        const float total = float(n) * cell + float(n - 1) * gap;
        float x = ds.x * 0.5f - total * 0.5f;
        const float y = ds.y - cell - 26.0f * s;
        for (int i = 0; i < n; ++i, x += cell + gap) {
            const bool sel = i == inventory.current;
            const float lift = sel ? 8.0f * s : 0.0f;
            const ImVec2 a(x, y - lift), b(x + cell, y + cell - lift);
            dl->AddRectFilled(a, b, IM_COL32(11, 12, 16, sel ? 235 : 190), 9.0f * s);
            dl->AddRect(a, b, sel ? col::accent : IM_COL32(70, 76, 92, 200), 9.0f * s, 0, sel ? 2.4f * s : 1.0f * s);
            if (const ItemDef* d = inventory.defAt(i)) {
                if (const unsigned tex = assetThumbnailTexture(*this, d->asset)) {
                    const float pad = 5.0f * s;
                    dl->AddImage(ImTextureRef(ImTextureID(std::uintptr_t(tex))), ImVec2(a.x + pad, a.y + pad), ImVec2(b.x - pad, b.y - pad));
                } else {
                    pushFont(fonts.bold);
                    dl->AddText(ImVec2(a.x + 8 * s, a.y + 18 * s), col::textDim, d->name.substr(0, 2).c_str());
                    popFont();
                }
            }
            pushFont(fonts.small);
            char num[12]; std::snprintf(num, sizeof num, "%d", i + 1);
            dl->AddText(ImVec2(a.x + 6.0f * s, a.y + 3.0f * s), sel ? col::text : col::textDim, num);
            popFont();
        }
    }

    drawItemPanel(dl, inventory, ImVec2(ds.x - 250.0f * s - 28.0f * s, ds.y - 108.0f * s), s);
}

} // namespace px
