// Transitions into the experimental spherical voxel editor, separate from UI.
#include "core/Application.h"
#include "world/PlanetCreatorModel.h"
#include <algorithm>
#include <filesystem>
#include <stdexcept>
#include <string>
#include <system_error>

namespace px {

std::string Application::planetSavePath() const {
    // Old --demo planet sessions have the existing legacy prototype pathname;
    // newly created planets live under worlds/sandbox/planets/<unique>.vxplanet.
    return activePlanetSavePath.empty() ? worldFolder() + "/local-planet.vxplanet" : activePlanetSavePath;
}

void Application::requestOpenPlanet(const std::string& path) {
    pendingPlanetOpenPath = path;
    // Leaving an open project can discard unsaved edits. Ask in the editor;
    // opening from the hub needs no destructive confirmation.
    if (mode == Mode::Editor) planetOpenConfirmVisible = true;
    else planetOpenRequested = true;
}

void Application::positionPlanetCamera(const PlanetaryTerrainSettings& settings) {
    camera = Camera{};
    camera.position = planetCreatorCameraPosition(settings);
    camera.setUpVector(world.localUp(camera.position));
    camera.lookAt(glm::vec3(0.0f, static_cast<float>(settings.planet.radiusMeters), 0.0f));
    timeOfDay = 13.0f;
    timeFlowing = false;
    renderSettings.water = false;
    uiHidden = false;
    cursorHitValid = false;
    world.planetLoadRadius = 2;
    setMode(Mode::Editor);
}

void Application::applyPlanetRequests() {
    if (!planetCreateRequested && !planetOpenRequested) return;
    const bool create = planetCreateRequested;
    planetCreateRequested = false;
    planetOpenRequested = false;
    PlanetaryTerrainSettings settings = pendingPlanetCreation;
    const std::string loadPath = std::move(pendingPlanetOpenPath);
    pendingPlanetOpenPath.clear();

    if (create) {
        if (const auto error = planetCreatorValidation(settings); !error.empty()) {
            toast("Planet creation rejected: " + error, Toast::Kind::Warning);
            return;
        }
        const std::filesystem::path directory = "worlds/sandbox/planets";
        std::error_code ec;
        std::filesystem::create_directories(directory, ec);
        if (ec) {
            toast("Cannot create the planet save directory", Toast::Kind::Warning);
            return;
        }
        const auto filename = nextPlanetSavePath(directory, settings.planet.name);
        if (filename.empty()) {
            toast("Cannot choose a safe planet filename", Toast::Kind::Warning);
            return;
        }
        settings.planet.id = filename.stem().string(); // unique even with duplicate display names
        try {
            if (mode != Mode::Editor || gameInfo != nullptr) {
                suppressTutorialOnce = true;
                openGame(nullptr);
            }
            // Planet creation never writes the legacy world.vxworld file.
            clearSceneState();
            world.startPlanetaryPrototype(settings);
            activePlanetSavePath = filename.string();
            autosave.endSession(); // don't autosave a planet via flat-world VXW serialization
            positionPlanetCamera(settings);
            if (world.savePlanetPrototype(activePlanetSavePath))
                toast("Planet created: " + settings.planet.name + " (Ctrl+S saves .vxplanet)", Toast::Kind::Success);
            else
                toast("Planet created, but initial .vxplanet save failed; use Ctrl+S", Toast::Kind::Warning);
        } catch (const std::exception& e) {
            toast(std::string("Planet creation failed: ") + e.what(), Toast::Kind::Warning);
        }
        return;
    }

    // A saved planet must be a normal .vxplanet file inside this project's
    // planet directory. No arbitrary file paths from UI can be loaded here.
    std::error_code ec;
    const auto canon = std::filesystem::weakly_canonical(loadPath, ec);
    if (ec || canon.extension() != ".vxplanet") {
        toast("Invalid planet file", Toast::Kind::Warning);
        return;
    }
    const auto parent = std::filesystem::weakly_canonical("worlds/sandbox/planets", ec);
    if (ec || canon.parent_path() != parent || !std::filesystem::is_regular_file(canon, ec)) {
        toast("Planet file must be in worlds/sandbox/planets", Toast::Kind::Warning);
        return;
    }
    try {
        if (mode != Mode::Editor || gameInfo != nullptr) {
                suppressTutorialOnce = true;
                openGame(nullptr);
            }
        if (world.loadPlanetPrototype(canon.string())) {
            // syncSceneFromWorld reads the just-loaded scene blob. Calling
            // clearSceneState here would erase that blob and lose placed props.
            syncSceneFromWorld();
            activePlanetSavePath = canon.string();
            autosave.endSession();
            // Use the planet settings just loaded, not old dialog defaults.
            if (const auto* loaded = world.currentPlanetSettings()) positionPlanetCamera(*loaded);
            toast("Planet opened: " + canon.stem().string(), Toast::Kind::Success);
        } else {
            toast("Planet load failed; active editor world was not replaced by invalid VXPL data", Toast::Kind::Warning);
        }
    } catch (const std::exception& e) {
        toast(std::string("Planet open failed: ") + e.what(), Toast::Kind::Warning);
    }
}

} // namespace px
