// --demo item...: screenshots of held items in play mode, and a self test that drives the real input paths
// (keys, mouse buttons, the item system's own frame step) against the real world.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "editor/ItemRange.h"
#include <cstdio>
#include <filesystem>
#include <iostream>

namespace px {

namespace {

SDL_Event mouseButton(bool down, Uint8 button) {
    SDL_Event e{};
    e.type = down ? SDL_EVENT_MOUSE_BUTTON_DOWN : SDL_EVENT_MOUSE_BUTTON_UP;
    e.button.button = button;
    return e;
}
SDL_Event keyDown(SDL_Keycode k) {
    SDL_Event e{};
    e.type = SDL_EVENT_KEY_DOWN;
    e.key.key = k;
    return e;
}

} // namespace

void Application::setupItemDemo() {
    if (demo == "itemselftest") { runItemSelfTest(); return; }

    // The demo name says what is in the hand and what is going on.
    struct Setup { const char* demo; const char* item; const char* action; };
    static const Setup table[] = {
        { "itempistol",  "Pistol",          "idle"  }, { "itemfire",   "Pistol",          "fire"  },
        { "itemrifle",   "Rifle",           "idle"  }, { "itemsword",  "Sword",           "idle"  },
        { "itemswing",   "Sword",           "swing" }, { "itemrocket", "Rocket Launcher", "idle"  },
        { "itemblast",   "Rocket Launcher", "blast" }, { "itemgrenade", "Grenade",        "idle"  },
        { "itemtool",    "Terraformer",     "idle"  }, { "itemdig",    "Terraformer",     "dig"   },
        { "itemreload",  "Pistol",          "reload" },
    };
    const Setup* s = nullptr;
    for (const Setup& t : table) if (demo == t.demo) s = &t;
    if (!s) return;

    // Stand on the ground looking across it.
    const glm::vec3 spot = demospot::calmSpot(world);
    {   // a worn dirt track to shoot across, so the grass does not hide the picture
        const glm::vec3 ahead(std::cos(glm::radians(-78.0f)), 0.0f, std::sin(glm::radians(-78.0f)));
        for (float d : { 0.0f, 14.0f, 28.0f, 42.0f }) world.paint(spot + ahead * d, 13.0f, MAT_SAND);
    }
    camera.position = spot + glm::vec3(0.0f, player.eyeHeight + 0.1f, 0.0f);
    camera.yaw = -78.0f; camera.pitch = -4.0f;
    timeOfDay = 11.0f; timeFlowing = false;
    inventory.enabled = true;
    startPlayingWith(s->item);
    player.position = camera.position - glm::vec3(0.0f, player.eyeHeight, 0.0f);
    player.velocity = glm::vec3(0.0f);
    toasts.clear();

    auto step = [&](float seconds) { for (float t = 0.0f; t < seconds; t += 1.0f / 60.0f) stepItems(1.0f / 60.0f); };
    step(0.6f);                                            // the item has been raised
    const std::string a = s->action;
    if (a == "fire") {
        inventory.pressTrigger(0);
        int guard = 0;
        while (inventory.totals.shots == 0 && guard++ < 60) stepItems(1.0f / 60.0f);
        inventory.releaseTrigger(0);
        step(0.03f);
        itemsFrozen = true;
    } else if (a == "swing") {
        inventory.pressTrigger(0); step(0.02f); inventory.releaseTrigger(0);
        step(0.17f);
        itemsFrozen = true;
    } else if (a == "blast") {
        camera.pitch = -7.0f;
        inventory.pressTrigger(0); step(0.02f); inventory.releaseTrigger(0);
        int guard = 0;
        while (inventory.totals.explosions == 0 && guard++ < 400) stepItems(1.0f / 60.0f);
        step(0.12f);
        itemsFrozen = true;
    } else if (a == "dig") {
        camera.pitch = -14.0f;
        inventory.pressTrigger(0); step(0.2f); inventory.releaseTrigger(0);
        step(0.06f);
        itemsFrozen = true;
    } else if (a == "reload") {
        for (int i = 0; i < 8; ++i) { inventory.pressTrigger(0); step(0.02f); inventory.releaseTrigger(0); step(0.22f); }
        inventory.reload(); step(0.6f);                    // a few rounds gone, the magazine halfway back in
        itemsFrozen = true;
    }
}

// ---------------------------------------------------------------- self test

void Application::runItemSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[itemtest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    namespace fs = std::filesystem;

    setMode(Mode::Editor);
    const std::string savedDir = assets.directory;
    const fs::path tmp = fs::temp_directory_path() / "pxitem_selftest";
    std::error_code ec;
    fs::remove_all(tmp, ec);
    assets.directory = tmp.string();

    const glm::vec3 spot = demospot::calmSpot(world);
    auto stand = [&](float yaw, float pitch) {
        camera.position = spot + glm::vec3(0.0f, player.eyeHeight + 0.1f, 0.0f);
        camera.yaw = yaw; camera.pitch = pitch;
        player.position = camera.position - glm::vec3(0.0f, player.eyeHeight, 0.0f);
        player.velocity = glm::vec3(0.0f);
    };
    auto step = [&](float seconds) { for (float t = 0.0f; t < seconds; t += 1.0f / 60.0f) stepItems(1.0f / 60.0f); };
    auto send = [&](SDL_Event e) { itemEvent(e); };
    auto fireMain = [&](float hold = 0.05f) { send(mouseButton(true, SDL_BUTTON_LEFT)); step(hold); send(mouseButton(false, SDL_BUTTON_LEFT)); };
    auto selectItem = [&](const std::string& name) {
        for (int i = 0; i < int(inventory.slots.size()); ++i) if (inventory.slots[i].item == name) { inventory.select(i); break; }
        step(0.6f);
    };
    std::vector<ItemHit> hits;
    onItemHit = [&](const ItemHit& h) { hits.push_back(h); };

    // ---- starting
    stand(-90.0f, -8.0f);
    startPlayingWith("Rifle");
    check(mode == Mode::Play && inventory.enabled, "the sandbox starts play mode with items on");
    check(inventory.slots.size() == 6 && inventory.current == 0 && inventory.currentDef() && inventory.currentDef()->name == "Rifle", "the hotbar holds the whole kit, the one asked for first");
    stand(-90.0f, -8.0f);
    step(0.6f);
    send(keyDown(SDLK_2));
    check(inventory.current == 1, "key 2 picks the second item");
    SDL_Event wheel{}; wheel.type = SDL_EVENT_MOUSE_WHEEL; wheel.wheel.y = -1.0f;
    send(wheel);
    check(inventory.current == 2, "the wheel moves along the hotbar");
    send(keyDown(SDLK_9));
    check(inventory.current == 2, "a key past the last slot does nothing");

    // ---- a pistol shot digs the terrain where you aim
    selectItem("Pistol");
    RayHit aim;
    check(world.raycast(camera.position, camera.front(), 200.0f, aim), "there is ground to aim at");
    {
        const size_t edits = world.editCount();
        const float before = world.density(aim.position);
        hits.clear();
        fireMain();
        check(world.editCount() == edits + 1, "a shot is one edit in the world");
        check(world.density(aim.position) > before + 0.05f, "...that takes material away where it landed");
        check(hits.size() == 1 && hits[0].object == 0 && !hits[0].explosion && hits[0].damage == 22.0f, "the game hears about the hit");
        check(inventory.ammo() == 11, "a round was used");
    }

    // ---- an object is hit, and the terrain is left alone
    {
        // A spot straight ahead with a clear line to it (a tree or a rock in the way would take the shot).
        glm::vec3 where = spot + glm::vec3(0.0f, 0.0f, -9.0f);
        for (float d : { 9.0f, 7.0f, 11.0f, 5.0f, 13.0f }) {
            const glm::vec3 c(spot.x, demospot::groundHeight(world, spot.x, spot.z - d) + 2.5f, spot.z - d);
            RayHit block;
            const glm::vec3 eyePos = spot + glm::vec3(0.0f, player.eyeHeight + 0.1f, 0.0f);
            if (!world.raycast(eyePos, glm::normalize(c - eyePos), glm::length(c - eyePos) - 3.0f, block)) { where = glm::vec3(c.x, c.y - 2.5f, c.z); break; }
        }
        const ObjectId id = placeObject("crate", where, 0.0f, 1.0f);
        scene.evaluate(assets, 0.0, false);
        glm::vec3 mn, mx;
        check(id != 0 && scene.worldBounds(id, mn, mx), "a crate stands in the way");
        camera.lookAt((mn + mx) * 0.5f);
        step(0.4f);
        const size_t edits = world.editCount();
        hits.clear();
        fireMain();
        check(!hits.empty() && hits[0].object == id, "the shot hits the crate");
        check(world.editCount() == edits, "...and does not dig the ground behind it");
        cmdUndo();                                         // takes the crate away again
        scene.evaluate(assets, 0.0, false);
    }

    // ---- a sword reaches only so far
    {
        selectItem("Sword");
        const ObjectId near = placeObject("crate", spot + glm::vec3(0.0f, 0.0f, -1.9f), 0.0f, 1.0f);
        scene.evaluate(assets, 0.0, false);
        glm::vec3 mn, mx;
        scene.worldBounds(near, mn, mx);
        camera.lookAt((mn + mx) * 0.5f);
        hits.clear();
        fireMain(); step(0.8f);
        bool struck = false;
        for (const ItemHit& h : hits) struck |= h.melee && h.object == near;
        check(struck, "a swing hits a crate within reach");
        cmdUndo();
        scene.evaluate(assets, 0.0, false);
    }

    // ---- a rocket makes a crater, and shoves you if you are close
    {
        stand(-90.0f, -3.0f);
        selectItem("Rocket Launcher");
        const size_t edits = world.editCount();
        const int explosionsBefore = inventory.totals.explosions;
        hits.clear();
        fireMain();
        int guard = 0;
        while (inventory.totals.explosions == explosionsBefore && guard++ < 600) stepItems(1.0f / 60.0f);
        check(inventory.totals.explosions == explosionsBefore + 1, "the rocket goes off");
        check(world.editCount() == edits + 1, "...and digs a crater");
        bool blast = false;
        for (const ItemHit& h : hits) blast |= h.explosion && h.radius > 3.0f;
        check(blast, "the game is told how big it was");

        stand(-90.0f, -85.0f);                             // straight down at your own feet: a rocket jump
        step(3.0f);                                        // reloaded
        fireMain();
        guard = 0;
        const int e2 = inventory.totals.explosions;
        while (inventory.totals.explosions == e2 && guard++ < 600) stepItems(1.0f / 60.0f);
        check(player.velocity.y > 4.0f, "a blast at your feet throws you up");
    }

    // ---- a grenade goes off after its fuse
    {
        stand(-90.0f, -35.0f);                             // a lob, so it lands inside the part of the world that is built
        selectItem("Grenade");
        const size_t edits = world.editCount();
        const int e0 = inventory.totals.explosions;
        hits.clear();
        fireMain();
        step(1.6f);
        check(inventory.totals.explosions == e0 && inventory.projectiles().size() == 1, "a grenade is still bouncing before its fuse runs out");
        step(1.4f);
        check(inventory.totals.explosions == e0 + 1 && world.editCount() == edits + 1, "...and then goes off and digs");
    }

    // ---- the terraformer digs with one button and builds with the other
    {
        stand(-90.0f, -14.0f);
        selectItem("Terraformer");
        RayHit h;
        world.raycast(camera.position, camera.front(), 18.0f, h);
        const float d0 = world.density(h.position);
        fireMain(0.05f); step(0.3f);
        check(world.density(h.position) > d0 + 0.05f, "the main button digs");
        world.raycast(camera.position, camera.front(), 18.0f, h);
        const glm::vec3 above = h.position + h.normal * 0.8f;
        const float d1 = world.density(above);
        send(mouseButton(true, SDL_BUTTON_RIGHT)); step(0.05f); send(mouseButton(false, SDL_BUTTON_RIGHT)); step(0.3f);
        check(world.density(above) < d1 - 0.05f, "the second button builds up");
    }

    // ---- your own items come first, and a name can't take a built-in's
    {
        ItemDef mine = ItemDef::defaultsFor(Behaviour::Hitscan, "Selftest Blaster", "pistol");
        check(itemLibrary.save(mine, tmp.string()) && fs::exists(tmp / "Selftest_Blaster.pxitem"), "an item is written as a .pxitem file");
        startPlayingWith("Selftest Blaster");
        check(inventory.slots.size() == 7 && inventory.slots[0].item == "Selftest Blaster" && inventory.current == 0, "Try it puts the new item first in the hotbar");
        std::string why;
        check(itemNameProblem("Pistol", &why) && !why.empty(), "a built-in item's name can't be taken");
        check(itemNameProblem("", nullptr), "an empty name can't be used");
        check(!itemNameProblem("Selftest Blaster", nullptr), "your own item's name can be saved over");
        itemLibrary.deleteFile("Selftest Blaster", tmp.string());
    }

    // ---- pausing and leaving
    {
        selectItem("Pistol");
        send(mouseButton(true, SDL_BUTTON_LEFT));
        setPaused(true);
        const int shots = inventory.totals.shots;
        updateItems(0.5f);
        check(inventory.totals.shots == shots, "nothing fires while paused");
        setPaused(false);
        send(mouseButton(false, SDL_BUTTON_LEFT));
        setMode(Mode::Editor);
        check(inventory.projectiles().empty() && inventory.effects().empty(), "leaving play mode clears projectiles and effects");
    }


    // ---- the Item Builder in the Workshop
    {
        setMode(Mode::Editor);
        int sw = 1200, sh = 700;
        SDL_GetWindowSize(window, &sw, &sh);
        viewRect = { 58.0f, 30.0f, float(sw) - 58.0f - 330.0f, float(sh) - 30.0f - 28.0f };
        NewAssetSpec spec;
        spec.name = "Selftest Gun";
        spec.tmpl = WorkshopTemplate::Pistol;
        enterWorkshopWith(spec);
        check(ws.active && ws.model.asset.type == AssetType::Item, "a pistol template starts as an Item");
        workshopLoadItem();
        check(ws.item.behaviour == Behaviour::Hitscan && ws.item.name == "Selftest Gun" && ws.item.asset == "Selftest Gun", "its item starts as a hitscan gun with its name");

        ws.item.stats.damage = 61.0f;
        ws.itemEdited = true;
        check(workshopModified(), "changing the item counts as an unsaved change");
        check(workshopSave(), "saving works");
        check(fs::exists(tmp / "Selftest_Gun.pxasset") && fs::exists(tmp / "Selftest_Gun.pxitem"), "the model and the item are saved side by side");
        const ItemDef* saved = itemLibrary.find("Selftest Gun");
        check(saved && saved->userMade && saved->stats.damage == 61.0f && saved->asset == "Selftest Gun", "the item is in the library with the new numbers");
        check(!workshopModified(), "...and nothing is left unsaved");

        // the firing range, driven with the real events
        updateWorkshop(0.016f);
        workshopEnterRange();
        check(ws.rangeOn && ws.range && ws.panelTab == 1, "the firing range opens");
        auto step = [&](float seconds) { for (float t = 0.0f; t < seconds; t += 1.0f / 60.0f) updateWorkshop(1.0f / 60.0f); };
        step(0.6f);
        SDL_Event click{};
        click.type = SDL_EVENT_MOUSE_BUTTON_DOWN; click.button.button = SDL_BUTTON_LEFT; click.button.x = viewRect.x + viewRect.w * 0.5f; click.button.y = viewRect.y + viewRect.h * 0.5f;
        workshopHandleEvent(click);
        check(ws.rangeCaptured && ws.range->score().shots == 0, "the first click takes the mouse, it does not fire");
        const glm::vec3 eye = ws.range->eye();
        const glm::vec3 d = glm::vec3(2.2f, 1.45f, 8.0f) - eye;
        camera.yaw = glm::degrees(std::atan2(d.z, d.x));
        camera.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
        workshopHandleEvent(click);
        step(0.12f);
        SDL_Event up = click; up.type = SDL_EVENT_MOUSE_BUTTON_UP;
        workshopHandleEvent(up);
        step(0.3f);
        const ItemRange::Score sc = ws.range->score();
        check(sc.shots >= 1 && sc.hits >= 1 && sc.damage >= 61.0f, "a click in the range fires the draft and hits the plate");
        check(ws.range->targets()[0].health < ws.range->targets()[0].maxHealth, "the plate took the damage");
        ws.item.stats.damage = 5.0f;
        step(0.1f);
        check(ws.range->items.currentDef() && ws.range->items.currentDef()->stats.damage == 5.0f, "changing a number reaches the item in your hand at once");
        SDL_Event esc{};
        esc.type = SDL_EVENT_KEY_DOWN; esc.key.key = SDLK_ESCAPE;
        workshopHandleEvent(esc);
        check(ws.rangeOn && !ws.rangeCaptured, "Escape lets go of the mouse first");
        workshopHandleEvent(esc);
        check(!ws.rangeOn, "...and then leaves the range");
        ws.item.stats.damage = 61.0f;

        // saving under a new name keeps the old one
        ws.model.setName("Selftest Gun 2");
        workshopSave();
        check(itemLibrary.find("Selftest Gun 2") && itemLibrary.find("Selftest Gun") && fs::exists(tmp / "Selftest_Gun_2.pxitem"), "saving under a new name makes a second item");

        // no longer an item: its item file goes away
        ws.model.setType(AssetType::Prop);
        check(workshopSave() && !itemLibrary.find("Selftest Gun 2") && !fs::exists(tmp / "Selftest_Gun_2.pxitem"), "an asset that stops being an item loses its item file");
        ws.model.setType(AssetType::Item);
        std::string why;
        ws.model.setName("Pistol");
        check(workshopNameProblem(&why) && !why.empty(), "an item can't take a built-in item's name");

        // the built-in weapon, copied: keeps its fine detail and its numbers
        ws.model.setName("Selftest Gun 2");
        ws.model.markSaved();
        ws.itemEdited = false;
        workshopRunAfter("close");
        check(!ws.active, "the Workshop closes");
        editAssetInWorkshop("rocket_launcher");
        workshopLoadItem();
        check(ws.copyOfBuiltin && ws.model.asset.voxelSize < 0.02f, "a built-in weapon keeps its fine detail when copied");
        check(ws.item.behaviour == Behaviour::Projectile && ws.item.effect.radius == 3.5f && ws.item.name == "rocket_launcher (mine)", "...and its item numbers come along");
        check(workshopSave() && itemLibrary.find("rocket_launcher (mine)") && itemLibrary.find("Rocket Launcher"), "saving the copy leaves the built-in one alone");

        // straight to the world with it
        workshopTryInWorld();
        check(!ws.active && mode == Mode::Play && inventory.slots.size() > 0 && inventory.slots[0].item == "rocket_launcher (mine)", "Save and try it puts it first in your hand");
        setMode(Mode::Editor);
        itemLibrary.deleteFile("rocket_launcher (mine)", tmp.string());
        itemLibrary.remove("rocket_launcher (mine)");
        itemLibrary.deleteFile("Selftest Gun", tmp.string());
        itemLibrary.remove("Selftest Gun");
    }

    onItemHit = nullptr;
    fs::remove_all(tmp, ec);
    assets.directory = savedDir;
    std::cerr << "[itemtest] " << (fails ? "FAILED" : "ALL OK") << " (" << fails << " failures)\n";
}

} // namespace px
