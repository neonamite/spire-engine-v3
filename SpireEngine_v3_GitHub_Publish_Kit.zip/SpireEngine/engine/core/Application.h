#pragma once
// Spire Engine application: window, main loop, Project Hub, editor
// (Director mode) and play mode. Games plug in through px::Game (core/Game.h)
// and appear in the hub via PX_REGISTER_GAME (core/GameRegistry.h).
#include <algorithm>
#include <array>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <vector>
#include <SDL3/SDL.h>
#include <imgui.h>
#include "audio/Ambience.h"
#include "audio/AudioEngine.h"
#include "core/Autosave.h"
#include "core/Camera.h"
#include "core/Commands.h"
#include "core/Display.h"
#include "core/EditorState.h"
#include "core/Game.h"
#include "core/GameRegistry.h"
#include "core/Graphics.h"
#include "core/Settings.h"
#include "editor/Gizmo.h"
#include "editor/WorkshopSession.h"
#include "editor/BlueprintEditor.h"
#include "editor/CharacterStudio.h"
#include "character/Npc.h"
#include "rules/Rules.h"
#include "rules/GameRules.h"
#include "share/Share.h"
#include "core/Tutorial.h"
#include <unordered_map>
#include "items/BuiltinItems.h"
#include "items/Item.h"
#include "items/ItemSystem.h"
#include "physics/CharacterController.h"
#include "render/Renderer.h"
#include "scene/Asset.h"
#include "scene/BuildKit.h"
#include "scene/Scene.h"
#include "scene/Trees.h"
#include "world/ChunkManager.h"
#include "world/PlanetCreatorModel.h"
#include "world/PlanetSurfaceRuntime.h"
#include "world/PrefabLibrary.h"

namespace px {

namespace wsui { struct View; }

inline constexpr const char* kEngineVersion = "2.0 Preview C11";

enum class Mode { Hub, Editor, Play };     // Hub = launcher, Editor = Director / god view
enum class Tool { Carve, Build, Smooth, Flatten, Paint, Stamp, Bake, Select, Count };


// The panels of the editor. Each is a dockable window: drag its tab to rearrange, pull it out
// to float it, or reset the layout from View > Layout.
enum class Layout { Default, Stacked, TwoSides, Objects, Count };


struct Toast {
    std::string text;
    float       age = 0.0f;
    enum class Kind { Info, Success, Warning } kind = Kind::Info;
};

class Application {
public:
    // Starts in the Project Hub. "--game <id>" opens a game straight away.
    bool init(int argc = 0, char** argv = nullptr);
    void run();
    void shutdown();

    // ---- engine systems (games may use all of these) ----
    PrefabLibrary       prefabs;
    ChunkManager        world{ prefabs };
    Renderer            renderer;
    RenderSettings      renderSettings;
    TerrainSettings     pendingTerrain;      // edited in UI, applied on "Regenerate"
    Camera              camera;
    CharacterController player;
    AudioEngine         audio;               // sounds: audio.playAt("boom", pos), audio.play("wind", loop), ...
    Ambience            ambience;            // world beds + game-defined ambience.zones
    UserSettings        settings;
    int rebinding = -1;                          // Settings > Controls: waiting for a key for this action (v0.24)
    void startTutorial();                        // the first-run tutorial, from the start (Help > Tutorial)
    Game*               game = nullptr;        // currently open game (nullptr = empty sandbox / hub)
    const GameInfo*     gameInfo = nullptr;

    Mode  mode = Mode::Hub;
    bool  paused = false;                    // play-mode pause menu
    std::string status = "Ready";

    // ---- editor state ----
    Tool  tool = Tool::Carve;
    float brushRadius  = 3.0f;
    MaterialId brushMaterial = MAT_STONE;   // used by Build and Paint
    float smoothStrength = 0.5f;
    // WB3: manually authored road strips. Endpoints are picked by the camera ray.
    bool roadStartSelected = false;
    glm::vec3 roadStart{0.0f};
    float roadWidth = 5.0f;
    bool roadGrade = true;
    MaterialId roadMaterial = MAT_COBBLESTONE;
    bool captureRoadStart();
    bool finishRoad();

    float flySpeed     = 30.0f;
    std::string stampPrefab = "stone_pillar";
    char  bakeName[64] = "my_prefab";
    int   bakeRadius   = 6;
    // ---- day/night cycle
    float timeOfDay        = 10.0f;   // hours, 0..24
    bool  timeFlowing      = true;
    float dayLengthMinutes = 24.0f;   // real minutes for a full day
    float sunHeading       = 35.0f;   // compass direction of the sun's path, degrees
    float sunMaxElevation  = 62.0f;   // how high the sun gets at noon, degrees
    bool  showToolbar   = true;      // the tool rail
    bool  showToolPanel = true;      // Tool, World, Environment and the game's own panel
    bool  showWorldPanel = true;
    bool  showEnvPanel  = true;
    bool  showGamePanel = true;
    bool  showOutliner  = true;      // the objects in the world
    bool  showAssets    = true;      // the Asset Browser
    bool  showProperties = true;     // the selected object
    bool  showHints     = true;      // the Character Studio's key hints
    bool  showShortcutList = false;  // F1 in the editor: every shortcut (a few key hints always show)

    // ---- the 1.1 layout (editor/Shell.cpp): four modes, each with only its own tools and shelf
    enum class EditMode { Shape, Build, People, Logic };
    EditMode editMode = EditMode::Build;
    Tool lastShapeTool = Tool::Carve;
    void setEditMode(EditMode m);
    std::vector<std::string> recentAssets;          // newest first: the shelf's Recent row
    int  shelfFilter = 1;                           // ShelfFilter in Shell.cpp
    char shelfSearch[64] = {};
    bool shelfFocusSearch = false;
    bool openRulesFold = false;                     // the context bar's Rules button: open that drawer in Details
    struct QuickWheel { bool open = false; float x = 0, y = 0; int hover = -1; } wheel;    // hold Space
    void drawTopBar();
    void drawToolStrip();
    void drawStatusBar();
    void drawViewportControls();
    void drawContextBar();
    void drawQuickWheel();
    void quickWheelAction(int slot);
    void drawShelf();
    void drawToolDetails();
    void drawMainMenus();                           // File, Edit, Tools, View, Game, Help (the project menu)
    void showShelf(int filter, bool focusSearch);
    bool  uiHidden      = false;  // H: hide all editor chrome
    bool  openSettings  = false;
    bool  openAbout     = false;
    std::vector<Toast> toasts;

    // Inspector tabs: 0 Tool, 1 World, 2 Environment, then any tabs the game adds (3, 4, ...).
    static constexpr int kFirstGameTab = 3;
    int forceInspectorTab = -1;
    ImGuiTabItemFlags tabFlags(int index) const { return forceInspectorTab == index ? ImGuiTabItemFlags_SetSelected : 0; }

    // Brush preview, filled every frame in Editor mode
    bool      cursorHitValid = false;
    RayHit    cursorHit;
    glm::mat4 viewProj{ 1.0f };

    // ---- command palette (Ctrl+P): every action is a Command. Games add their own in onStart.
    CommandRegistry commands;
    bool paletteOpen = false;

    // ---- camera bookmarks: Ctrl+1..9 fly to one, Ctrl+Shift+1..9 save the current view
    std::array<CameraBookmark, EditorState::kBookmarks> bookmarks;
    CameraFly flyTo;
    void saveBookmark(int slot);                 // 0-based
    void gotoBookmark(int slot);

    // ---- where the 3D view is on screen (window points). The whole window except in the
    // editor, where it is the free space between the docked panels.
    struct ViewRect { float x = 0, y = 0, w = 1, h = 1; };
    ViewRect viewRect;

    // ---- objects: copies of assets placed in the world (scene/Scene.h). They are saved inside the world
    // file, have their own undo steps (shared with the terrain's, in the order things happened), and
    // are solid to the player.
    AssetLibrary assets{ prefabs };
    Scene        scene;
    std::vector<ObjectId> selection;            // the last one is the primary: the gizmo sits on it
    ObjectId     hoverObject = 0;               // under the mouse with the Select tool
    std::string  placingAsset;                  // not empty: clicking in the world places this asset
    float        placeYaw = 0.0f, placeScale = 1.0f;

    // ---- building kits (editor/KitTools.cpp): pieces that snap to a grid and build houses in a few clicks (scene/BuildKit.h)
    bool        showKits = true;                 // the Kits panel
    std::string kitStyle = "Brick house";        // the kit new pieces come from
    bool        kitSnapOn = true;                // kit pieces snap to the grid
    int         kitLevel = 0;                    // the storey new pieces go on when pointing at the ground
    float       kitBaseY = 0.0f;                 // the height the ground floor's slab starts at
    bool        kitBaseSet = false;              // false: it follows the ground under the cursor until the first piece is placed
    int         kitTurns = 0;                    // how many times Rotate was pressed
    ObjectId    kitGroup = 0;                    // the "Building" group new pieces go into (0: the next piece starts one)
    KitCatalog  kits;
    KitRole     kitRoleOfAsset(const std::string& asset, std::string* style = nullptr) const;     // None unless it is a kit piece
    KitRole     placingKitRole() const { return kitRoleOfAsset(placingAsset); }
    bool        placingKit() const { return kitSnapOn && placingKitRole() != KitRole::None; }
    void        startPlacingKit(KitRole role);           // the current kit's piece for that role
    void        kitRotate() { ++kitTurns; }
    void        kitLevelStep(int d) { kitLevel = std::clamp(kitLevel + d, -3, 12); }
    // The spot under the cursor for a piece of this role (snapped). `plane` and `onKit` say which storey it is on and whether
    // that came from pointing at an existing piece. `forcePlane` (when not null) pins the storey, as a drag does.
    bool        kitSpotUnderCursor(KitRole role, KitSpot& spot, float* plane = nullptr, ObjectId* hitObject = nullptr, const float* forcePlane = nullptr) const;
    std::vector<ObjectId> kitClash(KitRole role, const KitSpot& spot) const;                         // pieces already in that slot
    // Puts `asset` on the spot, replacing what was in the slot. False when the very same piece is already there. No undo step: commit afterwards.
    bool        kitPlaceAt(const std::string& asset, KitRole role, const KitSpot& spot);
    bool        kitRemoveUnderCursor();                                                              // removes the kit piece under the cursor (no undo step yet)
    int         restyleObjects(const std::vector<ObjectId>& ids, const std::string& style);        // swaps kit pieces to another kit; returns how many changed; one undo step
    std::vector<ObjectId> kitBuildingOf(ObjectId id) const;                                          // the pieces of the building an object belongs to

    // ---- the Blueprint Tool (editor/BlueprintTools.cpp): draw rooms on a floor plan and a whole building is made from a kit
    BlueprintEditor bp;
    void openBlueprintEditor();                                  // the Blueprint window (a ready-made plan the first time)
    void editBuildingBlueprint(ObjectId id);                     // the plan of the building `id` is part of, ready to change and rebuild
    ObjectId blueprintBuildingOf(ObjectId id) const;             // the Building group with a plan that `id` is in (0: none)
    void bpChange();                                             // call before changing bp.plan: one step of the plan's own undo
    void bpPushUndo(const Blueprint& before);
    void bpUndo();
    void bpRedo();
    void bpLoadPlan(const Blueprint& plan, const std::string& why);   // a whole new plan (undoable)
    void bpPaintRect(int level, glm::ivec2 a, glm::ivec2 b, int mode);   // mode 0: a new room, 1: add to bp.room, 2: erase (one undo step)
    void bpSetEdge(int level, int o, int x, int z, BpEdge e);   // no undo step of its own: strokes take one at the start
    void bpToggleStairs(int level, int x, int z, int dir);      // adds stairs there, or takes away the ones that are there
    void bpStartPlacing();                                       // the building follows the cursor; a click builds it
    void bpStopPlacing(bool reopen = true);
    bool bpSpotUnderCursor(glm::vec3& spot);                     // the footprint's corner on the grid and the ground height under it
    // Builds the plan with its corner at `spot`, as a Building group (or into `rebuild`, replacing its pieces). One undo step
    // (two when the ground is levelled first). Returns the group, 0 when there was nothing to build.
    ObjectId bpBuild(const Blueprint& plan, const glm::vec3& spot, int turns, ObjectId rebuild = 0, bool levelGround = true);
    bool bpRebuildTarget();                                      // puts the edited plan back where its building is

    // ---- characters (character/*, editor/CharacterStudio.cpp, editor/CharacterWorld.cpp)
    CharacterLibrary characters;                                 // the ready-made people and every .pxcharacter in characters/
    std::string playerCharacter = "Explorer";                    // what you look like in third person
    bool thirdPerson = false;                                    // play mode: V switches between your eyes and over the shoulder
    CharacterStudio cs;
    bool inCharacterStudio() const { return cs.active; }
    void openCharacterStudio(const std::string& name = "");      // a character to edit ("" = a new one from the first ready-made look)
    void requestLeaveCharacterStudio();                          // asks first when there are unsaved changes
    void leaveCharacterStudio();                                 // back to the editor, no questions
    bool studioSave();                                           // characters/<name>.pxcharacter; false when the name can't be used
    void studioChanged(const CharacterDef& before);              // one undo step for a change to cs.def
    void studioUndo();
    void studioRedo();
    void studioFrame();                                          // the camera fits the character
    std::string studioNameProblem() const;                       // why the name can't be saved under ("" = fine)
    void startPlacingCharacter(const std::string& name);         // a click puts the character in the world
    ObjectId placeCharacter(const std::string& name, const glm::vec3& at, float yawDegrees);   // one undo step
    std::string placingCharacter;                                // not empty while placing a character
    const CharacterDef* characterOf(ObjectId id) const;          // the character standing there (nullptr: not a character)
    void setPlayerCharacter(const std::string& name);
    CrowdTool crowd;
    std::vector<ObjectId> makeCrowd(CrowdStyle style, int count, const glm::vec3& centre, float radius, std::uint32_t firstSeed);   // one undo step
    glm::vec3 crowdCentre() const;                               // where a crowd goes: under the cursor, or in front of you
    void drawCrowdWindow();                                      // editor/CrowdTool.cpp
    int  lastCharacterDraws = 0;                                 // body parts drawn last frame (tests)
    GizmoMode    gizmoMode = GizmoMode::Move;
    GizmoSpace   gizmoSpace = GizmoSpace::World;
    GizmoSnap    gizmoSnap;
    bool         previewMotion = false;         // objects move as they will in play mode

    ObjectId primaryObject() const { return selection.empty() ? 0 : selection.back(); }
    bool isSelected(ObjectId id) const { return std::find(selection.begin(), selection.end(), id) != selection.end(); }
    void selectObject(ObjectId id, bool additive = false);     // id 0 clears; additive toggles it in the selection
    void setSelection(std::vector<ObjectId> ids);
    bool commitScene(const std::string& label);                // one undo step for what changed since the last one
    ObjectId placeObject(const std::string& asset, const glm::vec3& at, float yawDegrees = 0.0f, float scale = 1.0f);
    void startPlacing(const std::string& asset);
    void stopPlacing();
    void cmdDeleteSelection();
    void cmdDuplicateSelection();
    void cmdGroupSelection();
    void cmdUngroupSelection();
    void cmdFocusSelection();
    void cmdDropToGround();
    void cmdSelectAll();
    void cmdSetGizmoMode(GizmoMode m) { gizmoMode = m; if (tool != Tool::Select) tool = Tool::Select; }
    bool canUndo() const { return !undoLog.empty() || world.canUndo(); }
    bool canRedo() const { return !redoLog.empty(); }
    bool gizmoDragging() const { return gizmo.dragging(); }

    // ---- the Asset Workshop (editor/WorkshopUI.cpp): a full-window screen for building one asset out of
    // fine voxels. It opens over the editor and hands back to it; the world is left exactly as it was.
    WorkshopSession ws;
    bool inWorkshop() const { return ws.active; }
    void enterWorkshopNew();                                  // opens the Workshop with the New Asset dialog
    void enterWorkshopWith(const NewAssetSpec& spec);         // straight into a fresh asset
    void editAssetInWorkshop(const std::string& name);        // your own asset: edit it; a built-in one: edit a copy
    void requestLeaveWorkshop();                              // asks first when there is unsaved work
    void leaveWorkshop();                                     // back to the editor, no questions asked
    bool workshopSave();                                      // writes assets/<name>.pxasset; false when the name can't be used
    void workshopSaveAndPlace();                              // save, close, and start placing it in the world
    bool workshopNameProblem(std::string* why = nullptr);   // true: the name can't be saved under
    void workshopTryInWorld();                                // save, then play with this item in hand

    // ---- items: things the player holds (items/Item.h). The built-in kit and every .pxitem in the assets folder
    // are in itemLibrary; inventory is the hotbar and the item in the hand. The sandbox turns it on by itself; a game
    // that wants engine items sets `inventory.enabled = true` in onStart (and handles its own keys first).
    ItemLibrary  itemLibrary;
    ItemSystem   inventory;
    std::function<void(const ItemHit&)> onItemHit;       // every hit and blast, also passed to Game::onItemHit
    void startPlayingWith(const std::string& item);       // into play mode with this item in the hand
    bool itemNameProblem(const std::string& name, std::string* why = nullptr) const;
    void itemHit(const ItemHit& h);                       // an item hit something: tells the game and onItemHit

    // ---- layouts
    void applyLayout(Layout l) { layoutRequest = int(l); }
    void saveLayoutAs(const std::string& name);          // config/layouts/<name>.ini
    void loadLayout(const std::string& name);
    std::vector<std::string> savedLayouts() const;

    // ---- autosave / recovery
    Autosave autosave;
    void cmdOpenAutosave(const std::string& path);

    // ---- graphics and display settings (core/Graphics.h, core/Display.h). The quality values live in
    // renderSettings and world.loadRadius, so the Environment panel, Settings and the palette all agree.
    GraphicsValues graphics() const { return readGraphics(renderSettings, world.loadRadius); }
    void setGraphics(const GraphicsValues& g) { writeGraphics(g, renderSettings, world.loadRadius); }
    Quality quality() const { return detectQuality(graphics()); }
    void setQuality(Quality q);               // Low / Medium / High / Ultra
    void applyDisplay();                      // window mode, size, monitor and V-Sync, after changing settings.display
    void applyUiScale();
    void toggleFullscreen();                  // F11: windowed <-> borderless fullscreen
    void cycleFpsCap();
    void nudgeUiScale(float delta);           // Ctrl + / Ctrl -
    int  settingsTab = 0;                     // Settings window: 0 General, 1 Graphics, 2 Display, 3 Audio
    int  settingsTabForce = -1;
    void openSettingsTab(int tab) { openSettings = true; settingsTabForce = tab; }

    // ---- commands shared by menus, shortcuts, buttons and games ----
    void openGame(const GameInfo* info, bool startPlaying = false);  // nullptr = empty sandbox
    void closeGame();                                                 // back to the Project Hub
    // Safe to call from UI code mid-frame; the switch happens at the start of the next frame.
    void requestOpenGame(const GameInfo* info, bool play = false) { requestedGame = info; requestedPlay = play; openGameRequested = true; }
    void requestSandbox(int startFrom = -1) { sandboxRequested = true; hubTemplate = startFrom; }   // startFrom: a GameTemplate to build in it
    int  hubTemplate = -1;
    unsigned detailsDock = 0;                       // the dock node Details lives in (a game's own panel joins it)
    int  shelfFront = 0;                            // frames left to bring the Shelf tab to the front (it came back from Shape mode)
    void requestCloseGame() { closeGameRequested = true; }
    std::string worldSavePath() const;                                // worlds/<game id>/world.vxworld
    void setMode(Mode m);
    void setPaused(bool p);
    void toast(const std::string& text, Toast::Kind kind = Toast::Kind::Info);
    void updateSunDirection();        // from timeOfDay / sunHeading / sunMaxElevation
    std::string timeOfDayText() const; // "14:35"
    void applySettings();             // mouse, field of view
    void cmdSave();
    void cmdLoad();
    void cmdNewWorld();
    void cmdNewBlankCanvas();  // WB2: creator-first flat construction canvas
    // Experimental v2.0 planet creation. Requests apply between frames, not
    // during ImGui input callbacks or while the renderer is drawing.
    void openNewProjectWizard();
    void drawNewProjectWizard();
    bool newProjectWizardVisible = false;
    bool newProjectWizardPopupRequested = false;
    int newProjectType = 0; // 0 blank, 1 advanced generated, 2 planet
    bool newProjectReplaceAcknowledged = false;
    void openPlanetCreator();
    void drawPlanetCreatorUI();
    void drawPlanetOpenConfirmation();
    void requestOpenPlanet(const std::string& path);
    std::string planetSavePath() const;
    bool planetCreatorVisible = false;
    int planetPreset = 0;
    char planetNameInput[96] = "New Planet";
    PlanetaryTerrainSettings planetDraft = planetPresetSettings(PlanetPreset::Rocky);
    bool planetReplaceAcknowledged = false;
    bool planetOpenConfirmVisible = false;
    void cmdUndo();
    void cmdRedo();
    void cmdScreenshot() { screenshotRequested = true; }
    void cmdQuit() { running = false; }
    // Small helpers for games: a sound at a world position / a UI blip.
    void playSfxAt(const std::string& clip, const glm::vec3& pos, float volume = 1.0f, float pitch = 1.0f);
    void playUiSound(const char* clip = "ui_click", float volume = 1.0f, float pitch = 1.0f);

private:
    // objects (editor/ObjectTools.cpp, editor/ObjectPanels.cpp)
    void updateObjects(float dt);                // evaluate the scene, hand the draw list to the renderer, keep the world file's copy current
    void syncSceneFromWorld();                   // after a world was loaded: take its objects
    void clearSceneState();                      // new world / reset: no objects, no object history
    bool selectToolMouseDown(bool additive);     // true when the click was used (gizmo handle, object pick, placement)
    void objectsMouseUp();
    void updateGizmoDrag();
    void noteTerrainEdit();
    void runObjectSelfTest();                    // --demo objselftest: drives the real editor code paths and prints results
    GizmoView gizmoView() const;
    bool findPlacementSpot(glm::vec3& pos, glm::vec3& normal, ObjectId* hitObject = nullptr) const;
    void drawKitPanel();
    void drawKitGuides(ImDrawList* dl, const GizmoView& v, float s);       // the grid under the cursor while building
    bool kitDragging = false, kitErasing = false;                           // a held click is building (or removing) a run of pieces
    int  kitStrokeCount = 0;
    float kitDragPlane = 0.0f;
    std::string kitLastKey;
    std::string kitRestyleTarget;
    float ghostYaw = 0.0f, ghostPlane = 0.0f;
    int  ghostLevel = 0;
    bool simulateLeftButton = false;                                        // tests: pretend the left button is held
    int  ghostKitState = 0;                                                 // 0 a new piece, 1 replaces another, 2 the same piece is already there
    void kitDragStep(bool buttonHeld);                                      // each frame of a held click
    void updateGrassClearings();                                            // no grass through the floors of kit buildings
    // ---- trees (1.3): the world's trees and bushes, drawn from the chunks; their trunks are solid
    TreeModels treeModels;
    bool treesForcedOff = false;                    // self tests: a tree must not stand in a test's way
    struct TreeClear { glm::vec3 lo, hi; };
    std::vector<TreeClear> treeClears;              // where objects stand: no trees grow through them
    std::uint64_t treeClearRev = ~0ull;
    struct Trunk { glm::vec3 base; float radius, height; };
    std::unordered_map<std::int64_t, std::vector<Trunk>> trunkGrid;   // 8 m cells -> the trunks drawn last frame
    void treeDraws(std::vector<ObjectDraw>& draws);
    float trunkDensity(const glm::vec3& p) const;
    struct WorldSolids : SolidProvider {           // the scene's objects and the trees' trunks, for walking into
        const Application* app = nullptr;
        float density(const glm::vec3& p) const override;
        glm::vec3 gradient(const glm::vec3& p) const override;
    } worldSolids;
    std::uint64_t clearSceneRev = ~std::uint64_t(0), clearAssetRev = ~std::uint64_t(0);
    void kitStrokeEnd();                                                    // the click was let go: one undo step for the whole run
    void setupKitDemo();                                                    // --demo kit_*  (editor/KitTest.cpp)
    void runKitSelfTest();                                                  // --demo kit_selftest
    void drawBlueprintWindow();                                             // editor/BlueprintTools.cpp
    void drawBlueprintCanvas(float width, float height);
    void drawBlueprintSidebar();
    void drawBlueprintOverlay(ImDrawList* dl, const GizmoView& v, float s);  // the footprint and the hint while placing
    void bpGhostDraws(std::vector<ObjectDraw>& draws);                      // the building following the cursor
    void bpRefreshPreview();
    void bpClickBuild(bool keepPlacing);
    void setupBlueprintDemo();                                              // --demo bp_*  (editor/BlueprintTest.cpp)
    void runBlueprintSelfTest();                                            // --demo bp_selftest
    // characters
    void studioHandleEvent(const SDL_Event& e);
    void updateCharacterStudio(float dt);
    void drawCharacterStudioUI();
    void drawStudioMenuBar();
    void drawStudioPanel(float top, float bottom);
    void drawStudioView();
    void studioRunAfter(std::string action);
    void studioApplyCamera();
    void characterWorldDraws(std::vector<ObjectDraw>& draws, float dt);    // the people in the world, and you in third person
    void updateThirdPersonCamera();
    void drawPlayerBody(float dt);
    HoldKind holdKindFor(const ItemDef* item);
    std::unordered_map<ObjectId, CharacterAnimator> npcAnim;
    std::unordered_map<ObjectId, glm::vec3> npcLastPos;
    CharacterAnimator playerAnim;
    bool playerAnimFresh = true;
    // ---- NPCs that live (v0.20, editor/NpcWorld.cpp)
    struct NpcLive { NpcState state; std::string text; NpcSettings settings; };
    std::unordered_map<ObjectId, NpcLive> npcLive;               // the people walking about while you play
    void updateNpcs(float dt);                                   // play mode: everyone does their thing (before scene.evaluate)
    void stopNpcs();                                             // everyone back where they were put
    NpcSettings npcSettingsOf(ObjectId id) const;                // their settings (defaults when they have none)
    void setNpcSettings(ObjectId id, const NpcSettings& s, const std::string& undoLabel);   // one undo step
    const NpcState* npcStateOf(ObjectId id) const;               // while playing (nullptr otherwise)
    void drawNpcOverlay();                                       // name tags and what they say; the selected one's path and range
    void drawNpcPanel(ObjectId id);                              // the Behaviour section of Properties
    ObjectId npcPicking = 0;                                     // clicking in the world adds to this person's path...
    bool npcPickingWork = false;                                 // ...or sets their work spot
    bool npcPickClick();                                         // a click while picking (true: used)
    bool showNameTags = true;
    bool npcsFrozen = false;                                     // demos
    // ---- "When this happens -> do that" (v0.21, editor/RulesWorld.cpp)
    RuleEngine ruleEngine;
    struct RuleCacheEntry { std::string text; RuleSet set; };
    std::unordered_map<ObjectId, RuleCacheEntry> ruleCache;      // parsed rules, by object
    std::vector<RuleObject> ruleObjects;                         // what the rules know about, set up when play starts
    bool rulesRunning = false;
    bool useRequested = false;                                   // E was pressed
    ObjectId useTarget = 0;                                      // what E would use now (0: nothing)
    std::string useLabel;                                        // "Open", "Talk"...
    struct RuleBanner { std::string text; float left = 0.0f, total = 1.0f; };
    std::vector<RuleBanner> ruleBanners;                         // messages on screen
    bool gameOver = false, gameWon = false;
    std::string gameOverText;
    bool anyScoreRules = false;
    void startRules();                                           // play starts: the rules wake up
    void stopRules();                                            // play stops: everything back as it was
    void updateRules(float dt);                                  // each frame in play mode (before scene.evaluate)
    const RuleSet* rulesOf(ObjectId id);                         // parsed (nullptr: none)
    void setRules(ObjectId id, const RuleSet& r, const std::string& undoLabel);   // one undo step
    void drawRulesPanel(ObjectId id);                            // the Rules section of Properties
    void drawRulesHUD();                                         // messages, the E prompt, points, win / lose
    void restartPlay();                                          // play again from the start
    // ---- game rules and templates (v0.22, editor/GameRulesUI.cpp, editor/GameTemplates.cpp)
    GameRules gameRulesNow;                                      // read when play starts
    GameState gameState;
    glm::vec3 playStartPos{ 0.0f };                              // where this play began (R starts there again)
    float playStartYaw = 0.0f;
    bool showGameRules = false;
    GameRules gameRulesOf() const;                               // this world's (defaults when none)
    void setGameRules(const GameRules& g, const std::string& undoLabel);   // one undo step
    void drawGameRulesWindow();
    enum class GameTemplate { Parkour, CoinHunt, CaptureTheFlag, Survival, Sandbox, Count };
    static const char* gameTemplateLabel(GameTemplate t);
    static const char* gameTemplateHint(GameTemplate t);
    void buildGameTemplate(GameTemplate t);                      // in front of you; one undo step for the objects
    // ---- Share (v0.23, editor/ShareGame.cpp)
    struct ShareWindow {
        bool open = false, filled = false;
        std::string name, author, description, folder;
        bool thirdPerson = false;
        ShareResult last;
        std::string lastFolder;
    } share;
    bool playerMode = false;                                     // started from a shared game: just the game, no editor
    GameManifest playerManifest;
    std::string programPath;                                     // this program (copied into shared games)
    SharePlan makeSharePlan(const GameManifest& m);
    ShareResult shareGame(const GameManifest& m, const std::string& outDir);   // saves the world, then writes the folder
    void drawShareWindow();
    bool startPlayerMode(const std::string& manifestPath);      // open the shared game and start playing
    // ---- polish (v0.24, editor/Polish.cpp): the tutorial, controls, accessibility
    Tutorial tutorial;
    glm::vec3 tutorialCam{ 0.0f };
    float tutorialYaw = 0.0f;
    int tutorialEdits = 0;
    size_t tutorialObjects = 0;
    void updateTutorial(float dt);
    void drawTutorial();
    bool runToggled = false;                                     // toggle-run is on and you are running
    bool held(const bool* keys, Action a) const { const int sc = settings.keys[a]; return sc > 0 && sc < 512 && keys[sc]; }
    bool isKey(const SDL_Event& e, Action a) const {           // (an event made by a test may carry only the key, not its place)
        return int(e.key.scancode) == settings.keys[a] || (e.key.scancode == SDL_SCANCODE_UNKNOWN && int(SDL_GetScancodeFromKey(e.key.key, nullptr)) == settings.keys[a]);
    }
    float hudScale() const { return settings.bigHud ? 1.4f : 1.0f; }
    struct Caption { std::string text; float left = 0.0f; };
    std::vector<Caption> captions;                               // words for sounds (Settings > Accessibility)
    void caption(const std::string& sound);
    void drawCaptions();
    void setupCharacterDemo();                                              // --demo cc_*  (editor/CharacterTest.cpp)
    void runCharacterSelfTest();                                            // --demo cc_selftest
    void setupNpcDemo();                                                    // --demo npc_*  (editor/NpcTest.cpp)
    void runNpcSelfTest();                                                  // --demo npc_selftest
    std::vector<ObjectId> buildNpcVillage(const glm::vec3& c);              // the demo village square
    void setupRuleDemo();                                                   // --demo rule_*  (editor/RulesTest.cpp)
    void setupGameDemo();                                                   // --demo game_*  (editor/GameTest.cpp)
    void setupShareDemo();                                                  // --demo share_* (editor/ShareTest.cpp)
    void setupPolishDemo();                                                 // --demo polish_* (editor/PolishTest.cpp)
    void runPolishSelfTest();                                               // --demo polish_selftest
    void runSoakSelfTest();                                                 // --demo soak_selftest (editor/StabilityTest.cpp)
    void runShareSelfTest();                                                // --demo share_selftest
    void runGameSelfTest();                                                 // --demo game_selftest
    void runRuleSelfTest();                                                 // --demo rule_selftest
    ObjectId buildRuleCourse(const glm::vec3& c, std::vector<ObjectId>* all);   // the demo course (returns the door)
    void drawObjectOverlay();                    // selection boxes, gizmo, placement preview
    void drawOutliner();
    void drawProperties();
    void drawObjectsToolSection();               // the Select tool's part of the Tool panel
    std::vector<ObjectId> selectionRoots() const;       // selected objects that are not inside another selected object

    std::vector<char> undoLog, redoLog;          // 'T' = terrain edit, 'S' = scene step, oldest first
    std::uint64_t sceneRevSynced = 0;
    double sceneClock = 0.0;                     // animation time (play mode, or the motion preview)
    Gizmo gizmo;
    struct GizmoDrag {
        std::vector<std::pair<ObjectId, glm::mat4>> start;      // rest transforms when the drag began
        glm::vec3 pivot{ 0.0f };
        std::string label;
    } gdrag;
    int gizmoHover = Gizmo::kNone;
    glm::vec3 ghostPos{ 0.0f }, ghostNormal{ 0, 1, 0 };
    bool ghostValid = false;
    ObjectId renameRequest = 0;                  // the Outliner opens a rename box for this object
    ObjectId outlinerAnchor = 0;

    // items (core/ItemPlay.cpp)
    void registerItems();
    void prepareHotbar();                        // entering play mode: the hotbar is the items you have, the one you just made first
    bool itemEvent(const SDL_Event& e);          // true when play-mode input was used by the item in the hand
    void updateItems(float dt);                  // the item system's frame, the view kick, and the hand model for the renderer
    void stepItems(float dt);                    // just the item system's frame
    bool itemsFrozen = false;                    // demos and tests stop time for a screenshot
    ItemView itemView() const;
    void drawItemHUD();                          // hotbar, ammo, crosshair, effects
    void runItemSelfTest();                      // --demo itemselftest
    void setupItemDemo();                        // --demo item*
    void setupMaterialDemo();                    // --demo mat_*  (engine/core/MaterialTest.cpp)
    void runMaterialSelfTest();                  // --demo mat_selftest
    std::string preferredItem;                   // goes first in the hotbar next time play mode starts

    // workshop (editor/WorkshopTools.cpp: behaviour, editor/WorkshopUI.cpp: drawing, editor/WorkshopTest.cpp: self test)
    void startWorkshop();
    void updateWorkshop(float dt);
    void workshopHandleEvent(const SDL_Event& e);
    void workshopRunAfter(const std::string& action);        // "close", "place", "new" or "quit", once unsaved work has been dealt with
    void workshopLeaveWith(const std::string& action);       // asks about unsaved work first
    void workshopSyncInfo();                                 // fills the name and tag boxes from the model
    void workshopResetBrush();
    void workshopSizeRange(float& lo, float& hi) const;
    void workshopScaleSize(float factor);
    void workshopSetTool(WTool t);
    void workshopFinishStroke();
    void workshopUndo();
    void workshopRedo();
    void workshopSound(const char* clip, float volume, float pitch);
    void workshopApplyCamera();
    void workshopFrame();                                    // fit the camera to the model
    bool workshopRay(glm::vec3& origin, glm::vec3& dir) const;
    Stamp workshopStamp(const glm::vec3& centre) const;
    bool workshopCentreFor(const WorkshopHit& hit, glm::vec3& centre) const;
    void workshopComputeHover();
    void workshopApplyStamp(const glm::vec3& centre);
    wsui::View workshopView() const;
    void workshopPointerDown(bool shift);
    void workshopPointerUp();
    void workshopPointerUpdate(float dt);
    void workshopSceneForRenderer();
    void drawWorkshopUI();
    void drawWorkshopMenuBar();
    void drawWorkshopRail(float top, float bottom);
    void drawWorkshopPanel(float top, float bottom);
    void drawWorkshopStatus(float y, float height);
    void drawWorkshopDialogs();
    void drawWorkshopOverlay();
    // items in the Workshop (editor/WorkshopItems.cpp)
    bool workshopModified() const { return ws.model.modified() || (ws.itemEdited && ws.model.asset.type == AssetType::Item); }
    void workshopLoadItem();                                 // fills ws.item for the asset being edited
    bool workshopSaveItem();                                 // writes (or removes) the .pxitem that goes with the asset
    void drawWorkshopItemPanel();                            // the Item tab of the side panel
    void workshopEnterRange();
    void workshopLeaveRange();
    void updateWorkshopRange(float dt);
    bool workshopRangeEvent(const SDL_Event& e);             // true: the range used it
    void drawWorkshopRange();                                // the view overlay while the range is showing
    void runWorkshopSelfTest();                              // --demo wsselftest
    void setupWorkshopDemo();                                // --demo ws*

    void handleEvent(const SDL_Event& e);
    void update(float dt);
    void useToolAtCursor(bool firstClick);
    glm::vec3 cursorRay() const;
    void drawEditorUI();  // editor/EditorUI.cpp
    void drawCommandPalette();   // editor/CommandPalette.cpp
    void registerCommands();     // editor/EditorCommands.cpp
    void buildLayout(unsigned dockId, Layout l);   // editor/EditorUI.cpp (DockBuilder)
    void saveEditorState();
    void loadEditorState();
    std::string editorStatePath() const;
    std::string worldFolder() const;
    void drawPlayUI();    // core/PlayUI.cpp: game HUD + toasts + pause menu
    void drawHubUI();     // editor/HubUI.cpp: the Project Hub start screen
    void resetEditorState();
    void applyPlanetRequests();
    bool suppressTutorialOnce = false;
    bool planetCreateRequested = false;
    bool planetOpenRequested = false;
    // Planet surface preview lifecycle is independent from local voxel chunks.
    std::unique_ptr<PlanetSurfaceRuntime> planetSurfaceRuntime;
    std::uint32_t planetSurfaceGeneration = ~std::uint32_t{0};
    PlanetaryTerrainSettings pendingPlanetCreation{};
    std::string pendingPlanetOpenPath;
    std::string activePlanetSavePath;
    void positionPlanetCamera(const PlanetaryTerrainSettings& settings);
    void saveScreenshot(int w, int h);
    void loadUserSettings(GraphicsValues& gfx);          // config/settings.cfg (core/ApplicationSettings.cpp)
    void saveUserSettingsIfChanged(bool force = false);
    void noteWindowResized(int w, int h);
    void runDemoSetup();  // --demo (testing / screenshots)
    void updateAudio(float dt);            // listener, mix settings, ambience, footsteps
    void updatePlayerSounds(float dt);     // footsteps, landing, jumping, swimming
    void measureSurroundings();            // a few times a second: enclosure, water, greenery
    void onWorldEdit(const EditOp& op);    // every new edit makes a sound

    std::unique_ptr<Game> ownedGame;
    float hubOrbit = 0.0f;           // slow camera orbit behind the hub
    bool  openGameRequested = false; // deferred so we never switch games mid-frame
    const GameInfo* requestedGame = nullptr;
    bool  requestedPlay = false;
    bool  closeGameRequested = false;
    bool  sandboxRequested = false;

    SDL_Window*   window = nullptr;
    SDL_GLContext glContext = nullptr;
    bool running = true;
    std::string appliedTexturePack = "\x01";   // the pack the renderer was last given (\x01 = not yet)
    size_t shownPackProblems = 0;
    void applyTexturePack();
    bool imguiReady = false;
    bool glReady = false;
    bool looking = false;        // editor: right mouse held
    bool lmbHeld = false;
    float toolRepeat = 0.0f;
    float mouseX = 0.0f, mouseY = 0.0f;
    bool  screenshotRequested = false;
    int   autoScreenshotFrame = -1;  // --screenshot-and-exit N (testing)
    int   frameCounter = 0;
    std::string demo;                // --demo <name>

    // layouts / palette / recovery
    int  layoutRequest = -1;                  // Layout to build next frame (-1 none)
    std::string pendingLayoutFile;            // ini to load before the next frame
    bool layoutDefaultsBuilt = false;
    std::vector<std::string> settleFronts;    // a fresh layout: the windows whose tab should come to the front
    int  settleFrames = 0;
    bool settleFront(const char* title) const {
        return settleFrames > 0 && std::find(settleFronts.begin(), settleFronts.end(), title) != settleFronts.end();
    }
    std::string imguiIniPath;
    char paletteQuery[96] = {};
    int  paletteSel = 0;
    bool paletteFocus = false;
    std::string pendingCommand;
    bool openSaveLayout = false;
    char layoutName[48] = "My layout";
    std::optional<AutosaveInfo> recovery;     // set when the last session of this world ended badly
    bool openRecovery = false;
    std::uint64_t lastManualSaveRev = 0;

    // settings file
    bool persistSettings = true;              // off for --screenshot-and-exit, --demo and --no-settings runs
    std::string lastSettingsText;
    float settingsTimer = 0.0f;
    int   ignoreResizeUntil = 0;              // window size changes we caused ourselves are not the user's choice

    // audio state
    float stepAccum = 0.0f, swimAccum = 0.0f, prevVelY = 0.0f, lastEditSound = -1.0f, measureTimer = 0.0f;
    bool  wasGrounded = true;
    AmbienceInputs ambienceIn;
public:
    const AmbienceInputs& ambienceInputs() const { return ambienceIn; }
};

// Shared UI pieces (implemented in editor/EditorUI.cpp).
void drawToasts(const std::vector<Toast>& toasts, float topY);
void drawSettingsModal(Application& app);

} // namespace px
