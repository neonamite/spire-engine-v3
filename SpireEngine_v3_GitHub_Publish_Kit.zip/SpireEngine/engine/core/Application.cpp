#include "core/Application.h"
#include "scene/BuiltinProps.h"
#include "character/SkinnedBody.h"
#include "character/HumanBody.h"
#include "rules/Gadgets.h"
#include "character/BodyParts.h"
#include "editor/ItemRange.h"
#include "ui/UiKit.h"
#include "workshop/KitPieces.h"
#include "editor/Panels.h"
#include "world/RoadPath.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>
#include <glad/glad.h>
#include <glm/gtc/constants.hpp>
#include <imgui.h>
#include <imgui_impl_sdl3.h>
#include <imgui_impl_opengl3.h>

#ifndef IMGUI_HAS_DOCK
#error "Spire Engine needs Dear ImGui with docking. With vcpkg this is the imgui[docking-experimental] feature (already in vcpkg.json)."
#endif

namespace px {

namespace {
// Finds the project folder (the one containing assets/) so the engine works no
// matter which directory it was launched from.
std::string findAssetRoot() {
    namespace fs = std::filesystem;
    std::vector<fs::path> starts = { fs::current_path() };
    if (const char* base = SDL_GetBasePath()) starts.emplace_back(base);
    for (fs::path p : starts)
        for (int i = 0; i < 5 && !p.empty(); ++i, p = p.parent_path())
            if (fs::exists(p / "engine" / "assets" / "fonts")) return p.string();
    return fs::current_path().string();
}
} // namespace

bool Application::init(int argc, char** argv) {
    std::string startGame, playFile;
    int startWidth = 1600, startHeight = 900;
    {
        // this program's own file, for Share (found before the working folder changes)
        std::error_code ec;
        if (std::filesystem::exists("/proc/self/exe", ec)) programPath = std::filesystem::canonical("/proc/self/exe", ec).string();
        if (programPath.empty() && argc > 0) programPath = std::filesystem::absolute(argv[0], ec).string();
#ifdef _WIN32
        if (!programPath.empty() && std::filesystem::path(programPath).extension().empty()) programPath += ".exe";
#endif
    }
    bool noAudio = false, noSettings = false, useSettings = false, sizeGiven = false;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--no-audio") == 0) noAudio = true;
        if (std::strcmp(argv[i], "--no-settings") == 0) noSettings = true;       // ignore and never write config/settings.cfg
        if (std::strcmp(argv[i], "--use-settings") == 0) useSettings = true;     // testing: read/write it even in --demo and screenshot runs
        if (std::strcmp(argv[i], "--rigid-characters") == 0) setCharacterSkinning(false);   // people part by part, as before 1.3
        if (std::strcmp(argv[i], "--voxel-people") == 0) setRealisticPeople(false);        // people made of voxel parts, as in 1.4
    }
    for (int i = 1; i + 1 < argc; ++i) {
        if (std::strcmp(argv[i], "--game") == 0) startGame = argv[i + 1];
        if (std::strcmp(argv[i], "--play") == 0) playFile = argv[i + 1];         // a shared game: play it, no editor
        if (std::strcmp(argv[i], "--screenshot-and-exit") == 0) autoScreenshotFrame = std::atoi(argv[i + 1]);
        if (std::strcmp(argv[i], "--demo") == 0) demo = argv[i + 1];
        if (std::strcmp(argv[i], "--size") == 0) { std::sscanf(argv[i + 1], "%dx%d", &startWidth, &startHeight); sizeGiven = true; }   // testing
    }
    // Screenshot and demo runs must always look the same: they neither read nor write the user's settings.
    persistSettings = !noSettings && (useSettings || (autoScreenshotFrame < 0 && demo.empty()));
    treesForcedOff = demo.find("selftest") != std::string::npos;             // self tests walk set paths: no tree in the way

    if (!SDL_Init(SDL_INIT_VIDEO)) {               // SDL3 returns true on success
        std::cerr << "SDL_Init failed: " << SDL_GetError() << "\n";
        return false;
    }
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

    // config/, worlds/, prefabs/ live next to the engine's assets; the settings file decides the window size.
    const std::string root = findAssetRoot();
    std::filesystem::current_path(root);
    GraphicsValues startGraphics;
    loadUserSettings(startGraphics);
    if (sizeGiven) { settings.display.width = startWidth; settings.display.height = startHeight; }       // --size wins
    else           { startWidth = settings.display.width; startHeight = settings.display.height; }

    window = SDL_CreateWindow("Spire Engine", startWidth, startHeight, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);
    if (!window) { std::cerr << "SDL_CreateWindow failed: " << SDL_GetError() << "\n"; return false; }
    glContext = SDL_GL_CreateContext(window);
    if (!glContext) { std::cerr << "GL context failed: " << SDL_GetError() << "\n"; return false; }
    SDL_GL_MakeCurrent(window, glContext);
    if (!gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress)) { std::cerr << "GLAD failed\n"; return false; }
    glReady = true;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    {
        // Dockable panels; the layout is remembered in config/layout.ini (not for --screenshot runs,
        // which must always look the same).
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
        std::error_code ec;
        std::filesystem::create_directories("config", ec);
        imguiIniPath = "config/layout-1.1.ini";        // 1.1 moved every panel: start from the new layout
        io.IniFilename = autoScreenshotFrame >= 0 ? nullptr : imguiIniPath.c_str();
    }
    float scale = SDL_GetWindowDisplayScale(window);
    if (scale <= 0.0f) scale = 1.0f;
    ui::setup(root + "/engine/assets/fonts", scale);
    applyUiScale();
    ImGui_ImplSDL3_InitForOpenGL(window, glContext);
    ImGui_ImplOpenGL3_Init("#version 330 core");
    imguiReady = true;

    if (!renderer.init()) return false;

    // Sounds are generated at start-up; with no sound device the engine just stays quiet.
    if (noAudio) audio.initOffline(); else audio.init();
    world.onEdit = [this](const EditOp& op) { onWorldEdit(op); };

    registerCommands();
    worldSolids.app = this;
    player.extraSolids = &worldSolids;              // placed objects and tree trunks are solid
    prefabs.addBuiltins();
    prefabs.loadDirectory("prefabs");
    assets.directory = "assets";                     // things made in the Asset Workshop (.pxasset)
    registerBuiltinKits(assets);                     // the building kits: listed now, built when first used
    registerBuiltinProps(assets);                    // boulder, crate, arch, steps, lamp post, pillar in fine detail (1.2)
    registerTreeProps(assets);                       // oak, pine, birch and bush to place by hand (1.3)
    treeModels.start();                              // the world's trees, built in the background (1.3)
    ensureHumanRenderData();                         // people's skin maps, eyes, hair and expressions (1.5; baked once, then cached)
    registerBodyParts(assets);                       // the built-in body parts, the same way
    registerGadgets(assets);                         // doors, plates, coins... (v0.21)
    characters.loadDirectory();                      // your own people: characters/*.pxcharacter
    assets.loadDirectory(assets.directory);
    registerItems();                                 // the built-in kit, then every .pxitem in the same folder

    pendingTerrain = TerrainSettings{};
    setGraphics(startGraphics);                      // view distance has to be known before the first chunks load
    world.start(pendingTerrain);
    updateSunDirection();
    applySettings();
    applyDisplay();

    const auto& t = world.terrain();
    camera.position = glm::vec3(0.0f, t.surfaceHeight(0, 0) + 25.0f, 30.0f);
    player.position = camera.position;
    // A shared game: game.pxgame beside the program (or --play) goes straight into the game.
    if (playFile.empty() && startGame.empty() && demo.empty() && std::filesystem::exists(kManifestFile)) playFile = kManifestFile;
    if (!playFile.empty()) {
        if (startPlayerMode(playFile)) return true;
        std::cerr << "Showing the Project Hub instead\n";
    }
    if (!startGame.empty()) {
        if (startGame == "sandbox") openGame(nullptr);
        else if (const GameInfo* gi = findGame(startGame)) openGame(gi);
        else std::cerr << "Unknown game '" << startGame << "', showing the Project Hub\n";
    }
    return true;
}

// ------------------------------------------------------------------ games

std::string Application::worldSavePath() const {
    return "worlds/" + (gameInfo ? gameInfo->id : std::string("sandbox")) + "/world.vxworld";
}

void Application::resetEditorState() {
    tool = Tool::Carve;
    toasts.clear();
    paused = false;
    looking = lmbHeld = false;
    ambience.zones.clear();
    bookmarks = {};
    flyTo.cancel();
    paletteOpen = false;
    pendingTerrain = TerrainSettings{};
    world.clearEdits();                          // also regenerates with default settings
    clearSceneState();
    bp.open = false;                             // the Blueprint window belongs to the game that was open
    world.setSettings(pendingTerrain);
    camera = Camera{};
    timeOfDay = 10.0f;
    timeFlowing = true; // planet editor may have frozen daylight
    applySettings();
    camera.position = glm::vec3(0.0f, world.terrain().surfaceHeight(0, 0) + 25.0f, 30.0f);
}

void Application::openGame(const GameInfo* info, bool startPlaying) {
    if (ws.active) leaveWorkshop();
    if (cs.active) leaveCharacterStudio();
    if (cs.active) leaveCharacterStudio();
    if (ownedGame) closeGame();
    resetEditorState();
    activePlanetSavePath.clear();
    gameInfo = info;
    ownedGame = info ? info->create() : nullptr;
    game = ownedGame.get();
    inventory.enabled = game == nullptr;             // the sandbox hands out items; a game opts in from onStart
    inventory.slots.clear(); inventory.current = -1; inventory.reset(); inventory.totals = {};

    const std::string title = (info ? info->name : std::string("Sandbox")) + "  -  Spire Engine";
    SDL_SetWindowTitle(window, title.c_str());

    // Each game keeps its own world; reopen where you left off.
    if (std::filesystem::exists(worldSavePath()) && world.loadWorld(worldSavePath())) { pendingTerrain = world.settings(); syncSceneFromWorld(); }

    // Crash safety: a lock file marks the world as open. If it was still there, the last session
    // died, and an autosave newer than the saved world is offered back.
    commands.removeWithPrefix("game.");
    if (demo.empty() && !playerMode) {
        autosave.intervalMinutes = settings.autosaveMinutes;
        const bool crashed = autosave.beginSession(worldFolder());
        autosave.markSaved(world);
        recovery.reset();
        if (crashed) { recovery = autosave.recoverable(worldSavePath()); openRecovery = recovery.has_value(); }
        loadEditorState();
    }

    mode = Mode::Editor;
    if (game) game->onStart(*this);
    if (demo.empty() && !playerMode && persistSettings && !settings.tutorialDone && autoScreenshotFrame < 0 && !suppressTutorialOnce) startTutorial();   // the first time ever
    suppressTutorialOnce = false;
    toast(std::string("Opened ") + (info ? info->name : "empty sandbox") + ". Press F1 for controls.");
    if (startPlaying) setMode(Mode::Play);
}

void Application::closeGame() {
    if (ws.active) leaveWorkshop();
    if (mode == Mode::Play) setMode(Mode::Editor);
    saveEditorState();
    autosave.endSession();
    if (game) game->onShutdown(*this);
    ownedGame.reset();
    game = nullptr;
    gameInfo = nullptr;
    SDL_SetWindowTitle(window, "Spire Engine");
    SDL_SetWindowRelativeMouseMode(window, false);
    resetEditorState();
    activePlanetSavePath.clear();
    mode = Mode::Hub;
}

// ------------------------------------------------------------------ commands

void Application::toast(const std::string& text, Toast::Kind kind) {
    status = text;
    if (kind == Toast::Kind::Success) playUiSound("ui_click", 0.45f, 1.25f);
    else if (kind == Toast::Kind::Warning) playUiSound("ui_click", 0.6f, 0.6f);
    toasts.push_back({ text, 0.0f, kind });
    if (toasts.size() > 4) toasts.erase(toasts.begin());
}

void Application::applySettings() {
    ui::setColourBlindFriendly(settings.colourBlind);
    camera.sensitivity = settings.mouseSensitivity;
    camera.fovDegrees  = settings.fov;
    SDL_GL_SetSwapInterval(settings.vsync ? 1 : 0);
}

void Application::updateSunDirection() {
    // The sun rises at 06:00, peaks at 12:00 and sets at 18:00, travelling across a
    // tilted circle. The moon is drawn opposite it.
    const float s = (timeOfDay - 6.0f) / 12.0f * glm::pi<float>();
    glm::vec3 toSun(std::cos(s), std::sin(s), 0.0f);                       // east -> up -> west
    const float tilt = glm::radians(90.0f - sunMaxElevation);
    toSun = glm::vec3(toSun.x, toSun.y * std::cos(tilt), toSun.y * std::sin(tilt));
    const float h = glm::radians(sunHeading);
    toSun = glm::vec3(toSun.x * std::cos(h) - toSun.z * std::sin(h), toSun.y, toSun.x * std::sin(h) + toSun.z * std::cos(h));
    renderSettings.sunDirection = -glm::normalize(toSun);                   // direction light travels
}

std::string Application::timeOfDayText() const {
    const int minutes = int(timeOfDay * 60.0f) % (24 * 60);
    char buf[8];
    std::snprintf(buf, sizeof buf, "%02d:%02d", minutes / 60, minutes % 60);
    return buf;
}

void Application::cmdSave() {
    if (scene.revision() != sceneRevSynced) {           // the world file carries the objects: make sure its copy is current
        world.setExtraBlob(scene.empty() ? std::string() : scene.toText());
        sceneRevSynced = scene.revision();
    }
    if (world.isPlanetaryPrototype()) {
        const auto path = planetSavePath();
        if (world.savePlanetPrototype(path)) toast("Experimental planet saved: " + path, Toast::Kind::Success);
        else toast("Unable to save experimental planet", Toast::Kind::Warning);
        return;
    }
    if (world.saveWorld(worldSavePath())) { autosave.markSaved(world); saveEditorState(); toast("World saved", Toast::Kind::Success); }
    else toast("Could not save the world", Toast::Kind::Warning);
}

void Application::cmdLoad() {
    if (world.isPlanetaryPrototype()) {
        const auto path = planetSavePath();
        if (world.loadPlanetPrototype(path)) {
            syncSceneFromWorld();
            toast("Experimental planet loaded: " + path, Toast::Kind::Success);
        } else toast("No valid experimental planet save found", Toast::Kind::Warning);
        return;
    }
    if (world.loadWorld(worldSavePath())) { pendingTerrain = world.settings(); syncSceneFromWorld(); autosave.markSaved(world); toast("World loaded", Toast::Kind::Success); }
    else toast("No saved world found", Toast::Kind::Warning);
}

void Application::cmdOpenAutosave(const std::string& path) {
    if (world.loadWorld(path)) {
        pendingTerrain = world.settings();
        syncSceneFromWorld();
        toast("Autosave loaded. Save the world (Ctrl+S) to keep it.", Toast::Kind::Success);
    } else toast("Could not read that autosave", Toast::Kind::Warning);
}

// ------------------------------------------------------------------ editor state, bookmarks

std::string Application::worldFolder() const { return "worlds/" + (gameInfo ? gameInfo->id : std::string("sandbox")); }
std::string Application::editorStatePath() const { return worldFolder() + "/editor.state"; }

void Application::saveEditorState() {
    if (!demo.empty() || mode == Mode::Hub) return;
    EditorState st;
    st.hasCamera = true; st.cameraPosition = camera.position; st.cameraYaw = camera.yaw; st.cameraPitch = camera.pitch;
    st.hasTime = true; st.timeOfDay = timeOfDay;
    st.tool = int(tool); st.brushRadius = brushRadius; st.brushMaterial = int(brushMaterial); st.flySpeed = flySpeed;
    st.playerCharacter = playerCharacter;
    st.bookmarks = bookmarks;
    st.save(editorStatePath());
}

void Application::loadEditorState() {
    EditorState st;
    if (!EditorState::load(editorStatePath(), st)) return;
    if (st.hasCamera) { camera.position = st.cameraPosition; camera.yaw = st.cameraYaw; camera.pitch = std::clamp(st.cameraPitch, -89.0f, 89.0f); }
    if (st.hasTime) timeOfDay = std::fmod(std::max(st.timeOfDay, 0.0f), 24.0f);
    if (st.tool >= 0 && st.tool < int(Tool::Count)) tool = Tool(st.tool);
    brushRadius = std::clamp(st.brushRadius, 1.0f, 12.0f);
    if (st.brushMaterial >= 0 && st.brushMaterial < int(MAT_COUNT)) brushMaterial = MaterialId(st.brushMaterial);
    flySpeed = std::clamp(st.flySpeed, 5.0f, 150.0f);
    if (!st.playerCharacter.empty()) playerCharacter = st.playerCharacter;
    bookmarks = st.bookmarks;
}

void Application::saveBookmark(int slot) {
    if (slot < 0 || slot >= EditorState::kBookmarks) return;
    CameraBookmark& b = bookmarks[size_t(slot)];
    if (!b.used || b.name.empty()) b.name = "Bookmark " + std::to_string(slot + 1);
    b.used = true; b.position = camera.position; b.yaw = camera.yaw; b.pitch = camera.pitch;
    toast("Saved bookmark " + std::to_string(slot + 1) + "  (Ctrl+" + std::to_string(slot + 1) + " to return)", Toast::Kind::Success);
}

void Application::gotoBookmark(int slot) {
    if (slot < 0 || slot >= EditorState::kBookmarks) return;
    const CameraBookmark& b = bookmarks[size_t(slot)];
    if (!b.used) { toast("Bookmark " + std::to_string(slot + 1) + " is empty. Ctrl+Shift+" + std::to_string(slot + 1) + " saves this view.", Toast::Kind::Warning); return; }
    if (mode != Mode::Editor) return;
    flyTo.start(camera, b.position, b.yaw, b.pitch);
}

// ------------------------------------------------------------------ layouts

void Application::saveLayoutAs(const std::string& nameIn) {
    std::string name;
    for (char c : nameIn) name += (std::isalnum(static_cast<unsigned char>(c)) || c == ' ' || c == '-' || c == '_') ? c : '_';
    if (name.empty()) return;
    std::error_code ec;
    std::filesystem::create_directories("config/layouts", ec);
    ImGui::SaveIniSettingsToDisk(("config/layouts/" + name + ".ini").c_str());
    toast("Layout saved: " + name, Toast::Kind::Success);
}

void Application::loadLayout(const std::string& name) {
    const std::string path = "config/layouts/" + name + ".ini";
    if (std::filesystem::exists(path)) pendingLayoutFile = path;          // applied before the next frame
}

std::vector<std::string> Application::savedLayouts() const {
    std::vector<std::string> out;
    std::error_code ec;
    for (auto& e : std::filesystem::directory_iterator("config/layouts", ec))
        if (e.path().extension() == ".ini") out.push_back(e.path().stem().string());
    std::sort(out.begin(), out.end());
    return out;
}

// World Builder: an explicit, opt-in manual road operation. The road is made
// from ordinary persistent voxel edits, so existing save/load and undo are reused.
bool Application::captureRoadStart() {
    if (world.isPlanetaryPrototype()) { toast("Road authoring on planets is not supported yet", Toast::Kind::Warning); return false; }
    RayHit hit;
    if (!world.raycast(camera.position, camera.front(), 300.0f, hit)) {
        toast("Aim the camera at loaded ground to select the road start", Toast::Kind::Warning);
        return false;
    }
    roadStart = hit.position;
    roadStartSelected = true;
    toast("Road start selected. Aim at the endpoint and press Build Road.", Toast::Kind::Success);
    return true;
}

bool Application::finishRoad() {
    if (!roadStartSelected || world.isPlanetaryPrototype()) return false;
    RayHit hit;
    if (!world.raycast(camera.position, camera.front(), 300.0f, hit)) {
        toast("Aim the camera at loaded ground for the road endpoint", Toast::Kind::Warning);
        return false;
    }
    const auto samples = buildRoadSamples(roadStart, hit.position, roadWidth);
    if (samples.empty()) {
        toast("Roads must be 1 to 160 meters long; use segments for longer roads", Toast::Kind::Warning);
        return false;
    }
    for (const auto& sample : samples) {
        if (roadGrade) world.flatten(sample.center, sample.flattenRadius);
        world.paint(sample.center, sample.paintRadius, roadMaterial);
    }
    roadStartSelected = false;
    toast("Manual road constructed; save the world to preserve it", Toast::Kind::Success);
    return true;
}

void Application::cmdNewBlankCanvas() {
    roadStartSelected = false;
    // Editor-first, empty flat construction canvas.  No noise, water, or
    // auto-scattered props; existing sculpting, stamping and persistence work.
    // This deliberately uses the v1.6 terrain/save schema for compatibility.
    if (world.isPlanetaryPrototype()) {
        world.start(TerrainSettings{});
        activePlanetSavePath.clear();
        camera = Camera{};
    }
    pendingTerrain = TerrainSettings{};
    pendingTerrain.baseHeight = 32.0f;
    pendingTerrain.hillAmplitude = 0.0f;
    pendingTerrain.caveAmplitude = 0.0f;
    pendingTerrain.scatterProps = false;
    pendingTerrain.scatterChance = 0.0f;
    pendingTerrain.water = false;
    world.clearEdits();
    world.setSettings(pendingTerrain);
    clearSceneState();
    camera.position = glm::vec3(0.0f, 55.0f, 36.0f);
    camera.lookAt(glm::vec3(0.0f, 32.0f, 0.0f));
    tool = Tool::Build;
    setEditMode(EditMode::Shape);
    toast("Blank construction canvas ready: sculpt, paint, and build", Toast::Kind::Success);
}

void Application::cmdNewWorld() {
    roadStartSelected = false;
    // A flat-world reset must explicitly exit planetary mode and clear its
    // separate save target; don't allow VXPL edits into a legacy world save.
    if (world.isPlanetaryPrototype()) {
        world.start(TerrainSettings{});
        activePlanetSavePath.clear();
        camera = Camera{};
    }
    pendingTerrain = TerrainSettings{};
    pendingTerrain.seed = std::uint32_t(SDL_GetTicks() & 0x7FFFFFFF);
    world.clearEdits();
    world.setSettings(pendingTerrain);
    clearSceneState();
    toast("New world (seed " + std::to_string(pendingTerrain.seed) + ")", Toast::Kind::Success);
}


void Application::setMode(Mode m) {
    if (m == mode || m == Mode::Hub) return;
    if (world.isPlanetaryPrototype() && m == Mode::Play) {
        toast("Planet mode is editor-only until radial character physics is ready.", Toast::Kind::Warning);
        return;
    }      // use closeGame() to reach the hub
    if (playerMode && m == Mode::Editor) return;  // a shared game has no editor
    mode = m;
    looking = false;
    paused = false;
    lmbHeld = false;
    stepAccum = swimAccum = 0.0f; prevVelY = 0.0f; wasGrounded = true;
    gizmo.end();
    if (mode == Mode::Play) {
        sceneClock = 0.0;
        placingAsset.clear();
        bp.placing = false;
        player.position = camera.position - glm::vec3(0, player.eyeHeight, 0);
        player.velocity = glm::vec3(0);
        SDL_SetWindowRelativeMouseMode(window, true);
        if (inventory.enabled) prepareHotbar();
        if (game) game->onEnterPlay(*this);
        playerAnimFresh = true;
        startRules();
        toast(playerMode ? "Esc for the menu, V to see yourself." : "Playing. Esc to pause, Tab for the editor, V to see yourself.");
    } else {
        SDL_SetWindowRelativeMouseMode(window, false);
        inventory.reset();
        stopRules();
        stopNpcs();
        if (game) game->onExitPlay(*this);
        toast("Editor");
    }
}

void Application::setPaused(bool p) {
    paused = p;
    if (p) { inventory.releaseTrigger(0); inventory.releaseTrigger(1); }
    SDL_SetWindowRelativeMouseMode(window, mode == Mode::Play && !paused);
}

// ------------------------------------------------------------------ input

glm::vec3 Application::cursorRay() const {
    // While flying the cursor is hidden, so aim from the centre of the view instead.
    return looking ? camera.front() : camera.rayThroughPixel(mouseX - viewRect.x, mouseY - viewRect.y, viewRect.w, viewRect.h);
}

void Application::handleEvent(const SDL_Event& e) {
    ImGui_ImplSDL3_ProcessEvent(&e);
    const ImGuiIO& io = ImGui::GetIO();
    const bool ctrl = (SDL_GetModState() & SDL_KMOD_CTRL) != 0;
    // Settings > Controls is waiting for a key: this one is it (Esc gives up)
    if (rebinding >= 0 && e.type == SDL_EVENT_KEY_DOWN && !e.key.repeat) {
        if (e.key.scancode != SDL_SCANCODE_ESCAPE) {
            Action swapped = Action::Count;
            if (rebind(settings.keys, Action(rebinding), int(e.key.scancode), &swapped)) {
                if (swapped != Action::Count) toast(std::string(actionLabel(swapped)) + " now uses " + SDL_GetScancodeName(SDL_Scancode(settings.keys[swapped])), Toast::Kind::Info);
            } else toast("That key is kept for the menus", Toast::Kind::Warning);
        }
        rebinding = -1;
        return;
    }

    // The Asset Workshop is a screen of its own: it takes every event except the window's own.
    if (ws.active && e.type != SDL_EVENT_QUIT && e.type != SDL_EVENT_WINDOW_RESIZED) { workshopHandleEvent(e); return; }
    if (cs.active && e.type != SDL_EVENT_QUIT && e.type != SDL_EVENT_WINDOW_RESIZED) { studioHandleEvent(e); return; }

    switch (e.type) {
    case SDL_EVENT_QUIT:
        if (ws.active) workshopLeaveWith("quit");
        else if (cs.active) { cs.afterLeave = "quit"; requestLeaveCharacterStudio(); }
        else running = false;
        break;

    case SDL_EVENT_WINDOW_RESIZED:
        noteWindowResized(e.window.data1, e.window.data2);
        break;

    case SDL_EVENT_KEY_DOWN: {
        if (e.key.repeat) break;
        const SDL_Keycode k = e.key.key;
        if (k == SDLK_F11 || (k == SDLK_RETURN && (SDL_GetModState() & SDL_KMOD_ALT))) { toggleFullscreen(); break; }   // F11 or Alt+Enter, anywhere
        if (mode == Mode::Hub) break;
        if (k == SDLK_F12) { cmdScreenshot(); break; }

        if (mode == Mode::Play) {
            if (k == SDLK_ESCAPE) { setPaused(!paused); break; }
            if (k == SDLK_TAB) { setMode(Mode::Editor); break; }
            if (gameOver) { if (k == SDLK_R) restartPlay(); break; }                  // the game is over: R plays again
            if (!paused && isKey(e, Action::Use) && !(game && game->onPlayEvent(*this, e))) { useRequested = true; break; }   // use what you look at
            if (!paused && settings.toggleRun && isKey(e, Action::Run)) runToggled = !runToggled;
            if (!paused && isKey(e, Action::View) && !(game && game->onPlayEvent(*this, e))) {      // your eyes, or over your shoulder
                thirdPerson = !thirdPerson;
                playerAnimFresh = true;
                toast(thirdPerson ? "Third person: you can see yourself. V goes back." : "First person");
                break;
            }
            if (!paused) { const bool used = game && game->onPlayEvent(*this, e); if (!used) itemEvent(e); }
            break;
        }

        // Director: global shortcuts work even while a panel has focus.
        if (ctrl && (SDL_GetModState() & SDL_KMOD_SHIFT) && k == SDLK_W) { enterWorkshopNew(); break; }
        if (ctrl && (SDL_GetModState() & SDL_KMOD_SHIFT) && k == SDLK_C) { openCharacterStudio(); break; }
        if (ctrl && (k == SDLK_P || k == SDLK_K)) {                                // find anything
            paletteOpen = !paletteOpen;
            if (paletteOpen) { paletteFocus = true; paletteQuery[0] = 0; paletteSel = 0; }
            break;
        }
        if (ctrl && k >= SDLK_1 && k <= SDLK_9) {                                  // camera bookmarks
            const bool shift = (SDL_GetModState() & SDL_KMOD_SHIFT) != 0;
            if (shift) saveBookmark(int(k - SDLK_1)); else gotoBookmark(int(k - SDLK_1));
            break;
        }
        if (ctrl && (k == SDLK_EQUALS || k == SDLK_PLUS || k == SDLK_KP_PLUS)) { nudgeUiScale(0.05f); break; }   // interface size
        if (ctrl && (k == SDLK_MINUS || k == SDLK_KP_MINUS)) { nudgeUiScale(-0.05f); break; }
        if (ctrl && k == SDLK_0) { nudgeUiScale(0.0f); break; }
        if (ctrl && (k == SDLK_Z || k == SDLK_Y) && bp.open && bp.windowFocused && !bp.placing && !io.WantTextInput) {   // the plan's own undo
            if (k == SDLK_Z) bpUndo(); else bpRedo();
            break;
        }
        if (ctrl && k == SDLK_B) { if (bp.placing) bpStopPlacing(); else openBlueprintEditor(); break; }
        if (ctrl && k == SDLK_Z) { cmdUndo(); break; }
        if (ctrl && k == SDLK_Y) { cmdRedo(); break; }
        if (ctrl && k == SDLK_S) { cmdSave(); break; }
        if (ctrl && k == SDLK_O) { cmdLoad(); break; }
        if (io.WantTextInput) break;
        if (ctrl && k == SDLK_D) { cmdDuplicateSelection(); break; }
        if (ctrl && k == SDLK_G) { if (SDL_GetModState() & SDL_KMOD_SHIFT) cmdUngroupSelection(); else cmdGroupSelection(); break; }
        if (ctrl && k == SDLK_A) { cmdSelectAll(); tool = Tool::Select; break; }
        if (bp.placing && k == SDLK_ESCAPE) { bpStopPlacing(); break; }
        if (bp.placing && !looking && !ctrl && k == SDLK_R) { bp.turns = (bp.turns + ((SDL_GetModState() & SDL_KMOD_SHIFT) ? 3 : 1)) % 4; break; }
        if (k == SDLK_ESCAPE && npcPicking) { npcPicking = 0; toast("Done"); break; }
        if (k == SDLK_ESCAPE) {
            if (gizmo.dragging()) { scene.discardUncommitted(); gizmo.end(); gdrag.start.clear(); }
            else if (!placingAsset.empty()) stopPlacing();
            else if (!selection.empty()) selectObject(0);
            break;
        }
        if (k == SDLK_DELETE) { cmdDeleteSelection(); break; }
        if (k == SDLK_F && !looking) { cmdFocusSelection(); break; }
        if (!looking && !ctrl && k == SDLK_R && placingKit()) { kitRotate(); break; }              // turning a building piece
        if (!looking && !ctrl && (k == SDLK_W || k == SDLK_E || k == SDLK_R)) {
            cmdSetGizmoMode(k == SDLK_W ? GizmoMode::Move : k == SDLK_E ? GizmoMode::Rotate : GizmoMode::Scale);
            break;
        }
        if (!looking && !ctrl && k == SDLK_X && tool == Tool::Select) { gizmoSpace = gizmoSpace == GizmoSpace::World ? GizmoSpace::Local : GizmoSpace::World; break; }
        if (k == SDLK_TAB) setMode(Mode::Play);
        if (k == SDLK_F1) showShortcutList = !showShortcutList;
        if (k == SDLK_H) uiHidden = !uiHidden;
        if (k >= SDLK_1 && k < SDLK_1 + int(Tool::Count)) tool = Tool(int(k - SDLK_1));
        // the tool strip's letters (Figma, Photoshop and friends use V for the pointer)
        if (!looking && !ctrl && k == SDLK_V) { tool = Tool::Select; if (editMode == EditMode::Shape) setEditMode(EditMode::Build); }
        if (!looking && !ctrl && k == SDLK_P) showShelf(-1, true);
        if (!looking && !ctrl && k == SDLK_K) { showKits = true; ImGui::SetWindowFocus("Kits"); }
        if (!looking && !ctrl && k == SDLK_B) openBlueprintEditor();
        if (!looking && !ctrl && k == SDLK_G) showShelf(3, false);
        if (!looking && !ctrl && k == SDLK_SPACE && !wheel.open) {                  // the quick wheel, at the pointer
            wheel.open = true; wheel.x = mouseX; wheel.y = mouseY; wheel.hover = -1;
        }
        if (k == SDLK_LEFTBRACKET || k == SDLK_RIGHTBRACKET) {
            if (placingKit()) kitLevelStep(k == SDLK_RIGHTBRACKET ? 1 : -1);                         // [ and ] change storey while building
            else brushRadius = k == SDLK_LEFTBRACKET ? std::max(1.0f, brushRadius - 0.5f) : std::min(12.0f, brushRadius + 0.5f);
        }
        break;
    }

    case SDL_EVENT_KEY_UP:
        if (e.key.key == SDLK_SPACE && wheel.open) {     // let go of Space: do what the pointer is on
            wheel.open = false;
            if (mode == Mode::Editor) quickWheelAction(wheel.hover);
        }
        break;

    case SDL_EVENT_MOUSE_MOTION:
        mouseX = e.motion.x; mouseY = e.motion.y;
        if ((mode == Mode::Play && !paused) || looking)
            camera.look(e.motion.xrel, settings.invertY ? -e.motion.yrel : e.motion.yrel);
        break;

    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (mode == Mode::Hub) break;
        if (mode == Mode::Play) {
            if (!paused) { const bool used = game && game->onPlayEvent(*this, e); if (!used) itemEvent(e); }
            break;
        }
        if (wheel.open) {                                // a click on the quick wheel picks too
            if (e.button.button == SDL_BUTTON_LEFT) quickWheelAction(wheel.hover);
            wheel.open = false;
            break;
        }
        if (io.WantCaptureMouse) break;
        if (e.button.button == SDL_BUTTON_RIGHT && npcPicking && !npcPickingWork) { npcPicking = 0; toast("Path done"); break; }
        if (e.button.button == SDL_BUTTON_RIGHT) { looking = true; flyTo.cancel(); SDL_SetWindowRelativeMouseMode(window, true); }
        if (e.button.button == SDL_BUTTON_LEFT) {
            const bool additive = (SDL_GetModState() & (SDL_KMOD_CTRL | SDL_KMOD_SHIFT)) != 0;
            if (!looking && bp.placing) { bpClickBuild((SDL_GetModState() & SDL_KMOD_SHIFT) != 0); break; }   // a whole building
            if (!looking && selectToolMouseDown(additive)) break;          // a gizmo handle, an object, or placing one
            lmbHeld = true; toolRepeat = 0.0f; useToolAtCursor(true);
        }
        break;

    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (mode == Mode::Play) { itemEvent(e); break; }
        if (e.button.button == SDL_BUTTON_RIGHT && mode == Mode::Editor) { looking = false; SDL_SetWindowRelativeMouseMode(window, false); }
        if (e.button.button == SDL_BUTTON_LEFT) { lmbHeld = false; objectsMouseUp(); }
        break;

    case SDL_EVENT_MOUSE_WHEEL:
        if (mode == Mode::Hub) break;
        if (mode == Mode::Play) { if (!paused) itemEvent(e); break; }
        if (mode == Mode::Editor && !io.WantCaptureMouse) {
            if (bp.placing) {                            // a blueprint: the wheel turns it
                if (e.wheel.y != 0.0f) bp.turns = (bp.turns + (e.wheel.y > 0 ? 1 : 3)) % 4;
            } else if (placingKit()) {                   // building: the wheel goes up and down a storey
                if (e.wheel.y != 0.0f && !kitDragging) kitLevelStep(e.wheel.y > 0 ? 1 : -1);
            } else if (!placingAsset.empty()) {          // placing: the wheel turns the model, with Shift it resizes it
                if (SDL_GetModState() & SDL_KMOD_SHIFT) placeScale = glm::clamp(placeScale * (1.0f + 0.1f * e.wheel.y), 0.25f, 4.0f);
                else placeYaw = std::fmod(placeYaw + 15.0f * e.wheel.y, 360.0f);
            } else if (tool != Tool::Select) {
                brushRadius = glm::clamp(brushRadius + e.wheel.y * 0.5f, 1.0f, 12.0f);
            }
        }
        break;
    }
}

void Application::useToolAtCursor(bool firstClick) {
    RayHit hit;
    if (!world.raycast(camera.position, cursorRay(), 300.0f, hit)) return;

    switch (tool) {
    case Tool::Carve:   world.applySphere(hit.position, brushRadius, CsgMode::Subtract); break;
    case Tool::Build:   world.applySphere(hit.position + hit.normal * (brushRadius * 0.5f), brushRadius, CsgMode::Union, brushMaterial); break;
    case Tool::Smooth:  world.smooth(hit.position, brushRadius * 1.25f, smoothStrength); break;
    case Tool::Flatten: world.flatten(hit.position, brushRadius * 1.5f); break;
    case Tool::Paint:   world.paint(hit.position, brushRadius, brushMaterial); break;
    case Tool::Stamp:
        if (firstClick) {
            if (world.stamp(stampPrefab, hit.position)) toast("Placed " + stampPrefab, Toast::Kind::Success);
            else toast("Prefab not found: " + stampPrefab, Toast::Kind::Warning);
        }
        break;
    case Tool::Bake:
        if (firstClick) {
            auto p = world.bake(hit.position, bakeRadius, bakeName);
            const std::string path = "prefabs/" + p->name + ".vxprefab";
            if (PrefabLibrary::saveToFile(*p, path)) {
                prefabs.add(p);
                stampPrefab = p->name;
                toast("Saved prefab '" + p->name + "'", Toast::Kind::Success);
            } else toast("Could not write " + path, Toast::Kind::Warning);
        }
        break;
    case Tool::Select:  break;                      // clicks are handled by selectToolMouseDown
    case Tool::Count: break;
    }
}

// ------------------------------------------------------------------ frame

void Application::update(float dt) {
    const bool* keys = SDL_GetKeyboardState(nullptr);
    const bool typing = ImGui::GetIO().WantTextInput;

    settingsTimer += dt;
    if (settingsTimer >= 1.5f) { settingsTimer = 0.0f; saveUserSettingsIfChanged(); }     // any change, from anywhere, is kept

    for (auto& t : toasts) t.age += dt;
    toasts.erase(std::remove_if(toasts.begin(), toasts.end(), [](const Toast& t) { return t.age > 4.0f; }), toasts.end());

    // ---- day/night
    if (mode == Mode::Hub) {
        timeOfDay = 17.2f;                                   // golden hour behind the hub
    } else if (timeFlowing && dayLengthMinutes > 0.0f) {
        timeOfDay += dt * 24.0f / (dayLengthMinutes * 60.0f);
        if (timeOfDay >= 24.0f) timeOfDay -= 24.0f;
    }
    if (ws.active) { updateWorkshop(dt); updateAudio(dt); return; }      // the Asset Workshop has no world to run
    if (cs.active) { updateCharacterStudio(dt); updateAudio(dt); return; }   // nor does the Character Studio
    updateTutorial(dt);
    updateSunDirection();
    updateObjects(dt);                                       // objects first: the player collides with them below

    // The sea is a world setting; the renderer and the character controller follow it.
    {
        const TerrainSettings& ts = world.settings();
        renderSettings.water = !world.isPlanetaryPrototype() && ts.water;
        renderSettings.waterLevel = ts.waterLevel;
        renderSettings.waterRadius = std::max(80.0f, float(world.loadRadius) * float(CHUNK_SIZE) + 8.0f);
        player.waterLevel = ts.water ? ts.waterLevel : -1e9f;
        // In play mode the grass parts around the player.
        renderSettings.interactor = (mode == Mode::Play) ? glm::vec4(player.position, 1.6f) : glm::vec4(0.0f, -1e5f, 0.0f, 0.0f);
    }

    if (mode == Mode::Hub) {
        // Slow cinematic orbit over the terrain behind the hub.
        hubOrbit += dt * 0.04f;
        const float r = 60.0f;
        const glm::vec3 c(0.0f, world.terrain().surfaceHeight(0, 0), 0.0f);
        camera.position = c + glm::vec3(std::cos(hubOrbit) * r, 28.0f, std::sin(hubOrbit) * r);
        camera.yaw = glm::degrees(hubOrbit) + 180.0f;
        camera.pitch = -18.0f;
        cursorHitValid = false;
    } else if (mode == Mode::Editor) {
        // A bookmark fly-to glides the camera; moving yourself takes the controls back.
        if (flyTo.active && settings.reduceMotion) { flyTo.t = flyTo.duration; flyTo.update(camera, 0.0f); }   // no glides: straight there
        if (flyTo.active) {
            const bool steering = looking && !typing && (keys[SDL_SCANCODE_W] || keys[SDL_SCANCODE_A] || keys[SDL_SCANCODE_S] ||
                                                           keys[SDL_SCANCODE_D] || keys[SDL_SCANCODE_E] || keys[SDL_SCANCODE_Q]);
            if (steering) flyTo.cancel(); else flyTo.update(camera, dt);
        }
        if (world.isPlanetaryPrototype())
            camera.setUpVector(world.localUp(camera.position));
        else if (camera.up != glm::vec3(0.0f, 1.0f, 0.0f))
            camera.setUpVector(glm::vec3(0.0f, 1.0f, 0.0f));
        if (looking && !typing && !flyTo.active) {
            const float speed = flySpeed * (keys[SDL_SCANCODE_LSHIFT] ? 3.0f : 1.0f) * dt;
            if (keys[SDL_SCANCODE_W]) camera.position += camera.front() * speed;
            if (keys[SDL_SCANCODE_S]) camera.position -= camera.front() * speed;
            if (keys[SDL_SCANCODE_A]) camera.position -= camera.right() * speed;
            if (keys[SDL_SCANCODE_D]) camera.position += camera.right() * speed;
            if (keys[SDL_SCANCODE_E]) camera.position += camera.up * speed;
            if (keys[SDL_SCANCODE_Q]) camera.position -= camera.up * speed;
        }
        if (lmbHeld && (tool == Tool::Carve || tool == Tool::Build || tool == Tool::Flatten || tool == Tool::Smooth || tool == Tool::Paint)) {
            toolRepeat += dt;
            if (toolRepeat > 0.08f) { toolRepeat = 0.0f; useToolAtCursor(false); }
        }
        // Brush preview target (skip while the mouse is over a panel).
        cursorHitValid = !ImGui::GetIO().WantCaptureMouse && world.raycast(camera.position, cursorRay(), 300.0f, cursorHit);
    } else {
        cursorHitValid = false;
        if (!paused) {
            glm::vec3 wish(0.0f);
            if (held(keys, Action::Forward)) wish += camera.flatFront();
            if (held(keys, Action::Back)) wish -= camera.flatFront();
            if (held(keys, Action::Right)) wish += camera.right();
            if (held(keys, Action::Left)) wish -= camera.right();
            if (glm::length(wish) > 0.0f) wish = glm::normalize(wish);
            if (gameOver) wish = glm::vec3(0.0f);                // the game is over: you stand still
            if (glm::length(wish) < 0.1f) runToggled = false;    // toggle-run stops when you stop
            player.dive = held(keys, Action::Dive);
            const bool running = settings.toggleRun ? runToggled : held(keys, Action::Run);
            player.update(world, wish, running, held(keys, Action::Jump) && !gameOver, dt);
            if (game) game->onPlayUpdate(*this, dt);
        }
        if (thirdPerson) updateThirdPersonCamera(); else camera.position = player.eye();
        updateItems(dt);                                     // after the camera is where the eyes are: the hand follows it exactly
        if (thirdPerson) drawPlayerBody(dt);                 // likewise, so your body never lags behind the camera
    }

    if (mode != Mode::Editor) flyTo.cancel();
    if (mode != Mode::Hub && !playerMode && !world.isPlanetaryPrototype()) {
        autosave.intervalMinutes = settings.autosaveMinutes;
        if (autosave.update(world, dt)) status = "Autosaved at " + Autosave::clockLabel(std::filesystem::file_time_type::clock::now());
    }
    updateAudio(dt);
    world.update(camera.position);
    renderer.sync(world);
    // C11: opt-in orbital visualization for the editor. This is a surface
    // preview only, not the editable volume near the player's feet. Stay on
    // the legacy renderer for all flat worlds and near-surface sculpting.
    std::vector<PlanetSurfaceDrawPacket> orbitalPackets;
    if (mode == Mode::Editor && world.isPlanetaryPrototype()) {
        const auto* ps=world.currentPlanetSettings();
        if (ps && glm::length(glm::dvec3(camera.position)) >
                  ps->planet.radiusMeters * 1.30) {
            if (!planetSurfaceRuntime)
                planetSurfaceRuntime=std::make_unique<PlanetSurfaceRuntime>(2);
            if (planetSurfaceGeneration!=world.generation()) {
                // Noise samplers are immutable and worker-owned. The orbital
                // surface ignores saved volume edits until mesh fusion lands.
                auto provider=std::make_shared<PlanetaryTerrainProvider>(*ps);
                const PlanetDefinition planet=ps->planet;
                if (planetSurfaceRuntime->configure(planet,
                      [provider, planet](const glm::dvec3& dir) {
                          return provider->shellRadius(dir)-planet.radiusMeters;
                      }, 24, std::max(0.5,planet.radiusMeters*0.003)))
                    planetSurfaceGeneration=world.generation();
            }
            if (planetSurfaceGeneration==world.generation()) {
                PlanetLodSettings lod;
                lod.maxTiles=96;
                lod.maxLevel=6;
                lod.viewportHeightPixels=720;
                lod.verticalFovDegrees=camera.fovDegrees;
                WorldPosition eye{};
                if (tryWorldPositionFromMeters(glm::dvec3(camera.position),eye)==CoordError::Ok)
                    planetSurfaceRuntime->update(glm::dvec3(camera.position),
                         WorldPosition{}, eye, lod, 20000.0, orbitalPackets);
            }
        }
    } else {
        planetSurfaceRuntime.reset();
        planetSurfaceGeneration=~std::uint32_t{0};
    }
    renderer.setPlanetSurfacePackets(std::move(orbitalPackets));
}

// ------------------------------------------------------------------ audio

namespace {
const char* stepClipFor(MaterialId m) {
    switch (m) {
        case MAT_GRASS: return "step_grass";
        case MAT_DIRT:  return "step_dirt";
        case MAT_STONE: return "step_stone";
        case MAT_SAND:  return "step_sand";
        case MAT_SNOW:  return "step_snow";
        case MAT_WOOD:  return "step_wood";
        case MAT_METAL: return "step_metal";
        case MAT_BRICK: return "step_brick";
        default:        return "step_dirt";
    }
}
float smooth01(float a, float b, float x) { const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }
float frand() { static std::uint32_t s = 0x1234567u; s = s * 1664525u + 1013904223u; return float(s >> 8) * (1.0f / 16777216.0f); }
} // namespace

void Application::playSfxAt(const std::string& clip, const glm::vec3& pos, float volume, float pitch) {
    PlayParams p;
    p.spatial = true; p.position = pos; p.volume = volume; p.pitch = pitch;
    p.minDistance = 6.0f; p.maxDistance = 120.0f;
    audio.playVariant(clip, p);
}

void Application::playUiSound(const char* clip, float volume, float pitch) {
    PlayParams p;
    p.bus = Bus::Ui; p.volume = volume; p.pitch = pitch;
    audio.playVariant(clip, p);
}

void Application::onWorldEdit(const EditOp& op) {
    noteTerrainEdit();                                  // the shared undo history
    if (mode == Mode::Hub) return;
    const float now = float(SDL_GetTicks()) * 0.001f;
    if (now - lastEditSound < 0.09f) return;            // a held brush ticks, it doesn't machine-gun
    lastEditSound = now;
    const char* clip = "dig";
    float vol = 0.8f, pitch = 1.0f;
    switch (op.kind) {
        case EditOp::Kind::Sphere:  clip = op.mode == CsgMode::Union ? "build" : "dig"; break;
        case EditOp::Kind::Stamp:   clip = "stamp"; vol = 0.9f; break;
        case EditOp::Kind::Flatten: clip = "smooth"; vol = 0.7f; pitch = 0.8f; break;
        case EditOp::Kind::Paint:   clip = "paint"; vol = 0.6f; break;
        case EditOp::Kind::Smooth:  clip = "smooth"; vol = 0.6f; break;
    }
    // Bigger brushes sound bigger: lower and a touch louder.
    pitch *= std::clamp(1.25f - op.radius * 0.05f, 0.7f, 1.3f) * (0.93f + 0.14f * frand());
    vol *= std::clamp(0.7f + op.radius * 0.05f, 0.7f, 1.2f);
    playSfxAt(clip, op.kind == EditOp::Kind::Stamp ? op.center : op.center, vol, pitch);
}

void Application::measureSurroundings() {
    // A handful of cheap probes, a few times a second: how enclosed are we, how near is the
    // sea, how green is the ground. The ambience crossfades toward whatever this says.
    const TerrainSettings& ts = world.settings();
    const glm::vec3 p = camera.position;
    AmbienceInputs& in = ambienceIn;

    // Enclosure: rays up, diagonally up and sideways. Rock close overhead = a cave.
    {
        constexpr float kReach = 22.0f;
        auto probe = [&](glm::vec3 dir) {
            RayHit h;
            if (!world.raycast(p, glm::normalize(dir), kReach, h)) return 0.0f;
            return std::clamp(1.0f - h.distance / kReach, 0.0f, 1.0f);
        };
        float score = 3.0f * probe({ 0, 1, 0 });
        for (int k = 0; k < 4; ++k) {
            const float a = float(k) * glm::half_pi<float>() + 0.4f;
            score += 1.5f * probe({ std::cos(a), 1.0f, std::sin(a) });
            score += 1.0f * probe({ std::cos(a), 0.0f, std::sin(a) });
        }
        in.enclosure = smooth01(0.30f, 0.65f, score / 13.0f);
    }

    // Water: the sea is a plane, so "near water" is "the terrain dips below sea level nearby".
    in.water = 0.0f;
    if (ts.water) {
        const TerrainGenerator& t = world.terrain();
        const float lvl = ts.waterLevel;
        float nearest = t.surfaceHeight(p.x, p.z) < lvl ? 0.0f : 1e9f;
        for (float r : { 6.0f, 14.0f, 28.0f, 50.0f }) {
            if (nearest < 1e9f) break;
            for (int k = 0; k < 12; ++k) {
                const float a = float(k) * glm::two_pi<float>() / 12.0f + r * 0.37f;
                if (t.surfaceHeight(p.x + std::cos(a) * r, p.z + std::sin(a) * r) < lvl) { nearest = r; break; }
            }
        }
        if (nearest < 1e9f) in.water = (1.0f - smooth01(0.0f, 60.0f, nearest)) * (1.0f - smooth01(10.0f, 45.0f, p.y - lvl));
    }

    // Greenery: how much of the ground around us is meadow (not sand, snow or sea floor).
    {
        const TerrainGenerator& t = world.terrain();
        const float lo = sandLevelFor(ts), hi = snowLevelFor(ts);
        int green = 0, total = 0;
        for (int k = -1; k < 8; ++k) {
            const float a = float(k) * glm::two_pi<float>() / 8.0f;
            const float r = k < 0 ? 0.0f : 12.0f;
            const float h = t.surfaceHeight(p.x + std::cos(a) * r, p.z + std::sin(a) * r);
            ++total;
            if (h > lo && h < hi && (!ts.water || h > ts.waterLevel + 0.5f)) ++green;
        }
        in.greenery = float(green) / float(total);
    }

    // Wind: stronger the higher you are in the world, scaled by the grass wind setting.
    {
        const float worldBottom = float(world.minChunkY * CHUNK_SIZE), worldTop = float((world.maxChunkY + 1) * CHUNK_SIZE);
        const float h = (p.y - worldBottom) / std::max(worldTop - worldBottom, 1.0f);
        const float w = 0.15f + 0.85f * smooth01(0.35f, 0.95f, h);
        in.wind = std::clamp(w * (0.35f + 0.65f * renderSettings.windStrength), 0.0f, 1.0f);
    }
}

void Application::updatePlayerSounds(float dt) {
    const glm::vec3 v = player.velocity;
    const float hs = glm::length(glm::vec2(v.x, v.z));
    const glm::vec3 feet = player.position;
    const bool wading = !player.swimming && player.position.y < player.waterLevel - 0.05f;

    PlayParams own;                                // the player's own sounds are centred
    if (player.swimming && !player.wasSwimming) {
        own.volume = std::clamp(-prevVelY / 14.0f + 0.35f, 0.35f, 1.0f);
        audio.play("splash", own);
    }
    if (player.grounded && !wasGrounded && prevVelY < -5.0f) {
        own.volume = std::clamp(-prevVelY / 26.0f, 0.2f, 1.0f);
        audio.play(wading ? "splash" : "land", own);
        stepAccum = 0.0f;
    }
    if (!player.grounded && wasGrounded && v.y > 2.5f && !player.swimming) {
        own.volume = 0.5f;
        audio.play("jump", own);
    }

    if (player.swimming) {
        if (hs > 0.8f || std::fabs(v.y) > 1.0f) {
            swimAccum += dt;
            if (swimAccum > 0.8f) { swimAccum = 0.0f; own.volume = 0.5f; own.pitch = 0.9f + 0.2f * frand(); audio.playVariant("swim", own); }
        }
    } else {
        swimAccum = 0.6f;
        if (player.grounded && hs > 1.2f) {
            stepAccum += hs * dt;
            const float stride = 2.0f + 0.1f * hs;
            if (stepAccum >= stride) {
                stepAccum -= stride;
                own.volume = 0.55f + 0.05f * hs / 6.0f + 0.08f * frand();
                own.pitch = 0.93f + 0.14f * frand();
                if (wading) { own.volume *= 0.9f; audio.playVariant("step_water", own); }
                else audio.playVariant(stepClipFor(world.surfaceMaterialAt(feet + glm::vec3(0, 0.3f, 0))), own);
            }
        } else if (!player.grounded) {
            stepAccum = 0.5f * (2.0f + 0.1f * hs);      // the first step after landing comes quickly
        }
    }
    wasGrounded = player.grounded;
    prevVelY = v.y;
}

void Application::updateAudio(float dt) {
    audio.setMasterVolume(settings.volMaster);
    audio.setBusVolume(Bus::Sfx, settings.volSfx);
    audio.setBusVolume(Bus::Ambient, settings.volAmbient);
    audio.setBusVolume(Bus::Music, settings.volMusic);
    audio.setBusVolume(Bus::Ui, settings.volUi);
    const bool unfocused = settings.muteUnfocused && window && !(SDL_GetWindowFlags(window) & SDL_WINDOW_INPUT_FOCUS);
    audio.setMuted(settings.muteAudio || unfocused);

    audio.setListener(camera.position, camera.front());
    audio.setUnderwater(renderSettings.water && camera.position.y < renderSettings.waterLevel);

    measureTimer -= dt;
    if (measureTimer <= 0.0f) { measureTimer = 0.25f; measureSurroundings(); }
    ambienceIn.listener = camera.position;
    ambienceIn.underwater = renderSettings.water && camera.position.y < renderSettings.waterLevel;
    ambienceIn.daylight = smooth01(-0.10f, 0.30f, -renderSettings.sunDirection.y);   // sun elevation (sine)

    ambience.enabled = !ws.active && !cs.active && (mode == Mode::Hub || mode == Mode::Play || (mode == Mode::Editor && settings.ambienceInEditor));
    ambience.volume = mode == Mode::Hub ? 0.55f : 1.0f;
    ambience.update(audio, ambienceIn, dt);

    if (mode == Mode::Play && !paused) updatePlayerSounds(dt);
}

void Application::runDemoSetup() {
    // Opt-in local planet demonstration. This is deliberately not the default
    // sandbox: legacy world saves and player physics still assume global Y-up.
    // Use --demo planet or --demo planetclean --screenshot-and-exit 240.
    if (demo == "planet" || demo == "planetclean") {
        if (mode == Mode::Hub) openGame(nullptr);
        PlanetaryTerrainSettings settings;
        settings.planet.radiusMeters = 96.0;
        settings.planet.terrainAmplitudeMeters = 5.0;
        settings.planet.seaLevelMeters = 0.0;
        settings.hillFrequency = 2.5f;
        settings.caveAmplitude = 0.0f;
        world.planetLoadRadius = 2;
        world.startPlanetaryPrototype(settings);
        // Fly the editor camera around a small patch of the +Y hemisphere.
        // Keep within a few chunk radii because the prototype has no LOD yet.
        camera.position = glm::vec3(25.0f, 122.0f, 36.0f);
        camera.setUpVector(world.localUp(camera.position));
        camera.lookAt(glm::vec3(0.0f, 94.0f, 0.0f));
        timeOfDay = 13.0f;
        timeFlowing = false;
        renderSettings.trees = false;
        renderSettings.grass = false;
        renderSettings.water = false;
        uiHidden = (demo == "planetclean");
        cursorHitValid = false;
        SDL_SetWindowTitle(window, "Spire Engine - Experimental Planetary Editor (VXPL manual save)");
        toast("Planetary prototype: manual VXPL save supported; autosave disabled.");
        return;
    }
    // Only used by --demo to produce reproducible screenshots for testing.
    RayHit hit;
    if (demo.rfind("ws", 0) == 0) { setupWorkshopDemo(); return; }          // --demo ws...: the Asset Workshop
    if (demo.rfind("item", 0) == 0) { setupItemDemo(); return; }            // --demo item...: the Item Builder and held items
    if (demo.rfind("mat_", 0) == 0) { setupMaterialDemo(); return; }         // --demo mat_...: the richer materials
    if (demo.rfind("kit_", 0) == 0) { setupKitDemo(); return; }
    if (demo.rfind("bp_", 0) == 0) { setupBlueprintDemo(); return; }
    if (demo.rfind("cc_", 0) == 0 || demo.rfind("hm_", 0) == 0) { setupCharacterDemo(); return; }
    if (demo.rfind("npc_", 0) == 0) { setupNpcDemo(); return; }
    if (demo.rfind("rule_", 0) == 0) { setupRuleDemo(); return; }
    if (demo.rfind("game_", 0) == 0) { setupGameDemo(); return; }
    if (demo.rfind("share_", 0) == 0) { setupShareDemo(); return; }
    if (demo.rfind("polish_", 0) == 0) { setupPolishDemo(); return; }
    if (demo == "soak_selftest") { runSoakSelfTest(); return; }          // 1.0: a long rough session    // --demo polish_...: tutorial, controls, accessibility      // --demo share_...: packing a game to share        // --demo game_...: game rules and templates        // --demo rule_...: rules and gadgets          // --demo npc_...: people living their lives          // --demo cc_...: characters          // --demo bp_...: the Blueprint Tool              // --demo kit_...: building kits
    if (demo.rfind("time", 0) == 0) {                     // --demo time06.5 etc.
        timeOfDay = float(std::atof(demo.c_str() + 4));
        timeFlowing = false;
        int w, h; SDL_GetWindowSize(window, &w, &h);
        mouseX = w * 0.58f; mouseY = h * 0.62f;
        return;
    }
    if (demo.rfind("water", 0) == 0) {                    // --demo water | waterclean | waterunder
        // Find the lowest ground near the origin and look at it from the shore.
        glm::vec2 best(0.0f); float lowest = 1e9f;
        for (int z = -100; z <= 100; z += 4)
            for (int x = -100; x <= 100; x += 4) {
                const float hgt = world.terrain().surfaceHeight(float(x), float(z));
                if (hgt < lowest) { lowest = hgt; best = { float(x), float(z) }; }
            }
        const float lvl = world.settings().waterLevel;
        const glm::vec3 lake(best.x, lvl, best.y);
        camera.position = lake + glm::vec3(24.0f, 9.0f, 20.0f);
        camera.lookAt(lake + glm::vec3(0, -1.0f, 0));
        if (demo == "waterunder") { camera.position = lake + glm::vec3(10.0f, -3.5f, 8.0f); camera.lookAt(lake + glm::vec3(0, -1.5f, 0)); }
        timeOfDay = 16.0f; timeFlowing = false;
        if (demo != "water") { uiHidden = true; mouseX = mouseY = -1000.0f; }
        return;
    }
    if (demo == "hub") return;
    if (demo == "hubopen") { requestOpenGame(findGame("vanguard")); return; }   // open a game from the running hub
    if (demo == "play" || demo == "pause") {
        setMode(Mode::Play);
        if (demo == "pause") setPaused(true);
    } else if (world.raycast(camera.position, camera.front(), 200.0f, hit)) {
        world.applySphere(hit.position, 5.0f, CsgMode::Subtract);
        world.stamp("stone_pillar", hit.position + glm::vec3(10, 0, 0));
        int w, h; SDL_GetWindowSize(window, &w, &h);
        mouseX = w * 0.58f; mouseY = h * 0.62f;
        brushRadius = 4.0f;
        if (demo.rfind("settings", 0) == 0) {                      // settings | settings_gfx | settings_display | settings_audio
            openSettingsTab(demo == "settings_gfx" ? 1 : demo == "settings_display" ? 2 : demo == "settings_audio" ? 3 : 0);
        }
        if (demo == "gfxlow" || demo == "gfxmedium" || demo == "gfxultra") {          // the same view at another quality, UI hidden
            setQuality(demo == "gfxlow" ? Quality::Low : demo == "gfxmedium" ? Quality::Medium : Quality::Ultra);
            uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        }
        if (demo == "gfxcustom") { GraphicsValues g = qualityPreset(Quality::Medium); g.renderScale = 0.9f; setGraphics(g); openSettingsTab(1); }
        if (demo == "uiscale") { settings.display.uiScale = 1.4f; applyUiScale(); }
        if (demo == "displaytest") {                                      // exercise the window-mode code and report
            std::cerr << "[displaytest] monitors=" << listMonitors().size() << "\n";
            toggleFullscreen();
            std::cerr << "[displaytest] after F11 flags fullscreen=" << ((SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN) != 0) << "\n";
            toggleFullscreen();
            int ww, wh; SDL_GetWindowSize(window, &ww, &wh);
            std::cerr << "[displaytest] back windowed " << ww << "x" << wh << " fullscreen=" << ((SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN) != 0) << "\n";
        }
        if (demo == "world") forceInspectorTab = 1;
        if (demo == "env") { forceInspectorTab = 2; timeOfDay = 17.4f; timeFlowing = false; }
        if (demo == "stamp") tool = Tool::Stamp;
        if (demo == "palette") { paletteOpen = true; paletteFocus = true; std::snprintf(paletteQuery, sizeof paletteQuery, "sa"); }
        if (demo == "stacked") applyLayout(Layout::Stacked);
        if (demo == "twosides") applyLayout(Layout::TwoSides);
        if (demo == "bookmarks") {
            forceInspectorTab = 0;
            bookmarks[0] = { true, "Spawn hill", camera.position, camera.yaw, camera.pitch };
            bookmarks[1] = { true, "The lake", camera.position + glm::vec3(30, -10, 20), camera.yaw + 40.0f, -15.0f };
            bookmarks[2] = { true, "Cave mouth", camera.position + glm::vec3(-20, -25, 10), camera.yaw - 70.0f, -5.0f };
        }
        if (demo == "objselftest") { runObjectSelfTest(); }
        else if (demo == "nature" || demo == "naturefar") {         // 1.3: trees up close, and a landscape with its forests
            auto groundAt = [&](float x, float z) {
                RayHit g;
                return world.raycast(glm::vec3(x, 250.0f, z), glm::vec3(0, -1, 0), 500.0f, g) ? g.position.y : hit.position.y;
            };
            glm::vec3 c = hit.position + glm::vec3(-3.0f, 0.0f, 14.0f);
            if (demo == "nature") {
                c.y = groundAt(c.x, c.z) - 1.0f;
                for (int i = 0; i < 3; ++i) world.flatten(c, 17.0f);
                world.paint(c, 15.0f, MAT_GRASS);
                const float y = groundAt(c.x, c.z);
                auto put = [&](const char* asset, float dx, float dz, float yaw, float scale) { placeObject(asset, glm::vec3(c.x + dx, y - 0.1f, c.z + dz), yaw, scale); };
                put("tree oak", -9.0f, -7.0f, 20.0f, 1.0f);
                put("tree pine", 0.5f, -11.0f, 0.0f, 0.9f);
                put("tree birch", 8.0f, -6.0f, 40.0f, 1.0f);
                put("bush", -3.5f, -1.5f, 0.0f, 1.0f);
                put("bush", 4.0f, -0.5f, 70.0f, 0.8f);
                camera.position = c + glm::vec3(0.0f, 2.6f, 13.0f);
                camera.lookAt(c + glm::vec3(0.0f, 4.0f, -6.0f));
            } else {
                camera.position = c + glm::vec3(0.0f, 35.0f, 0.0f);
                camera.lookAt(c + glm::vec3(60.0f, 10.0f, -120.0f));
            }
            commitScene("Demo");
            selection.clear();
            uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        }
        else if (demo.rfind("obj", 0) == 0) {                      // obj | objrotate | objscale | objlayout | objplace | objclean | objplay
            auto groundAt = [&](float x, float z) {
                RayHit g;
                return world.raycast(glm::vec3(x, 250.0f, z), glm::vec3(0, -1, 0), 500.0f, g) ? g.position.y : hit.position.y;
            };
            // A flat plaza a little way off, with a handful of objects on it.
            glm::vec3 c = hit.position + glm::vec3(-3.0f, 0.0f, 14.0f);
            c.y = groundAt(c.x, c.z) - 1.0f;
            for (int i = 0; i < 3; ++i) world.flatten(c, 17.0f);
            const float plazaY = groundAt(c.x, c.z);
            auto put = [&](const char* asset, float dx, float dz, float yaw, float scale) {
                return placeObject(asset, glm::vec3(c.x + dx, plazaY - 0.3f, c.z + dz), yaw, scale);
            };
            put("stone_arch", 0.0f, -7.0f, 0.0f, 1.0f);
            const ObjectId cr1 = put("crate", -9.0f, 1.0f, 15.0f, 1.0f);
            const ObjectId cr2 = put("crate", -9.0f, 4.5f, -10.0f, 0.8f);
            put("steps", 4.0f, 3.0f, 200.0f, 1.0f);
            put("lamp_post", 6.5f, -3.5f, 0.0f, 1.0f);
            put("lamp_post", -6.5f, -3.5f, 0.0f, 1.0f);
            const ObjectId rock = put("boulder", -14.0f, 9.0f, 0.0f, 1.2f);
            if (SceneObject* r = scene.mutate(rock)) { r->motion.kind = MotionSettings::Kind::Spin; r->motion.speed = 30.0f; }
            camera.position = c + glm::vec3(-3.0f, 14.0f, 31.0f);
            camera.lookAt(c + glm::vec3(0.0f, 1.0f, -3.0f));
            commitScene("Demo");
            const ObjectId grp = scene.group({ cr1, cr2 }, "Crates");
            commitScene("Group crates");
            if (demo == "objlayout") applyLayout(Layout::Objects);
            if (demo != "objclean" && demo != "objplace") { setSelection({ grp }); }
            else selection.clear();
            if (demo == "objplay") { setMode(Mode::Play); }
            showHints = false;
            if (demo == "objprops" || demo == "objassets") { settleFronts = { "Details", "Shelf" }; settleFrames = 5; }
            if (demo == "objprops") setSelection({ rock });
            tool = Tool::Select;
            gizmoMode = demo == "objrotate" ? GizmoMode::Rotate : demo == "objscale" ? GizmoMode::Scale : GizmoMode::Move;
            if (demo == "objplace") { placingAsset = "stone_arch"; mouseX = viewRect.x + viewRect.w * 0.5f; mouseY = viewRect.y + viewRect.h * 0.5f; }
            if (demo == "objclean") { uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f; }
            if (demo == "objwheel") {                                // the quick wheel, the pointer flicked left onto Move
                setSelection({ rock });
                wheel.open = true; wheel.x = viewRect.x + viewRect.w * 0.5f; wheel.y = viewRect.y + viewRect.h * 0.5f;
                mouseX = wheel.x - 100.0f * ui::scale(); mouseY = wheel.y + 6.0f;
            }
            if (demo == "objpeople") { setEditMode(EditMode::People); setSelection({}); }
            if (demo == "objlogic") { setEditMode(EditMode::Logic); setSelection({ grp }); }
            timeOfDay = 15.0f; timeFlowing = false;
        }
        if (demo == "recovery") { recovery = AutosaveInfo{ "", "14:32", {}, 0 }; openRecovery = true; }
        if (demo == "materials" || demo == "build" || demo == "materialsclean") {      // a little showcase of the material system
            const MaterialId mats[3] = { MAT_BRICK, MAT_WOOD, MAT_METAL };
            for (int i = 0; i < 3; ++i)
                for (int k = 0; k < 3; ++k)
                    world.applySphere(hit.position + glm::vec3(-9.0f + 9.0f * i, 2.0f + 2.2f * k, -4.0f), 2.6f, CsgMode::Union, mats[i]);
            world.paint(hit.position + glm::vec3(-6, 0, 7), 4.5f, MAT_SAND);
            world.paint(hit.position + glm::vec3(4, 0, 8), 3.5f, MAT_SNOW);
            for (int i = 0; i < 6; ++i) world.smooth(hit.position + glm::vec3(0, 2, -4), 9.0f, 1.0f);
            tool = demo == "build" ? Tool::Build : Tool::Paint;
            brushMaterial = MAT_BRICK;
            if (demo == "materialsclean") { uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f; }
        }
    }
    if (game) game->onDemo(*this, demo.c_str());
}

// Hands the renderer the texture pack chosen in Settings (or none). A missing folder quietly means the built-in look.
void Application::applyTexturePack() {
    appliedTexturePack = settings.texturePack;
    shownPackProblems = 0;
    if (settings.texturePack.empty()) { renderer.useTexturePack(nullptr); return; }
    auto pack = std::make_shared<TexturePack>(scanTexturePack(texturePackRoot() + "/" + settings.texturePack));
    if (pack->count() == 0) {
        toast("Texture pack \"" + settings.texturePack + "\" has no material folders yet, so the built-in textures stay.", Toast::Kind::Warning);
        renderer.useTexturePack(nullptr);
        return;
    }
    toast("Loading texture pack \"" + pack->name + "\" (" + std::to_string(pack->count()) + " materials)...");
    renderer.useTexturePack(std::move(pack));
}

void Application::run() {
    Uint64 last = SDL_GetPerformanceCounter();
    while (running) {
        // Planet transitions are deferred to the frame boundary so no UI
        // callback can invalidate world data while it is being rendered.
        applyPlanetRequests();
        const Uint64 now = SDL_GetPerformanceCounter();
        const float dt = std::min(0.1f, float(now - last) / float(SDL_GetPerformanceFrequency()));
        last = now;

        // A screenshot run (not a self test) waits for the full textures before its picture, so it shows the real look.
        if (settings.texturePack != appliedTexturePack) applyTexturePack();
        if (autoScreenshotFrame >= 0 && frameCounter == autoScreenshotFrame - 3 && demo.find("selftest") == std::string::npos) { renderer.finishTextures(); treeModels.finish(); }
        if (openGameRequested) { openGameRequested = false; openGame(requestedGame, requestedPlay); }
        if (sandboxRequested)  {
            sandboxRequested = false; openGame(nullptr);
            if (hubTemplate == -2) cmdNewBlankCanvas();
            else if (hubTemplate == -3) cmdNewWorld();
            else if (hubTemplate >= 0) buildGameTemplate(GameTemplate(hubTemplate));
            hubTemplate = -1;
        }
        if (closeGameRequested) { closeGameRequested = false; closeGame(); }

        SDL_Event e;
        while (SDL_PollEvent(&e)) handleEvent(e);
        if (!demo.empty() && frameCounter == 60) {
            runDemoSetup();
            if (demo.find("selftest") != std::string::npos) running = false;   // a self test has printed its result: done
        }
        update(dt);

        if (!pendingLayoutFile.empty()) {            // a saved layout is loaded between frames, never in the middle of one
            ImGui::LoadIniSettingsFromDisk(pendingLayoutFile.c_str());
            pendingLayoutFile.clear();
            layoutDefaultsBuilt = true;
        }

        // Where the 3D view goes: the whole window, or in the editor the free space between panels.
        int w, h, ww, wh;
        SDL_GetWindowSizeInPixels(window, &w, &h);
        SDL_GetWindowSize(window, &ww, &wh);
        if (mode != Mode::Editor || uiHidden) viewRect = { 0.0f, 0.0f, float(ww), float(wh) };
        const float sx = ww > 0 ? float(w) / float(ww) : 1.0f, sy = wh > 0 ? float(h) / float(wh) : 1.0f;
        const int vw = std::max(1, int(std::lround(viewRect.w * sx))), vh = std::max(1, int(std::lround(viewRect.h * sy)));
        const int vx = int(std::lround(viewRect.x * sx)), vy = h - int(std::lround((viewRect.y + viewRect.h) * sy));   // GL origin is bottom-left
        Camera view = camera;                                  // a blast shakes what you see, not where you aim
        if (settings.reduceMotion) {}                             // no shaking
        else if (mode == Mode::Play && inventory.enabled) { const glm::vec3 sh = inventory.shakeAngles(); view.yaw += sh.x; view.pitch = glm::clamp(view.pitch + sh.y, -89.0f, 89.0f); }
        else if (ws.active && ws.rangeOn && ws.range) { const glm::vec3 sh = ws.range->items.shakeAngles(); view.yaw += sh.x; view.pitch = glm::clamp(view.pitch + sh.y, -89.0f, 89.0f); }
        renderer.render(view, vw, vh, renderSettings, vx, vy);
        viewProj = view.projection(float(vw) / float(vh)) * view.view();

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL3_NewFrame();
        ImGui::NewFrame();
        if (ws.active) drawWorkshopUI();
        else if (cs.active) drawCharacterStudioUI();
        else if (mode == Mode::Hub) drawHubUI();
        else if (mode == Mode::Play) drawPlayUI();
        else drawEditorUI();
        if (!ws.active && !cs.active && (mode == Mode::Hub || mode == Mode::Editor))
            { drawNewProjectWizard(); drawPlanetCreatorUI(); drawPlanetOpenConfirmation(); }
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        ++frameCounter;
        if (frameCounter == autoScreenshotFrame) { screenshotRequested = true; running = false; }
        if (screenshotRequested) { saveScreenshot(w, h); screenshotRequested = false; }
        SDL_GL_SwapWindow(window);

        // Frame-rate limit: sleep for most of the wait, spin for the last moment so frames stay even.
        if (autoScreenshotFrame < 0) {
            const Uint32 wf = SDL_GetWindowFlags(window);
            const int cap = effectiveFpsCap(settings.display.fpsCap, settings.display.reduceInBackground,
                                            (wf & SDL_WINDOW_INPUT_FOCUS) != 0, (wf & SDL_WINDOW_MINIMIZED) != 0);
            if (cap > 0) {
                const double freq = double(SDL_GetPerformanceFrequency());
                for (;;) {
                    const double wait = frameWaitSeconds(double(SDL_GetPerformanceCounter() - now) / freq, cap);
                    if (wait <= 0.0) break;
                    if (wait > 0.002) SDL_DelayNS(Uint64((wait - 0.0015) * 1.0e9));
                }
            }
        }
    }
}

void Application::saveScreenshot(int w, int h) {
    std::vector<unsigned char> px(size_t(w) * h * 4);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    SDL_Surface* surf = SDL_CreateSurface(w, h, SDL_PIXELFORMAT_ABGR8888);
    if (!surf) return;
    for (int y = 0; y < h; ++y)   // OpenGL rows are bottom-up
        std::memcpy(static_cast<unsigned char*>(surf->pixels) + size_t(y) * surf->pitch, px.data() + size_t(h - 1 - y) * w * 4, size_t(w) * 4);
    std::filesystem::create_directories("screenshots");
    int n = 0;
    std::string path;
    do { path = "screenshots/shot_" + std::to_string(n++) + ".bmp"; } while (std::filesystem::exists(path));
    if (SDL_SaveBMP(surf, path.c_str())) toast("Screenshot saved: " + path, Toast::Kind::Success);
    SDL_DestroySurface(surf);
}

void Application::shutdown() {
    if (imguiReady) saveUserSettingsIfChanged();
    if (game && imguiReady) game->onShutdown(*this);
    ownedGame.reset();
    game = nullptr;
    if (autosave.active()) { saveEditorState(); autosave.endSession(); }   // a clean exit: no recovery prompt next time
    ambience.stopAll(audio);
    audio.shutdown();        // stop the audio thread before SDL goes away
    world.stop();            // join workers before anything else goes away
    if (glReady) { releaseAssetThumbnails(); forgetPersonThumbnails(); renderer.shutdown(); }     // GL objects need the context alive
    if (imguiReady) {
        ImGui_ImplOpenGL3_Shutdown();
        ImGui_ImplSDL3_Shutdown();
        ImGui::DestroyContext();
    }
    if (glContext) SDL_GL_DestroyContext(glContext);
    if (window) SDL_DestroyWindow(window);
    SDL_Quit();
}

} // namespace px
