#pragma once
// Spire Engine UI kit: theme, fonts, colours and the custom widgets every panel shares.
// Keep ad-hoc styling out of the panels themselves; add it here instead.
//
// The look is "Obsidian & Neon": near-black stone greys carry everything; two lit colours each
// mean one thing only. Neon (col::accent) = "selected / you are here". Fuse (col::fuse) = "live":
// the Play button and the frame while the game runs. Axes are red / green / blue as in every 3D tool.
#include <cfloat>
#include <string>
#include <imgui.h>

namespace px::ui {

struct Fonts {
    ImFont* body    = nullptr;   // Geist Medium 14
    ImFont* bold    = nullptr;   // Geist SemiBold 14
    ImFont* small   = nullptr;   // Geist Medium 12
    ImFont* title   = nullptr;   // Geist SemiBold 17
    ImFont* display = nullptr;   // Geist SemiBold 32 (pause menu, big HUD numbers)
    ImFont* mono    = nullptr;   // Geist Mono Medium 12.5 (numbers, the status bar, key caps)
    ImFont* brand   = nullptr;   // Unbounded Bold 15 (the SPIRE wordmark)
};
extern Fonts fonts;

// Palette
namespace col {
constexpr ImU32 bg        = IM_COL32( 11,  12,  16, 255);   // obsidian: the ground everything sits on
constexpr ImU32 bar       = IM_COL32( 16,  18,  23, 255);   // basalt: the top bar, tool strip, shelf
constexpr ImU32 panel     = IM_COL32( 21,  23,  29, 255);   // slate: panels
constexpr ImU32 panelAlt  = IM_COL32( 27,  30,  38, 255);   // raised: cards, hovered rows
constexpr ImU32 field     = IM_COL32( 14,  16,  21, 255);   // inputs
constexpr ImU32 border    = IM_COL32( 35,  39,  51, 255);   // seams between things
constexpr ImU32 line      = IM_COL32( 30,  34,  43, 255);   // the faint rule between sections
constexpr ImU32 text      = IM_COL32(232, 234, 240, 255);   // silver
constexpr ImU32 textDim   = IM_COL32(138, 144, 160, 255);   // ash: quiet text
constexpr ImU32 faint     = IM_COL32( 92,  98, 114, 255);   // key letters, counts
constexpr ImU32 accent    = IM_COL32( 61, 224, 255, 255);   // neon: selected / you are here
constexpr ImU32 accentDim = IM_COL32( 61, 224, 255,  36);   // neon wash behind a selected thing
constexpr ImU32 onAccent  = IM_COL32(  3,  22,  28, 255);   // text on a neon fill
constexpr ImU32 fuse      = IM_COL32(255, 122,  47, 255);   // fuse: live (Play, the playing frame)
constexpr ImU32 onFuse    = IM_COL32( 26,  12,   3, 255);
// Good, careful and bad: these three change with Settings > Accessibility > colour-blind friendly colours.
inline ImU32 success      = IM_COL32(108, 212, 106, 255);
inline ImU32 warning      = IM_COL32(244, 184,  72, 255);
inline ImU32 danger       = IM_COL32(242, 106, 106, 255);
}
// Colours red-green colour-blind people can tell apart (the Okabe-Ito palette) for good / careful / bad, the gizmo's
// axes and the like. Off: the usual colours.
void setColourBlindFriendly(bool on);
bool colourBlindFriendly();
ImU32 axisColour(int axis);          // x, y, z
ImU32 withAlpha(ImU32 c, float a);

void setup(const std::string& fontDir, float dpiScale);
float scale();                       // every pixel size is multiplied by this: system DPI x the user's UI scale
float uiScale();                     // just the user's part (Settings > Display), 1 = normal
void setUiScale(float user);         // safe at any time; call between frames
void pushFont(ImFont* f);
void popFont();

enum class Icon { Carve, Build, Smooth, Flatten, Paint, Stamp, Bake, Undo, Redo, Play, Pause, Save, Open, Sun, Globe, Gear, User,
                  Select, Eye, EyeOff, Lock, Unlock, Move, Rotate, Scale, Trash, Copy, Plus, Pin, Mirror, Hammer,
                  // added with the 1.1 layout
                  Mountain, House, Bolt, Grid, Blueprint, Search, Share, ChevronDown, ChevronRight, Magnet, Camera,
                  Crowd, Flag, Box, Wand, Stop, Power };
void drawIcon(ImDrawList* dl, Icon icon, ImVec2 center, float size, ImU32 color);

// The Black Spire mark: a spire on its tower, `height` tall, standing on `base` (bottom centre).
void drawSpireMark(ImDrawList* dl, ImVec2 base, float height, ImU32 color);

// Inside a menu bar: the spire, SPIRE, a thin rule and the screen's name ("Asset Workshop"). Every full screen starts
// with it, so you always know where you are.
void screenHeader(const char* screenName);

// Square tool button with an icon, selected state and a tooltip ("Name  [key]").
bool toolButton(const char* id, Icon icon, bool selected, float size, const char* tooltip, const char* shortcut);

// A tool on the left strip: icon over its name, its key in the corner, a neon bar on the edge when chosen.
bool stripButton(const char* id, Icon icon, const char* label, const char* key, bool selected, ImVec2 size, const char* tooltip = nullptr);

// Small text button with an icon on the left (for toolbars).
bool iconTextButton(const char* id, Icon icon, const char* label, bool enabled = true);

// A borderless square button with just an icon (panel headers, the context bar). Needs a tooltip.
bool iconButton(const char* id, Icon icon, float size, const char* tooltip, bool selected = false, ImU32 tint = 0);

// A rounded filter chip ("Recent", "Gadgets"...). Neon when selected.
bool chip(const char* label, bool selected);

// Section title with a thin rule, used inside panels.
void section(const char* title);
// A section that folds away. `summary` (may be null) is shown on the right while folded, so people see what is
// inside without opening it. Returns true while open; no matching end call.
bool foldSection(const char* title, bool defaultOpen, const char* summary = nullptr);

// Two-column "label | control" property grid, like a game-engine inspector.
bool beginProps(const char* id, float labelWidth = 104.0f);   // labelWidth at scale 1
void prop(const char* label, const char* tooltip = nullptr);  // call before each control
void endProps();

// Three number fields with a red / green / blue X Y Z tag on each (drag the tag or the number).
bool axisDrag3(const char* id, float* v, float speed, float vmin, float vmax, const char* fmt);

// Filled-track sliders (value text never hidden by a grab handle).
// The fill uses the current ImGuiCol_SliderGrab colour, so callers can tint it.
bool sliderFloat(const char* id, float* v, float vmin, float vmax, const char* fmt = "%.2f");
bool sliderInt(const char* id, int* v, int vmin, int vmax, const char* fmt = "%d");
bool sliderFloatLog(const char* id, float* v, float vmin, float vmax, const char* fmt = "%.2f");   // for sizes that span a wide range

// A button that is the chosen one of a set (Walk among Stand / Walk / Run...): neon wash, neon text. Wrap the button.
void pushSelectedButton();
void popSelectedButton();

// Common buttons and containers used by the editor and by game panels.
bool primaryButton(const char* label, ImVec2 size = ImVec2(-FLT_MIN, 0));
bool fuseButton(const char* label, ImVec2 size = ImVec2(-FLT_MIN, 0));    // Play and only Play
bool dangerButton(const char* label, ImVec2 size = ImVec2(-FLT_MIN, 0));
void beginCard(const char* id);   // rounded filled box that grows to fit its contents
void endCard();
void statTile(const char* label, const char* value);

void pill(const char* text, ImU32 bg, ImU32 fg = col::text);
void helpMarker(const char* text);
void keyCap(ImDrawList* dl, ImVec2 pos, const char* key, ImU32 color = col::textDim);   // draws a little keyboard key
float keyCapWidth(const char* key);

} // namespace px::ui
