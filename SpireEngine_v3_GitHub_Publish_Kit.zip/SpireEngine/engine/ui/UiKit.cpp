#include "UiKit.h"
#include <imgui_internal.h>   // item flags, clipped text
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <filesystem>

namespace px::ui {

namespace {
bool gColourBlind = false;
}
void setColourBlindFriendly(bool on) {
    gColourBlind = on;
    col::success = on ? IM_COL32( 86, 180, 233, 255) : IM_COL32(108, 212, 106, 255);
    col::warning = on ? IM_COL32(240, 228,  66, 255) : IM_COL32(244, 184,  72, 255);
    col::danger  = on ? IM_COL32(213,  94,   0, 255) : IM_COL32(242, 106, 106, 255);
}
bool colourBlindFriendly() { return gColourBlind; }
ImU32 axisColour(int axis) {
    static const ImU32 usual[3] = { IM_COL32(240, 82, 90, 255), IM_COL32(108, 212, 106, 255), IM_COL32(75, 141, 255, 255) };
    static const ImU32 safe[3] = { IM_COL32(213, 94, 0, 255), IM_COL32(0, 158, 115, 255), IM_COL32(86, 180, 233, 255) };
    return (gColourBlind ? safe : usual)[axis < 0 ? 0 : axis > 2 ? 2 : axis];
}

Fonts fonts;
static float gScale = 1.0f;          // dpi x user scale: what every pixel size in the UI is multiplied by
static float gDpi = 1.0f, gUser = 1.0f;
static ImGuiStyle gBaseStyle;        // shape and colours at scale 1, so the scale can change at any time

float scale() { return gScale; }
float uiScale() { return gUser; }

void setUiScale(float user) {
    gUser = std::clamp(user, 0.5f, 3.0f);
    gScale = gDpi * gUser;
    ImGuiStyle t = gBaseStyle;
    t.ScaleAllSizes(gScale);
#if IMGUI_VERSION_NUM >= 19200
    t.FontScaleMain = gUser;         // fonts were loaded at dpi size; the user's scale is applied on top
#endif
    ImGui::GetStyle() = t;
}

ImU32 withAlpha(ImU32 c, float a) {
    const ImU32 alpha = ImU32(((c >> IM_COL32_A_SHIFT) & 0xFF) * a);
    return (c & ~IM_COL32_A_MASK) | (alpha << IM_COL32_A_SHIFT);
}

void pushFont(ImFont* f) {
#if IMGUI_VERSION_NUM >= 19200
    ImGui::PushFont(f, f ? f->LegacySize : 0.0f);
#else
    ImGui::PushFont(f);
#endif
}
void popFont() { ImGui::PopFont(); }

static ImVec4 v4(ImU32 c) { return ImGui::ColorConvertU32ToFloat4(c); }

void setup(const std::string& fontDir, float dpi) {
    gScale = gDpi = dpi;
    gUser = 1.0f;
    ImGuiIO& io = ImGui::GetIO();

    // ---- fonts: Geist for the interface, Geist Mono for numbers, Unbounded for the wordmark; ImGui's own as a fallback
    auto load = [&](const char* file, float size) -> ImFont* {
        const std::string path = fontDir + "/" + file;
        if (std::filesystem::exists(path)) {
            ImFontConfig cfg;
            cfg.OversampleH = 2;
            cfg.PixelSnapH = false;
            return io.Fonts->AddFontFromFileTTF(path.c_str(), size * dpi, &cfg);
        }
        ImFontConfig cfg;
        cfg.SizePixels = size * dpi;
        return io.Fonts->AddFontDefault(&cfg);
    };
    fonts.body    = load("Geist-Medium.ttf",     14.0f);
    fonts.bold    = load("Geist-SemiBold.ttf",   14.0f);
    fonts.small   = load("Geist-Medium.ttf",     12.0f);
    fonts.title   = load("Geist-SemiBold.ttf",   17.0f);
    fonts.display = load("Geist-SemiBold.ttf",   32.0f);
    fonts.mono    = load("GeistMono-Medium.ttf", 12.5f);
    fonts.brand   = load("Unbounded-Bold.ttf",   15.0f);
    io.FontDefault = fonts.body;

    // ---- shape: compact and quiet, like a tool you use all day
    ImGuiStyle& s = ImGui::GetStyle();
    s = ImGuiStyle();
    s.WindowPadding     = ImVec2(14, 12);
    s.FramePadding      = ImVec2(8, 5);
    s.CellPadding       = ImVec2(6, 4);
    s.ItemSpacing       = ImVec2(8, 6);
    s.ItemInnerSpacing  = ImVec2(6, 4);
    s.IndentSpacing     = 14;
    s.ScrollbarSize     = 8;
    s.GrabMinSize       = 10;
    s.WindowBorderSize  = 1;
    s.ChildBorderSize   = 1;
    s.PopupBorderSize   = 1;
    s.FrameBorderSize   = 1;
    s.TabBorderSize     = 0;
    s.WindowRounding    = 8;
    s.ChildRounding     = 6;
    s.FrameRounding     = 5;
    s.PopupRounding     = 8;
    s.ScrollbarRounding = 4;
    s.GrabRounding      = 4;
    s.TabRounding       = 4;
    s.WindowTitleAlign  = ImVec2(0.0f, 0.5f);
    s.WindowMenuButtonPosition = ImGuiDir_None;
    s.SeparatorTextBorderSize = 1;
    s.TabBarOverlineSize = 2;
    s.DisabledAlpha     = 0.45f;
#ifdef IMGUI_HAS_DOCK
    s.DockingSeparatorSize = 1;
#endif

    // ---- colour
    ImVec4* c = s.Colors;
    c[ImGuiCol_Text]                 = v4(col::text);
    c[ImGuiCol_TextDisabled]         = v4(col::textDim);
    c[ImGuiCol_WindowBg]             = v4(col::panel);
    c[ImGuiCol_ChildBg]              = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_PopupBg]              = v4(IM_COL32(19, 21, 27, 252));
    c[ImGuiCol_Border]               = v4(col::border);
    c[ImGuiCol_BorderShadow]         = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_FrameBg]              = v4(col::field);
    c[ImGuiCol_FrameBgHovered]       = v4(IM_COL32(20, 23, 30, 255));
    c[ImGuiCol_FrameBgActive]        = v4(IM_COL32(24, 28, 36, 255));
    c[ImGuiCol_TitleBg]              = v4(col::bg);         // a dock node's tab strip: darker than the panel it heads
    c[ImGuiCol_TitleBgActive]        = v4(col::bg);
    c[ImGuiCol_TitleBgCollapsed]     = v4(col::bg);
    c[ImGuiCol_MenuBarBg]            = v4(col::bar);
    c[ImGuiCol_ScrollbarBg]          = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_ScrollbarGrab]        = v4(IM_COL32(48, 53, 66, 255));
    c[ImGuiCol_ScrollbarGrabHovered] = v4(IM_COL32(66, 72, 88, 255));
    c[ImGuiCol_ScrollbarGrabActive]  = v4(col::accent);
    c[ImGuiCol_CheckMark]            = v4(col::accent);
    c[ImGuiCol_SliderGrab]           = v4(col::accent);
    c[ImGuiCol_SliderGrabActive]     = v4(IM_COL32(140, 238, 255, 255));
    c[ImGuiCol_Button]               = v4(IM_COL32(31, 35, 44, 255));
    c[ImGuiCol_ButtonHovered]        = v4(IM_COL32(40, 45, 56, 255));
    c[ImGuiCol_ButtonActive]         = v4(IM_COL32(49, 55, 69, 255));
    c[ImGuiCol_Header]               = v4(IM_COL32(61, 224, 255, 34));
    c[ImGuiCol_HeaderHovered]        = v4(IM_COL32(255, 255, 255, 14));
    c[ImGuiCol_HeaderActive]         = v4(IM_COL32(61, 224, 255, 56));
    c[ImGuiCol_Separator]            = v4(col::line);
    c[ImGuiCol_SeparatorHovered]     = v4(col::accent);
    c[ImGuiCol_SeparatorActive]      = v4(col::accent);
    c[ImGuiCol_ResizeGrip]           = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_ResizeGripHovered]    = v4(col::accentDim);
    c[ImGuiCol_ResizeGripActive]     = v4(col::accent);
    c[ImGuiCol_Tab]                  = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_TabHovered]           = v4(IM_COL32(32, 36, 46, 255));
    c[ImGuiCol_TabSelected]          = v4(col::panelAlt);
    c[ImGuiCol_TabSelectedOverline]  = v4(col::accent);
    c[ImGuiCol_TabDimmed]            = v4(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_TabDimmedSelected]    = v4(col::panelAlt);
    c[ImGuiCol_TabDimmedSelectedOverline] = v4(IM_COL32(61, 224, 255, 110));
    c[ImGuiCol_PlotHistogram]        = v4(IM_COL32(61, 224, 255, 120));   // text sits on bars: a wash, not a fill
#ifdef IMGUI_HAS_DOCK
    c[ImGuiCol_DockingPreview]       = v4(IM_COL32(61, 224, 255, 70));       // where a dragged panel will land
    c[ImGuiCol_DockingEmptyBg]       = v4(IM_COL32(0, 0, 0, 0));
#endif
    c[ImGuiCol_TableHeaderBg]        = v4(col::panelAlt);
    c[ImGuiCol_TableBorderLight]     = v4(col::line);
    c[ImGuiCol_TableBorderStrong]    = v4(col::border);
    c[ImGuiCol_TextSelectedBg]       = v4(IM_COL32(61, 224, 255, 60));
    c[ImGuiCol_ModalWindowDimBg]     = v4(IM_COL32(4, 5, 7, 170));
    c[ImGuiCol_NavCursor]            = v4(col::accent);
    c[ImGuiCol_TextLink]             = v4(col::accent);
    gBaseStyle = s;                  // unscaled; setUiScale() turns it into the live style
    setUiScale(1.0f);
}

// ------------------------------------------------------------------ icons

void drawIcon(ImDrawList* dl, Icon icon, ImVec2 c, float s, ImU32 color) {
    const float t = std::max(1.5f, s * 0.09f);   // stroke
    const float h = s * 0.5f;
    auto P = [&](float x, float y) { return ImVec2(c.x + x * h, c.y + y * h); };
    const float pi = 3.14159265f;

    switch (icon) {
    case Icon::Carve:
        dl->AddCircle(c, h * 0.82f, color, 24, t);
        dl->AddLine(P(-0.4f, 0), P(0.4f, 0), color, t);
        break;
    case Icon::Build:
        dl->AddCircle(c, h * 0.82f, color, 24, t);
        dl->AddLine(P(-0.38f, 0), P(0.38f, 0), color, t);
        dl->AddLine(P(0, -0.38f), P(0, 0.38f), color, t);
        break;
    case Icon::Smooth:    // three soft waves
        for (float y : { -0.45f, 0.0f, 0.45f }) {
            for (int i = 0; i <= 16; ++i) {
                const float x = -0.8f + 1.6f * float(i) / 16.0f;
                dl->PathLineTo(P(x, y + 0.16f * std::sin(x * pi * 1.25f)));
            }
            dl->PathStroke(color, 0, t);
        }
        break;
    case Icon::Paint: {   // paint brush: handle, ferrule, bristles
        dl->AddLine(P(0.75f, -0.8f), P(0.12f, -0.12f), color, t * 1.6f);
        dl->AddQuadFilled(P(0.18f, -0.28f), P(0.32f, -0.12f), P(0.05f, 0.15f), P(-0.10f, 0.0f), color);
        dl->AddTriangleFilled(P(-0.10f, 0.02f), P(0.06f, 0.18f), P(-0.62f, 0.72f), color);
        break;
    }
    case Icon::Flatten:
        dl->AddLine(P(-0.85f, 0.55f), P(0.85f, 0.55f), color, t * 1.3f);
        for (float x : { -0.45f, 0.45f }) {
            dl->AddLine(P(x, -0.75f), P(x, 0.1f), color, t);
            dl->AddTriangleFilled(P(x - 0.22f, 0.0f), P(x + 0.22f, 0.0f), P(x, 0.3f), color);
        }
        break;
    case Icon::Stamp:     // rubber stamp
        dl->AddRect(P(-0.22f, -0.85f), P(0.22f, -0.2f), color, 2.0f, 0, t);
        dl->AddRectFilled(P(-0.75f, -0.2f), P(0.75f, 0.3f), color, 2.0f);
        dl->AddLine(P(-0.85f, 0.65f), P(0.85f, 0.65f), color, t);
        break;
    case Icon::Bake: {    // isometric cube
        const ImVec2 top = P(0, -0.85f), l = P(-0.75f, -0.42f), r = P(0.75f, -0.42f), m = P(0, 0.0f);
        const ImVec2 bl = P(-0.75f, 0.45f), br = P(0.75f, 0.45f), bm = P(0, 0.88f);
        dl->AddQuad(top, r, m, l, color, t);
        dl->AddLine(l, bl, color, t); dl->AddLine(r, br, color, t); dl->AddLine(m, bm, color, t);
        dl->AddLine(bl, bm, color, t); dl->AddLine(br, bm, color, t);
        break;
    }
    case Icon::Undo:
    case Icon::Redo: {
        const bool undo = icon == Icon::Undo;
        dl->PathArcTo(P(0, 0.1f), h * 0.62f, undo ? pi * 1.15f : -pi * 0.15f, undo ? pi * 2.1f : -pi * 1.1f, 20);
        dl->PathStroke(color, 0, t);
        const ImVec2 tip = undo ? P(-0.68f, -0.15f) : P(0.68f, -0.15f);
        const float d = undo ? 1.0f : -1.0f;
        dl->AddTriangleFilled(ImVec2(tip.x - d * h * 0.3f, tip.y), ImVec2(tip.x + d * h * 0.3f, tip.y), ImVec2(tip.x, tip.y + h * 0.42f), color);
        break;
    }
    case Icon::Play:
        dl->AddTriangleFilled(P(-0.45f, -0.7f), P(-0.45f, 0.7f), P(0.7f, 0.0f), color);
        break;
    case Icon::Pause:
        dl->AddRectFilled(P(-0.55f, -0.65f), P(-0.15f, 0.65f), color, 1.0f);
        dl->AddRectFilled(P(0.15f, -0.65f), P(0.55f, 0.65f), color, 1.0f);
        break;
    case Icon::Save:
        dl->AddRect(P(-0.75f, -0.75f), P(0.75f, 0.75f), color, 2.0f, 0, t);
        dl->AddRectFilled(P(-0.4f, -0.75f), P(0.35f, -0.25f), color);
        dl->AddRect(P(-0.45f, 0.15f), P(0.45f, 0.75f), color, 1.0f, 0, t);
        break;
    case Icon::Open:
        dl->AddRect(P(-0.85f, -0.45f), P(0.85f, 0.65f), color, 2.0f, 0, t);
        dl->AddLine(P(-0.85f, -0.45f), P(-0.85f, -0.7f), color, t);
        dl->AddLine(P(-0.85f, -0.7f), P(-0.2f, -0.7f), color, t);
        dl->AddLine(P(-0.2f, -0.7f), P(0.0f, -0.45f), color, t);
        break;
    case Icon::Sun:
        dl->AddCircleFilled(c, h * 0.38f, color, 16);
        for (int i = 0; i < 8; ++i) {
            const float a = i * pi / 4.0f;
            dl->AddLine(ImVec2(c.x + std::cos(a) * h * 0.6f, c.y + std::sin(a) * h * 0.6f),
                        ImVec2(c.x + std::cos(a) * h * 0.9f, c.y + std::sin(a) * h * 0.9f), color, t);
        }
        break;
    case Icon::Globe:
        dl->AddCircle(c, h * 0.82f, color, 24, t);
        for (int i = 0; i <= 20; ++i) {   // meridian ellipse (manual: AddEllipse's signature changed across ImGui versions)
            const float a = i / 20.0f * 2.0f * pi;
            dl->PathLineTo(ImVec2(c.x + std::cos(a) * h * 0.35f, c.y + std::sin(a) * h * 0.82f));
        }
        dl->PathStroke(color, 0, t);
        dl->AddLine(P(-0.82f, 0), P(0.82f, 0), color, t);
        break;
    case Icon::Gear:
        for (int i = 0; i < 8; ++i) {
            const float a = i * pi / 4.0f;
            dl->AddLine(ImVec2(c.x + std::cos(a) * h * 0.5f, c.y + std::sin(a) * h * 0.5f),
                        ImVec2(c.x + std::cos(a) * h * 0.9f, c.y + std::sin(a) * h * 0.9f), color, t * 1.8f);
        }
        dl->AddCircleFilled(c, h * 0.62f, color, 20);
        dl->AddCircleFilled(c, h * 0.25f, col::panel, 12);
        break;
    case Icon::User:
        dl->AddCircleFilled(P(0, -0.38f), h * 0.36f, color, 16);
        dl->PathArcTo(P(0, 0.85f), h * 0.75f, pi, 2 * pi, 16);
        dl->PathFillConvex(color);
        break;
    case Icon::Select: {   // arrow cursor
        dl->AddTriangleFilled(P(-0.55f, -0.85f), P(-0.55f, 0.55f), P(0.6f, 0.0f), color);
        dl->AddLine(P(-0.05f, 0.1f), P(0.5f, 0.88f), color, t * 1.6f);
        break;
    }
    case Icon::Eye:
    case Icon::EyeOff: {
        for (int pass = 0; pass < 2; ++pass) {          // an almond: upper then lower lid
            for (int i = 0; i <= 12; ++i) {
                const float x = -0.9f + 1.8f * float(i) / 12.0f;
                const float y = (pass == 0 ? -1.0f : 1.0f) * 0.62f * (1.0f - x * x / 0.81f);
                dl->PathLineTo(P(x, y));
            }
            dl->PathStroke(color, 0, t);
        }
        dl->AddCircleFilled(c, h * 0.27f, color, 14);
        if (icon == Icon::EyeOff) dl->AddLine(P(-0.8f, 0.8f), P(0.8f, -0.8f), color, t * 1.3f);
        break;
    }
    case Icon::Lock:
    case Icon::Unlock: {
        dl->AddRectFilled(P(-0.55f, -0.05f), P(0.55f, 0.82f), color, 2.0f);
        const bool locked = icon == Icon::Lock;
        dl->PathArcTo(locked ? P(0.0f, -0.08f) : P(0.34f, -0.08f), h * 0.36f, pi, locked ? 2.0f * pi : 1.85f * pi, 14);
        dl->PathStroke(color, 0, t);
        if (locked) { dl->AddLine(P(-0.36f, -0.1f), P(-0.36f, -0.08f), color, t); dl->AddLine(P(0.36f, -0.1f), P(0.36f, -0.08f), color, t); }
        else dl->AddLine(P(-0.02f, -0.08f), P(-0.02f, -0.02f), color, t);
        break;
    }
    case Icon::Move: {
        dl->AddLine(P(-0.85f, 0), P(0.85f, 0), color, t);
        dl->AddLine(P(0, -0.85f), P(0, 0.85f), color, t);
        const float a = 0.3f;
        dl->AddTriangleFilled(P(0.95f, 0), P(0.6f, -a), P(0.6f, a), color);
        dl->AddTriangleFilled(P(-0.95f, 0), P(-0.6f, -a), P(-0.6f, a), color);
        dl->AddTriangleFilled(P(0, 0.95f), P(-a, 0.6f), P(a, 0.6f), color);
        dl->AddTriangleFilled(P(0, -0.95f), P(-a, -0.6f), P(a, -0.6f), color);
        break;
    }
    case Icon::Rotate: {
        dl->PathArcTo(c, h * 0.68f, pi * 0.15f, pi * 1.75f, 24);
        dl->PathStroke(color, 0, t);
        const ImVec2 tip = P(0.55f, -0.55f);
        dl->AddTriangleFilled(ImVec2(tip.x - h * 0.05f, tip.y - h * 0.45f), ImVec2(tip.x + h * 0.5f, tip.y + h * 0.05f), ImVec2(tip.x - h * 0.5f, tip.y + h * 0.05f), color);
        break;
    }
    case Icon::Scale: {
        dl->AddRect(P(-0.85f, -0.05f), P(0.05f, 0.85f), color, 1.0f, 0, t);
        dl->AddRect(P(-0.4f, -0.85f), P(0.85f, 0.4f), color, 1.0f, 0, t);
        dl->AddLine(P(-0.2f, 0.2f), P(0.55f, -0.55f), color, t);
        break;
    }
    case Icon::Trash: {
        dl->AddLine(P(-0.8f, -0.55f), P(0.8f, -0.55f), color, t);
        dl->AddRect(P(-0.2f, -0.85f), P(0.2f, -0.55f), color, 1.0f, 0, t);
        dl->AddQuad(P(-0.6f, -0.45f), P(0.6f, -0.45f), P(0.48f, 0.85f), P(-0.48f, 0.85f), color, t);
        dl->AddLine(P(-0.2f, -0.2f), P(-0.17f, 0.6f), color, t * 0.8f);
        dl->AddLine(P(0.2f, -0.2f), P(0.17f, 0.6f), color, t * 0.8f);
        break;
    }
    case Icon::Copy: {
        dl->AddRect(P(-0.8f, -0.8f), P(0.25f, 0.25f), color, 2.0f, 0, t);
        dl->AddRectFilled(P(-0.25f, -0.25f), P(0.8f, 0.8f), col::panel, 2.0f);
        dl->AddRect(P(-0.25f, -0.25f), P(0.8f, 0.8f), color, 2.0f, 0, t);
        break;
    }
    case Icon::Plus:
        dl->AddLine(P(-0.7f, 0), P(0.7f, 0), color, t * 1.3f);
        dl->AddLine(P(0, -0.7f), P(0, 0.7f), color, t * 1.3f);
        break;
    case Icon::Pin:        // a socket: a ring with a dot and a stalk
        dl->AddCircle(P(0, -0.25f), h * 0.42f, color, 0, t);
        dl->AddCircleFilled(P(0, -0.25f), h * 0.13f, color);
        dl->AddLine(P(0, 0.2f), P(0, 0.9f), color, t);
        break;
    case Icon::Mirror:     // two halves either side of a plane
        dl->AddLine(P(0, -0.95f), P(0, 0.95f), color, t * 0.8f);
        dl->AddTriangleFilled(P(-0.15f, -0.6f), P(-0.9f, 0.0f), P(-0.15f, 0.6f), color);
        dl->AddTriangle(P(0.15f, -0.6f), P(0.9f, 0.0f), P(0.15f, 0.6f), color, t);
        break;
    case Icon::Hammer:     // the Asset Workshop
        dl->AddLine(P(-0.75f, 0.85f), P(0.2f, -0.2f), color, t * 1.5f);
        dl->AddQuadFilled(P(-0.15f, -0.55f), P(0.35f, -0.95f), P(0.95f, -0.3f), P(0.45f, 0.05f), color);
        break;
    case Icon::Mountain:   // Shape mode: two peaks
        dl->PathLineTo(P(-0.95f, 0.7f)); dl->PathLineTo(P(-0.3f, -0.45f)); dl->PathLineTo(P(0.05f, 0.1f));
        dl->PathLineTo(P(0.4f, -0.25f)); dl->PathLineTo(P(0.95f, 0.7f));
        dl->PathStroke(color, ImDrawFlags_Closed, t);
        break;
    case Icon::House:      // Build mode
        dl->PathLineTo(P(-0.8f, 0.85f)); dl->PathLineTo(P(-0.8f, -0.15f)); dl->PathLineTo(P(0.0f, -0.85f));
        dl->PathLineTo(P(0.8f, -0.15f)); dl->PathLineTo(P(0.8f, 0.85f));
        dl->PathStroke(color, ImDrawFlags_Closed, t);
        dl->AddRect(P(-0.25f, 0.25f), P(0.25f, 0.85f), color, 0.0f, 0, t);
        break;
    case Icon::Bolt:       // rules, Logic mode
        dl->PathLineTo(P(0.15f, -0.95f)); dl->PathLineTo(P(-0.6f, 0.15f)); dl->PathLineTo(P(-0.05f, 0.15f));
        dl->PathLineTo(P(-0.15f, 0.95f)); dl->PathLineTo(P(0.6f, -0.15f)); dl->PathLineTo(P(0.05f, -0.15f));
        dl->PathStroke(color, ImDrawFlags_Closed, t);
        break;
    case Icon::Grid:       // kits
        for (int i = 0; i < 4; ++i) {
            const float x = i % 2 ? 0.1f : -0.85f, y = i / 2 ? 0.1f : -0.85f;
            dl->AddRect(P(x, y), P(x + 0.75f, y + 0.75f), color, 2.0f, 0, t);
        }
        break;
    case Icon::Blueprint:  // a floor plan
        dl->AddRect(P(-0.85f, -0.85f), P(0.85f, 0.85f), color, 1.5f, 0, t);
        dl->AddLine(P(-0.85f, 0.05f), P(0.05f, 0.05f), color, t);
        dl->AddLine(P(0.05f, 0.05f), P(0.05f, 0.85f), color, t);
        dl->AddLine(P(0.05f, -0.85f), P(0.05f, -0.35f), color, t);
        break;
    case Icon::Search:
        dl->AddCircle(P(-0.15f, -0.15f), h * 0.58f, color, 20, t);
        dl->AddLine(P(0.3f, 0.3f), P(0.85f, 0.85f), color, t * 1.2f);
        break;
    case Icon::Share:      // an arrow up out of a tray
        dl->AddLine(P(0, -0.9f), P(0, 0.35f), color, t);
        dl->AddLine(P(0, -0.9f), P(-0.4f, -0.5f), color, t);
        dl->AddLine(P(0, -0.9f), P(0.4f, -0.5f), color, t);
        dl->PathLineTo(P(-0.75f, 0.1f)); dl->PathLineTo(P(-0.75f, 0.85f)); dl->PathLineTo(P(0.75f, 0.85f)); dl->PathLineTo(P(0.75f, 0.1f));
        dl->PathStroke(color, 0, t);
        break;
    case Icon::ChevronDown:
        dl->PathLineTo(P(-0.6f, -0.25f)); dl->PathLineTo(P(0.0f, 0.35f)); dl->PathLineTo(P(0.6f, -0.25f));
        dl->PathStroke(color, 0, t * 1.15f);
        break;
    case Icon::ChevronRight:
        dl->PathLineTo(P(-0.25f, -0.6f)); dl->PathLineTo(P(0.35f, 0.0f)); dl->PathLineTo(P(-0.25f, 0.6f));
        dl->PathStroke(color, 0, t * 1.15f);
        break;
    case Icon::Magnet:     // snapping
        dl->PathArcTo(P(0, 0.05f), h * 0.55f, 0.0f, pi, 16);
        dl->PathStroke(color, 0, t * 1.4f);
        dl->AddLine(P(-0.55f, 0.05f), P(-0.55f, -0.8f), color, t * 1.4f);
        dl->AddLine(P(0.55f, 0.05f), P(0.55f, -0.8f), color, t * 1.4f);
        dl->AddLine(P(-0.75f, -0.5f), P(-0.35f, -0.5f), color, t);
        dl->AddLine(P(0.35f, -0.5f), P(0.75f, -0.5f), color, t);
        break;
    case Icon::Camera:
        dl->AddRect(P(-0.9f, -0.5f), P(0.35f, 0.55f), color, 2.0f, 0, t);
        dl->AddTriangleFilled(P(0.4f, 0.02f), P(0.92f, -0.4f), P(0.92f, 0.45f), color);
        break;
    case Icon::Crowd:      // three people
        for (float x : { -0.55f, 0.55f }) {
            dl->AddCircle(P(x, -0.3f), h * 0.22f, color, 12, t * 0.9f);
            dl->PathArcTo(P(x, 0.7f), h * 0.42f, pi * 1.05f, pi * 1.95f, 10);
            dl->PathStroke(color, 0, t * 0.9f);
        }
        dl->AddCircleFilled(P(0, -0.45f), h * 0.27f, color, 14);
        dl->PathArcTo(P(0, 0.85f), h * 0.55f, pi, 2 * pi, 14);
        dl->PathFillConvex(color);
        break;
    case Icon::Flag:       // goals, game rules
        dl->AddLine(P(-0.6f, -0.9f), P(-0.6f, 0.9f), color, t);
        dl->AddQuadFilled(P(-0.6f, -0.85f), P(0.75f, -0.6f), P(0.75f, 0.05f), P(-0.6f, -0.15f), color);
        break;
    case Icon::Box: {      // place a thing: an open crate
        const ImVec2 top = P(0, -0.85f), l = P(-0.8f, -0.45f), r = P(0.8f, -0.45f), m = P(0, -0.05f);
        dl->AddQuad(top, r, m, l, color, t);
        dl->AddLine(l, P(-0.8f, 0.45f), color, t); dl->AddLine(r, P(0.8f, 0.45f), color, t); dl->AddLine(m, P(0, 0.88f), color, t);
        dl->AddLine(P(-0.8f, 0.45f), P(0, 0.88f), color, t); dl->AddLine(P(0.8f, 0.45f), P(0, 0.88f), color, t);
        break;
    }
    case Icon::Wand:       // templates: a ready-made start
        dl->AddLine(P(-0.85f, 0.85f), P(0.35f, -0.35f), color, t * 1.4f);
        for (int i = 0; i < 4; ++i) {
            const float a = i * pi * 0.5f;
            dl->AddLine(P(0.55f + std::cos(a) * 0.12f, -0.55f + std::sin(a) * 0.12f), P(0.55f + std::cos(a) * 0.4f, -0.55f + std::sin(a) * 0.4f), color, t);
        }
        break;
    case Icon::Stop:
        dl->AddRectFilled(P(-0.6f, -0.6f), P(0.6f, 0.6f), color, 2.0f);
        break;
    case Icon::Power:
        dl->PathArcTo(P(0, 0.1f), h * 0.72f, -pi * 0.5f + 0.75f, pi * 1.5f - 0.75f, 24);
        dl->PathStroke(color, 0, t * 1.1f);
        dl->AddLine(P(0, -0.95f), P(0, 0.05f), color, t * 1.1f);
        break;
    }
}

void drawSpireMark(ImDrawList* dl, ImVec2 base, float height, ImU32 color) {
    // Drawn on a 14 x 30 grid, like the logo: a needle spire on a tower with two pinnacles.
    const float u = height / 30.0f;
    auto P = [&](float x, float y) { return ImVec2(base.x + (x - 7.0f) * u, base.y - (30.0f - y) * u); };
    dl->AddTriangleFilled(P(7.0f, 0.0f), P(8.3f, 16.0f), P(5.7f, 16.0f), color);                    // the spire
    dl->AddRectFilled(P(3.4f, 16.0f), P(10.6f, 29.0f), color);                                      // the tower
    dl->AddRectFilled(P(2.6f, 28.2f), P(11.4f, 30.0f), color);                                      // its plinth
    dl->AddTriangleFilled(P(3.0f, 16.6f), P(3.7f, 12.6f), P(4.4f, 16.6f), color);                   // pinnacles
    dl->AddTriangleFilled(P(9.6f, 16.6f), P(10.3f, 12.6f), P(11.0f, 16.6f), color);
    dl->AddRectFilled(P(6.75f, -1.0f), P(7.25f, 1.5f), color);                                      // the finial
}

void screenHeader(const char* screenName) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float h = ImGui::GetWindowHeight();
    const ImVec2 o = ImGui::GetWindowPos();
    float x = ImGui::GetCursorScreenPos().x;
    drawSpireMark(dl, ImVec2(x + 8 * gScale, o.y + h - 6 * gScale), h - 11 * gScale, col::text);
    x += 24 * gScale;
    pushFont(fonts.brand);
    const ImVec2 ws = ImGui::CalcTextSize("SPIRE");
    dl->AddText(ImVec2(x, o.y + (h - ws.y) * 0.5f), col::text, "SPIRE");
    popFont();
    x += ws.x + 12 * gScale;
    dl->AddLine(ImVec2(x, o.y + h * 0.28f), ImVec2(x, o.y + h * 0.72f), col::border, 1.0f);
    x += 12 * gScale;
    pushFont(fonts.bold);
    const ImVec2 ns = ImGui::CalcTextSize(screenName);
    dl->AddText(ImVec2(x, o.y + (h - ns.y) * 0.5f), IM_COL32(197, 202, 214, 255), screenName);
    popFont();
    x += ns.x + 18 * gScale;
    ImGui::Dummy(ImVec2(x - ImGui::GetCursorScreenPos().x, 1));
}

static void tooltipWithKey(const char* tooltip, const char* shortcut) {
    ImGui::BeginTooltip();
    pushFont(fonts.bold); ImGui::TextUnformatted(tooltip); popFont();
    if (shortcut && *shortcut) {
        ImGui::SameLine(0, 12 * gScale);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        keyCap(ImGui::GetWindowDrawList(), ImVec2(p.x, p.y - 1 * gScale), shortcut, col::textDim);
        ImGui::Dummy(ImVec2(keyCapWidth(shortcut), 1));
    }
    ImGui::EndTooltip();
}

bool toolButton(const char* id, Icon icon, bool selected, float size, const char* tooltip, const char* shortcut) {
    ImGui::PushID(id);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton("##tool", ImVec2(size, size));
    const bool hovered = ImGui::IsItemHovered();
    const bool disabled = ImGui::GetItemFlags() & ImGuiItemFlags_Disabled;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 mx(pos.x + size, pos.y + size);
    const float r = 6.0f * gScale;
    if (selected) dl->AddRectFilled(pos, mx, col::accentDim, r);
    else if (hovered && !disabled) dl->AddRectFilled(pos, mx, col::panelAlt, r);
    const ImU32 ic = selected ? col::accent : disabled ? withAlpha(col::textDim, 0.45f) : (hovered ? col::text : col::textDim);
    drawIcon(dl, icon, ImVec2(pos.x + size * 0.5f, pos.y + size * 0.5f), size * 0.5f, ic);
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled) && tooltip) tooltipWithKey(tooltip, shortcut);
    ImGui::PopID();
    return pressed;
}

bool stripButton(const char* id, Icon icon, const char* label, const char* key, bool selected, ImVec2 size, const char* tooltip) {
    ImGui::PushID(id);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton("##strip", size);
    const bool hovered = ImGui::IsItemHovered();
    const bool disabled = ImGui::GetItemFlags() & ImGuiItemFlags_Disabled;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 mx(pos.x + size.x, pos.y + size.y);
    if (selected) {
        dl->AddRectFilled(pos, mx, col::accentDim);
        dl->AddRectFilled(pos, ImVec2(pos.x + 3 * gScale, mx.y), col::accent);
    } else if (hovered && !disabled) {
        dl->AddRectFilled(pos, mx, col::panelAlt);
    }
    const ImU32 ic = selected ? col::accent : disabled ? withAlpha(col::textDim, 0.45f) : hovered ? col::text : col::textDim;
    const ImU32 tc = selected ? col::text : disabled ? withAlpha(col::textDim, 0.45f) : hovered ? col::text : col::textDim;
    const bool hasLabel = label && *label;
    const float iconY = hasLabel ? pos.y + size.y * 0.40f : pos.y + size.y * 0.5f;
    drawIcon(dl, icon, ImVec2(pos.x + size.x * 0.5f, iconY), 19 * gScale, ic);
    if (hasLabel) {
        pushFont(fonts.small);
        const float fs = ImGui::GetFontSize() * 0.86f;
        ImFont* f = ImGui::GetFont();
        const ImVec2 ts = f->CalcTextSizeA(fs, FLT_MAX, 0.0f, label);
        dl->AddText(f, fs, ImVec2(pos.x + (size.x - ts.x) * 0.5f, pos.y + size.y * 0.70f), tc, label);
        popFont();
    }
    if (key && *key) {
        pushFont(fonts.mono);
        const float fs = ImGui::GetFontSize() * 0.8f;
        ImFont* f = ImGui::GetFont();
        const ImVec2 ks = f->CalcTextSizeA(fs, FLT_MAX, 0.0f, key);
        dl->AddText(f, fs, ImVec2(mx.x - ks.x - 6 * gScale, pos.y + 5 * gScale), selected ? withAlpha(col::accent, 0.85f) : IM_COL32(112, 118, 134, 255), key);
        popFont();
    }
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled | ImGuiHoveredFlags_DelayShort) && tooltip) tooltipWithKey(tooltip, key);
    ImGui::PopID();
    return pressed && !disabled;
}

bool iconTextButton(const char* id, Icon icon, const char* label, bool enabled) {
    ImGui::BeginDisabled(!enabled);
    const float iconSize = ImGui::GetFontSize();
    const ImVec2 textSize = ImGui::CalcTextSize(label, nullptr, true);
    const ImGuiStyle& st = ImGui::GetStyle();
    const ImVec2 size(st.FramePadding.x * 2 + iconSize + st.ItemInnerSpacing.x + textSize.x, ImGui::GetFrameHeight());
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    ImGui::PushID(id);
    const bool pressed = ImGui::Button("##b", size);
    ImGui::PopID();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImU32 color = enabled ? col::text : col::textDim;
    drawIcon(dl, icon, ImVec2(pos.x + st.FramePadding.x + iconSize * 0.5f, pos.y + size.y * 0.5f), iconSize * 0.9f, enabled ? col::textDim : color);
    ImGui::RenderTextClipped(ImVec2(pos.x + st.FramePadding.x + iconSize + st.ItemInnerSpacing.x, pos.y), ImVec2(pos.x + size.x, pos.y + size.y), label, nullptr, &textSize, ImVec2(0, 0.5f));
    ImGui::EndDisabled();
    return pressed && enabled;
}

bool iconButton(const char* id, Icon icon, float size, const char* tooltip, bool selected, ImU32 tint) {
    ImGui::PushID(id);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton("##ib", ImVec2(size, size));
    const bool hovered = ImGui::IsItemHovered();
    const bool disabled = ImGui::GetItemFlags() & ImGuiItemFlags_Disabled;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (selected) dl->AddRectFilled(pos, ImVec2(pos.x + size, pos.y + size), col::accentDim, 6 * gScale);
    else if (hovered && !disabled) dl->AddRectFilled(pos, ImVec2(pos.x + size, pos.y + size), IM_COL32(255, 255, 255, 16), 6 * gScale);
    ImU32 ic = tint ? tint : (hovered ? col::text : col::textDim);
    if (selected) ic = col::accent;
    if (disabled) ic = withAlpha(col::textDim, 0.4f);
    drawIcon(dl, icon, ImVec2(pos.x + size * 0.5f, pos.y + size * 0.5f), size * 0.56f, ic);
    if (tooltip && ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("%s", tooltip);
    ImGui::PopID();
    return pressed && !disabled;
}

bool chip(const char* label, bool selected) {
    pushFont(fonts.small);
    const ImVec2 ts = ImGui::CalcTextSize(label, nullptr, true);
    const float h = ts.y + 10 * gScale;
    const ImVec2 size(ts.x + 20 * gScale, h);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton(label, size);
    const bool hovered = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (selected) dl->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), col::accentDim, h * 0.5f);
    else if (hovered) dl->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(255, 255, 255, 14), h * 0.5f);
    const char* end = ImGui::FindRenderedTextEnd(label);
    dl->AddText(ImVec2(pos.x + 10 * gScale, pos.y + 5 * gScale), selected ? col::accent : hovered ? col::text : col::textDim, label, end);
    popFont();
    return pressed;
}

void section(const char* title) {
    ImGui::Dummy(ImVec2(0, 6.0f * gScale));
    pushFont(fonts.bold);
    ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(197, 202, 214, 255));
    ImGui::TextUnformatted(title);
    ImGui::PopStyleColor();
    popFont();
    const ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float x1 = ImGui::GetWindowPos().x + ImGui::GetWindowContentRegionMax().x;
    dl->AddLine(ImVec2(b.x + 10 * gScale, (a.y + b.y) * 0.5f + 0.5f), ImVec2(x1, (a.y + b.y) * 0.5f + 0.5f), col::line, 1.0f);
    ImGui::Dummy(ImVec2(0, 1.0f * gScale));
}

bool foldSection(const char* title, bool defaultOpen, const char* summary) {
    ImGuiStorage* store = ImGui::GetStateStorage();
    const ImGuiID key = ImGui::GetID(title);
    bool open = store->GetBool(key, defaultOpen);
    ImGui::Dummy(ImVec2(0, 2.0f * gScale));
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = ImGui::GetFontSize() + 16 * gScale;
    // the header runs edge to edge of the panel, like a drawer front
    const float x0 = ImGui::GetWindowPos().x + 1, x1 = ImGui::GetWindowPos().x + ImGui::GetWindowWidth() - 1;
    ImGui::PushID(title);
    if (ImGui::InvisibleButton("##fold", ImVec2(w, h))) { open = !open; store->SetBool(key, open); }
    const bool hovered = ImGui::IsItemHovered();
    ImGui::PopID();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddLine(ImVec2(x0, pos.y), ImVec2(x1, pos.y), col::line, 1.0f);
    if (hovered) dl->AddRectFilled(ImVec2(x0, pos.y + 1), ImVec2(x1, pos.y + h), IM_COL32(255, 255, 255, 8));
    drawIcon(dl, open ? Icon::ChevronDown : Icon::ChevronRight, ImVec2(pos.x + 6 * gScale, pos.y + h * 0.5f), 10 * gScale, col::faint);
    pushFont(fonts.bold);
    const float ty = pos.y + (h - ImGui::GetFontSize()) * 0.5f;
    dl->AddText(ImVec2(pos.x + 18 * gScale, ty), IM_COL32(197, 202, 214, 255), title, ImGui::FindRenderedTextEnd(title));
    const float tw = ImGui::CalcTextSize(title, nullptr, true).x;
    popFont();
    if (!open && summary && *summary) {
        pushFont(fonts.small);
        const float maxW = w - tw - 40 * gScale;
        const ImVec2 ss = ImGui::CalcTextSize(summary);
        const float sx = pos.x + w - std::min(ss.x, maxW);
        dl->PushClipRect(ImVec2(sx, pos.y), ImVec2(pos.x + w, pos.y + h), true);
        dl->AddText(ImVec2(sx, pos.y + (h - ImGui::GetFontSize()) * 0.5f), col::faint, summary);
        dl->PopClipRect();
        popFont();
    }
    if (open) ImGui::Dummy(ImVec2(0, 2.0f * gScale));
    return open;
}

bool beginProps(const char* id, float labelWidth) {
    if (!ImGui::BeginTable(id, 2, ImGuiTableFlags_SizingFixedFit)) return false;
    ImGui::TableSetupColumn("label", ImGuiTableColumnFlags_WidthFixed, labelWidth * gScale);
    ImGui::TableSetupColumn("value", ImGuiTableColumnFlags_WidthStretch);
    return true;
}

void prop(const char* label, const char* tooltip) {
    ImGui::TableNextRow();
    ImGui::TableNextColumn();
    ImGui::AlignTextToFramePadding();
    ImGui::PushStyleColor(ImGuiCol_Text, col::textDim);
    ImGui::TextUnformatted(label);
    ImGui::PopStyleColor();
    if (tooltip && ImGui::IsItemHovered()) ImGui::SetTooltip("%s", tooltip);
    ImGui::TableNextColumn();
    ImGui::SetNextItemWidth(-FLT_MIN);
}

void endProps() { ImGui::EndTable(); }

bool axisDrag3(const char* id, float* v, float speed, float vmin, float vmax, const char* fmt) {
    bool changed = false;
    ImGui::PushID(id);
    const float gap = 4 * gScale;
    const float w = (ImGui::CalcItemWidth() - gap * 2) / 3.0f;
    const float tag = 16 * gScale;
    static const char* names[3] = { "X", "Y", "Z" };
    ImGui::PushFont(fonts.mono, fonts.mono ? fonts.mono->LegacySize : 0.0f);
    for (int i = 0; i < 3; ++i) {
        if (i) ImGui::SameLine(0, gap);
        ImGui::PushID(i);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float h = ImGui::GetFrameHeight();
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(tag + 6 * gScale, ImGui::GetStyle().FramePadding.y));
        ImGui::SetNextItemWidth(w);
        changed |= ImGui::DragFloat("##v", &v[i], speed, vmin, vmax, fmt);
        ImGui::PopStyleVar();
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(ImVec2(p.x + 1, p.y + 1), ImVec2(p.x + tag, p.y + h - 1), axisColour(i), ImGui::GetStyle().FrameRounding, ImDrawFlags_RoundCornersLeft);
        pushFont(fonts.bold);
        const float fs = ImGui::GetFontSize() * 0.78f;
        const ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0, names[i]);
        dl->AddText(ImGui::GetFont(), fs, ImVec2(p.x + (tag - ts.x) * 0.5f + 0.5f, p.y + (h - ts.y) * 0.5f), IM_COL32(12, 12, 16, 255), names[i]);
        popFont();
        ImGui::PopID();
    }
    ImGui::PopFont();
    ImGui::PopID();
    return changed;
}

static bool filledSlider(float frac, auto&& widget) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const float w = ImGui::CalcItemWidth(), h = ImGui::GetFrameHeight();
    const ImGuiStyle& st = ImGui::GetStyle();
    const bool hovered = ImGui::IsMouseHoveringRect(pos, ImVec2(pos.x + w, pos.y + h)) && ImGui::IsWindowHovered();
    const ImU32 fill = ImGui::GetColorU32(ImGuiCol_SliderGrab);
    dl->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + h), ImGui::GetColorU32(hovered ? ImGuiCol_FrameBgHovered : ImGuiCol_FrameBg), st.FrameRounding);
    frac = std::clamp(frac, 0.0f, 1.0f);
    if (frac > 0.0f) {
        dl->AddRectFilled(pos, ImVec2(pos.x + std::max(w * frac, st.FrameRounding * 2), pos.y + h), withAlpha(fill, hovered ? 0.60f : 0.45f), st.FrameRounding);
    }
    ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, IM_COL32(0, 0, 0, 0));
    const bool changed = widget();
    ImGui::PopStyleColor(5);
    return changed;
}

bool sliderFloat(const char* id, float* v, float vmin, float vmax, const char* fmt) {
    return filledSlider((*v - vmin) / (vmax - vmin), [&] { return ImGui::SliderFloat(id, v, vmin, vmax, fmt); });
}

bool sliderFloatLog(const char* id, float* v, float vmin, float vmax, const char* fmt) {
    const float f = vmin > 0.0f && vmax > vmin ? std::log(std::max(*v, vmin) / vmin) / std::log(vmax / vmin) : 0.0f;
    return filledSlider(f, [&] { return ImGui::SliderFloat(id, v, vmin, vmax, fmt, ImGuiSliderFlags_Logarithmic | ImGuiSliderFlags_AlwaysClamp); });
}

bool sliderInt(const char* id, int* v, int vmin, int vmax, const char* fmt) {
    return filledSlider(float(*v - vmin) / float(vmax - vmin), [&] { return ImGui::SliderInt(id, v, vmin, vmax, fmt); });
}

bool primaryButton(const char* label, ImVec2 size) {
    ImGui::PushStyleColor(ImGuiCol_Button, col::accent);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(128, 236, 255, 255));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(40, 196, 228, 255));
    ImGui::PushStyleColor(ImGuiCol_Text, col::onAccent);
    ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 0));
    pushFont(fonts.bold);
    const bool r = ImGui::Button(label, size);
    popFont();
    ImGui::PopStyleColor(5);
    return r;
}

void pushSelectedButton() {
    ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(61, 224, 255, 40));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(61, 224, 255, 58));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(61, 224, 255, 76));
    ImGui::PushStyleColor(ImGuiCol_Text, col::accent);
    ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(61, 224, 255, 110));
}
void popSelectedButton() { ImGui::PopStyleColor(5); }

bool fuseButton(const char* label, ImVec2 size) {
    ImGui::PushStyleColor(ImGuiCol_Button, col::fuse);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(255, 146, 82, 255));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(232, 104, 32, 255));
    ImGui::PushStyleColor(ImGuiCol_Text, col::onFuse);
    ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 0));
    pushFont(fonts.bold);
    const bool r = ImGui::Button(label, size);
    popFont();
    ImGui::PopStyleColor(5);
    return r;
}

bool dangerButton(const char* label, ImVec2 size) {
    ImGui::PushStyleColor(ImGuiCol_Button, withAlpha(col::danger, 0.15f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, withAlpha(col::danger, 0.35f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, withAlpha(col::danger, 0.55f));
    ImGui::PushStyleColor(ImGuiCol_Text, col::danger);
    ImGui::PushStyleColor(ImGuiCol_Border, withAlpha(col::danger, 0.35f));
    const bool r = ImGui::Button(label, size);
    ImGui::PopStyleColor(5);
    return r;
}

void beginCard(const char* id) {
    ImGui::PushStyleColor(ImGuiCol_ChildBg, col::field);
    ImGui::PushStyleColor(ImGuiCol_Border, col::line);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 7.0f * gScale);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(12 * gScale, 10 * gScale));
    ImGui::BeginChild(id, ImVec2(-FLT_MIN, 0), ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysUseWindowPadding);
}

void endCard() {
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(2);
}

void statTile(const char* label, const char* value) {
    ImGui::BeginGroup();
    pushFont(fonts.small); ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::textDim), "%s", label); popFont();
    pushFont(fonts.title); ImGui::TextUnformatted(value); popFont();
    ImGui::EndGroup();
}

void pill(const char* text, ImU32 bg, ImU32 fg) {
    pushFont(fonts.small);
    const ImVec2 ts = ImGui::CalcTextSize(text);
    const ImVec2 pad(7 * gScale, 2 * gScale);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const float h = ImGui::GetFrameHeight();
    const ImVec2 mn(pos.x, pos.y + (h - ts.y - pad.y * 2) * 0.5f);
    const ImVec2 mx(mn.x + ts.x + pad.x * 2, mn.y + ts.y + pad.y * 2);
    ImGui::GetWindowDrawList()->AddRectFilled(mn, mx, bg, 99.0f);
    ImGui::GetWindowDrawList()->AddText(ImVec2(mn.x + pad.x, mn.y + pad.y), fg, text);
    ImGui::Dummy(ImVec2(mx.x - mn.x, h));
    popFont();
}

void helpMarker(const char* text) {
    ImGui::SameLine();
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", text);
}

float keyCapWidth(const char* key) {
    pushFont(fonts.mono);
    const float w = ImGui::CalcTextSize(key).x + 10.0f * gScale;
    popFont();
    return std::max(w, 20.0f * gScale);
}

void keyCap(ImDrawList* dl, ImVec2 pos, const char* key, ImU32 color) {
    pushFont(fonts.mono);
    const ImVec2 ts = ImGui::CalcTextSize(key);
    const float w = std::max(ts.x + 10.0f * gScale, 20.0f * gScale), h = ts.y + 5.0f * gScale;
    dl->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + h), IM_COL32(14, 16, 21, 220), 4.0f * gScale);
    dl->AddRect(pos, ImVec2(pos.x + w, pos.y + h), IM_COL32(58, 64, 77, 255), 4.0f * gScale, 0, 1.0f);
    dl->AddText(ImVec2(pos.x + (w - ts.x) * 0.5f, pos.y + 2.5f * gScale), color, key);
    popFont();
}

} // namespace px::ui
