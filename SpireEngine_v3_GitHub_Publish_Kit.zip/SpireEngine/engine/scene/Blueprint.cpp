#include "scene/Blueprint.h"
#include <algorithm>
#include <cctype>
#include <climits>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>
#include <tuple>

namespace px {

// ---------------------------------------------------------------- names

const char* bpEdgeName(BpEdge e) {
    switch (e) {
    case BpEdge::Auto: return "auto";
    case BpEdge::Wall: return "wall";
    case BpEdge::Window: return "window";
    case BpEdge::Door: return "door";
    case BpEdge::Open: return "open";
    }
    return "auto";
}
const char* bpEdgeLabel(BpEdge e) {
    switch (e) {
    case BpEdge::Auto: return "Auto";
    case BpEdge::Wall: return "Wall";
    case BpEdge::Window: return "Window";
    case BpEdge::Door: return "Door";
    case BpEdge::Open: return "Open";
    }
    return "Auto";
}
const char* bpRoofName(BpRoof r) { return r == BpRoof::Flat ? "flat" : r == BpRoof::None ? "none" : "pitched"; }
const char* bpRoofLabel(BpRoof r) { return r == BpRoof::Flat ? "Flat" : r == BpRoof::None ? "None" : "Pitched"; }
const char* bpWindowsName(BpWindows w) { return w == BpWindows::None ? "none" : w == BpWindows::Many ? "many" : "some"; }
const char* bpWindowsLabel(BpWindows w) { return w == BpWindows::None ? "None" : w == BpWindows::Many ? "Many" : "Some"; }

glm::ivec2 bpDir(int dir) {
    switch (((dir % 4) + 4) % 4) {
    case 0: return { 1, 0 };
    case 1: return { 0, 1 };
    case 2: return { -1, 0 };
    default: return { 0, -1 };
    }
}

// Objects turn about +y the way quatFromEuler does: yaw 0 keeps +x, 90 points it at -z, 180 at -x, 270 at +z.
float bpYawToward(int dir) {
    switch (((dir % 4) + 4) % 4) {
    case 0: return 0.0f;
    case 1: return 270.0f;
    case 2: return 180.0f;
    default: return 90.0f;
    }
}

std::uint32_t bpEdgeKey(int o, int x, int z) {
    return (std::uint32_t(o & 1) << 20) | (std::uint32_t(x & 1023) << 10) | std::uint32_t(z & 1023);
}
void bpEdgeFromKey(std::uint32_t key, int& o, int& x, int& z) {
    o = int((key >> 20) & 1u); x = int((key >> 10) & 1023u); z = int(key & 1023u);
}

// ---------------------------------------------------------------- the plan

Blueprint::Blueprint() {
    levels.resize(1);
    levels[0].cells.assign(size_t(width) * size_t(depth), 0);
}

int Blueprint::room(int level, int x, int z) const {
    if (level < 0 || level >= storeys() || !inGrid(x, z)) return 0;
    const BpLevel& l = levels[size_t(level)];
    const size_t i = size_t(x) + size_t(z) * size_t(width);
    return i < l.cells.size() ? int(l.cells[i]) : 0;
}

void Blueprint::setRoom(int level, int x, int z, int id) {
    if (level < 0 || level >= storeys() || !inGrid(x, z)) return;
    BpLevel& l = levels[size_t(level)];
    l.cells.resize(size_t(width) * size_t(depth), 0);
    l.cells[size_t(x) + size_t(z) * size_t(width)] = std::uint8_t(std::clamp(id, 0, kBpMaxRooms));
}

void Blueprint::fillRect(int level, int x0, int z0, int x1, int z1, int id) {
    if (x0 > x1) std::swap(x0, x1);
    if (z0 > z1) std::swap(z0, z1);
    for (int z = std::max(z0, 0); z <= std::min(z1, depth - 1); ++z)
        for (int x = std::max(x0, 0); x <= std::min(x1, width - 1); ++x) setRoom(level, x, z, id);
}

int Blueprint::cellCount(int level) const {
    int n = 0;
    for (int z = 0; z < depth; ++z) for (int x = 0; x < width; ++x) if (inside(level, x, z)) ++n;
    return n;
}
int Blueprint::cellCount(int level, int roomId) const {
    int n = 0;
    for (int z = 0; z < depth; ++z) for (int x = 0; x < width; ++x) if (room(level, x, z) == roomId) ++n;
    return n;
}
bool Blueprint::empty() const {
    for (int l = 0; l < storeys(); ++l) if (cellCount(l) > 0) return false;
    return true;
}

BpEdge Blueprint::edge(int level, int o, int x, int z) const {
    if (level < 0 || level >= storeys()) return BpEdge::Auto;
    const auto& m = levels[size_t(level)].edges;
    const auto it = m.find(bpEdgeKey(o, x, z));
    return it == m.end() ? BpEdge::Auto : it->second;
}

void Blueprint::setEdge(int level, int o, int x, int z, BpEdge e) {
    if (level < 0 || level >= storeys() || x < 0 || z < 0 || x > width || z > depth) return;
    if (o == 0 && (x >= width)) return;
    if (o == 1 && (z >= depth)) return;
    auto& m = levels[size_t(level)].edges;
    if (e == BpEdge::Auto) m.erase(bpEdgeKey(o, x, z));
    else m[bpEdgeKey(o, x, z)] = e;
}

void Blueprint::resize(int w, int d) {
    w = std::clamp(w, 1, kBpMaxSize);
    d = std::clamp(d, 1, kBpMaxSize);
    if (w == width && d == depth) return;
    for (BpLevel& l : levels) {
        std::vector<std::uint8_t> cells(size_t(w) * size_t(d), 0);
        for (int z = 0; z < std::min(d, depth); ++z)
            for (int x = 0; x < std::min(w, width); ++x) {
                const size_t i = size_t(x) + size_t(z) * size_t(width);
                if (i < l.cells.size()) cells[size_t(x) + size_t(z) * size_t(w)] = l.cells[i];
            }
        l.cells = std::move(cells);
    }
    width = w; depth = d;
    tidy();
}

void Blueprint::setStoreys(int n) {
    n = std::clamp(n, 1, kBpMaxLevels);
    while (storeys() > n) levels.pop_back();
    while (storeys() < n) {
        BpLevel l;
        l.cells = levels.back().cells;                 // the same outline as the one below, to start from
        levels.push_back(std::move(l));
    }
}

int Blueprint::addRoom(const std::string& nm) {
    if (int(rooms.size()) >= kBpMaxRooms) return 0;
    rooms.push_back(nm.empty() ? suggestRoomName() : nm.substr(0, 40));
    return int(rooms.size());
}

void Blueprint::removeRoom(int id) {
    if (id < 1 || id > int(rooms.size())) return;
    for (BpLevel& l : levels)
        for (std::uint8_t& c : l.cells) {
            if (c == id) c = 0;
            else if (c > id) --c;
        }
    rooms.erase(rooms.begin() + (id - 1));
    tidy();
}

std::string Blueprint::roomName(int id) const {
    if (id >= 1 && id <= int(rooms.size()) && !rooms[size_t(id - 1)].empty()) return rooms[size_t(id - 1)];
    return "Room " + std::to_string(id);
}

std::string Blueprint::suggestRoomName() const {
    static const char* names[] = { "Living room", "Kitchen", "Bedroom", "Bathroom", "Hall", "Study", "Dining room", "Store room", "Workshop", "Lounge" };
    for (const char* n : names)
        if (std::find(rooms.begin(), rooms.end(), std::string(n)) == rooms.end()) return n;
    for (int k = 2; k < 100; ++k) {
        const std::string n = "Bedroom " + std::to_string(k);
        if (std::find(rooms.begin(), rooms.end(), n) == rooms.end()) return n;
    }
    return "Room";
}

int Blueprint::usedRoomCount() const {
    std::set<int> used;
    for (int l = 0; l < storeys(); ++l)
        for (int z = 0; z < depth; ++z) for (int x = 0; x < width; ++x) if (int r = room(l, x, z)) used.insert(r);
    return int(used.size());
}

void Blueprint::tidy() {
    for (BpLevel& l : levels) {
        l.cells.resize(size_t(width) * size_t(depth), 0);
        for (std::uint8_t& c : l.cells) if (c > rooms.size()) c = 0;
        for (auto it = l.edges.begin(); it != l.edges.end();) {
            int o, x, z;
            bpEdgeFromKey(it->first, o, x, z);
            const bool ok = o == 0 ? (x < width && z <= depth) : (x <= width && z < depth);
            if (!ok || it->second == BpEdge::Auto) it = l.edges.erase(it); else ++it;
        }
        l.stairs.erase(std::remove_if(l.stairs.begin(), l.stairs.end(), [&](const BpStairs& s) {
            const glm::ivec2 b = glm::ivec2(s.x, s.z) + bpDir(s.dir);
            return !inGrid(s.x, s.z) || !inGrid(b.x, b.y);
        }), l.stairs.end());
    }
}

int BpResult::count(KitRole r) const {
    int n = 0;
    for (const BpPiece& p : pieces) if (p.role == r) ++n;
    return n;
}

glm::ivec2 blueprintFootprint(const Blueprint& bp, int turns) {
    return ((turns % 2) + 2) % 2 == 0 ? glm::ivec2(bp.width, bp.depth) : glm::ivec2(bp.depth, bp.width);
}

// ---------------------------------------------------------------- the generator

namespace {

struct CellSet {
    int w = 0, d = 0;
    std::vector<std::uint8_t> v;
    CellSet(int w_, int d_) : w(w_), d(d_), v(size_t(w_) * size_t(d_), 0) {}
    bool has(int x, int z) const { return x >= 0 && z >= 0 && x < w && z < d && v[size_t(x) + size_t(z) * size_t(w)]; }
    void put(int x, int z) { if (x >= 0 && z >= 0 && x < w && z < d) v[size_t(x) + size_t(z) * size_t(w)] = 1; }
};

std::string cellText(int x, int z) { return "(" + std::to_string(x + 1) + ", " + std::to_string(z + 1) + ")"; }

struct Gen {
    const Blueprint& bp;
    int W, D, L;
    BpResult out;
    std::vector<CellSet> holes, stairCells;          // per storey: open floor (stairs below), and cells stairs stand on
    std::vector<std::vector<BpStairs>> stairs;       // used, per storey

    explicit Gen(const Blueprint& b) : bp(b), W(b.width), D(b.depth), L(b.storeys()) {
        for (int l = 0; l < L; ++l) { holes.emplace_back(W, D); stairCells.emplace_back(W, D); }
        stairs.resize(size_t(L));
    }

    float plane(int l) const { return float(l) * kKitStorey; }
    void piece(KitRole r, glm::vec3 p, float yaw, int level) { out.pieces.push_back({ r, p, yaw, level }); }
    glm::vec3 cellCentre(int x, int z, float y) const { return glm::vec3(float(2 * x + 1), y, float(2 * z + 1)); }

    // ---- stairs
    bool stairsFit(int l, const BpStairs& s, bool needAbove) const {
        const glm::ivec2 a(s.x, s.z), b = a + bpDir(s.dir);
        const int r = bp.room(l, a.x, a.y);
        if (r == 0 || bp.room(l, b.x, b.y) != r) return false;
        if (holes[size_t(l)].has(a.x, a.y) || holes[size_t(l)].has(b.x, b.y)) return false;
        if (stairCells[size_t(l)].has(a.x, a.y) || stairCells[size_t(l)].has(b.x, b.y)) return false;
        if (needAbove) {                                 // upstairs, the opening and the cell you step out onto are one room: no wall across them
            const glm::ivec2 c = b + bpDir(s.dir);
            const int up = bp.room(l + 1, a.x, a.y);
            if (up == 0 || bp.room(l + 1, b.x, b.y) != up || bp.room(l + 1, c.x, c.y) != up) return false;
        }
        return true;
    }

    void useStairs(int l, const BpStairs& s, bool automatic) {
        const glm::ivec2 a(s.x, s.z), b = a + bpDir(s.dir);
        stairs[size_t(l)].push_back(s);
        stairCells[size_t(l)].put(a.x, a.y); stairCells[size_t(l)].put(b.x, b.y);
        if (l + 1 < L) { holes[size_t(l + 1)].put(a.x, a.y); holes[size_t(l + 1)].put(b.x, b.y); }
        out.stairs.push_back({ l, s, automatic });
    }

    int stairsScore(int l, const BpStairs& s) const {
        const glm::ivec2 a(s.x, s.z), d = bpDir(s.dir), b = a + d, start = a - d;
        const int r = bp.room(l, a.x, a.y);
        int score = 0;
        if (bp.room(l, start.x, start.y) == r && !stairCells[size_t(l)].has(start.x, start.y)) score += 4;   // room to step on at the bottom
        const glm::ivec2 c = b + d;
        if (!holes[size_t(l + 1)].has(c.x, c.y)) score += 1;
        {                                                                                               // up into a landing or hall: a room that leads to others
            const int top = bp.room(l + 1, a.x, a.y);
            std::set<int> next;
            for (int z = 0; z < D; ++z)
                for (int x = 0; x < W; ++x) {
                    if (bp.room(l + 1, x, z) != top) continue;
                    for (int d4 = 0; d4 < 4; ++d4) {
                        const glm::ivec2 n = glm::ivec2(x, z) + bpDir(d4);
                        const int r2 = bp.room(l + 1, n.x, n.y);
                        if (r2 && r2 != top) next.insert(r2);
                    }
                }
            score += std::min(int(next.size()), 3);
        }
        for (int side : { -1, 1 }) {                                                                    // along a wall rather than in the middle
            const glm::ivec2 p(-d.y * side, d.x * side);
            if (bp.room(l, a.x + p.x, a.y + p.y) != r && bp.room(l, b.x + p.x, b.y + p.y) != r) { score += 2; break; }
        }
        return score;
    }

    void placeStairs() {
        for (int l = 0; l < L; ++l) {
            const auto label = kitLevelLabel(l);
            for (const BpStairs& s : bp.levels[size_t(l)].stairs) {
                if (l + 1 >= L) { out.warnings.push_back(label + ": the stairs at " + cellText(s.x, s.z) + " are on the top storey, so they lead nowhere (left out)"); continue; }
                if (!stairsFit(l, s, false)) {
                    out.warnings.push_back(label + ": the stairs at " + cellText(s.x, s.z) + " need two cells of the same room, clear of other stairs and openings (left out)");
                    continue;
                }
                const glm::ivec2 a(s.x, s.z), b = a + bpDir(s.dir), c = b + bpDir(s.dir);
                if (!bp.inside(l + 1, a.x, a.y) || !bp.inside(l + 1, b.x, b.y))
                    out.warnings.push_back(label + ": the stairs at " + cellText(s.x, s.z) + " come up outside the storey above");
                else if (!bp.inside(l + 1, c.x, c.y))
                    out.warnings.push_back(label + ": the stairs at " + cellText(s.x, s.z) + " have no floor to step out onto at the top");
                else if (bp.room(l + 1, a.x, a.y) != bp.room(l + 1, b.x, b.y) || bp.room(l + 1, b.x, b.y) != bp.room(l + 1, c.x, c.y))
                    out.warnings.push_back(label + ": upstairs, a wall runs across the top of the stairs at " + cellText(s.x, s.z) + " (make it one room up there)");
                useStairs(l, s, false);
            }
            if (bp.autoStairs && l + 1 < L && stairs[size_t(l)].empty() && bp.cellCount(l + 1) > 0 && bp.cellCount(l) > 0) {
                BpStairs best; int bestScore = INT_MIN;
                for (int z = 0; z < D; ++z)
                    for (int x = 0; x < W; ++x)
                        for (int dir = 0; dir < 4; ++dir) {
                            const BpStairs s{ x, z, dir };
                            if (!stairsFit(l, s, true)) continue;
                            const int sc = stairsScore(l, s);
                            if (sc > bestScore) { bestScore = sc; best = s; }
                        }
                if (bestScore != INT_MIN) useStairs(l, best, true);
                else out.warnings.push_back("No room for stairs from the " + std::string(l == 0 ? "ground floor" : kitLevelLabel(l)) + " up: draw a room three cells long that the storey above covers");
            }
        }
    }

    // ---- edges
    struct EdgeWork {
        int level, o, x, z;
        int rA, rB;                      // the cells on either side (A: -z or -x)
        BpEdge manual;
        KitRole role;
    };
    std::vector<EdgeWork> edges;

    void decideEdges() {
        for (int l = 0; l < L; ++l)
            for (int o = 0; o < 2; ++o) {
                const int xn = o == 0 ? W : W + 1, zn = o == 0 ? D + 1 : D;
                for (int z = 0; z < zn; ++z)
                    for (int x = 0; x < xn; ++x) {
                        const int rA = o == 0 ? bp.room(l, x, z - 1) : bp.room(l, x - 1, z);
                        const int rB = bp.room(l, x, z);
                        if (rA == 0 && rB == 0) continue;
                        const BpEdge m = bp.edge(l, o, x, z);
                        KitRole role = KitRole::None;
                        switch (m) {
                        case BpEdge::Open: role = KitRole::None; break;
                        case BpEdge::Wall: role = KitRole::Wall; break;
                        case BpEdge::Window: role = KitRole::Window; break;
                        case BpEdge::Door: role = KitRole::Doorway; break;
                        case BpEdge::Auto: role = rA != rB ? KitRole::Wall : KitRole::None; break;
                        }
                        if (m == BpEdge::Auto && role == KitRole::None) continue;          // inside one room: nothing to record
                        edges.push_back({ l, o, x, z, rA, rB, m, role });
                    }
            }
    }

    bool exterior(const EdgeWork& e) const { return (e.rA == 0) != (e.rB == 0); }
    // The cells on either side of an edge.
    void sides(const EdgeWork& e, glm::ivec2& a, glm::ivec2& b) const {
        a = e.o == 0 ? glm::ivec2(e.x, e.z - 1) : glm::ivec2(e.x - 1, e.z);
        b = glm::ivec2(e.x, e.z);
    }
    // Which way an outside wall faces (from the room out): a bpDir.
    int outward(const EdgeWork& e) const {
        if (e.o == 0) return e.rA != 0 ? 1 : 3;
        return e.rA != 0 ? 0 : 2;
    }
    bool touchesStairsOrHole(const EdgeWork& e) const {
        glm::ivec2 a, b; sides(e, a, b);
        const CellSet& st = stairCells[size_t(e.level)];
        const CellSet& h = holes[size_t(e.level)];
        return st.has(a.x, a.y) || st.has(b.x, b.y) || h.has(a.x, a.y) || h.has(b.x, b.y);
    }

    void windows() {
        if (bp.windows == BpWindows::None) return;
        // Runs: outside edges on one line, facing the same way, next to each other.
        std::map<std::tuple<int, int, int, int>, std::vector<size_t>> runs;           // (level, o, line, outward) -> edges along it
        for (size_t i = 0; i < edges.size(); ++i) {
            const EdgeWork& e = edges[i];
            if (!exterior(e) || e.role == KitRole::None) continue;
            runs[{ e.level, e.o, e.o == 0 ? e.z : e.x, outward(e) }].push_back(i);
        }
        for (auto& [key, list] : runs) {
            std::sort(list.begin(), list.end(), [&](size_t a, size_t b) { return edges[a].o == 0 ? edges[a].x < edges[b].x : edges[a].z < edges[b].z; });
            size_t start = 0;
            while (start < list.size()) {
                size_t end = start + 1;
                auto pos = [&](size_t k) { return edges[list[k]].o == 0 ? edges[list[k]].x : edges[list[k]].z; };
                while (end < list.size() && pos(end) == pos(end - 1) + 1) ++end;
                const int n = int(end - start);
                const float c = float(n - 1) * 0.5f;
                for (int i = 0; i < n; ++i) {
                    EdgeWork& e = edges[list[start + size_t(i)]];
                    if (e.manual != BpEdge::Auto) continue;
                    bool win = true;
                    if (bp.windows == BpWindows::Some) {
                        const float d = std::fabs(float(i) - c);                              // symmetric about the middle of the wall
                        win = std::fmod(d, 2.0f) < 0.75f;
                    }
                    if (win) e.role = KitRole::Window;
                }
                start = end;
            }
        }
    }

    void frontDoor() {
        if (!bp.frontDoor) return;
        for (const EdgeWork& e : edges)
            if (e.level == 0 && exterior(e) && (e.manual == BpEdge::Door || e.manual == BpEdge::Open)) return;   // you made a way in yourself
        // The middle of the ground floor, along the wall.
        glm::vec2 centre(0.0f); int n = 0;
        for (int z = 0; z < D; ++z) for (int x = 0; x < W; ++x) if (bp.inside(0, x, z)) { centre += glm::vec2(float(x) + 0.5f, float(z) + 0.5f); ++n; }
        if (!n) return;
        centre /= float(n);
        static const int order[4] = { 1, 0, 2, 3 };                                           // the front first, then the sides, then the back
        long best = -1; float bestCost = 1e9f;
        for (int pref = 0; pref < 4 && best < 0; ++pref)
            for (size_t i = 0; i < edges.size(); ++i) {
                const EdgeWork& e = edges[i];
                if (e.level != 0 || !exterior(e) || e.manual != BpEdge::Auto || outward(e) != order[pref]) continue;
                const float along = e.o == 0 ? float(e.x) + 0.5f : float(e.z) + 0.5f;
                const float mid = e.o == 0 ? centre.x : centre.y;
                float cost = std::fabs(along - mid);
                if (touchesStairsOrHole(e)) cost += 50.0f;
                if (cost < bestCost - 1e-4f) { bestCost = cost; best = long(i); }
            }
        if (best >= 0) edges[size_t(best)].role = KitRole::Doorway;
    }

    void roomDoors() {
        if (!bp.roomDoors) return;
        std::map<std::tuple<int, int, int>, std::vector<size_t>> pairs;                     // (level, room, room) -> edges between them
        std::set<std::tuple<int, int, int>> handMade;
        for (size_t i = 0; i < edges.size(); ++i) {
            const EdgeWork& e = edges[i];
            if (exterior(e) || e.rA == e.rB || e.rA == 0 || e.rB == 0) continue;
            const auto key = std::make_tuple(e.level, std::min(e.rA, e.rB), std::max(e.rA, e.rB));
            if (e.manual == BpEdge::Door || e.manual == BpEdge::Open) handMade.insert(key);
            if (e.manual == BpEdge::Auto) pairs[key].push_back(i);
        }
        for (auto& [key, list] : pairs) {
            if (handMade.count(key)) continue;
            std::vector<size_t> good;
            for (size_t i : list) if (!touchesStairsOrHole(edges[i])) good.push_back(i);
            const std::vector<size_t>& from = good.empty() ? list : good;
            edges[from[from.size() / 2]].role = KitRole::Doorway;
        }
    }

    void edgePieces() {
        for (const EdgeWork& e : edges) {
            out.edges.push_back({ e.level, e.o, e.x, e.z, e.role, exterior(e), e.manual != BpEdge::Auto });
            if (e.role == KitRole::None) continue;
            const float y = plane(e.level) + kKitSlab;
            if (e.o == 0) piece(e.role, glm::vec3(float(2 * e.x + 1), y, float(2 * e.z)), 0.0f, e.level);
            else          piece(e.role, glm::vec3(float(2 * e.x), y, float(2 * e.z + 1)), 90.0f, e.level);
            if (!exterior(e) && e.rA == e.rB && e.role != KitRole::None && touchesStairsOrHole(e)) {
                glm::ivec2 a, b; sides(e, a, b);
                if (stairCells[size_t(e.level)].has(a.x, a.y) && stairCells[size_t(e.level)].has(b.x, b.y))
                    out.warnings.push_back(kitLevelLabel(e.level) + ": a wall you drew cuts across the stairs at " + cellText(b.x, b.y));
            }
        }
    }

    // ---- floors, stairs, posts
    void floorsAndStairs() {
        for (int l = 0; l < L; ++l) {
            for (int z = 0; z < D; ++z)
                for (int x = 0; x < W; ++x)
                    if (bp.inside(l, x, z) && !holes[size_t(l)].has(x, z)) piece(KitRole::Floor, cellCentre(x, z, plane(l)), 0.0f, l);
            for (const BpStairs& s : stairs[size_t(l)]) {
                const glm::ivec2 b = glm::ivec2(s.x, s.z) + bpDir(s.dir);
                const glm::vec3 mid = (cellCentre(s.x, s.z, 0.0f) + cellCentre(b.x, b.y, 0.0f)) * 0.5f;
                piece(KitRole::Stairs, glm::vec3(mid.x, plane(l) + kKitSlab, mid.z), bpYawToward(s.dir), l);
            }
            if (l > 0 && bp.cellCount(l) > 0 && bp.cellCount(l - 1) == 0)
                out.warnings.push_back(kitLevelLabel(l) + " floats in the air: the storey below it is empty");
        }
        if (!bp.cornerPosts) return;
        for (int l = 0; l < L; ++l)
            for (int z = 0; z <= D; ++z)
                for (int x = 0; x <= W; ++x) {
                    const int n = int(bp.inside(l, x - 1, z - 1)) + int(bp.inside(l, x, z - 1)) + int(bp.inside(l, x - 1, z)) + int(bp.inside(l, x, z));
                    if (n == 1 || n == 3) piece(KitRole::Pillar, glm::vec3(float(2 * x), plane(l) + kKitSlab, float(2 * z)), 0.0f, l);
                }
    }

    // ---- roofs
    void roofs() {
        if (bp.roof == BpRoof::None) return;
        for (int l = 0; l < L; ++l) {
            CellSet need(W, D);
            int left = 0;
            for (int z = 0; z < D; ++z)
                for (int x = 0; x < W; ++x)
                    if (bp.inside(l, x, z) && (l + 1 >= L || !bp.inside(l + 1, x, z))) { need.put(x, z); ++left; }
            const float top = plane(l + 1);
            if (bp.roof == BpRoof::Flat) {
                for (int z = 0; z < D; ++z) for (int x = 0; x < W; ++x) if (need.has(x, z)) piece(KitRole::Floor, cellCentre(x, z, top), 0.0f, l + 1);
                continue;
            }
            // Pitched: cover the cells with rectangles, biggest first; each gets a ridge along its long side.
            while (left > 0) {
                int bx0 = 0, bz0 = 0, bx1 = -1, bz1 = -1, bestArea = 0, bestMin = 0;
                for (int z0 = 0; z0 < D; ++z0)
                    for (int x0 = 0; x0 < W; ++x0) {
                        if (!need.has(x0, z0)) continue;
                        int maxX = W - 1;
                        for (int z1 = z0; z1 < D && need.has(x0, z1); ++z1) {
                            int x1 = x0;
                            while (x1 + 1 <= maxX && need.has(x1 + 1, z1)) ++x1;
                            maxX = x1;
                            const int area = (maxX - x0 + 1) * (z1 - z0 + 1);
                            const int mn = std::min(maxX - x0 + 1, z1 - z0 + 1);
                            if (area > bestArea || (area == bestArea && mn > bestMin)) { bestArea = area; bestMin = mn; bx0 = x0; bz0 = z0; bx1 = maxX; bz1 = z1; }
                        }
                    }
                if (bestArea == 0) break;
                pitchedRect(l, bx0, bz0, bx1, bz1, top);
                for (int z = bz0; z <= bz1; ++z) for (int x = bx0; x <= bx1; ++x) { need.v[size_t(x) + size_t(z) * size_t(W)] = 0; --left; }
            }
        }
    }

    // Is there a taller part of the building all along one long side of the rectangle? side 0 = before index 0, 1 = after the last.
    bool wallAlong(int l, int x0, int z0, int x1, int z1, bool acrossZ, int side) const {
        const int n = acrossZ ? z1 - z0 + 1 : x1 - x0 + 1, m = acrossZ ? x1 - x0 + 1 : z1 - z0 + 1;
        for (int j = 0; j < m; ++j) {
            glm::ivec2 c = acrossZ ? glm::ivec2(x0 + j, side == 0 ? z0 - 1 : z0 + n) : glm::ivec2(side == 0 ? x0 - 1 : x0 + n, z0 + j);
            if (!(bp.inside(l, c.x, c.y) && bp.inside(l + 1, c.x, c.y))) return false;
        }
        return true;
    }

    void pitchedRect(int l, int x0, int z0, int x1, int z1, float top) {
        const int wx = x1 - x0 + 1, wz = z1 - z0 + 1;
        bool acrossZ = wz <= wx;                           // the slope runs across the shorter side...
        auto leanTo = [&](bool az) {
            const int span = az ? wz : wx;
            return span <= 2 && wallAlong(l, x0, z0, x1, z1, az, 0) != wallAlong(l, x0, z0, x1, z1, az, 1);
        };
        if (!leanTo(acrossZ) && leanTo(!acrossZ)) acrossZ = !acrossZ;      // ...unless the other way makes a lean-to against a taller part
        const int n = acrossZ ? wz : wx, m = acrossZ ? wx : wz;
        auto cellAt = [&](int i, int j) { return acrossZ ? glm::ivec2(x0 + j, z0 + i) : glm::ivec2(x0 + i, z0 + j); };
        const bool lean = leanTo(acrossZ);
        const bool w1 = wallAlong(l, x0, z0, x1, z1, acrossZ, 1);
        const int up = acrossZ ? 1 : 0, down = acrossZ ? 3 : 2;   // towards the higher index / the lower index
        for (int i = 0; i < n; ++i) {
            int k = 0, dir = up;
            if (lean) {                                      // a lean-to rises all the way to the wall
                if (w1) { k = i; dir = up; } else { k = n - 1 - i; dir = down; }
            } else if (i < n - 1 - i) { k = i; dir = up; }
            else if (i > n - 1 - i) { k = n - 1 - i; dir = down; }
            else { k = i; dir = up; }                        // the middle row of an odd span
            for (int j = 0; j < m; ++j) {
                const glm::ivec2 c = cellAt(i, j);
                // A raised tile needs filling underneath. Inside the roof whole-metre steps are enough; at the two gable ends,
                // where the side shows, quarter-metre steps close it (each tile is 0.3 m deep at its low edge).
                const bool gable = j == 0 || j == m - 1;
                const int steps = gable ? 4 * k : k;
                for (int t = 0; t <= steps; ++t)
                    piece(KitRole::Roof, cellCentre(c.x, c.y, top + float(t) * (gable ? 0.25f : 1.0f)), bpYawToward(dir), l + 1);
            }
        }
    }

    // ---- can every room be reached?
    void reach() {
        if (bp.empty()) { out.warnings.push_back("The plan is empty: draw a room"); return; }
        auto node = [&](int l, int r) { return l * (kBpMaxRooms + 1) + r; };
        const int outside = -1;
        std::map<int, std::vector<int>> adj;
        auto link = [&](int a, int b) { adj[a].push_back(b); adj[b].push_back(a); };
        for (const BpEdgeOut& e : out.edges) {
            if (e.role != KitRole::None && e.role != KitRole::Doorway) continue;
            const int rA = e.o == 0 ? bp.room(e.level, e.x, e.z - 1) : bp.room(e.level, e.x - 1, e.z);
            const int rB = bp.room(e.level, e.x, e.z);
            if (rA == rB) continue;
            const int a = rA ? node(e.level, rA) : (e.level == 0 ? outside : INT_MIN);
            const int b = rB ? node(e.level, rB) : (e.level == 0 ? outside : INT_MIN);
            if (a != INT_MIN && b != INT_MIN) link(a, b);
        }
        for (const BpStairsOut& s : out.stairs) {
            const glm::ivec2 c = glm::ivec2(s.s.x, s.s.z) + 2 * bpDir(s.s.dir);
            const int top = bp.room(s.level + 1, c.x, c.y);
            if (top) link(node(s.level, bp.room(s.level, s.s.x, s.s.z)), node(s.level + 1, top));
        }
        std::set<int> seen{ outside };
        std::vector<int> todo{ outside };
        while (!todo.empty()) {
            const int n = todo.back(); todo.pop_back();
            for (int m : adj[n]) if (seen.insert(m).second) todo.push_back(m);
        }
        std::vector<std::string> lost;
        for (int l = 0; l < L; ++l) {
            std::set<int> rooms;
            for (int z = 0; z < D; ++z) for (int x = 0; x < W; ++x) if (int r = bp.room(l, x, z)) rooms.insert(r);
            for (int r : rooms) if (!seen.count(node(l, r))) lost.push_back(bp.roomName(r) + " (" + kitLevelLabel(l) + ")");
        }
        if (lost.empty()) return;
        if (seen.size() == 1) { out.warnings.push_back("There is no way into the building: add a door, or turn Front door on"); return; }
        std::string s = lost.size() == 1 ? "No way into " : "No way into these rooms: ";
        for (size_t i = 0; i < lost.size() && i < 6; ++i) { if (i) s += ", "; s += lost[i]; }
        if (lost.size() > 6) s += " and " + std::to_string(lost.size() - 6) + " more";
        out.warnings.push_back(s);
    }
};

} // namespace

BpResult generateBlueprint(const Blueprint& bpIn, int turns) {
    Blueprint bp = bpIn;
    bp.width = std::clamp(bp.width, 1, kBpMaxSize);
    bp.depth = std::clamp(bp.depth, 1, kBpMaxSize);
    if (bp.levels.empty()) bp.levels.resize(1);
    if (bp.storeys() > kBpMaxLevels) bp.levels.resize(kBpMaxLevels);
    bp.tidy();

    Gen g(bp);
    g.placeStairs();
    g.decideEdges();
    g.windows();
    g.frontDoor();
    g.roomDoors();
    g.edgePieces();
    g.floorsAndStairs();
    g.roofs();
    g.reach();

    BpResult r = std::move(g.out);
    // Turn about the corner, then move the footprint's corner back to the origin. Whole quarter turns keep every piece on the grid.
    const int q = ((turns % 4) + 4) % 4;
    const int c = q == 0 ? 1 : q == 2 ? -1 : 0, s = q == 1 ? 1 : q == 3 ? -1 : 0;   // cos, sin of 90q degrees
    auto rot = [&](glm::vec3 p) { return glm::vec3(p.x * float(c) + p.z * float(s), p.y, -p.x * float(s) + p.z * float(c)); };
    glm::vec3 lo(1e9f);
    for (const glm::vec3& corner : { glm::vec3(0.0f), glm::vec3(2.0f * float(bp.width), 0.0f, 0.0f), glm::vec3(0.0f, 0.0f, 2.0f * float(bp.depth)),
                                     glm::vec3(2.0f * float(bp.width), 0.0f, 2.0f * float(bp.depth)) })
        lo = glm::min(lo, rot(corner));
    float topY = 0.0f;
    for (BpPiece& p : r.pieces) {
        p.position = rot(p.position) - glm::vec3(lo.x, 0.0f, lo.z);
        p.yaw = std::fmod(p.yaw + 90.0f * float(q), 360.0f);
        const float h = p.role == KitRole::Roof ? 1.35f : p.role == KitRole::Floor ? kKitSlab : kKitWallHeight;
        topY = std::max(topY, p.position.y + h);
    }
    r.footprint = blueprintFootprint(bp, q);
    r.size = glm::vec3(2.0f * float(r.footprint.x), topY, 2.0f * float(r.footprint.y));
    return r;
}

// ---------------------------------------------------------------- files

namespace {
char roomChar(int id) {
    if (id <= 0) return '.';
    if (id <= 9) return char('0' + id);
    return char('A' + (id - 10));
}
int roomFromChar(char c) {
    if (c >= '1' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'Z') return 10 + (c - 'A');
    if (c >= 'a' && c <= 'z') return 10 + (c - 'a');
    return 0;
}
std::string clean(const std::string& s, size_t maxLen) {
    std::string o;
    for (char c : s) if (static_cast<unsigned char>(c) >= 0x20) o += c;
    if (o.size() > maxLen) o.resize(maxLen);
    return o;
}
} // namespace

Json blueprintToJson(const Blueprint& bp) {
    Json j = Json::object();
    j.set("format", "pxblueprint");
    j.set("version", kBpFileVersion);
    j.set("name", bp.name);
    j.set("style", bp.style);
    j.set("width", bp.width);
    j.set("depth", bp.depth);
    j.set("roof", bpRoofName(bp.roof));
    j.set("windows", bpWindowsName(bp.windows));
    j.set("frontDoor", bp.frontDoor);
    j.set("roomDoors", bp.roomDoors);
    j.set("autoStairs", bp.autoStairs);
    j.set("cornerPosts", bp.cornerPosts);
    Json rooms = Json::array();
    for (const std::string& r : bp.rooms) rooms.push(r);
    j.set("rooms", rooms);
    Json levels = Json::array();
    for (const BpLevel& l : bp.levels) {
        Json lv = Json::object();
        Json rows = Json::array();
        for (int z = 0; z < bp.depth; ++z) {
            std::string row;
            for (int x = 0; x < bp.width; ++x) {
                const size_t i = size_t(x) + size_t(z) * size_t(bp.width);
                row += roomChar(i < l.cells.size() ? int(l.cells[i]) : 0);
            }
            rows.push(row);
        }
        lv.set("rows", rows);
        if (!l.edges.empty()) {
            Json edges = Json::array();
            for (const auto& [key, e] : l.edges) {
                int o, x, z; bpEdgeFromKey(key, o, x, z);
                edges.push(Json::array({ o == 0 ? "x" : "z", x, z, bpEdgeName(e) }));
            }
            lv.set("edges", edges);
        }
        if (!l.stairs.empty()) {
            Json st = Json::array();
            for (const BpStairs& s : l.stairs) st.push(Json::array({ s.x, s.z, s.dir }));
            lv.set("stairs", st);
        }
        levels.push(lv);
    }
    j.set("levels", levels);
    return j;
}

bool blueprintFromJson(const Json& j, Blueprint& out, std::string* error) {
    auto fail = [&](const std::string& why) { if (error) *error = why; return false; };
    if (!j.isObject()) return fail("not a blueprint");
    if (j.has("format") && j.get("format").str() != "pxblueprint") return fail("not a blueprint file");
    if (j.get("version").integer(1) > kBpFileVersion) return fail("made by a newer version of Spire Engine");
    const Json& levels = j.get("levels");
    if (!levels.isArray() || levels.size() == 0) return fail("the blueprint has no storeys");

    Blueprint b;
    b.name = clean(j.get("name").str("House"), 64);
    if (b.name.empty()) b.name = "House";
    b.style = clean(j.get("style").str("Brick house"), 64);
    if (b.style.empty()) b.style = "Brick house";
    b.width = std::clamp(j.get("width").integer(5), 1, kBpMaxSize);
    b.depth = std::clamp(j.get("depth").integer(4), 1, kBpMaxSize);
    const std::string roof = j.get("roof").str("pitched"), win = j.get("windows").str("some");
    b.roof = roof == "flat" ? BpRoof::Flat : roof == "none" ? BpRoof::None : BpRoof::Pitched;
    b.windows = win == "none" ? BpWindows::None : win == "many" ? BpWindows::Many : BpWindows::Some;
    b.frontDoor = j.get("frontDoor").boolean(true);
    b.roomDoors = j.get("roomDoors").boolean(true);
    b.autoStairs = j.get("autoStairs").boolean(true);
    b.cornerPosts = j.get("cornerPosts").boolean(false);
    const Json& rooms = j.get("rooms");
    for (size_t i = 0; i < rooms.size() && i < size_t(kBpMaxRooms); ++i) b.rooms.push_back(clean(rooms.at(i).str(), 40));

    b.levels.clear();
    for (size_t li = 0; li < levels.size() && li < size_t(kBpMaxLevels); ++li) {
        const Json& lv = levels.at(li);
        BpLevel l;
        l.cells.assign(size_t(b.width) * size_t(b.depth), 0);
        const Json& rows = lv.get("rows");
        for (size_t z = 0; z < rows.size() && int(z) < b.depth; ++z) {
            const std::string row = rows.at(z).str();
            for (size_t x = 0; x < row.size() && int(x) < b.width; ++x) {
                const int id = roomFromChar(row[x]);
                l.cells[x + z * size_t(b.width)] = std::uint8_t(id <= int(b.rooms.size()) ? id : 0);
            }
        }
        const Json& edges = lv.get("edges");
        for (size_t i = 0; i < edges.size() && i < 4096; ++i) {
            const Json& e = edges.at(i);
            const int o = e.at(0).str() == "z" ? 1 : 0, x = e.at(1).integer(-1), z = e.at(2).integer(-1);
            const std::string k = e.at(3).str();
            BpEdge kind = BpEdge::Auto;
            for (BpEdge c : { BpEdge::Wall, BpEdge::Window, BpEdge::Door, BpEdge::Open }) if (k == bpEdgeName(c)) kind = c;
            if (kind == BpEdge::Auto || x < 0 || z < 0 || x > b.width || z > b.depth) continue;
            l.edges[bpEdgeKey(o, x, z)] = kind;
        }
        const Json& st = lv.get("stairs");
        for (size_t i = 0; i < st.size() && i < 64; ++i) {
            const Json& s = st.at(i);
            l.stairs.push_back({ s.at(0).integer(-1), s.at(1).integer(-1), ((s.at(2).integer(0) % 4) + 4) % 4 });
        }
        b.levels.push_back(std::move(l));
    }
    b.tidy();
    out = std::move(b);
    return true;
}

std::string blueprintFileName(const std::string& name) {
    std::string out;
    for (char c : name) {
        const unsigned char u = static_cast<unsigned char>(c);
        if (std::isalnum(u)) out += char(std::tolower(u));
        else if ((c == ' ' || c == '_' || c == '-') && !out.empty() && out.back() != '_') out += '_';
    }
    while (!out.empty() && out.back() == '_') out.pop_back();
    if (out.size() > 48) out.resize(48);
    return out.empty() ? std::string("blueprint") : out;
}

bool saveBlueprintFile(const Blueprint& bp, const std::string& path, std::string* error) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const fs::path target(path);
    if (target.has_parent_path()) fs::create_directories(target.parent_path(), ec);
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) { if (error) *error = "could not write " + tmp; return false; }
        f << blueprintToJson(bp).dump(2) << "\n";
        f.flush();
        if (!f) { f.close(); fs::remove(tmp, ec); if (error) *error = "could not write " + path + " (disk full?)"; return false; }
    }
    fs::rename(tmp, target, ec);
    if (ec) { fs::remove(tmp, ec); if (error) *error = "could not replace " + path; return false; }
    return true;
}

bool loadBlueprintFile(const std::string& path, Blueprint& out, std::string* error) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const auto len = fs::file_size(path, ec);
    if (ec) { if (error) *error = "could not open " + path; return false; }
    if (len > 1024 * 1024) { if (error) *error = "the file is too large to be a blueprint"; return false; }
    std::ifstream f(path, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    Json j;
    std::string err;
    if (!Json::parse(ss.str(), j, &err)) { if (error) *error = "damaged: " + err; return false; }
    return blueprintFromJson(j, out, error);
}

// ---------------------------------------------------------------- ready-made plans

const std::vector<Blueprint>& blueprintPresets() {
    static const std::vector<Blueprint> list = [] {
        std::vector<Blueprint> v;
        auto start = [&](const char* name, const char* style, int w, int d, int storeys) {
            Blueprint b;
            b.name = name; b.style = style;
            b.resize(w, d);
            b.setStoreys(storeys);
            for (BpLevel& l : b.levels) std::fill(l.cells.begin(), l.cells.end(), std::uint8_t(0));
            return b;
        };
        {   // a one-room-and-a-bedroom cabin with a porch-post look
            Blueprint b = start("Cottage", "Timber cabin", 5, 2, 1);
            b.fillRect(0, 0, 0, 2, 1, b.addRoom("Living room"));
            b.fillRect(0, 3, 0, 4, 1, b.addRoom("Bedroom"));
            b.cornerPosts = true;
            v.push_back(b);
        }
        {   // two storeys, stairs found automatically
            Blueprint b = start("Family house", "Brick house", 5, 4, 2);
            b.fillRect(0, 0, 0, 2, 3, b.addRoom("Living room"));
            b.fillRect(0, 3, 0, 4, 1, b.addRoom("Kitchen"));
            b.fillRect(0, 3, 2, 4, 3, b.addRoom("Hall"));
            b.fillRect(1, 0, 0, 1, 3, b.addRoom("Bedroom"));
            b.fillRect(1, 2, 0, 2, 3, b.addRoom("Landing"));
            b.fillRect(1, 3, 0, 4, 3, b.addRoom("Bedroom 2"));
            v.push_back(b);
        }
        {   // a shop at the front with a flat above, flat roof, lots of glass
            Blueprint b = start("Corner shop", "Modern", 4, 4, 2);
            b.fillRect(0, 0, 0, 3, 0, b.addRoom("Store room"));
            b.fillRect(0, 0, 1, 3, 3, b.addRoom("Shop"));
            b.fillRect(1, 0, 0, 1, 3, b.addRoom("Living room"));
            b.fillRect(1, 2, 0, 3, 3, b.addRoom("Bedroom"));
            b.roof = BpRoof::Flat;
            b.windows = BpWindows::Many;
            v.push_back(b);
        }
        {   // two wings, two ridges
            Blueprint b = start("L-shaped house", "Brick house", 6, 5, 1);
            b.fillRect(0, 0, 0, 2, 1, b.addRoom("Living room"));
            b.fillRect(0, 3, 0, 5, 1, b.addRoom("Kitchen"));
            b.fillRect(0, 0, 2, 1, 4, b.addRoom("Bedroom"));
            v.push_back(b);
        }
        {   // four storeys of one room each, stairs all the way up
            Blueprint b = start("Watchtower", "Stone keep", 3, 3, 4);
            const char* names[4] = { "Guard room", "Store", "Quarters", "Lookout" };
            for (int l = 0; l < 4; ++l) b.fillRect(l, 0, 0, 2, 2, b.addRoom(names[l]));
            b.roof = BpRoof::Flat;
            v.push_back(b);
        }
        {   // one big room, no windows
            Blueprint b = start("Barn", "Timber cabin", 4, 6, 1);
            b.fillRect(0, 0, 0, 3, 5, b.addRoom("Barn"));
            b.windows = BpWindows::None;
            v.push_back(b);
        }
        {   // an outpost: two rooms, metal and light strips
            Blueprint b = start("Outpost", "Sci-fi", 4, 3, 1);
            b.fillRect(0, 0, 0, 1, 2, b.addRoom("Control room"));
            b.fillRect(0, 2, 0, 3, 2, b.addRoom("Bunks"));
            b.roof = BpRoof::Flat;
            b.windows = BpWindows::Many;
            v.push_back(b);
        }
        return v;
    }();
    return list;
}

} // namespace px
