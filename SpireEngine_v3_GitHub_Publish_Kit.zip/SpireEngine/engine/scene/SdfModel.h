#pragma once
// Building models from signed-distance operations with value noise (props, trees): shared by scene/BuiltinProps.cpp and
// scene/Trees.cpp. Everything here is header-only and free of global state, so models can be built on any thread.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <glm/glm.hpp>
#include "scene/Asset.h"
#include "world/WorldTypes.h"

namespace px::sdf {

using Sdf = std::function<float(const glm::vec3&)>;
inline constexpr float kPi = 3.14159265f;

// ---------------------------------------------------------------- shapes

inline float boxSdf(const glm::vec3& q, const glm::vec3& half) {
    const glm::vec3 d = glm::abs(q) - half;
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f);
}
inline float roundBox(const glm::vec3& q, const glm::vec3& half, float r) { return boxSdf(q, half - glm::vec3(r)) - r; }
inline float chamferBox(const glm::vec3& q, const glm::vec3& half, float c) {         // every edge cut at 45 degrees
    const glm::vec3 a = glm::abs(q);
    float d = boxSdf(q, half);
    d = std::max(d, (a.x + a.y - (half.x + half.y - c)) * 0.70710678f);
    d = std::max(d, (a.y + a.z - (half.y + half.z - c)) * 0.70710678f);
    d = std::max(d, (a.x + a.z - (half.x + half.z - c)) * 0.70710678f);
    return d;
}
inline float ellipsoid(const glm::vec3& p, const glm::vec3& r) {
    const float k0 = glm::length(p / r), k1 = glm::length(p / (r * r));
    return k1 > 1e-6f ? k0 * (k0 - 1.0f) / k1 : -std::min(r.x, std::min(r.y, r.z));
}
inline float cylY(const glm::vec3& q, float r, float halfH) {
    const glm::vec2 d = glm::abs(glm::vec2(glm::length(glm::vec2(q.x, q.z)), q.y)) - glm::vec2(r, halfH);
    return std::min(std::max(d.x, d.y), 0.0f) + glm::length(glm::max(d, glm::vec2(0.0f)));
}
inline float torusY(const glm::vec3& q, float R, float r) { return glm::length(glm::vec2(glm::length(glm::vec2(q.x, q.z)) - R, q.y)) - r; }
inline float capsule(const glm::vec3& p, const glm::vec3& a, const glm::vec3& b, float ra, float rb) {
    const glm::vec3 pa = p - a, ba = b - a;
    const float h = std::clamp(glm::dot(pa, ba) / std::max(glm::dot(ba, ba), 1e-8f), 0.0f, 1.0f);
    return glm::length(pa - ba * h) - glm::mix(ra, rb, h);
}
inline float smin(float a, float b, float k) {
    if (k <= 0.0f) return std::min(a, b);
    const float h = std::clamp(0.5f + 0.5f * (b - a) / k, 0.0f, 1.0f);
    return glm::mix(b, a, h) - k * h * (1.0f - h);
}

// ---------------------------------------------------------------- 3D value noise (stone, weathering)

inline std::uint32_t hash3(int x, int y, int z, std::uint32_t seed) {
    std::uint32_t h = std::uint32_t(x) * 0x8da6b343u ^ std::uint32_t(y) * 0xd8163841u ^ std::uint32_t(z) * 0xcb1ab31fu ^ seed * 0x9e3779b9u;
    h ^= h >> 15; h *= 0x2c1b3c6du; h ^= h >> 12; h *= 0x297a2d39u; h ^= h >> 15;
    return h;
}
inline float vnoise(const glm::vec3& p, std::uint32_t seed) {                         // -1..1
    const glm::vec3 f = glm::floor(p), t = p - f;
    const glm::vec3 s = t * t * (glm::vec3(3.0f) - 2.0f * t);
    const int x = int(f.x), y = int(f.y), z = int(f.z);
    auto v = [&](int i, int j, int k) { return float(hash3(x + i, y + j, z + k, seed) & 0xFFFFu) / 32767.5f - 1.0f; };
    const float a = glm::mix(glm::mix(v(0, 0, 0), v(1, 0, 0), s.x), glm::mix(v(0, 1, 0), v(1, 1, 0), s.x), s.y);
    const float b = glm::mix(glm::mix(v(0, 0, 1), v(1, 0, 1), s.x), glm::mix(v(0, 1, 1), v(1, 1, 1), s.x), s.y);
    return glm::mix(a, b, s.z);
}
inline float fbm3(glm::vec3 p, int octaves, std::uint32_t seed) {
    float sum = 0.0f, amp = 0.5f;
    for (int o = 0; o < octaves; ++o) { sum += vnoise(p, seed + std::uint32_t(o) * 17u) * amp; p = p * 2.03f + glm::vec3(1.7f, 9.2f, 4.1f); amp *= 0.5f; }
    return sum;
}

// ---------------------------------------------------------------- a model made of signed-distance operations

struct Model {
    Asset a;
    float vs;
    // `lo`..`hi`: the space the model needs, in metres around its origin.
    Model(const std::string& name, const glm::vec3& lo, const glm::vec3& hi, float voxel) : vs(voxel) {
        a.name = name;
        a.type = AssetType::Prop;
        a.tags = { "prop" };
        a.userMade = false;
        a.voxelSize = voxel;
        a.size = glm::ivec3(glm::ceil((hi - lo) / voxel)) + glm::ivec3(1);
        a.pivot = -lo / voxel;
        a.grid.assign(size_t(a.size.x) * a.size.y * a.size.z, DENSITY_CLAMP);
        a.materials.assign(a.grid.size(), MaterialId(MAT_STONE));
    }
    template <class Fn> void each(glm::vec3 lo, glm::vec3 hi, float margin, Fn&& fn) {
        const glm::ivec3 i0 = glm::max(glm::ivec3(glm::floor((lo - glm::vec3(margin)) / vs + a.pivot)), glm::ivec3(0));
        const glm::ivec3 i1 = glm::min(glm::ivec3(glm::ceil((hi + glm::vec3(margin)) / vs + a.pivot)), a.size - glm::ivec3(1));
        for (int z = i0.z; z <= i1.z; ++z)
            for (int y = i0.y; y <= i1.y; ++y)
                for (int x = i0.x; x <= i1.x; ++x)
                    fn(size_t(a.index(x, y, z)), (glm::vec3(float(x), float(y), float(z)) - a.pivot) * vs);
    }
    void add(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m, float blend = 0.0f) {
        each(lo, hi, blend + 3.0f * vs, [&](size_t i, const glm::vec3& p) {
            const float d = f(p) / vs, cur = a.grid[i];
            const float n = smin(cur, d, blend / vs);
            if (d < cur + 0.5f * blend / vs) a.materials[i] = m;
            a.grid[i] = std::clamp(n, -DENSITY_CLAMP, DENSITY_CLAMP);
        });
    }
    void carve(const Sdf& f, glm::vec3 lo, glm::vec3 hi) {
        each(lo, hi, 3.0f * vs, [&](size_t i, const glm::vec3& p) { a.grid[i] = std::clamp(std::max(a.grid[i], -f(p) / vs), -DENSITY_CLAMP, DENSITY_CLAMP); });
    }
    void paint(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m) {
        each(lo, hi, 2.0f * vs, [&](size_t i, const glm::vec3& p) { if (a.grid[i] < 2.0f && f(p) < 0.0f) a.materials[i] = m; });
    }
    void box(glm::vec3 c, glm::vec3 h, float r, MaterialId m) { add([=](const glm::vec3& p) { return roundBox(p - c, h, r); }, c - h, c + h, m); }
    void cbox(glm::vec3 c, glm::vec3 h, float ch, MaterialId m) { add([=](const glm::vec3& p) { return chamferBox(p - c, h, ch); }, c - h, c + h, m); }
    AssetPtr finish() {
        a.buildMesh();
        return std::make_shared<Asset>(std::move(a));
    }
};


} // namespace px::sdf
