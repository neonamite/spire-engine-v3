#pragma once
// The built-in props (boulder, crate, stone arch, steps, lamp post, stone pillar), modelled in fine detail with the
// Asset Workshop's own tools. They keep the names, size and origin of the 1 m voxel prefabs they replace, so worlds
// that already use them simply look better. (The prefabs themselves stay: stamping a pillar into the terrain still
// uses them.)
#include <string>

namespace px {

class AssetLibrary;

void registerBuiltinProps(AssetLibrary& lib);
bool isBuiltinProp(const std::string& name);

} // namespace px
