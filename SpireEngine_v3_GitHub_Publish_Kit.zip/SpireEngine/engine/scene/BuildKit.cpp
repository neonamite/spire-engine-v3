#include "scene/BuildKit.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <map>

namespace px {

namespace {
std::string lower(std::string s) { for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c))); return s; }
std::string trimmed(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}
float wrapDegrees(float d) { d = std::fmod(d, 360.0f); return d < 0.0f ? d + 360.0f : d; }
int quarter(int turns) { return ((turns % 4) + 4) % 4; }
} // namespace

const char* kitRoleName(KitRole r) {
    switch (r) {
    case KitRole::Wall: return "wall";
    case KitRole::Window: return "window";
    case KitRole::Doorway: return "doorway";
    case KitRole::Floor: return "floor";
    case KitRole::Roof: return "roof";
    case KitRole::Stairs: return "stairs";
    case KitRole::Pillar: return "pillar";
    case KitRole::None: break;
    }
    return "none";
}
const char* kitRoleLabel(KitRole r) {
    switch (r) {
    case KitRole::Wall: return "Wall";
    case KitRole::Window: return "Window";
    case KitRole::Doorway: return "Doorway";
    case KitRole::Floor: return "Floor";
    case KitRole::Roof: return "Roof";
    case KitRole::Stairs: return "Stairs";
    case KitRole::Pillar: return "Pillar";
    case KitRole::None: break;
    }
    return "";
}
const char* kitRoleInfo(KitRole r) {
    switch (r) {
    case KitRole::Wall: return "A 2 m wall on the edge of a cell.";
    case KitRole::Window: return "A wall with a window in it. Replaces a wall in the same place.";
    case KitRole::Doorway: return "A wall with a doorway. Replaces a wall in the same place.";
    case KitRole::Floor: return "A 2 x 2 m floor tile. Floors for the next storey sit on top of the walls.";
    case KitRole::Roof: return "A sloped roof tile. Two back to back make a ridge over a 4 m house.";
    case KitRole::Stairs: return "Stairs over two cells that climb one storey. Leave the floor above open.";
    case KitRole::Pillar: return "A post on the corner of a cell, for porches and open sides.";
    case KitRole::None: break;
    }
    return "";
}
KitRole kitRoleFromName(const std::string& s) {
    const std::string t = lower(trimmed(s));
    for (int i = 1; i < kKitRoleCount; ++i) if (t == kitRoleName(KitRole(i))) return KitRole(i);
    return KitRole::None;
}
bool kitIsEdgePiece(KitRole r) { return r == KitRole::Wall || r == KitRole::Window || r == KitRole::Doorway; }

// ---------------------------------------------------------------- tags

std::vector<std::string> kitTagList(const std::string& style, KitRole role) {
    return { "kit:" + trimmed(style), std::string("role:") + kitRoleName(role) };
}

bool kitParseTags(const std::vector<std::string>& tags, std::string& style, KitRole& role) {
    std::string st;
    KitRole r = KitRole::None;
    for (const std::string& t : tags) {
        const std::string l = lower(t);
        if (l.rfind("kit:", 0) == 0 && st.empty()) st = trimmed(t.substr(4));
        else if (l.rfind("role:", 0) == 0 && r == KitRole::None) r = kitRoleFromName(t.substr(5));
    }
    if (st.empty() || r == KitRole::None) return false;
    style = st; role = r;
    return true;
}

std::vector<std::string> kitRetag(const std::vector<std::string>& tags, const std::string& style, KitRole role) {
    std::vector<std::string> out;
    for (const std::string& t : tags) {
        const std::string l = lower(t);
        if (l.rfind("kit:", 0) == 0 || l.rfind("role:", 0) == 0) continue;
        out.push_back(t);
    }
    for (const std::string& t : kitTagList(style, role)) out.push_back(t);
    return out;
}

// ---------------------------------------------------------------- the grid

float kitRoleLift(KitRole r) { return (r == KitRole::Floor || r == KitRole::Roof) ? 0.0f : kKitSlab; }

KitSpot kitSnap(KitRole role, const glm::vec3& aim, float plane, int turns) {
    KitSpot s;
    const float gx = aim.x / kKitCell, gz = aim.z / kKitCell;
    const float cx = (std::floor(gx) + 0.5f) * kKitCell, cz = (std::floor(gz) + 0.5f) * kKitCell;      // centre of the cell under the aim
    const float lx = std::round(gx) * kKitCell, lz = std::round(gz) * kKitCell;                          // nearest grid lines
    const float y = plane + kitRoleLift(role);
    const int q = quarter(turns);
    switch (role) {
    case KitRole::Wall: case KitRole::Window: case KitRole::Doorway: {
        const float dx = std::fabs(gx - std::round(gx)), dz = std::fabs(gz - std::round(gz));
        const bool flip = (q & 1) != 0;
        if (dz <= dx) { s.position = glm::vec3(cx, y, lz); s.yaw = flip ? 180.0f : 0.0f; }               // runs along X
        else          { s.position = glm::vec3(lx, y, cz); s.yaw = flip ? 270.0f : 90.0f; }              // runs along Z
        break;
    }
    case KitRole::Floor: case KitRole::Roof:
        s.position = glm::vec3(cx, y, cz);
        s.yaw = 90.0f * float(q);
        break;
    case KitRole::Pillar:
        s.position = glm::vec3(lx, y, lz);
        s.yaw = 0.0f;
        break;
    case KitRole::Stairs:
        // Four metres long along the piece's own X axis, one cell wide: the long way is centred on a grid line.
        if ((q & 1) == 0) s.position = glm::vec3(lx, y, cz);
        else              s.position = glm::vec3(cx, y, lz);
        s.yaw = 90.0f * float(q);
        break;
    case KitRole::None:
        s.position = aim; s.yaw = 0.0f;
        break;
    }
    s.yaw = wrapDegrees(s.yaw);
    return s;
}

float kitPlaneAt(float plane, float h) {
    return plane + std::floor((h - plane + 0.05f) / kKitStorey) * kKitStorey;
}
float kitPlaneOf(KitRole role, float originY) { return originY - kitRoleLift(role); }

std::string kitLevelLabel(int level) {
    if (level == 0) return "Ground floor";
    if (level > 0) return "Floor " + std::to_string(level);
    return "Basement " + std::to_string(-level);
}

bool kitSameSlot(KitRole a, const glm::vec3& pa, float ya, KitRole b, const glm::vec3& pb, float yb) {
    if (a == KitRole::None || b == KitRole::None) return false;
    const float eps = 0.12f;
    const bool nearAll = std::fabs(pa.x - pb.x) < eps && std::fabs(pa.y - pb.y) < eps && std::fabs(pa.z - pb.z) < eps;
    if (!nearAll) return false;
    if (kitIsEdgePiece(a) && kitIsEdgePiece(b)) {                     // the same edge, front or back
        const float d = std::fmod(wrapDegrees(ya) - wrapDegrees(yb) + 540.0f, 180.0f);
        return d < 1.0f || d > 179.0f;
    }
    const bool slabA = a == KitRole::Floor || a == KitRole::Roof, slabB = b == KitRole::Floor || b == KitRole::Roof;
    if (slabA && slabB) return true;                                  // a floor and a roof tile cannot share a cell
    return a == b && (a == KitRole::Pillar || a == KitRole::Stairs);
}

// ---------------------------------------------------------------- the catalog

void KitCatalog::rebuild(const AssetLibrary& lib) {
    list.clear();
    std::map<std::string, size_t> at;
    auto entryFor = [&](const std::string& style) -> KitStyleEntry& {
        auto it = at.find(style);
        if (it != at.end()) return list[it->second];
        at[style] = list.size();
        list.push_back({});
        list.back().name = style;
        return list.back();
    };
    // Built-in kits first, in the order the engine lists them; then the ones made in the Workshop, by name.
    std::vector<std::string> order = lib.generatedNames();
    const std::vector<std::string> all = lib.names();
    for (const std::string& n : all) if (std::find(order.begin(), order.end(), n) == order.end()) order.push_back(n);
    for (const std::string& name : order) {
        std::vector<std::string> tags;
        if (!lib.tagsOf(name, tags)) continue;
        std::string style; KitRole role;
        if (!kitParseTags(tags, style, role)) continue;
        KitStyleEntry& e = entryFor(style);
        if (lib.isGenerated(name)) e.builtin = true;
        if (e.piece[size_t(role)].empty()) e.piece[size_t(role)] = name;
    }
    std::stable_sort(list.begin(), list.end(), [](const KitStyleEntry& a, const KitStyleEntry& b) { return a.builtin && !b.builtin; });
    builtFor = lib.revision();
    built = true;
}

const KitStyleEntry* KitCatalog::find(const std::string& style) const {
    for (const KitStyleEntry& e : list) if (e.name == style) return &e;
    return nullptr;
}

std::string KitCatalog::piece(const std::string& style, KitRole role) const {
    const KitStyleEntry* e = find(style);
    return e && role != KitRole::None ? e->piece[size_t(role)] : std::string();
}

std::string KitCatalog::restyle(const AssetLibrary& lib, const std::string& assetName, const std::string& newStyle) const {
    std::vector<std::string> tags;
    if (!lib.tagsOf(assetName, tags)) return {};
    std::string style; KitRole role;
    if (!kitParseTags(tags, style, role)) return {};
    return piece(newStyle, role);
}

} // namespace px
