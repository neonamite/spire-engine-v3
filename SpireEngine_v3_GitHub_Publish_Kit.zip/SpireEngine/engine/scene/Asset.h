#pragma once
// An Asset is a thing you made once and can place many times: a voxel model (density + one
// material per voxel) with a meshed copy for drawing. Today assets come from prefabs (1 m
// voxels); the Asset Workshop will make finer ones (voxelSize 0.25) and save them as .pxasset.
// Assets never move or change by themselves: placed copies are Objects (scene/Scene.h).
#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>
#include "world/Materials.h"
#include "world/PrefabLibrary.h"
#include "world/VoxelChunk.h"      // Vertex

namespace px {

// A named point on an asset where something attaches or something happens: a sword's `grip`, a gun's
// `muzzle`, a chair's `seat`. Position is in the asset's own space (metres, origin at the pivot);
// direction is a unit vector (the way the thing "points").
struct Socket {
    std::string name;
    glm::vec3   position{ 0.0f };
    glm::vec3   direction{ 0.0f, 1.0f, 0.0f };
    bool operator==(const Socket&) const = default;
};

enum class AssetType : std::uint8_t { Prop, BuildingPiece, CharacterPart, Item, VehiclePart };    // append only: stored in files
const char* assetTypeName(AssetType t);
constexpr int kAssetTypeCount = 5;

struct Asset {
    std::string name;
    AssetType   type = AssetType::Prop;
    std::vector<std::string> tags;
    std::vector<Socket> sockets;
    bool        userMade = false;        // made in the Workshop (a .pxasset file), not wrapped from a prefab
    glm::ivec3  size{ 0 };               // samples per axis
    float       voxelSize = 1.0f;        // metres between samples
    glm::vec3   pivot{ 0.0f };           // where the object's origin sits, in grid coordinates
    std::vector<float>      grid;        // density, x + y*size.x + z*size.x*size.y; negative = solid
    std::vector<MaterialId> materials;   // same layout (empty = all stone)

    // Derived by buildMesh(): triangles in the asset's own space (metres, origin at the pivot).
    std::vector<Vertex> mesh;
    glm::vec3 boundsMin{ 0.0f }, boundsMax{ 0.0f };
    std::uint32_t version = 1;           // bumped whenever the mesh is rebuilt (the renderer re-uploads)

    bool valid() const { return size.x > 0 && size.y > 0 && size.z > 0 && grid.size() == size_t(size.x) * size.y * size.z; }
    int  index(int x, int y, int z) const { return x + y * size.x + z * size.x * size.y; }
    glm::vec3 center() const { return (boundsMin + boundsMax) * 0.5f; }
    glm::vec3 extent() const { return boundsMax - boundsMin; }

    // Density at a point in the asset's own space (metres). Inside the grid it is the trilinear
    // sample times voxelSize; outside it grows with the distance from the grid, so a character
    // standing next to the model is correctly "in air".
    float density(const glm::vec3& local) const;
    glm::vec3 gradient(const glm::vec3& local) const;     // unit vector toward air (finite differences)
    MaterialId materialNear(const glm::vec3& local) const;
    // First point where a ray (in asset space) enters solid matter; false if it misses.
    bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist, float& tHit) const;

    void buildMesh();                                      // marching cubes over the grid, padded with air
    // Triangles for the cells from..to (inclusive, in grid cells; -1 and size-1 are the padding of air
    // around the model). Appends to `out`. The Workshop remeshes only the blocks an edit touched.
    void meshCells(const glm::ivec3& from, const glm::ivec3& to, std::vector<Vertex>& out) const;
    void updateBounds();                                   // boundsMin/boundsMax from the current mesh
    static std::shared_ptr<Asset> fromPrefab(const Prefab& p);
};

using AssetPtr = std::shared_ptr<Asset>;

// All assets the editor can place. Prefabs are wrapped on demand, so a prefab you bake appears here
// (and in the Asset Browser) at once.
class AssetLibrary {
public:
    explicit AssetLibrary(PrefabLibrary& prefabs) : prefabs(prefabs) {}
    AssetPtr get(const std::string& name);                 // nullptr if unknown; built and cached on first use
    std::vector<std::string> names() const;                // sorted
    void add(AssetPtr a);                                  // e.g. from the Workshop (replaces one of the same name)
    void forget(const std::string& name) { cache.erase(name); ++rev; }

    // Assets the engine knows how to make but only makes when something asks for them (the built-in building kits).
    // They are listed by name and tags without being built; an asset of the same name added later (say, your own
    // version saved from the Workshop) takes their place.
    using Factory = std::function<AssetPtr()>;
    void addGenerated(const std::string& name, std::vector<std::string> tags, Factory make);
    bool isGenerated(const std::string& name) const;       // still the engine's own version (not replaced by yours)
    const std::vector<std::string>& generatedNames() const { return generatedOrder; }   // in the order they were registered
    // A whole family of generated assets, made from their name when first asked for ("head e1 b2 n0 m1"): too many to list
    // one by one (every face a character can have). Not listed by names() until built; never shown as yours.
    using FamilyFactory = std::function<AssetPtr(const std::string& name)>;
    void addFamily(const std::string& prefix, FamilyFactory make);
    // The tags of an asset without building it. False for an unknown name (prefabs have none).
    bool tagsOf(const std::string& name, std::vector<std::string>& tags) const;
    // Changes whenever the set of assets or their tags may have changed, so lists built from them know to refresh.
    std::uint64_t revision() const { return rev; }

    // Assets made in the Workshop live as .pxasset files in one folder.
    int  loadDirectory(const std::string& dir);            // reads every .pxasset in it; returns how many
    bool saveAsset(const Asset& a, const std::string& dir);          // writes <dir>/<name>.pxasset and adds it
    bool isUserMade(const std::string& name) const;
    std::string directory;                                 // where saveAsset writes (set by the application)
    static std::string fileNameFor(const std::string& assetName);     // safe file stem: letters, digits, '_' and '-' 
private:
    PrefabLibrary& prefabs;
    std::unordered_map<std::string, AssetPtr> cache;
    struct Generated { std::vector<std::string> tags; Factory make; };
    std::unordered_map<std::string, Generated> generated;
    std::vector<std::string> generatedOrder;
    std::vector<std::pair<std::string, FamilyFactory>> families;
    bool inFamily(const std::string& name) const;
    std::uint64_t rev = 1;
};

} // namespace px
