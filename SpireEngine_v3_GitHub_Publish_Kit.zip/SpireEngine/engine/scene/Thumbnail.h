#pragma once
// A small picture of an asset for the Assets browser, drawn in software (a tiny z-buffered
// rasteriser) so it needs no GL state, looks the same everywhere, and can be tested.
#include <cstdint>
#include <vector>
#include <glm/glm.hpp>
#include "scene/Asset.h"

namespace px {

struct Thumbnail {
    int size = 0;
    std::vector<std::uint8_t> rgba;       // size * size * 4, straight (not premultiplied) alpha, row 0 at the top
    int opaquePixels() const;
};

// The colour a material is drawn in on a thumbnail (a flat stand-in for its texture).
glm::vec3 thumbnailColour(MaterialId id);

Thumbnail renderThumbnail(const Asset& asset, int size = 96);

// Several assets placed together (a person's posed body parts): each with its model matrix and a colour multiplier.
struct ThumbPart { const Asset* asset = nullptr; glm::mat4 model{ 1.0f }; glm::vec3 tint{ 1.0f }; };
// portrait: head and shoulders, nearly face on (for people); otherwise the whole thing from a three-quarter view.
Thumbnail renderThumbnail(const std::vector<ThumbPart>& parts, int size = 96, bool portrait = false);

} // namespace px
