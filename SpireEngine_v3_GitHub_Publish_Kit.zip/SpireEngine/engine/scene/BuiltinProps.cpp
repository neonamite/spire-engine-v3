#include "scene/BuiltinProps.h"
#include "scene/SdfModel.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <glm/glm.hpp>
#include "scene/Asset.h"
#include "world/WorldTypes.h"

namespace px {

namespace {

using namespace sdf;

// ---------------------------------------------------------------- the props
// Origins and sizes match the old 1 m prefabs (origin = the prefab grid's (size/2, 1, size/2)).

AssetPtr makeBoulder() {
    Model m("boulder", { -4.2f, -1.2f, -4.2f }, { 4.4f, 6.2f, 4.2f }, 0.075f);
    // Two masses, broken by a few flat fracture planes, then weathered with noise at three scales.
    const glm::vec3 planes[] = { glm::normalize(glm::vec3(0.8f, 0.5f, 0.3f)), glm::normalize(glm::vec3(-0.6f, 0.6f, 0.5f)),
                                 glm::normalize(glm::vec3(0.1f, 0.9f, -0.4f)), glm::normalize(glm::vec3(-0.3f, 0.2f, -0.9f)),
                                 glm::normalize(glm::vec3(0.5f, -0.1f, 0.85f)), glm::normalize(glm::vec3(-0.9f, -0.05f, -0.2f)) };
    const float reach[] = { 3.6f, 3.3f, 4.1f, 2.9f, 3.0f, 3.2f };
    m.add([&](const glm::vec3& p) {
              float d = smin(ellipsoid(p - glm::vec3(0.0f, 2.2f, 0.0f), glm::vec3(3.3f, 2.5f, 3.0f)),
                             ellipsoid(p - glm::vec3(1.3f, 3.5f, -0.4f), glm::vec3(2.2f, 1.9f, 2.0f)), 1.0f);
              for (int i = 0; i < 6; ++i) d = std::max(d, glm::dot(p - glm::vec3(0.4f, 2.6f, 0.0f), planes[i]) - reach[i]);
              d += 0.45f * fbm3(p * 0.32f, 3, 11) + 0.10f * fbm3(p * 1.5f, 3, 12);
              d += 0.05f * std::fabs(vnoise(p * glm::vec3(0.7f, 3.0f, 0.7f), 13));             // faint bedding lines
              return d;
          }, { -4.2f, -1.2f, -4.2f }, { 4.4f, 6.2f, 4.2f }, MAT_STONE);
    // moss and lichen on what faces the sky, in patches
    m.paint([](const glm::vec3& p) { return 4.5f + 0.9f * fbm3(p * 0.6f, 3, 14) - p.y; }, { -4.2f, 2.5f, -4.2f }, { 4.4f, 6.2f, 4.2f }, MAT_MOSS);
    return m.finish();
}

AssetPtr makeCrate() {
    // A 5 m shipping crate (the old prop's size): chamfered frame boards round every edge, planks with gaps, a diagonal
    // brace on each side, steel corner brackets.
    Model m("crate", { -2.7f, -0.1f, -2.7f }, { 2.7f, 5.2f, 2.7f }, 0.05f);
    const glm::vec3 c(0.0f, 2.5f, 0.0f);
    m.box(c, glm::vec3(2.38f), 0.02f, MAT_WOOD);                                                 // the planked faces
    // gaps between planks: horizontal on the four sides, along x on the top and bottom
    m.carve([c](const glm::vec3& p) {
                const glm::vec3 q = p - c;
                const float side = std::max(std::fabs(q.x), std::fabs(q.z));
                const float t = (q.y + 2.38f) / 0.794f;
                const float gap = std::fabs(t - std::round(t)) * 0.794f - 0.022f;
                return std::max(gap, 2.33f - side);
            }, c - glm::vec3(2.5f), c + glm::vec3(2.5f));
    m.carve([c](const glm::vec3& p) {
                const glm::vec3 q = p - c;
                const float t = (q.x + 2.38f) / 0.794f;
                const float gap = std::fabs(t - std::round(t)) * 0.794f - 0.022f;
                return std::max(gap, 2.33f - std::fabs(q.y));
            }, c - glm::vec3(2.5f), c + glm::vec3(2.5f));
    // the frame: 12 boards along the edges, standing proud of the planks
    const float e = 2.5f, t = 0.2f;
    for (int ax = 0; ax < 3; ++ax)
        for (float s1 : { -1.0f, 1.0f })
            for (float s2 : { -1.0f, 1.0f }) {
                glm::vec3 pos(0.0f), half(t);
                const int a1 = (ax + 1) % 3, a2 = (ax + 2) % 3;
                pos[a1] = s1 * (e - t); pos[a2] = s2 * (e - t); half[ax] = e;
                m.cbox(c + pos, half, 0.04f, MAT_WOOD);
            }
    // a diagonal brace on each side face
    for (int face = 0; face < 4; ++face) {
        const float ang = float(face) * kPi * 0.5f;
        const glm::vec3 nrm(std::cos(ang), 0.0f, std::sin(ang)), along(-std::sin(ang), 0.0f, std::cos(ang));
        m.add([=](const glm::vec3& p) {
                  const glm::vec3 q = p - c;
                  const float u = glm::dot(q, along), v = q.y, w = glm::dot(q, nrm) - 2.43f;
                  const float k = 0.70710678f;
                  const float across = (u * k - v * k), lengthwise = (u * k + v * k);
                  return chamferBox(glm::vec3(across, lengthwise, w), glm::vec3(0.18f, 2.6f, 0.08f), 0.03f);
              }, c - glm::vec3(2.7f), c + glm::vec3(2.7f), MAT_WOOD);
        m.carve([=](const glm::vec3& p) {                                                  // trimmed to the frame
                    const glm::vec3 q = p - c;
                    return -(std::max(std::fabs(glm::dot(q, along)), std::fabs(q.y)) - 2.3f);
                }, c - glm::vec3(2.7f), c + glm::vec3(2.7f));
    }
    // corner brackets
    for (float sx : { -1.0f, 1.0f }) for (float sy : { -1.0f, 1.0f }) for (float sz : { -1.0f, 1.0f }) {
        const glm::vec3 k = c + glm::vec3(sx, sy, sz) * 2.42f;
        m.add([=](const glm::vec3& p) {
                  // a thin shell over the three outer faces of the corner
                  return std::max(boxSdf(p - k, glm::vec3(0.36f)), -boxSdf(p - k - glm::vec3(-sx, -sy, -sz) * 0.06f, glm::vec3(0.36f)));
              }, k - glm::vec3(0.45f), k + glm::vec3(0.45f), MAT_RUST);
    }
    return m.finish();
}

AssetPtr makeStoneArch() {
    // Brick, with dressed stone where a real arch has it: a plinth, quoins on the jambs, imposts, a ring of voussoirs
    // with a keystone, and a cornice.
    Model m("stone_arch", { -6.8f, -0.2f, -1.9f }, { 6.8f, 13.4f, 1.9f }, 0.08f);
    const MaterialId dressed = MAT_SANDSTONE;
    auto opening = [](const glm::vec3& p) {
        return std::min(boxSdf(p - glm::vec3(0.0f, 3.0f, 0.0f), glm::vec3(3.0f, 4.0f, 3.0f)), glm::length(glm::vec2(p.x, p.y - 7.0f)) - 3.0f);
    };
    m.add([&](const glm::vec3& p) { return std::max(roundBox(p - glm::vec3(0.0f, 6.5f, 0.0f), glm::vec3(6.5f, 6.5f, 1.6f), 0.04f), -opening(p)); },
          { -6.6f, -0.1f, -1.7f }, { 6.6f, 13.1f, 1.7f }, MAT_BRICK);
    // plinth
    for (float sx : { -1.0f, 1.0f })
        m.cbox({ sx * 4.8f, 0.4f, 0.0f }, { 1.8f, 0.42f, 1.72f }, 0.08f, dressed);
    // quoins up both jambs (alternating long and short) and both outer corners
    for (int i = 0; i < 10; ++i) {
        const float y = 0.82f + 0.6f * float(i) + 0.29f;
        if (y > 6.4f) break;
        const float len = (i % 2 == 0) ? 0.75f : 0.45f;
        for (float sx : { -1.0f, 1.0f }) {
            m.cbox({ sx * (3.0f + len * 0.5f), y, 0.0f }, { len * 0.5f, 0.27f, 1.66f }, 0.04f, dressed);
            m.cbox({ sx * (6.5f - len * 0.5f), y, 0.0f }, { len * 0.5f + 0.02f, 0.27f, 1.66f }, 0.04f, dressed);
        }
    }
    for (int i = 0; i < 11; ++i) {
        const float y = 6.82f + 0.6f * float(i) + 0.29f;
        if (y > 12.3f) break;
        const float len = (i % 2 == 0) ? 0.75f : 0.45f;
        for (float sx : { -1.0f, 1.0f }) m.cbox({ sx * (6.5f - len * 0.5f), y, 0.0f }, { len * 0.5f + 0.02f, 0.27f, 1.66f }, 0.04f, dressed);
    }
    // imposts at the springing line
    for (float sx : { -1.0f, 1.0f }) m.cbox({ sx * 3.45f, 6.82f, 0.0f }, { 0.55f, 0.18f, 1.75f }, 0.06f, dressed);
    // voussoirs: 13 wedge stones round the arch, the middle one (the keystone) bigger and proud
    for (int i = 0; i < 13; ++i) {
        const float a0 = kPi * float(i) / 13.0f, a1 = kPi * float(i + 1) / 13.0f, mid = (a0 + a1) * 0.5f;
        const bool key = i == 6;
        const float rOut = key ? 4.25f : 3.95f, depth = key ? 1.78f : 1.68f;
        m.add([=](const glm::vec3& p) {
                  const glm::vec2 q(p.x, p.y - 7.0f);
                  const float r = glm::length(q);
                  const float ang = std::atan2(q.y, -q.x);                          // 0 at the left springer, pi at the right
                  const float radial = std::max(3.0f - r, r - rOut);
                  const float angular = (std::max(a0 - ang, ang - a1)) * r - 0.025f;    // a hair of mortar between stones
                  return std::max(std::max(radial, angular), std::fabs(p.z) - depth);
              }, { -4.4f, 6.8f, -1.9f }, { 4.4f, 11.4f, 1.9f }, dressed);
        (void)mid;
    }
    m.carve(opening, { -3.1f, -1.0f, -2.0f }, { 3.1f, 10.1f, 2.0f });
    // cornice and coping
    m.cbox({ 0.0f, 12.62f, 0.0f }, { 6.72f, 0.2f, 1.82f }, 0.08f, dressed);
    m.cbox({ 0.0f, 12.95f, 0.0f }, { 6.6f, 0.14f, 1.7f }, 0.1f, dressed);
    return m.finish();
}

AssetPtr makeSteps() {
    // Five monumental steps (the old prop's size: 1.5 m risers), each a slab with a rounded, slightly worn nosing,
    // between two cheek walls with a sloping coping.
    Model m("steps", { -4.3f, -0.15f, -5.3f }, { 4.3f, 7.9f, 5.3f }, 0.08f);
    for (int i = 0; i < 5; ++i) {
        const float z0 = -5.0f + 2.0f * float(i), y1 = 1.5f * float(i + 1);
        m.add([=](const glm::vec3& p) {
                  float d = roundBox(p - glm::vec3(0.0f, y1 * 0.5f, (z0 + 5.0f) * 0.5f), glm::vec3(3.6f, y1 * 0.5f, (5.0f - z0) * 0.5f), 0.06f);
                  d += 0.03f * fbm3(p * 1.3f, 2, 21);
                  return d;
              }, { -3.7f, -0.1f, z0 - 0.2f }, { 3.7f, y1 + 0.2f, 5.1f }, MAT_STONE);
        m.add([=](const glm::vec3& p) {                                                    // the nosing: a half-round lip
                  const glm::vec2 q(p.y - (y1 - 0.09f), p.z - (z0 + 0.03f));
                  return std::max(glm::length(q) - 0.1f, std::fabs(p.x) - 3.6f);
              }, { -3.7f, y1 - 0.25f, z0 - 0.2f }, { 3.7f, y1 + 0.1f, z0 + 0.2f }, MAT_STONE);
    }
    for (float sx : { -1.0f, 1.0f }) {
        const float x = sx * 3.95f;
        m.add([=](const glm::vec3& p) {
                  const float top = 0.6f + 0.75f * (p.z + 5.0f);                       // follows the nosings, 0.6 m above
                  const float d = std::max(std::max(std::fabs(p.x - x) - 0.35f, p.y - top), std::max(-p.y, std::fabs(p.z) - 5.0f));
                  return d + 0.02f * fbm3(p * 1.1f, 2, 22);
              }, { x - 0.4f, -0.1f, -5.1f }, { x + 0.4f, 7.9f, 5.1f }, MAT_SANDSTONE);
        m.add([=](const glm::vec3& p) {                                                    // coping, proud on both faces
                  const float top = 0.6f + 0.75f * (p.z + 5.0f);
                  const float k = 1.0f / std::sqrt(1.0f + 0.75f * 0.75f);
                  const float slab = std::max((p.y - top - 0.12f) * k, (top - 0.05f - p.y) * k);
                  return std::max(std::max(slab, std::fabs(p.x - x) - 0.42f), std::fabs(p.z) - 5.08f);
              }, { x - 0.45f, 0.4f, -5.2f }, { x + 0.45f, 7.9f, 5.2f }, MAT_SANDSTONE);
    }
    return m.finish();
}

AssetPtr makeLampPost() {
    // A cast-iron street lamp (10 m, the old prop's size): moulded base, fluted shaft, ladder bar, a four-sided lantern
    // with glowing panes, a domed cap and a finial.
    Model m("lamp_post", { -1.5f, -0.1f, -1.5f }, { 1.5f, 10.6f, 1.5f }, 0.04f);
    const MaterialId iron = MAT_PAINT_BLACK;
    m.add([](const glm::vec3& p) { return cylY(p - glm::vec3(0, 0.25f, 0), 1.2f, 0.25f) - 0.0f; }, { -1.3f, 0.0f, -1.3f }, { 1.3f, 0.55f, 1.3f }, MAT_CONCRETE);
    m.add([](const glm::vec3& p) {                                                      // tapering base with mouldings
              const float t = std::clamp((p.y - 0.5f) / 1.2f, 0.0f, 1.0f);
              const float r = glm::mix(0.95f, 0.5f, t * t * (3.0f - 2.0f * t));
              return std::max(glm::length(glm::vec2(p.x, p.z)) - r, std::max(0.5f - p.y, p.y - 1.7f));
          }, { -1.0f, 0.4f, -1.0f }, { 1.0f, 1.8f, 1.0f }, iron, 0.05f);
    for (float y : { 0.62f, 1.7f }) m.add([=](const glm::vec3& p) { return torusY(p - glm::vec3(0, y, 0), y < 1.0f ? 0.95f : 0.48f, 0.08f); }, { -1.1f, y - 0.15f, -1.1f }, { 1.1f, y + 0.15f, 1.1f }, iron);
    m.add([](const glm::vec3& p) {                                                      // fluted shaft
              const float t = std::clamp((p.y - 1.7f) / 6.0f, 0.0f, 1.0f);
              const float ang = std::atan2(p.z, p.x);
              const float flute = 0.03f * std::max(0.0f, std::cos(ang * 12.0f));
              const float r = glm::mix(0.36f, 0.27f, t) - flute;
              return std::max(glm::length(glm::vec2(p.x, p.z)) - r, std::max(1.6f - p.y, p.y - 7.8f));
          }, { -0.45f, 1.5f, -0.45f }, { 0.45f, 7.9f, 0.45f }, iron);
    for (float y : { 7.55f, 7.8f }) m.add([=](const glm::vec3& p) { return torusY(p - glm::vec3(0, y, 0), 0.3f, 0.06f); }, { -0.4f, y - 0.1f, -0.4f }, { 0.4f, y + 0.1f, 0.4f }, iron);
    m.add([](const glm::vec3& p) { return cylY(glm::vec3(p.y - 7.2f, p.x, p.z), 0.05f, 0.85f); }, { -0.95f, 7.1f, -0.1f }, { 0.95f, 7.3f, 0.1f }, iron);   // ladder bar
    for (float sx : { -1.0f, 1.0f }) m.add([=](const glm::vec3& p) { return glm::length(p - glm::vec3(sx * 0.88f, 7.2f, 0.0f)) - 0.08f; }, { sx * 0.88f - 0.1f, 7.1f, -0.1f }, { sx * 0.88f + 0.1f, 7.3f, 0.1f }, iron);
    // the lantern: a frustum widening upward, glazed on four sides, iron at the corners
    auto frustum = [](const glm::vec3& p, float grow) {
        const float t = std::clamp((p.y - 8.0f) / 1.55f, 0.0f, 1.0f);
        const float half = glm::mix(0.42f, 0.72f, t) + grow;
        return std::max(std::max(std::fabs(p.x), std::fabs(p.z)) - half, std::max(8.0f - p.y, p.y - 9.55f));
    };
    m.add([&](const glm::vec3& p) { return frustum(p, -0.03f); }, { -0.8f, 7.9f, -0.8f }, { 0.8f, 9.6f, 0.8f }, MAT_LAMP);
    m.add([&](const glm::vec3& p) {                                                     // corner bars
              const float t = std::clamp((p.y - 8.0f) / 1.55f, 0.0f, 1.0f);
              const float half = glm::mix(0.42f, 0.72f, t);
              const glm::vec2 q(std::fabs(p.x) - half, std::fabs(p.z) - half);
              return std::max(glm::length(q) - 0.05f, std::max(8.0f - p.y, p.y - 9.55f));
          }, { -0.8f, 7.9f, -0.8f }, { 0.8f, 9.6f, 0.8f }, iron);
    m.cbox({ 0, 7.95f, 0 }, { 0.5f, 0.07f, 0.5f }, 0.03f, iron);                      // floor of the lantern
    m.cbox({ 0, 9.6f, 0 }, { 0.8f, 0.06f, 0.8f }, 0.03f, iron);                       // its eave
    m.add([](const glm::vec3& p) {                                                      // a four-sided dome
              const float t = std::clamp((p.y - 9.6f) / 0.6f, 0.0f, 1.0f);
              const float half = 0.78f * std::sqrt(std::max(0.0f, 1.0f - t * t));
              return std::max(std::max(std::fabs(p.x), std::fabs(p.z)) - half, std::max(9.6f - p.y, p.y - 10.2f));
          }, { -0.85f, 9.55f, -0.85f }, { 0.85f, 10.25f, 0.85f }, iron);
    m.add([](const glm::vec3& p) { return glm::length(p - glm::vec3(0, 10.32f, 0)) - 0.12f; }, { -0.15f, 10.15f, -0.15f }, { 0.15f, 10.5f, 0.15f }, iron);
    return m.finish();
}

AssetPtr makeStonePillar() {
    // A weathered rock column (the old prop's size: 4.4 m across, 11 m tall): bulging strata, a slight lean, a rounded
    // top with grass and moss on it.
    Model m("stone_pillar", { -3.0f, -0.2f, -3.0f }, { 3.0f, 11.6f, 3.0f }, 0.1f);
    m.add([](const glm::vec3& p) {
              const float lean = 0.12f * p.y / 11.0f;
              const glm::vec2 q(p.x - lean, p.z);
              const float strata = 0.12f * std::sin(p.y * 2.1f + 0.8f * vnoise(p * 0.4f, 31)) + 0.08f * vnoise(glm::vec3(p.y * 1.7f, 0.0f, 0.0f), 32);
              const float r = 2.15f - 0.12f * p.y / 11.0f + strata;
              float d = std::max(glm::length(q) - r, -p.y);
              const float top = p.y - (10.6f + 0.35f * fbm3(p * 0.5f, 2, 33));
              d = -smin(-d, -top, 0.6f);                                                   // a rounded top
              d += 0.28f * fbm3(p * 0.45f, 3, 34) + 0.06f * fbm3(p * 2.0f, 2, 35);
              return d;
          }, { -3.0f, -0.2f, -3.0f }, { 3.0f, 11.6f, 3.0f }, MAT_STONE);
    m.paint([](const glm::vec3& p) { return 10.0f + 0.4f * fbm3(p * 0.7f, 2, 36) - p.y; }, { -3.0f, 9.0f, -3.0f }, { 3.0f, 11.6f, 3.0f }, MAT_GRASS);
    m.paint([](const glm::vec3& p) { return 0.25f - fbm3(p * 0.5f, 3, 37) - std::max(0.0f, (p.y - 1.0f) * 0.02f); }, { -3.0f, -0.2f, -3.0f }, { 3.0f, 9.5f, 3.0f }, MAT_MOSS);
    return m.finish();
}

const char* const kProps[] = { "boulder", "crate", "stone_arch", "steps", "lamp_post", "stone_pillar" };

} // namespace

bool isBuiltinProp(const std::string& name) {
    for (const char* n : kProps) if (name == n) return true;
    return false;
}

void registerBuiltinProps(AssetLibrary& lib) {
    lib.addGenerated("boulder", { "prop", "nature" }, makeBoulder);
    lib.addGenerated("crate", { "prop" }, makeCrate);
    lib.addGenerated("stone_arch", { "prop", "building" }, makeStoneArch);
    lib.addGenerated("steps", { "prop", "building" }, makeSteps);
    lib.addGenerated("lamp_post", { "prop", "light" }, makeLampPost);
    lib.addGenerated("stone_pillar", { "prop", "nature" }, makeStonePillar);
}

} // namespace px
