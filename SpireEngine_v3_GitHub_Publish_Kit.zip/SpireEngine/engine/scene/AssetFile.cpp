#include "scene/AssetFile.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>

namespace px {

namespace {
constexpr char     kMagic[4] = { 'P', 'X', 'A', 'S' };
constexpr uint32_t kVersion  = 1;

constexpr float kQuant = 127.0f / DENSITY_CLAMP;
// Keeps the sign of every sample (a hair inside stays inside), so the mesh has the same shape after a round trip.
std::int8_t quantise(float d) {
    long q = std::lround(std::clamp(d, -DENSITY_CLAMP, DENSITY_CLAMP) * kQuant);
    if (d < 0.0f && q >= 0) q = -1;
    if (d > 0.0f && q <= 0) q = 1;
    return std::int8_t(q);
}
float dequantise(std::int8_t q) { return float(q) / kQuant; }

void rleEncode(const std::vector<std::uint8_t>& in, std::string& out) {
    size_t i = 0;
    while (i < in.size()) {
        const std::uint8_t v = in[i];
        size_t n = 1;
        while (i + n < in.size() && in[i + n] == v && n < 255) ++n;
        out.push_back(char(n));
        out.push_back(char(v));
        i += n;
    }
}
bool rleDecode(const char* data, size_t bytes, size_t expected, std::vector<std::uint8_t>& out) {
    if (bytes % 2) return false;
    out.clear();
    out.reserve(expected);
    for (size_t i = 0; i < bytes; i += 2) {
        const size_t n = std::uint8_t(data[i]);
        if (n == 0 || out.size() + n > expected) return false;
        out.insert(out.end(), n, std::uint8_t(data[i + 1]));
    }
    return out.size() == expected;
}
void put32(std::string& s, uint32_t v) { s.append(reinterpret_cast<const char*>(&v), 4); }
bool get32(const std::string& s, size_t& at, uint32_t& v) {
    if (at + 4 > s.size()) return false;
    std::memcpy(&v, s.data() + at, 4);
    at += 4;
    return true;
}
Json vec3Json(const glm::vec3& v) { return Json::array({ v.x, v.y, v.z }); }
glm::vec3 jsonVec3(const Json& j, const glm::vec3& fallback) {
    if (!j.isArray() || j.size() != 3) return fallback;
    return glm::vec3(float(j.at(0).num()), float(j.at(1).num()), float(j.at(2).num()));
}
}

// ------------------------------------------------------------------ metadata

Json assetToJson(const Asset& a) {
    Json j = Json::object();
    j.set("format", "pxasset");
    j.set("version", int(kVersion));
    j.set("name", a.name);
    j.set("type", assetTypeName(a.type));
    Json tags = Json::array();
    for (const std::string& t : a.tags) tags.push(t);
    j.set("tags", std::move(tags));
    j.set("voxelSize", a.voxelSize);
    j.set("size", Json::array({ a.size.x, a.size.y, a.size.z }));
    j.set("pivot", vec3Json(a.pivot));
    Json sockets = Json::array();
    for (const Socket& s : a.sockets) {
        Json o = Json::object();
        o.set("name", s.name);
        o.set("position", vec3Json(s.position));
        o.set("direction", vec3Json(s.direction));
        sockets.push(std::move(o));
    }
    j.set("sockets", std::move(sockets));
    return j;
}

bool assetFromJson(const Json& j, Asset& a, std::string* error) {
    auto fail = [&](const char* why) { if (error) *error = why; return false; };
    if (!j.isObject() || j.get("format").str() != "pxasset") return fail("not an asset description");
    a.name = j.get("name").str();
    if (a.name.empty()) return fail("the asset has no name");
    a.type = AssetType::Prop;
    const std::string type = j.get("type").str();
    for (int t = 0; t < kAssetTypeCount; ++t) if (type == assetTypeName(AssetType(t))) a.type = AssetType(t);
    a.tags.clear();
    for (size_t i = 0; i < j.get("tags").size(); ++i) { const std::string t = j.get("tags").at(i).str(); if (!t.empty()) a.tags.push_back(t); }
    a.voxelSize = float(j.get("voxelSize").num(0.0));
    if (!(a.voxelSize >= 0.01f && a.voxelSize <= 8.0f)) return fail("the voxel size is not sensible");
    const Json& sz = j.get("size");
    if (!sz.isArray() || sz.size() != 3) return fail("the grid size is missing");
    a.size = glm::ivec3(sz.at(0).integer(), sz.at(1).integer(), sz.at(2).integer());
    if (a.size.x < 2 || a.size.y < 2 || a.size.z < 2 || a.size.x > kMaxAssetAxis || a.size.y > kMaxAssetAxis || a.size.z > kMaxAssetAxis)
        return fail("the grid size is out of range");
    a.pivot = jsonVec3(j.get("pivot"), glm::vec3(float(a.size.x / 2), 1.0f, float(a.size.z / 2)));
    a.sockets.clear();
    std::set<std::string> seen;
    for (size_t i = 0; i < j.get("sockets").size(); ++i) {
        const Json& o = j.get("sockets").at(i);
        Socket s;
        s.name = o.get("name").str();
        if (s.name.empty() || !seen.insert(s.name).second) continue;
        s.position = jsonVec3(o.get("position"), glm::vec3(0.0f));
        const glm::vec3 d = jsonVec3(o.get("direction"), glm::vec3(0, 1, 0));
        s.direction = glm::length(d) > 1e-4f ? glm::normalize(d) : glm::vec3(0, 1, 0);
        a.sockets.push_back(std::move(s));
    }
    return true;
}

// ------------------------------------------------------------------ whole file

std::string assetToBytes(const Asset& a) {
    std::string out;
    out.append(kMagic, 4);
    put32(out, kVersion);
    const std::string meta = assetToJson(a).dump(2);
    put32(out, uint32_t(meta.size()));
    out += meta;

    std::vector<std::uint8_t> q(a.grid.size());
    for (size_t i = 0; i < q.size(); ++i) q[i] = std::uint8_t(quantise(a.grid[i]));
    std::string dens;
    rleEncode(q, dens);
    put32(out, uint32_t(dens.size()));
    out += dens;

    std::vector<std::uint8_t> m(a.grid.size(), std::uint8_t(MAT_STONE));
    if (a.materials.size() == a.grid.size()) for (size_t i = 0; i < m.size(); ++i) m[i] = a.materials[i];
    std::string mats;
    rleEncode(m, mats);
    put32(out, uint32_t(mats.size()));
    out += mats;
    return out;
}

AssetPtr assetFromBytes(const std::string& bytes, std::string* error) {
    auto fail = [&](const std::string& why) -> AssetPtr { if (error) *error = why; return nullptr; };
    if (bytes.size() < 12 || std::memcmp(bytes.data(), kMagic, 4) != 0) return fail("this is not a .pxasset file");
    size_t at = 4;
    uint32_t version = 0, metaBytes = 0;
    get32(bytes, at, version);
    if (version == 0 || version > kVersion) return fail("this asset was made by a newer version of Spire Engine");
    if (!get32(bytes, at, metaBytes) || at + metaBytes > bytes.size()) return fail("the file is cut short");
    Json meta;
    std::string jerr;
    if (!Json::parse(bytes.substr(at, metaBytes), meta, &jerr)) return fail("the description is damaged (" + jerr + ")");
    at += metaBytes;

    auto a = std::make_shared<Asset>();
    if (!assetFromJson(meta, *a, error)) return nullptr;
    const size_t cells = size_t(a->size.x) * size_t(a->size.y) * size_t(a->size.z);

    uint32_t denseBytes = 0, matBytes = 0;
    if (!get32(bytes, at, denseBytes) || at + denseBytes > bytes.size()) return fail("the file is cut short");
    std::vector<std::uint8_t> q;
    if (!rleDecode(bytes.data() + at, denseBytes, cells, q)) return fail("the voxel data is damaged");
    at += denseBytes;
    if (!get32(bytes, at, matBytes) || at + matBytes > bytes.size()) return fail("the file is cut short");
    std::vector<std::uint8_t> m;
    if (!rleDecode(bytes.data() + at, matBytes, cells, m)) return fail("the material data is damaged");

    a->grid.resize(cells);
    a->materials.resize(cells);
    for (size_t i = 0; i < cells; ++i) {
        a->grid[i] = dequantise(std::int8_t(q[i]));
        a->materials[i] = m[i] < MAT_COUNT ? MaterialId(m[i]) : MaterialId(MAT_STONE);
    }
    a->userMade = true;
    a->buildMesh();
    return a;
}

bool saveAssetFile(const Asset& a, const std::string& path) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const fs::path p(path);
    if (p.has_parent_path()) fs::create_directories(p.parent_path(), ec);
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        const std::string bytes = assetToBytes(a);
        f.write(bytes.data(), std::streamsize(bytes.size()));
        if (!f) return false;
    }
    fs::rename(tmp, p, ec);
    if (ec) { fs::remove(tmp, ec); return false; }
    return true;
}

AssetPtr loadAssetFile(const std::string& path, std::string* error) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { if (error) *error = "the file can't be opened"; return nullptr; }
    std::ostringstream ss;
    ss << f.rdbuf();
    return assetFromBytes(ss.str(), error);
}

} // namespace px
