#include "scene/Asset.h"
#include "scene/AssetFile.h"
#include "MarchingCubesTables.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <filesystem>
#include <set>

namespace px {

// ---------------------------------------------------------------- sampling

namespace {
float cellAt(const Asset& a, int x, int y, int z) {            // air outside the grid
    if (x < 0 || y < 0 || z < 0 || x >= a.size.x || y >= a.size.y || z >= a.size.z) return DENSITY_CLAMP;
    return a.grid[size_t(a.index(x, y, z))];
}
}

float Asset::density(const glm::vec3& local) const {
    if (!valid()) return DENSITY_CLAMP * voxelSize;
    const glm::vec3 g = local / voxelSize + pivot;               // grid coordinates
    const glm::vec3 hi(float(size.x - 1), float(size.y - 1), float(size.z - 1));
    const glm::vec3 c = glm::clamp(g, glm::vec3(0.0f), hi);
    const glm::ivec3 i0(int(std::floor(c.x)), int(std::floor(c.y)), int(std::floor(c.z)));
    const glm::vec3 f = c - glm::vec3(i0);
    auto s = [&](int dx, int dy, int dz) { return cellAt(*this, std::min(i0.x + dx, size.x - 1), std::min(i0.y + dy, size.y - 1), std::min(i0.z + dz, size.z - 1)); };
    const float x00 = glm::mix(s(0, 0, 0), s(1, 0, 0), f.x), x10 = glm::mix(s(0, 1, 0), s(1, 1, 0), f.x);
    const float x01 = glm::mix(s(0, 0, 1), s(1, 0, 1), f.x), x11 = glm::mix(s(0, 1, 1), s(1, 1, 1), f.x);
    float d = glm::mix(glm::mix(x00, x10, f.y), glm::mix(x01, x11, f.y), f.z);
    d += glm::length(g - c);                                     // outside: farther from the model = more air
    return d * voxelSize;
}

glm::vec3 Asset::gradient(const glm::vec3& p) const {
    const float e = voxelSize * 0.5f;
    const glm::vec3 g(density(p + glm::vec3(e, 0, 0)) - density(p - glm::vec3(e, 0, 0)),
                      density(p + glm::vec3(0, e, 0)) - density(p - glm::vec3(0, e, 0)),
                      density(p + glm::vec3(0, 0, e)) - density(p - glm::vec3(0, 0, e)));
    const float len = glm::length(g);
    return len > 1e-6f ? g / len : glm::vec3(0, 1, 0);
}

MaterialId Asset::materialNear(const glm::vec3& local) const {
    if (!valid() || materials.size() != grid.size()) return MAT_STONE;
    const glm::vec3 g = local / voxelSize + pivot;
    const int x = std::clamp(int(std::lround(g.x)), 0, size.x - 1), y = std::clamp(int(std::lround(g.y)), 0, size.y - 1), z = std::clamp(int(std::lround(g.z)), 0, size.z - 1);
    const MaterialId m = materials[size_t(index(x, y, z))];
    return m == MAT_NATURAL ? MaterialId(MAT_STONE) : m;
}

bool Asset::raycast(const glm::vec3& o, const glm::vec3& d, float maxDist, float& tHit) const {
    if (!valid()) return false;
    // Clip the ray to the model's box first, then march in steps smaller than a voxel.
    const glm::vec3 lo = (glm::vec3(0.0f) - pivot) * voxelSize - glm::vec3(voxelSize),
                    hi = (glm::vec3(size) - glm::vec3(1.0f) - pivot) * voxelSize + glm::vec3(voxelSize);
    float t0 = 0.0f, t1 = maxDist;
    for (int a = 0; a < 3; ++a) {
        if (std::fabs(d[a]) < 1e-8f) { if (o[a] < lo[a] || o[a] > hi[a]) return false; continue; }
        float ta = (lo[a] - o[a]) / d[a], tb = (hi[a] - o[a]) / d[a];
        if (ta > tb) std::swap(ta, tb);
        t0 = std::max(t0, ta); t1 = std::min(t1, tb);
        if (t0 > t1) return false;
    }
    const float step = voxelSize * 0.35f;
    float prevT = t0, prev = density(o + d * t0);
    if (prev < 0.0f) { tHit = t0; return true; }
    for (float t = t0 + step; t <= t1 + step; t += step) {
        const float tt = std::min(t, t1);
        const float v = density(o + d * tt);
        if (v < 0.0f) {                                          // crossed the surface: refine by bisection
            float a = prevT, b = tt;
            for (int i = 0; i < 12; ++i) { const float m = 0.5f * (a + b); (density(o + d * m) < 0.0f ? b : a) = m; }
            tHit = b;
            return true;
        }
        prevT = tt; prev = v;
        if (tt >= t1) break;
    }
    (void)prev;
    return false;
}

// ---------------------------------------------------------------- meshing

void Asset::meshCells(const glm::ivec3& from, const glm::ivec3& to, std::vector<Vertex>& out) const {
    static const glm::ivec3 corner[8] = {{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    static const int edge[12][2] = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
    if (!valid()) return;

    auto sample = [&](int x, int y, int z) { return cellAt(*this, x, y, z); };
    auto gradAt = [&](int x, int y, int z) {
        const glm::vec3 g(sample(x + 1, y, z) - sample(x - 1, y, z), sample(x, y + 1, z) - sample(x, y - 1, z), sample(x, y, z + 1) - sample(x, y, z - 1));
        const float len = glm::length(g);
        return len > 1e-5f ? g / len : glm::vec3(0, 1, 0);
    };
    auto matAt = [&](int x, int y, int z) {
        x = std::clamp(x, 0, size.x - 1); y = std::clamp(y, 0, size.y - 1); z = std::clamp(z, 0, size.z - 1);
        MaterialId m = materials.size() == grid.size() ? materials[size_t(index(x, y, z))] : MaterialId(MAT_STONE);
        return m == MAT_NATURAL || m >= MAT_COUNT ? MaterialId(MAT_STONE) : m;
    };
    auto ao = [&](const glm::vec3& p, const glm::vec3& n) {
        float v = 1.0f;
        for (int i = 1; i <= 3; ++i) {
            const glm::vec3 s = p + n * (float(i) * 0.75f);
            if (sample(int(std::round(s.x)), int(std::round(s.y)), int(std::round(s.z))) < 0.0f) v -= 0.35f / float(i);
        }
        return std::max(0.15f, v);
    };

    const glm::ivec3 lo = glm::max(from, glm::ivec3(-1)), hi = glm::min(to, size - glm::ivec3(1));
    for (int z = lo.z; z <= hi.z; ++z)
        for (int y = lo.y; y <= hi.y; ++y)
            for (int x = lo.x; x <= hi.x; ++x) {
                float val[8]; int cubeIndex = 0;
                for (int i = 0; i < 8; ++i) {
                    val[i] = sample(x + corner[i].x, y + corner[i].y, z + corner[i].z);
                    if (val[i] < 0.0f) cubeIndex |= (1 << i);
                }
                const int edges = edgeTable[cubeIndex];
                if (edges == 0) continue;

                glm::vec3 ev[12], en[12];
                MaterialId em[12];
                for (int e = 0; e < 12; ++e) {
                    if (!(edges & (1 << e))) continue;
                    const int a = edge[e][0], b = edge[e][1];
                    const float denom = val[b] - val[a];
                    const float t = std::abs(denom) > 1e-6f ? std::clamp(-val[a] / denom, 0.0f, 1.0f) : 0.5f;
                    const glm::ivec3 pa = glm::ivec3(x, y, z) + corner[a], pb = glm::ivec3(x, y, z) + corner[b];
                    ev[e] = glm::mix(glm::vec3(pa), glm::vec3(pb), t);
                    const glm::vec3 n = glm::mix(gradAt(pa.x, pa.y, pa.z), gradAt(pb.x, pb.y, pb.z), t);
                    en[e] = glm::length(n) > 1e-5f ? glm::normalize(n) : glm::vec3(0, 1, 0);
                    const glm::ivec3 ps = val[a] < 0.0f ? pa : pb;
                    em[e] = matAt(ps.x, ps.y, ps.z);
                }
                for (int i = 0; triTable[cubeIndex][i] != -1; i += 3) {
                    int i0 = triTable[cubeIndex][i], i1 = triTable[cubeIndex][i + 1], i2 = triTable[cubeIndex][i + 2];
                    const glm::vec3 faceN = glm::cross(ev[i1] - ev[i0], ev[i2] - ev[i0]);
                    if (glm::dot(faceN, en[i0] + en[i1] + en[i2]) < 0.0f) std::swap(i1, i2);
                    const std::uint8_t l0 = std::uint8_t(em[i0] - 1), l1 = std::uint8_t(em[i1] - 1), l2 = std::uint8_t(em[i2] - 1);
                    const int tri[3] = { i0, i1, i2 };
                    for (int k = 0; k < 3; ++k) {
                        const glm::vec3 local = (ev[tri[k]] - pivot) * voxelSize;
                        Vertex v{ local, en[tri[k]], ao(ev[tri[k]], en[tri[k]]), { l0, l1, l2, 0 }, { 0, 0, 0, 0 } };
                        v.bary[k] = 255;
                        out.push_back(v);
                    }
                }
            }
}

void Asset::updateBounds() {
    if (mesh.empty()) { boundsMin = boundsMax = glm::vec3(0.0f); return; }
    boundsMin = glm::vec3(1e9f); boundsMax = glm::vec3(-1e9f);
    for (const Vertex& v : mesh) { boundsMin = glm::min(boundsMin, v.position); boundsMax = glm::max(boundsMax, v.position); }
}

void Asset::buildMesh() {
    mesh.clear();
    ++version;
    if (!valid()) { boundsMin = boundsMax = glm::vec3(0.0f); return; }
    meshCells(glm::ivec3(-1), size - glm::ivec3(1), mesh);        // one cell of air all round, so a model touching the edge of its grid is still closed
    updateBounds();
}

const char* assetTypeName(AssetType t) {
    switch (t) {
    case AssetType::Prop: return "Prop";
    case AssetType::BuildingPiece: return "Building piece";
    case AssetType::CharacterPart: return "Character part";
    case AssetType::Item: return "Item";
    case AssetType::VehiclePart: return "Vehicle part";
    }
    return "Prop";
}

std::shared_ptr<Asset> Asset::fromPrefab(const Prefab& p) {
    auto a = std::make_shared<Asset>();
    a->name = p.name;
    a->size = glm::ivec3(p.size);
    a->voxelSize = 1.0f;
    a->pivot = glm::vec3(float(p.size / 2), 1.0f, float(p.size / 2));       // the same spot a stamp puts on the clicked point
    a->grid = p.grid;
    a->materials = p.materials;
    a->buildMesh();
    return a;
}

// ---------------------------------------------------------------- library

AssetPtr AssetLibrary::get(const std::string& name) {
    if (auto it = cache.find(name); it != cache.end()) return it->second;
    if (auto g = generated.find(name); g != generated.end()) {
        AssetPtr a = g->second.make ? g->second.make() : nullptr;
        if (a) cache[name] = a;
        return a;
    }
    for (const auto& [prefix, make] : families)
        if (name.rfind(prefix, 0) == 0) {
            AssetPtr a = make ? make(name) : nullptr;
            if (a) { a->name = name; a->userMade = false; cache[name] = a; }
            return a;
        }
    if (auto p = prefabs.get(name)) {
        AssetPtr a = Asset::fromPrefab(*p);
        cache[name] = a;
        return a;
    }
    return nullptr;
}

std::vector<std::string> AssetLibrary::names() const {
    std::set<std::string> all;
    for (const auto& n : prefabs.names()) all.insert(n);
    for (const auto& [n, _] : cache) all.insert(n);
    for (const auto& [n, _] : generated) all.insert(n);
    return { all.begin(), all.end() };
}

void AssetLibrary::add(AssetPtr a) { if (a) { cache[a->name] = std::move(a); ++rev; } }

void AssetLibrary::addGenerated(const std::string& name, std::vector<std::string> tags, Factory make) {
    if (name.empty() || !make) return;
    if (!generated.count(name)) generatedOrder.push_back(name);
    generated[name] = Generated{ std::move(tags), std::move(make) };
    cache.erase(name);
    ++rev;
}

void AssetLibrary::addFamily(const std::string& prefix, FamilyFactory make) {
    if (prefix.empty() || !make) return;
    families.emplace_back(prefix, std::move(make));
    ++rev;
}

bool AssetLibrary::inFamily(const std::string& name) const {
    for (const auto& f : families) if (name.rfind(f.first, 0) == 0) return true;
    return false;
}

bool AssetLibrary::isGenerated(const std::string& name) const {
    if (inFamily(name)) { auto it = cache.find(name); return it == cache.end() || !it->second->userMade; }
    if (!generated.count(name)) return false;
    auto it = cache.find(name);
    return it == cache.end() || !it->second->userMade;
}

bool AssetLibrary::tagsOf(const std::string& name, std::vector<std::string>& tags) const {
    if (auto it = cache.find(name); it != cache.end()) { tags = it->second->tags; return true; }
    if (auto g = generated.find(name); g != generated.end()) { tags = g->second.tags; return true; }
    return false;
}

std::string AssetLibrary::fileNameFor(const std::string& assetName) {
    std::string out;
    for (unsigned char c : assetName) {
        if (std::isalnum(c) || c == '_' || c == '-') out += char(c);
        else if (c == ' ') out += '_';
    }
    return out.empty() ? std::string("asset") : out;
}

int AssetLibrary::loadDirectory(const std::string& dir) {
    namespace fs = std::filesystem;
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) return 0;
    int n = 0;
    for (const auto& e : fs::directory_iterator(dir, ec)) {
        if (!e.is_regular_file() || e.path().extension() != ".pxasset") continue;
        if (AssetPtr a = loadAssetFile(e.path().string())) { add(a); ++n; }
    }
    return n;
}

bool AssetLibrary::saveAsset(const Asset& a, const std::string& dir) {
    if (a.name.empty() || !a.valid()) return false;
    const std::string path = (std::filesystem::path(dir) / (fileNameFor(a.name) + ".pxasset")).string();
    if (!saveAssetFile(a, path)) return false;
    auto copy = std::make_shared<Asset>(a);          // the library keeps its own copy: the Workshop goes on editing its own
    copy->userMade = true;
    add(std::move(copy));
    return true;
}

bool AssetLibrary::isUserMade(const std::string& name) const {
    auto it = cache.find(name);
    return it != cache.end() && it->second->userMade;
}

} // namespace px
