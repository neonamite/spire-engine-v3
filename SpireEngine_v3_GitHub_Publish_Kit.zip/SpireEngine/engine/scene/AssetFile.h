#pragma once
// The .pxasset file: one thing made in the Asset Workshop.
//
//   "PXAS"  u32 version   u32 metaBytes  <meta: readable JSON>   u32 densityBytes <data>   u32 materialBytes <data>
//
// The JSON holds everything people or tools may want to read or edit by hand (name, type, tags,
// voxel size, grid size, pivot, sockets). The voxel data follows as two run-length-coded byte
// streams: density quantised to 1/16 of a voxel, and one material byte per voxel.
#include <string>
#include "core/Json.h"
#include "scene/Asset.h"

namespace px {

Json assetToJson(const Asset& a);                                        // the readable part
bool assetFromJson(const Json& j, Asset& a, std::string* error = nullptr);   // metadata only (no voxels)

std::string assetToBytes(const Asset& a);                                // the whole file
AssetPtr assetFromBytes(const std::string& bytes, std::string* error = nullptr);   // meshed; nullptr if it isn't a usable asset

bool saveAssetFile(const Asset& a, const std::string& path);             // atomic: temp file, then rename
AssetPtr loadAssetFile(const std::string& path, std::string* error = nullptr);

constexpr int kMaxAssetAxis = 192;                                       // samples per axis a file may ask for

} // namespace px
