#pragma once
// Building Kits: snap-together pieces (walls, windows, doorways, floors, roofs, stairs, pillars) that
// share one grid, so a house goes up in a few clicks. A kit piece is an ordinary asset (type Building
// piece) with two tags that say what it is:
//     kit:<Style name>        e.g. "kit:Brick house"
//     role:<piece>            e.g. "role:wall"
// Pieces that share a style name make a kit; pieces that share a role are interchangeable, which is what
// "swap the style" uses. This file is the pure logic (no window, no OpenGL): the grid, where a piece
// snaps to, which pieces compete for the same spot, and the catalog of kits found in the asset library.
//
// The grid (world axes, metres):
//   * a CELL is 2 x 2 m; cell corners sit on even numbers (x = 0, 2, 4 ...), the same everywhere in the world
//   * a STOREY is 2.5 m from the top of one floor to the top of the next; a floor slab is 0.2 m thick
//   * a level's PLANE is the height of the bottom of its floor slab: plane(n) = base + n * 2.5
//   * floors and roofs sit ON the plane; walls, windows, doorways, stairs and pillars stand on the floor top
//     (plane + 0.2) and are 2.3 m tall, so the next level's slab lies on their tops
//   * walls run along cell edges (centred on the edge, 2.2 m long so corners close), floors and roofs fill a
//     cell, pillars stand on cell corners, stairs fill two cells (4 m long, 1 cell wide) and climb one storey
#include <array>
#include <cstdint>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "scene/Asset.h"

namespace px {

constexpr float kKitCell   = 2.0f;
constexpr float kKitStorey = 2.5f;
constexpr float kKitSlab   = 0.2f;
constexpr float kKitWallHeight = kKitStorey - kKitSlab;      // 2.3 m

enum class KitRole : std::uint8_t { None, Wall, Window, Doorway, Floor, Roof, Stairs, Pillar };
constexpr int kKitRoleCount = 8;                              // including None
const char* kitRoleName(KitRole r);                           // "wall": what the tag says
const char* kitRoleLabel(KitRole r);                          // "Wall": what the panels say
const char* kitRoleInfo(KitRole r);                           // one line for tooltips
KitRole     kitRoleFromName(const std::string& s);            // None when it isn't one (case does not matter)
bool kitIsEdgePiece(KitRole r);                               // wall, window, doorway: they stand on a cell edge
inline bool kitRoleValid(KitRole r) { return r != KitRole::None; }

// The two tags that make an asset a kit piece.
std::vector<std::string> kitTagList(const std::string& style, KitRole role);
bool kitParseTags(const std::vector<std::string>& tags, std::string& style, KitRole& role);   // false unless both are there
// The tags with the kit ones replaced (or added), other tags kept.
std::vector<std::string> kitRetag(const std::vector<std::string>& tags, const std::string& style, KitRole role);

// How far above its level's plane a piece's origin sits.
float kitRoleLift(KitRole r);

struct KitSpot {
    glm::vec3 position{ 0.0f };      // where the asset's origin goes (world, metres)
    float     yaw = 0.0f;            // degrees
};

// Where a piece of this role lands when the cursor is at `aim`, for the level whose plane is `plane`.
// `turns` is how many times the player pressed Rotate (a quarter turn each; walls only flip front for back).
KitSpot kitSnap(KitRole role, const glm::vec3& aim, float plane, int turns);

// The plane of the storey that the height `h` belongs to when `plane` is the plane of the storey you are on:
// pointing at the top of a wall means the storey above it.
float kitPlaneAt(float plane, float h);
// The plane an existing piece stands on, from where its origin is.
float kitPlaneOf(KitRole role, float originY);
// "Ground floor", "Floor 1", "Basement 1".
std::string kitLevelLabel(int level);

// Two pieces compete for one spot when they could not both be there: a wall and a window on the same edge, two
// floors in one cell, and so on. Placing the second replaces the first.
bool kitSameSlot(KitRole a, const glm::vec3& posA, float yawA, KitRole b, const glm::vec3& posB, float yawB);

// ---------------------------------------------------------------- the catalog of kits

struct KitStyleEntry {
    std::string name;
    bool builtin = false;                                   // made by the engine (the others are yours)
    std::array<std::string, kKitRoleCount> piece;           // asset name per role; "" = this kit has none
    int pieces() const { int n = 0; for (const auto& p : piece) n += p.empty() ? 0 : 1; return n; }
};

class KitCatalog {
public:
    // Reads every asset's kit tags. Cheap enough to call when the library changed (built-in pieces are not built to be listed).
    void rebuild(const AssetLibrary& lib);
    void update(const AssetLibrary& lib) { if (!built || builtFor != lib.revision()) rebuild(lib); }
    const std::vector<KitStyleEntry>& styles() const { return list; }
    const KitStyleEntry* find(const std::string& style) const;
    std::string piece(const std::string& style, KitRole role) const;        // asset name or ""
    // The same role in another style: the asset to swap to ("" when this isn't a kit piece or that style lacks the role).
    std::string restyle(const AssetLibrary& lib, const std::string& assetName, const std::string& newStyle) const;
private:
    std::vector<KitStyleEntry> list;
    std::uint64_t builtFor = 0;
    bool built = false;
};

} // namespace px
