#include "scene/Scene.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <set>
#include <sstream>
#include "world/WorldTypes.h"

namespace px {

const char* motionName(MotionSettings::Kind k) {
    switch (k) {
    case MotionSettings::Kind::None:  return "None";
    case MotionSettings::Kind::Spin:  return "Spin";
    case MotionSettings::Kind::Bob:   return "Bob up and down";
    case MotionSettings::Kind::Sway:  return "Sway";
    case MotionSettings::Kind::Slide: return "Slide back and forth";
    }
    return "None";
}

// ---------------------------------------------------------------- transform helpers

glm::quat quatFromEuler(const glm::vec3& d) {
    return glm::angleAxis(glm::radians(d.y), glm::vec3(0, 1, 0)) *
           glm::angleAxis(glm::radians(d.x), glm::vec3(1, 0, 0)) *
           glm::angleAxis(glm::radians(d.z), glm::vec3(0, 0, 1));
}

glm::vec3 eulerFromMatrix(const glm::mat3& m) {
    // m = Ry * Rx * Rz. glm indexes m[column][row].
    const float m13 = m[2][0], m23 = m[2][1], m33 = m[2][2], m21 = m[0][1], m22 = m[1][1], m31 = m[0][2], m11 = m[0][0];
    float x = std::asin(-std::clamp(m23, -1.0f, 1.0f)), y, z;
    if (std::fabs(m23) < 0.9999999f) { y = std::atan2(m13, m33); z = std::atan2(m21, m22); }
    else                              { y = std::atan2(-m31, m11); z = 0.0f; }
    return glm::degrees(glm::vec3(x, y, z));
}

glm::mat4 composeTransform(const glm::vec3& position, const glm::vec3& rotationDeg, float scale) {
    glm::mat4 m = glm::mat4_cast(quatFromEuler(rotationDeg));
    m[0] *= scale; m[1] *= scale; m[2] *= scale;
    m[3] = glm::vec4(position, 1.0f);
    return m;
}

Decomposed decomposeTransform(const glm::mat4& m) {
    Decomposed d;
    d.position = glm::vec3(m[3]);
    d.scale = std::max(1e-5f, glm::length(glm::vec3(m[0])));
    d.rotation = eulerFromMatrix(glm::mat3(glm::vec3(m[0]) / d.scale, glm::vec3(m[1]) / d.scale, glm::vec3(m[2]) / d.scale));
    return d;
}

namespace {
constexpr float kTwoPi = 6.28318530718f;

// The object's own transform with its motion applied for this moment.
glm::mat4 localMatrix(const SceneObject& o, double time, bool animate) {
    glm::vec3 pos = o.position;
    glm::quat rot = quatFromEuler(o.rotation);
    const MotionSettings& mo = o.motion;
    if (animate && mo.kind != MotionSettings::Kind::None) {
        const glm::vec3 axis = glm::length(mo.axis) > 1e-5f ? glm::normalize(mo.axis) : glm::vec3(0, 1, 0);
        const float t = float(std::fmod(time * double(mo.speed) + double(mo.phase), 1024.0));      // keep float precision for long sessions
        switch (mo.kind) {
        case MotionSettings::Kind::None: break;
        case MotionSettings::Kind::Spin:
            rot = rot * glm::angleAxis(glm::radians(float(std::fmod(time * double(mo.speed) + double(mo.phase) * 360.0, 360.0))), axis);
            break;
        case MotionSettings::Kind::Bob:
            pos += axis * (std::sin(t * kTwoPi) * mo.amount);
            break;
        case MotionSettings::Kind::Sway:
            rot = rot * glm::angleAxis(glm::radians(std::sin(t * kTwoPi) * mo.amount), axis);
            break;
        case MotionSettings::Kind::Slide: {
            const float u = t - std::floor(t);
            const float tri = u < 0.5f ? u * 2.0f : 2.0f - u * 2.0f;
            pos += axis * (glm::smoothstep(0.0f, 1.0f, tri) * mo.amount);
            break;
        }
        }
    }
    glm::mat4 m = glm::mat4_cast(rot);
    m[0] *= o.scale; m[1] *= o.scale; m[2] *= o.scale;
    m[3] = glm::vec4(pos, 1.0f);
    return m;
}
} // namespace

// ---------------------------------------------------------------- objects

int Scene::indexOf(ObjectId id) const {
    auto it = index.find(id);
    return it == index.end() ? -1 : it->second;
}

void Scene::rebuildIndex() {
    index.clear();
    for (int i = 0; i < int(objs.size()); ++i) index[objs[size_t(i)].id] = i;
}

const SceneObject* Scene::find(ObjectId id) const {
    const int i = indexOf(id);
    return i < 0 ? nullptr : &objs[size_t(i)];
}

SceneObject* Scene::mutate(ObjectId id) {
    const int i = indexOf(id);
    if (i < 0) return nullptr;
    ++rev;
    return &objs[size_t(i)];
}

std::string Scene::uniqueName(const std::string& wantedIn) const {
    std::string base = wantedIn.empty() ? std::string("Object") : wantedIn;
    // "Rock 3" counts as a "Rock"
    const size_t sp = base.find_last_of(' ');
    if (sp != std::string::npos && sp + 1 < base.size() && std::all_of(base.begin() + long(sp) + 1, base.end(), [](char c) { return c >= '0' && c <= '9'; }))
        base = base.substr(0, sp);
    std::set<std::string> taken;
    for (const auto& o : objs) taken.insert(o.name);
    if (!taken.count(base)) return base;
    for (int n = 2;; ++n) {
        const std::string c = base + " " + std::to_string(n);
        if (!taken.count(c)) return c;
    }
}

ObjectId Scene::add(SceneObject o) {
    o.id = nextId++;
    o.name = uniqueName(o.name.empty() ? (o.asset.empty() ? std::string("Group") : o.asset) : o.name);
    if (o.parent != 0 && indexOf(o.parent) < 0) o.parent = 0;
    o.scale = std::clamp(o.scale, 0.01f, 100.0f);
    objs.push_back(std::move(o));
    index[objs.back().id] = int(objs.size()) - 1;
    ++rev;
    return objs.back().id;
}

void Scene::removeOne(ObjectId id) {
    const int i = indexOf(id);
    if (i < 0) return;
    objs.erase(objs.begin() + i);
    rebuildIndex();
}

void Scene::remove(ObjectId id) {
    if (indexOf(id) < 0) return;
    std::vector<ObjectId> all = descendants(id);
    all.push_back(id);
    for (ObjectId d : all) removeOne(d);
    ev.clear(); evIndex.clear();
    ++rev;
}

void Scene::clear() {
    objs.clear(); index.clear(); ev.clear(); evIndex.clear(); live.clear(); game.clear();
    nextId = 1;
    ++rev;
    resetHistory();
}

// ---------------------------------------------------------------- hierarchy

std::vector<ObjectId> Scene::children(ObjectId parent) const {
    std::vector<ObjectId> out;
    for (const auto& o : objs) if (o.parent == parent) out.push_back(o.id);
    return out;
}

std::vector<ObjectId> Scene::descendants(ObjectId id) const {
    std::vector<ObjectId> out;
    std::vector<ObjectId> stack{ id };
    while (!stack.empty()) {
        const ObjectId cur = stack.back(); stack.pop_back();
        for (const auto& o : objs)
            if (o.parent == cur && o.id != id && std::find(out.begin(), out.end(), o.id) == out.end()) { out.push_back(o.id); stack.push_back(o.id); }
    }
    return out;
}

bool Scene::isAncestor(ObjectId ancestor, ObjectId of) const {
    int guard = 0;
    for (const SceneObject* o = find(of); o && o->parent != 0 && guard < 256; o = find(o->parent), ++guard)
        if (o->parent == ancestor) return true;
    return false;
}

glm::mat4 Scene::restWorld(ObjectId id) const {
    glm::mat4 m(1.0f);
    int guard = 0;
    for (const SceneObject* o = find(id); o && guard < 256; o = find(o->parent), ++guard) {
        m = localMatrix(*o, 0.0, false) * m;
        if (o->parent == 0) break;
    }
    return m;
}

bool Scene::setRestWorld(ObjectId id, const glm::mat4& world) {
    const SceneObject* o = find(id);
    if (!o) return false;
    const glm::mat4 local = o->parent ? glm::inverse(restWorld(o->parent)) * world : world;
    const Decomposed d = decomposeTransform(local);
    SceneObject* m = mutate(id);
    m->position = d.position;
    m->rotation = d.rotation;
    m->scale = std::clamp(d.scale, 0.01f, 100.0f);
    return true;
}

bool Scene::setParent(ObjectId id, ObjectId newParent, bool keepWorld) {
    const SceneObject* o = find(id);
    if (!o) return false;
    if (newParent != 0 && (!find(newParent) || newParent == id || isAncestor(id, newParent))) return false;
    if (o->parent == newParent) return true;
    const glm::mat4 world = restWorld(id);
    mutate(id)->parent = newParent;
    if (keepWorld) setRestWorld(id, world);
    return true;
}

ObjectId Scene::group(const std::vector<ObjectId>& idsIn, const std::string& name) {
    std::vector<ObjectId> ids;
    for (ObjectId id : idsIn) if (find(id)) ids.push_back(id);
    // Anything already inside another picked object goes along with it.
    ids.erase(std::remove_if(ids.begin(), ids.end(), [&](ObjectId id) {
        return std::any_of(ids.begin(), ids.end(), [&](ObjectId other) { return other != id && isAncestor(other, id); });
    }), ids.end());
    if (ids.empty()) return 0;

    glm::vec3 centre(0.0f);
    for (ObjectId id : ids) centre += glm::vec3(restWorld(id)[3]);
    centre /= float(ids.size());

    SceneObject g;
    g.name = name;
    g.parent = find(ids.front())->parent;
    const glm::mat4 parentWorld = g.parent ? restWorld(g.parent) : glm::mat4(1.0f);
    g.position = glm::vec3(glm::inverse(parentWorld) * glm::vec4(centre, 1.0f));
    const ObjectId gid = add(g);
    for (ObjectId id : ids) setParent(id, gid, true);
    return gid;
}

bool Scene::ungroup(ObjectId groupId) {
    const SceneObject* g = find(groupId);
    if (!g || !g->isGroup()) return false;
    const ObjectId up = g->parent;
    for (ObjectId c : children(groupId)) setParent(c, up, true);
    remove(groupId);
    return true;
}

ObjectId Scene::duplicate(ObjectId id, const glm::vec3& offset) {
    if (!find(id)) return 0;
    std::vector<ObjectId> all{ id };
    for (ObjectId d : descendants(id)) all.push_back(d);
    // Parents come before children in `all`, because descendants() walks down from the root.
    std::unordered_map<ObjectId, ObjectId> made;
    ObjectId root = 0;
    for (ObjectId old : all) {
        SceneObject c = *find(old);
        if (old == id) c.position += offset;
        else c.parent = made.at(c.parent);
        c.name = uniqueName(c.name);
        const ObjectId nid = add(c);
        made[old] = nid;
        if (old == id) root = nid;
    }
    return root;
}

void Scene::moveInOrder(ObjectId id, int newIndex) {
    const SceneObject* o = find(id);
    if (!o) return;
    const ObjectId parent = o->parent;
    std::vector<ObjectId> sib = children(parent);
    sib.erase(std::remove(sib.begin(), sib.end(), id), sib.end());
    newIndex = std::clamp(newIndex, 0, int(sib.size()));
    sib.insert(sib.begin() + newIndex, id);
    // Re-fill the slots the siblings occupy, in the new order.
    std::vector<int> slots;
    for (int i = 0; i < int(objs.size()); ++i) if (objs[size_t(i)].parent == parent) slots.push_back(i);
    std::vector<SceneObject> ordered;
    for (ObjectId s : sib) ordered.push_back(*find(s));
    for (size_t k = 0; k < slots.size(); ++k) objs[size_t(slots[k])] = ordered[k];
    rebuildIndex();
    ++rev;
}

// ---------------------------------------------------------------- per frame

void Scene::evaluate(AssetLibrary& assets, double time, bool animate) {
    ev.clear(); evIndex.clear();
    const int n = int(objs.size());
    ev.resize(size_t(n));
    std::vector<char> done(size_t(n), 0);

    std::function<void(int, int)> resolve = [&](int i, int depth) {
        if (done[size_t(i)]) return;
        const SceneObject& o = objs[size_t(i)];
        Evaluated& e = ev[size_t(i)];
        glm::mat4 parentWorld(1.0f);
        float parentScale = 1.0f;
        bool parentVisible = true;
        const int pi = o.parent ? indexOf(o.parent) : -1;
        if (pi >= 0 && depth < 128) {
            resolve(pi, depth + 1);
            parentWorld = ev[size_t(pi)].world; parentScale = ev[size_t(pi)].scale; parentVisible = ev[size_t(pi)].visible;
        }
        e.id = o.id; e.index = i;
        const auto lv = live.find(o.id);
        if (lv != live.end() && lv->second.kind == 1) e.world = composeTransform(lv->second.pos, glm::vec3(0.0f, lv->second.yaw, 0.0f), parentScale * o.scale);
        else if (lv != live.end() && lv->second.kind == 2) e.world = lv->second.m;
        else e.world = parentWorld * localMatrix(o, time, animate);
        e.inverse = glm::inverse(e.world);
        e.scale = parentScale * o.scale;
        e.visible = o.visible && parentVisible && !(lv != live.end() && lv->second.hidden);
        e.locked = o.locked;
        e.solid = false;
        done[size_t(i)] = 1;
    };
    for (int i = 0; i < n; ++i) resolve(i, 0);

    for (int i = 0; i < n; ++i) {
        Evaluated& e = ev[size_t(i)];
        const SceneObject& o = objs[size_t(i)];
        evIndex[e.id] = i;
        e.centre = glm::vec3(e.world[3]);
        e.radius = 0.0f;
        if (o.isGroup()) continue;
        e.asset = assets.get(o.asset);
        if (!e.asset || e.asset->mesh.empty()) { e.asset = nullptr; continue; }
        const glm::vec3 c = e.asset->center();
        e.centre = glm::vec3(e.world * glm::vec4(c, 1.0f));
        e.radius = (glm::length(e.asset->extent()) * 0.5f + e.asset->voxelSize * 2.0f) * e.scale;
        e.solid = e.visible && o.solid;
    }
}

void Scene::setLive(ObjectId id, const glm::vec3& worldPos, float yawDegrees) { Live& l = live[id]; l.kind = 1; l.pos = worldPos; l.yaw = yawDegrees; }
void Scene::setLiveMatrix(ObjectId id, const glm::mat4& world) { Live& l = live[id]; l.kind = 2; l.m = world; }
void Scene::setLiveHidden(ObjectId id, bool hidden) { live[id].hidden = hidden; }

const Evaluated* Scene::evaluatedFor(ObjectId id) const {
    auto it = evIndex.find(id);
    return it == evIndex.end() || it->second >= int(ev.size()) ? nullptr : &ev[size_t(it->second)];
}

// ---------------------------------------------------------------- questions

bool Scene::raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist, Hit& hit, bool includeLocked, bool skipCharacters) const {
    bool found = false;
    float best = maxDist;
    for (const Evaluated& e : ev) {
        if (!e.asset || !e.visible || (e.locked && !includeLocked)) continue;
        if (skipCharacters && size_t(e.index) < objs.size() && !objs[size_t(e.index)].character.empty()) continue;
        // Quick reject against the bounding sphere.
        const glm::vec3 oc = origin - e.centre;
        const float b = glm::dot(oc, dir), c = glm::dot(oc, oc) - e.radius * e.radius;
        const float disc = b * b - c;
        if (disc < 0.0f || (-b + std::sqrt(disc)) < 0.0f || (-b - std::sqrt(disc)) > best) continue;

        const glm::vec3 lo = glm::vec3(e.inverse * glm::vec4(origin, 1.0f));
        const glm::vec3 ld = glm::normalize(glm::vec3(e.inverse * glm::vec4(dir, 0.0f)));
        float tl = 0.0f;
        if (!e.asset->raycast(lo, ld, best / e.scale, tl)) continue;
        const float t = tl * e.scale;
        if (t < best) {
            best = t; found = true;
            hit.id = e.id; hit.distance = t; hit.point = origin + dir * t;
            const glm::vec3 g = e.asset->gradient(lo + ld * tl);
            hit.normal = glm::normalize(glm::vec3(e.world * glm::vec4(g, 0.0f)));
        }
    }
    return found;
}

float Scene::density(const glm::vec3& p) const {
    float best = DENSITY_CLAMP;
    for (const Evaluated& e : ev) {
        if (!e.solid) continue;
        if (glm::distance(p, e.centre) - e.radius > 4.0f) continue;
        const float d = e.asset->density(glm::vec3(e.inverse * glm::vec4(p, 1.0f))) * e.scale;
        best = std::min(best, d);
    }
    return best;
}

glm::vec3 Scene::gradient(const glm::vec3& p) const {
    float best = 1e9f;
    const Evaluated* nearest = nullptr;
    for (const Evaluated& e : ev) {
        if (!e.solid) continue;
        if (glm::distance(p, e.centre) - e.radius > 4.0f) continue;
        const float d = e.asset->density(glm::vec3(e.inverse * glm::vec4(p, 1.0f))) * e.scale;
        if (d < best) { best = d; nearest = &e; }
    }
    if (!nearest) return glm::vec3(0, 1, 0);
    const glm::vec3 g = nearest->asset->gradient(glm::vec3(nearest->inverse * glm::vec4(p, 1.0f)));
    return glm::normalize(glm::vec3(nearest->world * glm::vec4(g, 0.0f)));
}

bool Scene::worldBounds(ObjectId id, glm::vec3& mn, glm::vec3& mx) const {
    bool any = false;
    mn = glm::vec3(1e9f); mx = glm::vec3(-1e9f);
    std::vector<ObjectId> all = descendants(id);
    all.push_back(id);
    for (ObjectId oid : all) {
        const Evaluated* e = evaluatedFor(oid);
        if (!e || !e->asset) continue;
        const glm::vec3 a = e->asset->boundsMin, b = e->asset->boundsMax;
        for (int k = 0; k < 8; ++k) {
            const glm::vec3 c((k & 1) ? b.x : a.x, (k & 2) ? b.y : a.y, (k & 4) ? b.z : a.z);
            const glm::vec3 w = glm::vec3(e->world * glm::vec4(c, 1.0f));
            mn = glm::min(mn, w); mx = glm::max(mx, w);
        }
        any = true;
    }
    if (!any) {                 // an empty group: just its own position
        const Evaluated* e = evaluatedFor(id);
        if (!e) return false;
        mn = mx = glm::vec3(e->world[3]);
        return true;
    }
    return true;
}

// ---------------------------------------------------------------- saving

namespace {
std::string quote(const std::string& s) {
    std::string out = "\"";
    for (char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += c; }
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else out += c;
    }
    return out + "\"";
}
std::string num(float f) { char b[40]; std::snprintf(b, sizeof b, "%.9g", double(f)); return b; }
std::string vec(const glm::vec3& v) { return num(v.x) + "," + num(v.y) + "," + num(v.z); }

// Splits one line into key / value pairs: key=value or key="quoted value".
std::vector<std::pair<std::string, std::string>> tokens(const std::string& line) {
    std::vector<std::pair<std::string, std::string>> out;
    size_t i = 0;
    while (i < line.size()) {
        while (i < line.size() && line[i] == ' ') ++i;
        const size_t kb = i;
        while (i < line.size() && line[i] != '=' && line[i] != ' ') ++i;
        std::string key = line.substr(kb, i - kb), value;
        if (i < line.size() && line[i] == '=') {
            ++i;
            if (i < line.size() && line[i] == '"') {
                ++i;
                while (i < line.size() && line[i] != '"') {
                    if (line[i] == '\\' && i + 1 < line.size()) {
                        ++i;
                        value += line[i] == 'n' ? '\n' : line[i] == 'r' ? '\r' : line[i];
                    } else value += line[i];
                    ++i;
                }
                if (i < line.size()) ++i;
            } else {
                const size_t vb = i;
                while (i < line.size() && line[i] != ' ') ++i;
                value = line.substr(vb, i - vb);
            }
        }
        if (!key.empty()) out.emplace_back(std::move(key), std::move(value));
    }
    return out;
}

bool parseFloats(const std::string& s, float* out, int n) {
    const char* p = s.c_str();
    for (int i = 0; i < n; ++i) {
        char* end = nullptr;
        const float v = std::strtof(p, &end);
        if (end == p || !std::isfinite(v)) return false;
        out[i] = v;
        p = end;
        if (i + 1 < n) { if (*p != ',') return false; ++p; }
    }
    return true;
}
}

std::string Scene::toText() const {
    std::ostringstream out;
    out << "PXSCENE 1\n";
    out << "next " << nextId << "\n";
    if (!game.empty()) out << "game " << quote(game) << "\n";
    for (const auto& o : objs) {
        out << "object id=" << o.id << " parent=" << o.parent << " name=" << quote(o.name) << " asset=" << quote(o.asset)
            << " pos=" << vec(o.position) << " rot=" << vec(o.rotation) << " scale=" << num(o.scale)
            << " visible=" << int(o.visible) << " locked=" << int(o.locked) << " solid=" << int(o.solid);
        if (o.motion.kind != MotionSettings::Kind::None)
            out << " motion=" << int(o.motion.kind) << " maxis=" << vec(o.motion.axis) << " mspeed=" << num(o.motion.speed)
                << " mamount=" << num(o.motion.amount) << " mphase=" << num(o.motion.phase);
        if (!o.blueprint.empty()) out << " blueprint=" << quote(o.blueprint);
        if (!o.character.empty()) out << " character=" << quote(o.character);
        if (!o.npc.empty()) out << " npc=" << quote(o.npc);
        if (!o.rules.empty()) out << " rules=" << quote(o.rules);
        out << "\n";
    }
    return out.str();
}

bool Scene::fromText(const std::string& text) {
    std::istringstream in(text);
    std::string line;
    if (!std::getline(in, line) || line.rfind("PXSCENE ", 0) != 0) return false;

    std::vector<SceneObject> loaded;
    std::string loadedGame;
    ObjectId next = 1;
    std::set<ObjectId> seen;
    while (std::getline(in, line) && loaded.size() < 20000) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.rfind("next ", 0) == 0) { next = ObjectId(std::strtoul(line.c_str() + 5, nullptr, 10)); continue; }
        if (line.rfind("game ", 0) == 0) { for (const auto& [k, v] : tokens("game=" + line.substr(5))) if (k == "game") loadedGame = v.substr(0, 65536); continue; }
        if (line.rfind("object ", 0) != 0) continue;
        SceneObject o;
        float v[3];
        for (const auto& [k, val] : tokens(line.substr(7))) {
            if (k == "id") o.id = ObjectId(std::strtoul(val.c_str(), nullptr, 10));
            else if (k == "parent") o.parent = ObjectId(std::strtoul(val.c_str(), nullptr, 10));
            else if (k == "name") o.name = val.substr(0, 128);
            else if (k == "asset") o.asset = val.substr(0, 128);
            else if (k == "pos" && parseFloats(val, v, 3)) o.position = glm::vec3(v[0], v[1], v[2]);
            else if (k == "rot" && parseFloats(val, v, 3)) o.rotation = glm::vec3(v[0], v[1], v[2]);
            else if (k == "scale" && parseFloats(val, v, 1)) o.scale = std::clamp(v[0], 0.01f, 100.0f);
            else if (k == "visible") o.visible = val != "0";
            else if (k == "locked") o.locked = val == "1";
            else if (k == "solid") o.solid = val != "0";
            else if (k == "motion") { const int m = std::atoi(val.c_str()); o.motion.kind = MotionSettings::Kind(std::clamp(m, 0, 4)); }
            else if (k == "maxis" && parseFloats(val, v, 3)) o.motion.axis = glm::vec3(v[0], v[1], v[2]);
            else if (k == "mspeed" && parseFloats(val, v, 1)) o.motion.speed = v[0];
            else if (k == "mamount" && parseFloats(val, v, 1)) o.motion.amount = v[0];
            else if (k == "mphase" && parseFloats(val, v, 1)) o.motion.phase = v[0];
            else if (k == "blueprint" && val.size() <= 65536) o.blueprint = val;
            else if (k == "character") o.character = val.substr(0, 64);
            else if (k == "npc" && val.size() <= 32768) o.npc = val;
            else if (k == "rules" && val.size() <= 65536) o.rules = val;
        }
        if (o.id == 0 || seen.count(o.id)) continue;       // a damaged line is skipped, the rest still loads
        seen.insert(o.id);
        loaded.push_back(std::move(o));
    }

    // Parents must exist, and nothing may be its own ancestor.
    for (auto& o : loaded) if (o.parent != 0 && !seen.count(o.parent)) o.parent = 0;
    std::unordered_map<ObjectId, ObjectId> parentOf;
    for (const auto& o : loaded) parentOf[o.id] = o.parent;
    for (auto& o : loaded) {
        ObjectId cur = o.parent; int steps = 0;
        while (cur != 0 && cur != o.id && steps++ < 4096) cur = parentOf[cur];
        if (cur == o.id) { o.parent = 0; parentOf[o.id] = 0; }
    }

    objs = std::move(loaded);
    game = std::move(loadedGame);
    ObjectId maxId = 0;
    for (const auto& o : objs) maxId = std::max(maxId, o.id);
    nextId = std::max(next, maxId + 1);
    rebuildIndex();
    ev.clear(); evIndex.clear();
    ++rev;
    resetHistory();
    return true;
}

// ---------------------------------------------------------------- history

Scene::State Scene::snapshot(const std::string& label) const { return State{ objs, nextId, label, game }; }

void Scene::restore(const State& s) {
    objs = s.objs;
    game = s.game;
    nextId = std::max(nextId, s.nextId);
    rebuildIndex();
    ev.clear(); evIndex.clear();
    ++rev;
}

bool Scene::dirtySinceCommit() const { return !(history[cursor].objs == objs) || history[cursor].game != game; }

void Scene::discardUncommitted() { if (dirtySinceCommit()) restore(history[cursor]); }

bool Scene::commit(const std::string& label) {
    if (!dirtySinceCommit()) return false;
    history.resize(cursor + 1);
    history.push_back(snapshot(label));
    ++cursor;
    if (history.size() > kMaxHistory) { history.erase(history.begin()); --cursor; }
    return true;
}

bool Scene::undo() {
    if (!canUndo()) return false;
    // Uncommitted edits are part of what is undone: go back to the last committed state.
    if (dirtySinceCommit()) { restore(history[cursor]); return true; }
    --cursor;
    restore(history[cursor]);
    return true;
}

bool Scene::redo() {
    if (!canRedo()) return false;
    ++cursor;
    restore(history[cursor]);
    return true;
}

void Scene::clearRedo() { history.resize(cursor + 1); }

void Scene::resetHistory() {
    history.clear();
    history.push_back(snapshot(""));
    cursor = 0;
}

} // namespace px
