#include "scene/Trees.h"
#include <cmath>
#include <vector>
#include "scene/SdfModel.h"

namespace px {

using namespace sdf;

namespace {

struct Rng {
    std::uint32_t s;
    explicit Rng(std::uint32_t seed) : s(seed * 2654435761u + 12345u) {}
    float next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return float(s & 0xFFFFFFu) / float(0x1000000u); }
    float range(float a, float b) { return a + (b - a) * next(); }
};

// Bark: shallow furrows running up the trunk, broken up by noise (on any trunk-like shape).
float barkRelief(const glm::vec3& p, float depth) {
    const float a = std::atan2(p.z, p.x);
    return depth * (0.5f + 0.5f * std::sin(a * 13.0f + 2.5f * vnoise(p * glm::vec3(2.0f, 0.4f, 2.0f), 91)));
}

// A crown of leaf clumps: rounded clusters, smoothly joined, their surface broken into smaller clumps by noise.
// `freq` scales the noise to the size of the plant (1 for a tree's crown, more for a bush).
struct Clump { glm::vec3 c; glm::vec3 r; };
float crown(const std::vector<Clump>& clumps, const glm::vec3& p, float join, std::uint32_t seed, float rough, float freq = 1.0f) {
    float d = 1e9f;
    for (const Clump& k : clumps) d = smin(d, ellipsoid(p - k.c, k.r), join);
    if (d > 1.2f / freq) return d;                                            // far outside: no need for the detail
    const glm::vec3 q = p * freq;
    const float amp = rough / freq;
    d += amp * (0.42f * fbm3(q * 0.9f, 3, seed) + 0.16f * fbm3(q * 2.6f, 2, seed + 7));
    d -= amp * 0.09f * std::fabs(vnoise(q * 6.5f, seed + 13));                // little gaps between bunches of leaves
    return d;
}

// Branches from the trunk out to the clumps, each forking once.
struct Branch { glm::vec3 a, b; float ra, rb; };

void growBranches(std::vector<Branch>& out, Rng& rng, const glm::vec3& trunkTop, float trunkLow, const std::vector<Clump>& clumps, float thick, size_t stride = 2) {
    for (size_t i = 0; i < clumps.size(); ++i) {
        if (i % stride != 0) continue;                                        // every few clumps get a main branch
        const glm::vec3 from(trunkTop.x * 0.5f, rng.range(trunkLow, trunkTop.y), trunkTop.z * 0.5f);
        const glm::vec3 to = clumps[i].c * 0.85f + glm::vec3(0.0f, -0.25f, 0.0f);
        const glm::vec3 mid = glm::mix(from, to, 0.55f) + glm::vec3(rng.range(-0.3f, 0.3f), rng.range(0.1f, 0.5f), rng.range(-0.3f, 0.3f));
        out.push_back({ from, mid, thick, thick * 0.7f });
        out.push_back({ mid, to, thick * 0.7f, thick * 0.35f });
        if (i + 1 < clumps.size()) out.push_back({ mid, clumps[i + 1].c * 0.8f, thick * 0.5f, thick * 0.25f });
    }
}

AssetPtr makeOak(int variant, float vs, const std::string& name) {
    Rng rng(101u + std::uint32_t(variant) * 7u);
    const float trunkH = rng.range(2.3f, 2.9f);
    const glm::vec3 lean(rng.range(-0.2f, 0.2f), 0.0f, rng.range(-0.2f, 0.2f));
    const glm::vec3 top = glm::vec3(0.0f, trunkH, 0.0f) + lean;
    const glm::vec3 radii(rng.range(3.2f, 3.8f), rng.range(3.1f, 3.6f), rng.range(3.2f, 3.8f));
    const glm::vec3 centre = top + glm::vec3(rng.range(-0.3f, 0.3f), radii.y * 0.95f, rng.range(-0.3f, 0.3f));
    // The crown: many clumps over a dome (rounded on top, flatter and more open underneath), each a different size,
    // so the outline is broken and irregular rather than one cloud.
    std::vector<Clump> clumps;
    const int n = 24 + 2 * variant;
    for (int i = 0; i < n; ++i) {
        const float a = float(i) * 2.39996323f + rng.range(-0.35f, 0.35f);
        const float up = rng.range(-0.45f, 1.0f);
        const float ring = std::sqrt(std::max(0.0f, 1.0f - up * up));
        const glm::vec3 dir(std::cos(a) * ring, up, std::sin(a) * ring);
        const float rr = rng.range(0.75f, 1.3f) * (up < 0.0f ? 0.85f : 1.0f);
        const float out = rng.range(0.62f, 0.95f);
        clumps.push_back({ centre + dir * radii * out + glm::vec3(0.0f, up < 0.0f ? 0.35f : 0.0f, 0.0f), glm::vec3(rr, rr * 0.82f, rr) });
    }
    clumps.push_back({ centre + glm::vec3(0.0f, 0.2f, 0.0f), radii * 0.5f });  // the dense middle (no sky through it)
    // Limbs: the trunk forks into a few big limbs that climb out into the crown, then branches out to the clumps.
    std::vector<Branch> branches;
    const int limbs = 3 + variant % 2;
    for (int l = 0; l < limbs; ++l) {
        const float a = float(l) * 6.2832f / float(limbs) + rng.range(-0.4f, 0.4f) + float(variant);
        const glm::vec3 end = centre + glm::vec3(std::cos(a) * radii.x * 0.55f, rng.range(-0.6f, 0.4f), std::sin(a) * radii.z * 0.55f);
        const glm::vec3 kink = glm::mix(top, end, 0.45f) + glm::vec3(0.0f, -0.25f, 0.0f);
        branches.push_back({ top - glm::vec3(0.0f, 0.3f, 0.0f), kink, 0.23f, 0.17f });
        branches.push_back({ kink, end, 0.17f, 0.08f });
    }
    growBranches(branches, rng, top, trunkH * 0.85f, clumps, 0.11f, 3);

    const glm::vec3 lo(-radii.x - 2.2f, -0.7f, -radii.z - 2.2f), hi(radii.x + 2.2f, centre.y + radii.y + 1.6f, radii.z + 2.2f);
    Model m(name, lo, hi, vs);
    m.a.tags = { "prop", "nature", "tree" };
    // trunk, flaring into roots at the foot
    m.add([&](const glm::vec3& p) {
              float d = capsule(p, glm::vec3(0.0f, -0.5f, 0.0f), top, 0.38f, 0.27f);
              for (int r = 0; r < 5; ++r) {
                  const float a = float(r) * 1.2566f + float(variant);
                  d = smin(d, capsule(p, glm::vec3(0.0f, 0.4f, 0.0f), glm::vec3(std::cos(a) * 1.1f, -0.35f, std::sin(a) * 1.1f), 0.17f, 0.03f), 0.3f);
              }
              return d + barkRelief(p, 0.035f);
          }, glm::vec3(-1.5f, -0.7f, -1.5f), glm::vec3(1.5f, top.y + 0.6f, 1.5f), MAT_BARK);
    for (const Branch& b : branches)
        m.add([b](const glm::vec3& p) { return capsule(p, b.a, b.b, b.ra, b.rb) + barkRelief(p, 0.015f); },
              glm::min(b.a, b.b) - glm::vec3(0.4f), glm::max(b.a, b.b) + glm::vec3(0.4f), MAT_BARK, 0.12f);
    m.add([&](const glm::vec3& p) { return crown(clumps, p, 0.32f, 200u + std::uint32_t(variant), 1.0f); },
          centre - radii - glm::vec3(2.2f), centre + radii + glm::vec3(2.2f), MAT_LEAVES);
    return m.finish();
}

AssetPtr makePine(int variant, float vs, const std::string& name) {
    Rng rng(301u + std::uint32_t(variant) * 11u);
    const float H = rng.range(11.0f, 14.0f);
    const float base = rng.range(1.6f, 2.4f);                                   // where the lowest branches start
    const float R = rng.range(2.6f, 3.2f);
    const int tiers = 9 + variant;
    Model m(name, glm::vec3(-R - 0.9f, -0.6f, -R - 0.9f), glm::vec3(R + 0.9f, H + 0.8f, R + 0.9f), vs);
    m.a.tags = { "prop", "nature", "tree" };
    m.add([&](const glm::vec3& p) {
              float d = capsule(p, glm::vec3(0.0f, -0.5f, 0.0f), glm::vec3(0.0f, H, 0.0f), 0.3f, 0.04f);
              for (int r = 0; r < 4; ++r) {
                  const float a = float(r) * 1.5708f + 0.4f * float(variant);
                  d = smin(d, capsule(p, glm::vec3(0.0f, 0.3f, 0.0f), glm::vec3(std::cos(a) * 0.8f, -0.3f, std::sin(a) * 0.8f), 0.13f, 0.03f), 0.25f);
              }
              return d + barkRelief(p, 0.025f);
          }, glm::vec3(-1.2f, -0.7f, -1.2f), glm::vec3(1.2f, H + 0.2f, 1.2f), MAT_BARK);
    // the needles: tiers of drooping, ragged cones, wide at the bottom, narrowing to the tip
    std::vector<float> tierY(static_cast<size_t>(tiers)), tierR(static_cast<size_t>(tiers)), tierTwist(static_cast<size_t>(tiers));
    for (int i = 0; i < tiers; ++i) {
        const float t = float(i) / float(tiers - 1);
        tierY[size_t(i)] = base + (H - base - 0.6f) * std::pow(t, 0.9f);
        tierR[size_t(i)] = (R * std::pow(1.0f - t, 0.85f) + 0.35f) * rng.range(0.9f, 1.08f);
        tierTwist[size_t(i)] = rng.range(0.0f, 6.28f);
    }
    m.add([&](const glm::vec3& p) {
              const float r = glm::length(glm::vec2(p.x, p.z));
              const float ang = std::atan2(p.z, p.x);
              float d = 1e9f;
              for (int i = 0; i < tiers; ++i) {
                  const float y0 = tierY[size_t(i)], rad = tierR[size_t(i)];
                  if (p.y < y0 - 1.6f || p.y > y0 + 1.6f + rad * 0.3f) continue;
                  const float tufts = 1.0f + 0.13f * std::sin(ang * 9.0f + tierTwist[size_t(i)]) + 0.07f * std::sin(ang * 23.0f - tierTwist[size_t(i)]);
                  const float edge = rad * tufts;
                  const float h = 0.9f + rad * 0.35f;                         // how tall the tier is
                  // a cone from a point above to the edge below, its rim drooping
                  const float along = std::clamp(r / std::max(edge, 0.05f), 0.0f, 1.3f);
                  const float surfaceY = y0 + h * (1.0f - along) - 0.35f * along * along;
                  const float slope = std::sqrt(1.0f + (h / edge) * (h / edge));
                  const float cone = (p.y - surfaceY) / slope;
                  const float under = (y0 - 0.55f * along - 0.25f) - p.y;   // a thin skirt, hollow under it
                  d = std::min(d, std::max(std::max(cone, under), r - edge));
              }
              if (d > 0.8f) return d;
              return d + 0.12f * fbm3(p * 1.4f, 3, 401u + std::uint32_t(variant)) - 0.04f * std::fabs(vnoise(p * 6.0f, 409u));
          }, glm::vec3(-R - 0.9f, base - 1.8f, -R - 0.9f), glm::vec3(R + 0.9f, H + 0.8f, R + 0.9f), MAT_NEEDLES);
    return m.finish();
}

AssetPtr makeBirch(int variant, float vs, const std::string& name) {
    Rng rng(501u + std::uint32_t(variant) * 13u);
    const float H = rng.range(8.5f, 10.0f);
    const glm::vec3 bend(rng.range(-0.35f, 0.35f), 0.0f, rng.range(-0.35f, 0.35f));
    const glm::vec3 mid = glm::vec3(0.0f, H * 0.5f, 0.0f) + bend * 0.6f, top = glm::vec3(0.0f, H, 0.0f) + bend;
    const glm::vec3 centre = glm::vec3(0.0f, H * 0.7f, 0.0f) + bend * 0.8f;
    const glm::vec3 radii(rng.range(1.9f, 2.4f), H * 0.34f, rng.range(1.9f, 2.4f));
    // An open, narrow crown: many small clumps hung along the upper trunk, widest a third of the way up and tapering
    // to the top, so the outline is tall, ragged and light rather than one ball.
    std::vector<Clump> clumps;
    const int n = 30 + 2 * variant;
    for (int i = 0; i < n; ++i) {
        const float a = float(i) * 2.39996323f + rng.range(-0.3f, 0.3f);
        const float t = rng.range(0.0f, 1.0f);                                   // 0 = lowest leaves, 1 = the tip
        const float y = H * (0.42f + 0.56f * t);
        const float width = radii.x * (0.35f + 0.75f * std::sin(3.1416f * std::min(1.0f, 0.25f + t * 0.85f))) * rng.range(0.55f, 1.0f);
        const glm::vec3 along = glm::mix(glm::vec3(0.0f), bend, y / H);
        const float rr = rng.range(0.62f, 0.95f) * (1.0f - 0.3f * t);
        clumps.push_back({ along + glm::vec3(std::cos(a) * width, y - 0.25f * width, std::sin(a) * width), glm::vec3(rr, rr * 1.15f, rr) });
    }
    std::vector<Branch> branches;
    growBranches(branches, rng, top, H * 0.4f, clumps, 0.07f, 3);
    Model m(name, glm::vec3(-radii.x - 1.4f, -0.5f, -radii.z - 1.4f), glm::vec3(radii.x + 1.4f, top.y + 1.4f, radii.z + 1.4f), vs);
    m.a.tags = { "prop", "nature", "tree" };
    m.add([&](const glm::vec3& p) { return std::min(capsule(p, glm::vec3(0.0f, -0.4f, 0.0f), mid, 0.17f, 0.12f), capsule(p, mid, top, 0.12f, 0.03f)); },
          glm::vec3(-1.0f, -0.6f, -1.0f), top + glm::vec3(1.0f), MAT_PLASTER);       // the white bark
    // its black marks: short dashes across the trunk, and a darker, rougher foot
    m.paint([&](const glm::vec3& p) {
                const float band = std::fabs(std::fmod(p.y * 5.3f + 0.6f * vnoise(p * 3.0f, 511u) + 10.0f, 1.0f) - 0.5f);
                const float spot = vnoise(glm::vec3(std::atan2(p.z, p.x) * 2.0f, p.y * 5.3f, 0.0f), 513u);
                return (band < 0.09f && spot > 0.15f) ? -1.0f : 1.0f;
            }, glm::vec3(-1.0f, 0.4f, -1.0f), top + glm::vec3(1.0f), MAT_PAINT_BLACK);
    m.paint([](const glm::vec3& p) { return p.y - 0.45f - 0.2f * vnoise(p * 4.0f, 517u); }, glm::vec3(-1.0f, -0.6f, -1.0f), glm::vec3(1.0f, 0.8f, 1.0f), MAT_BARK);
    for (const Branch& b : branches)
        m.add([b](const glm::vec3& p) { return capsule(p, b.a, b.b, b.ra, b.rb); }, glm::min(b.a, b.b) - glm::vec3(0.3f), glm::max(b.a, b.b) + glm::vec3(0.3f), MAT_BARK, 0.04f);
    m.add([&](const glm::vec3& p) { return crown(clumps, p, 0.42f, 520u + std::uint32_t(variant), 0.8f, 1.4f); },
          centre - radii - glm::vec3(1.4f), centre + radii + glm::vec3(1.4f), MAT_LEAVES);
    return m.finish();
}

AssetPtr makeBush(int variant, float vs, const std::string& name) {
    Rng rng(701u + std::uint32_t(variant) * 17u);
    std::vector<Clump> clumps;
    const int n = 9 + variant * 2;
    for (int i = 0; i < n; ++i) {
        const float a = float(i) * 2.39996323f + rng.range(0.0f, 0.5f);
        const float d = rng.range(0.2f, 0.85f);
        const float rr = rng.range(0.32f, 0.6f);
        clumps.push_back({ glm::vec3(std::cos(a) * d, rr * 0.75f + rng.range(0.0f, 0.3f), std::sin(a) * d), glm::vec3(rr, rr * 0.85f, rr) });
    }
    Model m(name, glm::vec3(-1.9f, -0.3f, -1.9f), glm::vec3(1.9f, 2.2f, 1.9f), vs);
    m.a.tags = { "prop", "nature", "bush" };
    m.add([&](const glm::vec3& p) { return std::max(crown(clumps, p, 0.18f, 720u + std::uint32_t(variant), 1.3f, 2.4f), -0.15f - p.y); },
          glm::vec3(-1.9f, -0.3f, -1.9f), glm::vec3(1.9f, 2.2f, 1.9f), MAT_LEAVES);
    return m.finish();
}

} // namespace

const char* treeKindName(TreeKind k) {
    switch (k) {
    case TreeKind::Oak: return "oak";
    case TreeKind::Pine: return "pine";
    case TreeKind::Birch: return "birch";
    case TreeKind::Bush: return "bush";
    case TreeKind::Count: break;
    }
    return "tree";
}

float treeTrunkRadius(TreeKind k) {
    switch (k) {
    case TreeKind::Oak: return 0.34f;
    case TreeKind::Pine: return 0.28f;
    case TreeKind::Birch: return 0.16f;
    default: return 0.0f;
    }
}
float treeTrunkHeight(TreeKind k) { return k == TreeKind::Pine ? 8.0f : k == TreeKind::Bush ? 0.0f : 3.0f; }

AssetPtr makeTree(TreeKind kind, int variant, int lod, const std::string& name) {
    variant = std::clamp(variant, 0, kTreeVariants - 1);
    const float scale = lod == 0 ? 1.0f : 2.8f;                                   // the distant model: coarser voxels
    switch (kind) {
    case TreeKind::Oak: return makeOak(variant, 0.095f * scale, name);
    case TreeKind::Pine: return makePine(variant, 0.13f * scale, name);
    case TreeKind::Birch: return makeBirch(variant, 0.075f * scale, name);
    case TreeKind::Bush: return makeBush(variant, 0.06f * scale, name);
    case TreeKind::Count: break;
    }
    return nullptr;
}

TreeModels::~TreeModels() {
    stop = true;
    if (job.joinable()) job.join();
}

void TreeModels::start() {
    if (started) return;
    started = true;
    job = std::thread([this] {
        // The far models first (a forest on the horizon appears quickly), then the near ones.
        for (int lod = kTreeLods - 1; lod >= 0 && !stop; --lod)
            for (int k = 0; k < kTreeKinds && !stop; ++k)
                for (int v = 0; v < kTreeVariants && !stop; ++v) {
                    const std::string name = std::string("tree ") + treeKindName(TreeKind(k)) + " " + std::to_string(v + 1) + (lod ? " far" : "");
                    models[size_t((k * kTreeVariants + v) * kTreeLods + lod)] = makeTree(TreeKind(k), v, lod, name);
                }
        done = true;
    });
}

void TreeModels::finish() {
    start();
    if (job.joinable()) job.join();
}

AssetPtr TreeModels::get(TreeKind kind, int variant, int lod) const {
    if (!done) return nullptr;
    return models[size_t((int(kind) * kTreeVariants + std::clamp(variant, 0, kTreeVariants - 1)) * kTreeLods + std::clamp(lod, 0, kTreeLods - 1))];
}

namespace {
const char* const kTreeProps[] = { "tree oak", "tree pine", "tree birch", "bush" };
}

void registerTreeProps(AssetLibrary& lib) {
    lib.addGenerated("tree oak", { "prop", "nature", "tree" }, [] { return makeTree(TreeKind::Oak, 0, 0, "tree oak"); });
    lib.addGenerated("tree pine", { "prop", "nature", "tree" }, [] { return makeTree(TreeKind::Pine, 0, 0, "tree pine"); });
    lib.addGenerated("tree birch", { "prop", "nature", "tree" }, [] { return makeTree(TreeKind::Birch, 0, 0, "tree birch"); });
    lib.addGenerated("bush", { "prop", "nature", "bush" }, [] { return makeTree(TreeKind::Bush, 0, 0, "bush"); });
}

bool isTreeProp(const std::string& name) {
    for (const char* n : kTreeProps) if (name == n) return true;
    return false;
}

} // namespace px
