#include "scene/Thumbnail.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace px {

int Thumbnail::opaquePixels() const {
    int n = 0;
    for (size_t i = 3; i < rgba.size(); i += 4) if (rgba[i] > 127) ++n;
    return n;
}

glm::vec3 thumbnailColour(MaterialId id) {
    const MaterialInfo& m = materialInfo(id == MAT_NATURAL ? MaterialId(MAT_STONE) : id);
    return { m.flat[0], m.flat[1], m.flat[2] };
}

Thumbnail renderThumbnail(const Asset& a, int size) {
    return renderThumbnail(std::vector<ThumbPart>{ ThumbPart{ &a, glm::mat4(1.0f), glm::vec3(1.0f) } }, size);
}

Thumbnail renderThumbnail(const std::vector<ThumbPart>& parts, int size, bool portrait) {
    Thumbnail out;
    out.size = size;
    out.rgba.assign(size_t(size) * size * 4, 0);
    if (size < 8) return out;

    // Everything in world space first: the bounds frame the picture.
    glm::vec3 mn(std::numeric_limits<float>::max()), mx(-std::numeric_limits<float>::max());
    size_t triangles = 0;
    for (const ThumbPart& p : parts) {
        if (!p.asset || p.asset->mesh.empty()) continue;
        for (const Vertex& v : p.asset->mesh) {
            const glm::vec3 w = glm::vec3(p.model * glm::vec4(v.position, 1.0f));
            mn = glm::min(mn, w); mx = glm::max(mx, w);
        }
        triangles += p.asset->mesh.size() / 3;
    }
    if (!triangles) return out;

    constexpr int kSuper = 2;
    const int S = size * kSuper;
    std::vector<float> depth(size_t(S) * S, std::numeric_limits<float>::max());
    std::vector<glm::vec3> colour(size_t(S) * S, glm::vec3(0.0f));

    // A three-quarter view from above: the camera looks along -dir.
    const glm::vec3 dir = portrait ? glm::normalize(glm::vec3(0.55f, 0.22f, 1.0f)) : glm::normalize(glm::vec3(1.0f, 0.78f, 1.15f));
    const glm::vec3 fwd = -dir;
    const glm::vec3 right = glm::normalize(glm::cross(fwd, glm::vec3(0, 1, 0)));
    const glm::vec3 up = glm::cross(right, fwd);
    glm::vec3 centre = (mn + mx) * 0.5f;
    float radius = std::max(0.25f, glm::length(mx - mn) * 0.5f);
    if (portrait) {                                   // from the waist up: the face is what tells people apart
        const float h = mx.y - mn.y;
        centre.y = mn.y + h * 0.74f;
        radius = std::max(0.2f, h * 0.30f);
    }
    const glm::vec3 light = glm::normalize(glm::vec3(-0.45f, 0.85f, 0.35f));

    struct V { glm::vec2 p; float z; glm::vec3 c; };
    for (const ThumbPart& part : parts) {
        if (!part.asset || part.asset->mesh.empty()) continue;
        const glm::mat3 nm = glm::mat3(part.model);
        auto toV = [&](const Vertex& v, int corner) {
            const glm::vec3 d = glm::vec3(part.model * glm::vec4(v.position, 1.0f)) - centre;
            V r;
            r.p = glm::vec2(float(S) * 0.5f + glm::dot(d, right) / radius * float(S) * 0.45f,
                            float(S) * 0.5f - glm::dot(d, up) / radius * float(S) * 0.45f);
            r.z = glm::dot(d, fwd);
            const MaterialId m = MaterialId(v.layers[corner] + 1);
            const glm::vec3 n = glm::normalize(nm * v.normal);
            const float lambert = std::max(glm::dot(n, light), 0.0f);
            const float shade = (0.34f + 0.66f * lambert) * (0.55f + 0.45f * v.ao);
            r.c = thumbnailColour(m) * part.tint * shade;
            return r;
        };
        const std::vector<Vertex>& mesh = part.asset->mesh;
        for (size_t i = 0; i + 2 < mesh.size(); i += 3) {
            // Each corner's colour comes from its own layer slot (vertex k carries weight 255 at slot k).
            V t[3];
            for (int k = 0; k < 3; ++k) {
                const Vertex& v = mesh[i + size_t(k)];
                int corner = 0;
                for (int c = 0; c < 3; ++c) if (v.bary[c] == 255) corner = c;
                t[k] = toV(v, corner);
            }
            const float area = (t[1].p.x - t[0].p.x) * (t[2].p.y - t[0].p.y) - (t[1].p.y - t[0].p.y) * (t[2].p.x - t[0].p.x);
            if (std::fabs(area) < 1e-6f) continue;
            const int x0 = std::max(0, int(std::floor(std::min({ t[0].p.x, t[1].p.x, t[2].p.x }))));
            const int x1 = std::min(S - 1, int(std::ceil(std::max({ t[0].p.x, t[1].p.x, t[2].p.x }))));
            const int y0 = std::max(0, int(std::floor(std::min({ t[0].p.y, t[1].p.y, t[2].p.y }))));
            const int y1 = std::min(S - 1, int(std::ceil(std::max({ t[0].p.y, t[1].p.y, t[2].p.y }))));
            for (int y = y0; y <= y1; ++y)
                for (int x = x0; x <= x1; ++x) {
                    const glm::vec2 p(float(x) + 0.5f, float(y) + 0.5f);
                    const float w0 = ((t[1].p.x - p.x) * (t[2].p.y - p.y) - (t[1].p.y - p.y) * (t[2].p.x - p.x)) / area;
                    const float w1 = ((t[2].p.x - p.x) * (t[0].p.y - p.y) - (t[2].p.y - p.y) * (t[0].p.x - p.x)) / area;
                    const float w2 = 1.0f - w0 - w1;
                    if (w0 < 0.0f || w1 < 0.0f || w2 < 0.0f) continue;
                    const float z = w0 * t[0].z + w1 * t[1].z + w2 * t[2].z;
                    float& zb = depth[size_t(y) * S + x];
                    if (z >= zb) continue;
                    zb = z;
                    colour[size_t(y) * S + x] = t[0].c * w0 + t[1].c * w1 + t[2].c * w2;
                }
        }
    }

    // Average each kSuper x kSuper block: colour over the covered samples, alpha = coverage.
    for (int y = 0; y < size; ++y)
        for (int x = 0; x < size; ++x) {
            glm::vec3 sum(0.0f); int covered = 0;
            for (int j = 0; j < kSuper; ++j)
                for (int i = 0; i < kSuper; ++i) {
                    const size_t k = size_t(y * kSuper + j) * S + size_t(x * kSuper + i);
                    if (depth[k] < std::numeric_limits<float>::max()) { sum += colour[k]; ++covered; }
                }
            std::uint8_t* px = &out.rgba[(size_t(y) * size + x) * 4];
            if (!covered) continue;
            const glm::vec3 c = glm::clamp(sum / float(covered), 0.0f, 1.0f);
            px[0] = std::uint8_t(std::lround(c.r * 255.0f));
            px[1] = std::uint8_t(std::lround(c.g * 255.0f));
            px[2] = std::uint8_t(std::lround(c.b * 255.0f));
            px[3] = std::uint8_t(std::lround(255.0f * float(covered) / float(kSuper * kSuper)));
        }
    return out;
}

} // namespace px
