#pragma once
// The Blueprint Tool's model (v0.17): a floor plan you draw, and the building-kit pieces it turns into.
//
// A blueprint is a grid of 2 x 2 m cells (the same cells as the building kits, scene/BuildKit.h), up to 16 x 16, with
// up to four storeys. On each storey every cell is either outside (0) or part of a ROOM (1, 2, ...). That is all you have
// to draw: the walls, windows, doors, floors, stairs and roof follow from it.
//
//   * an edge between a room and outside        -> an outside wall; Auto spaces windows along it
//   * an edge between two different rooms        -> an inside wall, with one doorway per pair of rooms (Auto)
//   * an edge inside one room                    -> nothing
//   * every edge can be set by hand: Wall, Window, Door, or Open (no wall at all)
//   * one front door on the ground floor, on the front (+z, the bottom of the plan) when you did not put one in yourself
//   * stairs between storeys (two cells, they climb towards `dir`), found automatically when a storey has none;
//     the floor above them is left open
//   * a floor tile under every room cell; a roof over every cell with nothing above it: pitched (ridges and lean-tos),
//     flat, or none
//
// Everything here is pure (no window, no GPU, no scene), so the unit tests cover every rule. The editor draws the plan
// (editor/BlueprintTools.cpp) and places the generated pieces as objects in a Building group.
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "core/Json.h"
#include "scene/BuildKit.h"

namespace px {

inline constexpr int kBpMaxSize = 16;            // cells per side
inline constexpr int kBpMaxLevels = 4;           // storeys
inline constexpr int kBpMaxRooms = 32;
inline constexpr int kBpFileVersion = 1;

enum class BpEdge : std::uint8_t { Auto, Wall, Window, Door, Open };
enum class BpRoof : std::uint8_t { Pitched, Flat, None };
enum class BpWindows : std::uint8_t { None, Some, Many };
const char* bpEdgeName(BpEdge e);                 // "auto", "wall", ... (in files)
const char* bpEdgeLabel(BpEdge e);                // "Auto", "Wall", ... (on screen)
const char* bpRoofName(BpRoof r);
const char* bpRoofLabel(BpRoof r);
const char* bpWindowsName(BpWindows w);
const char* bpWindowsLabel(BpWindows w);

// Directions on the plan: 0 = +x, 1 = +z (towards the front), 2 = -x, 3 = -z.
glm::ivec2 bpDir(int dir);
float bpYawToward(int dir);                       // the yaw that turns a piece's own +x towards `dir`

// An edge of the plan: o = 0 runs along x on the line z (between cells (x, z-1) and (x, z)),
// o = 1 runs along z on the line x (between cells (x-1, z) and (x, z)).
std::uint32_t bpEdgeKey(int o, int x, int z);
void bpEdgeFromKey(std::uint32_t key, int& o, int& x, int& z);

struct BpStairs {
    int x = 0, z = 0;         // the bottom cell
    int dir = 0;              // the way they climb; the second cell is (x, z) + bpDir(dir)
    bool operator==(const BpStairs&) const = default;
};

struct BpLevel {
    std::vector<std::uint8_t> cells;                  // room id per cell, x + z * width; 0 = outside
    std::map<std::uint32_t, BpEdge> edges;            // edges set by hand (Auto is never stored)
    std::vector<BpStairs> stairs;                     // stairs drawn by hand, from this storey to the next
    bool operator==(const BpLevel&) const = default;
};

struct Blueprint {
    std::string name = "House";
    std::string style = "Brick house";                // the building kit the pieces come from
    int width = 5, depth = 4;                         // cells
    std::vector<BpLevel> levels;                      // storeys, ground floor first; never empty
    std::vector<std::string> rooms;                   // room id n is rooms[n - 1]
    BpRoof roof = BpRoof::Pitched;
    BpWindows windows = BpWindows::Some;
    bool frontDoor = true;                            // a door on the ground floor when none was drawn
    bool roomDoors = true;                            // a doorway between every two rooms that touch
    bool autoStairs = true;                           // stairs where a storey above needs them and none were drawn
    bool cornerPosts = false;                         // a pillar on every outside corner

    Blueprint();                                      // 5 x 4 cells, one empty storey
    bool operator==(const Blueprint&) const = default;

    int storeys() const { return int(levels.size()); }
    bool inGrid(int x, int z) const { return x >= 0 && z >= 0 && x < width && z < depth; }
    int  room(int level, int x, int z) const;         // 0 outside the grid or the storey
    bool inside(int level, int x, int z) const { return room(level, x, z) != 0; }
    void setRoom(int level, int x, int z, int id);
    void fillRect(int level, int x0, int z0, int x1, int z1, int id);    // inclusive corners, any order
    int  cellCount(int level) const;
    int  cellCount(int level, int roomId) const;
    bool empty() const;                               // no room cells at all

    BpEdge edge(int level, int o, int x, int z) const;
    void   setEdge(int level, int o, int x, int z, BpEdge e);           // Auto removes the hand-made setting

    // Changing the size keeps what fits; storeys added copy the outline of the one below (cells, not edges or stairs).
    void resize(int w, int d);
    void setStoreys(int n);
    int  addRoom(const std::string& name);            // the new id, or 0 when there are already kBpMaxRooms
    void removeRoom(int id);                          // its cells become outside; higher ids move down one
    std::string roomName(int id) const;               // "Room 3" when it has no name
    std::string suggestRoomName() const;              // the next of Living room, Kitchen, Bedroom ... not used yet
    int  usedRoomCount() const;                       // rooms that have at least one cell
    void tidy();                                      // drops hand-made edges and stairs that fall outside the grid
};

// One piece to place: a kit role at a spot in BUILDING SPACE (metres; the footprint's corner at the origin, the ground
// floor's plane at y = 0). The editor adds the world position of the corner and the ground height.
struct BpPiece {
    KitRole   role = KitRole::None;
    glm::vec3 position{ 0.0f };
    float     yaw = 0.0f;
    int       level = 0;
};

// What the generator decided for one edge of the plan (for drawing the plan; plan space, not turned).
struct BpEdgeOut {
    int level = 0, o = 0, x = 0, z = 0;
    KitRole role = KitRole::None;                     // Wall, Window or Doorway; None = open
    bool exterior = false;                            // between a room and outside
    bool manual = false;                              // set by hand
};

struct BpStairsOut {
    int level = 0;
    BpStairs s;
    bool automatic = false;
};

struct BpResult {
    std::vector<BpPiece> pieces;
    std::vector<std::string> warnings;                // things that probably are not what you meant
    std::vector<BpEdgeOut> edges;                     // every edge with a wall, window or doorway, plus Open ones
    std::vector<BpStairsOut> stairs;                  // the stairs used, drawn and automatic
    glm::ivec2 footprint{ 0 };                        // cells, after turning
    glm::vec3 size{ 0.0f };                           // metres: width, height (to the top of the roof), depth; after turning
    int count(KitRole r) const;
};

// The building for a blueprint, turned `turns` quarter turns (the same way objects turn) about its corner.
BpResult generateBlueprint(const Blueprint& bp, int turns = 0);
glm::ivec2 blueprintFootprint(const Blueprint& bp, int turns);

// .pxblueprint files: readable JSON. Loading checks everything and brings it into range.
Json blueprintToJson(const Blueprint& bp);
bool blueprintFromJson(const Json& j, Blueprint& out, std::string* error = nullptr);
bool saveBlueprintFile(const Blueprint& bp, const std::string& path, std::string* error = nullptr);    // atomic
bool loadBlueprintFile(const std::string& path, Blueprint& out, std::string* error = nullptr);
std::string blueprintFileName(const std::string& name);       // "My House!" -> "my_house"

// Ready-made plans to start from.
const std::vector<Blueprint>& blueprintPresets();

} // namespace px
