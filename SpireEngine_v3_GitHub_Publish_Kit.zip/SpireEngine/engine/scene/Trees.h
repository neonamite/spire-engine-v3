#pragma once
// Trees and bushes (1.4): four kinds (oak, pine, birch, bush), a few variants each, every one in two levels of detail
// (a fine model for up close, a coarse one for the distance). The world plants them on grass by itself (see
// world/VoxelChunk: TreeInstance); they are also on the Shelf as ordinary props you can place by hand.
//
// The models are built from signed-distance shapes (trunk, roots, branches, clumps of leaves, needle tiers) with noise,
// on a background thread when the editor starts, so the first trees appear a few seconds in without a hitch.
#include <array>
#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include "scene/Asset.h"

namespace px {

enum class TreeKind : std::uint8_t { Oak, Pine, Birch, Bush, Count };   // append only: stored in nothing yet, but keep it stable
inline constexpr int kTreeKinds = int(TreeKind::Count);
inline constexpr int kTreeVariants = 3;        // variants per kind
inline constexpr int kTreeLods = 2;            // 0 = near, 1 = far

const char* treeKindName(TreeKind k);          // "oak", "pine", "birch", "bush"
// The model of one variant at one level of detail (pure: any thread, no library). `name` names the asset.
AssetPtr makeTree(TreeKind kind, int variant, int lod, const std::string& name);
// How thick the trunk is at its base (metres, before the tree's own scale): what you bump into. 0 for bushes.
float treeTrunkRadius(TreeKind kind);
float treeTrunkHeight(TreeKind kind);

// All the models, built in the background.
class TreeModels {
public:
    ~TreeModels();
    void start();                              // begins building (once)
    bool ready() const { return done.load(); }
    void finish();                             // waits until built (tests, screenshots)
    AssetPtr get(TreeKind kind, int variant, int lod) const;
private:
    std::array<AssetPtr, size_t(kTreeKinds * kTreeVariants * kTreeLods)> models{};
    std::thread job;
    std::atomic<bool> done{ false }, stop{ false };
    bool started = false;
};

// The trees and bush as placeable props ("tree oak", "tree pine", "tree birch", "bush"), built when first placed.
void registerTreeProps(AssetLibrary& lib);
bool isTreeProp(const std::string& name);

} // namespace px
