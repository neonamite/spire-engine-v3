#pragma once
// The Scene is the list of objects placed in a world: each one is a copy of an Asset with its
// own position, rotation and size, optionally parented to another object, optionally moving.
// It is saved inside the world file, has its own undo history, and answers the questions the
// rest of the engine asks about objects: what is under the mouse, how far is the nearest
// solid surface, what should be drawn where.
//
// Rules worth knowing:
//   * Scale is uniform (one number). That keeps the density field a distance field, so
//     collision and picking stay exact after resizing.
//   * Rotation is stored as degrees applied as yaw (Y), then pitch (X), then roll (Z).
//   * Editing goes through add / remove / mutate / setParent / ... so the revision counter
//     (used by saving and autosave) always notices.
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include "physics/Solid.h"
#include "scene/Asset.h"

namespace px {

using ObjectId = std::uint32_t;     // 0 = none

struct MotionSettings {
    enum class Kind : std::uint8_t { None, Spin, Bob, Sway, Slide };      // append only: stored in saves
    Kind      kind = Kind::None;
    glm::vec3 axis{ 0.0f, 1.0f, 0.0f };   // spin / sway axis, or the direction of a bob / slide (object space)
    float     speed  = 1.0f;              // spin: degrees per second; the rest: cycles per second
    float     amount = 1.0f;              // bob / slide: metres; sway: degrees
    float     phase  = 0.0f;              // 0..1 head start in the cycle
    bool operator==(const MotionSettings&) const = default;
};
const char* motionName(MotionSettings::Kind k);

struct SceneObject {
    ObjectId    id = 0;
    ObjectId    parent = 0;
    std::string name;
    std::string asset;                    // empty = a group (just a transform that holds children)
    glm::vec3   position{ 0.0f };         // relative to the parent, metres
    glm::vec3   rotation{ 0.0f };         // degrees: yaw (Y), pitch (X), roll (Z)
    float       scale = 1.0f;
    bool        visible = true;
    bool        locked  = false;          // can't be picked or moved with the mouse
    bool        solid   = true;           // characters collide with it
    MotionSettings motion;
    std::string blueprint;                // a Building made by the Blueprint Tool keeps its plan here (JSON), so it can be rebuilt
    std::string character;                // a person standing in the world: the character's name (the asset is its invisible stand-in)
    std::string npc;                      // what that person does (character/Npc.h settings as JSON; "" = they just stand)
    std::string rules;                    // "When this happens -> do that" (rules/Rules.h, JSON; "" = none)
    bool isGroup() const { return asset.empty(); }
    bool operator==(const SceneObject&) const = default;
};

// Rotation helpers, shared with the gizmo.
glm::quat quatFromEuler(const glm::vec3& degrees);
glm::vec3 eulerFromMatrix(const glm::mat3& pureRotation);          // degrees, same convention
glm::mat4 composeTransform(const glm::vec3& position, const glm::vec3& rotationDeg, float scale);
struct Decomposed { glm::vec3 position; glm::vec3 rotation; float scale; };
Decomposed decomposeTransform(const glm::mat4& m);

// One object as it looks this frame (animation applied, parents resolved).
struct Evaluated {
    ObjectId  id = 0;
    int       index = 0;                  // into Scene::objects()
    glm::mat4 world{ 1.0f }, inverse{ 1.0f };
    float     scale = 1.0f;               // accumulated
    bool      visible = true;             // this object and every parent
    bool      locked = false;             // this object (not its parents) can't be picked
    bool      solid = false;              // visible && solid && has an asset
    AssetPtr  asset;                      // null for groups
    glm::vec3 centre{ 0.0f };             // world-space bounding sphere
    float     radius = 0.0f;
};

class Scene : public SolidProvider {
public:
    struct Hit { ObjectId id = 0; float distance = 0.0f; glm::vec3 point{ 0.0f }; glm::vec3 normal{ 0, 1, 0 }; };

    // ---- the objects
    const std::vector<SceneObject>& objects() const { return objs; }
    size_t size() const { return objs.size(); }
    bool empty() const { return objs.empty(); }
    const SceneObject* find(ObjectId id) const;
    SceneObject* mutate(ObjectId id);                    // for editing: counts as a change
    ObjectId add(SceneObject o);                         // gives it an id and a unique name; returns the id
    void remove(ObjectId id);                            // and everything inside it
    void clear();
    std::string uniqueName(const std::string& wanted) const;       // "Rock" -> "Rock 2" when taken

    // ---- hierarchy
    std::vector<ObjectId> children(ObjectId parent) const;         // in order; parent 0 = the top level
    std::vector<ObjectId> descendants(ObjectId id) const;          // not including id
    bool isAncestor(ObjectId ancestor, ObjectId of) const;         // true when `of` sits somewhere inside `ancestor`
    // Moves id under newParent (0 = top level). Refused (false) if that would put a group inside itself.
    // keepWorld keeps it where it is on screen by adjusting its local transform.
    bool setParent(ObjectId id, ObjectId newParent, bool keepWorld = true);
    ObjectId group(const std::vector<ObjectId>& ids, const std::string& name = "Group");      // 0 if nothing to group
    bool ungroup(ObjectId groupId);                                // children move up one level; the group goes
    ObjectId duplicate(ObjectId id, const glm::vec3& offset = glm::vec3(1.0f, 0.0f, 1.0f));   // with all its children
    void moveInOrder(ObjectId id, int newIndexAmongSiblings);

    // ---- transforms
    // Where an object sits ignoring animation (what the gizmo edits), and setting it from a world transform.
    glm::mat4 restWorld(ObjectId id) const;
    bool setRestWorld(ObjectId id, const glm::mat4& world);

    // ---- per frame
    // Resolves every object's transform for this moment. time only matters when animate is true.
    void evaluate(AssetLibrary& assets, double time, bool animate);
    const std::vector<Evaluated>& evaluated() const { return ev; }
    const Evaluated* evaluatedFor(ObjectId id) const;
    // While playing, people walk about: where one is now (world position and yaw) overrides where they were put. Not
    // saved and not undoable; cleared when play stops.
    void setLive(ObjectId id, const glm::vec3& worldPos, float yawDegrees);
    void setLiveMatrix(ObjectId id, const glm::mat4& world);      // a door swinging open: its whole transform
    void setLiveHidden(ObjectId id, bool hidden);                 // a coin once collected: not drawn, not solid
    void clearLive(ObjectId id) { live.erase(id); }
    void clearLiveTransform(ObjectId id) { if (auto it = live.find(id); it != live.end()) it->second.kind = 0; }   // back where it was (still hidden if hidden)
    void clearLive() { live.clear(); }
    bool hasLive() const { return !live.empty(); }

    // ---- questions (all use the last evaluate())
    bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist, Hit& hit, bool includeLocked = false, bool skipCharacters = false) const;
    // Distance-like value to the nearest solid object (negative inside); DENSITY_CLAMP when nothing is near.
    float density(const glm::vec3& p) const override;
    glm::vec3 gradient(const glm::vec3& p) const override;         // unit vector toward air around the nearest object
    // World-space box around an object and everything inside it (false: it has no geometry).
    bool worldBounds(ObjectId id, glm::vec3& mn, glm::vec3& mx) const;

    // ---- the game's own rules (v0.22): goal, time, lives... (rules/GameRules.h, JSON; "" = just play). Saved and undoable
    // with the objects.
    const std::string& gameRules() const { return game; }
    void setGameRules(const std::string& text) { if (text != game) { game = text; ++rev; } }

    // ---- saving
    std::string toText() const;
    bool fromText(const std::string& text);              // false (and no change) if it isn't a scene; clears history

    // Bumps on every change (also undo / redo / load). Used to know when the world file is out of date.
    std::uint64_t revision() const { return rev; }

    // ---- history: each commit() is one undo step if anything changed since the last one
    bool commit(const std::string& label);               // true if a step was recorded
    bool undo();
    bool redo();
    bool canUndo() const { return cursor > 0; }
    bool canRedo() const { return cursor + 1 < history.size(); }
    std::string undoLabel() const { return canUndo() ? history[cursor].label : std::string(); }
    std::string redoLabel() const { return canRedo() ? history[cursor + 1].label : std::string(); }
    void clearRedo();                                    // something else changed the world: redo no longer applies
    void resetHistory();                                 // the current state becomes the starting point
    bool dirtySinceCommit() const;                       // edited but not committed yet (mid-drag)
    void discardUncommitted();                           // back to the last committed state (Esc during a drag)

private:
    struct State { std::vector<SceneObject> objs; ObjectId nextId = 1; std::string label; std::string game; };
    int indexOf(ObjectId id) const;
    void rebuildIndex();
    void restore(const State& s);
    void removeOne(ObjectId id);
    State snapshot(const std::string& label) const;

    std::vector<SceneObject> objs;
    std::string game;
    std::unordered_map<ObjectId, int> index;
    ObjectId nextId = 1;
    std::uint64_t rev = 1;

    struct Live { int kind = 0; glm::vec3 pos{ 0.0f }; float yaw = 0.0f; glm::mat4 m{ 1.0f }; bool hidden = false; };   // kind 0: none, 1: pos+yaw, 2: matrix
    std::unordered_map<ObjectId, Live> live;
    std::vector<Evaluated> ev;
    std::unordered_map<ObjectId, int> evIndex;

    std::vector<State> history{ State{} };
    size_t cursor = 0;
    static constexpr size_t kMaxHistory = 200;
};

} // namespace px
