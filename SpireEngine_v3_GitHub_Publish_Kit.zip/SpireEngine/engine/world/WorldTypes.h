#pragma once
// Shared world-space constants and small helpers.
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <functional>
#include <glm/glm.hpp>

namespace px {

// One chunk = 32x32x32 cells. Density samples sit on cell corners, so a chunk
// needs 33 samples per axis. We also keep a PAD-wide border of samples copied
// from the neighbouring space so normals and AO never read outside the chunk
// (that is what removes the seams the old version had at chunk borders).
constexpr int CHUNK_SIZE   = 32;
constexpr int PAD          = 3;
constexpr int SAMPLES      = CHUNK_SIZE + 1 + PAD * 2;   // 39
constexpr int SAMPLE_COUNT = SAMPLES * SAMPLES * SAMPLES;

// Density convention used everywhere in the engine:
//   negative = solid matter, positive = air, 0 = surface.
constexpr float DENSITY_CLAMP = 8.0f;

struct IVec3Hash {
    std::size_t operator()(const glm::ivec3& v) const noexcept {
        std::uint64_t h = static_cast<std::uint32_t>(v.x) * 0x9E3779B97F4A7C15ull;
        h ^= static_cast<std::uint32_t>(v.y) * 0xC2B2AE3D27D4EB4Full + (h << 6) + (h >> 2);
        h ^= static_cast<std::uint32_t>(v.z) * 0x165667B19E3779F9ull + (h << 6) + (h >> 2);
        return static_cast<std::size_t>(h);
    }
};

inline int floorDiv(int a, int b) { return (a >= 0) ? a / b : -((-a + b - 1) / b); }

inline glm::ivec3 worldToChunk(const glm::vec3& p) {
    return glm::ivec3(static_cast<int>(std::floor(p.x / CHUNK_SIZE)),
                      static_cast<int>(std::floor(p.y / CHUNK_SIZE)),
                      static_cast<int>(std::floor(p.z / CHUNK_SIZE)));
}

// Cheap deterministic hash -> [0,1). Used for procedural scatter so every
// chunk independently agrees on where props go (no cross-chunk coordination).
inline float hash01(int x, int z, std::uint32_t seed) {
    std::uint32_t h = static_cast<std::uint32_t>(x) * 374761393u + static_cast<std::uint32_t>(z) * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return static_cast<float>(h & 0xFFFFFFu) / static_cast<float>(0x1000000u);
}

} // namespace px
