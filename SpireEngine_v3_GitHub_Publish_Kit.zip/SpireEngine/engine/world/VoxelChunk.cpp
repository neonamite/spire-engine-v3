#include "VoxelChunk.h"
#include "TerrainGenerator.h"
#include "TerrainProvider.h"
#include <stdexcept>
#include "MarchingCubesTables.h"
#include <algorithm>
#include <cmath>

namespace px {

VoxelChunk::VoxelChunk(glm::ivec3 c) : coord(c), density(SAMPLE_COUNT, 1.0f), material(SAMPLE_COUNT, MAT_NATURAL) {}

namespace {
// Sample range of this chunk touched by a sphere (local coords, clamped to the padded grid).
struct Range { int x0, x1, y0, y1, z0, z1; };
Range sphereRange(const glm::vec3& local, float r) {
    const int r0 = int(std::ceil(r)) + 1;
    return { std::max(-PAD, int(std::floor(local.x)) - r0), std::min(CHUNK_SIZE + PAD, int(std::ceil(local.x)) + r0),
             std::max(-PAD, int(std::floor(local.y)) - r0), std::min(CHUNK_SIZE + PAD, int(std::ceil(local.y)) + r0),
             std::max(-PAD, int(std::floor(local.z)) - r0), std::min(CHUNK_SIZE + PAD, int(std::ceil(local.z)) + r0) };
}
} // namespace

float VoxelChunk::sampleClamped(int lx, int ly, int lz) const {
    lx = std::clamp(lx, -PAD, CHUNK_SIZE + PAD);
    ly = std::clamp(ly, -PAD, CHUNK_SIZE + PAD);
    lz = std::clamp(lz, -PAD, CHUNK_SIZE + PAD);
    return density[index(lx, ly, lz)];
}

void VoxelChunk::generate(const TerrainGenerator& gen) {
    radialTerrain = false;
    const glm::ivec3 o = origin();
    const auto& s = gen.settings;
    sandLevel = sandLevelFor(s);
    snowLevel = snowLevelFor(s);
    for (int z = -PAD; z <= CHUNK_SIZE + PAD; ++z)
        for (int x = -PAD; x <= CHUNK_SIZE + PAD; ++x) {
            // Layers by depth below the column's surface: Natural topsoil, then dirt, then stone.
            const float h = gen.surfaceHeight(float(o.x + x), float(o.z + z));
            for (int y = -PAD; y <= CHUNK_SIZE + PAD; ++y) {
                const float wy = float(o.y + y);
                const int i = index(x, y, z);
                density[i] = gen.density(float(o.x + x), wy, float(o.z + z));
                const float depth = h - wy;
                material[i] = depth < 4.0f ? MAT_NATURAL : depth < 10.0f ? MAT_DIRT : MAT_STONE;
            }
        }
}

void VoxelChunk::generate(const ITerrainProvider& provider) {
    if (provider.kind() == TerrainProviderKind::Flat) {
        // Match the exact historical flat generation/material logic.
        const auto* flat = dynamic_cast<const FlatTerrainProvider*>(&provider);
        if (!flat) throw std::invalid_argument("unknown flat terrain provider");
        generate(flat->terrainGenerator());
        return;
    }
    const auto* planet = dynamic_cast<const PlanetaryTerrainProvider*>(&provider);
    if (!planet) throw std::invalid_argument("unknown planetary terrain provider");
    radialTerrain = true;
    // Explicit radial surface materials avoid the legacy Y-up cliff classifier.
    // Vegetation billboards also assume Y-up, and are omitted for the prototype.
    sandLevel = -1e9f;
    snowLevel = 1e9f;
    const glm::ivec3 o = origin();
    for (int z = -PAD; z <= CHUNK_SIZE + PAD; ++z)
        for (int y = -PAD; y <= CHUNK_SIZE + PAD; ++y)
            for (int x = -PAD; x <= CHUNK_SIZE + PAD; ++x) {
                const glm::dvec3 pos(static_cast<double>(o.x) + x,
                                     static_cast<double>(o.y) + y,
                                     static_cast<double>(o.z) + z);
                const int i = index(x, y, z);
                density[i] = planet->densityAt(pos);
                const double radius = glm::length(pos);
                const double surface = radius > 1e-9
                    ? planet->shellRadius(pos / radius)
                    : planet->settings.planet.radiusMeters;
                const double depth = surface - radius;
                material[i] = depth < 4.0 ? MAT_GRASS : (depth < 10.0 ? MAT_DIRT : MAT_STONE);
            }
}

MaterialId resolveNatural(const glm::vec3& p, const glm::vec3& n, float sandLevel, float snowLevel) {
    if (n.y < 0.55f) return MAT_STONE;                               // cliffs, cave walls, overhangs
    const float wobble = 2.5f * std::sin(p.x * 0.13f) * std::cos(p.z * 0.11f);  // no ruler-straight borders
    if (p.y > snowLevel + wobble) return n.y > 0.68f ? MAT_SNOW : MAT_STONE;
    if (p.y < sandLevel + wobble) return MAT_SAND;
    return n.y > 0.66f ? MAT_GRASS : MAT_DIRT;
}

MaterialId VoxelChunk::resolve(MaterialId m, const glm::vec3& p, const glm::vec3& n) const {
    return m != MAT_NATURAL ? m : resolveNatural(p, n, sandLevel, snowLevel);
}

bool VoxelChunk::overlaps(const glm::vec3& mn, const glm::vec3& mx) const {
    const glm::vec3 lo = glm::vec3(origin() - PAD);
    const glm::vec3 hi = glm::vec3(origin() + CHUNK_SIZE + PAD);
    return !(mx.x < lo.x || mn.x > hi.x || mx.y < lo.y || mn.y > hi.y || mx.z < lo.z || mn.z > hi.z);
}

bool VoxelChunk::applySphere(const glm::vec3& c, float r, CsgMode mode, MaterialId mat) {
    const glm::vec3 local = c - glm::vec3(origin());
    const Range b = sphereRange(local, r);
    bool changed = false;
    for (int z = b.z0; z <= b.z1; ++z)
        for (int y = b.y0; y <= b.y1; ++y)
            for (int x = b.x0; x <= b.x1; ++x) {
                const float sdf = glm::length(glm::vec3(x, y, z) - local) - r; // sphere SDF
                const int i = index(x, y, z);
                float& d = density[i];
                const float before = d;
                // Real CSG: subtract = max(d, -sphere), union = min(d, sphere)
                if (mode == CsgMode::Subtract) d = std::max(d, -sdf);
                else if (sdf < d) { d = sdf; material[i] = mat; }      // the sphere's matter wins here
                d = std::clamp(d, -DENSITY_CLAMP, DENSITY_CLAMP);
                changed |= (d != before);
            }
    return changed;
}

bool VoxelChunk::applyPaint(const glm::vec3& c, float r, MaterialId mat) {
    const glm::vec3 local = c - glm::vec3(origin());
    const Range b = sphereRange(local, r);
    bool changed = false;
    for (int z = b.z0; z <= b.z1; ++z)
        for (int y = b.y0; y <= b.y1; ++y)
            for (int x = b.x0; x <= b.x1; ++x) {
                if (glm::length(glm::vec3(x, y, z) - local) > r) continue;
                MaterialId& m = material[index(x, y, z)];
                if (m != mat) { m = mat; changed = true; }
            }
    return changed;
}

bool VoxelChunk::addDelta(const DeltaGrid& g) {
    const glm::ivec3 o = origin();
    const int n = g.size;
    bool changed = false;
    for (size_t k = 0; k < g.index.size(); ++k) {
        const int gi = int(g.index[k]);
        const int lx = g.min.x + gi % n - o.x, ly = g.min.y + (gi / n) % n - o.y, lz = g.min.z + gi / (n * n) - o.z;
        if (lx < -PAD || ly < -PAD || lz < -PAD || lx > CHUNK_SIZE + PAD || ly > CHUNK_SIZE + PAD || lz > CHUNK_SIZE + PAD) continue;
        float& d = density[index(lx, ly, lz)];
        d = std::clamp(d + g.value[k], -DENSITY_CLAMP, DENSITY_CLAMP);
        changed = true;
    }
    return changed;
}

bool VoxelChunk::applyFlatten(const glm::vec3& c, float r) {
    const glm::vec3 local = c - glm::vec3(origin());
    const Range b = sphereRange(local, r);
    bool changed = false;
    for (int z = b.z0; z <= b.z1; ++z)
        for (int y = b.y0; y <= b.y1; ++y)
            for (int x = b.x0; x <= b.x1; ++x) {
                const float horiz = glm::length(glm::vec2(x - local.x, z - local.z));
                if (horiz > r || std::abs(y - local.y) > r) continue;
                const float w = glm::smoothstep(r, r * 0.55f, horiz);      // 1 in the middle, 0 at the rim
                float& d = density[index(x, y, z)];
                const float before = d;
                d = std::clamp(glm::mix(d, float(y) - local.y, w), -DENSITY_CLAMP, DENSITY_CLAMP);
                changed |= (d != before);
            }
    return changed;
}

bool VoxelChunk::unionGrid(const glm::ivec3& worldMin, int size, const std::vector<float>& grid,
                           const std::vector<MaterialId>& mats, MaterialId fallback) {
    const glm::ivec3 o = origin();
    bool changed = false;
    for (int gz = 0; gz < size; ++gz)
        for (int gy = 0; gy < size; ++gy)
            for (int gx = 0; gx < size; ++gx) {
                const int lx = worldMin.x + gx - o.x, ly = worldMin.y + gy - o.y, lz = worldMin.z + gz - o.z;
                if (lx < -PAD || ly < -PAD || lz < -PAD || lx > CHUNK_SIZE + PAD || ly > CHUNK_SIZE + PAD || lz > CHUNK_SIZE + PAD) continue;
                const size_t gi = size_t(gx + gy * size + gz * size * size);
                const int i = index(lx, ly, lz);
                if (grid[gi] < density[i]) {
                    density[i] = grid[gi];
                    material[i] = mats.empty() ? fallback : mats[gi];
                    changed = true;
                }
            }
    return changed;
}

glm::vec3 VoxelChunk::gradient(int x, int y, int z) const {
    const glm::vec3 g(sampleClamped(x + 1, y, z) - sampleClamped(x - 1, y, z),
                      sampleClamped(x, y + 1, z) - sampleClamped(x, y - 1, z),
                      sampleClamped(x, y, z + 1) - sampleClamped(x, y, z - 1));
    const float len = glm::length(g);
    return len > 1e-5f ? g / len : glm::vec3(0, 1, 0); // points toward air = outward
}

float VoxelChunk::ambientOcclusion(const glm::vec3& p, const glm::vec3& n) const {
    float ao = 1.0f;
    for (int i = 1; i <= 3; ++i) {
        const glm::vec3 s = p + n * (float(i) * 0.75f);
        if (sampleClamped(int(std::round(s.x)), int(std::round(s.y)), int(std::round(s.z))) < 0.0f)
            ao -= 0.35f / float(i);
    }
    return std::max(0.15f, ao);
}

void VoxelChunk::buildMesh() {
    static const glm::ivec3 corner[8] = {{0,0,0},{1,0,0},{1,1,0},{0,1,0},{0,0,1},{1,0,1},{1,1,1},{0,1,1}};
    static const int edge[12][2] = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};

    mesh.clear();
    const glm::vec3 o = glm::vec3(origin());

    // Cells 0..31 on every axis -> neighbouring chunks share their border faces
    // exactly, so there are no gaps between chunks.
    for (int z = 0; z < CHUNK_SIZE; ++z)
        for (int y = 0; y < CHUNK_SIZE; ++y)
            for (int x = 0; x < CHUNK_SIZE; ++x) {
                float val[8]; int cubeIndex = 0;
                for (int i = 0; i < 8; ++i) {
                    val[i] = sample(x + corner[i].x, y + corner[i].y, z + corner[i].z);
                    if (val[i] < 0.0f) cubeIndex |= (1 << i);
                }
                const int edges = edgeTable[cubeIndex];
                if (edges == 0) continue;

                glm::vec3 ev[12], en[12];
                MaterialId em[12];
                for (int e = 0; e < 12; ++e) {
                    if (!(edges & (1 << e))) continue;
                    const int a = edge[e][0], b = edge[e][1];
                    const float denom = val[b] - val[a];
                    const float t = std::abs(denom) > 1e-6f ? std::clamp(-val[a] / denom, 0.0f, 1.0f) : 0.5f;
                    const glm::ivec3 pa = glm::ivec3(x, y, z) + corner[a], pb = glm::ivec3(x, y, z) + corner[b];
                    ev[e] = glm::mix(glm::vec3(pa), glm::vec3(pb), t);
                    const glm::vec3 n = glm::mix(gradient(pa.x, pa.y, pa.z), gradient(pb.x, pb.y, pb.z), t);
                    en[e] = glm::length(n) > 1e-5f ? glm::normalize(n) : glm::vec3(0, 1, 0);
                    // The surface takes the material of the solid side of the edge.
                    const glm::ivec3 ps = val[a] < 0.0f ? pa : pb;
                    em[e] = resolve(materialAt(ps.x, ps.y, ps.z), ev[e] + o, en[e]);
                }

                for (int i = 0; triTable[cubeIndex][i] != -1; i += 3) {
                    int i0 = triTable[cubeIndex][i], i1 = triTable[cubeIndex][i + 1], i2 = triTable[cubeIndex][i + 2];
                    // Make winding agree with the outward normal so back-face culling is correct.
                    const glm::vec3 faceN = glm::cross(ev[i1] - ev[i0], ev[i2] - ev[i0]);
                    if (glm::dot(faceN, en[i0] + en[i1] + en[i2]) < 0.0f) std::swap(i1, i2);
                    const std::uint8_t l0 = std::uint8_t(em[i0] - 1), l1 = std::uint8_t(em[i1] - 1), l2 = std::uint8_t(em[i2] - 1);
                    const int tri[3] = { i0, i1, i2 };
                    for (int k = 0; k < 3; ++k) {
                        Vertex v{ ev[tri[k]] + o, en[tri[k]], ambientOcclusion(ev[tri[k]], en[tri[k]]),
                                  { l0, l1, l2, 0 }, { 0, 0, 0, 0 } };
                        v.bary[k] = 255;
                        mesh.push_back(v);
                    }
                }
            }
    buildGrass();
    buildTrees();
    ++meshVersion;
}

// Blades sit on a jittered grid fixed in WORLD space, so sculpting nearby never makes
// them jump around: an edit only changes the height a blade is planted at (or removes it
// if the ground stops being grass). Every grass-material triangle plants the blades whose
// grid cell falls inside it (seen from above).
void VoxelChunk::buildGrass() {
    if (radialTerrain) { grass.clear(); return; }
    grass.clear();
    constexpr float kCell = 0.28f;                               // ~12 blades per square metre
    auto lattice = [](int x, int z) { return hash01(x, z, 77u); };
    auto patch = [&](float wx, float wz) {                       // smooth value noise, 5 m features
        const float fx = wx / 5.0f, fz = wz / 5.0f;
        const int ix = int(std::floor(fx)), iz = int(std::floor(fz));
        float tx = fx - ix, tz = fz - iz;
        tx = tx * tx * (3 - 2 * tx); tz = tz * tz * (3 - 2 * tz);
        return glm::mix(glm::mix(lattice(ix, iz), lattice(ix + 1, iz), tx), glm::mix(lattice(ix, iz + 1), lattice(ix + 1, iz + 1), tx), tz);
    };

    for (size_t i = 0; i + 2 < mesh.size(); i += 3) {
        const Vertex &a = mesh[i], &b = mesh[i + 1], &c = mesh[i + 2];
        if (a.layers[0] != MAT_GRASS - 1 || a.layers[1] != MAT_GRASS - 1 || a.layers[2] != MAT_GRASS - 1) continue;
        const glm::vec3 n = glm::normalize(a.normal + b.normal + c.normal);
        if (n.y < 0.62f) continue;

        const glm::vec2 p0(a.position.x, a.position.z), p1(b.position.x, b.position.z), p2(c.position.x, c.position.z);
        const float det = (p1.y - p2.y) * (p0.x - p2.x) + (p2.x - p1.x) * (p0.y - p2.y);
        if (std::abs(det) < 1e-6f) continue;
        const float minx = std::min({ p0.x, p1.x, p2.x }), maxx = std::max({ p0.x, p1.x, p2.x });
        const float minz = std::min({ p0.y, p1.y, p2.y }), maxz = std::max({ p0.y, p1.y, p2.y });
        const float slope = glm::smoothstep(0.62f, 0.85f, n.y);

        for (int gz = int(std::floor(minz / kCell)); gz <= int(std::floor(maxz / kCell)); ++gz)
            for (int gx = int(std::floor(minx / kCell)); gx <= int(std::floor(maxx / kCell)); ++gx) {
                const glm::vec2 q((float(gx) + hash01(gx, gz, 11u)) * kCell, (float(gz) + hash01(gx, gz, 12u)) * kCell);
                const float l0 = ((p1.y - p2.y) * (q.x - p2.x) + (p2.x - p1.x) * (q.y - p2.y)) / det;
                const float l1 = ((p2.y - p0.y) * (q.x - p2.x) + (p0.x - p2.x) * (q.y - p2.y)) / det;
                const float l2 = 1.0f - l0 - l1;
                if (l0 < 0.0f || l1 < 0.0f || l2 < 0.0f) continue;

                // Meadow patches: some places are thick, some thin.
                const float cover = (0.35f + 0.65f * glm::smoothstep(0.2f, 0.6f, patch(q.x, q.y))) * slope;
                if (hash01(gx, gz, 13u) > cover) continue;

                GrassBlade g{};
                g.x = q.x; g.z = q.y;
                g.y = l0 * a.position.y + l1 * b.position.y + l2 * c.position.y;
                g.seed = std::uint8_t(hash01(gx, gz, 14u) * 255.0f);
                g.size = std::uint8_t(hash01(gx, gz, 15u) * 255.0f);
                // A few flowers, clustered where the meadow is thick.
                if (hash01(gx, gz, 16u) < 0.012f + 0.03f * glm::smoothstep(0.55f, 0.9f, patch(q.x + 40.0f, q.y - 17.0f)))
                    g.kind = std::uint8_t(1 + int(hash01(gx, gz, 17u) * 5.0f) % 5);
                g.nx = std::int8_t(std::lround(n.x * 127.0f));
                g.nz = std::int8_t(std::lround(n.z * 127.0f));
                grass.push_back(g);
            }
    }
}


// Trees on a coarser world grid than the grass, by the same rule (a cell's jittered point inside a grass triangle).
// Forests come and go on a large scale (about 120 m), with a few lone trees in the meadows and bushes at the edges.
void VoxelChunk::buildTrees() {
    if (radialTerrain) { trees.clear(); return; }
    trees.clear();
    auto smoothNoise = [](float wx, float wz, float size, std::uint32_t seed) {
        const float fx = wx / size, fz = wz / size;
        const int ix = int(std::floor(fx)), iz = int(std::floor(fz));
        float tx = fx - ix, tz = fz - iz;
        tx = tx * tx * (3 - 2 * tx); tz = tz * tz * (3 - 2 * tz);
        auto l = [&](int x, int z) { return hash01(x, z, seed); };
        return glm::mix(glm::mix(l(ix, iz), l(ix + 1, iz), tx), glm::mix(l(ix, iz + 1), l(ix + 1, iz + 1), tx), tz);
    };
    auto forestAt = [&](float x, float z) { return 0.65f * smoothNoise(x, z, 120.0f, 301u) + 0.35f * smoothNoise(x, z, 37.0f, 302u); };
    struct Grid { float cell; std::uint32_t salt; bool bushes; };
    const Grid grids[2] = { { 6.5f, 400u, false }, { 4.0f, 500u, true } };

    for (size_t i = 0; i + 2 < mesh.size(); i += 3) {
        const Vertex &a = mesh[i], &b = mesh[i + 1], &c = mesh[i + 2];
        if (a.layers[0] != MAT_GRASS - 1 || a.layers[1] != MAT_GRASS - 1 || a.layers[2] != MAT_GRASS - 1) continue;
        const glm::vec3 n = glm::normalize(a.normal + b.normal + c.normal);
        if (n.y < 0.8f) continue;                                    // not on steep slopes
        const glm::vec2 p0(a.position.x, a.position.z), p1(b.position.x, b.position.z), p2(c.position.x, c.position.z);
        const float det = (p1.y - p2.y) * (p0.x - p2.x) + (p2.x - p1.x) * (p0.y - p2.y);
        if (std::abs(det) < 1e-6f) continue;
        const float minx = std::min({ p0.x, p1.x, p2.x }), maxx = std::max({ p0.x, p1.x, p2.x });
        const float minz = std::min({ p0.y, p1.y, p2.y }), maxz = std::max({ p0.y, p1.y, p2.y });
        for (const Grid& g : grids)
            for (int gz = int(std::floor(minz / g.cell)); gz <= int(std::floor(maxz / g.cell)); ++gz)
                for (int gx = int(std::floor(minx / g.cell)); gx <= int(std::floor(maxx / g.cell)); ++gx) {
                    const glm::vec2 q((float(gx) + 0.15f + 0.7f * hash01(gx, gz, g.salt + 1u)) * g.cell, (float(gz) + 0.15f + 0.7f * hash01(gx, gz, g.salt + 2u)) * g.cell);
                    const float l0 = ((p1.y - p2.y) * (q.x - p2.x) + (p2.x - p1.x) * (q.y - p2.y)) / det;
                    const float l1 = ((p2.y - p0.y) * (q.x - p2.x) + (p0.x - p2.x) * (q.y - p2.y)) / det;
                    const float l2 = 1.0f - l0 - l1;
                    if (l0 < 0.0f || l1 < 0.0f || l2 < 0.0f) continue;
                    const float forest = forestAt(q.x, q.y);
                    const float wood = glm::smoothstep(0.5f, 0.68f, forest);
                    const float chance = g.bushes ? 0.05f + 0.35f * glm::smoothstep(0.42f, 0.55f, forest) * (1.0f - wood * 0.6f)   // thickets at the forest edge
                                                  : 0.03f + 0.85f * wood;                                                       // forests, and a lone tree now and then
                    if (hash01(gx, gz, g.salt + 3u) > chance) continue;
                    TreeInstance t{};
                    t.x = q.x; t.z = q.y;
                    t.y = l0 * a.position.y + l1 * b.position.y + l2 * c.position.y;
                    if (g.bushes) t.kind = 3;
                    else {
                        // pines high up and here and there; birches in light patches; oaks elsewhere
                        const float alpine = glm::smoothstep(snowLevel - 30.0f, snowLevel - 8.0f, t.y);
                        const float pick = hash01(gx, gz, g.salt + 4u);
                        const float pineShare = 0.25f + 0.7f * alpine + 0.3f * smoothNoise(q.x, q.y, 90.0f, 303u);
                        t.kind = pick < pineShare ? 1 : (smoothNoise(q.x, q.y, 50.0f, 304u) > 0.6f ? 2 : 0);
                    }
                    t.variant = std::uint8_t(std::min(2, int(hash01(gx, gz, g.salt + 5u) * 3.0f)));
                    t.yaw = std::uint8_t(hash01(gx, gz, g.salt + 6u) * 255.0f);
                    t.rand = std::uint8_t(hash01(gx, gz, g.salt + 7u) * 255.0f);
                    t.scale = 0.75f + 0.5f * hash01(gx, gz, g.salt + 8u);
                    trees.push_back(t);
                }
    }
}

} // namespace px
