#pragma once
// Spherified-cube mapping prototype. Input face coordinates u/v are in [-1,1].
// This provides deterministic directions; quadtree tile addressing and seam
// stitching are separate follow-up work.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <glm/glm.hpp>

namespace px {

enum class CubeFace : std::uint8_t { PositiveX, NegativeX, PositiveY, NegativeY, PositiveZ, NegativeZ };

inline glm::dvec3 spherifiedCubeDirection(CubeFace face, double u, double v) {
    // Clamp tiny caller error but do not silently wrap face coordinates.
    u = glm::clamp(u, -1.0, 1.0);
    v = glm::clamp(v, -1.0, 1.0);
    double x = 0.0, y = 0.0, z = 0.0;
    switch (face) {
        case CubeFace::PositiveX: x = 1; y = v; z = -u; break;
        case CubeFace::NegativeX: x = -1; y = v; z = u; break;
        case CubeFace::PositiveY: x = u; y = 1; z = -v; break;
        case CubeFace::NegativeY: x = u; y = -1; z = v; break;
        case CubeFace::PositiveZ: x = u; y = v; z = 1; break;
        case CubeFace::NegativeZ: x = -u; y = v; z = -1; break;
    }
    const double xx = x*x, yy = y*y, zz = z*z;
    const double sx = x * std::sqrt(std::max(0.0, 1.0 - yy*0.5 - zz*0.5 + yy*zz/3.0));
    const double sy = y * std::sqrt(std::max(0.0, 1.0 - zz*0.5 - xx*0.5 + zz*xx/3.0));
    const double sz = z * std::sqrt(std::max(0.0, 1.0 - xx*0.5 - yy*0.5 + xx*yy/3.0));
    const glm::dvec3 d(sx, sy, sz);
    const double len = glm::length(d);
    return len > 0.0 ? d / len : glm::dvec3(0.0, 1.0, 0.0);
}

inline glm::dvec3 planetSurfacePoint(CubeFace face, double u, double v, double radiusMeters) {
    return spherifiedCubeDirection(face, u, v) * radiusMeters;
}

} // namespace px
