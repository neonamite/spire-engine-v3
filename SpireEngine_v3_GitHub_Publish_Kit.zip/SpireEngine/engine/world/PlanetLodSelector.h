#pragma once
// CPU-only quadtree tile selector for a planet's *surface* render layer.
// Output is deterministic and budget bounded, but not yet wired to the GPU,
// the voxel streamer, or full topological mixed-LOD seam stitching.
#include "CubeTile.h"
#include "PlanetDefinition.h"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <tuple>
#include <vector>
#include <glm/glm.hpp>

namespace px {

struct PlanetLodSettings {
    double targetScreenErrorPixels = 3.0;
    double verticalFovDegrees = 70.0;
    std::uint32_t viewportHeightPixels = 1080;
    std::uint32_t maxTiles = 512;
    std::uint8_t maxLevel = 20;
    bool horizonCulling = true;
};

inline bool validPlanetLodSettings(const PlanetLodSettings& s) {
    return std::isfinite(s.targetScreenErrorPixels) && s.targetScreenErrorPixels > 0 &&
        std::isfinite(s.verticalFovDegrees) && s.verticalFovDegrees >= 1.0 && s.verticalFovDegrees < 175.0 &&
        s.viewportHeightPixels >= 16 && s.viewportHeightPixels <= 16384 &&
        s.maxTiles >= 6 && s.maxTiles <= 65536 && s.maxLevel <= kMaxCubeTileLevel;
}

inline bool selectPlanetSurfaceTiles(const PlanetDefinition& planet,
                                     const glm::dvec3& cameraAbsolute,
                                     const PlanetLodSettings& settings,
                                     std::vector<CubeTileCoord>& out) {
    if (!planet.valid() || !validPlanetLodSettings(settings) ||
        !std::isfinite(cameraAbsolute.x) || !std::isfinite(cameraAbsolute.y) ||
        !std::isfinite(cameraAbsolute.z)) return false;
    const double cameraDistance = glm::length(cameraAbsolute);
    if (!std::isfinite(cameraDistance)) return false;
    const glm::dvec3 eyeDirection = cameraDistance > 1.0e-10
        ? cameraAbsolute / cameraDistance : glm::dvec3(0.0, 0.0, 1.0);
    const double horizonAngle = cameraDistance > planet.radiusMeters
        ? std::acos(std::clamp(planet.radiusMeters / cameraDistance, 0.0, 1.0))
        : 3.14159265358979323846;
    const double focal = settings.viewportHeightPixels /
        (2.0 * std::tan(settings.verticalFovDegrees * 3.14159265358979323846 / 360.0));

    const auto measure = [&](const CubeTileCoord& t, double& priority, bool& visible) {
        double u=0.0, v=0.0;
        (void)tileCenterUv(t, u, v);
        const glm::dvec3 dir = spherifiedCubeDirection(t.face, u, v);
        const double ang = std::acos(std::clamp(glm::dot(dir, eyeDirection), -1.0, 1.0));
        const double step = 2.0 / static_cast<double>(tilesPerEdge(t.level));
        double angleExtent = 0.0;
        for (int dx=-1; dx<=1; dx+=2) for (int dy=-1; dy<=1; dy+=2) {
            const glm::dvec3 corner = spherifiedCubeDirection(t.face, u+dx*step*0.5, v+dy*step*0.5);
            angleExtent = std::max(angleExtent,
                std::acos(std::clamp(glm::dot(dir, corner), -1.0, 1.0)));
        }
        visible = !settings.horizonCulling || horizonAngle >= 3.0 ||
            ang <= horizonAngle + angleExtent + 1.0e-8;
        const double centerDistance = glm::length(cameraAbsolute - planet.radiusMeters * dir);
        const double projectedDistance = std::max(1.0, centerDistance);
        // Conservative proxy for curvature chord error + unresolved relief.
        // Proper terrain-frequency error metrics will replace the latter term.
        const double n = static_cast<double>(tilesPerEdge(t.level));
        const double worldError = planet.radiusMeters * (1.0 - std::cos(1.0/n)) +
                                  planet.terrainAmplitudeMeters/n;
        priority = worldError * focal / projectedDistance;
    };

    constexpr CubeFace faces[] = {CubeFace::PositiveX, CubeFace::NegativeX,
        CubeFace::PositiveY, CubeFace::NegativeY, CubeFace::PositiveZ, CubeFace::NegativeZ};
    std::vector<CubeTileCoord> leaves;
    leaves.reserve(std::min<std::uint32_t>(settings.maxTiles,4096));
    for (const CubeFace face : faces) {
        const CubeTileCoord root{face,0,0,0};
        double score; bool visible;
        measure(root,score,visible);
        if(visible) leaves.push_back(root);
    }
    // Splitting adds at most three leaves. Horizon culling can add fewer,
    // never violating the user's active tile budget.
    while (!leaves.empty()) {
        std::size_t best = leaves.size();
        double bestError = settings.targetScreenErrorPixels;
        for (std::size_t i=0;i<leaves.size();++i) {
            if(leaves[i].level >= settings.maxLevel) continue;
            double score; bool visible;
            measure(leaves[i],score,visible);
            if(visible && score > bestError) {bestError=score; best=i;}
        }
        if(best==leaves.size()) break;
        const CubeTileCoord parent=leaves[best];
        std::vector<CubeTileCoord> children;
        for(std::uint32_t dy=0;dy<2;++dy) for(std::uint32_t dx=0;dx<2;++dx) {
            const CubeTileCoord child{parent.face,static_cast<std::uint8_t>(parent.level+1),
                                      parent.x*2+dx,parent.y*2+dy};
            double score; bool visible;
            measure(child,score,visible);
            if(visible) children.push_back(child);
        }
        const auto sizeAfter = leaves.size()-1+children.size();
        if(sizeAfter > settings.maxTiles) break;
        leaves.erase(leaves.begin()+static_cast<std::ptrdiff_t>(best));
        leaves.insert(leaves.end(),children.begin(),children.end());
    }
    std::sort(leaves.begin(),leaves.end(),[](const CubeTileCoord& a,const CubeTileCoord& b){
        return std::tie(a.face,a.level,a.x,a.y) < std::tie(b.face,b.level,b.x,b.y);
    });
    out = std::move(leaves);
    return true;
}

} // namespace px
