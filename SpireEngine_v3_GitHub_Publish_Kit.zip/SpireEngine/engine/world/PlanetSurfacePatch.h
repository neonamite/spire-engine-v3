#pragma once
// CPU-only cube-sphere surface patch builder for planetary quadtree LOD.
// Tile vertices are stored relative to an authoritative DOUBLE-precision
// patch origin. This keeps near-camera meshes precise on large planets.
//
// This is a surface LOD prototype, not yet the authoritative voxel volume
// pipeline or a renderer upload. Terrain caves/overhangs remain handled by the
// existing radial voxel SDF. Different-resolution edges use optional skirts
// as a visual crack mask; exact topological seam stitching is future work.
#include "CubeTile.h"
#include "PlanetDefinition.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <limits>
#include <vector>
#include <glm/glm.hpp>

namespace px {

struct PlanetPatchVertex {
    glm::vec3 localPosition{0.0f}; // metres relative to patch.originMeters
    glm::vec3 normal{0.0f, 1.0f, 0.0f}; // radial preliminary normal
};

struct PlanetSurfacePatch {
    CubeTileCoord tile{};
    glm::dvec3 originMeters{0.0};
    std::uint16_t cellsPerEdge = 0;
    std::vector<PlanetPatchVertex> vertices;
    std::vector<std::uint32_t> indices;
    std::uint32_t skirtVertexStart = 0;
};

// Surface relief *relative to nominal radius*, in metres. The function must
// return finite results for all unit directions on the tile, and be pure so
// two faces produce identical points at their shared edge.
using PlanetReliefSampler = std::function<double(const glm::dvec3&)>;

inline bool buildPlanetSurfacePatch(const CubeTileCoord& tile, const PlanetDefinition& planet,
                                    std::uint16_t resolution, double skirtDepthMeters,
                                    const PlanetReliefSampler& relief,
                                    PlanetSurfacePatch& out) {
    if (!planet.valid() || validateTile(tile) != TileError::Ok ||
        resolution < 2 || resolution > 256 || !std::isfinite(skirtDepthMeters) ||
        skirtDepthMeters < 0.0 || skirtDepthMeters > 100'000.0 ||
        skirtDepthMeters > planet.radiusMeters * 0.5 || !relief) return false;
    const auto surfacePoint = [&](double u, double v, glm::dvec3& p, glm::dvec3& up) -> bool {
        up = spherifiedCubeDirection(tile.face, u, v);
        const double height = relief(up);
        const double radius = planet.radiusMeters + height;
        if (!std::isfinite(radius) || radius <= 0.0 || !std::isfinite(height)) return false;
        p = up * radius;
        return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
    };
    const double t = static_cast<double>(tilesPerEdge(tile.level));
    const double step = 2.0 / t;
    const double u0 = -1.0 + static_cast<double>(tile.x) * step;
    const double v0 = -1.0 + static_cast<double>(tile.y) * step;
    PlanetSurfacePatch patch;
    patch.tile = tile;
    patch.cellsPerEdge = resolution;
    glm::dvec3 originUp{};
    if (!surfacePoint(u0 + step*0.5, v0 + step*0.5, patch.originMeters, originUp)) return false;
    const std::uint32_t stride = static_cast<std::uint32_t>(resolution) + 1u;
    const std::uint32_t total = stride * stride;
    const std::uint32_t boundaryCount = std::uint32_t(resolution) * 4u;
    patch.vertices.reserve(total + (skirtDepthMeters > 0.0 ? boundaryCount : 0u));
    patch.indices.reserve(6u * std::uint32_t(resolution) * resolution +
                          (skirtDepthMeters > 0.0 ? 6u * boundaryCount : 0u));
    const auto vertex = [&](std::uint32_t x, std::uint32_t y) {return x + y*stride;};
    for (std::uint32_t y=0; y<stride; ++y) {
        for (std::uint32_t x=0; x<stride; ++x) {
            glm::dvec3 world{}, up{};
            if (!surfacePoint(u0 + step * (static_cast<double>(x) / resolution),
                              v0 + step * (static_cast<double>(y) / resolution), world, up)) return false;
            const glm::dvec3 local = world - patch.originMeters;
            if (glm::length(local) > 1.0e9 ||
                !std::isfinite(local.x) || !std::isfinite(local.y) || !std::isfinite(local.z)) return false;
            patch.vertices.push_back({glm::vec3(local), glm::vec3(up)});
        }
    }
    for (std::uint32_t y=0; y<resolution; ++y) {
        for (std::uint32_t x=0; x<resolution; ++x) {
            const auto a=vertex(x,y), b=vertex(x+1,y), c=vertex(x,y+1), d=vertex(x+1,y+1);
            patch.indices.insert(patch.indices.end(), {a,b,c, b,d,c});
        }
    }
    patch.skirtVertexStart = total;
    if (skirtDepthMeters > 0.0) {
        std::vector<std::uint32_t> boundary;
        boundary.reserve(boundaryCount);
        for (std::uint32_t x=0; x<resolution; ++x) boundary.push_back(vertex(x,0));
        for (std::uint32_t y=0; y<resolution; ++y) boundary.push_back(vertex(resolution,y));
        for (std::uint32_t x=resolution; x>0; --x) boundary.push_back(vertex(x,resolution));
        for (std::uint32_t y=resolution; y>0; --y) boundary.push_back(vertex(0,y));
        for (std::uint32_t i=0;i<boundaryCount;++i) {
            const auto& original = patch.vertices[boundary[i]];
            const glm::dvec3 inward = glm::dvec3(original.normal) * skirtDepthMeters;
            const glm::dvec3 lowered = glm::dvec3(original.localPosition) - inward;
            patch.vertices.push_back({glm::vec3(lowered), original.normal});
        }
        for (std::uint32_t i=0;i<boundaryCount;++i) {
            const std::uint32_t j=(i+1)%boundaryCount;
            const std::uint32_t a=boundary[i], b=boundary[j];
            const std::uint32_t c=total+i, d=total+j;
            patch.indices.insert(patch.indices.end(), {a,c,b, b,c,d});
        }
    }
    out = std::move(patch); // transactional: out unchanged on invalid sample
    return true;
}

// Reconstruct absolute world position for accurate cross-face comparisons.
inline glm::dvec3 planetPatchWorldVertex(const PlanetSurfacePatch& patch, std::size_t index) {
    return patch.originMeters + glm::dvec3(patch.vertices.at(index).localPosition);
}

} // namespace px
