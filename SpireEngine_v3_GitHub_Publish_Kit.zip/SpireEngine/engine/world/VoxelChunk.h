#pragma once
// A chunk is pure CPU data: a padded density grid plus the triangle mesh built
// from it. It owns no OpenGL objects, so it can be built on any thread and
// destroyed anywhere. The renderer keeps the GPU copy separately.
#include <vector>
#include <cstdint>
#include <glm/glm.hpp>
#include "WorldTypes.h"
#include "Materials.h"

namespace px {

class TerrainGenerator;
class ITerrainProvider;

// What "Natural" matter looks like at a spot: stone on steep faces, snow high up,
// sand low down, otherwise grass or dirt by slope. n = unit surface normal.
MaterialId resolveNatural(const glm::vec3& worldPos, const glm::vec3& n, float sandLevel, float snowLevel);

struct Vertex {
    glm::vec3    position;  // world space
    glm::vec3    normal;
    float        ao;        // baked ambient occlusion, 0.15..1
    // Texture layers of the triangle's three corners (the same on all three
    // vertices) plus this vertex's barycentric weights (255 at its own corner).
    // The shader blends the three materials across the triangle, so painted
    // edges fade softly instead of following the mesh's triangles.
    std::uint8_t layers[4];
    std::uint8_t bary[4];
};
static_assert(sizeof(Vertex) == 36, "Vertex layout is mirrored in Renderer::upload");

enum class CsgMode : std::uint8_t { Subtract, Union };

// One blade of grass (or a flower), planted on the surface. Built on the worker
// threads along with the mesh, drawn by the renderer as GPU instances.
struct GrassBlade {
    float        x, y, z;        // world position of the root
    std::uint8_t seed;           // random per blade: direction, colour, thinning
    std::uint8_t size;           // height variation
    std::uint8_t kind;           // 0 = grass, 1..5 = flower colour
    std::uint8_t pad0;
    std::int8_t  nx, nz;         // ground normal (x, z) * 127
    std::uint8_t pad1[2];
};
static_assert(sizeof(GrassBlade) == 20, "GrassBlade layout is mirrored in Renderer::upload");

// A tree (or bush) the world planted (1.3). Placed on a jittered grid fixed in world space, on grass that is not too
// steep, thicker in forests than in meadows, pines higher up; rebuilt with the mesh, so paving over grass removes it.
struct TreeInstance {
    float        x, y, z;        // where the trunk meets the ground
    std::uint8_t kind;           // TreeKind: oak, pine, birch, bush
    std::uint8_t variant;        // 0..2
    std::uint8_t yaw;            // turn, in 256ths of a circle
    std::uint8_t rand;           // 0..255: drawn when below the density setting (so thinning is stable)
    float        scale;          // 0.75..1.25
};

// Sparse density offsets on a world-space cube (only the non-zero samples are
// stored). The Smooth brush records its result this way.
struct DeltaGrid {
    glm::ivec3 min{0};
    int size = 0;                          // cube edge, in samples
    std::vector<std::uint32_t> index;      // x + y*size + z*size*size
    std::vector<float> value;
};

class VoxelChunk {
public:
    explicit VoxelChunk(glm::ivec3 coord);

    glm::ivec3 coord;                 // chunk index
    glm::ivec3 origin() const { return coord * CHUNK_SIZE; }

    std::vector<float>      density;    // SAMPLE_COUNT values, padded
    std::vector<MaterialId> material;   // SAMPLE_COUNT values, same layout as density
    std::vector<Vertex> mesh;
    std::vector<GrassBlade> grass;    // rebuilt with the mesh
    std::vector<TreeInstance> trees;  // rebuilt with the mesh
    std::uint32_t meshVersion = 0;    // bumped on every remesh -> renderer re-uploads

    // local coords range [-PAD, CHUNK_SIZE + PAD]
    static int index(int lx, int ly, int lz) {
        return (lx + PAD) + (ly + PAD) * SAMPLES + (lz + PAD) * SAMPLES * SAMPLES;
    }
    float sample(int lx, int ly, int lz) const { return density[index(lx, ly, lz)]; }
    float sampleClamped(int lx, int ly, int lz) const;
    MaterialId materialAt(int lx, int ly, int lz) const { return material[index(lx, ly, lz)]; }

    // Heights (world Y) where Natural turns into sand below / snow above. Set by generate().
    float sandLevel = -1e9f, snowLevel = 1e9f;

    void generate(const TerrainGenerator& gen);
    // Planetary prototype uses the same padded voxel grid and Marching Cubes
    // pipeline, with radial density/material layers instead of flat world Y.
    void generate(const ITerrainProvider& provider);
    bool radialTerrain = false;

    // CSG sphere edit in world space. Union also gives the new matter `mat`.
    // Returns true if any sample changed.
    bool applySphere(const glm::vec3& worldCenter, float radius, CsgMode mode, MaterialId mat = MAT_STONE);

    // Change the material inside a sphere without changing the shape.
    bool applyPaint(const glm::vec3& worldCenter, float radius, MaterialId mat);

    // Add a world-space grid of density offsets (used by the Smooth brush, whose
    // result is computed once from the live world so every chunk agrees on it).
    bool addDelta(const DeltaGrid& delta);

    // Pull terrain toward a flat plane at worldCenter.y inside a radius (soft edge).
    bool applyFlatten(const glm::vec3& worldCenter, float radius);

    // Union an arbitrary density grid (a prefab) whose min corner sits at worldMin.
    // `mats` may be empty, then the new matter gets `fallback`.
    bool unionGrid(const glm::ivec3& worldMin, int size, const std::vector<float>& grid,
                   const std::vector<MaterialId>& mats = {}, MaterialId fallback = MAT_STONE);

    // Does the padded sample region of this chunk overlap a world AABB?
    bool overlaps(const glm::vec3& mn, const glm::vec3& mx) const;

    void buildMesh();

private:
    void buildGrass();
    void buildTrees();
    glm::vec3 gradient(int lx, int ly, int lz) const;
    float     ambientOcclusion(const glm::vec3& local, const glm::vec3& n) const;
    MaterialId resolve(MaterialId m, const glm::vec3& worldPos, const glm::vec3& n) const;
};

} // namespace px
