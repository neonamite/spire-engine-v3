#include "PlanetSurfaceRuntime.h"
#include <algorithm>
#include <functional>
#include <set>
#include <tuple>
#include <unordered_set>

namespace px {
namespace {
CubeTileCoord parentOf(CubeTileCoord t) {
    --t.level;
    t.x /= 2;
    t.y /= 2;
    return t;
}
// Only commit children when *all* visible descendants are ready. A parent
// remains as a coherent fallback instead of overlapping a partly ready child.
bool emitReady(const CubeTileCoord& tile,
               const std::unordered_set<CubeTileCoord, CubeTileHash>& leaves,
               const PlanetSurfaceStreamer& streamer,
               std::vector<CubeTileCoord>& drawn) {
    if (leaves.contains(tile)) {
        if (!streamer.findReady(tile)) return false;
        drawn.push_back(tile);
        return true;
    }
    if (tile.level >= kMaxCubeTileLevel) return false;
    const auto checkpoint = drawn.size();
    for (std::uint32_t y = 0; y < 2; ++y) {
        for (std::uint32_t x = 0; x < 2; ++x) {
            CubeTileCoord child{tile.face, static_cast<std::uint8_t>(tile.level+1),
                                tile.x*2+x, tile.y*2+y};
            // A culled child is not a supported hole: parent must cover it.
            if (!emitReady(child, leaves, streamer, drawn)) {
                drawn.resize(checkpoint);
                if (!streamer.findReady(tile)) return false;
                drawn.push_back(tile);
                return true;
            }
        }
    }
    return true;
}
}
PlanetSurfaceRuntime::PlanetSurfaceRuntime(unsigned workers): streamer_(workers) {}

bool PlanetSurfaceRuntime::configure(const PlanetDefinition& planet, PlanetReliefSampler sampler,
                                     std::uint16_t resolution, double skirtMeters) {
    if (!streamer_.configure(planet, resolution, skirtMeters, std::move(sampler))) return false;
    planet_ = planet;
    configured_ = true;
    wanted_.clear();
    return true;
}

bool PlanetSurfaceRuntime::update(const glm::dvec3& cameraRelativeToPlanet,
                 const WorldPosition& planetCenter, const WorldPosition& camera,
                 const PlanetLodSettings& lod, double maxDrawOriginDistance,
                 std::vector<PlanetSurfaceDrawPacket>& packets) {
    if (!configured_ || !camera.isCanonical() || !planetCenter.isCanonical()) return false;
    std::vector<CubeTileCoord> leaves;
    if (!selectPlanetSurfaceTiles(planet_, cameraRelativeToPlanet, lod, leaves)) return false;
    // Request visible leaves and all their ancestors, with roots first to
    // guarantee fast coarse coverage even with a small worker/queue budget.
    std::unordered_set<CubeTileCoord, CubeTileHash> unique;
    unique.reserve(leaves.size() * 5 + 6);
    for (auto t : leaves) {
        unique.insert(t);
        while (t.level > 0) { t = parentOf(t); unique.insert(t); }
    }
    std::vector<CubeTileCoord> selected(unique.begin(), unique.end());
    std::sort(selected.begin(), selected.end(), [](const auto& a, const auto& b) {
        return std::tie(a.level, a.face, a.x, a.y) < std::tie(b.level, b.face, b.x, b.y);
    });
    if (selected.size() > 4096 || !streamer_.setSelection(selected)) return false;
    streamer_.collect(16);
    std::unordered_set<CubeTileCoord, CubeTileHash> leafSet(leaves.begin(), leaves.end());
    std::vector<CubeTileCoord> draw;
    for (CubeFace face : {CubeFace::PositiveX, CubeFace::NegativeX, CubeFace::PositiveY,
                          CubeFace::NegativeY, CubeFace::PositiveZ, CubeFace::NegativeZ}) {
        const CubeTileCoord root{face, 0, 0, 0};
        if (unique.contains(root)) emitReady(root, leafSet, streamer_, draw);
    }
    if (!makePlanetSurfaceDrawPackets(streamer_, draw, planetCenter, camera,
                                      maxDrawOriginDistance, packets)) return false;
    wanted_ = std::move(selected);
    return true;
}
} // namespace px
