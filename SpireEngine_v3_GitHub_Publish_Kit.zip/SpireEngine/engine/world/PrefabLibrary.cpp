#include "PrefabLibrary.h"
#include "WorldTypes.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>

namespace px {

namespace {
constexpr char     kMagic[4] = { 'V', 'X', 'P', 'F' };
constexpr uint32_t kVersion  = 2;   // v2 adds one material byte per sample (v1 loads as stone)
constexpr int      kMaxSize  = 64;

std::shared_ptr<Prefab> makeSDF(const std::string& name, int size, auto&& sdf) {
    auto p = std::make_shared<Prefab>();
    p->name = name; p->size = size; p->grid.resize(size * size * size);
    for (int z = 0; z < size; ++z)
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x)
                p->grid[x + y * size + z * size * size] = std::clamp(sdf(glm::vec3(x, y, z)), -DENSITY_CLAMP, DENSITY_CLAMP);
    return p;
}

// Same, with a single material for every voxel of the prop.
std::shared_ptr<Prefab> makeSDFm(const std::string& name, int size, MaterialId material, auto&& sdf) {
    auto p = makeSDF(name, size, sdf);
    p->materials.assign(p->grid.size(), material);
    return p;
}
float sdBox(const glm::vec3& p, const glm::vec3& centre, const glm::vec3& half, float round = 0.0f) {
    const glm::vec3 q = glm::abs(p - centre) - (half - glm::vec3(round));
    return glm::length(glm::max(q, glm::vec3(0.0f))) + std::min(std::max(q.x, std::max(q.y, q.z)), 0.0f) - round;
}
// Cylinder standing on the Y axis through (cx, cz), from y0 to y1.
float sdCylY(const glm::vec3& p, float cx, float cz, float radius, float y0, float y1) {
    const glm::vec2 d(glm::length(glm::vec2(p.x - cx, p.z - cz)) - radius, std::abs(p.y - (y0 + y1) * 0.5f) - (y1 - y0) * 0.5f);
    return std::min(std::max(d.x, d.y), 0.0f) + glm::length(glm::max(d, glm::vec2(0.0f)));
}
} // namespace

void PrefabLibrary::addBuiltins() {
    // Stone pillar: a capped vertical cylinder.
    add(makeSDF("stone_pillar", 14, [](glm::vec3 p) {
        const glm::vec2 d = glm::vec2(glm::length(glm::vec2(p.x - 7, p.z - 7)) - 2.2f, std::abs(p.y - 6.5f) - 5.5f);
        return std::min(std::max(d.x, d.y), 0.0f) + glm::length(glm::max(d, glm::vec2(0.0f)));
    }));
    // Boulder: two blended spheres.
    add(makeSDF("boulder", 10, [](glm::vec3 p) {
        const float a = glm::length(p - glm::vec3(5, 3.5f, 5)) - 3.2f;
        const float b = glm::length(p - glm::vec3(6.5f, 5, 4.5f)) - 2.2f;
        const float h = std::clamp(0.5f + 0.5f * (b - a) / 1.5f, 0.0f, 1.0f); // smooth union
        return glm::mix(b, a, h) - 1.5f * h * (1.0f - h);
    }));

    // A few simple props to build with straight away (use them from the Assets panel).
    add(makeSDFm("crate", 8, MAT_WOOD, [](glm::vec3 p) { return sdBox(p, glm::vec3(4, 3.5f, 4), glm::vec3(2.5f), 0.6f); }));
    add(makeSDFm("stone_arch", 16, MAT_BRICK, [](glm::vec3 p) {
        const float outer = sdBox(p, glm::vec3(8, 7.5f, 8), glm::vec3(6.5f, 6.5f, 1.6f), 0.4f);
        const float door = std::min(sdBox(p, glm::vec3(8, 4.0f, 8), glm::vec3(3.0f, 4.0f, 3.0f)),
                                    glm::length(glm::vec2(p.x - 8.0f, p.y - 8.0f)) - 3.0f);
        return std::max(outer, -door);
    }));
    add(makeSDFm("steps", 12, MAT_STONE, [](glm::vec3 p) {
        float d = 1e9f;
        for (int i = 0; i < 5; ++i) {
            const float z0 = 1.0f + 2.0f * float(i), z1 = 11.0f, y1 = 1.0f + 1.5f * float(i + 1);
            d = std::min(d, sdBox(p, glm::vec3(6.0f, (1.0f + y1) * 0.5f, (z0 + z1) * 0.5f), glm::vec3(4.0f, (y1 - 1.0f) * 0.5f, (z1 - z0) * 0.5f), 0.2f));
        }
        return d;
    }));
    add(makeSDFm("lamp_post", 12, MAT_METAL, [](glm::vec3 p) {
        const float pole = sdCylY(p, 6.0f, 6.0f, 0.6f, 1.0f, 9.0f);
        const float base = sdCylY(p, 6.0f, 6.0f, 1.3f, 1.0f, 2.2f);
        const float head = glm::length(p - glm::vec3(6.0f, 9.8f, 6.0f)) - 1.5f;
        return std::min(std::min(pole, base), head);
    }));
}

bool PrefabLibrary::saveToFile(const Prefab& p, const std::string& path) {
    std::filesystem::create_directories(std::filesystem::path(path).parent_path());
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    const int32_t size = p.size;
    f.write(kMagic, 4);
    f.write(reinterpret_cast<const char*>(&kVersion), sizeof(kVersion));
    f.write(reinterpret_cast<const char*>(&size), sizeof(size));
    f.write(reinterpret_cast<const char*>(p.grid.data()), std::streamsize(p.grid.size() * sizeof(float)));
    std::vector<MaterialId> mats = p.materials;
    mats.resize(p.grid.size(), MAT_STONE);
    f.write(reinterpret_cast<const char*>(mats.data()), std::streamsize(mats.size()));
    return bool(f);
}

std::shared_ptr<Prefab> PrefabLibrary::loadFromFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return nullptr;
    char magic[4]; uint32_t version = 0; int32_t size = 0;
    f.read(magic, 4);
    f.read(reinterpret_cast<char*>(&version), sizeof(version));
    f.read(reinterpret_cast<char*>(&size), sizeof(size));
    if (!f || std::memcmp(magic, kMagic, 4) != 0 || version < 1 || version > kVersion || size <= 0 || size > kMaxSize) {
        std::cerr << "[Prefab] Rejected " << path << " (bad header)\n";
        return nullptr;
    }
    auto p = std::make_shared<Prefab>();
    p->name = std::filesystem::path(path).stem().string();
    p->size = size;
    p->grid.resize(size_t(size) * size * size);
    f.read(reinterpret_cast<char*>(p->grid.data()), std::streamsize(p->grid.size() * sizeof(float)));
    if (!f) return nullptr;
    if (version >= 2) {
        p->materials.resize(p->grid.size());
        f.read(reinterpret_cast<char*>(p->materials.data()), std::streamsize(p->materials.size()));
        if (!f) return nullptr;
        for (auto& m : p->materials) if (m >= MAT_COUNT) m = MAT_STONE;
    }
    return p;
}

void PrefabLibrary::loadDirectory(const std::string& dir) {
    std::error_code ec;
    if (!std::filesystem::exists(dir, ec)) return;
    for (const auto& e : std::filesystem::directory_iterator(dir, ec))
        if (e.path().extension() == ".vxprefab")
            if (auto p = loadFromFile(e.path().string())) add(p);
}

void PrefabLibrary::add(PrefabPtr p) {
    std::unique_lock lock(mutex);
    prefabs[p->name] = std::move(p);
}

PrefabPtr PrefabLibrary::get(const std::string& name) const {
    std::shared_lock lock(mutex);
    auto it = prefabs.find(name);
    return it == prefabs.end() ? nullptr : it->second;
}

std::vector<std::string> PrefabLibrary::names() const {
    std::shared_lock lock(mutex);
    std::vector<std::string> out;
    for (auto& [n, _] : prefabs) out.push_back(n);
    std::sort(out.begin(), out.end());
    return out;
}

std::vector<PrefabPtr> PrefabLibrary::scatterSet() const {
    std::shared_lock lock(mutex);
    std::vector<PrefabPtr> out;
    for (const char* n : { "stone_pillar", "boulder" })
        if (auto it = prefabs.find(n); it != prefabs.end()) out.push_back(it->second);
    return out;
}

} // namespace px
