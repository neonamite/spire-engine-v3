#pragma once
// Sector-local voxel chunk identity for a future planet-aware chunk registry.
// This does not replace the legacy glm::ivec3 registry yet. A 1024m sector
// contains 32 chunks per edge (32m/chunk). Integer identity remains exact even
// when the global position is too distant to represent as a float or double.
#include "PlanetCoordinates.h"
#include "WorldTypes.h"
#include <cmath>
#include <cstdint>
#include <limits>
#include <glm/glm.hpp>

namespace px {

static_assert(static_cast<int>(WORLD_SECTOR_SIZE) % CHUNK_SIZE == 0,
              "A world sector must contain an integral number of chunks");
inline constexpr int CHUNKS_PER_SECTOR = static_cast<int>(WORLD_SECTOR_SIZE) / CHUNK_SIZE;

struct PlanetChunkAddress {
    SectorCoord sector{};
    std::uint8_t x = 0, y = 0, z = 0;
    friend constexpr bool operator==(const PlanetChunkAddress&, const PlanetChunkAddress&) = default;
};

inline bool validPlanetChunkAddress(const PlanetChunkAddress& a) noexcept {
    return a.x < CHUNKS_PER_SECTOR && a.y < CHUNKS_PER_SECTOR && a.z < CHUNKS_PER_SECTOR;
}

inline bool tryPlanetChunkAddress(const WorldPosition& p, PlanetChunkAddress& out) noexcept {
    if (!p.isCanonical(0.0)) return false;
    PlanetChunkAddress tmp;
    tmp.sector = p.sector;
    tmp.x = static_cast<std::uint8_t>(std::floor(p.local.x / CHUNK_SIZE));
    tmp.y = static_cast<std::uint8_t>(std::floor(p.local.y / CHUNK_SIZE));
    tmp.z = static_cast<std::uint8_t>(std::floor(p.local.z / CHUNK_SIZE));
    if (!validPlanetChunkAddress(tmp)) return false;
    out = tmp;
    return true;
}

// Change a chunk by exactly one cell of the chunk registry on an axis. A
// failed operation leaves the output untouched, including at INT64 limits.
inline bool tryStepPlanetChunk(const PlanetChunkAddress& src, int axis, int dir,
                              PlanetChunkAddress& out) noexcept {
    if (!validPlanetChunkAddress(src) || axis < 0 || axis > 2 || (dir != -1 && dir != 1)) return false;
    PlanetChunkAddress next = src;
    std::uint8_t* local = axis == 0 ? &next.x : axis == 1 ? &next.y : &next.z;
    std::int64_t* sector = axis == 0 ? &next.sector.x : axis == 1 ? &next.sector.y : &next.sector.z;
    if (dir > 0) {
        if (*local + 1 < CHUNKS_PER_SECTOR) ++*local;
        else {
            if (*sector == std::numeric_limits<std::int64_t>::max()) return false;
            ++*sector;
            *local = 0;
        }
    } else {
        if (*local != 0) --*local;
        else {
            if (*sector == std::numeric_limits<std::int64_t>::min()) return false;
            --*sector;
            *local = CHUNKS_PER_SECTOR - 1;
        }
    }
    out = next;
    return true;
}

// True only for objects close enough to the render origin to cast safely to
// 32-bit GPU coordinates. Computes the sector difference before conversion.
inline bool tryChunkOriginRelativeTo(const PlanetChunkAddress& a, const WorldPosition& origin,
                                     glm::vec3& result, double maxDistanceMeters = 100000.0) noexcept {
    // Limit local renderer requests to a sane neighborhood. Computing huge
    // differences in floating point would erase adjacent sectors on MSVC,
    // where long double has only 53 bits of precision.
    if (!validPlanetChunkAddress(a) || !origin.isCanonical(0.0) ||
        !std::isfinite(maxDistanceMeters) || maxDistanceMeters <= 0.0 ||
        maxDistanceMeters > 1.0e9) return false;
    const auto axis = [maxDistanceMeters](std::int64_t sector, std::uint8_t local,
                                         std::int64_t originSector, double originLocal,
                                         float& dest) -> bool {
        const bool negative = sector < originSector;
        // Unsigned subtraction is well defined even for extreme signed sectors.
        // Subtract *before* the cast, so two adjacent sectors beyond 2^53
        // are still exactly one sector apart on MSVC and other compilers.
        const std::uint64_t diff = negative
            ? static_cast<std::uint64_t>(originSector) - static_cast<std::uint64_t>(sector)
            : static_cast<std::uint64_t>(sector) - static_cast<std::uint64_t>(originSector);
        const std::uint64_t allowedSectors =
            static_cast<std::uint64_t>(maxDistanceMeters / WORLD_SECTOR_SIZE) + 2;
        if (diff > allowedSectors) return false;
        const double meters = (negative ? -1.0 : 1.0) * static_cast<double>(diff) *
                              WORLD_SECTOR_SIZE + static_cast<double>(local) * CHUNK_SIZE - originLocal;
        if (!std::isfinite(meters) || std::abs(meters) > maxDistanceMeters) return false;
        dest = static_cast<float>(meters);
        return std::isfinite(dest);
    };
    glm::vec3 local{};
    if (!axis(a.sector.x, a.x, origin.sector.x, origin.local.x, local.x) ||
        !axis(a.sector.y, a.y, origin.sector.y, origin.local.y, local.y) ||
        !axis(a.sector.z, a.z, origin.sector.z, origin.local.z, local.z)) return false;
    result = local;
    return true;
}

} // namespace px
