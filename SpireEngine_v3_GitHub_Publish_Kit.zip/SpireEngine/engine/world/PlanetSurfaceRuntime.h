#pragma once
// C10: CPU-only orbital LOD coordinator. Keeps parent fallback available until
// ALL descendants needed to replace it are ready (no parent/child overdraw).
// All methods except streamer workers are called from the main thread.
#include "PlanetLodSelector.h"
#include "render/PlanetSurfaceDrawPackets.h"
#include <memory>
#include <vector>

namespace px {

class PlanetSurfaceRuntime {
public:
    explicit PlanetSurfaceRuntime(unsigned workers = 2);

    // Explicit initialization is required on planet change. The sampler must be
    // thread-safe, pure, and remain valid until the next configure/destruction.
    bool configure(const PlanetDefinition& planet, PlanetReliefSampler sampler,
                   std::uint16_t resolution = 16, double skirtMeters = 1.0);
    // cameraRelativeToPlanet is DOUBLE precision. planetCenter/camera are sector
    // positions, so draw packets never construct giant absolute float positions.
    bool update(const glm::dvec3& cameraRelativeToPlanet,
                const WorldPosition& planetCenter, const WorldPosition& camera,
                const PlanetLodSettings& lod, double maxDrawOriginDistance,
                std::vector<PlanetSurfaceDrawPacket>& packets);
    PlanetSurfaceStreamStats stats() const { return streamer_.stats(); }
    std::size_t requestedTiles() const { return wanted_.size(); }

private:
    PlanetSurfaceStreamer streamer_;
    PlanetDefinition planet_{};
    bool configured_ = false;
    std::vector<CubeTileCoord> wanted_;
};

} // namespace px
