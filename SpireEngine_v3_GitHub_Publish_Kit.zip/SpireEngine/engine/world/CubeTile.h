#pragma once
// Cube-face tile addresses for a spherified-cube planet grid.
// Face UVs match SpherifiedCube.h: tile +x follows face +u, tile +y follows +v.
// Crossing an edge applies a deterministic remapping onto the adjacent face so
// shared boundary samples agree in 3D. This is addressing only — no meshing.
#include "world/SpherifiedCube.h"
#include <cstdint>

namespace px {

inline constexpr std::uint8_t kMaxCubeTileLevel = 24; // 2^24 tiles/edge fits uint32

enum class TileDir : std::uint8_t {
    East = 0,  // +u / +x
    West = 1,  // -u / -x
    North = 2, // +v / +y
    South = 3  // -v / -y
};

inline constexpr TileDir oppositeTileDir(TileDir d) noexcept {
    switch (d) {
    case TileDir::East: return TileDir::West;
    case TileDir::West: return TileDir::East;
    case TileDir::North: return TileDir::South;
    case TileDir::South: return TileDir::North;
    }
    return TileDir::East;
}

enum class TileError : std::uint8_t {
    Ok = 0,
    InvalidLevel,
    OutOfRange
};

inline constexpr const char* tileErrorMessage(TileError e) noexcept {
    switch (e) {
    case TileError::Ok: return "ok";
    case TileError::InvalidLevel: return "cube tile level out of range";
    case TileError::OutOfRange: return "cube tile index out of range";
    }
    return "unknown tile error";
}

struct CubeTileCoord {
    CubeFace face = CubeFace::PositiveZ;
    std::uint8_t level = 0;
    std::uint32_t x = 0;
    std::uint32_t y = 0;

    friend constexpr bool operator==(const CubeTileCoord&, const CubeTileCoord&) = default;
};

inline constexpr std::uint32_t tilesPerEdge(std::uint8_t level) noexcept {
    return 1u << level;
}

inline TileError validateTile(const CubeTileCoord& t) noexcept {
    if (t.level > kMaxCubeTileLevel) return TileError::InvalidLevel;
    const std::uint32_t n = tilesPerEdge(t.level);
    if (t.x >= n || t.y >= n) return TileError::OutOfRange;
    return TileError::Ok;
}

// Centre of the tile in face UV space [-1, 1].
inline bool tileCenterUv(const CubeTileCoord& t, double& u, double& v) noexcept {
    if (validateTile(t) != TileError::Ok) return false;
    const double n = static_cast<double>(tilesPerEdge(t.level));
    const double step = 2.0 / n;
    u = -1.0 + (static_cast<double>(t.x) + 0.5) * step;
    v = -1.0 + (static_cast<double>(t.y) + 0.5) * step;
    return true;
}

namespace detail {

// How the along-edge index `a` (0..N-1) maps onto the destination face.
enum class EdgeMap : std::uint8_t {
    U_A_V0,       // x'=a,     y'=0
    U_A_VMax,     // x'=a,     y'=N-1
    U_RevA_V0,    // x'=N-1-a, y'=0
    U_RevA_VMax,  // x'=N-1-a, y'=N-1
    V_A_U0,       // x'=0,     y'=a
    V_A_UMax,     // x'=N-1,   y'=a
    V_RevA_U0,    // x'=0,     y'=N-1-a
    V_RevA_UMax   // x'=N-1,   y'=N-1-a
};

struct EdgeCross {
    CubeFace face;
    EdgeMap map;
};

inline CubeTileCoord applyEdgeMap(CubeFace face, std::uint8_t level, std::uint32_t a, EdgeMap map) noexcept {
    const std::uint32_t n = tilesPerEdge(level);
    const std::uint32_t rev = n - 1u - a;
    CubeTileCoord out{face, level, 0, 0};
    switch (map) {
    case EdgeMap::U_A_V0: out.x = a; out.y = 0; break;
    case EdgeMap::U_A_VMax: out.x = a; out.y = n - 1u; break;
    case EdgeMap::U_RevA_V0: out.x = rev; out.y = 0; break;
    case EdgeMap::U_RevA_VMax: out.x = rev; out.y = n - 1u; break;
    case EdgeMap::V_A_U0: out.x = 0; out.y = a; break;
    case EdgeMap::V_A_UMax: out.x = n - 1u; out.y = a; break;
    case EdgeMap::V_RevA_U0: out.x = 0; out.y = rev; break;
    case EdgeMap::V_RevA_UMax: out.x = n - 1u; out.y = rev; break;
    }
    return out;
}

// Adjacency tables derived from SpherifiedCube.h face parametrizations so that
// a sample on the shared edge has the same world-space cube point on both faces.
inline EdgeCross crossTable(CubeFace face, TileDir dir) noexcept {
    using F = CubeFace;
    using M = EdgeMap;
    switch (face) {
    case F::PositiveZ:
        switch (dir) {
        case TileDir::East:  return {F::PositiveX, M::V_A_U0};
        case TileDir::West:  return {F::NegativeX, M::V_A_UMax};
        case TileDir::North: return {F::PositiveY, M::U_A_V0};
        case TileDir::South: return {F::NegativeY, M::U_A_VMax};
        }
        break;
    case F::NegativeZ:
        switch (dir) {
        case TileDir::East:  return {F::NegativeX, M::V_A_U0};
        case TileDir::West:  return {F::PositiveX, M::V_A_UMax};
        case TileDir::North: return {F::PositiveY, M::U_RevA_VMax};
        case TileDir::South: return {F::NegativeY, M::U_RevA_V0};
        }
        break;
    case F::PositiveX:
        switch (dir) {
        case TileDir::East:  return {F::NegativeZ, M::V_A_U0};
        case TileDir::West:  return {F::PositiveZ, M::V_A_UMax};
        case TileDir::North: return {F::PositiveY, M::V_A_UMax};
        case TileDir::South: return {F::NegativeY, M::V_RevA_UMax};
        }
        break;
    case F::NegativeX:
        switch (dir) {
        case TileDir::East:  return {F::PositiveZ, M::V_A_U0};
        case TileDir::West:  return {F::NegativeZ, M::V_A_UMax};
        case TileDir::North: return {F::PositiveY, M::V_RevA_U0};
        case TileDir::South: return {F::NegativeY, M::V_A_U0};
        }
        break;
    case F::PositiveY:
        switch (dir) {
        case TileDir::East:  return {F::PositiveX, M::U_A_VMax};
        case TileDir::West:  return {F::NegativeX, M::U_RevA_VMax};
        case TileDir::North: return {F::NegativeZ, M::U_RevA_VMax};
        case TileDir::South: return {F::PositiveZ, M::U_A_VMax};
        }
        break;
    case F::NegativeY:
        switch (dir) {
        case TileDir::East:  return {F::PositiveX, M::U_RevA_V0};
        case TileDir::West:  return {F::NegativeX, M::U_A_V0};
        case TileDir::North: return {F::PositiveZ, M::U_A_V0};
        case TileDir::South: return {F::NegativeZ, M::U_RevA_V0};
        }
        break;
    }
    return {CubeFace::PositiveZ, EdgeMap::U_A_V0};
}

} // namespace detail

// Step one tile in `dir`. On success, `out` is a valid tile at the same level.
inline TileError tryNeighborTile(const CubeTileCoord& tile, TileDir dir, CubeTileCoord& out) {
    if (const TileError err = validateTile(tile); err != TileError::Ok) return err;

    const std::uint32_t n = tilesPerEdge(tile.level);
    CubeTileCoord next = tile;

    switch (dir) {
    case TileDir::East:
        if (tile.x + 1u < n) { next.x = tile.x + 1u; out = next; return TileError::Ok; }
        break;
    case TileDir::West:
        if (tile.x > 0u) { next.x = tile.x - 1u; out = next; return TileError::Ok; }
        break;
    case TileDir::North:
        if (tile.y + 1u < n) { next.y = tile.y + 1u; out = next; return TileError::Ok; }
        break;
    case TileDir::South:
        if (tile.y > 0u) { next.y = tile.y - 1u; out = next; return TileError::Ok; }
        break;
    }

    const detail::EdgeCross cross = detail::crossTable(tile.face, dir);
    const std::uint32_t along = (dir == TileDir::East || dir == TileDir::West) ? tile.y : tile.x;
    out = detail::applyEdgeMap(cross.face, tile.level, along, cross.map);
    return TileError::Ok;
}

// True when some step from the neighbor returns to `tile`.
// After a face cross, the return direction is not always oppositeTileDir(dir)
// because UV axes can flip which edge was entered.
inline bool neighborIsReciprocal(const CubeTileCoord& tile, TileDir dir) {
    CubeTileCoord a{};
    if (tryNeighborTile(tile, dir, a) != TileError::Ok) return false;
    const TileDir backCandidates[] = {TileDir::East, TileDir::West, TileDir::North, TileDir::South};
    for (TileDir back : backCandidates) {
        CubeTileCoord b{};
        if (tryNeighborTile(a, back, b) == TileError::Ok && b == tile) return true;
    }
    return false;
}

} // namespace px
