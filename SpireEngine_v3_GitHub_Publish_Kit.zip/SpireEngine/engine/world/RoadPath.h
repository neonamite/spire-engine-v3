#pragma once
// Reusable flat-world road stamping path. A deliberately bounded sequence of
// sample centers; the caller owns voxel edits and project persistence.
#include <algorithm>
#include <cmath>
#include <vector>
#include <glm/glm.hpp>
namespace px {
struct RoadSample { glm::vec3 center; float flattenRadius; float paintRadius; };
inline std::vector<RoadSample> buildRoadSamples(const glm::vec3& start,
                                                const glm::vec3& end,
                                                float requestedWidth) {
    if (!std::isfinite(start.x) || !std::isfinite(start.y) || !std::isfinite(start.z) ||
        !std::isfinite(end.x) || !std::isfinite(end.y) || !std::isfinite(end.z) ||
        !std::isfinite(requestedWidth)) return {};
    const glm::vec3 delta = end - start;
    const float length = std::hypot(delta.x, delta.z);
    if (!std::isfinite(length) || length < 1.0f || length > 160.0f) return {};
    const float width = std::clamp(requestedWidth, 2.0f, 16.0f);
    const int steps = std::max(1, int(std::ceil(length / std::max(1.0f, width * 0.65f))));
    std::vector<RoadSample> samples;
    samples.reserve(static_cast<std::size_t>(steps + 1));
    for (int i = 0; i <= steps; ++i) {
        const float t = float(i) / float(steps);
        samples.push_back({start + delta * t, width * 0.60f, width * 0.52f});
    }
    return samples;
}
} // namespace px
