#include "ChunkManager.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>

namespace px {

ChunkManager::ChunkManager(PrefabLibrary& prefabs)
    : prefabLib(prefabs), generator(std::make_shared<TerrainGenerator>(TerrainSettings{})) {}

ChunkManager::~ChunkManager() { stop(); }

void ChunkManager::launchWorkers(unsigned workerCount) {
    if (workerCount == 0) workerCount = std::max(1u, std::thread::hardware_concurrency() > 2 ? std::thread::hardware_concurrency() - 2 : 1u);
    running = true;
    for (unsigned i = 0; i < workerCount; ++i) workers.emplace_back(&ChunkManager::workerLoop, this);
}

void ChunkManager::leavePlanetaryPrototype() {
    if (!planetaryProvider) return;
    planetaryProvider.reset();
    editLog.clear();
    redoStack.clear();
    if (haveFlatEditBackup) {
        editLog = std::move(savedFlatEdits);
        redoStack = std::move(savedFlatRedo);
        haveFlatEditBackup = false;
    }
    ++rev;
}

glm::vec3 ChunkManager::localUp(const glm::vec3& position) const noexcept {
    if (!planetaryProvider) return {0.0f, 1.0f, 0.0f};
    const glm::dvec3 direction(position);
    const double length = glm::length(direction);
    if (length <= 1e-9) return {0.0f, 1.0f, 0.0f};
    return glm::vec3(direction / length);
}

void ChunkManager::start(const TerrainSettings& s, unsigned workerCount) {
    stop();
    leavePlanetaryPrototype();
    generator = std::make_shared<TerrainGenerator>(s);
    ++worldGeneration;
    activeChunks.clear();
    pending.clear();
    launchWorkers(workerCount);
}

void ChunkManager::startPlanetaryPrototype(const PlanetaryTerrainSettings& s, unsigned workerCount) {
    if (!s.planet.valid() || !std::isfinite(s.caveFrequency) || !std::isfinite(s.caveAmplitude) ||
        !std::isfinite(s.hillFrequency) || s.caveAmplitude < 0.0f || s.caveFrequency < 0.0f ||
        s.hillFrequency < 0.0f)
        throw std::invalid_argument("invalid planetary terrain settings");
    stop();
    if (!planetaryProvider) {
        savedFlatEdits = std::move(editLog);
        savedFlatRedo = std::move(redoStack);
        haveFlatEditBackup = true;
    }
    editLog.clear();
    redoStack.clear();
    planetaryProvider = std::make_shared<PlanetaryTerrainProvider>(s);
    ++worldGeneration;
    activeChunks.clear();
    pending.clear();
    launchWorkers(workerCount);
}

bool ChunkManager::clearPlanetEdits() {
    if (!planetaryProvider) return false;
    const PlanetaryTerrainSettings settings = planetaryProvider->settings;
    startPlanetaryPrototype(settings);
    ++rev;
    return true;
}

void ChunkManager::stop() {
    if (!running.exchange(false)) return;
    jobCv.notify_all();
    for (auto& t : workers) if (t.joinable()) t.join();
    workers.clear();
    jobs.clear();
    results.clear();
    pending.clear();
}

// ---------------------------------------------------------------- streaming

bool ChunkManager::inRange(const glm::ivec3& c, const glm::ivec3& center) const {
    const std::int64_t dx = std::int64_t(c.x) - center.x;
    const std::int64_t dz = std::int64_t(c.z) - center.z;
    if (planetaryProvider) {
        const std::int64_t dy = std::int64_t(c.y) - center.y;
        const auto r = std::clamp(planetLoadRadius, 1, 4) + 1;
        return dx * dx + dy * dy + dz * dz <= r * r;
    }
    const auto r = std::max(0, loadRadius) + 1;
    return dx * dx + dz * dz <= std::int64_t(r) * r && c.y >= minChunkY && c.y <= maxChunkY;
}

void ChunkManager::update(const glm::vec3& cameraPos) {
    const glm::ivec3 cc = worldToChunk(cameraPos);
    camChunkX = cc.x; camChunkY = cc.y; camChunkZ = cc.z;

    // 1. Queue missing chunks inside the load radius.
    std::vector<Job> newJobs;
    if (planetaryProvider) {
        // Load a small 3D neighborhood of world-space voxel chunks around the
        // camera. Six-face cube-tile quadtree streaming replaces this later;
        // keeping this mode separate preserves all legacy X/Z scheduling.
        const int r = std::clamp(planetLoadRadius, 1, 4);
        for (int z = -r; z <= r; ++z)
            for (int y = -r; y <= r; ++y)
                for (int x = -r; x <= r; ++x) {
                    if (x * x + y * y + z * z > r * r) continue;
                    const glm::ivec3 c = cc + glm::ivec3(x, y, z);
                    if (activeChunks.count(c) || pending.count(c)) continue;
                    pending.insert(c);
                    newJobs.push_back(makeJob(c));
                }
    } else {
        for (int z = -loadRadius; z <= loadRadius; ++z)
            for (int x = -loadRadius; x <= loadRadius; ++x) {
                if (x * x + z * z > loadRadius * loadRadius) continue;
                for (int y = minChunkY; y <= maxChunkY; ++y) {
                    const glm::ivec3 c(cc.x + x, y, cc.z + z);
                    if (activeChunks.count(c) || pending.count(c)) continue;
                    pending.insert(c);
                    newJobs.push_back(makeJob(c));
                }
            }
    }
    if (!newJobs.empty()) {
        std::lock_guard lock(jobMutex);
        for (auto& j : newJobs) jobs.push_back(std::move(j));
        jobCv.notify_all();
    }

    // 2. Collect finished chunks.
    std::vector<Result> done;
    {
        std::lock_guard lock(resultMutex);
        done.swap(results);
    }
    for (auto& r : done) {
        const glm::ivec3 c = r.chunk->coord;
        if (r.generation != worldGeneration) continue;          // stale (settings changed)
        pending.erase(c);
        if (r.editEpoch != editEpoch) continue;                  // built before an undo; re-queued next frame
        if (!inRange(c, cc)) continue;                           // flew away meanwhile
        // Replay edits made while this chunk was being built.
        bool dirty = false;
        for (size_t i = r.editCountAtSnapshot; i < editLog.size(); ++i)
            if (r.chunk->overlaps(editLog[i].boundsMin, editLog[i].boundsMax)) { applyEdit(*r.chunk, editLog[i]); dirty = true; }
        if (dirty) r.chunk->buildMesh();
        activeChunks[c] = std::move(r.chunk);
    }

    // 3. Unload chunks that fell outside the radius.
    for (auto it = activeChunks.begin(); it != activeChunks.end();)
        it = inRange(it->first, cc) ? std::next(it) : activeChunks.erase(it);
    {
        std::lock_guard lock(jobMutex);
        for (auto it = jobs.begin(); it != jobs.end();) {
            if (!inRange(it->coord, cc)) { pending.erase(it->coord); it = jobs.erase(it); }
            else ++it;
        }
    }
}

ChunkManager::Job ChunkManager::makeJob(const glm::ivec3& c) const {
    Job job{ c, worldGeneration, generator, planetaryProvider,
             !planetaryProvider && generator->settings.scatterProps ? prefabLib.scatterSet() : std::vector<PrefabPtr>{},
             {}, editLog.size(), editEpoch };
    const VoxelChunk probe(c);
    for (const auto& op : editLog)
        if (probe.overlaps(op.boundsMin, op.boundsMax)) job.edits.push_back(op);
    return job;
}

void ChunkManager::workerLoop() {
    while (running) {
        Job job;
        {
            std::unique_lock lock(jobMutex);
            jobCv.wait(lock, [&] { return !running || !jobs.empty(); });
            if (!running) return;
            // Nearest-first so the area around the player fills in before the horizon.
            const glm::ivec3 cam(camChunkX.load(), camChunkY.load(), camChunkZ.load());
            auto best = std::min_element(jobs.begin(), jobs.end(), [&](const Job& a, const Job& b) {
                const auto distSq = [&](const glm::ivec3& c) {
                    const std::int64_t x = std::int64_t(c.x) - cam.x;
                    const std::int64_t y = std::int64_t(c.y) - cam.y;
                    const std::int64_t z = std::int64_t(c.z) - cam.z;
                    return x*x + y*y + z*z;
                };
                return distSq(a.coord) < distSq(b.coord);
            });
            job = std::move(*best);
            jobs.erase(best);
        }
        auto chunk = std::make_unique<VoxelChunk>(job.coord);
        buildChunk(*chunk, job);
        std::lock_guard lock(resultMutex);
        results.push_back({ std::move(chunk), job.generation, job.editCountAtSnapshot, job.editEpoch });
    }
}

void ChunkManager::buildChunk(VoxelChunk& c, const Job& job) {
    if (job.planetGen) c.generate(*job.planetGen);
    else c.generate(*job.gen);

    // Deterministic scatter: every 16x16 column cell decides for itself whether it
    // owns a prop. Each chunk checks the cells around it too, so props that hang
    // over a chunk border are stamped into both sides and never get sliced.
    if (!job.scatter.empty()) {
        const auto& s = job.gen->settings;
        const int cell = 16, margin = 32;
        const glm::ivec3 o = c.origin();
        const float top = s.baseHeight + s.hillAmplitude + s.caveAmplitude + 4.0f;
        for (int cz = floorDiv(o.z - margin, cell); cz <= floorDiv(o.z + CHUNK_SIZE + margin, cell); ++cz)
            for (int cx = floorDiv(o.x - margin, cell); cx <= floorDiv(o.x + CHUNK_SIZE + margin, cell); ++cx) {
                if (hash01(cx, cz, s.seed) > s.scatterChance) continue;
                const float px = cx * cell + hash01(cx, cz, s.seed + 1) * cell;
                const float pz = cz * cell + hash01(cx, cz, s.seed + 2) * cell;
                const auto& prefab = job.scatter[size_t(hash01(cx, cz, s.seed + 3) * job.scatter.size()) % job.scatter.size()];
                const float gy = job.gen->findGround(px, pz, top, 0.0f);
                if (gy <= 1.0f) continue;
                const glm::ivec3 mn = prefab->minCornerFor({ px, gy, pz });
                if (c.overlaps(glm::vec3(mn), glm::vec3(mn + prefab->size)))
                    c.unionGrid(mn, prefab->size, prefab->grid, prefab->materials);
            }
    }

    for (const auto& op : job.edits) applyEdit(c, op);
    c.buildMesh();
}

// ---------------------------------------------------------------- edits

bool ChunkManager::applyEdit(VoxelChunk& c, const EditOp& op) {
    switch (op.kind) {
    case EditOp::Kind::Sphere:  return c.applySphere(op.center, op.radius, op.mode, op.material);
    case EditOp::Kind::Flatten: return c.applyFlatten(op.center, op.radius);
    case EditOp::Kind::Paint:   return c.applyPaint(op.center, op.radius, op.material);
    case EditOp::Kind::Smooth:  return op.delta && c.addDelta(*op.delta);
    case EditOp::Kind::Stamp:
        return op.prefab && c.unionGrid(op.prefab->minCornerFor(op.center), op.prefab->size, op.prefab->grid, op.prefab->materials);
    }
    return false;
}

void ChunkManager::setBounds(EditOp& op) {
    if (op.kind == EditOp::Kind::Stamp && op.prefab) {
        op.boundsMin = glm::vec3(op.prefab->minCornerFor(op.center));
        op.boundsMax = op.boundsMin + glm::vec3(float(op.prefab->size));
    } else if (op.kind == EditOp::Kind::Smooth && op.delta) {
        op.boundsMin = glm::vec3(op.delta->min);
        op.boundsMax = glm::vec3(op.delta->min + op.delta->size);
    } else {
        op.boundsMin = op.center - glm::vec3(op.radius + 1.0f);
        op.boundsMax = op.center + glm::vec3(op.radius + 1.0f);
    }
}

bool ChunkManager::recordAndApply(EditOp op, bool clearRedo) {
    bool changed = false;
    for (auto& [coord, chunk] : activeChunks)
        if (chunk->overlaps(op.boundsMin, op.boundsMax) && applyEdit(*chunk, op)) {
            chunk->buildMesh();
            changed = true;
        }
    // Edits that change nothing (painting the same spot twice, a brush held
    // still) aren't recorded, so they don't fill up the undo history.
    if (!changed && clearRedo) return false;
    if (clearRedo) redoStack.clear();
    editLog.push_back(std::move(op));
    ++rev;
    if (clearRedo && onEdit) onEdit(editLog.back());
    return true;
}

void ChunkManager::applySphere(const glm::vec3& center, float radius, CsgMode mode, MaterialId material) {
    EditOp op;
    op.kind = EditOp::Kind::Sphere; op.center = center; op.radius = radius; op.mode = mode; op.material = material;
    setBounds(op);
    recordAndApply(std::move(op));
}

void ChunkManager::flatten(const glm::vec3& center, float radius) {
    EditOp op;
    op.kind = EditOp::Kind::Flatten; op.center = center; op.radius = radius;
    setBounds(op);
    recordAndApply(std::move(op));
}

void ChunkManager::paint(const glm::vec3& center, float radius, MaterialId material) {
    EditOp op;
    op.kind = EditOp::Kind::Paint; op.center = center; op.radius = radius; op.material = material;
    setBounds(op);
    recordAndApply(std::move(op));
}

bool ChunkManager::smooth(const glm::vec3& center, float radius, float strength) {
    // The blur needs neighbouring samples, which a chunk rebuilt on a worker
    // thread can't see across its border. So the result is computed once here
    // from the live world and stored as density offsets; replaying those is
    // exact in every chunk, in any order.
    const int R = int(std::ceil(radius)) + 1;
    const glm::ivec3 mn = glm::ivec3(glm::floor(center)) - glm::ivec3(R);
    const int n = 2 * R + 2;
    const int m = n + 2;                                   // with a 1-sample border for the blur
    std::vector<float> src(size_t(m) * m * m);
    for (int z = 0; z < m; ++z)
        for (int y = 0; y < m; ++y)
            for (int x = 0; x < m; ++x)
                src[size_t(x + y * m + z * m * m)] = sampleGrid(mn.x + x - 1, mn.y + y - 1, mn.z + z - 1);

    auto g = std::make_shared<DeltaGrid>();
    g->min = mn; g->size = n;
    strength = std::clamp(strength, 0.0f, 1.0f);
    for (int z = 0; z < n; ++z)
        for (int y = 0; y < n; ++y)
            for (int x = 0; x < n; ++x) {
                const float dist = glm::length(glm::vec3(mn + glm::ivec3(x, y, z)) - center);
                const float w = glm::smoothstep(radius, radius * 0.35f, dist) * strength;
                if (w <= 0.0f) continue;
                float sum = 0.0f;
                for (int k = -1; k <= 1; ++k)
                    for (int j = -1; j <= 1; ++j)
                        for (int i = -1; i <= 1; ++i)
                            sum += src[size_t((x + 1 + i) + (y + 1 + j) * m + (z + 1 + k) * m * m)];
                const float d = src[size_t((x + 1) + (y + 1) * m + (z + 1) * m * m)];
                // Quantised to 1/4096 so a saved world replays bit-for-bit.
                const float delta = std::round(std::clamp((sum / 27.0f - d) * w, -7.99f, 7.99f) * 4096.0f) / 4096.0f;
                if (delta == 0.0f) continue;
                g->index.push_back(std::uint32_t(x + y * n + z * n * n));
                g->value.push_back(delta);
            }
    if (g->index.empty()) return false;

    EditOp op;
    op.kind = EditOp::Kind::Smooth; op.center = center; op.radius = radius; op.strength = strength;
    op.delta = std::move(g);
    setBounds(op);
    return recordAndApply(std::move(op));
}

bool ChunkManager::undo() {
    if (editLog.empty()) return false;
    EditOp op = std::move(editLog.back());
    editLog.pop_back();
    ++editEpoch;
    ++rev;
    // Chunks still being built include the undone edit; drop their pending
    // flag so they get requested again with the corrected edit list.
    rebuildRegion(op.boundsMin, op.boundsMax);
    redoStack.push_back(std::move(op));
    return true;
}

bool ChunkManager::redo() {
    if (redoStack.empty()) return false;
    EditOp op = std::move(redoStack.back());
    redoStack.pop_back();
    recordAndApply(std::move(op), false);
    return true;
}

void ChunkManager::rebuildRegion(const glm::vec3& mn, const glm::vec3& mx) {
    // Edits can't be "subtracted" back out, so rebuild the touched chunks from
    // the generator and replay the remaining edit log. Synchronous: an edit only
    // touches a handful of chunks.
    for (auto& [coord, chunk] : activeChunks) {
        if (!chunk->overlaps(mn, mx)) continue;
        const Job job = makeJob(coord);
        auto fresh = std::make_unique<VoxelChunk>(coord);
        buildChunk(*fresh, job);
        fresh->meshVersion = chunk->meshVersion + 1;
        chunk = std::move(fresh);
    }
}

bool ChunkManager::stamp(const std::string& prefabName, const glm::vec3& anchor) {
    auto p = prefabLib.get(prefabName);
    if (!p) return false;
    EditOp op;
    op.kind = EditOp::Kind::Stamp; op.center = anchor; op.prefab = p;
    setBounds(op);
    recordAndApply(std::move(op));
    return true;
}

void ChunkManager::clearEdits() {
    editLog.clear();
    redoStack.clear();
    setSettings(generator->settings);
}

std::shared_ptr<Prefab> ChunkManager::bake(const glm::vec3& center, int radius, const std::string& name) const {
    auto p = std::make_shared<Prefab>();
    p->name = name;
    p->size = radius * 2;
    p->grid.resize(size_t(p->size) * p->size * p->size);
    p->materials.resize(p->grid.size());
    // Anchor convention matches Prefab::minCornerFor: bottom-centre at `center`.
    const glm::ivec3 mn(int(std::floor(center.x)) - radius, int(std::floor(center.y)) - 1, int(std::floor(center.z)) - radius);
    for (int z = 0; z < p->size; ++z)
        for (int y = 0; y < p->size; ++y)
            for (int x = 0; x < p->size; ++x) {
                const size_t i = size_t(x + y * p->size + z * p->size * p->size);
                p->grid[i] = sampleGrid(mn.x + x, mn.y + y, mn.z + z);
                p->materials[i] = sampleMaterial(mn.x + x, mn.y + y, mn.z + z);
            }
    return p;
}

void ChunkManager::setSettings(const TerrainSettings& s) {
    ++rev;
    leavePlanetaryPrototype(); // applying flat settings explicitly exits planet prototype
    generator = std::make_shared<TerrainGenerator>(s);
    ++worldGeneration;
    activeChunks.clear();
    pending.clear();
    std::lock_guard lock(jobMutex);
    jobs.clear();
}

// ---------------------------------------------------------------- queries

float ChunkManager::sampleGrid(int x, int y, int z) const {
    const glm::ivec3 c(floorDiv(x, CHUNK_SIZE), floorDiv(y, CHUNK_SIZE), floorDiv(z, CHUNK_SIZE));
    auto it = activeChunks.find(c);
    if (it == activeChunks.end()) return 1.0f;
    const glm::ivec3 l = glm::ivec3(x, y, z) - c * CHUNK_SIZE;
    return it->second->sample(l.x, l.y, l.z);
}

MaterialId ChunkManager::sampleMaterial(int x, int y, int z) const {
    const glm::ivec3 c(floorDiv(x, CHUNK_SIZE), floorDiv(y, CHUNK_SIZE), floorDiv(z, CHUNK_SIZE));
    auto it = activeChunks.find(c);
    if (it == activeChunks.end()) return MAT_NATURAL;
    const glm::ivec3 l = glm::ivec3(x, y, z) - c * CHUNK_SIZE;
    return it->second->materialAt(l.x, l.y, l.z);
}

MaterialId ChunkManager::materialAt(const glm::vec3& p) const {
    return sampleMaterial(int(std::round(p.x)), int(std::round(p.y)), int(std::round(p.z)));
}

MaterialId ChunkManager::surfaceMaterialAt(const glm::vec3& p) const {
    // Walk down to the first solid point, then ask what the surface there is made of.
    for (float t = 0.0f; t <= 2.0f; t += 0.25f) {
        const glm::vec3 q = p - localUp(p) * t;
        if (!isLoaded(q)) return MAT_NATURAL;
        if (density(q) >= 0.0f) continue;
        const glm::vec3 n = densityGradient(q);
        const MaterialId m = materialAt(q - n * 0.7f);
        if (m != MAT_NATURAL) return m;
        if (planetaryProvider) return MAT_STONE; // radial worlds use explicit materials
        const auto& st = generator->settings;
        return resolveNatural(q, n, sandLevelFor(st), snowLevelFor(st));
    }
    return MAT_NATURAL;
}

float ChunkManager::density(const glm::vec3& p) const {
    const glm::ivec3 b(int(std::floor(p.x)), int(std::floor(p.y)), int(std::floor(p.z)));
    const glm::vec3 f = p - glm::vec3(b);
    float v[8];
    for (int i = 0; i < 8; ++i) v[i] = sampleGrid(b.x + (i & 1), b.y + ((i >> 1) & 1), b.z + ((i >> 2) & 1));
    const float x00 = glm::mix(v[0], v[1], f.x), x10 = glm::mix(v[2], v[3], f.x);
    const float x01 = glm::mix(v[4], v[5], f.x), x11 = glm::mix(v[6], v[7], f.x);
    return glm::mix(glm::mix(x00, x10, f.y), glm::mix(x01, x11, f.y), f.z);
}

glm::vec3 ChunkManager::densityGradient(const glm::vec3& p) const {
    const float e = 0.5f;
    glm::vec3 g(density(p + glm::vec3(e, 0, 0)) - density(p - glm::vec3(e, 0, 0)),
                density(p + glm::vec3(0, e, 0)) - density(p - glm::vec3(0, e, 0)),
                density(p + glm::vec3(0, 0, e)) - density(p - glm::vec3(0, 0, e)));
    const float len = glm::length(g);
    return len > 1e-5f ? g / len : glm::vec3(0, 1, 0);
}

bool ChunkManager::isLoaded(const glm::vec3& p) const {
    return activeChunks.count(worldToChunk(p)) > 0;
}

bool ChunkManager::raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist, RayHit& hit) const {
    const glm::vec3 d = glm::normalize(dir);
    const float step = 0.25f;
    float prevT = 0.0f;
    if (density(origin) < 0.0f) return false; // started inside rock
    for (float t = step; t <= maxDist; t += step) {
        const float cur = density(origin + d * t);
        if (cur < 0.0f) {
            // Binary-search the exact surface crossing.
            float lo = prevT, hi = t;
            for (int i = 0; i < 8; ++i) {
                const float mid = 0.5f * (lo + hi);
                (density(origin + d * mid) < 0.0f ? hi : lo) = mid;
            }
            hit.distance = hi;
            hit.position = origin + d * hi;
            hit.normal = densityGradient(hit.position);
            return true;
        }
        prevT = t;
    }
    return false;
}

// ---------------------------------------------------------------- save / load

namespace {
constexpr char kWorldMagic[4] = { 'V', 'X', 'W', 'D' };
constexpr uint32_t kWorldVersion = 3;   // v2: materials, paint, smooth. v3: sea level (older files still load)
// Terrain settings as saved by versions 1 and 2 (before sea level existed).
struct LegacyTerrainSettings {
    std::uint32_t seed; float baseHeight, hillFrequency, hillAmplitude, caveFrequency, caveAmplitude, scatterChance; bool scatterProps;
};
template <class T> void put(std::ofstream& f, const T& v) { f.write(reinterpret_cast<const char*>(&v), sizeof(T)); }
template <class T> bool get(std::ifstream& f, T& v) { f.read(reinterpret_cast<char*>(&v), sizeof(T)); return bool(f); }
}

bool ChunkManager::saveWorld(const std::string& path) const {
    // Planet persistence requires a versioned format with a planet identity.
    // Do not mislabel a spherical scene as a v1.6 flat .vxworld save.
    if (planetaryProvider) return false;
    // Written next to the target and renamed into place, so a crash or a full disk in the middle
    // of saving can never leave a half-written world where the good one was.
    std::filesystem::create_directories(std::filesystem::path(path).parent_path());
    const std::string tmpPath = path + ".tmp";
    {
    std::ofstream f(tmpPath, std::ios::binary);
    if (!f) return false;
    f.write(kWorldMagic, 4);
    put(f, kWorldVersion);
    put(f, generator->settings);
    put(f, uint32_t(editLog.size()));
    for (const auto& op : editLog) {
        put(f, op.kind); put(f, op.center); put(f, op.radius); put(f, op.mode);
        put(f, op.material); put(f, op.strength);
        const std::string name = op.prefab ? op.prefab->name : std::string();
        put(f, uint32_t(name.size()));
        f.write(name.data(), std::streamsize(name.size()));
        if (op.kind == EditOp::Kind::Smooth) {
            const DeltaGrid& g = *op.delta;
            put(f, g.min); put(f, int32_t(g.size)); put(f, uint32_t(g.index.size()));
            for (size_t i = 0; i < g.index.size(); ++i) {
                put(f, g.index[i]);
                put(f, int16_t(std::lround(g.value[i] * 4096.0f)));
            }
        }
    }
    if (!extra.empty()) {                       // optional trailer: older versions stop reading before it
        f.write("VXEX", 4);
        put(f, uint32_t(extra.size()));
        f.write(extra.data(), std::streamsize(extra.size()));
    }
    f.flush();
    if (!f) { f.close(); std::error_code ec; std::filesystem::remove(tmpPath, ec); return false; }
    }
    std::error_code ec;
    std::filesystem::rename(tmpPath, path, ec);
    if (ec) { std::filesystem::remove(tmpPath, ec); return false; }
    return true;
}

bool ChunkManager::loadWorld(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    char magic[4]; uint32_t version = 0, count = 0;
    TerrainSettings s;
    f.read(magic, 4);
    if (!f || std::memcmp(magic, kWorldMagic, 4) != 0 || !get(f, version) || version < 1 || version > kWorldVersion) return false;
    if (version >= 3) {
        if (!get(f, s)) return false;
    } else {
        LegacyTerrainSettings old{};
        if (!get(f, old)) return false;
        s.seed = old.seed; s.baseHeight = old.baseHeight; s.hillFrequency = old.hillFrequency; s.hillAmplitude = old.hillAmplitude;
        s.caveFrequency = old.caveFrequency; s.caveAmplitude = old.caveAmplitude; s.scatterChance = old.scatterChance; s.scatterProps = old.scatterProps;
        s.water = false;     // old worlds keep their old look (and their old sand line)
    }
    if (!get(f, count)) return false;

    std::vector<EditOp> ops;
    for (uint32_t i = 0; i < count; ++i) {
        EditOp op; uint32_t len = 0;
        if (!get(f, op.kind) || !get(f, op.center) || !get(f, op.radius) || !get(f, op.mode)) return false;
        if (version >= 2 && (!get(f, op.material) || !get(f, op.strength))) return false;
        if (op.kind > EditOp::Kind::Smooth || op.material >= MAT_COUNT) return false;
        if (!get(f, len) || len > 256) return false;
        std::string name(len, '\0');
        f.read(name.data(), len);
        if (op.kind == EditOp::Kind::Smooth) {
            auto g = std::make_shared<DeltaGrid>();
            int32_t size = 0; uint32_t n = 0;
            if (!get(f, g->min) || !get(f, size) || !get(f, n) || size <= 0 || size > 128 || n > uint32_t(size) * size * size) return false;
            g->size = size;
            g->index.resize(n); g->value.resize(n);
            for (uint32_t k = 0; k < n; ++k) {
                int16_t q = 0;
                if (!get(f, g->index[k]) || !get(f, q) || g->index[k] >= uint32_t(size) * size * size) return false;
                g->value[k] = float(q) / 4096.0f;
            }
            op.delta = std::move(g);
        } else if (op.kind == EditOp::Kind::Stamp) {
            op.prefab = prefabLib.get(name);
            if (!op.prefab) { std::cerr << "[World] Missing prefab '" << name << "', skipping stamp\n"; continue; }
        }
        setBounds(op);
        ops.push_back(std::move(op));
    }
    std::string blob;
    char tag[4];
    if (f.read(tag, 4) && std::memcmp(tag, "VXEX", 4) == 0) {
        uint32_t len = 0;
        if (get(f, len) && len <= (64u << 20)) {
            blob.resize(len);
            f.read(blob.data(), std::streamsize(len));
            if (!f) blob.clear();
        }
    }
    // Loading a legacy save explicitly replaces the current world, including
    // any temporary planet edits and the old flat-world backup.
    planetaryProvider.reset();
    savedFlatEdits.clear();
    savedFlatRedo.clear();
    haveFlatEditBackup = false;
    editLog = std::move(ops);
    redoStack.clear();
    extra = std::move(blob);
    setSettings(s);
    return true;
}

} // namespace px
