#pragma once
// CPU-side asynchronous quadtree surface-mesh streamer. The OpenGL renderer
// remains main-thread-only; completed meshes are immutable and have DOUBLE
// precision origins suitable for camera-relative GPU upload.
//
// Threading: one owner thread calls setSelection()/collect()/findReady(). Worker
// threads only access snapshots and the synchronized job/result queues.
// Samplers must be pure and safe to invoke on multiple worker threads.
#include "PlanetSurfacePatch.h"
#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace px {

struct CubeTileHash {
    std::size_t operator()(const CubeTileCoord& t) const noexcept {
        std::uint64_t k = (static_cast<std::uint64_t>(static_cast<unsigned>(t.face)) << 56) |
            (static_cast<std::uint64_t>(t.level) << 48) |
            (static_cast<std::uint64_t>(t.x) << 24) | t.y;
        k ^= k >> 33; k *= 0xff51afd7ed558ccdULL;
        k ^= k >> 33; k *= 0xc4ceb9fe1a85ec53ULL;
        k ^= k >> 33;
        return static_cast<std::size_t>(k);
    }
};

struct PlanetSurfaceStreamStats {
    std::size_t wanted = 0;
    std::size_t ready = 0;
    std::size_t pending = 0;
    std::size_t queued = 0;
    std::size_t completedWaiting = 0;
    std::uint64_t generated = 0;
    std::uint64_t discarded = 0;
    std::uint64_t failed = 0;
};

class PlanetSurfaceStreamer {
public:
    // maxBuffered: cap on completed meshes waiting for main-thread collection.
    explicit PlanetSurfaceStreamer(unsigned workerCount = 2, std::size_t maxBuffered = 8);
    ~PlanetSurfaceStreamer();
    PlanetSurfaceStreamer(const PlanetSurfaceStreamer&) = delete;
    PlanetSurfaceStreamer& operator=(const PlanetSurfaceStreamer&) = delete;

    // Reconfiguration invalidates every queued and completed mesh, retaining
    // immutable snapshots for in-flight jobs. An invalid request changes nothing.
    bool configure(const PlanetDefinition& planet, std::uint16_t resolution,
                   double skirtDepthMeters, PlanetReliefSampler sampler);

    // `tiles` is the desired complete draw selection, prioritized in input
    // order (first tiles generated first). Rejects invalid/duplicate entries.
    // Selection churn does not invalidate already-generated matching tiles.
    bool setSelection(const std::vector<CubeTileCoord>& tiles);

    // Called on owner/render thread; collects at most maxCount completed jobs.
    // No OpenGL calls occur here. Returns number of accepted new patches.
    std::size_t collect(std::size_t maxCount = 8);
    std::shared_ptr<const PlanetSurfacePatch> findReady(const CubeTileCoord& tile) const;
    std::vector<CubeTileCoord> readyTiles() const;
    PlanetSurfaceStreamStats stats() const;

private:
    struct Config {
        PlanetDefinition planet;
        std::uint16_t resolution = 0;
        double skirt = 0.0;
        PlanetReliefSampler sampler;
    };
    struct Job {
        CubeTileCoord tile;
        std::uint64_t epoch = 0;
        std::shared_ptr<const Config> config;
    };
    struct Result {
        CubeTileCoord tile;
        std::uint64_t epoch = 0;
        std::shared_ptr<const PlanetSurfacePatch> patch;
    };
    void workerLoop();
    mutable std::mutex mutex_;
    std::condition_variable wake_;
    std::vector<std::thread> threads_;
    const std::size_t maxBuffered_;
    bool stopping_ = false;
    std::uint64_t epoch_ = 0;
    std::shared_ptr<const Config> config_;
    std::deque<Job> jobs_;
    std::deque<Result> completed_;
    std::unordered_set<CubeTileCoord, CubeTileHash> desired_;
    std::unordered_set<CubeTileCoord, CubeTileHash> pending_;
    std::unordered_map<CubeTileCoord, std::shared_ptr<const PlanetSurfacePatch>, CubeTileHash> ready_;
    std::uint64_t generated_ = 0, discarded_ = 0, failed_ = 0;
};

} // namespace px
