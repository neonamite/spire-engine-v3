#include "DualContouring.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace px {
namespace {
constexpr std::array<glm::ivec3,8> corners{{{0,0,0},{1,0,0},{0,1,0},{1,1,0},
                                              {0,0,1},{1,0,1},{0,1,1},{1,1,1}}};
constexpr std::array<std::array<int,2>,12> edges{{{{0,1}},{{2,3}},{{4,5}},{{6,7}},
                                                   {{0,2}},{{1,3}},{{4,6}},{{5,7}},
                                                   {{0,4}},{{1,5}},{{2,6}},{{3,7}}}};
bool finite(const glm::dvec3& p) { return std::isfinite(p.x)&&std::isfinite(p.y)&&std::isfinite(p.z); }
struct Hermite { glm::dvec3 point, normal; };
// Gaussian elimination, partial pivot; returns false if system singular.
bool solve3x3(double a[3][4], glm::dvec3& result) {
    for (int col=0;col<3;++col) {
        int pivot=col;
        for (int row=col+1;row<3;++row) if(std::abs(a[row][col])>std::abs(a[pivot][col]))pivot=row;
        if (std::abs(a[pivot][col])<1e-18) return false;
        if (pivot!=col) for (int k=col;k<4;++k) std::swap(a[pivot][k],a[col][k]);
        const double div=a[col][col];
        for (int k=col;k<4;++k)a[col][k]/=div;
        for (int row=0;row<3;++row) if(row!=col) {
            const double factor=a[row][col];
            for(int k=col;k<4;++k)a[row][k]-=factor*a[col][k];
        }
    }
    result={a[0][3],a[1][3],a[2][3]};
    return finite(result);
}
// Fit Hermite planes n_i dot (x-p_i)=0. Regularization prefers intersection
// mass point when an SDF gives fewer than three independent plane normals.
glm::dvec3 solveQef(const std::vector<Hermite>& h, const glm::dvec3& mn,
                    const double cellSize, const double reg) {
    glm::dvec3 mass(0.0);
    for (const auto& v:h) mass+=v.point;
    mass/=double(h.size());
    double mat[3][4]{};
    for (const auto& v:h) {
        for(int i=0;i<3;++i)for(int j=0;j<3;++j)mat[i][j]+=v.normal[i]*v.normal[j];
        const double b=glm::dot(v.normal,v.point);
        for(int i=0;i<3;++i)mat[i][3]+=v.normal[i]*b;
    }
    // Keep lambda small but nonzero relative to number of constraints.
    const double lambda=std::max(1e-12,reg)*double(h.size());
    for(int i=0;i<3;++i) {mat[i][i]+=lambda;mat[i][3]+=lambda*mass[i];}
    glm::dvec3 x=mass;
    (void)solve3x3(mat,x);
    return glm::clamp(x,mn,mn+glm::dvec3(cellSize));
}
}

bool buildDualContourMesh(const DcSettings& settings, const DcDensity& density, DcMesh& out) {
    const auto n=settings.cells;
    if (!density || !finite(settings.origin) || n<2 || n>128 ||
        !std::isfinite(settings.cellSize) || settings.cellSize<=0.0 ||
        !std::isfinite(settings.gradientStep) || settings.gradientStep<=0.0 ||
        settings.gradientStep>settings.cellSize*0.5 ||
        !std::isfinite(settings.qefRegularization) || settings.qefRegularization<0.0 ||
        settings.qefRegularization>1.0) return false;
    const std::size_t stride=std::size_t(n)+1;
    const auto sampleIdx=[&](std::size_t x,std::size_t y,std::size_t z){return x+stride*(y+stride*z);};
    const auto cellIdx=[&](std::size_t x,std::size_t y,std::size_t z){return x+std::size_t(n)*(y+std::size_t(n)*z);};
    std::vector<double> samples(stride*stride*stride);
    // Sample once at double-precision world positions, store vertices near origin.
    const auto pos=[&](std::size_t x,std::size_t y,std::size_t z){
        return settings.origin+glm::dvec3(x,y,z)*settings.cellSize;
    };
    for (std::size_t z=0;z<stride;++z)for (std::size_t y=0;y<stride;++y)
        for (std::size_t x=0;x<stride;++x) {
            const double v=density(pos(x,y,z));
            if (!std::isfinite(v)) return false;
            samples[sampleIdx(x,y,z)]=v;
        }
    DcMesh mesh;mesh.origin=settings.origin;
    std::vector<int> cellVert(std::size_t(n)*n*n,-1);
    const auto gradient=[&](const glm::dvec3& p, glm::dvec3& normal) {
        glm::dvec3 g(0.0);
        for (int i=0;i<3;++i) {
            glm::dvec3 delta(0.0);delta[i]=settings.gradientStep;
            const double a=density(p+delta),b=density(p-delta);
            if(!std::isfinite(a)||!std::isfinite(b)) return false;
            g[i]=(a-b)/(settings.gradientStep*2.0);
        }
        const double len=glm::length(g);
        if (!std::isfinite(len)||len<1e-12) return false;
        normal=g/len;return true;
    };
    for (std::uint32_t z=0;z<n;++z)for (std::uint32_t y=0;y<n;++y)
        for (std::uint32_t x=0;x<n;++x) {
            std::array<double,8> d{};
            for(std::size_t i=0;i<8;++i) {
                auto c=corners[i];d[i]=samples[sampleIdx(x+c.x,y+c.y,z+c.z)];
            }
            std::vector<Hermite> h;
            h.reserve(12);
            glm::dvec3 avgNormal(0.0);
            for (const auto& e:edges) {
                const double a=d[e[0]], b=d[e[1]];
                if ((a<0.0)==(b<0.0))continue;
                const double t=std::clamp(a/(a-b),0.0,1.0);
                const auto aOff=corners[e[0]],bOff=corners[e[1]];
                const glm::dvec3 pa=pos(x+aOff.x,y+aOff.y,z+aOff.z);
                const glm::dvec3 pb=pos(x+bOff.x,y+bOff.y,z+bOff.z);
                const glm::dvec3 p=pa+(pb-pa)*t;
                glm::dvec3 normal{};
                if (!gradient(p,normal))return false;
                h.push_back({p,normal});avgNormal+=normal;
            }
            if(h.empty())continue;
            const auto absolute=solveQef(h,pos(x,y,z),settings.cellSize,settings.qefRegularization);
            const auto rel=absolute-settings.origin;
            if (!finite(rel)||glm::length(rel)>1e9||mesh.vertices.size()>=std::numeric_limits<std::uint32_t>::max())return false;
            const glm::dvec3 normal=glm::length(avgNormal)>1e-12 ? glm::normalize(avgNormal) : h.front().normal;
            cellVert[cellIdx(x,y,z)]=int(mesh.vertices.size());
            mesh.vertices.push_back({glm::vec3(rel),glm::vec3(normal)});
        }
    // Every signed grid edge with four incident cells produces a quad.
    // Boundary edges are omitted; chunk stitching requires a halo in v3.0.
    const auto emit=[&](std::array<int,4> c, const glm::dvec3& at) {
        for(auto i:c)if(i<0)return true;
        const auto a=mesh.vertices[c[0]].position,b=mesh.vertices[c[1]].position,
                   d=mesh.vertices[c[2]].position;
        glm::dvec3 normal{};
        if(!gradient(at,normal))return false;
        if (glm::dot(glm::cross(glm::dvec3(b-a),glm::dvec3(d-a)), normal)<0.0)
            std::swap(c[1],c[3]);
        for(auto j:{0,1,2,0,2,3})mesh.indices.push_back(std::uint32_t(c[j]));
        return true;
    };
    for(std::uint32_t z=0;z<=n;++z)for(std::uint32_t y=0;y<=n;++y)
        for(std::uint32_t x=0;x<=n;++x) {
            // X-axis grid edge
            if(x<n && y>0&&y<n&&z>0&&z<n &&
               ((samples[sampleIdx(x,y,z)]<0)!=(samples[sampleIdx(x+1,y,z)]<0))) {
                const double a=samples[sampleIdx(x,y,z)],b=samples[sampleIdx(x+1,y,z)];
                const auto interp=pos(x,y,z)+glm::dvec3(a/(a-b)*settings.cellSize,0,0);
                if(!emit({cellVert[cellIdx(x,y-1,z-1)],cellVert[cellIdx(x,y,z-1)],
                          cellVert[cellIdx(x,y,z)],cellVert[cellIdx(x,y-1,z)]},interp))return false;
            }
            // Y-axis grid edge
            if(y<n && x>0&&x<n&&z>0&&z<n &&
               ((samples[sampleIdx(x,y,z)]<0)!=(samples[sampleIdx(x,y+1,z)]<0))) {
                const double a=samples[sampleIdx(x,y,z)],b=samples[sampleIdx(x,y+1,z)];
                const auto interp=pos(x,y,z)+glm::dvec3(0,a/(a-b)*settings.cellSize,0);
                if(!emit({cellVert[cellIdx(x-1,y,z-1)],cellVert[cellIdx(x,y,z-1)],
                          cellVert[cellIdx(x,y,z)],cellVert[cellIdx(x-1,y,z)]},interp))return false;
            }
            // Z-axis grid edge
            if(z<n && x>0&&x<n&&y>0&&y<n &&
               ((samples[sampleIdx(x,y,z)]<0)!=(samples[sampleIdx(x,y,z+1)]<0))) {
                const double a=samples[sampleIdx(x,y,z)],b=samples[sampleIdx(x,y,z+1)];
                const auto interp=pos(x,y,z)+glm::dvec3(0,0,a/(a-b)*settings.cellSize);
                if(!emit({cellVert[cellIdx(x-1,y-1,z)],cellVert[cellIdx(x,y-1,z)],
                          cellVert[cellIdx(x,y,z)],cellVert[cellIdx(x-1,y,z)]},interp))return false;
            }
        }
    out=std::move(mesh);
    return true;
}
} // namespace px
