#pragma once
// Terrain materials. Every density sample also stores a material id (one byte),
// so the world remembers what it is made of: grass on top, dirt under that,
// stone deeper down, plus anything you build or paint.
//
// Id 0 is special: "Natural" means "let the engine decide from the shape". At
// mesh time it becomes grass on flat ground, dirt on gentle slopes, stone on
// cliffs and overhangs, sand in low valleys and snow on high peaks. Everything
// the generator makes starts as Natural; painting Natural restores that look.
//
// Slot = id - 1 (the renderer keeps one slot per real material; each slot picks a texture, a tint and a glow).
#include <cstdint>

namespace px {

using MaterialId = std::uint8_t;

enum Material : MaterialId {
    MAT_NATURAL = 0,
    // terrain
    MAT_GRASS,
    MAT_DIRT,
    MAT_STONE,
    MAT_SAND,
    MAT_SNOW,
    // building
    MAT_WOOD,
    MAT_METAL,
    MAT_BRICK,
    MAT_PLASTER,
    MAT_TILE,
    MAT_CLOTH,
    MAT_ICE,
    // glowing
    MAT_LAVA,
    MAT_LAMP,
    MAT_CRYSTAL,
    // paint: plaster with a colour (new materials are only ever added at the end, so saved worlds keep their meaning)
    MAT_PAINT_RED,
    MAT_PAINT_ORANGE,
    MAT_PAINT_YELLOW,
    MAT_PAINT_GREEN,
    MAT_PAINT_TEAL,
    MAT_PAINT_BLUE,
    MAT_PAINT_PURPLE,
    MAT_PAINT_PINK,
    MAT_PAINT_BLACK,
    // 1.2: more ground, more building materials, nature
    MAT_MOSS,
    MAT_GRAVEL,
    MAT_MUD,
    MAT_SANDSTONE,
    MAT_COBBLESTONE,
    MAT_MARBLE,
    MAT_CONCRETE,
    MAT_SLATE,
    MAT_ROOF_TILES,
    MAT_RUST,
    MAT_BARK,
    MAT_LEAVES,
    // 1.2: for windows and people
    MAT_GLASS,
    MAT_SKIN,
    MAT_HAIR,
    MAT_LEATHER,
    MAT_GOLD,
    MAT_STEEL,
    MAT_NEEDLES,
    MAT_COUNT
};

// Every material is drawn from one of the procedural textures, tinted, and may glow. The renderer
// has one "slot" per real material (slot = id - 1): the mesher writes slots into the vertices, and the
// terrain shader looks the texture, tint and glow of each slot up in small tables.
constexpr int kMaterialSlots = MAT_COUNT - 1;   // real materials (everything but Natural)
constexpr int kTextureImages = 32;              // distinct textures (see render/MaterialTextures.cpp)

enum class MaterialGroup : std::uint8_t { Natural, Terrain, Nature, Building, Glowing, Paint, People };

struct MaterialInfo {
    const char*   name;
    const char*   blurb;
    MaterialGroup group;
    int           texture;      // which procedural texture it is drawn with (-1 for Natural)
    float         tint[3];      // multiplies the texture's colour (1,1,1 = as drawn)
    float         glow;         // 0 = does not glow; above 0 it gives off its own light, brighter than the sun lights it
    float         glowMask;     // 0 = the whole surface glows, 1 = only the bright parts of the texture (lava cracks)
    float         flat[3];      // one colour that stands for it in thumbnails
};

inline const MaterialInfo& materialInfo(MaterialId id) {
    // texture: 0 grass 1 dirt 2 stone 3 sand 4 snow 5 wood 6 metal 7 brick 8 plaster 9 tile 10 cloth 11 ice 12 lava 13 lamp 14 crystal
    //          15 moss 16 gravel 17 mud 18 cobblestone 19 marble 20 concrete 21 sandstone 22 slate 23 bark 24 rust 25 roof tiles 26 leaves
    //          27 glass 28 skin 29 hair 30 leather 31 polished metal
    static const MaterialInfo infos[MAT_COUNT] = {
        { "Natural", "Grass, dirt, stone, sand or snow, picked from the slope and height", MaterialGroup::Natural, -1, { 1, 1, 1 }, 0.0f, 0.0f, { 0.56f, 0.57f, 0.60f } },
        { "Grass",   "Meadow grass",                  MaterialGroup::Terrain,  0, { 1, 1, 1 }, 0.0f, 0.0f, { 0.36f, 0.62f, 0.24f } },
        { "Dirt",    "Packed earth with pebbles",     MaterialGroup::Terrain,  1, { 1, 1, 1 }, 0.0f, 0.0f, { 0.46f, 0.34f, 0.23f } },
        { "Stone",   "Cracked grey rock",             MaterialGroup::Terrain,  2, { 1, 1, 1 }, 0.0f, 0.0f, { 0.56f, 0.57f, 0.60f } },
        { "Sand",    "Wind-rippled sand",             MaterialGroup::Terrain,  3, { 1, 1, 1 }, 0.0f, 0.0f, { 0.83f, 0.73f, 0.49f } },
        { "Snow",    "Soft snow",                     MaterialGroup::Terrain,  4, { 1, 1, 1 }, 0.0f, 0.0f, { 0.93f, 0.95f, 0.98f } },
        { "Wood",    "Wooden planks",                 MaterialGroup::Building, 5, { 1, 1, 1 }, 0.0f, 0.0f, { 0.60f, 0.42f, 0.23f } },
        { "Metal",   "Riveted metal panels",          MaterialGroup::Building, 6, { 1, 1, 1 }, 0.0f, 0.0f, { 0.63f, 0.67f, 0.73f } },
        { "Brick",   "Red brick wall",                MaterialGroup::Building, 7, { 1, 1, 1 }, 0.0f, 0.0f, { 0.67f, 0.29f, 0.23f } },
        { "Plaster", "Smooth white wall",             MaterialGroup::Building, 8, { 1, 1, 1 }, 0.0f, 0.0f, { 0.88f, 0.86f, 0.82f } },
        { "Tile",    "Glossy ceramic tiles",          MaterialGroup::Building, 9, { 1, 1, 1 }, 0.0f, 0.0f, { 0.80f, 0.84f, 0.86f } },
        { "Cloth",   "Woven fabric",                  MaterialGroup::Building, 10, { 1, 1, 1 }, 0.0f, 0.0f, { 0.72f, 0.66f, 0.55f } },
        { "Ice",     "Clear blue ice, shiny and cracked", MaterialGroup::Building, 11, { 1, 1, 1 }, 0.0f, 0.0f, { 0.62f, 0.80f, 0.92f } },
        { "Lava",    "Molten rock: dark crust with glowing cracks", MaterialGroup::Glowing, 12, { 1, 1, 1 }, 2.6f, 1.0f, { 0.95f, 0.38f, 0.10f } },
        { "Lamp",    "A warm light panel",            MaterialGroup::Glowing, 13, { 1, 0.86f, 0.62f }, 2.2f, 0.0f, { 1.00f, 0.86f, 0.55f } },
        { "Crystal", "A glowing blue crystal",        MaterialGroup::Glowing, 14, { 0.55f, 0.85f, 1.0f }, 1.8f, 0.0f, { 0.45f, 0.80f, 1.00f } },
        { "Red",     "Red paint",                     MaterialGroup::Paint, 8, { 0.85f, 0.14f, 0.12f }, 0.0f, 0.0f, { 0.80f, 0.18f, 0.16f } },
        { "Orange",  "Orange paint",                  MaterialGroup::Paint, 8, { 0.95f, 0.45f, 0.08f }, 0.0f, 0.0f, { 0.92f, 0.50f, 0.14f } },
        { "Yellow",  "Yellow paint",                  MaterialGroup::Paint, 8, { 0.98f, 0.82f, 0.12f }, 0.0f, 0.0f, { 0.95f, 0.82f, 0.20f } },
        { "Green",   "Green paint",                   MaterialGroup::Paint, 8, { 0.20f, 0.60f, 0.20f }, 0.0f, 0.0f, { 0.26f, 0.62f, 0.26f } },
        { "Teal",    "Teal paint",                    MaterialGroup::Paint, 8, { 0.10f, 0.62f, 0.62f }, 0.0f, 0.0f, { 0.20f, 0.62f, 0.62f } },
        { "Blue",    "Blue paint",                    MaterialGroup::Paint, 8, { 0.14f, 0.32f, 0.85f }, 0.0f, 0.0f, { 0.20f, 0.36f, 0.82f } },
        { "Purple",  "Purple paint",                  MaterialGroup::Paint, 8, { 0.52f, 0.20f, 0.72f }, 0.0f, 0.0f, { 0.54f, 0.28f, 0.70f } },
        { "Pink",    "Pink paint",                    MaterialGroup::Paint, 8, { 0.95f, 0.45f, 0.65f }, 0.0f, 0.0f, { 0.92f, 0.52f, 0.68f } },
        { "Black",   "Black paint",                   MaterialGroup::Paint, 8, { 0.07f, 0.07f, 0.08f }, 0.0f, 0.0f, { 0.12f, 0.12f, 0.13f } },
        { "Moss",        "Deep, cushiony moss",                         MaterialGroup::Nature,   15, { 1, 1, 1 }, 0.0f, 0.0f, { 0.30f, 0.42f, 0.14f } },
        { "Gravel",      "Loose pebbles of mixed stone",                MaterialGroup::Terrain,  16, { 1, 1, 1 }, 0.0f, 0.0f, { 0.52f, 0.49f, 0.45f } },
        { "Mud",         "Wet, churned mud with puddles",               MaterialGroup::Terrain,  17, { 1, 1, 1 }, 0.0f, 0.0f, { 0.30f, 0.23f, 0.16f } },
        { "Sandstone",   "Layered warm sandstone",                      MaterialGroup::Terrain,  21, { 1, 1, 1 }, 0.0f, 0.0f, { 0.78f, 0.57f, 0.38f } },
        { "Cobblestone", "Rounded street cobbles",                      MaterialGroup::Building, 18, { 1, 1, 1 }, 0.0f, 0.0f, { 0.50f, 0.48f, 0.45f } },
        { "Marble",      "Polished white marble with veins",            MaterialGroup::Building, 19, { 1, 1, 1 }, 0.0f, 0.0f, { 0.90f, 0.89f, 0.87f } },
        { "Concrete",    "Cast concrete",                               MaterialGroup::Building, 20, { 1, 1, 1 }, 0.0f, 0.0f, { 0.58f, 0.58f, 0.56f } },
        { "Slate",       "Split slate flagstones",                      MaterialGroup::Building, 22, { 1, 1, 1 }, 0.0f, 0.0f, { 0.31f, 0.33f, 0.37f } },
        { "Roof tiles",  "Clay roof tiles",                             MaterialGroup::Building, 25, { 1, 1, 1 }, 0.0f, 0.0f, { 0.66f, 0.32f, 0.20f } },
        { "Rust",        "Rusting steel",                               MaterialGroup::Building, 24, { 1, 1, 1 }, 0.0f, 0.0f, { 0.56f, 0.33f, 0.18f } },
        { "Bark",        "Tree bark",                                   MaterialGroup::Nature,   23, { 1, 1, 1 }, 0.0f, 0.0f, { 0.36f, 0.30f, 0.24f } },
        { "Leaves",      "A canopy of leaves",                          MaterialGroup::Nature,   26, { 1, 1, 1 }, 0.0f, 0.0f, { 0.26f, 0.42f, 0.14f } },
        { "Glass",       "Window glass: dark, with the sky in it",      MaterialGroup::Building, 27, { 1, 1, 1 }, 0.0f, 0.0f, { 0.20f, 0.26f, 0.32f } },
        { "Skin",        "Skin (takes a person's skin colour)",         MaterialGroup::People,   28, { 0.92f, 0.74f, 0.62f }, 0.0f, 0.0f, { 0.86f, 0.68f, 0.56f } },
        { "Hair",        "Hair (takes a person's hair colour)",         MaterialGroup::People,   29, { 0.32f, 0.22f, 0.14f }, 0.0f, 0.0f, { 0.30f, 0.21f, 0.14f } },
        { "Leather",     "Tanned leather: shoes, belts, jackets",       MaterialGroup::People,   30, { 0.48f, 0.30f, 0.18f }, 0.0f, 0.0f, { 0.45f, 0.29f, 0.18f } },
        { "Gold",        "Polished gold and brass",                     MaterialGroup::Building, 31, { 1.0f, 0.76f, 0.33f }, 0.0f, 0.0f, { 0.95f, 0.74f, 0.32f } },
        { "Steel",       "Polished steel: blades, fittings, chrome",    MaterialGroup::Building, 31, { 0.78f, 0.79f, 0.80f }, 0.0f, 0.0f, { 0.74f, 0.75f, 0.77f } },
        { "Needles",     "Pine needles: dark, blue-green",              MaterialGroup::Nature,   26, { 0.52f, 0.68f, 0.62f }, 0.0f, 0.0f, { 0.15f, 0.28f, 0.12f } },
    };
    return infos[id < MAT_COUNT ? id : 0];
}

inline const char* materialGroupName(MaterialGroup g) {
    switch (g) {
    case MaterialGroup::Natural:  return "Natural";
    case MaterialGroup::Terrain:  return "Terrain";
    case MaterialGroup::Nature:   return "Nature";
    case MaterialGroup::Building: return "Building";
    case MaterialGroup::Glowing:  return "Glowing";
    case MaterialGroup::Paint:    return "Paint";
    case MaterialGroup::People:   return "People";
    }
    return "";
}

} // namespace px
