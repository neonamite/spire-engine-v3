#pragma once
// Data-only planetary configuration. Existing flat-world TerrainGenerator and
// v1.6 save formats are intentionally unchanged in the first migration step.
#include <cstdint>
#include <cmath>
#include <string>
#include <glm/glm.hpp>

namespace px {

enum class PlanetProjection : std::uint8_t {
    SpherifiedCube = 0
};

struct PlanetDefinition {
    std::string id = "planet-001";
    std::string name = "New Planet";
    double radiusMeters = 6'371'000.0;
    std::uint64_t seed = 1337;
    double surfaceGravity = 9.81;
    PlanetProjection projection = PlanetProjection::SpherifiedCube;
    double terrainAmplitudeMeters = 1200.0;
    double seaLevelMeters = 0.0;

    bool valid() const noexcept {
        return !id.empty() && std::isfinite(radiusMeters) && radiusMeters > 0.0 &&
               std::isfinite(surfaceGravity) && surfaceGravity >= 0.0 &&
               std::isfinite(terrainAmplitudeMeters) && terrainAmplitudeMeters >= 0.0 &&
               std::isfinite(seaLevelMeters) && radiusMeters + seaLevelMeters > 0.0;
    }

    // Local up direction at an absolute point relative to this planet center.
    // Returns zero for the exact center, where radial up is undefined.
    glm::dvec3 radialUp(const glm::dvec3& pointRelativeToCenter) const {
        const double len = glm::length(pointRelativeToCenter);
        return len > 0.0 ? pointRelativeToCenter / len : glm::dvec3(0.0);
    }
};

} // namespace px
