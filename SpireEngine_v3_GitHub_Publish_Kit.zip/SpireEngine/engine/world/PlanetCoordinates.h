#pragma once
// Planet-ready world coordinates. Absolute positions are represented as an
// integer sector plus a small local offset; renderer-facing positions remain
// float and camera-relative. This is additive to v1.6's glm::vec3 API.
//
// Contract (after a successful normalize / addOffset / worldPositionFromMeters):
//   - Every local component is finite and in [0, WORLD_SECTOR_SIZE).
//   - Sector indices are signed 64-bit; operations that would leave that range
//     fail with CoordError::SectorOverflow and leave the input unchanged.
//   - Non-finite local components fail with CoordError::NonFinite (unchanged).
//   - Offsets whose magnitude cannot be reduced exactly via double-precision
//     floor division fail with CoordError::ImpreciseOffset (unchanged).
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <glm/glm.hpp>

namespace px {

inline constexpr double WORLD_SECTOR_SIZE = 1024.0;

// Doubles represent integers exactly only up to 2^53. A local offset whose
// absolute sector-carry exceeds this cannot be floored without gaps, so the
// API rejects it rather than silently mis-canonicalizing.
inline constexpr double WORLD_MAX_EXACT_SECTOR_CARRY =
    9007199254740992.0; // 2^53

enum class CoordError : std::uint8_t {
    Ok = 0,
    NonFinite,
    SectorOverflow,
    ImpreciseOffset
};

inline constexpr const char* coordErrorMessage(CoordError e) noexcept {
    switch (e) {
    case CoordError::Ok: return "ok";
    case CoordError::NonFinite: return "non-finite local coordinate";
    case CoordError::SectorOverflow: return "sector index out of int64 range";
    case CoordError::ImpreciseOffset: return "offset exceeds exact double sector carry";
    }
    return "unknown coordinate error";
}

struct SectorCoord {
    std::int64_t x = 0, y = 0, z = 0;
    friend constexpr bool operator==(const SectorCoord&, const SectorCoord&) = default;
};

struct WorldPosition {
    SectorCoord sector{};
    // Canonical local components are in [0, WORLD_SECTOR_SIZE).
    glm::dvec3 local{0.0};

    bool isCanonical(double epsilon = 1e-9) const noexcept {
        auto axisOk = [epsilon](double v) {
            return std::isfinite(v) && v >= -epsilon && v < WORLD_SECTOR_SIZE + epsilon;
        };
        return axisOk(local.x) && axisOk(local.y) && axisOk(local.z);
    }
};

namespace detail {

inline bool canAddSector(std::int64_t sector, std::int64_t delta) noexcept {
    if (delta > 0) return sector <= std::numeric_limits<std::int64_t>::max() - delta;
    if (delta < 0) return sector >= std::numeric_limits<std::int64_t>::min() - delta;
    return true;
}

// Floor-divide local into sector carry + remainder in [0, WORLD_SECTOR_SIZE).
// Mutates the working copies only; callers commit on full success.
inline CoordError normalizeAxis(std::int64_t& sector, double& local) {
    if (!std::isfinite(local)) return CoordError::NonFinite;

    const double carryD = std::floor(local / WORLD_SECTOR_SIZE);
    if (!std::isfinite(carryD)) return CoordError::NonFinite;
    if (std::abs(carryD) > WORLD_MAX_EXACT_SECTOR_CARRY) return CoordError::ImpreciseOffset;

    // Conversion to int64_t outside its range is undefined; refuse first.
    // INT64_MAX is not exactly representable as double, so the safe upper gate
    // is 2^63 (== -INT64_MIN as double), matching a half-open cast range.
    constexpr double kMinI64 = static_cast<double>(std::numeric_limits<std::int64_t>::min());
    constexpr double kOpenMaxI64 = -kMinI64; // 2^63
    if (carryD < kMinI64 || carryD >= kOpenMaxI64) return CoordError::SectorOverflow;

    const auto carry = static_cast<std::int64_t>(carryD);
    if (!canAddSector(sector, carry)) return CoordError::SectorOverflow;

    sector += carry;
    local -= static_cast<double>(carry) * WORLD_SECTOR_SIZE;

    // Protect against tiny rounding excursions at sector boundaries.
    if (local < 0.0) {
        if (sector == std::numeric_limits<std::int64_t>::min()) return CoordError::SectorOverflow;
        --sector;
        local += WORLD_SECTOR_SIZE;
    }
    if (local >= WORLD_SECTOR_SIZE) {
        if (sector == std::numeric_limits<std::int64_t>::max()) return CoordError::SectorOverflow;
        ++sector;
        local -= WORLD_SECTOR_SIZE;
    }

    if (!std::isfinite(local) || local < 0.0 || local >= WORLD_SECTOR_SIZE)
        return CoordError::ImpreciseOffset;
    return CoordError::Ok;
}

} // namespace detail

// Transactional: on any failure, `p` is left exactly as it was on entry.
inline CoordError tryNormalize(WorldPosition& p) {
    WorldPosition tmp = p;
    if (const CoordError ex = detail::normalizeAxis(tmp.sector.x, tmp.local.x); ex != CoordError::Ok) return ex;
    if (const CoordError ey = detail::normalizeAxis(tmp.sector.y, tmp.local.y); ey != CoordError::Ok) return ey;
    if (const CoordError ez = detail::normalizeAxis(tmp.sector.z, tmp.local.z); ez != CoordError::Ok) return ez;
    p = tmp;
    return CoordError::Ok;
}

inline bool normalize(WorldPosition& p) {
    return tryNormalize(p) == CoordError::Ok;
}

inline CoordError tryAddOffset(WorldPosition& p, const glm::dvec3& offset) {
    if (!std::isfinite(offset.x) || !std::isfinite(offset.y) || !std::isfinite(offset.z))
        return CoordError::NonFinite;
    WorldPosition tmp = p;
    tmp.local += offset;
    const CoordError err = tryNormalize(tmp);
    if (err != CoordError::Ok) return err;
    p = tmp;
    return CoordError::Ok;
}

inline bool addOffset(WorldPosition& p, const glm::dvec3& offset) {
    return tryAddOffset(p, offset) == CoordError::Ok;
}

// Returns a camera-relative float position for GPU rendering. Intended for
// nearby objects; callers should cull objects beyond their chosen render range.
inline glm::vec3 relativeTo(const WorldPosition& p, const WorldPosition& origin) {
    const long double sx = static_cast<long double>(p.sector.x) - static_cast<long double>(origin.sector.x);
    const long double sy = static_cast<long double>(p.sector.y) - static_cast<long double>(origin.sector.y);
    const long double sz = static_cast<long double>(p.sector.z) - static_cast<long double>(origin.sector.z);
    const long double scale = static_cast<long double>(WORLD_SECTOR_SIZE);
    return glm::vec3(
        static_cast<float>(sx * scale + static_cast<long double>(p.local.x - origin.local.x)),
        static_cast<float>(sy * scale + static_cast<long double>(p.local.y - origin.local.y)),
        static_cast<float>(sz * scale + static_cast<long double>(p.local.z - origin.local.z)));
}

inline CoordError tryWorldPositionFromMeters(const glm::dvec3& absolute, WorldPosition& out) {
    WorldPosition p;
    p.local = absolute;
    const CoordError err = tryNormalize(p);
    if (err != CoordError::Ok) return err;
    out = p;
    return CoordError::Ok;
}

inline WorldPosition worldPositionFromMeters(const glm::dvec3& absolute) {
    WorldPosition p;
    const CoordError err = tryWorldPositionFromMeters(absolute, p);
    if (err != CoordError::Ok) throw std::out_of_range(coordErrorMessage(err));
    return p;
}

} // namespace px
