#pragma once
// C8 planet-creation model shared by the Hub UI and headless tests.
// The legacy local voxel renderer can currently handle only small demo planets.
// This deliberately does NOT advertise full Earth-scale planets or finished biomes.
#include "TerrainProvider.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <string>

namespace px {

enum class PlanetPreset : int { Rocky = 0, Desert = 1, Ice = 2, Moon = 3, Custom = 4 };

inline PlanetaryTerrainSettings planetPresetSettings(PlanetPreset preset) {
    PlanetaryTerrainSettings settings;
    auto& planet = settings.planet;
    planet.id = "new-planet";
    planet.name = "New Planet";
    planet.radiusMeters = 96.0;
    planet.terrainAmplitudeMeters = 5.0;
    planet.seaLevelMeters = 0.0;
    planet.seed = 1337;
    planet.surfaceGravity = 9.81;
    settings.hillFrequency = 2.5f;
    settings.caveFrequency = 0.025f;
    settings.caveAmplitude = 0.0f; // keep the prototype shell stable at creation
    switch (preset) {
        case PlanetPreset::Rocky: break;
        case PlanetPreset::Desert:
            planet.radiusMeters = 128.0; planet.terrainAmplitudeMeters = 9.0;
            planet.surfaceGravity = 8.5; settings.hillFrequency = 3.5f; break;
        case PlanetPreset::Ice:
            planet.radiusMeters = 96.0; planet.terrainAmplitudeMeters = 3.0;
            planet.surfaceGravity = 6.5; settings.hillFrequency = 1.8f; break;
        case PlanetPreset::Moon:
            planet.radiusMeters = 80.0; planet.terrainAmplitudeMeters = 6.0;
            planet.surfaceGravity = 1.62; settings.hillFrequency = 5.0f; break;
        case PlanetPreset::Custom: break;
    }
    return settings;
}

// Restrict the interactive creator to the *current* legacy float-coordinate
// + 32-cell Marching Cubes path. Large planets will need C7 surface LOD render
// integration, double-precision scene transforms and planet-safe physics first.
inline std::string planetCreatorValidation(const PlanetaryTerrainSettings& settings) {
    const auto& p = settings.planet;
    if (p.name.empty() || p.name.size() > 72 ||
        p.name.find_first_not_of(" \t\r\n") == std::string::npos)
        return "Enter a planet name (up to 72 characters).";
    if (!p.valid()) return "Planet values must be finite and non-negative where required.";
    if (p.radiusMeters < 48.0 || p.radiusMeters > 512.0)
        return "Prototype radius must be between 48 and 512 meters.";
    if (p.terrainAmplitudeMeters > p.radiusMeters * 0.15)
        return "Terrain relief cannot exceed 15% of planet radius in this prototype.";
    if (std::abs(p.seaLevelMeters) > p.radiusMeters * 0.10)
        return "Sea-level offset must stay within 10% of planet radius.";
    if (p.surfaceGravity > 100.0)
        return "Prototype surface gravity cannot exceed 100 m/s^2.";
    if (!std::isfinite(settings.hillFrequency) || settings.hillFrequency < 0.0f || settings.hillFrequency > 20.0f ||
        !std::isfinite(settings.caveFrequency) || settings.caveFrequency < 0.0f || settings.caveFrequency > 2.0f ||
        !std::isfinite(settings.caveAmplitude) || settings.caveAmplitude < 0.0f || settings.caveAmplitude > 32.0f)
        return "Noise values are outside the supported prototype range.";
    return {};
}

inline std::string planetFileStem(const std::string& name) {
    std::string result;
    result.reserve(std::min<std::size_t>(name.size(), 48));
    for (unsigned char c : name) {
        if (result.size() >= 48) break;
        if (std::isalnum(c) && c < 128) result.push_back(static_cast<char>(std::tolower(c)));
        else if ((c == ' ' || c == '-' || c == '_') && !result.empty() && result.back() != '-') result.push_back('-');
    }
    while (!result.empty() && result.back() == '-') result.pop_back();
    return result.empty() ? "new-planet" : result;
}

// Finds a filename that cannot overwrite an existing planet; the user may
// create multiple planets with the same display name safely.
inline std::filesystem::path nextPlanetSavePath(const std::filesystem::path& planetDirectory, const std::string& name) {
    const std::string stem = planetFileStem(name);
    std::filesystem::path candidate = planetDirectory / (stem + ".vxplanet");
    std::error_code ec;
    for (std::uint32_t suffix = 2; std::filesystem::exists(candidate, ec) && !ec; ++suffix) {
        candidate = planetDirectory / (stem + "-" + std::to_string(suffix) + ".vxplanet");
    }
    return ec ? std::filesystem::path{} : candidate;
}

// Local prototype camera spawn, not a celestial-coordinate / orbital camera.
inline glm::vec3 planetCreatorCameraPosition(const PlanetaryTerrainSettings& s) {
    return glm::vec3(0.0f, static_cast<float>(s.planet.radiusMeters +
                                              s.planet.seaLevelMeters +
                                              s.planet.terrainAmplitudeMeters + 25.0), 35.0f);
}

} // namespace px
