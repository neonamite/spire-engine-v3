#pragma once
// Pluggable terrain density for flat worlds and planetary prototypes.
// ChunkManager still uses TerrainGenerator directly; this layer is tested and
// ready for a future migration without changing v1.6 saves or flat gameplay.
#include "PlanetDefinition.h"
#include "TerrainGenerator.h"
#include "WorldTypes.h"
#include <cmath>
#include <cstdint>
#include <memory>
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Waggressive-loop-optimizations"
#endif
#include "FastNoiseLite.h"
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic pop
#endif
#include <glm/glm.hpp>

namespace px {

enum class TerrainProviderKind : std::uint8_t {
    Flat = 0,
    Planetary = 1
};

// Same density convention as TerrainGenerator: negative = solid, positive = air.
class ITerrainProvider {
public:
    virtual ~ITerrainProvider() = default;
    virtual TerrainProviderKind kind() const noexcept = 0;
    virtual float density(float x, float y, float z) const = 0;
    // Column reference for material layering (flat heightmap Y, planetary shell Y).
    virtual float referenceSurfaceY(float x, float z) const = 0;
};

class FlatTerrainProvider final : public ITerrainProvider {
public:
    explicit FlatTerrainProvider(const TerrainSettings& settings) : generator(settings) {}

    TerrainProviderKind kind() const noexcept override { return TerrainProviderKind::Flat; }
    float density(float x, float y, float z) const override { return generator.density(x, y, z); }
    float referenceSurfaceY(float x, float z) const override { return generator.surfaceHeight(x, z); }

    const TerrainGenerator& terrainGenerator() const noexcept { return generator; }

private:
    TerrainGenerator generator;
};

struct PlanetaryTerrainSettings {
    PlanetDefinition planet{};
    float caveFrequency = 0.035f;
    float caveAmplitude = 9.0f;
    float hillFrequency = 0.004f; // direction-space noise scale
};

// Spherical shell density around the origin. Not wired into ChunkManager yet.
class PlanetaryTerrainProvider final : public ITerrainProvider {
public:
    explicit PlanetaryTerrainProvider(const PlanetaryTerrainSettings& s) : settings(s) {
        hills.SetSeed(static_cast<int>(s.planet.seed));
        hills.SetNoiseType(FastNoiseLite::NoiseType_OpenSimplex2);
        hills.SetFractalType(FastNoiseLite::FractalType_FBm);
        hills.SetFractalOctaves(5);
        hills.SetFrequency(s.hillFrequency);

        caves.SetSeed(static_cast<int>(s.planet.seed) + 101);
        caves.SetNoiseType(FastNoiseLite::NoiseType_OpenSimplex2);
        caves.SetFractalType(FastNoiseLite::FractalType_FBm);
        caves.SetFractalOctaves(3);
        caves.SetFrequency(s.caveFrequency);
    }

    TerrainProviderKind kind() const noexcept override { return TerrainProviderKind::Planetary; }

    double shellRadius(const glm::dvec3& unitDir) const {
        if (settings.planet.terrainAmplitudeMeters == 0.0)
            return settings.planet.radiusMeters + settings.planet.seaLevelMeters;
        const double relief = hills.GetNoise(static_cast<float>(unitDir.x),
                                             static_cast<float>(unitDir.y),
                                             static_cast<float>(unitDir.z)) *
                              settings.planet.terrainAmplitudeMeters;
        return settings.planet.radiusMeters + settings.planet.seaLevelMeters + relief;
    }

    // The double-precision sampler is the authoritative radial math for new
    // planet consumers. The legacy float interface remains an adapter.
    float densityAt(const glm::dvec3& p) const {
        const double len = glm::length(p);
        if (len < 1e-6) return -DENSITY_CLAMP;

        const glm::dvec3 dir = p / len;
        double d = len - shellRadius(dir);
        if (settings.caveAmplitude > 0.0f) {
            // Carve only near the shell so deep core and outer space stay stable.
            if (std::abs(d) < settings.planet.terrainAmplitudeMeters * 1.5 + settings.caveAmplitude) {
                // TEMPORARY: cave noise still uses float world coordinates.
                // Sector-local cave domain mapping is required for huge planets.
                d += caves.GetNoise(static_cast<float>(p.x), static_cast<float>(p.y),
                                    static_cast<float>(p.z)) * settings.caveAmplitude;
            }
        }
        return glm::clamp(static_cast<float>(d), -DENSITY_CLAMP, DENSITY_CLAMP);
    }

    float density(float x, float y, float z) const override {
        return densityAt(glm::dvec3(x, y, z));
    }

    float referenceSurfaceY(float x, float z) const override {
        const glm::dvec3 dir = glm::normalize(glm::dvec3(x, settings.planet.radiusMeters, z));
        return static_cast<float>(dir.y * shellRadius(dir));
    }

    const PlanetaryTerrainSettings settings;

private:
    FastNoiseLite hills;
    FastNoiseLite caves;
};

inline std::unique_ptr<ITerrainProvider> makeFlatTerrainProvider(const TerrainSettings& settings) {
    return std::make_unique<FlatTerrainProvider>(settings);
}

inline std::unique_ptr<ITerrainProvider> makePlanetaryTerrainProvider(const PlanetaryTerrainSettings& settings) {
    return std::make_unique<PlanetaryTerrainProvider>(settings);
}

} // namespace px
