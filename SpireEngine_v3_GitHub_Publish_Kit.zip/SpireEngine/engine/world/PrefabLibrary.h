#pragma once
// Voxel prefabs: a cube of density values you sculpt in-engine, bake to a
// .vxprefab file, and stamp back into the world (by hand or by procedural
// scatter). Because prefabs are density, not polygons, stamped props are
// fully destructible like the terrain around them.
#include <cmath>
#include <memory>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>
#include "Materials.h"

namespace px {

struct Prefab {
    std::string name;
    int size = 0;                 // grid is size^3
    std::vector<float> grid;      // x + y*size + z*size*size
    std::vector<MaterialId> materials;  // same layout; empty = all stone
    // Stamping places the bottom-centre of the grid at the target point.
    glm::ivec3 minCornerFor(const glm::vec3& anchor) const {
        return glm::ivec3(int(std::floor(anchor.x)) - size / 2, int(std::floor(anchor.y)) - 1, int(std::floor(anchor.z)) - size / 2);
    }
};

using PrefabPtr = std::shared_ptr<const Prefab>;

class PrefabLibrary {
public:
    // Built-in procedural props so the world has something to scatter even
    // before you bake your own.
    void addBuiltins();
    void loadDirectory(const std::string& dir);

    static bool saveToFile(const Prefab& p, const std::string& path);
    static std::shared_ptr<Prefab> loadFromFile(const std::string& path);

    void add(PrefabPtr p);
    PrefabPtr get(const std::string& name) const;
    std::vector<std::string> names() const;
    std::vector<PrefabPtr> scatterSet() const;   // prefabs used for procedural scatter

private:
    mutable std::shared_mutex mutex;
    std::unordered_map<std::string, PrefabPtr> prefabs;
};

} // namespace px
