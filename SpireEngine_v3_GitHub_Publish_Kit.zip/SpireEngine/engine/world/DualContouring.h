#pragma once
// v3.0 experimental CPU Dual Contouring. Does not replace Marching Cubes.
// Negative density = solid. Sharp features use intersections + SDF gradients
// solved via regularized least squares (QEF). This uniform-grid prototype
// deliberately omits chunk-border stitching/adaptive SVO transitions.
#include <glm/glm.hpp>
#include <cstdint>
#include <functional>
#include <vector>

namespace px {

using DcDensity = std::function<double(const glm::dvec3&)>;
struct DcVertex {
    glm::vec3 position{0.0f}; // relative to the requested double world origin
    glm::vec3 normal{0.0f,1.0f,0.0f};
};
struct DcMesh {
    glm::dvec3 origin{0.0};
    std::vector<DcVertex> vertices;
    std::vector<std::uint32_t> indices;
};
struct DcSettings {
    glm::dvec3 origin{0.0};
    std::uint32_t cells = 16;     // each axis, uniform cube
    double cellSize = 1.0;       // metres
    double gradientStep = 0.01;  // sampling step in metres
    double qefRegularization = 1e-8;
};

// Out-param is transactional on invalid density samples / arguments.
// Not thread-safe if the provided density callback isn't thread-safe.
bool buildDualContourMesh(const DcSettings& settings, const DcDensity& density, DcMesh& out);

} // namespace px
