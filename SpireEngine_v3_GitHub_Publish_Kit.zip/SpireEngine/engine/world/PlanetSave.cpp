#include "ChunkManager.h"
// Experimental local-planet persistence. Separate magic/version from the
// v1.6 flat .vxworld format, so the two cannot be confused.
// All scalar fields use fixed-width little-endian encoding: no GLM struct
// layout, padding or native bool serialization. Main-thread only.
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <string>
#include <utility>
#include <vector>

namespace px {
namespace {
static_assert(std::numeric_limits<float>::is_iec559 && std::numeric_limits<double>::is_iec559,
              "VXPL persistence requires IEEE-754 floating point");
constexpr char kMagic[4] = {'V', 'X', 'P', 'L'};
constexpr std::uint32_t kVersion = 1;
constexpr std::uint32_t kMaxEdits = 100'000;
constexpr std::uint32_t kMaxText = 256;
constexpr std::uint32_t kMaxExtra = 16u * 1024 * 1024;
constexpr std::uint32_t kMaxGridEntries = 128u * 128 * 128;

struct Writer {
    std::ofstream& f;
    void u8(std::uint8_t v) { f.put(static_cast<char>(v)); }
    void u16(std::uint16_t v) { for (int i = 0; i < 2; ++i) u8(static_cast<std::uint8_t>(v >> (8*i))); }
    void u32(std::uint32_t v) { for (int i = 0; i < 4; ++i) u8(static_cast<std::uint8_t>(v >> (8*i))); }
    void u64(std::uint64_t v) { for (int i = 0; i < 8; ++i) u8(static_cast<std::uint8_t>(v >> (8*i))); }
    void f32(float v) { u32(std::bit_cast<std::uint32_t>(v)); }
    void f64(double v) { u64(std::bit_cast<std::uint64_t>(v)); }
    void vec3(const glm::vec3& v) { f32(v.x); f32(v.y); f32(v.z); }
    void ivec3(const glm::ivec3& v) { u32(static_cast<std::uint32_t>(v.x)); u32(static_cast<std::uint32_t>(v.y)); u32(static_cast<std::uint32_t>(v.z)); }
    bool text(const std::string& s, std::uint32_t max) {
        if (s.size() > max) return false;
        u32(static_cast<std::uint32_t>(s.size()));
        f.write(s.data(), static_cast<std::streamsize>(s.size()));
        return bool(f);
    }
};

struct Reader {
    std::ifstream& f;
    bool u8(std::uint8_t& v) { const int c = f.get(); if (c == std::char_traits<char>::eof()) return false; v = static_cast<std::uint8_t>(c); return true; }
    bool u16(std::uint16_t& v) { v = 0; for (int i=0;i<2;++i) {std::uint8_t x; if(!u8(x))return false; v |= std::uint16_t(x) << (8*i);} return true; }
    bool u32(std::uint32_t& v) { v = 0; for (int i=0;i<4;++i) {std::uint8_t x; if(!u8(x))return false; v |= std::uint32_t(x) << (8*i);} return true; }
    bool u64(std::uint64_t& v) { v = 0; for (int i=0;i<8;++i) {std::uint8_t x; if(!u8(x))return false; v |= std::uint64_t(x) << (8*i);} return true; }
    bool f32(float& v) { std::uint32_t u; if(!u32(u))return false; v = std::bit_cast<float>(u); return std::isfinite(v); }
    bool f64(double& v) { std::uint64_t u; if(!u64(u))return false; v = std::bit_cast<double>(u); return std::isfinite(v); }
    bool vec3(glm::vec3& v) {return f32(v.x) && f32(v.y) && f32(v.z);}
    bool ivec3(glm::ivec3& v) {std::uint32_t x,y,z; if(!u32(x)||!u32(y)||!u32(z))return false; v=glm::ivec3(std::bit_cast<std::int32_t>(x),std::bit_cast<std::int32_t>(y),std::bit_cast<std::int32_t>(z)); return true;}
    bool text(std::string& s, std::uint32_t max) {
        std::uint32_t n; if(!u32(n) || n>max) return false;
        s.resize(n); f.read(s.data(), static_cast<std::streamsize>(n)); return bool(f);
    }
};

bool validOp(const EditOp& op) {
    const auto good = [](float v){return std::isfinite(v);};
    return op.kind <= EditOp::Kind::Smooth && op.mode <= CsgMode::Union && op.material < MAT_COUNT &&
        good(op.center.x) && good(op.center.y) && good(op.center.z) &&
        good(op.radius) && op.radius >= 0.0f && op.radius <= 4096.0f &&
        good(op.strength) && op.strength >= 0.0f && op.strength <= 1.0f &&
        (op.kind != EditOp::Kind::Stamp || static_cast<bool>(op.prefab)) &&
        (op.kind != EditOp::Kind::Smooth || static_cast<bool>(op.delta));
}

bool writeOp(Writer& w, const EditOp& op) {
    if (!validOp(op)) return false;
    w.u8(static_cast<std::uint8_t>(op.kind)); w.vec3(op.center); w.f32(op.radius);
    w.u8(static_cast<std::uint8_t>(op.mode)); w.u8(op.material); w.f32(op.strength);
    if (!w.text(op.prefab ? op.prefab->name : std::string(), kMaxText)) return false;
    if (op.kind == EditOp::Kind::Smooth) {
        const DeltaGrid& g = *op.delta;
        if (g.size <= 0 || g.size > 128 || g.index.size() != g.value.size() ||
            g.index.size() > kMaxGridEntries) return false;
        w.ivec3(g.min); w.u32(static_cast<std::uint32_t>(g.size));
        w.u32(static_cast<std::uint32_t>(g.index.size()));
        const auto maxIndex = static_cast<std::uint32_t>(g.size * g.size * g.size);
        for (std::size_t i=0;i<g.index.size();++i) {
            if (g.index[i] >= maxIndex || !std::isfinite(g.value[i]) || std::abs(g.value[i]) > DENSITY_CLAMP) return false;
            w.u32(g.index[i]);
            const long rounded = std::lround(g.value[i] * 4096.0f);
            const auto q = static_cast<std::int16_t>(std::clamp(rounded, -32768L, 32767L));
            w.u16(std::bit_cast<std::uint16_t>(q));
        }
    }
    return bool(w.f);
}

bool readOp(Reader& r, EditOp& op, const PrefabLibrary& prefabs) {
    std::uint8_t kind, mode, material;
    if (!r.u8(kind) || kind > static_cast<std::uint8_t>(EditOp::Kind::Smooth) ||
        !r.vec3(op.center) || !r.f32(op.radius) || !r.u8(mode) || mode > 1 ||
        !r.u8(material) || material >= MAT_COUNT || !r.f32(op.strength)) return false;
    op.kind = static_cast<EditOp::Kind>(kind);
    op.mode = static_cast<CsgMode>(mode);
    op.material = material;
    std::string name;
    if (!r.text(name, kMaxText)) return false;
    if (op.kind == EditOp::Kind::Stamp) {
        op.prefab = prefabs.get(name);
        if (!op.prefab) return false; // reject missing dependencies rather than silently losing edits
    }
    if (op.kind == EditOp::Kind::Smooth) {
        auto g = std::make_shared<DeltaGrid>();
        std::uint32_t size, count;
        if (!r.ivec3(g->min) || !r.u32(size) || size == 0 || size > 128 ||
            !r.u32(count) || count > size * size * size) return false;
        g->size = static_cast<int>(size);
        g->index.reserve(count); g->value.reserve(count);
        for (std::uint32_t i=0;i<count;++i) {
            std::uint32_t index; std::uint16_t q;
            if (!r.u32(index) || index >= size * size * size || !r.u16(q)) return false;
            g->index.push_back(index);
            g->value.push_back(static_cast<float>(std::bit_cast<std::int16_t>(q)) / 4096.0f);
        }
        op.delta = std::move(g);
    }
    return validOp(op);
}
} // namespace

bool ChunkManager::savePlanetPrototype(const std::string& path) const {
    if (!planetaryProvider || editLog.size() > kMaxEdits || extra.size() > kMaxExtra) return false;
    const auto& s = planetaryProvider->settings;
    if (!s.planet.valid() || s.planet.id.size() > kMaxText || s.planet.name.size() > kMaxText) return false;
    namespace fs = std::filesystem;
    const fs::path destination(path);
    if (destination.empty() || destination.filename().empty()) return false;
    std::error_code ec;
    if (!destination.parent_path().empty()) fs::create_directories(destination.parent_path(), ec);
    if (ec) return false;
    const fs::path temp = destination.string() + ".tmp";
    {
        std::ofstream file(temp, std::ios::binary | std::ios::trunc);
        if (!file) return false;
        Writer w{file};
        file.write(kMagic, 4); w.u32(kVersion);
        if (!w.text(s.planet.id, kMaxText) || !w.text(s.planet.name, kMaxText)) return false;
        w.u64(s.planet.seed);
        w.f64(s.planet.radiusMeters); w.f64(s.planet.surfaceGravity);
        w.f64(s.planet.terrainAmplitudeMeters); w.f64(s.planet.seaLevelMeters);
        w.u8(static_cast<std::uint8_t>(s.planet.projection));
        w.f32(s.hillFrequency); w.f32(s.caveFrequency); w.f32(s.caveAmplitude);
        w.u32(static_cast<std::uint32_t>(editLog.size()));
        for (const auto& op : editLog) {
            if (!writeOp(w, op)) {
                file.close();
                std::error_code cleanupError;
                fs::remove(temp, cleanupError);
                return false;
            }
        }
        if (!w.text(extra, kMaxExtra)) return false;
        file.flush();
        if (!file) return false;
    }
    fs::rename(temp, destination, ec);
    if (ec) { fs::remove(temp, ec); return false; }
    return true;
}

bool ChunkManager::loadPlanetPrototype(const std::string& path) {
    std::error_code ec;
    const auto bytes = std::filesystem::file_size(path, ec);
    if (ec || bytes > (64ull << 20)) return false;
    std::ifstream file(path, std::ios::binary);
    if (!file) return false;
    Reader r{file};
    char magic[4]{}; file.read(magic, 4);
    std::uint32_t version;
    if (!file || std::memcmp(magic, kMagic, 4) != 0 || !r.u32(version) || version != kVersion) return false;
    PlanetaryTerrainSettings settings;
    auto& p = settings.planet;
    std::uint8_t projection;
    if (!r.text(p.id, kMaxText) || !r.text(p.name, kMaxText) || !r.u64(p.seed) ||
        !r.f64(p.radiusMeters) || !r.f64(p.surfaceGravity) ||
        !r.f64(p.terrainAmplitudeMeters) || !r.f64(p.seaLevelMeters) ||
        !r.u8(projection) || projection != static_cast<std::uint8_t>(PlanetProjection::SpherifiedCube) ||
        !r.f32(settings.hillFrequency) || !r.f32(settings.caveFrequency) || !r.f32(settings.caveAmplitude) ||
        !p.valid() || settings.hillFrequency < 0 || settings.caveFrequency < 0 || settings.caveAmplitude < 0) return false;
    p.projection = static_cast<PlanetProjection>(projection);
    std::uint32_t count;
    if (!r.u32(count) || count > kMaxEdits) return false;
    std::vector<EditOp> edits; edits.reserve(count);
    for (std::uint32_t i=0;i<count;++i) {
        EditOp op;
        if (!readOp(r, op, prefabLib)) return false;
        setBounds(op);
        edits.push_back(std::move(op));
    }
    std::string sceneExtra;
    if (!r.text(sceneExtra, kMaxExtra)) return false;
    if (file.peek() != std::char_traits<char>::eof()) return false;
    // Transactional load: no world state changes until every byte is valid.
    startPlanetaryPrototype(settings);
    editLog = std::move(edits);
    redoStack.clear();
    extra = std::move(sceneExtra);
    ++rev;
    return true;
}

} // namespace px
