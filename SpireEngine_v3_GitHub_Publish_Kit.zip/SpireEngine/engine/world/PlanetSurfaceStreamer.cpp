#include "PlanetSurfaceStreamer.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <utility>

namespace px {

PlanetSurfaceStreamer::PlanetSurfaceStreamer(unsigned workerCount, std::size_t maxBuffered)
    : maxBuffered_(std::max<std::size_t>(1, maxBuffered)) {
    workerCount = std::clamp(workerCount, 1u, 16u);
    threads_.reserve(workerCount);
    for (unsigned i = 0; i < workerCount; ++i)
        threads_.emplace_back([this] { workerLoop(); });
}

PlanetSurfaceStreamer::~PlanetSurfaceStreamer() {
    {
        std::lock_guard lock(mutex_);
        stopping_ = true;
        jobs_.clear();
        completed_.clear();
    }
    wake_.notify_all();
    for (auto& thread : threads_) thread.join();
}

bool PlanetSurfaceStreamer::configure(const PlanetDefinition& planet,
        std::uint16_t resolution, double skirtDepthMeters, PlanetReliefSampler sampler) {
    if (!planet.valid() || !std::isfinite(planet.radiusMeters) ||
        !std::isfinite(planet.terrainAmplitudeMeters) ||
        !std::isfinite(planet.surfaceGravity) || !std::isfinite(planet.seaLevelMeters) ||
        resolution < 2 || resolution > 256 || !sampler ||
        !std::isfinite(skirtDepthMeters) || skirtDepthMeters < 0 ||
        skirtDepthMeters > 100000.0 || skirtDepthMeters > planet.radiusMeters * 0.5)
        return false;
    auto next = std::make_shared<Config>();
    next->planet = planet;
    next->resolution = resolution;
    next->skirt = skirtDepthMeters;
    next->sampler = std::move(sampler);
    {
        std::lock_guard lock(mutex_);
        ++epoch_;
        config_ = std::move(next);
        desired_.clear();
        pending_.clear();
        ready_.clear();
        jobs_.clear();
        completed_.clear();
    }
    wake_.notify_all();
    return true;
}

bool PlanetSurfaceStreamer::setSelection(const std::vector<CubeTileCoord>& tiles) {
    // Check input without changing the current selection on invalid requests.
    if (tiles.size() > 4096) return false;
    std::unordered_set<CubeTileCoord, CubeTileHash> next;
    next.reserve(tiles.size());
    for (const auto& t : tiles)
        if (validateTile(t) != TileError::Ok || !next.insert(t).second) return false;
    {
        std::lock_guard lock(mutex_);
        if (!config_) return false;
        desired_ = std::move(next);
        for (auto it = ready_.begin(); it != ready_.end();) {
            if (!desired_.contains(it->first)) it = ready_.erase(it);
            else ++it;
        }
        // Drop obsolete waiting jobs; only in-flight jobs remain in pending_.
        for (auto it = jobs_.begin(); it != jobs_.end();) {
            if (!desired_.contains(it->tile)) {
                pending_.erase(it->tile);
                it = jobs_.erase(it);
            } else ++it;
        }
        // Input order is significant: callers can prioritize near-screen tiles.
        for (const auto& t : tiles) {
            if (!ready_.contains(t) && pending_.insert(t).second)
                jobs_.push_back(Job{t, epoch_, config_});
        }
    }
    wake_.notify_all();
    return true;
}

std::size_t PlanetSurfaceStreamer::collect(std::size_t maxCount) {
    std::size_t accepted = 0;
    {
        std::lock_guard lock(mutex_);
        for (std::size_t i = 0; i < maxCount && !completed_.empty(); ++i) {
            Result result = std::move(completed_.front());
            completed_.pop_front();
            if (result.epoch != epoch_) { ++discarded_; continue; }
            pending_.erase(result.tile);
            if (!desired_.contains(result.tile)) { ++discarded_; continue; }
            if (!result.patch) { ++failed_; continue; }
            ready_[result.tile] = std::move(result.patch);
            ++accepted;
            ++generated_;
        }
    }
    wake_.notify_all();
    return accepted;
}

std::shared_ptr<const PlanetSurfacePatch> PlanetSurfaceStreamer::findReady(
        const CubeTileCoord& tile) const {
    std::lock_guard lock(mutex_);
    const auto it = ready_.find(tile);
    return it == ready_.end() ? nullptr : it->second;
}

std::vector<CubeTileCoord> PlanetSurfaceStreamer::readyTiles() const {
    std::vector<CubeTileCoord> out;
    {
        std::lock_guard lock(mutex_);
        out.reserve(ready_.size());
        for (const auto& [tile, mesh] : ready_) out.push_back(tile);
    }
    std::sort(out.begin(), out.end(), [](const CubeTileCoord& a, const CubeTileCoord& b) {
        if (a.face != b.face) return a.face < b.face;
        if (a.level != b.level) return a.level < b.level;
        if (a.x != b.x) return a.x < b.x;
        return a.y < b.y;
    });
    return out;
}

PlanetSurfaceStreamStats PlanetSurfaceStreamer::stats() const {
    std::lock_guard lock(mutex_);
    return {desired_.size(), ready_.size(), pending_.size(), jobs_.size(),
        completed_.size(), generated_, discarded_, failed_};
}

void PlanetSurfaceStreamer::workerLoop() {
    while (true) {
        Job job;
        {
            std::unique_lock lock(mutex_);
            wake_.wait(lock, [this] {
                return stopping_ || (!jobs_.empty() && completed_.size() < maxBuffered_);
            });
            if (stopping_) return;
            job = std::move(jobs_.front());
            jobs_.pop_front();
        }
        auto patch = std::make_shared<PlanetSurfacePatch>();
        bool ok = false;
        try {
            ok = buildPlanetSurfacePatch(job.tile, job.config->planet,
                job.config->resolution, job.config->skirt, job.config->sampler, *patch);
        } catch (...) { ok = false; } // A bad user sampler must not kill the worker thread.
        {
            std::unique_lock lock(mutex_);
            // Obsolete work is discarded BEFORE hitting the completed queue cap.
            if (stopping_) return;
            if (job.epoch != epoch_ || !desired_.contains(job.tile)) {
                if (job.epoch == epoch_) pending_.erase(job.tile);
                ++discarded_;
                continue;
            }
            wake_.wait(lock, [this, &job] {
                return stopping_ || job.epoch != epoch_ ||
                    !desired_.contains(job.tile) || completed_.size() < maxBuffered_;
            });
            if (stopping_) return;
            if (job.epoch != epoch_ || !desired_.contains(job.tile)) {
                if (job.epoch == epoch_) pending_.erase(job.tile);
                ++discarded_;
                continue;
            }
            completed_.push_back(Result{job.tile, job.epoch, ok ? std::move(patch) : nullptr});
        }
        wake_.notify_all();
    }
}

} // namespace px
