#pragma once
// Streams chunks around the camera using a pool of background worker threads,
// and owns the world edit log.
//
// Threading rules (keep these when extending):
//   * activeChunks / editLog are only touched on the main thread.
//   * Workers receive a self-contained Job (coords + immutable generator +
//     a copy of the edits that touch that chunk) and hand back a finished
//     VoxelChunk. They never read the live world.
//   * No OpenGL here at all; the renderer uploads meshes on the main thread.
//
// Every sculpt / stamp is recorded in an edit log and replayed whenever a
// chunk is (re)generated, so edits survive unloading, regeneration and
// save/load.
#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <glm/glm.hpp>
#include "VoxelChunk.h"
#include "TerrainGenerator.h"
#include "TerrainProvider.h"
#include "PrefabLibrary.h"

namespace px {

struct EditOp {
    // Append new kinds at the end: the value is stored in world saves.
    enum class Kind : std::uint8_t { Sphere, Stamp, Flatten, Paint, Smooth } kind = Kind::Sphere;
    glm::vec3  center{0.0f};   // sphere centre, or stamp anchor
    float      radius = 0.0f;
    CsgMode    mode   = CsgMode::Subtract;
    MaterialId material = MAT_STONE;    // Build (union) and Paint
    float      strength = 0.0f;         // Smooth
    PrefabPtr  prefab;                  // Stamp
    std::shared_ptr<const DeltaGrid> delta;   // Smooth: the computed result
    glm::vec3  boundsMin{0.0f}, boundsMax{0.0f};
};

struct RayHit {
    glm::vec3 position{0.0f};
    glm::vec3 normal{0.0f, 1.0f, 0.0f};
    float     distance = 0.0f;
};

class ChunkManager {
public:
    explicit ChunkManager(PrefabLibrary& prefabs);
    ~ChunkManager();

    void start(const TerrainSettings& settings, unsigned workerCount = 0);
    // Experimental opt-in local spherical world. Existing flat-world start(),
    // world saves, and editor defaults are not modified.
    void startPlanetaryPrototype(const PlanetaryTerrainSettings& settings, unsigned workerCount = 0);
    bool isPlanetaryPrototype() const noexcept { return static_cast<bool>(planetaryProvider); }
    // Discard only the active planet edits, keeping its radial terrain settings
    // and the saved flat-world edit backup untouched.
    bool clearPlanetEdits();
    const PlanetaryTerrainSettings* currentPlanetSettings() const noexcept {
        return planetaryProvider ? &planetaryProvider->settings : nullptr;
    }
    // Planet-relative up for future character/camera integrations; legacy Y-up
    // remains unchanged unless prototype mode is explicitly activated.
    glm::vec3 localUp(const glm::vec3& position) const noexcept;
    void stop();

    // Call once per frame on the main thread.
    void update(const glm::vec3& cameraPos);

    // Changing settings regenerates every chunk (edits are kept and replayed).
    void setSettings(const TerrainSettings& s);
    const TerrainSettings& settings() const { return generator->settings; }
    const TerrainGenerator& terrain() const { return *generator; }

    // Called on the main thread after every new edit (tools, powers, stamps) that changed
    // the world; not for undo/redo or loading. The engine uses it for edit sounds.
    std::function<void(const EditOp&)> onEdit;

    static constexpr int kDefaultLoadRadius = 5;
    int loadRadius     = kDefaultLoadRadius;   // flat chunks, horizontal
    int planetLoadRadius = 2;                  // 3D spherical prototype, max 4
    int minChunkY      = 0;
    int maxChunkY      = 2;   // world height = 3 chunks = 96 voxels

    // --- Queries ---
    float density(const glm::vec3& p) const;             // trilinear, +1 if not loaded
    glm::vec3 densityGradient(const glm::vec3& p) const;
    bool isLoaded(const glm::vec3& p) const;
    bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDist, RayHit& hit) const;

    // --- Edits (main thread) ---
    void applySphere(const glm::vec3& center, float radius, CsgMode mode, MaterialId material = MAT_STONE);
    void flatten(const glm::vec3& center, float radius);
    void paint(const glm::vec3& center, float radius, MaterialId material);
    // Relax bumps and sharp edges inside the sphere. strength 0..1 per application.
    bool smooth(const glm::vec3& center, float radius, float strength);
    MaterialId materialAt(const glm::vec3& p) const;   // nearest sample, MAT_NATURAL if not loaded
    // What the ground at/below p looks like (never MAT_NATURAL unless nothing is loaded
    // there): used for footsteps, impact sounds and gameplay that cares about the surface.
    MaterialId surfaceMaterialAt(const glm::vec3& p) const;
    bool stamp(const std::string& prefabName, const glm::vec3& anchor);
    bool undo();
    bool redo();
    bool canUndo() const { return !editLog.empty(); }
    bool canRedo() const { return !redoStack.empty(); }
    std::shared_ptr<Prefab> bake(const glm::vec3& center, int radius, const std::string& name) const;
    void clearEdits();
    // Something other than the terrain (an object was placed...) changed history: what was undone
    // can no longer be redone.
    void clearRedo() { redoStack.clear(); }

    // --- Persistence ---
    // Extra data saved with the world and handed back on load: the engine keeps the scene (placed
    // objects) here. Changing it counts as a change to the world, so saving and autosave notice.
    void setExtraBlob(std::string blob) { if (blob != extra) { extra = std::move(blob); ++rev; } }
    const std::string& extraBlob() const { return extra; }
    bool saveWorld(const std::string& path) const;
    bool loadWorld(const std::string& path);
    // Local planetary prototype format. Distinct from legacy .vxworld; saves
    // planet settings, terrain edit replay and the optional scene blob.
    bool savePlanetPrototype(const std::string& path) const;
    bool loadPlanetPrototype(const std::string& path);

    // --- Stats / access for renderer & UI ---
    const std::unordered_map<glm::ivec3, std::unique_ptr<VoxelChunk>, IVec3Hash>& chunks() const { return activeChunks; }
    size_t pendingCount() const { return pending.size(); }
    size_t editCount() const { return editLog.size(); }
    std::uint32_t generation() const { return worldGeneration; }
    // Bumps on every change to the world (edit, undo, redo, clear, new settings, load). Autosave
    // compares it with the revision it last saved to know whether there is anything new.
    std::uint64_t revision() const { return rev; }

private:
    struct Job {
        glm::ivec3 coord;
        std::uint32_t generation;
        std::shared_ptr<const TerrainGenerator> gen;
        std::shared_ptr<const PlanetaryTerrainProvider> planetGen;
        std::vector<PrefabPtr> scatter;
        std::vector<EditOp> edits;
        size_t editCountAtSnapshot;
        std::uint32_t editEpoch;
    };
    struct Result {
        std::unique_ptr<VoxelChunk> chunk;
        std::uint32_t generation;
        size_t editCountAtSnapshot;
        std::uint32_t editEpoch;
    };

    void workerLoop();
    static void buildChunk(VoxelChunk& c, const Job& job);
    static bool applyEdit(VoxelChunk& c, const EditOp& op);
    bool recordAndApply(EditOp op, bool clearRedo = true);
    Job makeJob(const glm::ivec3& coord) const;
    void rebuildRegion(const glm::vec3& mn, const glm::vec3& mx);
    bool inRange(const glm::ivec3& c, const glm::ivec3& center) const;
    float sampleGrid(int x, int y, int z) const;
    MaterialId sampleMaterial(int x, int y, int z) const;
    static void setBounds(EditOp& op);

    PrefabLibrary& prefabLib;
    std::shared_ptr<const TerrainGenerator> generator;
    std::shared_ptr<const PlanetaryTerrainProvider> planetaryProvider;
    // Do not let experimental planet sculpt edits leak into legacy world saves.
    std::vector<EditOp> savedFlatEdits;
    std::vector<EditOp> savedFlatRedo;
    bool haveFlatEditBackup = false;
    void leavePlanetaryPrototype();
    void launchWorkers(unsigned workerCount);
    std::uint32_t worldGeneration = 0;

    std::unordered_map<glm::ivec3, std::unique_ptr<VoxelChunk>, IVec3Hash> activeChunks;
    std::unordered_set<glm::ivec3, IVec3Hash> pending;
    std::vector<EditOp> editLog;
    std::vector<EditOp> redoStack;
    std::uint32_t editEpoch = 0;   // bumped on undo: in-flight jobs become stale
    std::uint64_t rev = 0;
    std::string extra;

    std::vector<std::thread> workers;
    std::deque<Job> jobs;
    std::mutex jobMutex;
    std::condition_variable jobCv;
    std::vector<Result> results;
    std::mutex resultMutex;
    std::atomic<bool> running{false};
    std::atomic<int> camChunkX{0}, camChunkY{0}, camChunkZ{0};
};

} // namespace px
