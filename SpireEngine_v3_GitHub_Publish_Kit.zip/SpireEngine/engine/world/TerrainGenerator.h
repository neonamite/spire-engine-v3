#pragma once
// Procedural density function. Immutable after construction, so worker threads
// can share one instance safely. Changing settings = build a new generator.
#include <cstdint>
#include <glm/glm.hpp>
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Waggressive-loop-optimizations"   // third-party header, harmless
#endif
#include "FastNoiseLite.h"
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic pop
#endif

namespace px {

struct TerrainSettings {
    std::uint32_t seed      = 1337;
    float baseHeight        = 40.0f;  // average ground level (world Y)
    float hillFrequency     = 0.008f;
    float hillAmplitude     = 22.0f;
    float caveFrequency     = 0.035f;
    float caveAmplitude     = 9.0f;   // 0 = no caves/overhangs
    float scatterChance     = 0.35f;  // chance a 16x16 cell gets a prop
    bool  scatterProps      = true;
    // Sea level: every air pocket below this height is filled with water.
    // Beaches (sand) form just above it.
    bool  water             = true;
    float waterLevel        = 31.0f;
};

// Heights (world Y) where "Natural" terrain turns into sand below / snow above.
inline float sandLevelFor(const TerrainSettings& s) {
    return s.water ? s.waterLevel + 2.2f : s.baseHeight - s.hillAmplitude * 0.62f;
}
inline float snowLevelFor(const TerrainSettings& s) { return s.baseHeight + s.hillAmplitude * 0.62f; }

class TerrainGenerator {
public:
    explicit TerrainGenerator(const TerrainSettings& s) : settings(s) {
        hills.SetSeed(static_cast<int>(s.seed));
        hills.SetNoiseType(FastNoiseLite::NoiseType_OpenSimplex2);
        hills.SetFractalType(FastNoiseLite::FractalType_FBm);
        hills.SetFractalOctaves(5);
        hills.SetFrequency(s.hillFrequency);

        caves.SetSeed(static_cast<int>(s.seed) + 101);
        caves.SetNoiseType(FastNoiseLite::NoiseType_OpenSimplex2);
        caves.SetFractalType(FastNoiseLite::FractalType_FBm);
        caves.SetFractalOctaves(3);
        caves.SetFrequency(s.caveFrequency);
    }

    // Height of the 2D terrain layer at a column (ignores caves).
    float surfaceHeight(float x, float z) const {
        return settings.baseHeight + hills.GetNoise(x, z) * settings.hillAmplitude;
    }

    // Full 3D density: heightmap ground + 3D noise for overhangs/caves.
    float density(float x, float y, float z) const {
        float d = y - surfaceHeight(x, z);
        if (settings.caveAmplitude > 0.0f) {
            // Only let 3D noise act near/below the surface so the sky stays clear.
            d += caves.GetNoise(x, y, z) * settings.caveAmplitude;
        }
        if (y < 1.0f) d = glm::min(d, y - 1.0f); // bedrock floor, never fall out
        return glm::clamp(d, -8.0f, 8.0f);
    }

    // First solid point scanning down a column (used to sit props on the ground).
    float findGround(float x, float z, float top, float bottom) const {
        for (float y = top; y > bottom; y -= 1.0f)
            if (density(x, y, z) < 0.0f) return y;
        return bottom;
    }

    const TerrainSettings settings;

private:
    FastNoiseLite hills;
    FastNoiseLite caves;
};

} // namespace px
