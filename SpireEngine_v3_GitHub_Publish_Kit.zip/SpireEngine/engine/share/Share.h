#pragma once
// Share (v0.23): a game you made, packed into one folder that anyone can run - no editor, no setup. The folder holds the
// engine program (and the libraries next to it), its fonts, the world, the assets, people and items you made that the
// world uses, a game.pxgame file that says what to open, a "Play" launcher for Windows and for Linux / macOS, and a
// read-me with the controls. When the program starts and finds game.pxgame beside it, it goes straight into the game.
//
// This part is pure: it works out what goes in (a SharePlan) and writes the folder. Unit tested.
#include <cstdint>
#include <set>
#include <string>
#include <vector>
#include "core/Json.h"

namespace px {

struct GameManifest {
    std::string name = "My game";
    std::string author;
    std::string description;
    std::string game = "sandbox";            // which game module ("sandbox" or a registered game's id)
    std::string world;                       // relative path of the world file ("worlds/sandbox/world.vxworld")
    std::string engineVersion;
    std::string created;                     // "2026-10-09"
    bool thirdPerson = false;                // start over the shoulder
    bool operator==(const GameManifest&) const = default;
};

Json manifestToJson(const GameManifest& m);
bool manifestFromJson(const Json& j, GameManifest& out, std::string* error = nullptr);
bool loadManifest(const std::string& path, GameManifest& out, std::string* error = nullptr);
inline constexpr const char* kManifestFile = "game.pxgame";

// What a scene uses: the assets its objects are copies of, and the people standing in it.
struct SceneUses {
    std::set<std::string> assets;
    std::set<std::string> characters;
};
SceneUses sceneUses(const std::string& sceneText);

std::string shareFolderName(const std::string& gameName);        // "Bob's Game!" -> "Bobs_Game"

struct ShareFile { std::string from, to; };                     // a file to copy (to: relative to the package)
struct SharePlan {
    GameManifest manifest;
    std::vector<ShareFile> files;
    std::vector<std::pair<std::string, std::string>> folders;   // whole folders to copy (from, to)
    std::string programName;                                     // the program's file name inside the package ("SpireEngine")
    std::vector<std::string> notes;                              // what to tell the person (things missing, etc.)
};

struct ShareResult {
    bool ok = false;
    std::string error;
    int files = 0;
    std::uintmax_t bytes = 0;
};
// Writes the package into `outDir` (made if needed; an existing package there is replaced).
ShareResult writeShare(const SharePlan& plan, const std::string& outDir);

} // namespace px
