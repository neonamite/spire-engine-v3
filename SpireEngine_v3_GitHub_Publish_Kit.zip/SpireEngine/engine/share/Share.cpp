#include "share/Share.h"
#include <cctype>
#include <filesystem>
#include <fstream>
#include <sstream>
#include "scene/Scene.h"

namespace px {

namespace fs = std::filesystem;

Json manifestToJson(const GameManifest& m) {
    Json j = Json::object();
    j.set("format", "pxgame");
    j.set("version", 1);
    j.set("name", m.name);
    if (!m.author.empty()) j.set("author", m.author);
    if (!m.description.empty()) j.set("description", m.description);
    j.set("game", m.game);
    j.set("world", m.world);
    if (!m.engineVersion.empty()) j.set("engine", m.engineVersion);
    if (!m.created.empty()) j.set("created", m.created);
    if (m.thirdPerson) j.set("thirdPerson", true);
    return j;
}

bool manifestFromJson(const Json& j, GameManifest& out, std::string* error) {
    auto fail = [&](const char* why) { if (error) *error = why; return false; };
    if (!j.isObject()) return fail("not a game file");
    if (j.get("format").str() != "pxgame") return fail("not a Spire Engine game file");
    if (j.get("version").integer(0) > 1) return fail("made by a newer Spire Engine");
    GameManifest m;
    m.name = j.get("name").str("My game").substr(0, 80);
    m.author = j.get("author").str().substr(0, 80);
    m.description = j.get("description").str().substr(0, 400);
    m.game = j.get("game").str("sandbox").substr(0, 64);
    m.world = j.get("world").str();
    if (m.world.empty() || m.world.find("..") != std::string::npos || (!m.world.empty() && (m.world[0] == '/' || m.world[0] == '\\')) || m.world.find(':') != std::string::npos)
        return fail("the world path is missing or points outside the game folder");
    m.engineVersion = j.get("engine").str();
    m.created = j.get("created").str();
    m.thirdPerson = j.get("thirdPerson").boolean(false);
    out = m;
    return true;
}

bool loadManifest(const std::string& path, GameManifest& out, std::string* error) {
    std::ifstream f(path, std::ios::binary);
    if (!f) { if (error) *error = "can't open " + path; return false; }
    std::stringstream ss; ss << f.rdbuf();
    Json j;
    std::string perr;
    if (!Json::parse(ss.str(), j, &perr)) { if (error) *error = "damaged game file: " + perr; return false; }
    return manifestFromJson(j, out, error);
}

SceneUses sceneUses(const std::string& sceneText) {
    SceneUses u;
    Scene s;
    if (sceneText.empty() || !s.fromText(sceneText)) return u;
    for (const SceneObject& o : s.objects()) {
        if (!o.asset.empty()) u.assets.insert(o.asset);
        if (!o.character.empty()) u.characters.insert(o.character);
    }
    return u;
}

std::string shareFolderName(const std::string& gameName) {
    std::string out;
    bool gap = false;
    for (unsigned char c : gameName) {
        if (std::isalnum(c)) { if (gap && !out.empty()) out += '_'; out += char(c); gap = false; }
        else if (c == ' ' || c == '-' || c == '_') gap = true;
    }
    if (out.size() > 48) out.resize(48);
    return out.empty() ? std::string("My_game") : out;
}

namespace {
bool writeText(const fs::path& p, const std::string& text) {
    std::ofstream f(p, std::ios::binary);
    f << text;
    return bool(f);
}
std::string readme(const SharePlan& plan) {
    const GameManifest& m = plan.manifest;
    std::string r;
    r += m.name + "\n" + std::string(m.name.size(), '=') + "\n\n";
    if (!m.author.empty()) r += "Made by " + m.author + " with Spire Engine.\n\n";
    if (!m.description.empty()) r += m.description + "\n\n";
    r += "How to play\n-----------\n";
    r += "Windows: double-click \"Play.bat\".\n";
    r += "Linux / macOS: run ./play.sh (or double-click it).\n\n";
    r += "Controls\n--------\n";
    r += "  WASD      move            Space    jump\n";
    r += "  Shift     run             Mouse    look\n";
    r += "  E         use / talk      V        first or third person\n";
    r += "  1-9       pick an item    Left / right mouse   use the item\n";
    r += "  Esc       pause menu      R        play again (when the game is over)\n";
    return r;
}
} // namespace

ShareResult writeShare(const SharePlan& plan, const std::string& outDir) {
    ShareResult res;
    std::error_code ec;
    const fs::path root(outDir);
    // replace an earlier package (only if it looks like one: never wipe a folder that isn't ours)
    if (fs::exists(root, ec)) {
        if (!fs::exists(root / kManifestFile, ec) && !fs::is_empty(root, ec)) { res.error = "the folder is not empty and is not a Spire Engine game: " + outDir; return res; }
        fs::remove_all(root, ec);
    }
    fs::create_directories(root, ec);
    if (ec) { res.error = "can't make the folder " + outDir + ": " + ec.message(); return res; }
    auto copyOne = [&](const fs::path& from, const fs::path& to) {
        std::error_code e;
        fs::create_directories(to.parent_path(), e);
        if (!fs::copy_file(from, to, fs::copy_options::overwrite_existing, e)) { res.error = "can't copy " + from.string() + ": " + e.message(); return false; }
        ++res.files;
        res.bytes += fs::file_size(to, e);
        return true;
    };
    for (const ShareFile& f : plan.files)
        if (!copyOne(f.from, root / f.to)) return res;
    for (const auto& [from, to] : plan.folders) {
        if (!fs::is_directory(from, ec)) continue;
        for (const auto& e : fs::recursive_directory_iterator(from, ec)) {
            if (!e.is_regular_file()) continue;
            if (!copyOne(e.path(), root / to / fs::relative(e.path(), from, ec))) return res;
        }
    }
    // keep the program runnable
    if (!plan.programName.empty() && fs::exists(root / plan.programName, ec))
        fs::permissions(root / plan.programName, fs::perms::owner_exec | fs::perms::group_exec | fs::perms::others_exec, fs::perm_options::add, ec);
    // what to open, how to start it, and how to play
    if (!writeText(root / kManifestFile, manifestToJson(plan.manifest).dump(2))) { res.error = "can't write game.pxgame"; return res; }
    const std::string prog = plan.programName.empty() ? std::string("SpireEngine") : plan.programName;
    writeText(root / "play.sh", "#!/bin/sh\ncd \"$(dirname \"$0\")\"\nexec ./" + prog + " --play game.pxgame \"$@\"\n");
    fs::permissions(root / "play.sh", fs::perms::owner_exec | fs::perms::group_exec | fs::perms::others_exec, fs::perm_options::add, ec);
    writeText(root / "Play.bat", "@echo off\r\ncd /d \"%~dp0\"\r\nstart \"\" \"" + prog + (prog.size() > 4 && prog.substr(prog.size() - 4) == ".exe" ? "" : ".exe") + "\" --play game.pxgame\r\n");
    writeText(root / "README.txt", readme(plan));
    res.files += 4;
    res.ok = true;
    return res;
}

} // namespace px
