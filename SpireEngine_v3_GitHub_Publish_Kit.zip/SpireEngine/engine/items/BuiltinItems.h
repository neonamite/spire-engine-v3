#pragma once
// The items that ship with the engine: a pistol, a rifle, a sword, a rocket launcher, a grenade and a
// terraforming pick. Each has a model (built here out of fine voxels, like anything made in the Asset
// Workshop) and a behaviour. They give every new game something to hold, and they are the examples to
// copy: open one in the Workshop and "Make my own version".
#include "items/Item.h"
#include "scene/Asset.h"

namespace px {

void registerBuiltinItems(ItemLibrary& items, AssetLibrary& assets);

} // namespace px
