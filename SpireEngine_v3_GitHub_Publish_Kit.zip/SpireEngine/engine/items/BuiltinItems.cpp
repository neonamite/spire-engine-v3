#include "items/BuiltinItems.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include "workshop/Workshop.h"

namespace px {

namespace {

float roundedBox(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
float capsule(const glm::vec3& p, const glm::vec3& a, const glm::vec3& b, float r) {
    const glm::vec3 pa = p - a, ba = b - a;
    const float h = std::clamp(glm::dot(pa, ba) / std::max(1e-9f, glm::dot(ba, ba)), 0.0f, 1.0f);
    return glm::length(pa - ba * h) - r;
}
float ellipsoid(const glm::vec3& q, const glm::vec3& half) {
    const float k0 = glm::length(q / half), k1 = glm::length(q / (half * half));
    return k1 < 1e-9f ? -std::min(half.x, std::min(half.y, half.z)) : k0 * (k0 - 1.0f) / k1;
}

// A small sculpting kit around a Workshop, so each model below reads like a parts list.
struct Sculptor {
    Workshop w;
    explicit Sculptor(const NewAssetSpec& spec) { w.create(spec); }

    void box(glm::vec3 c, glm::vec3 half, float round, MaterialId m, float blend = 0.0f) {
        w.stampSdf([=](const glm::vec3& p) { return roundedBox(p - c, half, round); }, c - half - glm::vec3(0.05f), c + half + glm::vec3(0.05f), StampMode::Add, m, blend);
    }
    void rod(glm::vec3 a, glm::vec3 b, float r, MaterialId m, float blend = 0.0f) {
        w.stampSdf([=](const glm::vec3& p) { return capsule(p, a, b, r); }, glm::min(a, b) - glm::vec3(r + 0.05f), glm::max(a, b) + glm::vec3(r + 0.05f), StampMode::Add, m, blend);
    }
    void blob(glm::vec3 c, glm::vec3 half, MaterialId m, float blend = 0.0f) {
        w.stampSdf([=](const glm::vec3& p) { return ellipsoid(p - c, half); }, c - half - glm::vec3(0.05f), c + half + glm::vec3(0.05f), StampMode::Add, m, blend);
    }
    AssetPtr finish(const std::string& name, AssetType type) {
        w.remesh();
        w.asset.name = name;
        w.asset.type = type;
        w.asset.userMade = false;                 // it ships with the engine: not a file
        return std::make_shared<Asset>(w.asset);
    }
};

AssetPtr templateAsset(WorkshopTemplate t, const std::string& name) {
    NewAssetSpec spec;
    spec.name = name; spec.tmpl = t;
    Workshop w;
    w.create(spec);
    w.remesh();
    w.asset.name = name;
    w.asset.userMade = false;
    return std::make_shared<Asset>(w.asset);
}

AssetPtr buildRifle() {
    NewAssetSpec s; s.name = "rifle"; s.voxelSize = 0.015625f; s.sizeMetres = { 1.4f, 0.45f, 0.18f };
    Sculptor k(s);
    const MaterialId metal = MAT_PAINT_BLACK, steel = MAT_STEEL, wood = MAT_WOOD;   // a black matte finish, a bright steel barrel
    k.box({ 0.04f, 0.185f, 0 }, { 0.17f, 0.036f, 0.021f }, 0.01f, metal);              // receiver
    k.box({ 0.05f, 0.225f, 0 }, { 0.12f, 0.010f, 0.012f }, 0.004f, metal);             // top rail
    k.rod({ 0.20f, 0.19f, 0 }, { 0.56f, 0.19f, 0 }, 0.0105f, steel);                  // barrel
    k.rod({ 0.52f, 0.19f, 0 }, { 0.58f, 0.19f, 0 }, 0.016f, metal);                   // muzzle brake
    k.box({ 0.29f, 0.178f, 0 }, { 0.09f, 0.027f, 0.025f }, 0.012f, wood);             // handguard
    k.box({ -0.24f, 0.165f, 0 }, { 0.15f, 0.040f, 0.019f }, 0.012f, wood);            // stock
    k.box({ -0.38f, 0.135f, 0 }, { 0.025f, 0.060f, 0.021f }, 0.01f, metal);           // butt plate
    k.box({ -0.045f, 0.095f, 0 }, { 0.018f, 0.052f, 0.017f }, 0.008f, wood);          // grip
    k.box({ 0.075f, 0.105f, 0 }, { 0.018f, 0.062f, 0.014f }, 0.005f, metal);          // magazine
    k.box({ 0.012f, 0.145f, 0 }, { 0.040f, 0.005f, 0.012f }, 0.003f, metal);          // trigger guard
    k.box({ 0.02f, 0.245f, 0 }, { 0.016f, 0.014f, 0.008f }, 0.004f, metal);           // rear sight
    k.box({ 0.50f, 0.222f, 0 }, { 0.006f, 0.016f, 0.006f }, 0.002f, metal);           // front sight
    k.w.addSocket("grip",   { -0.045f, 0.10f, 0 }, { 0, 1, 0 });
    k.w.addSocket("muzzle", { 0.585f, 0.19f, 0 },  { 1, 0, 0 });
    k.w.addSocket("sight",  { 0.02f, 0.26f, 0 },   { 0, 1, 0 });
    return k.finish("rifle", AssetType::Item);
}

AssetPtr buildLauncher() {
    NewAssetSpec s; s.name = "rocket_launcher"; s.voxelSize = 0.015625f; s.sizeMetres = { 1.6f, 0.5f, 0.3f };
    Sculptor k(s);
    const MaterialId metal = MAT_METAL, wood = MAT_WOOD, red = MAT_BRICK;
    k.rod({ -0.40f, 0.22f, 0 }, { 0.55f, 0.22f, 0 }, 0.062f, metal, 0.01f);           // the tube
    k.rod({ 0.50f, 0.22f, 0 }, { 0.58f, 0.22f, 0 }, 0.075f, metal);                    // flared mouth
    k.rod({ -0.42f, 0.22f, 0 }, { -0.36f, 0.22f, 0 }, 0.080f, metal);                  // rear flare
    k.rod({ 0.30f, 0.22f, 0 }, { 0.36f, 0.22f, 0 }, 0.068f, red);                      // a red band
    k.rod({ -0.20f, 0.22f, 0 }, { -0.14f, 0.22f, 0 }, 0.068f, red);
    k.box({ 0.0f, 0.115f, 0 }, { 0.018f, 0.070f, 0.018f }, 0.008f, wood);              // grip
    k.box({ 0.22f, 0.135f, 0 }, { 0.016f, 0.050f, 0.016f }, 0.008f, wood);             // foregrip
    k.box({ -0.05f, 0.305f, 0 }, { 0.050f, 0.016f, 0.012f }, 0.005f, metal);           // sight
    k.box({ -0.10f, 0.28f, 0 }, { 0.040f, 0.010f, 0.030f }, 0.005f, metal);            // shoulder pad
    k.w.addSocket("grip",   { 0.0f, 0.12f, 0 },   { 0, 1, 0 });
    k.w.addSocket("muzzle", { 0.60f, 0.22f, 0 },  { 1, 0, 0 });
    k.w.addSocket("sight",  { -0.05f, 0.33f, 0 }, { 0, 1, 0 });
    return k.finish("rocket_launcher", AssetType::Item);
}

AssetPtr buildGrenade() {
    NewAssetSpec s; s.name = "grenade"; s.voxelSize = 0.01f; s.sizeMetres = { 0.22f, 0.22f, 0.22f };
    Sculptor k(s);
    k.blob({ 0, 0.065f, 0 }, { 0.050f, 0.060f, 0.050f }, MAT_METAL, 0.01f);            // body
    k.box({ 0, 0.128f, 0 }, { 0.016f, 0.016f, 0.016f }, 0.005f, MAT_METAL);            // fuse housing
    k.box({ 0.030f, 0.105f, 0 }, { 0.006f, 0.040f, 0.014f }, 0.003f, MAT_BRICK);       // the lever
    k.w.addSocket("grip", { 0, 0.07f, 0 }, { 0, 1, 0 });
    return k.finish("grenade", AssetType::Item);
}

AssetPtr buildPick() {
    NewAssetSpec s; s.name = "terraformer"; s.voxelSize = 0.015625f; s.sizeMetres = { 0.6f, 1.0f, 0.16f };
    Sculptor k(s);
    k.rod({ 0, 0.02f, 0 }, { 0, 0.80f, 0 }, 0.016f, MAT_WOOD, 0.004f);                 // handle
    k.rod({ 0, 0.83f, 0 }, { 0.20f, 0.75f, 0 }, 0.022f, MAT_METAL, 0.01f);             // the two arms of the head
    k.rod({ 0, 0.83f, 0 }, { -0.20f, 0.75f, 0 }, 0.022f, MAT_METAL, 0.01f);
    k.box({ 0, 0.82f, 0 }, { 0.030f, 0.030f, 0.024f }, 0.01f, MAT_METAL);              // the hub
    k.rod({ 0, 0.16f, 0 }, { 0, 0.34f, 0 }, 0.021f, MAT_BRICK, 0.004f);                // a red grip wrap
    k.w.addSocket("grip", { 0, 0.26f, 0 }, { 0, 1, 0 });
    k.w.addSocket("tip",  { 0.215f, 0.74f, 0 }, { 1, 0, 0 });
    return k.finish("terraformer", AssetType::Item);
}

} // namespace

void registerBuiltinItems(ItemLibrary& items, AssetLibrary& assets) {
    assets.add(templateAsset(WorkshopTemplate::Pistol, "pistol"));
    assets.add(buildRifle());
    assets.add(templateAsset(WorkshopTemplate::Sword, "sword"));
    assets.add(buildLauncher());
    assets.add(buildGrenade());
    assets.add(buildPick());

    auto add = [&](ItemDef d, const std::string& text) { d.description = text; d.userMade = false; items.add(std::move(d)); };

    {   // Pistol: semi-automatic, small dents
        ItemDef d = ItemDef::defaultsFor(Behaviour::Hitscan, "Pistol", "pistol");
        d.hold.offset = { 0.22f, -0.19f, 0.48f }; d.hold.rotation = { 28.0f, -4.0f, 0.0f }; d.hold.scale = 0.9f;
        add(d, "A reliable sidearm. One shot per click, twelve to a magazine.");
    }
    {   // Rifle: automatic
        ItemDef d = ItemDef::defaultsFor(Behaviour::Hitscan, "Rifle", "rifle");
        d.stats.damage = 14; d.stats.fireRate = 9; d.stats.automatic = true; d.stats.magazine = 30; d.stats.reloadTime = 2.0f;
        d.stats.spread = 1.1f; d.stats.recoil = 0.9f; d.stats.range = 220;
        d.effect.radius = 0.45f; d.feel.pitch = 0.92f;
        d.hold.offset = { 0.20f, -0.19f, 0.56f }; d.hold.scale = 0.8f;
        add(d, "Hold the button to keep firing. Thirty rounds, a little recoil.");
    }
    {   // Sword
        ItemDef d = ItemDef::defaultsFor(Behaviour::Melee, "Sword", "sword");
        d.hold.offset = { 0.30f, -0.50f, 0.80f }; d.hold.rotation = { -10.0f, 0.0f, 6.0f }; d.hold.scale = 0.8f;
        add(d, "Swing it at things within reach.");
    }
    {   // Rocket launcher
        ItemDef d = ItemDef::defaultsFor(Behaviour::Projectile, "Rocket Launcher", "rocket_launcher");
        d.hold.offset = { 0.24f, -0.22f, 0.62f }; d.hold.scale = 0.6f;
        add(d, "Fires a rocket that digs a big crater and throws you if you stand too close.");
    }
    {   // Grenade
        ItemDef d = ItemDef::defaultsFor(Behaviour::Thrown, "Grenade", "grenade");
        d.hold.offset = { 0.20f, -0.17f, 0.46f }; d.hold.scale = 0.9f;
        add(d, "Throw it. It bounces, then goes off after two seconds.");
    }
    {   // Terraformer
        ItemDef d = ItemDef::defaultsFor(Behaviour::Tool, "Terraformer", "terraformer");
        d.hold.offset = { 0.30f, -0.44f, 0.74f }; d.hold.rotation = { 0.0f, 0.0f, 0.0f }; d.hold.scale = 0.8f;
        add(d, "Left button digs, right button builds up stone. Hold to keep going.");
    }
}

} // namespace px
