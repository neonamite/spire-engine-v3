#include "items/ItemSystem.h"
#include <algorithm>
#include <cmath>
#include <imgui.h>
#include <glm/gtc/constants.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {

constexpr float kPi = 3.14159265358979f;

float smooth01(float t) { t = std::clamp(t, 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }

glm::mat4 rotX(float deg) { return glm::rotate(glm::mat4(1.0f), glm::radians(deg), glm::vec3(1, 0, 0)); }
glm::mat4 rotY(float deg) { return glm::rotate(glm::mat4(1.0f), glm::radians(deg), glm::vec3(0, 1, 0)); }
glm::mat4 rotZ(float deg) { return glm::rotate(glm::mat4(1.0f), glm::radians(deg), glm::vec3(0, 0, 1)); }

glm::vec3 safeNormalize(const glm::vec3& v, const glm::vec3& fallback) {
    const float l = glm::length(v);
    return l > 1e-6f ? v / l : fallback;
}

// The rotation that turns a model so that its `forward` axis points away from the viewer and its `up` axis points up.
glm::mat3 alignment(const glm::vec3& forward, const glm::vec3& up) {
    const glm::vec3 f = safeNormalize(forward, glm::vec3(1, 0, 0));
    glm::vec3 u = safeNormalize(up, glm::vec3(0, 1, 0));
    if (std::fabs(glm::dot(u, f)) > 0.95f) u = std::fabs(f.y) < 0.9f ? glm::vec3(0, 1, 0) : glm::vec3(0, 0, 1);
    const glm::vec3 r = safeNormalize(glm::cross(f, u), glm::vec3(0, 0, 1));
    const glm::vec3 u2 = glm::cross(r, f);
    return glm::transpose(glm::mat3(r, u2, -f));
}

const Socket* findSocket(const Asset& a, const char* name) {
    for (const Socket& s : a.sockets) if (s.name == name) return &s;
    return nullptr;
}

float impactPitch(MaterialId m) {
    switch (m) {
    case MAT_METAL: return 1.6f;
    case MAT_WOOD:  return 1.0f;
    case MAT_BRICK: return 1.15f;
    case MAT_STONE: return 1.05f;
    case MAT_SNOW:  return 0.7f;
    case MAT_SAND:  return 0.75f;
    case MAT_DIRT:  return 0.8f;
    case MAT_GRASS: return 0.8f;
    default:        return 0.95f;
    }
}

} // namespace

ItemView ItemView::fromAngles(const glm::vec3& eye, float yawDeg, float pitchDeg, float walkSpeed) {
    const float y = glm::radians(yawDeg), p = glm::radians(pitchDeg);
    ItemView v;
    v.eye = eye;
    v.forward = glm::normalize(glm::vec3(std::cos(y) * std::cos(p), std::sin(p), std::sin(y) * std::cos(p)));
    v.right = glm::normalize(glm::cross(v.forward, glm::vec3(0, 1, 0)));
    v.up = glm::cross(v.right, v.forward);
    v.walkSpeed = walkSpeed;
    return v;
}

// ------------------------------------------------------------------ the hotbar

void ItemSystem::setHotbar(const std::vector<std::string>& names, int select_) {
    slots.clear();
    for (const std::string& n : names) {
        if (int(slots.size()) >= kMaxSlots) break;
        const ItemDef* d = library ? library->find(n) : nullptr;
        slots.push_back({ n, d ? d->stats.magazine : 0 });
    }
    current = slots.empty() ? -1 : std::clamp(select_, 0, int(slots.size()) - 1);
    equipT = 0.0f; reloadLeft = 0.0f; swingT = -1.0f; cooldown = 0.0f;
}

int ItemSystem::give(const std::string& item, bool selectIt) {
    const ItemDef* d = library ? library->find(item) : nullptr;
    int at = -1;
    for (int i = 0; i < int(slots.size()); ++i) if (slots[i].item == item) { at = i; break; }
    if (at < 0) {
        if (int(slots.size()) >= kMaxSlots) return -1;
        slots.push_back({ item, 0 });
        at = int(slots.size()) - 1;
    }
    slots[at].ammo = d ? d->stats.magazine : 0;
    if (selectIt) select(at);
    return at;
}

void ItemSystem::select(int s) {
    if (s < 0 || s >= int(slots.size()) || s == current) return;
    current = s;
    equipT = 0.0f; reloadLeft = 0.0f; swingT = -1.0f; cooldown = std::max(cooldown, 0.1f);
}

void ItemSystem::cycle(int direction) {
    const int n = int(slots.size());
    if (n == 0) return;
    int next = current < 0 ? 0 : (current + direction) % n;
    if (next < 0) next += n;
    select(next);
}

void ItemSystem::reset() {
    flying.clear(); fx.clear();
    held[0] = held[1] = false; pressBuffer[0] = pressBuffer[1] = 0.0f;
    cooldown = 0.0f; reloadLeft = 0.0f; swingT = -1.0f; equipT = 0.0f;
    pendingKick = recovering = kickOut = 0.0f; shake = 0.0f; hitmarkerT = 0.0f; kickAnim = 0.0f;
    reloadRequested = false;
}

void ItemSystem::pressTrigger(int button) {
    if (button < 0 || button > 1) return;
    held[button] = true;
    pressBuffer[button] = 0.14f;
}
void ItemSystem::releaseTrigger(int button) { if (button >= 0 && button <= 1) held[button] = false; }
void ItemSystem::reload() { reloadRequested = true; }

// ------------------------------------------------------------------ questions

const ItemDef* ItemSystem::defAt(int s) const {
    if (!library || s < 0 || s >= int(slots.size())) return nullptr;
    return library->find(slots[s].item);
}
const ItemDef* ItemSystem::currentDef() const { return defAt(current); }

int ItemSystem::ammo() const { const Slot* s = slot(); return s ? s->ammo : 0; }

float ItemSystem::reloadProgress() const { return reloadLeft > 0.0f && reloadTotal > 0.0f ? 1.0f - reloadLeft / reloadTotal : 0.0f; }

bool ItemSystem::canUse(const ItemDef& d) const {
    const Slot* s = slot();
    if (!s) return false;
    if (equipT < 1.0f || reloadLeft > 0.0f || swingT >= 0.0f || cooldown > 0.0f) return false;
    const bool usesAmmo = d.stats.magazine > 0 && d.behaviour != Behaviour::Melee && d.behaviour != Behaviour::Tool;
    return !usesAmmo || s->ammo > 0;
}

bool ItemSystem::ready() const { const ItemDef* d = currentDef(); return d && canUse(*d); }

float ItemSystem::crosshairSpread() const {
    const ItemDef* d = currentDef();
    if (!d) return 0.0f;
    return d->behaviour == Behaviour::Hitscan || d->behaviour == Behaviour::Projectile ? d->stats.spread : 0.0f;
}

float ItemSystem::takeViewKick() { const float k = kickOut; kickOut = 0.0f; return k; }

glm::vec3 ItemSystem::shakeAngles() const {
    const float t = float(clock);
    return glm::vec3(std::sin(t * 47.0f) * 0.8f, std::sin(t * 53.0f + 1.0f) * 0.8f, std::sin(t * 41.0f + 2.0f) * 1.2f) * shake;
}

float ItemSystem::rnd() {
    rngState ^= rngState << 13; rngState ^= rngState >> 17; rngState ^= rngState << 5;
    return float(rngState & 0xFFFFFF) * (1.0f / 16777216.0f);
}

glm::vec3 ItemSystem::coneAround(const glm::vec3& dir, float spreadDeg) {
    if (spreadDeg <= 0.0f) return dir;
    const glm::vec3 a = std::fabs(dir.y) < 0.95f ? glm::vec3(0, 1, 0) : glm::vec3(1, 0, 0);
    const glm::vec3 r = glm::normalize(glm::cross(dir, a));
    const glm::vec3 u = glm::cross(r, dir);
    const float angle = glm::radians(spreadDeg) * std::sqrt(rnd());
    const float turn = rnd() * 2.0f * kPi;
    return glm::normalize(dir * std::cos(angle) + (r * std::cos(turn) + u * std::sin(turn)) * std::sin(angle));
}

// ------------------------------------------------------------------ the item in the hand

glm::mat4 ItemSystem::heldMatrix(const ItemView& view, const ItemDef& def, const Asset* asset) const {
    const glm::mat4 viewToWorld(glm::vec4(view.right, 0.0f), glm::vec4(view.up, 0.0f), glm::vec4(-view.forward, 0.0f), glm::vec4(view.eye, 1.0f));

    // Standard pose: a gun points along its muzzle, a blade or handle points up and a little forward.
    glm::vec3 grip(0.0f);
    glm::vec3 f(1, 0, 0), u(0, 1, 0);
    float tilt = 0.0f;
    if (asset) {
        grip = asset->center();
        if (const Socket* g = findSocket(*asset, "grip")) { grip = g->position; u = g->direction; }
        if (def.behaviour == Behaviour::Hitscan || def.behaviour == Behaviour::Projectile) {
            if (const Socket* m = findSocket(*asset, "muzzle")) f = m->direction;
            else if (const Socket* g = findSocket(*asset, "grip")) { u = glm::vec3(0, 1, 0); (void)g; }
        } else {
            if (def.behaviour == Behaviour::Thrown) u = glm::vec3(0, 1, 0);
            // The model's -Z side faces away from you and +X is your right: you see a blade's broad side.
            const glm::vec3 a = std::fabs(u.z) < 0.9f ? glm::vec3(0, 0, -1) : glm::vec3(1, 0, 0);
            f = safeNormalize(a - u * glm::dot(a, u), glm::vec3(1, 0, 0));
            if (def.behaviour == Behaviour::Melee || def.behaviour == Behaviour::Tool) tilt = 22.0f;
        }
    }
    const glm::mat4 align = glm::mat4(alignment(f, u));

    // Animation, all in view space around the grip.
    glm::vec3 off = def.hold.offset;
    float roll = 0.0f, pitch = 0.0f, yaw = 0.0f;

    const float e = smooth01(equipT);
    off.y -= (1.0f - e) * 0.45f;
    pitch += (1.0f - e) * 40.0f;

    const float sway = std::sin(bobPhase) * bobAmount;
    off.x += sway * 0.012f + std::sin(float(clock) * 1.3f) * 0.0025f;
    off.y += std::fabs(std::sin(bobPhase)) * bobAmount * 0.012f + std::sin(float(clock) * 1.7f) * 0.002f;

    if (reloadLeft > 0.0f) {
        const float k = std::sin(kPi * reloadProgress());
        off.y -= 0.16f * k; pitch += 28.0f * k; roll += 14.0f * k;
    }
    pitch += kickAnim * 6.0f;
    off.z -= kickAnim * 0.05f;

    if (swingT >= 0.0f) {
        const float p = std::clamp(swingT, 0.0f, 1.0f);
        if (def.behaviour == Behaviour::Melee) {
            const float arc = def.stats.swingArc;
            roll += glm::mix(-arc * 0.45f, arc * 0.45f, smooth01(p));
            pitch -= std::sin(kPi * p) * 30.0f;
            off.x -= smooth01(p) * 0.20f;
            off.z += std::sin(kPi * p) * 0.12f;
        } else {
            pitch -= std::sin(kPi * p) * 38.0f;
            off.z += std::sin(kPi * p) * 0.10f;
            off.y -= std::sin(kPi * p) * 0.05f;
        }
    }

    const glm::mat4 hold = rotY(def.hold.rotation.x) * rotX(def.hold.rotation.y) * rotZ(def.hold.rotation.z);
    glm::mat4 m = glm::translate(glm::mat4(1.0f), glm::vec3(off.x, off.y, -off.z));
    m = m * rotZ(roll) * rotX(pitch + (tilt != 0.0f ? -tilt : 0.0f)) * rotY(yaw) * hold * align;
    m = glm::scale(m, glm::vec3(def.hold.scale));
    m = glm::translate(m, -grip);
    return viewToWorld * m;
}

AssetPtr ItemSystem::assetFor(const std::string& name) const {
    if (findAsset) return findAsset(name);
    return assets ? assets->get(name) : nullptr;
}

bool ItemSystem::heldDraw(const ItemView& view, ObjectDraw& out) const {
    if (!enabled) return false;
    const ItemDef* d = currentDef();
    if (!d || equipT <= 0.02f) return false;
    AssetPtr a = assetFor(d->asset);
    if (!a || !a->valid()) return false;
    out.asset = a;
    out.model = heldMatrix(view, *d, a.get());
    out.scale = d->hold.scale;
    out.highlight = glm::vec4(0.0f);
    return true;
}

glm::vec3 ItemSystem::muzzlePoint(const ItemView& view) const {
    const ItemDef* d = currentDef();
    if (d) {
        if (AssetPtr a = assetFor(d->asset)) {
            if (const Socket* m = findSocket(*a, "muzzle")) return glm::vec3(heldMatrix(view, *d, a.get()) * glm::vec4(m->position, 1.0f));
            if (const Socket* t = findSocket(*a, "blade_tip")) return glm::vec3(heldMatrix(view, *d, a.get()) * glm::vec4(t->position, 1.0f));
        }
    }
    return view.eye + view.forward * 0.7f + view.right * 0.2f - view.up * 0.15f;
}

// ------------------------------------------------------------------ using it

void ItemSystem::startReload(ItemWorld& world, const ItemView& view) {
    const ItemDef* d = currentDef();
    Slot* s = slot();
    if (!d || !s || d->stats.magazine <= 0 || s->ammo >= d->stats.magazine || reloadLeft > 0.0f) return;
    reloadLeft = reloadTotal = std::max(0.05f, d->stats.reloadTime);
    world.sound("reload", view.eye + view.forward * 0.3f, 0.7f, 1.0f);
}

void ItemSystem::update(float dt, ItemWorld& world, const ItemView& view) {
    clock += double(dt);
    cooldown = std::max(0.0f, cooldown - dt);
    for (float& b : pressBuffer) b = std::max(0.0f, b - dt);
    hitmarkerT = std::max(0.0f, hitmarkerT - dt * 4.0f);
    shake *= std::exp(-dt * 7.0f);
    kickAnim = std::max(0.0f, kickAnim - dt * 7.0f);
    bobAmount += (std::min(1.0f, view.walkSpeed / 6.0f) - bobAmount) * std::min(1.0f, dt * 8.0f);
    bobPhase += dt * (2.0f + view.walkSpeed * 1.5f);

    {   // the view kick: most of it stays, a part settles back
        const float s = pendingKick * std::min(1.0f, dt * 25.0f);
        pendingKick -= s; kickOut += s; recovering += s * 0.3f;
        const float r = std::min(recovering, dt * 10.0f);
        recovering -= r; kickOut -= r;
    }

    const ItemDef* def = enabled ? currentDef() : nullptr;
    Slot* s = slot();
    if (def && s) {
        equipT = std::min(1.0f, equipT + dt / 0.30f);

        if (reloadRequested) { reloadRequested = false; if (equipT >= 1.0f && swingT < 0.0f) startReload(world, view); }
        if (reloadLeft > 0.0f) {
            reloadLeft -= dt;
            if (reloadLeft <= 0.0f) { reloadLeft = 0.0f; s->ammo = def->stats.magazine; }
        }
        if (swingT >= 0.0f) {
            swingT += dt / swingLength;
            if (!swingStruck && swingT >= 0.4f) {
                swingStruck = true;
                if (def->behaviour == Behaviour::Melee) meleeStrike(*def, world, view);
            }
            if (swingT >= 1.0f) swingT = -1.0f;
        }
        if (canUse(*def)) {
            for (int b = 0; b < 2; ++b) {
                if (b == 1 && def->behaviour != Behaviour::Tool) continue;
                if ((held[b] && def->stats.automatic) || pressBuffer[b] > 0.0f) { use(b, world, view); break; }
            }
        }
        const bool usesAmmo = def->stats.magazine > 0 && def->behaviour != Behaviour::Melee && def->behaviour != Behaviour::Tool;
        if (usesAmmo && s->ammo <= 0 && reloadLeft <= 0.0f && equipT >= 1.0f) startReload(world, view);
    }
    reloadRequested = false;

    updateProjectiles(dt, world, view);

    // effects age, and hide behind whatever is in the way
    for (ItemFx& f : fx) {
        f.age += dt;
        if (f.kind == ItemFx::Kind::Blast || f.kind == ItemFx::Kind::Sparks || f.kind == ItemFx::Kind::Puff) {
            const glm::vec3 d = f.a - view.eye;
            const float dist = glm::length(d);
            ItemRayHit h;
            f.visible = !(dist > 1.0f && world.raycast(view.eye, d / dist, dist - 0.6f, h));
        }
    }
    fx.erase(std::remove_if(fx.begin(), fx.end(), [](const ItemFx& f) { return f.age >= f.life; }), fx.end());
}

void ItemSystem::use(int button, ItemWorld& world, const ItemView& view) {
    const ItemDef* defp = currentDef();
    Slot* s = slot();
    if (!defp || !s) return;
    const ItemDef& d = *defp;
    pressBuffer[button] = 0.0f;
    const bool usesAmmo = d.stats.magazine > 0 && d.behaviour != Behaviour::Melee && d.behaviour != Behaviour::Tool;

    switch (d.behaviour) {
    case Behaviour::Hitscan:    fireHitscan(d, world, view); break;
    case Behaviour::Projectile: fireProjectile(d, world, view, false); break;
    case Behaviour::Thrown:     fireProjectile(d, world, view, true); equipT = -1.5f; break;
    case Behaviour::Melee:
        swingT = 0.0f; swingStruck = false; swingButton = button;
        swingLength = std::clamp(0.8f / d.stats.fireRate, 0.18f, 0.7f);
        break;
    case Behaviour::Tool:
        swingT = 0.0f; swingStruck = true; swingButton = button;
        swingLength = std::clamp(0.5f / d.stats.fireRate, 0.1f, 0.4f);
        useTool(d, button, world, view);
        break;
    }
    if (usesAmmo) s->ammo = std::max(0, s->ammo - 1);
    cooldown = 1.0f / d.stats.fireRate;
    ++totals.shots;

    if (!d.feel.fireSound.empty())
        world.sound(d.feel.fireSound, view.eye + view.forward * 0.6f, d.feel.volume, d.feel.pitch * (0.96f + 0.08f * rnd()));
    if (d.stats.recoil > 0.0f) {
        pendingKick += d.stats.recoil;
        kickAnim = std::min(1.0f, kickAnim + 0.8f);
    }
    shake = std::max(shake, d.feel.shake * 0.35f);
    if (d.feel.muzzleFlash && (d.behaviour == Behaviour::Hitscan || d.behaviour == Behaviour::Projectile)) {
        ItemFx f; f.kind = ItemFx::Kind::Flash; f.a = muzzlePoint(view); f.b = view.forward; f.colour = d.feel.tracerColour;
        f.life = 0.06f; f.size = 0.35f + 0.02f * d.stats.damage / std::max(1, d.stats.pellets > 1 ? 4 : 1); f.seed = std::uint32_t(rnd() * 1e6f);
        f.size = std::clamp(f.size, 0.3f, 0.9f);
        addFx(f);
    }
}

void ItemSystem::fireHitscan(const ItemDef& d, ItemWorld& world, const ItemView& view) {
    const glm::vec3 muzzle = muzzlePoint(view);
    for (int i = 0; i < d.stats.pellets; ++i) {
        const glm::vec3 dir = coneAround(view.forward, d.stats.spread);
        ItemRayHit h;
        const bool got = world.raycast(view.eye, dir, d.stats.range, h);
        const glm::vec3 end = got ? h.point : view.eye + dir * std::min(d.stats.range, 250.0f);
        if (d.feel.tracer) {
            ItemFx t; t.kind = ItemFx::Kind::Tracer; t.a = muzzle; t.b = end; t.colour = d.feel.tracerColour; t.life = 0.07f;
            addFx(t);
        }
        if (got) landHit(d, world, h, d.stats.damage, false, true);
    }
}

void ItemSystem::landHit(const ItemDef& d, ItemWorld& world, const ItemRayHit& h, float damage, bool melee, bool crater) {
    const bool thing = h.object != 0 || h.target >= 0;
    if (crater && h.object == 0 && d.effect.kind != WorldEffect::None) {
        const bool build = d.effect.kind == WorldEffect::Build;
        world.crater(build ? h.point + h.normal * (d.effect.radius * 0.5f) : h.point, d.effect.radius, build, d.effect.material);
    }
    const std::string clip = d.feel.impactSound.empty() ? std::string("bullet_hit") : d.feel.impactSound;
    world.sound(clip, h.point, melee ? 0.9f : 0.75f, (melee ? 0.8f : 1.0f) * impactPitch(h.material) * (0.94f + 0.12f * rnd()));

    ItemFx sp; sp.kind = ItemFx::Kind::Sparks; sp.a = h.point; sp.b = h.normal; sp.life = 0.3f; sp.seed = std::uint32_t(rnd() * 1e6f);
    sp.size = std::clamp(0.5f + d.effect.radius * 0.4f, 0.5f, 1.4f);
    sp.colour = (h.material == MAT_METAL || h.material == MAT_STONE || h.material == MAT_BRICK) ? glm::vec3(1.0f, 0.85f, 0.5f) : glm::vec3(0.75f, 0.68f, 0.55f);
    addFx(sp);
    ItemFx pf; pf.kind = ItemFx::Kind::Puff; pf.a = h.point + h.normal * 0.1f; pf.life = 0.45f; pf.size = 0.35f + d.effect.radius * 0.5f; pf.colour = glm::vec3(0.46f, 0.41f, 0.35f);
    addFx(pf);

    if (thing) { ++totals.hits; totals.damage += damage; hitmarkerT = 1.0f; }
    ItemHit r;
    r.item = &d; r.point = h.point; r.normal = h.normal; r.distance = h.distance; r.damage = damage;
    r.object = h.object; r.target = h.target; r.melee = melee;
    world.hit(r);
}

void ItemSystem::fireProjectile(const ItemDef& d, ItemWorld& world, const ItemView& view, bool thrown) {
    Projectile p;
    p.def = &d;
    glm::vec3 dir;
    if (thrown) {
        p.pos = view.eye + view.forward * 0.45f + view.right * 0.18f - view.up * 0.12f;
        dir = glm::normalize(view.forward + view.up * 0.10f);
    } else {
        p.pos = muzzlePoint(view);
        float aimDist = 80.0f;
        ItemRayHit h;
        if (world.raycast(view.eye, view.forward, 300.0f, h) && h.distance > 3.0f) aimDist = h.distance;
        dir = coneAround(safeNormalize(view.eye + view.forward * aimDist - p.pos, view.forward), d.stats.spread);
    }
    p.vel = dir * d.stats.speed;
    flying.push_back(p);
}

void ItemSystem::useTool(const ItemDef& d, int button, ItemWorld& world, const ItemView& view) {
    if (d.effect.kind == WorldEffect::None) return;
    ItemRayHit h;
    if (!world.raycast(view.eye, view.forward, d.stats.range, h)) return;
    const bool carve = (d.effect.kind == WorldEffect::Carve) != (button == 1);
    if (h.object == 0) world.crater(carve ? h.point : h.point + h.normal * (d.effect.radius * 0.5f), d.effect.radius, !carve, d.effect.material);
    ItemFx pf; pf.kind = ItemFx::Kind::Puff; pf.a = h.point + h.normal * 0.2f; pf.life = 0.5f; pf.size = 0.4f + d.effect.radius * 0.5f; pf.colour = glm::vec3(0.46f, 0.41f, 0.34f);
    addFx(pf);
    ItemHit r;
    r.item = &d; r.point = h.point; r.normal = h.normal; r.distance = h.distance; r.damage = d.stats.damage; r.object = h.object; r.target = h.target;
    world.hit(r);
}

void ItemSystem::meleeStrike(const ItemDef& d, ItemWorld& world, const ItemView& view) {
    const float half = std::clamp(d.stats.swingArc * 0.25f, 5.0f, 45.0f);
    ItemRayHit best; bool found = false; float bestScore = 1e9f;
    for (int i = -2; i <= 2; ++i) {
        const float a = glm::radians(half * float(i) * 0.5f);
        const glm::vec3 dir = glm::normalize(view.forward * std::cos(a) + view.right * std::sin(a));
        ItemRayHit h;
        if (!world.raycast(view.eye, dir, d.stats.range, h)) continue;
        const float score = h.distance + std::fabs(float(i)) * 0.05f;
        if (score < bestScore) { bestScore = score; best = h; found = true; }
    }
    if (found) landHit(d, world, best, d.stats.damage, true, true);
}

void ItemSystem::explode(const ItemDef& d, ItemWorld& world, const ItemView& view, const glm::vec3& at, const glm::vec3& normal, std::uint32_t object) {
    const float r = d.effect.radius;
    if (d.effect.kind != WorldEffect::None && object == 0) {
        const bool build = d.effect.kind == WorldEffect::Build;
        world.crater(build ? at + normal * (r * 0.5f) : at, r, build, d.effect.material);
    }
    if (d.effect.push > 0.0f) world.blast(at, r, d.effect.push);
    world.sound("boom", at, 1.0f, std::clamp(1.35f - r * 0.1f, 0.55f, 1.3f));

    ItemFx b; b.kind = ItemFx::Kind::Blast; b.a = at; b.life = 0.6f; b.size = std::max(1.0f, r); b.seed = std::uint32_t(rnd() * 1e6f);
    addFx(b);
    ItemFx sp; sp.kind = ItemFx::Kind::Sparks; sp.a = at; sp.b = normal; sp.life = 0.7f; sp.size = std::max(1.5f, r * 0.7f); sp.seed = std::uint32_t(rnd() * 1e6f);
    sp.colour = glm::vec3(1.0f, 0.7f, 0.3f);
    addFx(sp);

    const float dist = glm::length(view.eye - at);
    shake = std::max(shake, d.feel.shake * std::clamp(1.0f - dist / (std::max(r, 1.0f) * 8.0f), 0.0f, 1.0f) * 2.0f);
    ++totals.explosions;

    ItemHit h;
    h.item = &d; h.point = at; h.normal = normal; h.distance = dist; h.damage = d.stats.damage; h.object = object; h.explosion = true; h.radius = r;
    world.hit(h);
}

void ItemSystem::updateProjectiles(float dt, ItemWorld& world, const ItemView& view) {
    // explode() may add to `flying` only through callbacks, never directly, but keep indices safe anyway
    for (size_t i = 0; i < flying.size(); ++i) {
        Projectile& p = flying[i];
        const ItemDef& d = *p.def;
        const ItemStats& st = d.stats;
        const bool thrown = d.behaviour == Behaviour::Thrown;
        p.age += dt;

        if (!p.resting) {
            p.vel.y -= st.gravity * dt;
            const glm::vec3 step = p.vel * dt;
            const float len = glm::length(step);
            if (len > 1e-5f) {
                const glm::vec3 dir = step / len;
                ItemRayHit h;
                if (world.raycast(p.pos, dir, len + 0.02f, h)) {
                    if (thrown && st.fuse > 0.0f) {
                        p.pos = h.point + h.normal * 0.07f;
                        const float speed = glm::length(p.vel);
                        if (st.bounce > 0.01f && speed > 2.0f) {
                            const float vn = glm::dot(p.vel, h.normal);
                            const glm::vec3 vt = p.vel - vn * h.normal;
                            p.vel = vt * 0.82f - vn * st.bounce * h.normal;
                            world.sound("land", p.pos, std::min(1.0f, speed / 24.0f) * 0.6f, 1.4f);
                        } else {
                            p.vel = glm::vec3(0.0f); p.resting = true;
                        }
                    } else {
                        explode(d, world, view, h.point, h.normal, h.object);
                        p.dead = true;
                    }
                } else {
                    p.pos += step; p.travelled += len;
                }
            }
        }
        if (!p.dead && st.fuse > 0.0f && p.age >= st.fuse) {
            explode(d, world, view, p.pos, glm::vec3(0, 1, 0), 0);
            p.dead = true;
        }
        if (!p.dead && (p.travelled > st.range || p.age > 20.0f || p.pos.y < -400.0f)) p.dead = true;

        if (!p.dead && !p.resting) {
            p.trail -= dt;
            if (p.trail <= 0.0f) {
                p.trail = 0.03f;
                ItemFx t; t.kind = ItemFx::Kind::Puff; t.a = p.pos; t.life = thrown ? 0.25f : 0.55f; t.size = thrown ? 0.12f : 0.3f;
                t.colour = thrown ? glm::vec3(0.8f) : glm::vec3(0.9f, 0.62f, 0.35f);
                addFx(t);
            }
        }
    }
    flying.erase(std::remove_if(flying.begin(), flying.end(), [](const Projectile& p) { return p.dead; }), flying.end());
}

// ------------------------------------------------------------------ effects on screen

namespace {

struct Screen {
    const glm::mat4& vp;
    float x, y, w, h;
    bool point(const glm::vec3& p, ImVec2& out, float* clipW = nullptr) const {
        const glm::vec4 c = vp * glm::vec4(p, 1.0f);
        if (c.w <= 0.05f) return false;
        out = ImVec2(x + (c.x / c.w * 0.5f + 0.5f) * w, y + (1.0f - (c.y / c.w * 0.5f + 0.5f)) * h);
        if (clipW) *clipW = c.w;
        return true;
    }
    // a line that may cross the near plane
    bool line(glm::vec3 a, glm::vec3 b, ImVec2& pa, ImVec2& pb) const {
        const float wa = (vp * glm::vec4(a, 1.0f)).w, wb = (vp * glm::vec4(b, 1.0f)).w;
        constexpr float kNear = 0.08f;
        if (wa < kNear && wb < kNear) return false;
        if (wa < kNear) a = a + (b - a) * ((kNear - wa) / (wb - wa));
        else if (wb < kNear) b = a + (b - a) * ((kNear - wa) / (wb - wa));
        return point(a, pa) && point(b, pb);
    }
    // how many pixels a length of `metres` covers at a point, looking across the view
    float pixels(const glm::vec3& p, const glm::vec3& cameraRight, float metres) const {
        ImVec2 a, b;
        if (!point(p, a) || !point(p + cameraRight * metres, b)) return 0.0f;
        return std::hypot(b.x - a.x, b.y - a.y);
    }
};

ImU32 col(const glm::vec3& c, float a) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(std::clamp(c.x, 0.0f, 1.0f), std::clamp(c.y, 0.0f, 1.0f), std::clamp(c.z, 0.0f, 1.0f), std::clamp(a, 0.0f, 1.0f)));
}

// A disc that fades out towards its edge: a few nested discs, each faint, add up to a soft puff of light or smoke.
void softDisc(ImDrawList* dl, const ImVec2& c, float r, const glm::vec3& colour, float alpha, int layers = 11) {
    const float a = alpha / float(layers);
    for (int k = 0; k < layers; ++k) dl->AddCircleFilled(c, r * (1.0f - 0.9f * float(k) / float(layers)), col(colour, a * (k == 0 ? 0.7f : 1.15f)), 24);
}

float hash01(std::uint32_t n) {
    n ^= n >> 16; n *= 0x7FEB352Du; n ^= n >> 15; n *= 0x846CA68Bu; n ^= n >> 16;
    return float(n & 0xFFFFFF) * (1.0f / 16777216.0f);
}

} // namespace

void ItemSystem::drawFx(ImDrawList* dl, const glm::mat4& viewProj, const ItemView& view, float x, float y, float w, float h, float uiScale) const {
    const Screen sc{ viewProj, x, y, w, h };
    dl->PushClipRect(ImVec2(x, y), ImVec2(x + w, y + h), true);

    for (const ItemFx& f : fx) {
        if (!f.visible) continue;
        const float t = std::clamp(f.age / f.life, 0.0f, 1.0f);
        switch (f.kind) {
        case ItemFx::Kind::Tracer: {
            ImVec2 a, b;
            if (!sc.line(f.a, f.b, a, b)) break;
            const float fade = 1.0f - t * t;
            dl->AddLine(a, b, col(glm::vec3(0.10f, 0.08f, 0.06f), 0.40f * fade), 4.6f * uiScale);       // a dark edge, so it reads on sand and snow too
            dl->AddLine(a, b, col(f.colour, 0.55f * fade), 3.0f * uiScale);
            dl->AddLine(a, b, col(glm::mix(f.colour, glm::vec3(1.0f), 0.6f), 0.95f * fade), 1.4f * uiScale);
            break;
        }
        case ItemFx::Kind::Flash: {
            ImVec2 p;
            if (!sc.point(f.a, p)) break;
            const float r = f.size * 56.0f * uiScale * (1.0f - t * 0.4f);
            const float fade = 1.0f - t;
            softDisc(dl, p, r * 0.8f, f.colour, 0.55f * fade);
            softDisc(dl, p, r * 0.3f, glm::vec3(1.0f, 0.97f, 0.85f), 0.95f * fade, 5);
            for (int i = 0; i < 6; ++i) {
                const float a = hash01(f.seed + std::uint32_t(i) * 7u) * 6.2832f;
                const float l = r * (0.7f + 0.8f * hash01(f.seed + std::uint32_t(i) * 13u + 5u));
                dl->AddLine(p, ImVec2(p.x + std::cos(a) * l, p.y + std::sin(a) * l), col(glm::vec3(1.0f, 0.9f, 0.6f), 0.8f * fade), 2.0f * uiScale);
            }
            break;
        }
        case ItemFx::Kind::Sparks: {
            const glm::vec3 n = safeNormalize(f.b, glm::vec3(0, 1, 0));
            const glm::vec3 ta = std::fabs(n.y) < 0.9f ? glm::vec3(0, 1, 0) : glm::vec3(1, 0, 0);
            const glm::vec3 t1 = glm::normalize(glm::cross(n, ta)), t2 = glm::cross(n, t1);
            const int count = 10;
            for (int i = 0; i < count; ++i) {
                const float a = hash01(f.seed + std::uint32_t(i) * 3u) * 6.2832f;
                const float spd = (2.0f + 5.0f * hash01(f.seed + std::uint32_t(i) * 11u + 1u)) * f.size;
                const glm::vec3 v = (n * (0.6f + hash01(f.seed + std::uint32_t(i) * 17u + 2u)) + (t1 * std::cos(a) + t2 * std::sin(a)) * 0.9f) * spd;
                const float tm = f.age;
                const glm::vec3 p0 = f.a + v * tm + glm::vec3(0, -9.0f * tm * tm, 0);
                const glm::vec3 p1 = f.a + v * std::max(0.0f, tm - 0.03f) + glm::vec3(0, -9.0f * std::max(0.0f, tm - 0.03f) * std::max(0.0f, tm - 0.03f), 0);
                ImVec2 a0, a1;
                if (!sc.line(p1, p0, a1, a0)) continue;
                dl->AddLine(a1, a0, col(glm::vec3(0.12f, 0.08f, 0.04f), 0.40f * (1.0f - t)), 3.6f * uiScale);
                dl->AddLine(a1, a0, col(f.colour, 0.95f * (1.0f - t)), 1.8f * uiScale);
            }
            break;
        }
        case ItemFx::Kind::Puff: {
            ImVec2 p;
            if (!sc.point(f.a, p)) break;
            const float R = std::max(1.0f, sc.pixels(f.a, view.right, f.size * (1.0f + 2.2f * t)));
            const float alpha = 0.36f * (1.0f - t) * (1.0f - t);
            for (int i = 0; i < 6; ++i) {                    // a cloud of soft lobes, not one hard disc
                const float ang = hash01(f.seed + std::uint32_t(i) * 7919u) * 6.2832f;
                const float dist = (0.1f + 0.5f * hash01(f.seed + std::uint32_t(i) * 104729u)) * R * 0.7f;
                const float rad = R * (0.35f + 0.3f * hash01(f.seed + std::uint32_t(i) * 31u));
                softDisc(dl, ImVec2(p.x + std::cos(ang) * dist, p.y + std::sin(ang) * dist * 0.8f - t * R * 0.3f), rad, f.colour, alpha);
            }
            break;
        }
        case ItemFx::Kind::Blast: {
            ImVec2 p;
            if (!sc.point(f.a, p)) break;
            const float grow = 1.0f - (1.0f - t) * (1.0f - t);
            const float R = sc.pixels(f.a, view.right, f.size * (0.4f + 1.2f * grow));
            const float fade = 1.0f - t;
            const float fire = std::max(0.0f, 1.0f - t * 1.6f);
            // smoke: dark lobes that drift up and linger
            for (int i = 0; i < 8; ++i) {
                const float ang = hash01(f.seed + std::uint32_t(i) * 7919u) * 6.2832f;
                const float dist = (0.2f + 0.6f * hash01(f.seed + std::uint32_t(i) * 104729u)) * R;
                const float rad = R * (0.32f + 0.26f * hash01(f.seed + std::uint32_t(i) * 31u)) * (0.6f + 0.7f * grow);
                const ImVec2 c(p.x + std::cos(ang) * dist, p.y + std::sin(ang) * dist * 0.7f - t * R * 0.4f);
                softDisc(dl, c, rad, glm::vec3(0.20f, 0.18f, 0.17f), 0.55f * fade * fade);
            }
            // fire: orange lobes that burn out sooner than the smoke
            for (int i = 0; i < 7; ++i) {
                const float ang = hash01(f.seed + std::uint32_t(i) * 15485863u) * 6.2832f;
                const float dist = (0.1f + 0.45f * hash01(f.seed + std::uint32_t(i) * 32452843u)) * R;
                const float rad = R * (0.28f + 0.2f * hash01(f.seed + std::uint32_t(i) * 49979687u)) * (0.5f + 0.8f * grow);
                const ImVec2 c(p.x + std::cos(ang) * dist, p.y + std::sin(ang) * dist * 0.8f);
                softDisc(dl, c, rad, glm::vec3(1.0f, 0.45f + 0.2f * hash01(f.seed + std::uint32_t(i)), 0.12f), 0.85f * fire);
            }
            softDisc(dl, p, R * 0.5f * (0.4f + 0.6f * fire), glm::vec3(1.0f, 0.80f, 0.38f), 1.0f * fire);
            softDisc(dl, p, R * 0.24f * fade * fade, glm::vec3(1.0f, 0.97f, 0.88f), 1.0f * fade, 5);
            dl->AddCircle(p, R * (0.9f + 1.0f * t), col(glm::vec3(1.0f, 0.9f, 0.7f), 0.30f * fade), 36, 2.0f * uiScale);
            break;
        }
        }
    }
    dl->PopClipRect();
}

} // namespace px
