#include "items/Item.h"
#include <algorithm>
#include <cctype>
#include <filesystem>
#include <fstream>
#include <sstream>
#include "core/Json.h"
#include "scene/Asset.h"

namespace px {

// ------------------------------------------------------------------ names

const char* behaviourName(Behaviour b) {
    switch (b) {
    case Behaviour::Melee: return "Melee";
    case Behaviour::Hitscan: return "Hitscan gun";
    case Behaviour::Projectile: return "Projectile launcher";
    case Behaviour::Thrown: return "Thrown";
    case Behaviour::Tool: return "Tool";
    }
    return "?";
}
const char* behaviourKey(Behaviour b) {
    switch (b) {
    case Behaviour::Melee: return "melee";
    case Behaviour::Hitscan: return "hitscan";
    case Behaviour::Projectile: return "projectile";
    case Behaviour::Thrown: return "thrown";
    case Behaviour::Tool: return "tool";
    }
    return "hitscan";
}
const char* behaviourInfo(Behaviour b) {
    switch (b) {
    case Behaviour::Melee: return "Swings, and hits whatever is in reach halfway through.";
    case Behaviour::Hitscan: return "A shot that lands at once. Pistols, rifles, and shotguns with pellets.";
    case Behaviour::Projectile: return "Fires something that flies and goes off on impact. Rockets, arrows, fireballs.";
    case Behaviour::Thrown: return "Throws it. It bounces, and goes off when its fuse runs out.";
    case Behaviour::Tool: return "Shapes the world. The main button carves; the second button does the opposite.";
    }
    return "";
}
bool behaviourFromKey(const std::string& key, Behaviour& out) {
    for (int i = 0; i < kBehaviourCount; ++i)
        if (key == behaviourKey(Behaviour(i))) { out = Behaviour(i); return true; }
    return false;
}

const char* worldEffectName(WorldEffect e) {
    switch (e) {
    case WorldEffect::None: return "Nothing";
    case WorldEffect::Carve: return "Carve a crater";
    case WorldEffect::Build: return "Build up a lump";
    }
    return "?";
}

namespace {

const char* effectKey(WorldEffect e) { return e == WorldEffect::None ? "none" : e == WorldEffect::Carve ? "carve" : "build"; }

std::string lower(std::string s) { for (char& c : s) c = char(std::tolower(static_cast<unsigned char>(c))); return s; }

Json vec3Json(const glm::vec3& v) { return Json::array({ v.x, v.y, v.z }); }
glm::vec3 jsonVec3(const Json& j, const glm::vec3& fallback) {
    if (!j.isArray() || j.size() != 3) return fallback;
    return glm::vec3(float(j.at(0).num(fallback.x)), float(j.at(1).num(fallback.y)), float(j.at(2).num(fallback.z)));
}

bool materialFromName(const std::string& name, MaterialId& out) {
    const std::string n = lower(name);
    for (int i = 1; i < MAT_COUNT; ++i) if (lower(materialInfo(MaterialId(i)).name) == n) { out = MaterialId(i); return true; }
    return false;
}

float num(const Json& j, const char* key, float fallback) { return float(j.get(key).num(fallback)); }

} // namespace

// ------------------------------------------------------------------ defaults and limits

ItemDef ItemDef::defaultsFor(Behaviour b, const std::string& name, const std::string& asset) {
    ItemDef d;
    d.name = name;
    d.asset = asset;
    d.behaviour = b;
    switch (b) {
    case Behaviour::Hitscan:
        d.stats.damage = 22; d.stats.fireRate = 5; d.stats.automatic = false; d.stats.magazine = 12; d.stats.reloadTime = 1.3f;
        d.stats.pellets = 1; d.stats.spread = 0.6f; d.stats.recoil = 1.8f; d.stats.range = 150;
        d.effect = { WorldEffect::Carve, 0.5f, MAT_STONE, 0.0f };
        d.feel.fireSound = "shot"; d.feel.shake = 0.3f;
        d.hold.offset = { 0.20f, -0.18f, 0.42f };
        break;
    case Behaviour::Projectile:
        d.stats.damage = 90; d.stats.fireRate = 0.9f; d.stats.magazine = 1; d.stats.reloadTime = 2.2f; d.stats.spread = 0.3f;
        d.stats.recoil = 4.0f; d.stats.range = 300; d.stats.speed = 55; d.stats.gravity = 0; d.stats.fuse = 0;
        d.effect = { WorldEffect::Carve, 3.5f, MAT_STONE, 14.0f };
        d.feel.fireSound = "launch"; d.feel.tracer = false; d.feel.shake = 1.0f; d.feel.tracerColour = { 1.0f, 0.62f, 0.25f };
        d.hold.offset = { 0.26f, -0.24f, 0.62f };
        break;
    case Behaviour::Thrown:
        d.stats.damage = 100; d.stats.fireRate = 0.8f; d.stats.magazine = 3; d.stats.reloadTime = 1.5f; d.stats.recoil = 0.0f;
        d.stats.range = 80; d.stats.speed = 18; d.stats.gravity = 22; d.stats.fuse = 2.2f; d.stats.bounce = 0.45f; d.stats.spread = 0.0f;
        d.effect = { WorldEffect::Carve, 3.0f, MAT_STONE, 11.0f };
        d.feel.fireSound = "whoosh"; d.feel.pitch = 0.8f; d.feel.tracer = false; d.feel.muzzleFlash = false; d.feel.shake = 0.8f;
        d.hold.offset = { 0.22f, -0.20f, 0.40f };
        break;
    case Behaviour::Melee:
        d.stats.damage = 35; d.stats.fireRate = 1.6f; d.stats.magazine = 0; d.stats.recoil = 0.0f; d.stats.range = 2.4f; d.stats.swingArc = 110;
        d.stats.spread = 0.0f; d.stats.automatic = false;
        d.effect = { WorldEffect::None, 0.5f, MAT_STONE, 0.0f };
        d.feel.fireSound = "whoosh"; d.feel.pitch = 0.9f; d.feel.tracer = false; d.feel.muzzleFlash = false; d.feel.shake = 0.15f;
        d.hold.offset = { 0.34f, -0.48f, 0.78f }; d.hold.scale = 0.8f;
        break;
    case Behaviour::Tool:
        d.stats.damage = 0; d.stats.fireRate = 6; d.stats.automatic = true; d.stats.magazine = 0; d.stats.recoil = 0.0f;
        d.stats.range = 18; d.stats.swingArc = 60; d.stats.spread = 0.0f;
        d.effect = { WorldEffect::Carve, 1.6f, MAT_STONE, 0.0f };
        d.feel.fireSound = ""; d.feel.tracer = false; d.feel.muzzleFlash = false; d.feel.shake = 0.0f;
        d.hold.offset = { 0.32f, -0.42f, 0.72f }; d.hold.scale = 0.8f;
        break;
    }
    return d;
}

void ItemDef::clamp() {
    auto cl = [](float& v, float lo, float hi) { v = std::clamp(v, lo, hi); };
    while (!name.empty() && std::isspace(static_cast<unsigned char>(name.back()))) name.pop_back();
    cl(stats.damage, 0.0f, 10000.0f);
    cl(stats.fireRate, 0.1f, 30.0f);
    stats.magazine = std::clamp(stats.magazine, 0, 500);
    cl(stats.reloadTime, 0.0f, 10.0f);
    stats.pellets = std::clamp(stats.pellets, 1, 40);
    cl(stats.spread, 0.0f, 30.0f);
    cl(stats.recoil, 0.0f, 20.0f);
    cl(stats.range, behaviour == Behaviour::Melee ? 0.5f : 1.0f, 1000.0f);
    cl(stats.speed, 1.0f, 300.0f);
    cl(stats.gravity, 0.0f, 60.0f);
    cl(stats.fuse, 0.0f, 10.0f);
    cl(stats.bounce, 0.0f, 0.9f);
    cl(stats.swingArc, 10.0f, 220.0f);
    cl(effect.radius, 0.1f, 12.0f);
    cl(effect.push, 0.0f, 60.0f);
    if (effect.material == MAT_NATURAL || effect.material >= MAT_COUNT) effect.material = MAT_STONE;
    cl(feel.volume, 0.0f, 2.0f);
    cl(feel.pitch, 0.4f, 2.5f);
    cl(feel.shake, 0.0f, 3.0f);
    for (int i = 0; i < 3; ++i) { cl(hold.offset[i], -2.0f, 2.0f); cl(hold.rotation[i], -180.0f, 180.0f); cl(feel.tracerColour[i], 0.0f, 4.0f); }
    cl(hold.scale, 0.1f, 4.0f);
}

// ------------------------------------------------------------------ text

std::string itemToText(const ItemDef& d) {
    Json j = Json::object();
    j.set("format", "pxitem");
    j.set("version", 1);
    j.set("name", d.name);
    j.set("asset", d.asset);
    j.set("description", d.description);
    j.set("behaviour", behaviourKey(d.behaviour));

    Json s = Json::object();
    s.set("damage", d.stats.damage);
    s.set("fireRate", d.stats.fireRate);
    s.set("automatic", d.stats.automatic);
    s.set("magazine", d.stats.magazine);
    s.set("reloadTime", d.stats.reloadTime);
    s.set("pellets", d.stats.pellets);
    s.set("spread", d.stats.spread);
    s.set("recoil", d.stats.recoil);
    s.set("range", d.stats.range);
    s.set("speed", d.stats.speed);
    s.set("gravity", d.stats.gravity);
    s.set("fuse", d.stats.fuse);
    s.set("bounce", d.stats.bounce);
    s.set("swingArc", d.stats.swingArc);
    j.set("stats", s);

    Json e = Json::object();
    e.set("kind", effectKey(d.effect.kind));
    e.set("radius", d.effect.radius);
    e.set("material", lower(materialInfo(d.effect.material).name));
    e.set("push", d.effect.push);
    j.set("effect", e);

    Json f = Json::object();
    f.set("fireSound", d.feel.fireSound);
    f.set("impactSound", d.feel.impactSound);
    f.set("volume", d.feel.volume);
    f.set("pitch", d.feel.pitch);
    f.set("muzzleFlash", d.feel.muzzleFlash);
    f.set("tracer", d.feel.tracer);
    f.set("tracerColour", vec3Json(d.feel.tracerColour));
    f.set("shake", d.feel.shake);
    j.set("feel", f);

    Json h = Json::object();
    h.set("offset", vec3Json(d.hold.offset));
    h.set("rotation", vec3Json(d.hold.rotation));
    h.set("scale", d.hold.scale);
    j.set("hold", h);
    return j.dump(2) + "\n";
}

bool itemFromText(const std::string& text, ItemDef& out, std::string* error) {
    Json j;
    if (!Json::parse(text, j, error)) return false;
    if (!j.isObject() || j.get("format").str() != "pxitem") { if (error) *error = "not a .pxitem file"; return false; }
    if (j.get("name").str().empty()) { if (error) *error = "the item has no name"; return false; }

    Behaviour b = Behaviour::Hitscan;
    if (!behaviourFromKey(j.get("behaviour").str(), b)) { if (error) *error = "unknown behaviour '" + j.get("behaviour").str() + "'"; return false; }

    ItemDef d = ItemDef::defaultsFor(b, j.get("name").str(), j.get("asset").str());     // anything the file leaves out keeps the standard value
    d.description = j.get("description").str();
    const Json& s = j.get("stats");
    d.stats.damage = num(s, "damage", d.stats.damage);
    d.stats.fireRate = num(s, "fireRate", d.stats.fireRate);
    d.stats.automatic = s.get("automatic").boolean(d.stats.automatic);
    d.stats.magazine = s.get("magazine").integer(d.stats.magazine);
    d.stats.reloadTime = num(s, "reloadTime", d.stats.reloadTime);
    d.stats.pellets = s.get("pellets").integer(d.stats.pellets);
    d.stats.spread = num(s, "spread", d.stats.spread);
    d.stats.recoil = num(s, "recoil", d.stats.recoil);
    d.stats.range = num(s, "range", d.stats.range);
    d.stats.speed = num(s, "speed", d.stats.speed);
    d.stats.gravity = num(s, "gravity", d.stats.gravity);
    d.stats.fuse = num(s, "fuse", d.stats.fuse);
    d.stats.bounce = num(s, "bounce", d.stats.bounce);
    d.stats.swingArc = num(s, "swingArc", d.stats.swingArc);

    const Json& e = j.get("effect");
    const std::string kind = e.get("kind").str(effectKey(d.effect.kind));
    d.effect.kind = kind == "none" ? WorldEffect::None : kind == "build" ? WorldEffect::Build : WorldEffect::Carve;
    d.effect.radius = num(e, "radius", d.effect.radius);
    materialFromName(e.get("material").str(), d.effect.material);
    d.effect.push = num(e, "push", d.effect.push);

    const Json& f = j.get("feel");
    d.feel.fireSound = f.get("fireSound").str(d.feel.fireSound);
    d.feel.impactSound = f.get("impactSound").str(d.feel.impactSound);
    d.feel.volume = num(f, "volume", d.feel.volume);
    d.feel.pitch = num(f, "pitch", d.feel.pitch);
    d.feel.muzzleFlash = f.get("muzzleFlash").boolean(d.feel.muzzleFlash);
    d.feel.tracer = f.get("tracer").boolean(d.feel.tracer);
    d.feel.tracerColour = jsonVec3(f.get("tracerColour"), d.feel.tracerColour);
    d.feel.shake = num(f, "shake", d.feel.shake);

    const Json& h = j.get("hold");
    d.hold.offset = jsonVec3(h.get("offset"), d.hold.offset);
    d.hold.rotation = jsonVec3(h.get("rotation"), d.hold.rotation);
    d.hold.scale = num(h, "scale", d.hold.scale);

    d.userMade = true;
    d.clamp();
    out = std::move(d);
    return true;
}

// ------------------------------------------------------------------ library

std::string ItemLibrary::fileNameFor(const std::string& itemName) { return AssetLibrary::fileNameFor(itemName); }

void ItemLibrary::add(ItemDef d) {
    d.clamp();
    const std::string name = d.name;
    if (!d.userMade && std::find(builtinOrder.begin(), builtinOrder.end(), name) == builtinOrder.end()) builtinOrder.push_back(name);
    if (d.userMade) builtinOrder.erase(std::remove(builtinOrder.begin(), builtinOrder.end(), name), builtinOrder.end());
    items[name] = std::move(d);
}

const ItemDef* ItemLibrary::find(const std::string& name) const {
    auto it = items.find(name);
    return it == items.end() ? nullptr : &it->second;
}

const ItemDef* ItemLibrary::findByAsset(const std::string& assetName) const {
    const ItemDef* builtin = nullptr;
    for (const auto& kv : items) {
        if (kv.second.asset != assetName) continue;
        if (kv.second.userMade) return &kv.second;
        if (!builtin) builtin = &kv.second;
    }
    return builtin;
}

std::vector<std::string> ItemLibrary::names() const {
    std::vector<std::string> mine, out;
    for (const auto& [name, d] : items) if (d.userMade) mine.push_back(name);
    std::sort(mine.begin(), mine.end(), [](const std::string& a, const std::string& b) { return lower(a) < lower(b); });
    out = std::move(mine);
    for (const std::string& n : builtinOrder) if (items.count(n)) out.push_back(n);
    return out;
}

bool ItemLibrary::remove(const std::string& name) {
    builtinOrder.erase(std::remove(builtinOrder.begin(), builtinOrder.end(), name), builtinOrder.end());
    return items.erase(name) > 0;
}

int ItemLibrary::loadDirectory(const std::string& dir) {
    namespace fs = std::filesystem;
    std::error_code ec;
    if (!fs::is_directory(dir, ec)) return 0;
    int n = 0;
    for (const auto& e : fs::directory_iterator(dir, ec)) {
        if (!e.is_regular_file() || e.path().extension() != ".pxitem") continue;
        std::ifstream in(e.path(), std::ios::binary);
        std::stringstream buf; buf << in.rdbuf();
        ItemDef d;
        if (itemFromText(buf.str(), d)) { add(std::move(d)); ++n; }
    }
    return n;
}

bool ItemLibrary::save(ItemDef d, const std::string& dir) {
    d.userMade = true;
    d.clamp();
    if (d.name.empty()) return false;
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    const std::filesystem::path path = std::filesystem::path(dir) / (fileNameFor(d.name) + ".pxitem");
    const std::string tmp = path.string() + ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out) return false;
        out << itemToText(d);
        if (!out) return false;
    }
    std::filesystem::rename(tmp, path, ec);
    if (ec) { std::filesystem::remove(tmp, ec); return false; }
    add(std::move(d));
    return true;
}

bool ItemLibrary::deleteFile(const std::string& name, const std::string& dir) {
    std::error_code ec;
    const bool removed = std::filesystem::remove(std::filesystem::path(dir) / (fileNameFor(name) + ".pxitem"), ec);
    remove(name);
    return removed;
}

} // namespace px
