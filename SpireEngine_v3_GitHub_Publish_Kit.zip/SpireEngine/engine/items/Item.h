#pragma once
// Items: things a character holds and uses. An item is an Asset (the model, with `grip` and `muzzle`
// sockets) plus a behaviour and some numbers. It is saved as <name>.pxitem (readable JSON) in the
// same folder as the .pxasset it uses, so one folder is one game's creations.
//
//   Behaviour   what pressing the button does
//   Melee       swing: hits whatever is in reach at the middle of the swing
//   Hitscan     a bullet that arrives at once (pistols, rifles, shotguns with pellets)
//   Projectile  a thing that flies (rockets, arrows, fireballs); goes off when it hits something
//   Thrown      a thing you throw; bounces, and goes off after its fuse (grenades)
//   Tool        shapes the world: Carve with the main button, the opposite with the second
//
// The world effect is what a hit does to the voxel world (a crater, or a lump built up), and `push`
// is how hard a blast shoves whoever stands near it. Nothing here knows about windows or OpenGL.
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "world/Materials.h"

namespace px {

enum class Behaviour : std::uint8_t { Melee, Hitscan, Projectile, Thrown, Tool };     // append only: stored in files
constexpr int kBehaviourCount = 5;
const char* behaviourName(Behaviour b);       // "Hitscan gun"
const char* behaviourKey(Behaviour b);        // "hitscan" (what the file says)
const char* behaviourInfo(Behaviour b);       // one line for the Item Builder
bool behaviourFromKey(const std::string& key, Behaviour& out);

enum class WorldEffect : std::uint8_t { None, Carve, Build };
const char* worldEffectName(WorldEffect e);   // "Carve"

struct ItemStats {
    float damage     = 20.0f;     // per hit (per pellet); games decide what it does, the range counts it
    float fireRate   = 4.0f;      // uses per second (melee: swings per second)
    bool  automatic  = false;     // hold the button to keep going
    int   magazine   = 12;        // uses before reloading; 0 = never needs reloading
    float reloadTime = 1.4f;      // seconds
    int   pellets    = 1;         // hitscan: bullets per shot
    float spread     = 1.0f;      // degrees: how far a bullet can stray from where you aim
    float recoil     = 1.5f;      // degrees the view kicks up per use
    float range      = 120.0f;    // metres: hitscan and tool reach, melee reach, how far a projectile flies
    float speed      = 40.0f;     // metres per second for projectiles and thrown things
    float gravity    = 0.0f;      // metres per second squared pulling a projectile down
    float fuse       = 0.0f;      // seconds until a thrown thing goes off (0 = when it hits something)
    float bounce     = 0.0f;      // thrown: how much speed a bounce keeps (0..0.9)
    float swingArc   = 100.0f;    // melee: degrees the swing covers
    bool operator==(const ItemStats&) const = default;
};

struct ItemEffect {
    WorldEffect kind = WorldEffect::Carve;
    float       radius = 0.5f;            // metres: the crater or lump
    MaterialId  material = MAT_STONE;     // what a Build effect is made of
    float       push = 0.0f;              // blast strength: metres per second given to whoever is at the centre
    bool operator==(const ItemEffect&) const = default;
};

struct ItemFeel {
    std::string fireSound = "shot";       // a clip in the sound bank ("shot", "boom", "whoosh", "zap", "dig", ...)
    std::string impactSound;              // empty: picked from the material that was hit
    float       volume = 1.0f;
    float       pitch  = 1.0f;
    bool        muzzleFlash = true;
    bool        tracer = true;
    glm::vec3   tracerColour{ 1.0f, 0.82f, 0.45f };
    float       shake = 0.4f;             // how much the view shakes when it goes off (blasts shake by distance)
    bool operator==(const ItemFeel&) const = default;
};

// How it sits in the hand, relative to the view: offset is right / up / forward in metres from the camera, rotation
// is turn / tilt / roll in degrees on top of the standard pose, scale resizes the model in the hand only.
struct ItemHold {
    glm::vec3 offset{ 0.22f, -0.20f, 0.50f };
    glm::vec3 rotation{ 0.0f };
    float     scale = 1.0f;
    bool operator==(const ItemHold&) const = default;
};

struct ItemDef {
    std::string name;                     // also the file name: <name>.pxitem
    std::string asset;                    // the model (an asset name)
    std::string description;
    Behaviour   behaviour = Behaviour::Hitscan;
    ItemStats   stats;
    ItemEffect  effect;
    ItemFeel    feel;
    ItemHold    hold;
    bool        userMade = false;         // a .pxitem file, not one the engine ships with

    // A sensible starting point for a behaviour: stats, effect, feel and hand position all filled in.
    static ItemDef defaultsFor(Behaviour b, const std::string& name, const std::string& asset);
    void clamp();                         // brings every number into a range the runtime can use
    bool operator==(const ItemDef&) const = default;
};

std::string itemToText(const ItemDef& d);                          // readable JSON
bool itemFromText(const std::string& text, ItemDef& out, std::string* error = nullptr);

// Every item the game knows: the ones that ship with the engine, and the ones loaded from .pxitem files.
class ItemLibrary {
public:
    void add(ItemDef d);                                            // replaces one of the same name
    const ItemDef* find(const std::string& name) const;
    const ItemDef* findByAsset(const std::string& assetName) const;   // the item that uses this model (yours first), or null
    bool has(const std::string& name) const { return find(name) != nullptr; }
    std::vector<std::string> names() const;                         // yours first (A to Z), then the built-in ones in their own order
    bool remove(const std::string& name);                           // forgets it (does not delete a file)
    size_t size() const { return items.size(); }

    int  loadDirectory(const std::string& dir);                     // every .pxitem in it; returns how many
    bool save(ItemDef d, const std::string& dir);                   // writes <dir>/<file name>.pxitem, then keeps it as yours
    bool deleteFile(const std::string& name, const std::string& dir);
    static std::string fileNameFor(const std::string& itemName);

private:
    std::map<std::string, ItemDef> items;
    std::vector<std::string> builtinOrder;
};

} // namespace px
