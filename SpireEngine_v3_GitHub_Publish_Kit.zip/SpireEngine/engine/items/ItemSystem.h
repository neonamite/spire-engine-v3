#pragma once
// The held-item runtime: a hotbar of items, one in the hand, and everything that happens when you use
// it (shots, swings, throws, blasts) plus how it looks (the item in the hand, tracers, flashes, sparks).
//
// It knows nothing about windows, the editor or even the terrain. Everything it needs from the
// world around it comes through ItemWorld, which the engine implements for the real world (play mode)
// and the Asset Workshop implements for its firing range. So tests can fake one too.
#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "items/Item.h"
#include "render/Renderer.h"
#include "scene/Asset.h"

struct ImDrawList;

namespace px {

struct ItemRayHit {
    glm::vec3 point{ 0.0f }, normal{ 0.0f, 1.0f, 0.0f };
    float distance = 0.0f;
    std::uint32_t object = 0;            // the scene object that was hit; 0 = the terrain (or anything that is not an object)
    MaterialId material = MAT_STONE;     // what was hit is made of
    int target = -1;                     // the firing range numbers its targets; -1 elsewhere
};

// Handed to the game (Game::onItemHit) and the firing range every time something is hit or goes off.
struct ItemHit {
    const ItemDef* item = nullptr;
    glm::vec3 point{ 0.0f }, normal{ 0.0f, 1.0f, 0.0f };
    float distance = 0.0f;
    float damage = 0.0f;
    std::uint32_t object = 0;
    int target = -1;
    bool explosion = false;              // a blast: `radius` says how big
    float radius = 0.0f;
    bool melee = false;
};

// What an item needs from the world around it.
class ItemWorld {
public:
    virtual ~ItemWorld() = default;
    // The nearest thing a ray reaches within maxDistance (terrain, objects, targets).
    virtual bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDistance, ItemRayHit& hit) = 0;
    // Digs (or builds up) the world: a crater / lump of the given radius.
    virtual void crater(const glm::vec3& centre, float radius, bool build, MaterialId material) = 0;
    // A blast shoves things near its centre; `push` is the speed it gives at the centre, fading out with distance.
    virtual void blast(const glm::vec3& centre, float radius, float push) { (void)centre; (void)radius; (void)push; }
    virtual void sound(const std::string& clip, const glm::vec3& at, float volume, float pitch) = 0;
    virtual void hit(const ItemHit& h) { (void)h; }
};

// Where the character's eyes are and which way they face. Updated every frame by whoever drives the system.
struct ItemView {
    glm::vec3 eye{ 0.0f };
    glm::vec3 forward{ 0.0f, 0.0f, -1.0f }, right{ 1.0f, 0.0f, 0.0f }, up{ 0.0f, 1.0f, 0.0f };
    float walkSpeed = 0.0f;              // metres per second on the ground: the item sways more while walking
    static ItemView fromAngles(const glm::vec3& eye, float yawDeg, float pitchDeg, float walkSpeed = 0.0f);
};

// A short-lived picture: a tracer line, a muzzle flash, sparks, a fireball. Drawn over the 3D view.
struct ItemFx {
    enum class Kind : std::uint8_t { Tracer, Flash, Sparks, Blast, Puff };
    Kind kind = Kind::Puff;
    glm::vec3 a{ 0.0f }, b{ 0.0f };      // tracer: from, to. Others: a = where; b = the surface normal (sparks) or direction (flash)
    glm::vec3 colour{ 1.0f };
    float age = 0.0f, life = 0.2f, size = 1.0f;
    std::uint32_t seed = 0;
    bool visible = true;                 // false while something solid is in the way
};

class ItemSystem {
public:
    struct Slot { std::string item; int ammo = 0; };

    // ---- setup
    bool enabled = false;                                   // takes input and draws the hand; effects always finish
    const ItemLibrary* library = nullptr;
    AssetLibrary*      assets = nullptr;
    // Where models come from when it is not the library: the firing range shows the unsaved model being built.
    std::function<AssetPtr(const std::string&)> findAsset;
    std::vector<Slot>  slots;                               // the hotbar, slot 1 first
    int                current = -1;                        // the slot in the hand (-1: empty hand)
    static constexpr int kMaxSlots = 9;

    void setHotbar(const std::vector<std::string>& names, int select = 0);      // full ammo in every slot
    int  give(const std::string& item, bool select = true);                    // into the first free slot, or refills the one that has it; returns the slot (-1: full)
    void select(int slot);
    void cycle(int direction);
    void reset();                                           // no projectiles, effects or buttons held; the hand starts fresh

    // ---- input
    void pressTrigger(int button);                          // 0 = main (left mouse), 1 = second (right mouse)
    void releaseTrigger(int button);
    void reload();

    // ---- per frame
    void update(float dt, ItemWorld& world, const ItemView& view);

    // ---- what is in the hand
    const ItemDef* currentDef() const;
    const ItemDef* defAt(int slot) const;
    int   ammo() const;                                     // uses left in the magazine (0 for items that never reload)
    bool  reloading() const { return reloadLeft > 0.0f; }
    float reloadProgress() const;                           // 0..1
    bool  ready() const;                                    // could be used this instant
    float crosshairSpread() const;                          // degrees, for the HUD
    bool  swinging() const { return swingT >= 0.0f; }

    // The held item as the renderer wants it (false when the hand is empty, or the item has been thrown).
    bool  heldDraw(const ItemView& view, ObjectDraw& out) const;
    glm::vec3 muzzlePoint(const ItemView& view) const;

    // Camera feedback: upward kick (degrees) to add to the view this frame, and a small shake (degrees).
    float takeViewKick();
    glm::vec3 shakeAngles() const;                          // yaw, pitch, roll offsets in degrees for drawing only
    float hitmarker() const { return hitmarkerT; }          // 1 -> 0 after a hit (the HUD flashes the crosshair)

    // ---- bookkeeping the range and tests read
    struct Totals { int shots = 0; int hits = 0; float damage = 0.0f; int explosions = 0; } totals;
    struct Projectile {
        glm::vec3 pos{ 0.0f }, vel{ 0.0f };
        const ItemDef* def = nullptr;
        float age = 0.0f, travelled = 0.0f, trail = 0.0f;
        bool resting = false;
        bool dead = false;
    };
    const std::vector<Projectile>& projectiles() const { return flying; }
    const std::vector<ItemFx>& effects() const { return fx; }

    // Draws tracers, flashes, sparks and blasts into a screen rectangle of the window (x, y, w, h in window points).
    void drawFx(ImDrawList* dl, const glm::mat4& viewProj, const ItemView& view, float x, float y, float w, float h, float uiScale) const;

private:
    struct Pose;
    AssetPtr assetFor(const std::string& name) const;
    glm::mat4 heldMatrix(const ItemView& view, const ItemDef& def, const Asset* asset) const;
    bool canUse(const ItemDef& def) const;
    void use(int button, ItemWorld& world, const ItemView& view);
    void fireHitscan(const ItemDef& def, ItemWorld& world, const ItemView& view);
    void fireProjectile(const ItemDef& def, ItemWorld& world, const ItemView& view, bool thrown);
    void useTool(const ItemDef& def, int button, ItemWorld& world, const ItemView& view);
    void meleeStrike(const ItemDef& def, ItemWorld& world, const ItemView& view);
    void landHit(const ItemDef& def, ItemWorld& world, const ItemRayHit& h, float damage, bool melee, bool crater);
    void explode(const ItemDef& def, ItemWorld& world, const ItemView& view, const glm::vec3& at, const glm::vec3& normal, std::uint32_t object);
    void updateProjectiles(float dt, ItemWorld& world, const ItemView& view);
    void startReload(ItemWorld& world, const ItemView& view);
    void addFx(ItemFx f) { if (fx.size() < 200) fx.push_back(std::move(f)); }
    float rnd();
    glm::vec3 coneAround(const glm::vec3& dir, float spreadDeg);
    const Slot* slot() const { return current >= 0 && current < int(slots.size()) ? &slots[current] : nullptr; }
    Slot* slot() { return current >= 0 && current < int(slots.size()) ? &slots[current] : nullptr; }

    bool  held[2] = { false, false };
    float pressBuffer[2] = { 0.0f, 0.0f };                  // a press that came a moment too early still counts
    float cooldown = 0.0f;
    float reloadLeft = 0.0f, reloadTotal = 0.0f;
    float equipT = 1.0f;                                    // 0 -> 1 while the item is raised; below 0 it is out of the hand (just thrown)
    float swingT = -1.0f, swingLength = 0.4f;               // melee / tool animation; -1 = not swinging
    bool  swingStruck = false;
    int   swingButton = 0;
    float kickAnim = 0.0f;                                  // 0..1 recoil of the item in the hand
    float pendingKick = 0.0f, recovering = 0.0f;
    float shake = 0.0f;
    float hitmarkerT = 0.0f;
    bool  reloadRequested = false;
    float kickOut = 0.0f;
    float bobPhase = 0.0f, bobAmount = 0.0f;
    double clock = 0.0;
    std::uint32_t rngState = 0x2545F491u;

    std::vector<Projectile> flying;
    std::vector<ItemFx> fx;
};

} // namespace px
