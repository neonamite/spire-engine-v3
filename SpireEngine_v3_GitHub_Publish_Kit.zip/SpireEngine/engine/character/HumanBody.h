#pragma once
// Realistic people (1.5): every character's body is the MakeHuman base human (CC0, engine/assets/human), shaped by the
// character's look (gender, age, muscle, weight, heritage, face) with MakeHuman's own shape targets, fitted onto the
// character's skeleton, and skinned to it, so the animation, IK and everything held or worn works as before.
//
//   - The skin is the person's colour over shared detail maps on the body's UV layout (lips, cheeks, brows, nails,
//     creases), with the Skin material's pores on top. Eyes are real eyeballs; teeth, tongue and lashes are there too.
//   - Faces move with expressions (blink, smile, frown, brows...) mixed on the graphics card each frame, not by
//     swapping heads.
//   - Close-fitting clothes (shirts, sleeves, trousers, jackets, armour) are shells around the body, made from the body
//     itself; loose things (skirts, robes, shoes and boots, hair, hats, glasses, beards, backpacks) are the parts they
//     always were, worn on their bones.
#include <memory>
#include <string>
#include <vector>
#include "character/Animator.h"
#include "character/Character.h"
#include "render/SkinnedMesh.h"

namespace px {

class AssetLibrary;

// The expressions, in the order the renderer mixes them (Expressions[i]).
enum class Expression : std::uint8_t { Blink, MouthOpen, Smile, Frown, Press, BrowsDown, BrowsUp, BrowsWorried, Count };
static_assert(int(Expression::Count) == kMaxExpressions, "one slot per expression");

// Is the MakeHuman body there (engine/assets/human/human.pxh)? Without it people are drawn the 1.4 way.
bool humanBodyAvailable();
// Draw people as realistic bodies (the default) or the 1.4 way (voxel parts; tests, --voxel-people).
void setRealisticPeople(bool on);
bool realisticPeople();
// Does this character use the realistic body? (Yes, unless it has a head of your own making, or the body is missing.)
bool usesHumanBody(const CharacterDef& c);

struct HumanBody {
    std::shared_ptr<SkinnedMesh> mesh;
    std::shared_ptr<SkinnedMesh> hair;  // hair as see-through cards (the built-in styles), on the head bone; null: bald or a hair part
    // Where the head's things go: the voxel head they were made for, fitted onto this head (head bone space).
    glm::mat4 headFit{ 1.0f };         // hair parts (the skull onto the skull)
    glm::mat4 hatFit{ 1.0f };          // hats: the same, a little lower (the hair under them lies flat)
    glm::mat4 faceFit{ 1.0f };         // glasses and beards: the voxel face's eyes onto these eyes
    bool hairAsCards = false;          // the hair is in `hair` (the built-in styles), not drawn as its part
    bool beardAsCards = false;         // the beard is in `hair` (the built-in beards), not drawn as its part
    bool shoesAsParts = true;           // the feet are drawn by the Foot part (shoes, boots); the body's own are hidden
    std::vector<PartSlot> rigidSlots;   // the slots whose parts are drawn as parts (skirts, robes, shoes...), not as shells
};

// Builds one (tests; the cache below is what drawing uses).
std::shared_ptr<HumanBody> buildHumanBody(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib);
// The body for this character and skeleton, built the first time and then cached. nullptr while it waits its turn
// (a crowd arriving at once is spread over a few frames) or when it cannot be built.
std::shared_ptr<const HumanBody> humanBodyFor(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib);
size_t humanBodyCacheSize();
void clearHumanBodyCache();

// The face of the moment: the character's resting face and mood, and a blink.
Expressions expressionsFor(const CharacterDef& c, const AnimOutput& pose);

// The shared skin maps, eyes and expression shapes (made the first time, cached on disk in cache/human/), handed to the
// renderer. Call once a frame or whenever; cheap after the first time.
void ensureHumanRenderData();
// The skin maps on their own, at `size` (tests; the debug view).
std::shared_ptr<HumanRenderData> bakeHumanRenderData(int size);

} // namespace px
