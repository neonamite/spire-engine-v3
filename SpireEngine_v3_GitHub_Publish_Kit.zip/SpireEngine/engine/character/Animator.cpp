#include "character/Animator.h"
#include <algorithm>
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {
constexpr float kPi = 3.14159265f;
float smooth01(float a, float b, float x) { const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }
float approach(float v, float target, float rate, float dt) { return v + (target - v) * std::min(1.0f, rate * dt); }
float wrapDeg(float d) { d = std::fmod(d + 180.0f, 360.0f); if (d < 0.0f) d += 360.0f; return d - 180.0f; }
glm::quat ax(float a) { return glm::angleAxis(a, glm::vec3(1, 0, 0)); }
glm::quat ay(float a) { return glm::angleAxis(a, glm::vec3(0, 1, 0)); }
glm::quat az(float a) { return glm::angleAxis(a, glm::vec3(0, 0, 1)); }
glm::vec3 pos(const glm::mat4& m) { return glm::vec3(m[3]); }
} // namespace

glm::quat boneAim(const glm::vec3& dirIn, const glm::vec3& xHint) {
    const glm::vec3 dir = glm::normalize(dirIn);
    const glm::vec3 y = -dir;
    glm::vec3 x = xHint - y * glm::dot(xHint, y);
    if (glm::length(x) < 1e-4f) { x = glm::cross(y, glm::vec3(0, 0, 1)); if (glm::length(x) < 1e-4f) x = glm::cross(y, glm::vec3(1, 0, 0)); }
    x = glm::normalize(x);
    const glm::vec3 z = glm::cross(x, y);
    return glm::normalize(glm::quat_cast(glm::mat3(x, y, z)));
}

const char* moodLabel(Mood m) {
    static const char* n[] = { "Calm", "Happy", "Angry", "Scared", "Sad", "Talking" };
    return size_t(m) < std::size(n) ? n[size_t(m)] : "Calm";
}
const char* fidgetLabel(Fidget f) {
    static const char* n[] = { "Nothing", "Look around", "Shift weight", "Cross arms", "Hands on hips", "Check watch", "Stretch", "Scratch head", "Wave", "Work" };
    return size_t(f) < std::size(n) ? n[size_t(f)] : "Nothing";
}

void CharacterAnimator::reset(float yaw) {
    yawDeg = yaw; gait = 0.0f; move = run = air = land = time = prevVy = drop = 0.0f;
    blinkTimer = 2.0f; blinkLeft = idleTime = fidgetTime = fidgetLength = fidgetBlend = talk = 0.0f;
    fidgetNow = fidgetShown = Fidget::None;
    swayPos = swayVel = swayPrevVel = glm::vec3(0.0f);
    rng = 0;
    started = true;
}

float CharacterAnimator::rand01() {
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return float(rng % 10000u) / 10000.0f;
}

void CharacterAnimator::startFidget(Fidget f, float seconds) {
    fidgetNow = f; fidgetTime = 0.0f; fidgetLength = seconds; idleTime = 0.0f;
    if (f != Fidget::None) fidgetShown = f;
}

const AnimOutput& CharacterAnimator::update(const Skeleton& sk, const AnimInput& in, float dtIn) {
    const float dt = std::clamp(dtIn, 0.0f, 0.1f);
    if (!started) reset(glm::degrees(std::atan2(in.facing.x, in.facing.z)));
    if (rng == 0) { rng = (in.seed * 2654435761u) ^ 0x9E3779B9u; if (rng == 0) rng = 1; blinkTimer = 0.5f + 3.0f * rand01(); }
    time += dt;
    MoveStyle st = in.style;
    st.clamp();

    // ---- what the body is doing
    const glm::vec2 v2(in.velocity.x, in.velocity.z);
    const float speed = glm::length(v2);
    if (glm::length(glm::vec2(in.facing.x, in.facing.z)) > 1e-4f) {
        const float target = glm::degrees(std::atan2(in.facing.x, in.facing.z));
        yawDeg = wrapDeg(yawDeg + wrapDeg(target - yawDeg) * std::min(1.0f, dt * 10.0f));
    }
    const float s = sk.scale;
    air = approach(air, in.grounded ? 0.0f : 1.0f, 8.0f, dt);
    move = approach(move, in.grounded ? smooth01(0.12f, 1.2f * s, speed) : 0.0f, 8.0f, dt);
    run = approach(run, smooth01(2.8f * s, 5.2f * s, speed), 5.0f, dt);
    if (in.grounded && prevVy < -4.0f) land = std::min(1.0f, -prevVy / 12.0f);
    land = std::max(0.0f, land - dt * 3.0f);
    prevVy = in.grounded ? 0.0f : in.velocity.y;

    const glm::vec3 fwd(std::sin(glm::radians(yawDeg)), 0.0f, std::cos(glm::radians(yawDeg)));
    if (in.grounded && speed > 0.05f) {
        const float along = glm::dot(glm::vec3(v2.x, 0.0f, v2.y), fwd);
        const float sign = along < -0.3f * speed ? -1.0f : 1.0f;            // walking backwards plays the stride backwards
        const float stride = s * (1.35f + 0.9f * run) * st.stride;                        // metres for a whole cycle (two steps)
        gait = std::fmod(gait + sign * speed * dt / stride * 2.0f * kPi + 4.0f * kPi, 2.0f * kPi);
    }

    // ---- the pose
    Pose p;
    const float m = move, r = run, a = air;
    for (int side = 0; side < 2; ++side) {
        const float ph = gait + (side == 0 ? 0.0f : kPi);
        const float hipAmp = m * (0.42f + 0.33f * r) * (0.75f + 0.25f * st.stride);
        float thigh = -hipAmp * std::sin(ph);                                 // negative swings it forward
        float knee = 0.04f + m * (0.08f + (0.85f + 0.75f * r) * std::max(0.0f, std::cos(ph)));
        // in the air: one knee up, the other trailing; landing: both bend
        thigh = glm::mix(thigh, side == 0 ? -0.75f : -0.25f, a);
        knee = glm::mix(knee, side == 0 ? 1.2f : 0.7f, a) + land * 0.9f;
        thigh -= land * 0.45f;
        const float foot = -(thigh + knee) * 0.9f;                            // keep the foot roughly level
        const float out = (side == 0 ? 1.0f : -1.0f) * (0.02f + 0.05f * a);
        p.local[size_t(side == 0 ? Bone::UpperLegL : Bone::UpperLegR)] = az(out) * ax(thigh);
        p.local[size_t(side == 0 ? Bone::LowerLegL : Bone::LowerLegR)] = ax(knee);
        p.local[size_t(side == 0 ? Bone::FootL : Bone::FootR)] = ax(foot);

        // arms swing against the legs
        const float armAmp = m * (0.35f + 0.45f * r) * st.armSwing;
        const float swing = armAmp * std::sin(ph) * (1.0f - a) - a * 0.5f;
        const float spread = (side == 0 ? 1.0f : -1.0f) * (0.09f + 0.08f * r + 0.55f * a);
        const float elbow = -(0.12f + 0.22f * m + 0.95f * r) * (1.0f - a) - a * 0.4f;
        p.local[size_t(side == 0 ? Bone::UpperArmL : Bone::UpperArmR)] = az(spread) * ax(swing);
        p.local[size_t(side == 0 ? Bone::LowerArmL : Bone::LowerArmR)] = ax(elbow);
    }
    const float bob = m * (0.012f + 0.03f * r) * st.bounce * (0.5f + 0.5f * std::cos(2.0f * gait));
    p.pelvisOffset = glm::vec3(0.0f, -bob * s - land * 0.16f * s, 0.0f);
    p.local[size_t(Bone::Pelvis)] = ay((0.10f + 0.16f * st.swagger) * m * std::sin(gait)) * az(0.07f * st.swagger * m * std::sin(gait));
    // posture: hunched (-1) leans the chest forward; proud (+1) pushes it back a little
    float lean = 0.05f * m + 0.16f * r + 0.012f * std::sin(time * 1.7f) * (1.0f - m) + land * 0.25f;
    lean += st.posture < 0.0f ? -st.posture * 0.28f : -st.posture * 0.07f;
    if (in.mood == Mood::Sad) lean += 0.18f;
    p.local[size_t(Bone::Chest)] = ay(-(0.16f + 0.18f * st.swagger) * m * std::sin(gait)) * ax(lean);
    p.local[size_t(Bone::Neck)] = ax(-lean * 0.5f);
    p.local[size_t(Bone::Head)] = ax(-lean * 0.5f);

    // ---- personality: blinking, the face of a mood, and what they do with themselves while standing about
    blinkTimer -= dt;
    if (blinkTimer <= 0.0f) { blinkLeft = 0.13f; blinkTimer = 1.8f + 3.5f * rand01(); if (rand01() < 0.15f) blinkTimer = 0.25f; }   // now and then a double blink
    blinkLeft = std::max(0.0f, blinkLeft - dt);
    out.blink = blinkLeft > 0.0f;
    out.mouth = out.brows = -1;
    talk += dt;
    switch (in.mood) {
    case Mood::Happy:   out.mouth = 3; out.brows = 1; break;
    case Mood::Angry:   out.mouth = 4; out.brows = 2; break;
    case Mood::Scared:  out.mouth = 2; out.brows = 3; break;
    case Mood::Sad:     out.mouth = 4; out.brows = 3; break;
    case Mood::Talking: out.mouth = (std::fmod(talk, 0.36f) < 0.18f) ? 3 : 2; break;
    default: break;
    }
    const bool idle = m < 0.05f && a < 0.05f && in.hold == HoldKind::None && in.grounded;
    if (fidgetNow != Fidget::None) {
        fidgetTime += dt;
        if (fidgetTime >= fidgetLength || (!idle && fidgetLength < 100.0f)) { fidgetNow = Fidget::None; idleTime = 0.0f; }
    } else if (idle && in.idleFidgets && st.fidget > 0.01f) {
        idleTime += dt;
        const float wait = 2.0f + 9.0f * (1.0f - st.fidget);                  // fidgety people wait less
        if (idleTime > wait) startFidget(Fidget(1 + int(rand01() * 0.999f * float(kIdleFidgets))), 2.5f + 2.0f * rand01());
    } else idleTime = 0.0f;
    fidgetBlend = approach(fidgetBlend, fidgetNow != Fidget::None ? 1.0f : 0.0f, 5.0f, dt);
    if (fidgetBlend < 0.01f) fidgetShown = Fidget::None;
    if (fidgetShown != Fidget::None && fidgetBlend > 0.001f) {
        const float w = fidgetBlend, t = fidgetTime;
        auto blend = [&](Bone b, const glm::quat& q) { p.local[size_t(b)] = glm::slerp(p.local[size_t(b)], q, w); };
        auto arms = [&](float uz, float ux, const glm::quat& lowerL, const glm::quat& lowerR) {   // uz: out (+) for the left arm, mirrored
            blend(Bone::UpperArmL, az(uz) * ax(ux)); blend(Bone::UpperArmR, az(-uz) * ax(ux));
            blend(Bone::LowerArmL, lowerL); blend(Bone::LowerArmR, lowerR);
        };
        switch (fidgetShown) {
        case Fidget::LookAround: {
            const float turn = 0.75f * std::sin(t * 1.4f);
            blend(Bone::Neck, ay(turn * 0.4f)); blend(Bone::Head, ay(turn * 0.6f) * ax(-0.05f));
            break;
        }
        case Fidget::ShiftWeight:
            p.pelvisOffset.x += 0.035f * s * w;
            p.local[size_t(Bone::Pelvis)] = p.local[size_t(Bone::Pelvis)] * glm::slerp(glm::quat(1, 0, 0, 0), az(-0.06f), w);
            blend(Bone::UpperLegR, az(-0.04f) * ax(-0.12f)); blend(Bone::LowerLegR, ax(0.28f)); blend(Bone::FootR, ax(-0.14f));
            break;
        case Fidget::CrossArms:
            arms(0.18f, -0.3f, ay(-1.15f) * ax(-1.55f), ay(1.15f) * ax(-1.55f));
            break;
        case Fidget::HandsOnHips:
            arms(0.62f, 0.32f, az(-1.6f) * ax(0.15f), az(1.6f) * ax(0.15f));
            break;
        case Fidget::CheckWatch:
            blend(Bone::UpperArmL, az(0.25f) * ax(-0.55f)); blend(Bone::LowerArmL, ay(-1.05f) * ax(-1.45f));
            blend(Bone::Neck, ay(0.15f) * ax(0.2f)); blend(Bone::Head, ay(0.2f) * ax(0.3f));
            break;
        case Fidget::Stretch: {
            const float up = 0.5f + 0.5f * std::sin(std::min(t, 2.0f) * 0.785f);
            arms(2.75f * up + 0.1f, 0.0f, ax(-0.25f * up), ax(-0.25f * up));
            blend(Bone::Chest, ax(-0.14f * up)); blend(Bone::Head, ax(-0.2f * up));
            break;
        }
        case Fidget::Wave:                                                     // the right hand up, waving
            blend(Bone::UpperArmR, az(-2.5f) * ax(-0.2f)); blend(Bone::LowerArmR, az(0.35f + 0.45f * std::sin(t * 9.0f)));
            break;
        case Fidget::Work: {                                                   // hammering at something in front of them
            const float hit = std::pow(0.5f + 0.5f * std::sin(t * 6.0f), 2.0f);
            blend(Bone::Chest, ax(0.25f)); blend(Bone::Neck, ax(0.15f)); blend(Bone::Head, ax(0.25f));
            blend(Bone::UpperArmR, az(-0.15f) * ax(-0.5f - 1.6f * hit)); blend(Bone::LowerArmR, ax(-0.9f + 0.6f * hit));
            blend(Bone::UpperArmL, az(0.2f) * ax(-0.7f)); blend(Bone::LowerArmL, ay(-0.6f) * ax(-0.9f));
            break;
        }
        case Fidget::ScratchHead:
            blend(Bone::UpperArmR, az(-1.5f) * ax(-0.35f)); blend(Bone::LowerArmR, az(-2.05f + 0.12f * std::sin(t * 14.0f)));
            blend(Bone::Head, az(0.12f) * ax(0.08f));
            break;
        default: break;
        }
    }
    out.fidget = fidgetShown;
    if (in.mood == Mood::Scared) {                                             // knees in, hands up
        for (int side = 0; side < 2; ++side) {
            const float sg = side == 0 ? 1.0f : -1.0f;
            p.local[size_t(side == 0 ? Bone::UpperArmL : Bone::UpperArmR)] = az(0.15f * sg) * ax(-0.5f);
            p.local[size_t(side == 0 ? Bone::LowerArmL : Bone::LowerArmR)] = ax(-1.6f);
        }
    }

    const glm::quat yawQ = glm::angleAxis(glm::radians(yawDeg), glm::vec3(0, 1, 0));
    out.root = glm::translate(glm::mat4(1.0f), in.position) * glm::mat4_cast(yawQ);
    out.world = poseToWorld(sk, p, out.root);

    // ---- looking at something: the neck and head share the turn, as far as a neck can go
    if (in.hasLook) {
        const glm::vec3 eye = pos(out.world[size_t(Bone::Head)]) + glm::vec3(0.0f, 0.12f * s, 0.0f);
        const glm::vec3 d = glm::inverse(glm::mat3(out.root)) * (in.lookAt - eye);
        if (glm::length(d) > 0.05f) {
            float yawL = std::atan2(d.x, d.z), pitchL = std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z));
            if (std::fabs(yawL) > 2.2f) yawL = 0.0f, pitchL = 0.0f;           // behind: don't wrench the neck round
            yawL = std::clamp(yawL, -1.15f, 1.15f);
            pitchL = std::clamp(pitchL, -0.6f, 0.55f);
            p.local[size_t(Bone::Neck)] = ay(yawL * 0.4f) * ax(-pitchL * 0.4f - lean * 0.5f);
            p.local[size_t(Bone::Head)] = ay(yawL * 0.6f) * ax(-pitchL * 0.6f - lean * 0.5f);
            out.world = poseToWorld(sk, p, out.root);
        }
    }

    // ---- holding something: the hands reach for where the item is held (two-bone IK on the arms)
    const glm::vec3 right = glm::vec3(out.root * glm::vec4(-1, 0, 0, 0)), up(0, 1, 0);
    const float pitch = glm::radians(std::clamp(in.aimPitch, -70.0f, 70.0f));
    const glm::vec3 aimF = glm::normalize(fwd * std::cos(pitch) + up * std::sin(pitch));
    const glm::vec3 aimU = glm::normalize(glm::cross(right, aimF));          // up, tilted with the aim
    const glm::vec3 shoulders = (pos(out.world[size_t(Bone::UpperArmL)]) + pos(out.world[size_t(Bone::UpperArmR)])) * 0.5f;
    glm::vec3 handTarget[2];
    bool reach[2] = { false, false };
    switch (in.hold) {
    case HoldKind::TwoHand:
        handTarget[1] = shoulders + right * (0.10f * s) - aimU * (0.10f * s) + aimF * (0.30f * s); reach[1] = true;
        handTarget[0] = shoulders + right * (-0.02f * s) - aimU * (0.09f * s) + aimF * (0.52f * s); reach[0] = true;
        break;
    case HoldKind::OneHand:
        handTarget[1] = shoulders + right * (0.07f * s) - aimU * (0.03f * s) + aimF * (0.50f * s); reach[1] = true;
        break;
    case HoldKind::Melee:
        handTarget[1] = shoulders + right * (0.22f * s) - up * (0.32f * s) + fwd * (0.30f * s); reach[1] = true;
        break;
    case HoldKind::None: break;
    }
    if (reach[0] || reach[1]) {
        for (int side = 0; side < 2; ++side) {
            if (!reach[side]) continue;
            const Bone ub = side == 0 ? Bone::UpperArmL : Bone::UpperArmR, lb = side == 0 ? Bone::LowerArmL : Bone::LowerArmR, hb = side == 0 ? Bone::HandL : Bone::HandR;
            const glm::vec3 A = pos(out.world[size_t(ub)]), B = pos(out.world[size_t(lb)]), C = pos(out.world[size_t(hb)]);
            const float sideSign = side == 0 ? -1.0f : 1.0f;                   // elbows out and down
            const glm::vec3 pole = A - up * 1.0f + right * (sideSign * 0.6f) - fwd * 0.2f;
            const glm::vec3 nb = solveTwoBone(A, B, C, handTarget[side], pole);
            const glm::vec3 xHint = glm::vec3(out.world[size_t(ub)][0]);
            p.local[size_t(ub)] = localFor(sk, out.world, out.root, ub, boneAim(nb - A, xHint));
            out.world = poseToWorld(sk, p, out.root);
            glm::vec3 reached;
            solveTwoBone(A, B, C, handTarget[side], pole, &reached);
            p.local[size_t(lb)] = localFor(sk, out.world, out.root, lb, boneAim(reached - pos(out.world[size_t(lb)]), glm::vec3(out.world[size_t(lb)][0])));
            out.world = poseToWorld(sk, p, out.root);
            p.local[size_t(hb)] = localFor(sk, out.world, out.root, hb, boneAim(aimF * 0.6f - aimU * 0.8f, glm::vec3(out.world[size_t(hb)][0])));
            out.world = poseToWorld(sk, p, out.root);
        }
    }

    // ---- feet on the real ground
    float wantDrop = 0.0f;
    float dy[2] = { 0.0f, 0.0f };
    const float g = 1.0f - air;
    const bool ik = footIK && in.ground && g > 0.01f;
    if (ik) {
        for (int side = 0; side < 2; ++side) {
            const glm::vec3 A = pos(out.world[size_t(side == 0 ? Bone::FootL : Bone::FootR)]);
            float gy = in.position.y;
            if (!in.ground(A.x, A.z, gy)) gy = in.position.y;
            dy[side] = std::clamp(gy - in.position.y, -0.6f * s, 0.6f * s);
        }
        wantDrop = std::max(0.0f, -std::min(dy[0], dy[1])) * g;
    }
    drop = approach(drop, wantDrop, 14.0f, dt);
    if (ik && drop > 1e-4f) {
        p.pelvisOffset.y -= drop;
        out.world = poseToWorld(sk, p, out.root);
    }
    if (ik) {
        for (int side = 0; side < 2; ++side) {
            const Bone ub = side == 0 ? Bone::UpperLegL : Bone::UpperLegR, lb = side == 0 ? Bone::LowerLegL : Bone::LowerLegR, fb = side == 0 ? Bone::FootL : Bone::FootR;
            const glm::vec3 A = pos(out.world[size_t(ub)]), B = pos(out.world[size_t(lb)]), C = pos(out.world[size_t(fb)]);
            const glm::vec3 target = C + glm::vec3(0.0f, (drop + dy[side]) * g, 0.0f);
            if (glm::length(target - C) > 1e-4f) {
                const glm::vec3 pole = B + fwd * 1.0f;                         // knees bend forward
                const glm::vec3 nb = solveTwoBone(A, B, C, target, pole);
                p.local[size_t(ub)] = localFor(sk, out.world, out.root, ub, boneAim(nb - A, glm::vec3(out.world[size_t(ub)][0])));
                out.world = poseToWorld(sk, p, out.root);
                glm::vec3 reached;
                solveTwoBone(A, B, C, target, pole, &reached);
                p.local[size_t(lb)] = localFor(sk, out.world, out.root, lb, boneAim(reached - pos(out.world[size_t(lb)]), glm::vec3(out.world[size_t(lb)][0])));
                out.world = poseToWorld(sk, p, out.root);
            }
            // the foot lies along the ground (front to back slope)
            float toe = 0.0f, heel = 0.0f;
            const glm::vec3 F = pos(out.world[size_t(fb)]);
            float slope = 0.0f;
            if (in.ground(F.x + fwd.x * 0.12f * s, F.z + fwd.z * 0.12f * s, toe) && in.ground(F.x - fwd.x * 0.06f * s, F.z - fwd.z * 0.06f * s, heel))
                slope = std::clamp(std::atan2(toe - heel, 0.18f * s), -0.5f, 0.5f) * g;
            const glm::quat footWorld = yawQ * ax(-slope);
            p.local[size_t(fb)] = localFor(sk, out.world, out.root, fb, footWorld);
            out.world = poseToWorld(sk, p, out.root);
        }
    }
    out.pelvisDrop = drop;
    out.foot[0] = pos(out.world[size_t(Bone::FootL)]);
    out.foot[1] = pos(out.world[size_t(Bone::FootR)]);

    // ---- where a held item goes: in the right palm, pointing along the aim
    const glm::mat4& hand = out.world[size_t(Bone::HandR)];
    const glm::vec3 palm = pos(hand) + glm::vec3(hand * glm::vec4(0.0f, -0.07f * s, 0.0f, 0.0f));
    const glm::vec3 itemF = in.hold == HoldKind::Melee ? glm::normalize(fwd * 0.5f + up * 0.85f) : aimF;
    const glm::vec3 itemX = glm::normalize(glm::cross(up, itemF) + glm::vec3(1e-6f, 0.0f, 0.0f));
    const glm::vec3 itemY = glm::cross(itemF, itemX);
    out.item = glm::mat4(glm::vec4(itemX, 0.0f), glm::vec4(itemY, 0.0f), glm::vec4(itemF, 0.0f), glm::vec4(palm, 1.0f));

    // ---- sway (1.6): loose things lag behind the body, swing with the steps, bob, and stir in a breeze. A damped spring
    // toward where they would hang; the renderer moves each loose vertex by this times how loose it is.
    {
        const glm::vec3 vel(in.velocity.x, 0.0f, in.velocity.z);
        glm::vec3 acc = dt > 1e-4f ? (vel - swayPrevVel) / dt : glm::vec3(0.0f);
        if (glm::length(acc) > 25.0f) acc = glm::normalize(acc) * 25.0f;
        swayPrevVel = vel;
        const glm::vec3 side = glm::normalize(glm::cross(fwd, glm::vec3(0.0f, 1.0f, 0.0f)));
        const float ph = float(in.seed % 1000u) * 0.0061f;
        glm::vec3 target = -vel * 0.03f - acc * 0.006f
                         + side * (std::sin(gait) * 0.03f * move * (1.0f + run))
                         + glm::vec3(0.0f, 1.0f, 0.0f) * (std::cos(gait * 2.0f) * 0.012f * move)
                         + glm::vec3(std::sin(time * 1.3f + ph), 0.0f, std::sin(time * 0.9f + ph * 2.0f)) * 0.006f;
        target.y -= air * 0.0f;
        const float k = 90.0f, damp = 7.0f;
        swayVel += ((target - swayPos) * k - swayVel * damp) * dt;
        swayPos += swayVel * dt;
        if (glm::length(swayPos) > 0.15f) swayPos = glm::normalize(swayPos) * 0.15f;
        out.sway = swayPos * s;
    }
    return out;
}

} // namespace px
