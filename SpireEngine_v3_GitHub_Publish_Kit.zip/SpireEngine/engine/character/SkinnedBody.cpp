#include "character/SkinnedBody.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <thread>
#include <unordered_map>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include "character/BodyParts.h"
#include "scene/Asset.h"
#include "world/WorldTypes.h"

namespace px {

namespace {

bool gSkinning = true;

struct PartInfo {
    AssetPtr asset;
    Bone bone;
    glm::vec3 boneFrom{ 0.0f }, boneTo{ 0.0f };   // the bone as a line in the bind pose (which part owns a point where parts overlap)
    glm::mat4 toLocal{ 1.0f };    // bind-pose world -> the part's own space
    float scale = 1.0f;           // the part's own distances -> metres (the smallest of its stretch, so never too far)
    glm::vec3 lo{ 0.0f }, hi{ 0.0f };
    glm::vec3 tint{ 1.0f };
};

// The blend zone of each joint, named by the bone below it: how far either side of the joint the two bones share the
// skin (`reach`), and how far off the bone's line that sharing extends (`side`). Metres on the 1.8 m body.
struct JointZone { float reach, side; };
JointZone zoneFor(Bone child) {
    switch (child) {
    case Bone::Chest: return { 0.10f, 0.35f };                                       // the waist
    case Bone::Neck: return { 0.04f, 0.12f };
    case Bone::Head: return { 0.035f, 0.12f };
    case Bone::UpperArmL: case Bone::UpperArmR: return { 0.07f, 0.11f };             // shoulders
    case Bone::LowerArmL: case Bone::LowerArmR: return { 0.06f, 0.09f };             // elbows
    case Bone::HandL: case Bone::HandR: return { 0.03f, 0.07f };                     // wrists
    case Bone::UpperLegL: case Bone::UpperLegR: return { 0.08f, 0.13f };             // hips
    case Bone::LowerLegL: case Bone::LowerLegR: return { 0.07f, 0.10f };             // knees
    case Bone::FootL: case Bone::FootR: return { 0.04f, 0.09f };                     // ankles
    default: return { 0.05f, 0.1f };
    }
}

// The material of a part at a point: of the eight voxels round it, the most solid one's (the nearest voxel can be air,
// whose material means nothing).
MaterialId solidMaterial(const Asset& a, const glm::vec3& local) {
    if (!a.valid() || a.materials.size() != a.grid.size()) return MAT_SKIN;
    const glm::vec3 g = local / a.voxelSize + a.pivot;
    const glm::ivec3 b = glm::ivec3(glm::floor(g));
    float best = 1e9f;
    MaterialId m = MAT_SKIN;
    for (int i = 0; i < 8; ++i) {
        const glm::ivec3 q = glm::clamp(b + glm::ivec3(i & 1, (i >> 1) & 1, (i >> 2) & 1), glm::ivec3(0), a.size - glm::ivec3(1));
        const size_t idx = size_t(a.index(q.x, q.y, q.z));
        if (a.grid[idx] < best) { best = a.grid[idx]; m = a.materials[idx]; }
    }
    return m == MAT_NATURAL ? MaterialId(MAT_SKIN) : m;
}

float smooth(float a, float b, float x) {
    const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

std::string keyFor(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib) {
    std::string k;
    char buf[160];
    for (int b = 0; b < kBoneCount; ++b) {
        if (!boneIsSkinned(Bone(b))) continue;
        const PartSlot slot = slotForBone(Bone(b));
        const std::string name = partAssetFor(c, slot);
        AssetPtr a = name.empty() ? nullptr : lib.get(name);
        const glm::vec3 t = a ? partTint(c, slot, name, *a, lib) : glm::vec3(0.0f);
        const glm::vec3 ps = sk.bone(Bone(b)).partScale;
        std::snprintf(buf, sizeof buf, "%s#%p#%u|%.3f,%.3f,%.3f|%.4f,%.4f,%.4f;", name.c_str(), static_cast<const void*>(a.get()), a ? a->version : 0u,
                      double(t.x), double(t.y), double(t.z), double(ps.x), double(ps.y), double(ps.z));
        k += buf;
    }
    for (int b = 0; b < kBoneCount; ++b) {
        const glm::vec3 o = sk.bone(Bone(b)).offset;
        std::snprintf(buf, sizeof buf, "%.4f,%.4f,%.4f;", double(o.x), double(o.y), double(o.z));
        k += buf;
    }
    return k;
}

std::unordered_map<std::string, std::shared_ptr<SkinnedMesh>>& cache() {
    static std::unordered_map<std::string, std::shared_ptr<SkinnedMesh>> c;
    return c;
}

} // namespace

Pose skinBindPose() {
    Pose p;
    const glm::vec3 z(0.0f, 0.0f, 1.0f);
    p.local[size_t(Bone::UpperArmL)] = glm::angleAxis(glm::radians(42.0f), z);
    p.local[size_t(Bone::UpperArmR)] = glm::angleAxis(glm::radians(-42.0f), z);
    p.local[size_t(Bone::UpperLegL)] = glm::angleAxis(glm::radians(7.0f), z);
    p.local[size_t(Bone::UpperLegR)] = glm::angleAxis(glm::radians(-7.0f), z);
    return p;
}

bool boneIsSkinned(Bone b) {
    switch (b) {
    case Bone::Head: case Bone::Count: return false;           // the head stays its own piece: its face changes (blinks, moods)
    default: return true;
    }
}

void setCharacterSkinning(bool on) { gSkinning = on; }
bool characterSkinning() { return gSkinning; }

std::shared_ptr<SkinnedMesh> buildSkinnedBody(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib, float voxel) {
    // The pose the body is built in: arms out to the sides and legs a little apart (an "A" pose), so that nothing
    // touches what it should not be fused with (a hanging forearm would melt into the hips, thighs into each other).
    const std::array<glm::mat4, kBoneCount> bind = poseToWorld(sk, skinBindPose(), glm::mat4(1.0f));

    std::vector<PartInfo> parts;
    for (int b = 0; b < kBoneCount; ++b) {
        if (!boneIsSkinned(Bone(b))) continue;
        const PartSlot slot = slotForBone(Bone(b));
        const std::string name = partAssetFor(c, slot);
        if (name.empty()) continue;
        AssetPtr a = lib.get(name);
        if (!a || a->mesh.empty() || !a->valid()) continue;
        const glm::vec3 ps = sk.bone(Bone(b)).partScale;
        const glm::mat4 m = bind[size_t(b)] * glm::scale(glm::mat4(1.0f), ps) * glm::translate(glm::mat4(1.0f), -partJoint(*a, slot));
        PartInfo p;
        p.asset = a;
        p.bone = Bone(b);
        p.toLocal = glm::inverse(m);
        p.scale = std::min(ps.x, std::min(ps.y, ps.z));
        p.tint = partTint(c, slot, name, *a, lib);
        p.lo = glm::vec3(1e9f); p.hi = glm::vec3(-1e9f);
        for (int i = 0; i < 8; ++i) {
            const glm::vec3 corner((i & 1) ? a->boundsMax.x : a->boundsMin.x, (i & 2) ? a->boundsMax.y : a->boundsMin.y, (i & 4) ? a->boundsMax.z : a->boundsMin.z);
            const glm::vec3 w = glm::vec3(m * glm::vec4(corner, 1.0f));
            p.lo = glm::min(p.lo, w); p.hi = glm::max(p.hi, w);
        }
        p.boneFrom = glm::vec3(bind[size_t(b)][3]);
        glm::vec3 along = glm::normalize(glm::mat3(bind[size_t(b)]) * glm::vec3(0.0f, -1.0f, 0.0f));   // no child: down the bone's own way
        for (int k = 0; k < kBoneCount; ++k)
            if (boneParent(Bone(k)) == b && glm::length(sk.bone(Bone(k)).offset) > 1e-5f && !(Bone(b) == Bone::Chest && Bone(k) != Bone::Neck)) {
                along = glm::normalize(glm::mat3(bind[size_t(b)]) * sk.bone(Bone(k)).offset);
                break;
            }
        p.boneTo = p.boneFrom + along * sk.bone(Bone(b)).length;
        parts.push_back(std::move(p));
    }
    if (parts.empty()) return nullptr;
    auto segDist = [](const glm::vec3& p, const glm::vec3& a, const glm::vec3& b) {
        const glm::vec3 ab = b - a;
        const float t = std::clamp(glm::dot(p - a, ab) / std::max(glm::dot(ab, ab), 1e-8f), 0.0f, 1.0f);
        return glm::length(p - (a + ab * t));
    };

    // ---- the fields: one grid round the whole body at `voxel`, and finer grids round the hands and feet (fingers and
    // shoe soles need it). Each sample: the parts' surface (a smooth union), which part owns the point (for weights) and
    // whose surface it is (for material and colour). Where a fine grid covers the body, the coarse surface tucks just
    // inside the fine one and then stops, so the fine surface is what you see and the two never show a crack.
    struct Region { glm::vec3 lo, hi; };
    struct Field {
        Asset grid;
        std::vector<std::uint8_t> owner, colourOwner;
        glm::vec3 lo{ 0.0f };
        float vs = 0.0f;
        int region = -1;                  // -1: the coarse body grid; else the detail region this grid covers
    };
    const float vs = std::max(voxel, 0.003f);
    std::vector<Region> regions;
    std::vector<float> regionVoxel;
    for (const PartInfo& p : parts) {
        const bool hand = p.bone == Bone::HandL || p.bone == Bone::HandR, foot = p.bone == Bone::FootL || p.bone == Bone::FootR;
        if (!hand && !foot) continue;
        const float rv = hand ? 0.0035f : 0.005f;
        regions.push_back({ p.lo - glm::vec3(2.0f * rv), p.hi + glm::vec3(2.0f * rv) });
        regionVoxel.push_back(rv);
    }
    const float kBlend = 0.014f * sk.scale;
    const float coreMargin = 1.5f * vs, tuck = 0.0015f;
    auto depthIn = [](const Region& r, const glm::vec3& p) {          // > 0 inside the box: how far from its nearest face
        const glm::vec3 a = p - r.lo, b = r.hi - p;
        return std::min(std::min(std::min(a.x, b.x), std::min(a.y, b.y)), std::min(a.z, b.z));
    };

    auto sampleField = [&](Field& f, const glm::vec3& lo, const glm::vec3& hi, float fvs, int region) {
        f.lo = lo; f.vs = fvs; f.region = region;
        f.grid.name = "skinned body";
        f.grid.voxelSize = fvs;
        f.grid.size = glm::ivec3(glm::ceil((hi - lo) / fvs)) + glm::ivec3(1);
        f.grid.pivot = -lo / fvs;
        const size_t n = size_t(f.grid.size.x) * f.grid.size.y * f.grid.size.z;
        f.grid.grid.assign(n, DENSITY_CLAMP);
        f.grid.materials.assign(n, MaterialId(MAT_SKIN));
        f.owner.assign(n, 255); f.colourOwner.assign(n, 255);
        const float reach = 3.0f * fvs + kBlend;
        auto slab = [&](int z0, int z1) {
            for (int z = z0; z < z1; ++z)
                for (int y = 0; y < f.grid.size.y; ++y)
                    for (int x = 0; x < f.grid.size.x; ++x) {
                        const glm::vec3 p = lo + glm::vec3(float(x), float(y), float(z)) * fvs;
                        const size_t idx = size_t(f.grid.index(x, y, z));
                        // the coarse grid gives way inside the detail regions
                        float inset = 0.0f, cut = -1e9f;
                        if (region < 0)
                            for (const Region& r : regions) {
                                const float d = depthIn(r, p);
                                if (d <= 0.0f) continue;
                                inset = std::max(inset, tuck * smooth(0.0f, 0.5f * vs, d));
                                cut = std::max(cut, d - coreMargin);
                            }
                        if (cut > 2.0f * fvs) continue;                       // deep inside a detail region: air, untouched
                        float best = DENSITY_CLAMP * fvs;
                        float dist[32];
                        glm::vec3 locals[32];
                        const size_t np = std::min(parts.size(), size_t(32));
                        for (size_t i = 0; i < np; ++i) {
                            const PartInfo& q = parts[i];
                            dist[i] = 1e9f;
                            if (p.x < q.lo.x - reach || p.y < q.lo.y - reach || p.z < q.lo.z - reach || p.x > q.hi.x + reach || p.y > q.hi.y + reach || p.z > q.hi.z + reach) continue;
                            locals[i] = glm::vec3(q.toLocal * glm::vec4(p, 1.0f));
                            dist[i] = q.asset->density(locals[i]) * q.scale;
                        }
                        // the surface: the parts joined with a smooth union, so where a thick thigh meets a slimmer shin (or a
                        // sleeve meets a forearm) the surface flows from one to the other instead of stepping
                        float surface = DENSITY_CLAMP * fvs;
                        for (size_t i = 0; i < np; ++i) {
                            if (dist[i] > 1e8f) continue;
                            best = std::min(best, dist[i]);
                            const float h = std::clamp(0.5f + 0.5f * (dist[i] - surface) / kBlend, 0.0f, 1.0f);
                            surface = glm::mix(dist[i], surface, h) - kBlend * h * (1.0f - h);
                        }
                        // the owner: of the parts this point is in (or right at the surface of), the one whose bone is
                        // nearest, so where a sleeve overlaps a shoulder the choice does not flicker from voxel to voxel
                        int who = -1;
                        float nearestBone = 1e9f;
                        for (size_t i = 0; i < np; ++i) {
                            if (dist[i] > std::max(best + 1.5f * fvs, 0.0f) + 1.5f * fvs) continue;
                            const float bd = segDist(p, parts[i].boneFrom, parts[i].boneTo);
                            if (bd < nearestBone) { nearestBone = bd; who = int(i); }
                        }
                        int surfaceWho = -1;
                        for (size_t i = 0; i < np; ++i) if (dist[i] <= best && dist[i] < 1e8f) { surfaceWho = int(i); break; }
                        float d = std::min(surface, best);
                        if (region < 0) d = std::max(d + inset, cut);
                        else d -= 0.0008f;                                    // a hair proud of the coarse surface it overlaps
                        f.grid.grid[idx] = std::clamp(d / fvs, -DENSITY_CLAMP, DENSITY_CLAMP);
                        if (who >= 0) f.owner[idx] = std::uint8_t(who);
                        if (surfaceWho >= 0) {
                            f.colourOwner[idx] = std::uint8_t(surfaceWho);
                            if (best < 2.0f * fvs) f.grid.materials[idx] = solidMaterial(*parts[size_t(surfaceWho)].asset, locals[size_t(surfaceWho)]);
                        }
                    }
        };
        const int threads = std::clamp(int(std::thread::hardware_concurrency()), 1, 8);
        std::vector<std::thread> pool;
        for (int t = 0; t < threads; ++t) pool.emplace_back(slab, f.grid.size.z * t / threads, f.grid.size.z * (t + 1) / threads);
        for (std::thread& th : pool) th.join();
    };

    std::vector<Field> fields(1 + regions.size());
    {
        glm::vec3 lo(1e9f), hi(-1e9f);
        for (const PartInfo& p : parts) { lo = glm::min(lo, p.lo); hi = glm::max(hi, p.hi); }
        sampleField(fields[0], lo - glm::vec3(3.0f * vs), hi + glm::vec3(3.0f * vs), vs, -1);
    }
    for (size_t r = 0; r < regions.size(); ++r) sampleField(fields[r + 1], regions[r].lo, regions[r].hi, regionVoxel[r], int(r));
    std::vector<std::vector<Vertex>> fieldTris(fields.size());
    size_t triCount = 0;
    for (size_t f = 0; f < fields.size(); ++f) {
        fields[f].grid.meshCells(glm::ivec3(-1), fields[f].grid.size - glm::ivec3(1), fieldTris[f]);
        triCount += fieldTris[f].size();
    }
    if (triCount == 0) return nullptr;

    // ---- the joints: where two bones meet, which way the lower one runs
    struct Joint { int parent, child; glm::vec3 at, axis; float reach, side; };
    std::vector<Joint> joints;
    auto childDir = [&](Bone b) {
        for (int k = 0; k < kBoneCount; ++k)
            if (boneParent(Bone(k)) == int(b) && glm::length(sk.bone(Bone(k)).offset) > 1e-5f) {
                if (b == Bone::Chest && Bone(k) != Bone::Neck) continue;                  // the chest runs up to the neck
                return glm::normalize(glm::mat3(bind[size_t(b)]) * sk.bone(Bone(k)).offset);
            }
        return glm::vec3(0.0f);
    };
    for (int k = 0; k < kBoneCount; ++k) {
        const int par = boneParent(Bone(k));
        if (par < 0) continue;
        glm::vec3 axis = childDir(Bone(k));
        if (glm::length(axis) < 0.5f) axis = Bone(k) == Bone::Head ? glm::vec3(0, 1, 0) : childDir(Bone(par));   // hands and feet carry on the limb
        if (glm::length(axis) < 0.5f) axis = glm::vec3(0, -1, 0);
        const JointZone z = zoneFor(Bone(k));
        joints.push_back({ par, k, glm::vec3(bind[size_t(k)][3]), axis, z.reach * sk.scale, z.side * sk.scale });
    }

    auto mesh = std::make_shared<SkinnedMesh>();
    for (int b = 0; b < kMaxSkinBones; ++b) mesh->inverseBind[size_t(b)] = b < kBoneCount ? glm::inverse(bind[size_t(b)]) : glm::mat4(1.0f);
    mesh->vertices.reserve(triCount / 4);
    mesh->indices.reserve(triCount);
    // Corners shared by triangles are stored once. A triangle all of one material does not need its corner weights
    // (bary), so those are made the same and the corner can be shared too.
    struct Key {
        float x, y, z; std::uint32_t lb;
        bool operator==(const Key& o) const { return x == o.x && y == o.y && z == o.z && lb == o.lb; }
    };
    struct KeyHash { size_t operator()(const Key& k) const {
        std::uint32_t h[4]; std::memcpy(&h[0], &k.x, 4); std::memcpy(&h[1], &k.y, 4); std::memcpy(&h[2], &k.z, 4); h[3] = k.lb;
        size_t r = 1469598103934665603ull; for (std::uint32_t v : h) { r ^= v; r *= 1099511628211ull; } return r; } };
    std::unordered_map<Key, std::uint32_t, KeyHash> seen;
    seen.reserve(triCount / 3);
    auto ownerAt = [&](const Field& f, const std::vector<std::uint8_t>& grid, const glm::vec3& p) -> int {
        const glm::ivec3 g = glm::ivec3(glm::round((p - f.lo) / f.vs));
        for (int r = 0; r <= 2; ++r)
            for (int dz = -r; dz <= r; ++dz) for (int dy = -r; dy <= r; ++dy) for (int dx = -r; dx <= r; ++dx) {
                const glm::ivec3 q = glm::clamp(g + glm::ivec3(dx, dy, dz), glm::ivec3(0), f.grid.size - glm::ivec3(1));
                const std::uint8_t o = grid[size_t(f.grid.index(q.x, q.y, q.z))];
                if (o != 255) return o;
            }
        return 0;
    };
    for (size_t fi = 0; fi < fields.size(); ++fi)
    for (size_t ti = 0; ti < fieldTris[fi].size(); ++ti) {
        const Field& field = fields[fi];
        Vertex v = fieldTris[fi][ti];
        if (v.layers[0] == v.layers[1] && v.layers[0] == v.layers[2]) { v.bary[0] = 255; v.bary[1] = 0; v.bary[2] = 0; }
        const Key key{ v.position.x, v.position.y, v.position.z,
                       std::uint32_t(v.layers[0]) | std::uint32_t(v.layers[1]) << 8 | std::uint32_t(v.layers[2]) << 16 | std::uint32_t(v.bary[0] / 85 + (v.bary[1] / 85) * 4) << 24 };
        if (auto f = seen.find(key); f != seen.end()) { mesh->indices.push_back(f->second); continue; }
        const int who = ownerAt(field, field.owner, v.position - v.normal * (0.75f * field.vs));
        const int colourWho = ownerAt(field, field.colourOwner, v.position - v.normal * (0.75f * field.vs));
        const int own = int(parts[size_t(who)].bone);
        float w[kMaxSkinBones] = {};
        w[own] = 1.0f;
        for (const Joint& j : joints) {
            if (own != j.parent && own != j.child) continue;
            const glm::vec3 d = v.position - j.at;
            const float s = glm::dot(d, j.axis);
            const float lat = glm::length(d - j.axis * s);
            const float g = 1.0f - smooth(j.side, j.side * 1.6f, lat);
            const float t = smooth(-j.reach, j.reach, s);                        // the lower bone's share, across the joint
            const float share = own == j.child ? (1.0f - t) * g : t * g;
            const int other = own == j.child ? j.parent : j.child;
            const float move = share * w[own];
            w[own] -= move;
            w[other] += move;
        }
        // the four biggest, in bytes adding up to 255
        int idx[4] = { own, own, own, own };
        float val[4] = { 0, 0, 0, 0 };
        for (int b = 0; b < kMaxSkinBones; ++b) {
            if (w[b] <= val[3]) continue;
            int k = 3;
            while (k > 0 && w[b] > val[k - 1]) { val[k] = val[k - 1]; idx[k] = idx[k - 1]; --k; }
            val[k] = w[b]; idx[k] = b;
        }
        const float sum = std::max(val[0] + val[1] + val[2] + val[3], 1e-6f);
        SkinVertex sv;
        sv.v = v;
        int given = 0;
        for (int k = 0; k < 4; ++k) {
            sv.bones[k] = std::uint8_t(idx[k]);
            sv.weights[k] = std::uint8_t(std::lround(val[k] / sum * 255.0f));
            given += sv.weights[k];
        }
        sv.weights[0] = std::uint8_t(std::clamp(int(sv.weights[0]) + 255 - given, 0, 255));
        const glm::vec3 tint = glm::clamp(parts[size_t(colourWho)].tint, glm::vec3(0.0f), glm::vec3(1.0f));
        sv.tint[0] = std::uint8_t(std::lround(tint.x * 255.0f)); sv.tint[1] = std::uint8_t(std::lround(tint.y * 255.0f));
        sv.tint[2] = std::uint8_t(std::lround(tint.z * 255.0f)); sv.tint[3] = 255;
        seen.emplace(key, std::uint32_t(mesh->vertices.size()));
        mesh->indices.push_back(std::uint32_t(mesh->vertices.size()));
        mesh->vertices.push_back(sv);
    }
    return mesh;
}

std::shared_ptr<const SkinnedMesh> skinnedBodyFor(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib) {
    const std::string key = keyFor(c, sk, lib);
    auto& m = cache();
    if (auto it = m.find(key); it != m.end()) return it->second;
    // A body takes a tenth of a second or so to build: a crowd arriving at once is spread over several frames (two
    // builds per tenth of a second); until theirs is ready, people are drawn part by part as before.
    using Clock = std::chrono::steady_clock;
    static Clock::time_point windowStart = Clock::now();
    static int builtInWindow = 0;
    if (Clock::now() - windowStart > std::chrono::milliseconds(100)) { windowStart = Clock::now(); builtInWindow = 0; }
    if (builtInWindow >= 2) return nullptr;
    ++builtInWindow;
    if (m.size() >= 96) m.clear();                                  // a crowd of strangers: start again rather than grow forever
    auto body = buildSkinnedBody(c, sk, lib);
    m[key] = body;                                                   // (a body that could not be built is remembered too)
    return body;
}

size_t skinnedBodyCacheSize() { return cache().size(); }
void clearSkinnedBodyCache() { cache().clear(); }

} // namespace px
