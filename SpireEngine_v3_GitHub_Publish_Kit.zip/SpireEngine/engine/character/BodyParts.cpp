#include "character/BodyParts.h"
#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <functional>
#include <glm/gtc/matrix_transform.hpp>
#include "workshop/Workshop.h"
#include "character/PartBuilder.h"
#include "character/Wardrobe.h"
#include "character/SkinnedBody.h"
#include "character/HumanBody.h"

namespace px {

namespace {
using namespace partbuild;

constexpr MaterialId kCloth = MAT_CLOTH;

AssetPtr makeHips() {
    PartBuilder b("body hips", { 0.42f, 0.26f, 0.30f }, 0.008f);
    b.ball({ 0.0f, 0.11f, 0.0f }, { 0.158f, 0.092f, 0.104f }, kCloth);                      // pelvis
    for (float sx : { -1.0f, 1.0f }) b.ball({ sx * 0.062f, 0.085f, -0.048f }, { 0.074f, 0.08f, 0.064f }, kCloth, 0.03f);   // seat
    // a belt: an elliptical band hugging the waist (it follows the body's curve rather than sticking out like a tray)
    b.add([](const glm::vec3& p) {
              const glm::vec3 q = p - glm::vec3(0.0f, 0.172f, 0.0f);
              const float r = glm::length(glm::vec2(q.x / 0.134f, q.z / 0.09f));
              return std::max((r - 1.0f) * 0.09f - 0.001f, std::fabs(q.y) - 0.012f);
          }, { -0.18f, 0.15f, -0.12f }, { 0.18f, 0.2f, 0.12f }, MAT_PAINT_BLACK, 0.003f);   // (black: leather would take the trousers' colour)
    b.box({ 0.0f, 0.172f, 0.091f }, { 0.016f, 0.012f, 0.004f }, 0.003f, MAT_STEEL);          // its buckle
    b.add([](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, 0.1f, 0.1f), glm::vec3(0.006f, 0.055f, 0.005f), 0.004f); },   // fly seam
          { -0.02f, 0.03f, 0.08f }, { 0.02f, 0.16f, 0.12f }, kCloth, 0.004f);
    return b.finish(PartSlot::Hips, { 0.0f, 0.075f, 0.0f });
}

AssetPtr makeTorso() {
    PartBuilder b("body torso", { 0.52f, 0.50f, 0.30f }, 0.007f);
    sculptTorso(b, kCloth);
    shirtDetails(b, kCloth);
    return b.finish(PartSlot::Torso, { 0.0f, 0.0f, 0.0f });
}

AssetPtr makeNeck() {
    PartBuilder b("body neck", { 0.16f, 0.16f, 0.16f }, 0.006f);
    b.limb({ 0.0f, 0.0f, -0.006f }, { 0.0f, 0.11f, 0.0f }, 0.062f, 0.05f, kSkinMat);
    for (float sx : { -1.0f, 1.0f })                                                           // the two long muscles from behind the ears
        b.limb({ sx * 0.035f, 0.11f, -0.012f }, { sx * 0.012f, 0.005f, 0.036f }, 0.014f, 0.012f, kSkinMat, 0.014f);
    b.ball({ 0.0f, 0.06f, 0.038f }, { 0.012f, 0.014f, 0.01f }, kSkinMat, 0.01f);              // the throat
    return b.finish(PartSlot::Neck, { 0.0f, 0.0f, 0.0f });
}

AssetPtr makeHead() {
    PartBuilder b("body head", { 0.28f, 0.30f, 0.30f }, 0.004f);
    sculptHead(b, FaceStyle{}, false);
    return b.finish(PartSlot::Head, { 0.0f, 0.0f, 0.0f });
}

// Hair sits on the head's joint (the top of the neck). It is built 0.12 m up so long hair can hang below that point.
AssetPtr makeHair(HairStyle style) {
    const float up = 0.12f;
    PartBuilder b(builtinPartName(PartSlot::Hair, style), { 0.32f, 0.46f, 0.34f }, 0.006f);
    auto at = [&](float x, float y, float z) { return glm::vec3(x, y + up, z); };
    if (style == HairStyle::Spiky) {
        hairShell(b, up, 0.0f);
        const float spikes[][3] = { { 0.0f, 0.26f, 0.02f }, { 0.05f, 0.25f, -0.02f }, { -0.05f, 0.25f, -0.02f }, { 0.0f, 0.24f, -0.07f },
                                    { 0.07f, 0.22f, 0.04f }, { -0.07f, 0.22f, 0.04f }, { 0.03f, 0.23f, 0.07f }, { -0.03f, 0.23f, 0.07f },
                                    { 0.06f, 0.245f, -0.05f }, { -0.06f, 0.245f, -0.05f }, { 0.0f, 0.255f, 0.06f } };
        for (const auto& sp : spikes) {                                                         // tufts, not cones: a few strands each
            const glm::vec3 base = at(sp[0] * 0.6f, 0.17f, sp[2] * 0.6f), tip = at(sp[0] * 1.05f, sp[1] + 0.02f, sp[2] * 1.05f + 0.01f);
            for (int k = 0; k < 3; ++k) {
                const glm::vec3 o(0.008f * float(k - 1), 0.0f, 0.006f * float((k * 7) % 3 - 1));
                b.limb(base + o, tip + o * 1.6f, 0.02f, 0.003f, kHairMat, 0.012f);
            }
        }
    } else {
        hairShell(b, up, 0.0f);
    }
    hairline(b, up);
    if (style == HairStyle::Long)                                                               // down the back to the shoulders, in locks
        b.add([&](const glm::vec3& p) {
                  const glm::vec3 q = p - at(0.0f, 0.03f, -0.075f);
                  const float locks = 0.004f * std::sin(std::atan2(q.x, -q.z - 0.1f) * 36.0f + q.y * 20.0f);
                  return roundedBox(q, glm::vec3(0.1f - 0.01f * std::clamp(-q.y / 0.11f, 0.0f, 1.0f), 0.115f, 0.04f), 0.035f) + locks;
              }, at(-0.13f, -0.1f, -0.13f), at(0.13f, 0.16f, -0.02f), kHairMat, 0.03f);
    if (style == HairStyle::Bun) {
        b.add([&](const glm::vec3& p) {
                  const glm::vec3 q = p - at(0.0f, 0.22f, -0.09f);
                  return ellipsoid(q, glm::vec3(0.048f, 0.046f, 0.046f)) + 0.003f * std::sin(std::atan2(q.y, q.x) * 3.0f + glm::length(q) * 200.0f);   // coiled
              }, at(-0.06f, 0.16f, -0.15f), at(0.06f, 0.28f, -0.03f), kHairMat, 0.02f);
    }
    return b.finish(PartSlot::Hair, at(0.0f, 0.0f, 0.0f));
}

AssetPtr makeUpperArm() {
    PartBuilder b("body upper arm", { 0.18f, 0.34f, 0.18f }, 0.007f);
    sculptUpperArm(b, kCloth, true);
    return b.finish(PartSlot::UpperArm, { 0.0f, 0.29f, 0.0f });
}

AssetPtr makeLowerArm() {
    PartBuilder b("body lower arm", { 0.14f, 0.30f, 0.14f }, 0.006f);
    sculptForearm(b, kSkinMat);
    return b.finish(PartSlot::LowerArm, { 0.0f, 0.26f, 0.0f });
}

AssetPtr makeHand() {
    PartBuilder b("body hand", { 0.10f, 0.22f, 0.16f }, 0.0035f);
    sculptHand(b, kSkinMat);
    return b.finish(PartSlot::Hand, { 0.0f, 0.175f, 0.0f });
}

AssetPtr makeUpperLeg() {
    PartBuilder b("body upper leg", { 0.22f, 0.50f, 0.22f }, 0.008f);
    sculptThigh(b, kCloth);
    return b.finish(PartSlot::UpperLeg, { 0.0f, 0.44f, 0.0f });
}

AssetPtr makeLowerLeg() {
    PartBuilder b("body lower leg", { 0.18f, 0.48f, 0.20f }, 0.008f);
    sculptShin(b, kCloth, true);
    return b.finish(PartSlot::LowerLeg, { 0.0f, 0.42f, 0.0f });
}

AssetPtr makeFoot() {
    PartBuilder b("body foot", { 0.16f, 0.16f, 0.34f }, 0.005f);
    sculptShoe(b, kShoeMat, 0.0f);
    return b.finish(PartSlot::Foot, { 0.0f, 0.085f, 0.0f });
}

AssetPtr makeStandIn() {
    Workshop w;
    NewAssetSpec spec;
    spec.name = kCharacterStandIn;
    spec.voxelSize = 0.05f;
    spec.sizeMetres = { 0.8f, 2.0f, 0.6f };
    w.create(spec);
    w.stampSdf([](const glm::vec3& p) { return capsule(p, glm::vec3(0.0f, 0.3f, 0.0f), glm::vec3(0.0f, 1.5f, 0.0f), 0.28f, 0.28f); },
               glm::vec3(-0.35f, 0.0f, -0.35f), glm::vec3(0.35f, 1.85f, 0.35f), StampMode::Add, MAT_STONE, 0.0f);
    w.remesh();
    auto a = std::make_shared<Asset>(w.asset);
    a->type = AssetType::CharacterPart;
    a->tags = { "character" };
    a->userMade = false;
    return a;
}

} // namespace

std::string builtinPartName(PartSlot s, HairStyle hair) {
    switch (s) {
    case PartSlot::Hips: return "body hips";
    case PartSlot::Torso: return "body torso";
    case PartSlot::Neck: return "body neck";
    case PartSlot::Head: return "body head";
    case PartSlot::Hair: return hair == HairStyle::None ? std::string() : std::string("hair ") + hairStyleName(hair);
    case PartSlot::UpperArm: return "body upper arm";
    case PartSlot::LowerArm: return "body lower arm";
    case PartSlot::Hand: return "body hand";
    case PartSlot::UpperLeg: return "body upper leg";
    case PartSlot::LowerLeg: return "body lower leg";
    case PartSlot::Foot: return "body foot";
    case PartSlot::Hat: case PartSlot::Glasses: case PartSlot::Beard: case PartSlot::Back:   // accessories: none unless chosen
    case PartSlot::Count: break;
    }
    return {};
}

std::string partAssetFor(const CharacterDef& c, PartSlot s) {
    const std::string& own = c.parts[size_t(s)];
    if (!own.empty()) return own;
    if (s == PartSlot::Head) return faceHeadName(c.face);       // the built-in head wears the character's face
    return builtinPartName(s, c.hair);
}

void registerBodyParts(AssetLibrary& lib) {
    auto reg = [&](const std::string& name, PartSlot slot, std::function<AssetPtr()> make) {
        lib.addGenerated(name, { std::string("part:") + partSlotName(slot), "builtin body" }, std::move(make));
    };
    reg("body hips", PartSlot::Hips, makeHips);
    reg("body torso", PartSlot::Torso, makeTorso);
    reg("body neck", PartSlot::Neck, makeNeck);
    reg("body head", PartSlot::Head, makeHead);
    for (int h = 1; h < int(HairStyle::Ponytail); ++h) {          // the rest are in the wardrobe
        const HairStyle style = HairStyle(h);
        reg(builtinPartName(PartSlot::Hair, style), PartSlot::Hair, [style] { return makeHair(style); });
    }
    reg("body upper arm", PartSlot::UpperArm, makeUpperArm);
    reg("body lower arm", PartSlot::LowerArm, makeLowerArm);
    reg("body hand", PartSlot::Hand, makeHand);
    reg("body upper leg", PartSlot::UpperLeg, makeUpperLeg);
    reg("body lower leg", PartSlot::LowerLeg, makeLowerLeg);
    reg("body foot", PartSlot::Foot, makeFoot);
    lib.addGenerated(kCharacterStandIn, { "character" }, makeStandIn);
    registerWardrobe(lib);
}

std::vector<std::string> partsForSlot(const AssetLibrary& lib, PartSlot s) {
    const std::string tag = std::string("part:") + partSlotName(s);
    std::vector<std::string> builtin, mine;
    for (const std::string& n : lib.names()) {
        std::vector<std::string> tags;
        if (!lib.tagsOf(n, tags) || std::find(tags.begin(), tags.end(), tag) == tags.end()) continue;
        (lib.isGenerated(n) ? builtin : mine).push_back(n);
    }
    builtin.insert(builtin.end(), mine.begin(), mine.end());
    return builtin;
}

glm::vec3 partJoint(const Asset& a, PartSlot s) {
    for (const Socket& k : a.sockets) if (k.name == "joint") return k.position;
    // No joint socket: limbs hang from their top middle; the rest stand on their bottom middle.
    const bool hangs = s == PartSlot::UpperArm || s == PartSlot::LowerArm || s == PartSlot::Hand || s == PartSlot::UpperLeg || s == PartSlot::LowerLeg;
    const glm::vec3 c = a.center();
    return glm::vec3(c.x, hangs ? a.boundsMax.y : a.boundsMin.y, c.z);
}

glm::vec3 partTint(const CharacterDef& c, PartSlot slot, const std::string& name, const Asset& a, const AssetLibrary& lib) {
    if (lib.isGenerated(name)) {
        ColourRole role = colourRoleFor(slot);
        for (const std::string& t : a.tags)
            if (t.rfind("tint:", 0) == 0) colourRoleFromKey(t.substr(5), role);
        return c.colourOf(slot, role);
    }
    return c.partColour[size_t(slot)].w > 0.5f ? glm::vec3(c.partColour[size_t(slot)]) : glm::vec3(1.0f);
}

namespace {
void itemDraw(const AnimOutput& pose, const AssetPtr& item, const glm::vec4& highlight, std::vector<ObjectDraw>& out);

// 1.5: a realistic body, with what is worn as parts (shoes, skirts, hair, hats, glasses, beards, backpacks) on it.
bool humanDraws(const CharacterDef& c, const Skeleton& sk, const AnimOutput& pose, AssetLibrary& lib, std::vector<ObjectDraw>& out,
                const glm::vec4& highlight, const AssetPtr& item) {
    ensureHumanRenderData();
    std::shared_ptr<const HumanBody> hb = humanBodyFor(c, sk, lib);
    if (!hb || !hb->mesh) return false;
    const glm::vec4 hair(c.colourOf(PartSlot::Hair, ColourRole::Hair), 1.0f);
    {
        auto bones = std::make_shared<SkinBones>();
        for (int b = 0; b < kMaxSkinBones; ++b) (*bones)[size_t(b)] = b < kBoneCount ? pose.world[size_t(b)] * hb->mesh->inverseBind[size_t(b)] : glm::mat4(1.0f);
        ObjectDraw d;
        d.skin = hb->mesh;
        d.bones = std::move(bones);
        d.scale = 6.0f;
        d.highlight = highlight;
        d.hairTint = hair;
        d.expr = expressionsFor(c, pose);
        d.eyeColour = c.look.eyes;
        d.sway = pose.sway;
        if (hb->hair) {                                                    // the hair cards: the same bones, drawn see-through
            ObjectDraw h = d;
            h.skin = hb->hair;
            h.cards = true;
            h.expr = {};
            out.push_back(std::move(d));
            out.push_back(std::move(h));
        } else {
            out.push_back(std::move(d));
        }
    }
    auto part = [&](PartSlot slot, Bone bone, const std::string& name, const glm::mat4& fit, const glm::vec3* tintOverride = nullptr) {
        if (name.empty()) return;
        AssetPtr a = lib.get(name);
        if (!a || a->mesh.empty()) return;
        const bool onHead = slot == PartSlot::Hair || slot == PartSlot::Hat || slot == PartSlot::Glasses || slot == PartSlot::Beard;
        const glm::vec3 ps = onHead ? sk.bone(Bone::Head).partScale : sk.bone(bone).partScale;
        ObjectDraw d;
        d.asset = a;
        d.model = pose.world[size_t(bone)] * fit * glm::scale(glm::mat4(1.0f), ps) * glm::translate(glm::mat4(1.0f), -partJoint(*a, slot));
        d.scale = (ps.x + ps.y + ps.z) / 3.0f * 6.0f;
        d.highlight = highlight;
        d.hairTint = hair;
        d.tint = tintOverride ? *tintOverride : partTint(c, slot, name, *a, lib);
        out.push_back(std::move(d));
    };
    // what stays a part of its own (shoes and boots; skirts and robes)
    for (PartSlot slot : hb->rigidSlots)
        for (int b = 0; b < kBoneCount; ++b)
            if (slotForBone(Bone(b)) == slot) part(slot, Bone(b), partAssetFor(c, slot), glm::mat4(1.0f));
    // on the head: hair (tucked under a hat that covers it), hat, glasses, beard
    std::string hairName = partAssetFor(c, PartSlot::Hair);
    if (c.parts[size_t(PartSlot::Hair)].empty() && (c.hair == HairStyle::Spiky || c.hair == HairStyle::Mohawk || c.hair == HairStyle::Curly || c.hair == HairStyle::Bun)) {
        const std::string hat = partAssetFor(c, PartSlot::Hat);
        if (AssetPtr h = hat.empty() ? nullptr : lib.get(hat); h && std::find(h->tags.begin(), h->tags.end(), "covers:hair") != h->tags.end())
            hairName = builtinPartName(PartSlot::Hair, HairStyle::Short);
    }
    const glm::vec3 hairCol = c.colourOf(PartSlot::Hair, ColourRole::Hair);
    if (!hb->hairAsCards) part(PartSlot::Hair, Bone::Head, hairName, hb->headFit, c.parts[size_t(PartSlot::Hair)].empty() ? &hairCol : nullptr);
    part(PartSlot::Hat, Bone::Head, partAssetFor(c, PartSlot::Hat), hb->hatFit);
    part(PartSlot::Glasses, Bone::Head, partAssetFor(c, PartSlot::Glasses), hb->faceFit);
    if (!hb->beardAsCards) part(PartSlot::Beard, Bone::Head, partAssetFor(c, PartSlot::Beard), hb->faceFit);
    part(PartSlot::Back, boneForAccessory(PartSlot::Back), partAssetFor(c, PartSlot::Back), glm::mat4(1.0f));
    itemDraw(pose, item, highlight, out);
    return true;
}
} // namespace

void characterDraws(const CharacterDef& c, const Skeleton& sk, const AnimOutput& pose, AssetLibrary& lib, std::vector<ObjectDraw>& out,
                    const glm::vec4& highlight, const AssetPtr& item, bool rigidOnly) {
    if (!rigidOnly && characterSkinning() && usesHumanBody(c) && humanDraws(c, sk, pose, lib, out, highlight, item)) return;
    // The trunk and limbs as one skinned body, when it can be built.
    std::shared_ptr<const SkinnedMesh> body = (!rigidOnly && characterSkinning()) ? skinnedBodyFor(c, sk, lib) : nullptr;
    if (body) {
        auto bones = std::make_shared<SkinBones>();
        for (int b = 0; b < kMaxSkinBones; ++b) (*bones)[size_t(b)] = b < kBoneCount ? pose.world[size_t(b)] * body->inverseBind[size_t(b)] : glm::mat4(1.0f);
        ObjectDraw d;
        d.skin = body;
        d.bones = std::move(bones);
        d.model = glm::mat4(1.0f);
        d.scale = 6.0f;                                       // the same fine texture scale as the parts (bind space is metres)
        d.highlight = highlight;
        d.hairTint = glm::vec4(c.colourOf(PartSlot::Hair, ColourRole::Hair), 1.0f);
        out.push_back(std::move(d));
    }
    auto drawPart = [&](PartSlot slot, Bone bone) {
        std::string name = partAssetFor(c, slot);
        if (slot == PartSlot::Head && c.parts[size_t(PartSlot::Head)].empty()) {
            // the face of the moment: blinking, or a mood's mouth and brows over the character's own
            FaceStyle f = c.face;
            if (pose.mouth >= 0) f.mouth = std::uint8_t(pose.mouth);
            if (pose.brows >= 0) f.brows = std::uint8_t(pose.brows);
            name = faceHeadName(f, pose.blink);
        }
        if (name.empty()) return;
        AssetPtr a = lib.get(name);
        if (!a || a->mesh.empty()) return;
        const bool onHead = slot == PartSlot::Hair || slot == PartSlot::Hat || slot == PartSlot::Glasses || slot == PartSlot::Beard;
        const glm::vec3 ps = onHead ? sk.bone(Bone::Head).partScale : sk.bone(bone).partScale;
        ObjectDraw d;
        d.asset = a;
        d.model = pose.world[size_t(bone)] * glm::scale(glm::mat4(1.0f), ps) * glm::translate(glm::mat4(1.0f), -partJoint(*a, slot));
        d.scale = (ps.x + ps.y + ps.z) / 3.0f * 6.0f;         // textures six times finer than on buildings: a weave, not bricks
        d.highlight = highlight;
        d.hairTint = glm::vec4(c.colourOf(PartSlot::Hair, ColourRole::Hair), 1.0f);
        d.tint = partTint(c, slot, name, *a, lib);
        out.push_back(std::move(d));
    };
    for (int b = 0; b < kBoneCount; ++b)
        if (!body || !boneIsSkinned(Bone(b))) drawPart(slotForBone(Bone(b)), Bone(b));
    // Under most hats, big hair (spikes, a mohawk, curls, a bun) is tucked in: it would poke through.
    bool tuck = false;
    if (c.parts[size_t(PartSlot::Hair)].empty() && (c.hair == HairStyle::Spiky || c.hair == HairStyle::Mohawk || c.hair == HairStyle::Curly || c.hair == HairStyle::Bun)) {
        const std::string hat = partAssetFor(c, PartSlot::Hat);
        if (AssetPtr h = hat.empty() ? nullptr : lib.get(hat)) tuck = std::find(h->tags.begin(), h->tags.end(), "covers:hair") != h->tags.end();
    }
    if (tuck) {
        CharacterDef tucked = c;
        tucked.hair = HairStyle::Short;
        const std::string name = builtinPartName(PartSlot::Hair, HairStyle::Short);
        if (AssetPtr a = lib.get(name); a && !a->mesh.empty()) {
            const glm::vec3 ps = sk.bone(Bone::Head).partScale;
            ObjectDraw d;
            d.asset = a;
            d.model = pose.world[size_t(Bone::Head)] * glm::scale(glm::mat4(1.0f), ps) * glm::translate(glm::mat4(1.0f), -partJoint(*a, PartSlot::Hair));
            d.scale = (ps.x + ps.y + ps.z) / 3.0f * 6.0f;
            d.highlight = highlight;
            d.tint = c.colourOf(PartSlot::Hair, ColourRole::Hair);
            d.hairTint = glm::vec4(d.tint, 1.0f);
            out.push_back(std::move(d));
        }
    } else {
        drawPart(PartSlot::Hair, Bone::Head);
    }
    for (PartSlot s : { PartSlot::Hat, PartSlot::Glasses, PartSlot::Beard, PartSlot::Back }) drawPart(s, boneForAccessory(s));
    itemDraw(pose, item, highlight, out);
}

namespace {
void itemDraw(const AnimOutput& pose, const AssetPtr& item, const glm::vec4& highlight, std::vector<ObjectDraw>& out) {
    if (item && !item->mesh.empty()) {
        // The item's own axes: a gun points along its muzzle socket (up is up); anything else points along its grip socket's
        // direction (a blade or a handle). That axis goes along the hand's aim, held at the grip.
        glm::vec3 grip = item->center(), along(0, 0, 1), upish(0, 1, 0);
        bool gun = false;
        for (const Socket& k : item->sockets) {
            if (k.name == "grip") { grip = k.position; if (!gun) along = k.direction; }
            if (k.name == "muzzle") { along = k.direction; gun = true; }
        }
        if (!gun) upish = std::fabs(along.z) < 0.9f ? glm::vec3(0, 0, -1) : glm::vec3(1, 0, 0);
        const glm::vec3 zm = glm::normalize(along);
        glm::vec3 ym = upish - zm * glm::dot(upish, zm);
        ym = glm::length(ym) > 1e-4f ? glm::normalize(ym) : glm::vec3(0, 1, 0);
        const glm::vec3 xm = glm::cross(ym, zm);
        const glm::mat3 toFrame = glm::transpose(glm::mat3(xm, ym, zm));          // the item's axes onto the hand's frame
        ObjectDraw d;
        d.asset = item;
        d.model = pose.item * glm::mat4(toFrame) * glm::translate(glm::mat4(1.0f), -grip);
        d.highlight = highlight;
        out.push_back(std::move(d));
    }
}
} // namespace

} // namespace px
