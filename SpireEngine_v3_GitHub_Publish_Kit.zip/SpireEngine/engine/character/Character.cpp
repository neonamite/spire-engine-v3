#include "character/Character.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

// ---------------------------------------------------------------- names

const char* boneName(Bone b) {
    static const char* n[kBoneCount] = { "pelvis", "chest", "neck", "head", "upper_arm_l", "lower_arm_l", "hand_l", "upper_arm_r", "lower_arm_r",
                                         "hand_r", "upper_leg_l", "lower_leg_l", "foot_l", "upper_leg_r", "lower_leg_r", "foot_r" };
    return int(b) < kBoneCount ? n[int(b)] : "";
}

int boneParent(Bone b) {
    switch (b) {
    case Bone::Pelvis: return -1;
    case Bone::Chest: return int(Bone::Pelvis);
    case Bone::Neck: return int(Bone::Chest);
    case Bone::Head: return int(Bone::Neck);
    case Bone::UpperArmL: case Bone::UpperArmR: return int(Bone::Chest);
    case Bone::LowerArmL: return int(Bone::UpperArmL);
    case Bone::HandL: return int(Bone::LowerArmL);
    case Bone::LowerArmR: return int(Bone::UpperArmR);
    case Bone::HandR: return int(Bone::LowerArmR);
    case Bone::UpperLegL: case Bone::UpperLegR: return int(Bone::Pelvis);
    case Bone::LowerLegL: return int(Bone::UpperLegL);
    case Bone::FootL: return int(Bone::LowerLegL);
    case Bone::LowerLegR: return int(Bone::UpperLegR);
    case Bone::FootR: return int(Bone::LowerLegR);
    case Bone::Count: break;
    }
    return -1;
}

const char* partSlotName(PartSlot s) {
    static const char* n[kPartSlotCount] = { "hips", "torso", "neck", "head", "hair", "upper_arm", "lower_arm", "hand", "upper_leg", "lower_leg", "foot",
                                             "hat", "glasses", "beard", "back" };
    return int(s) < kPartSlotCount ? n[int(s)] : "";
}
const char* partSlotLabel(PartSlot s) {
    static const char* n[kPartSlotCount] = { "Hips", "Torso", "Neck", "Head", "Hair", "Upper arms", "Lower arms", "Hands", "Upper legs", "Lower legs", "Feet",
                                             "Hat", "Glasses", "Beard", "On the back" };
    return int(s) < kPartSlotCount ? n[int(s)] : "";
}

PartSlot slotForBone(Bone b) {
    switch (b) {
    case Bone::Pelvis: return PartSlot::Hips;
    case Bone::Chest: return PartSlot::Torso;
    case Bone::Neck: return PartSlot::Neck;
    case Bone::Head: return PartSlot::Head;
    case Bone::UpperArmL: case Bone::UpperArmR: return PartSlot::UpperArm;
    case Bone::LowerArmL: case Bone::LowerArmR: return PartSlot::LowerArm;
    case Bone::HandL: case Bone::HandR: return PartSlot::Hand;
    case Bone::UpperLegL: case Bone::UpperLegR: return PartSlot::UpperLeg;
    case Bone::LowerLegL: case Bone::LowerLegR: return PartSlot::LowerLeg;
    case Bone::FootL: case Bone::FootR: return PartSlot::Foot;
    case Bone::Count: break;
    }
    return PartSlot::Torso;
}

bool isAccessorySlot(PartSlot s) { return s == PartSlot::Hat || s == PartSlot::Glasses || s == PartSlot::Beard || s == PartSlot::Back; }
Bone boneForAccessory(PartSlot s) { return s == PartSlot::Back ? Bone::Chest : Bone::Head; }

const char* colourRoleKey(ColourRole r) {
    static const char* k[int(ColourRole::Count)] = { "skin", "hair", "top", "bottoms", "shoes", "accent" };
    return int(r) < int(ColourRole::Count) ? k[int(r)] : "skin";
}
bool colourRoleFromKey(const std::string& key, ColourRole& out) {
    for (int i = 0; i < int(ColourRole::Count); ++i) if (key == colourRoleKey(ColourRole(i))) { out = ColourRole(i); return true; }
    return false;
}

const char* eyeStyleLabel(int i) { static const char* n[] = { "Natural", "Round", "Narrow", "Sleepy", "Wide" }; return n[std::clamp(i, 0, kEyeStyles - 1)]; }
const char* browStyleLabel(int i) { static const char* n[] = { "None", "Soft", "Angry", "Worried", "Bushy" }; return n[std::clamp(i, 0, kBrowStyles - 1)]; }
const char* noseStyleLabel(int i) { static const char* n[] = { "Small", "Round", "Long", "Button" }; return n[std::clamp(i, 0, kNoseStyles - 1)]; }
const char* mouthStyleLabel(int i) { static const char* n[] = { "Relaxed", "Smile", "Pressed", "Grin", "Frown" }; return n[std::clamp(i, 0, kMouthStyles - 1)]; }

void HumanLook::clamp() {
    auto fix = [](float& v, float def) { v = std::isfinite(v) ? std::clamp(v, 0.0f, 1.0f) : def; };
    fix(gender, 1.0f); fix(age, 0.5f); fix(muscle, 0.5f); fix(weight, 0.5f);
    float sum = 0.0f;
    for (float& h : heritage) { fix(h, 1.0f / 3.0f); sum += h; }
    if (sum < 1e-4f) heritage = { 1.0f / 3.0f, 1.0f / 3.0f, 1.0f / 3.0f };
    else for (float& h : heritage) h /= sum;
    for (int i = 0; i < 3; ++i) eyes[i] = std::isfinite(eyes[i]) ? std::clamp(eyes[i], 0.0f, 1.0f) : 0.3f;
}

const char* heritageLabel(int i) {
    switch (i) { case 0: return "African"; case 1: return "Asian"; default: return "European"; }
}

void MoveStyle::clamp() {
    auto fix = [](float& v, float lo, float hi, float def) { v = std::isfinite(v) ? std::clamp(v, lo, hi) : def; };
    fix(stride, 0.7f, 1.3f, 1.0f); fix(swagger, 0.0f, 1.0f, 0.0f); fix(armSwing, 0.0f, 1.6f, 1.0f);
    fix(bounce, 0.0f, 2.0f, 1.0f); fix(posture, -1.0f, 1.0f, 0.0f); fix(fidget, 0.0f, 1.0f, 0.5f);
}

const std::vector<std::pair<const char*, MoveStyle>>& moveStylePresets() {
    static const std::vector<std::pair<const char*, MoveStyle>> p = {
        { "Normal",  MoveStyle{} },
        { "March",   MoveStyle{ 1.15f, 0.0f, 1.5f, 0.6f, 0.8f, 0.15f } },
        { "Shuffle", MoveStyle{ 0.72f, 0.1f, 0.3f, 0.2f, -0.9f, 0.3f } },
        { "Bouncy",  MoveStyle{ 0.95f, 0.2f, 1.2f, 2.0f, 0.2f, 0.9f } },
        { "Swagger", MoveStyle{ 1.05f, 1.0f, 0.8f, 0.7f, 0.5f, 0.6f } },
        { "Sneak",   MoveStyle{ 0.8f, 0.0f, 0.4f, 0.3f, -0.5f, 0.2f } },
        { "Proud",   MoveStyle{ 1.1f, 0.3f, 0.9f, 0.8f, 1.0f, 0.4f } },
    };
    return p;
}

const char* colourRoleLabel(ColourRole r) {
    switch (r) {
    case ColourRole::Skin: return "Skin";
    case ColourRole::Hair: return "Hair";
    case ColourRole::Top: return "Top";
    case ColourRole::Bottoms: return "Trousers";
    case ColourRole::Shoes: return "Shoes";
    case ColourRole::Accent: return "Accent";
    case ColourRole::Count: break;
    }
    return "";
}

ColourRole colourRoleFor(PartSlot s) {
    switch (s) {
    case PartSlot::Hips: case PartSlot::UpperLeg: case PartSlot::LowerLeg: return ColourRole::Bottoms;
    case PartSlot::Torso: case PartSlot::UpperArm: return ColourRole::Top;
    case PartSlot::Hair: return ColourRole::Hair;
    case PartSlot::Foot: return ColourRole::Shoes;
    case PartSlot::Hat: case PartSlot::Glasses: case PartSlot::Back: return ColourRole::Accent;
    case PartSlot::Beard: return ColourRole::Hair;
    default: return ColourRole::Skin;
    }
}

const char* hairStyleName(HairStyle h) {
    static const char* n[int(HairStyle::Count)] = { "none", "short", "long", "bun", "spiky", "ponytail", "curly", "mohawk" };
    return int(h) < int(HairStyle::Count) ? n[int(h)] : "short";
}
const char* hairStyleLabel(HairStyle h) {
    static const char* n[int(HairStyle::Count)] = { "None", "Short", "Long", "Bun", "Spiky", "Ponytail", "Curly", "Mohawk" };
    return int(h) < int(HairStyle::Count) ? n[int(h)] : "Short";
}

void BodyShape::clamp() {
    auto fix = [](float& v, float lo, float hi, float def) { v = std::isfinite(v) ? std::clamp(v, lo, hi) : def; };
    fix(height, 1.0f, 2.4f, 1.8f);
    fix(build, 0.7f, 1.5f, 1.0f);
    fix(shoulders, 0.8f, 1.3f, 1.0f);
    fix(legs, 0.85f, 1.15f, 1.0f);
    fix(arms, 0.85f, 1.15f, 1.0f);
    fix(head, 0.8f, 1.5f, 1.0f);
}

// ---------------------------------------------------------------- the skeleton

Skeleton buildSkeleton(const BodyShape& in) {
    BodyShape s = in;
    s.clamp();
    // The standard body is 1.8 m, in real proportions (1.5: those of the MakeHuman body, so the realistic body fits its
    // skeleton without stretching): ankle 0.079, shin 0.405, thigh 0.452, pelvis 0.11, chest 0.473, neck 0.117, head 0.164
    // (from the top of the neck to the crown). The built-in voxel parts were made for the 1.4 lengths (0.085, 0.42, 0.44,
    // 0.11, 0.42, 0.09); their stretch (partScale) makes up the difference.
    const float l = s.legs, h = s.head, a = s.arms, b = s.build;
    const float total = 0.079f + 0.857f * l + 0.11f + 0.473f + 0.117f + 0.164f * h;
    const float f = s.height / total;
    Skeleton sk;
    sk.height = s.height;
    sk.scale = f;
    sk.ankleHeight = 0.079f * f;
    sk.hipHeight = (0.079f + 0.857f * l) * f;
    const float thick = f * b, slim = f * std::sqrt(b);
    const float hipX = 0.105f * f * (0.85f + 0.15f * b);
    const float shoulderX = 0.18f * f * s.shoulders * (0.9f + 0.1f * b);
    auto set = [&](Bone bone, glm::vec3 off, float len, glm::vec3 ps) {
        Skeleton::B& B = sk.bones[size_t(bone)];
        B.parent = boneParent(bone); B.offset = off; B.length = len; B.partScale = ps;
    };
    set(Bone::Pelvis, glm::vec3(0.0f, sk.hipHeight, 0.0f), 0.11f * f, glm::vec3(thick, f, thick));
    set(Bone::Chest, glm::vec3(0.0f, 0.11f * f, 0.0f), 0.473f * f, glm::vec3(thick * (0.55f + 0.45f * s.shoulders), f * (0.473f / 0.42f), thick));
    set(Bone::Neck, glm::vec3(0.0f, 0.473f * f, 0.0f), 0.117f * f, glm::vec3(slim, f * (0.117f / 0.09f), slim));
    set(Bone::Head, glm::vec3(0.0f, 0.117f * f, 0.0f), 0.164f * f * h, glm::vec3(f * h));
    for (int side = 0; side < 2; ++side) {
        const float sx = side == 0 ? 1.0f : -1.0f;               // left is +x
        const Bone up = side == 0 ? Bone::UpperArmL : Bone::UpperArmR, lo = side == 0 ? Bone::LowerArmL : Bone::LowerArmR, hand = side == 0 ? Bone::HandL : Bone::HandR;
        set(up, glm::vec3(sx * shoulderX, 0.404f * f, 0.0f), 0.25f * f * a, glm::vec3(thick, f * a * (0.25f / 0.29f), thick));
        set(lo, glm::vec3(0.0f, -0.25f * f * a, 0.0f), 0.25f * f * a, glm::vec3(slim, f * a * (0.25f / 0.26f), slim));
        set(hand, glm::vec3(0.0f, -0.25f * f * a, 0.0f), 0.18f * f, glm::vec3(f));
        const Bone th = side == 0 ? Bone::UpperLegL : Bone::UpperLegR, sh = side == 0 ? Bone::LowerLegL : Bone::LowerLegR, foot = side == 0 ? Bone::FootL : Bone::FootR;
        set(th, glm::vec3(sx * hipX, 0.0f, 0.0f), 0.452f * f * l, glm::vec3(thick, f * l * (0.452f / 0.44f), thick));
        set(sh, glm::vec3(0.0f, -0.452f * f * l, 0.0f), 0.405f * f * l, glm::vec3(slim, f * l * (0.405f / 0.42f), slim));
        set(foot, glm::vec3(0.0f, -0.405f * f * l, 0.0f), 0.26f * f, glm::vec3(slim, f * (0.079f / 0.085f), f));
    }
    return sk;
}

std::array<glm::mat4, kBoneCount> poseToWorld(const Skeleton& sk, const Pose& p, const glm::mat4& root) {
    std::array<glm::mat4, kBoneCount> w;
    for (int i = 0; i < kBoneCount; ++i) {
        const Skeleton::B& b = sk.bones[size_t(i)];
        const glm::mat4& parent = b.parent < 0 ? root : w[size_t(b.parent)];
        const glm::vec3 off = b.parent < 0 ? b.offset + p.pelvisOffset : b.offset;
        w[size_t(i)] = parent * glm::translate(glm::mat4(1.0f), off) * glm::mat4_cast(p.local[size_t(i)]);
    }
    return w;
}

glm::quat localFor(const Skeleton& sk, const std::array<glm::mat4, kBoneCount>& world, const glm::mat4& root, Bone b, const glm::quat& worldRot) {
    const int parent = sk.bone(b).parent;
    const glm::quat pr = glm::quat_cast(glm::mat3(parent < 0 ? root : world[size_t(parent)]));
    return glm::normalize(glm::inverse(pr) * worldRot);
}

glm::vec3 solveTwoBone(const glm::vec3& a, const glm::vec3& b, const glm::vec3& c, const glm::vec3& target, const glm::vec3& pole, glm::vec3* reached) {
    const float l1 = glm::length(b - a), l2 = glm::length(c - b);
    glm::vec3 toT = target - a;
    float d = glm::length(toT);
    const glm::vec3 dir = d > 1e-6f ? toT / d : glm::normalize(c - a + glm::vec3(0.0f, -1e-6f, 0.0f));
    d = std::clamp(d, std::fabs(l1 - l2) + 1e-4f, l1 + l2 - 1e-4f);
    glm::vec3 pv = pole - a;
    pv -= dir * glm::dot(pv, dir);
    if (glm::length(pv) < 1e-5f) { pv = b - a; pv -= dir * glm::dot(pv, dir); }
    if (glm::length(pv) < 1e-5f) { pv = std::fabs(dir.y) < 0.9f ? glm::vec3(0, 1, 0) : glm::vec3(0, 0, 1); pv -= dir * glm::dot(pv, dir); }
    const glm::vec3 n = glm::normalize(pv);
    const float cosA = std::clamp((l1 * l1 + d * d - l2 * l2) / (2.0f * l1 * d), -1.0f, 1.0f);
    const float sinA = std::sqrt(std::max(0.0f, 1.0f - cosA * cosA));
    if (reached) *reached = a + dir * d;
    return a + dir * (l1 * cosA) + n * (l1 * sinA);
}

// ---------------------------------------------------------------- files

std::string colourToHex(const glm::vec3& c) {
    char b[8];
    auto byte = [](float v) { return int(std::lround(std::clamp(v, 0.0f, 1.0f) * 255.0f)); };
    std::snprintf(b, sizeof b, "#%02x%02x%02x", byte(c.r), byte(c.g), byte(c.b));
    return b;
}

bool colourFromHex(const std::string& s, glm::vec3& out) {
    std::string t = s;
    if (!t.empty() && t[0] == '#') t.erase(t.begin());
    if (t.size() != 6) return false;
    int v[3];
    for (int i = 0; i < 3; ++i) {
        int x = 0;
        for (int k = 0; k < 2; ++k) {
            const char ch = char(std::tolower(static_cast<unsigned char>(t[size_t(i * 2 + k)])));
            if (ch >= '0' && ch <= '9') x = x * 16 + (ch - '0');
            else if (ch >= 'a' && ch <= 'f') x = x * 16 + (ch - 'a' + 10);
            else return false;
        }
        v[i] = x;
    }
    out = glm::vec3(float(v[0]), float(v[1]), float(v[2])) / 255.0f;
    return true;
}

Json characterToJson(const CharacterDef& c) {
    Json j = Json::object();
    j.set("format", "pxcharacter");
    j.set("version", 1);
    j.set("name", c.name);
    Json body = Json::object();
    body.set("height", c.shape.height);
    body.set("build", c.shape.build);
    body.set("shoulders", c.shape.shoulders);
    body.set("legs", c.shape.legs);
    body.set("arms", c.shape.arms);
    body.set("head", c.shape.head);
    j.set("body", body);
    Json col = Json::object();
    for (int i = 0; i < int(ColourRole::Count); ++i) col.set(colourRoleKey(ColourRole(i)), colourToHex(c.colours[size_t(i)]));
    j.set("colours", col);
    j.set("hair", hairStyleName(c.hair));
    j.set("face", Json::array({ int(c.face.eyes), int(c.face.brows), int(c.face.nose), int(c.face.mouth) }));
    Json mv = Json::object();
    mv.set("stride", c.move.stride); mv.set("swagger", c.move.swagger); mv.set("armSwing", c.move.armSwing);
    mv.set("bounce", c.move.bounce); mv.set("posture", c.move.posture); mv.set("fidget", c.move.fidget);
    j.set("move", mv);
    Json lk = Json::object();
    lk.set("gender", c.look.gender); lk.set("age", c.look.age); lk.set("muscle", c.look.muscle); lk.set("weight", c.look.weight);
    lk.set("heritage", Json::array({ c.look.heritage[0], c.look.heritage[1], c.look.heritage[2] }));
    lk.set("faceSeed", double(c.look.faceSeed));
    lk.set("eyes", colourToHex(c.look.eyes));
    j.set("look", lk);
    Json pc = Json::object();
    for (int i = 0; i < kPartSlotCount; ++i) if (c.partColour[size_t(i)].w > 0.5f) pc.set(partSlotName(PartSlot(i)), colourToHex(glm::vec3(c.partColour[size_t(i)])));
    if (pc.size()) j.set("partColours", pc);
    Json parts = Json::object();
    for (int i = 0; i < kPartSlotCount; ++i) if (!c.parts[size_t(i)].empty()) parts.set(partSlotName(PartSlot(i)), c.parts[size_t(i)]);
    if (parts.size()) j.set("parts", parts);
    return j;
}

namespace {
std::string clean(const std::string& s, size_t maxLen) {
    std::string o;
    for (char ch : s) if (static_cast<unsigned char>(ch) >= 0x20) o += ch;
    if (o.size() > maxLen) o.resize(maxLen);
    return o;
}
} // namespace

HumanLook lookFromShape(const CharacterDef& c) {
    HumanLook l;
    const bool longHair = c.hair == HairStyle::Long || c.hair == HairStyle::Bun || c.hair == HairStyle::Ponytail;
    l.gender = longHair ? 0.1f : 0.9f;
    if (c.parts[size_t(PartSlot::Beard)].size()) l.gender = 1.0f;
    l.age = c.shape.height < 1.45f ? 0.25f : 0.5f;
    l.weight = std::clamp(0.5f + (c.shape.build - 1.0f) * 0.9f, 0.0f, 1.0f);
    l.muscle = std::clamp(0.5f + (c.shape.shoulders - 1.0f) * 1.2f, 0.0f, 1.0f);
    // the skin tone suggests a heritage (only a starting point: every slider is yours to move)
    const glm::vec3 s = c.colour(ColourRole::Skin);
    const float light = (s.r + s.g + s.b) / 3.0f;
    l.heritage = light < 0.45f ? std::array<float, 3>{ 0.8f, 0.05f, 0.15f } : light > 0.7f ? std::array<float, 3>{ 0.05f, 0.15f, 0.8f }
                                                                           : std::array<float, 3>{ 0.25f, 0.35f, 0.4f };
    std::uint32_t h = 2166136261u;
    for (char ch : c.name) { h ^= std::uint8_t(ch); h *= 16777619u; }
    l.faceSeed = h | 1u;
    l.clamp();
    return l;
}

bool characterFromJson(const Json& j, CharacterDef& out, std::string* error) {
    auto fail = [&](const char* why) { if (error) *error = why; return false; };
    if (!j.isObject()) return fail("not a character");
    if (j.has("format") && j.get("format").str() != "pxcharacter") return fail("not a character file");
    if (j.get("version").integer(1) > 1) return fail("made by a newer version of Spire Engine");
    CharacterDef c;
    c.name = clean(j.get("name").str("Character"), 64);
    if (c.name.empty()) c.name = "Character";
    const Json& body = j.get("body");
    c.shape.height = float(body.get("height").num(1.8));
    c.shape.build = float(body.get("build").num(1.0));
    c.shape.shoulders = float(body.get("shoulders").num(1.0));
    c.shape.legs = float(body.get("legs").num(1.0));
    c.shape.arms = float(body.get("arms").num(1.0));
    c.shape.head = float(body.get("head").num(1.0));
    c.shape.clamp();
    const Json& col = j.get("colours");
    for (int i = 0; i < int(ColourRole::Count); ++i) {
        glm::vec3 v;
        if (colourFromHex(col.get(colourRoleKey(ColourRole(i))).str(), v)) c.colours[size_t(i)] = v;
    }
    const Json& face = j.get("face");
    if (face.size() == 4) {
        c.face.eyes = std::uint8_t(std::clamp(face.at(0).integer(1), 0, kEyeStyles - 1));
        c.face.brows = std::uint8_t(std::clamp(face.at(1).integer(1), 0, kBrowStyles - 1));
        c.face.nose = std::uint8_t(std::clamp(face.at(2).integer(0), 0, kNoseStyles - 1));
        c.face.mouth = std::uint8_t(std::clamp(face.at(3).integer(1), 0, kMouthStyles - 1));
    }
    const Json& mv = j.get("move");
    c.move.stride = float(mv.get("stride").num(1.0)); c.move.swagger = float(mv.get("swagger").num(0.0));
    c.move.armSwing = float(mv.get("armSwing").num(1.0)); c.move.bounce = float(mv.get("bounce").num(1.0));
    c.move.posture = float(mv.get("posture").num(0.0)); c.move.fidget = float(mv.get("fidget").num(0.5));
    c.move.clamp();
    const Json& pc = j.get("partColours");
    for (int i = 0; i < kPartSlotCount; ++i) {
        glm::vec3 v;
        if (colourFromHex(pc.get(partSlotName(PartSlot(i))).str(), v)) c.partColour[size_t(i)] = glm::vec4(v, 1.0f);
    }
    const std::string hair = j.get("hair").str("short");
    for (int h = 0; h < int(HairStyle::Count); ++h) if (hair == hairStyleName(HairStyle(h))) c.hair = HairStyle(h);
    if (j.has("look")) {
        const Json& lk = j.get("look");
        c.look.gender = float(lk.get("gender").num(1.0)); c.look.age = float(lk.get("age").num(0.5));
        c.look.muscle = float(lk.get("muscle").num(0.5)); c.look.weight = float(lk.get("weight").num(0.5));
        const Json& h = lk.get("heritage");
        if (h.size() == 3) for (int i = 0; i < 3; ++i) c.look.heritage[size_t(i)] = float(h.at(size_t(i)).num(1.0 / 3.0));
        c.look.faceSeed = std::uint32_t(std::clamp(lk.get("faceSeed").num(0.0), 0.0, 4294967295.0));
        glm::vec3 e;
        if (colourFromHex(lk.get("eyes").str(), e)) c.look.eyes = e;
    } else {
        // a character from before 1.5: a body to match what they were (long hair and a slim build read as a woman)
        c.look = lookFromShape(c);
    }
    c.look.clamp();
    const Json& parts = j.get("parts");
    for (int i = 0; i < kPartSlotCount; ++i) c.parts[size_t(i)] = clean(parts.get(partSlotName(PartSlot(i))).str(), 64);
    out = std::move(c);
    return true;
}

std::string characterFileName(const std::string& name) {
    std::string out;
    for (char ch : name) {
        const unsigned char u = static_cast<unsigned char>(ch);
        if (std::isalnum(u)) out += char(std::tolower(u));
        else if ((ch == ' ' || ch == '_' || ch == '-') && !out.empty() && out.back() != '_') out += '_';
    }
    while (!out.empty() && out.back() == '_') out.pop_back();
    if (out.size() > 48) out.resize(48);
    return out.empty() ? std::string("character") : out;
}

bool saveCharacterFile(const CharacterDef& c, const std::string& path, std::string* error) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const fs::path target(path);
    if (target.has_parent_path()) fs::create_directories(target.parent_path(), ec);
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) { if (error) *error = "could not write " + tmp; return false; }
        f << characterToJson(c).dump(2) << "\n";
        f.flush();
        if (!f) { f.close(); fs::remove(tmp, ec); if (error) *error = "could not write " + path; return false; }
    }
    fs::rename(tmp, target, ec);
    if (ec) { fs::remove(tmp, ec); if (error) *error = "could not replace " + path; return false; }
    return true;
}

bool loadCharacterFile(const std::string& path, CharacterDef& out, std::string* error) {
    namespace fs = std::filesystem;
    std::error_code ec;
    const auto len = fs::file_size(path, ec);
    if (ec) { if (error) *error = "could not open " + path; return false; }
    if (len > 256 * 1024) { if (error) *error = "the file is too large to be a character"; return false; }
    std::ifstream f(path, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    Json j;
    std::string err;
    if (!Json::parse(ss.str(), j, &err)) { if (error) *error = "damaged: " + err; return false; }
    return characterFromJson(j, out, error);
}

// ---------------------------------------------------------------- ready-made people

const std::vector<glm::vec3>& skinTones() {
    static const std::vector<glm::vec3> t = { { 0.96f, 0.80f, 0.69f }, { 0.91f, 0.71f, 0.56f }, { 0.80f, 0.58f, 0.42f },
                                              { 0.64f, 0.44f, 0.30f }, { 0.45f, 0.30f, 0.20f }, { 0.30f, 0.20f, 0.14f } };
    return t;
}
const std::vector<glm::vec3>& hairColours() {
    static const std::vector<glm::vec3> t = { { 0.06f, 0.05f, 0.05f }, { 0.22f, 0.14f, 0.08f }, { 0.42f, 0.27f, 0.14f }, { 0.86f, 0.71f, 0.42f },
                                              { 0.64f, 0.23f, 0.10f }, { 0.72f, 0.72f, 0.74f }, { 0.22f, 0.42f, 0.88f }, { 0.92f, 0.46f, 0.72f } };
    return t;
}

const std::vector<CharacterDef>& characterPresets() {
    static const std::vector<CharacterDef> list = [] {
        std::vector<CharacterDef> v;
        auto make = [&](const char* name, BodyShape sh, int skin, HairStyle hair, int hairCol, glm::vec3 top, glm::vec3 bottoms, glm::vec3 shoes) {
            CharacterDef c;
            c.name = name; c.shape = sh; c.hair = hair;
            c.colour(ColourRole::Skin) = skinTones()[size_t(skin)];
            c.colour(ColourRole::Hair) = hairColours()[size_t(hairCol)];
            c.colour(ColourRole::Top) = top; c.colour(ColourRole::Bottoms) = bottoms; c.colour(ColourRole::Shoes) = shoes;
            v.push_back(c);
        };
        BodyShape s;
        make("Explorer", s, 2, HairStyle::Short, 2, { 0.58f, 0.50f, 0.32f }, { 0.32f, 0.27f, 0.20f }, { 0.30f, 0.20f, 0.12f });
        s = BodyShape(); s.height = 1.86f; s.build = 1.25f; s.shoulders = 1.15f;
        make("Builder", s, 3, HairStyle::Spiky, 0, { 0.95f, 0.50f, 0.12f }, { 0.20f, 0.30f, 0.50f }, { 0.25f, 0.18f, 0.10f });
        s = BodyShape(); s.height = 1.82f; s.build = 0.95f;
        make("Agent", s, 4, HairStyle::Short, 0, { 0.11f, 0.11f, 0.13f }, { 0.11f, 0.11f, 0.13f }, { 0.05f, 0.05f, 0.05f });
        s = BodyShape(); s.height = 1.68f; s.build = 0.9f; s.shoulders = 0.92f;
        make("Scientist", s, 0, HairStyle::Bun, 4, { 0.93f, 0.93f, 0.93f }, { 0.40f, 0.42f, 0.46f }, { 0.20f, 0.20f, 0.22f });
        s = BodyShape(); s.height = 1.25f; s.build = 0.85f; s.head = 1.3f; s.legs = 0.9f; s.arms = 0.95f;
        make("Kid", s, 1, HairStyle::Spiky, 3, { 0.88f, 0.22f, 0.20f }, { 0.22f, 0.36f, 0.70f }, { 0.95f, 0.95f, 0.95f });
        s = BodyShape(); s.height = 2.3f; s.build = 1.45f; s.shoulders = 1.25f; s.head = 0.9f;
        make("Giant", s, 5, HairStyle::Long, 1, { 0.30f, 0.45f, 0.25f }, { 0.35f, 0.25f, 0.18f }, { 0.20f, 0.15f, 0.10f });
        // v0.19: each of them gets a face, a way of moving and a few things to wear
        auto dress = [&](const char* name, FaceStyle f, int move, std::initializer_list<std::pair<PartSlot, const char*>> parts, glm::vec3 accent) {
            for (CharacterDef& c : v) if (c.name == name) {
                c.face = f;
                c.move = moveStylePresets()[size_t(move)].second;
                for (const auto& [slot, asset] : parts) c.parts[size_t(slot)] = asset;
                c.colour(ColourRole::Accent) = accent;
            }
        };
        using P = PartSlot;
        dress("Explorer", { 1, 1, 0, 1 }, 0, { { P::Hat, "hat cowboy" }, { P::Back, "back backpack" }, { P::Foot, "foot boot" } }, { 0.45f, 0.32f, 0.18f });
        dress("Builder", { 0, 4, 1, 3 }, 4, { { P::Hat, "hat helmet" }, { P::Torso, "torso vest" }, { P::UpperArm, "upper arm bare" }, { P::Foot, "foot boot" },
                                              { P::Beard, "beard moustache" } }, { 0.95f, 0.78f, 0.12f });
        dress("Agent", { 2, 2, 0, 2 }, 6, { { P::Torso, "torso jacket" }, { P::Glasses, "glasses shades" } }, { 0.1f, 0.1f, 0.1f });
        dress("Scientist", { 1, 3, 3, 1 }, 2, { { P::Torso, "torso coat" }, { P::Glasses, "glasses round" } }, { 0.25f, 0.25f, 0.3f });
        dress("Kid", { 4, 1, 3, 3 }, 3, { { P::Hat, "hat cap" }, { P::LowerLeg, "lower leg bare" }, { P::Back, "back backpack" } }, { 0.2f, 0.6f, 0.95f });
        dress("Giant", { 3, 4, 2, 4 }, 0, { { P::Torso, "torso armour" }, { P::UpperArm, "upper arm bare" }, { P::Beard, "beard full" }, { P::Back, "back cape" },
                                            { P::Foot, "foot boot" } }, { 0.55f, 0.55f, 0.6f });
        for (CharacterDef& c : v) if (c.name == "Giant") { c.move.stride = 0.85f; c.move.bounce = 0.4f; }
        // 1.5: their bodies
        auto look = [&](const char* name, float gender, float age, float muscle, float weight, std::array<float, 3> heritage, glm::vec3 eyes) {
            for (CharacterDef& c : v) if (c.name == name) {
                c.look.gender = gender; c.look.age = age; c.look.muscle = muscle; c.look.weight = weight; c.look.heritage = heritage;
                c.look.eyes = eyes;
                std::uint32_t h = 2166136261u;
                for (char ch : c.name) { h ^= std::uint8_t(ch); h *= 16777619u; }
                c.look.faceSeed = h | 1u;
                c.look.clamp();
            }
        };
        look("Explorer", 0.85f, 0.45f, 0.6f, 0.45f, { 0.1f, 0.15f, 0.75f }, { 0.36f, 0.48f, 0.62f });
        look("Builder", 1.0f, 0.55f, 0.75f, 0.65f, { 0.15f, 0.1f, 0.75f }, { 0.30f, 0.20f, 0.12f });
        look("Agent", 0.95f, 0.5f, 0.6f, 0.4f, { 0.75f, 0.05f, 0.2f }, { 0.22f, 0.14f, 0.08f });
        look("Scientist", 0.05f, 0.45f, 0.4f, 0.4f, { 0.05f, 0.75f, 0.2f }, { 0.22f, 0.14f, 0.08f });
        look("Kid", 0.7f, 0.22f, 0.45f, 0.45f, { 0.3f, 0.3f, 0.4f }, { 0.30f, 0.20f, 0.12f });
        look("Giant", 1.0f, 0.6f, 0.85f, 0.75f, { 0.45f, 0.05f, 0.5f }, { 0.36f, 0.45f, 0.26f });
        return v;
    }();
    return list;
}

// ---------------------------------------------------------------- crowds

namespace {
// A small, fixed random generator: the same seed makes the same person on every machine, forever.
struct CrowdRng {
    std::uint64_t s;
    explicit CrowdRng(std::uint32_t seed) : s(0x9E3779B97F4A7C15ull ^ (std::uint64_t(seed) * 0xBF58476D1CE4E5B9ull)) { next(); next(); }
    std::uint32_t next() {
        std::uint64_t z = (s += 0x9E3779B97F4A7C15ull);
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
        z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
        return std::uint32_t((z ^ (z >> 31)) >> 16);
    }
    float f() { return float(next() % 100000u) / 100000.0f; }                  // 0 .. 1
    float range(float a, float b) { return a + (b - a) * f(); }
    int pick(int n) { return n <= 0 ? 0 : int(next() % std::uint32_t(n)); }
    bool chance(float p) { return f() < p; }
    template <class T> const T& of(const std::vector<T>& v) { return v[size_t(pick(int(v.size())))]; }
};

glm::vec3 jitter(CrowdRng& r, glm::vec3 c, float amount) {
    return glm::clamp(c * r.range(1.0f - amount, 1.0f + amount), glm::vec3(0.02f), glm::vec3(1.0f));
}

const char* kFirstNames[] = { "Mara", "Tobin", "Ada", "Jonas", "Ivy", "Rafe", "Nell", "Oskar", "Lena", "Hugo", "Bea", "Silas", "Wren", "Cato",
                              "Elsie", "Bram", "Yara", "Felix", "Juno", "Otto", "Pia", "Arlo", "Rosa", "Emil", "Tess", "Kofi", "Mei", "Ravi",
                              "Noor", "Dario", "Lark", "Inge", "Sami", "Vera", "Ezra", "Coral" };
const char* kLastNames[] = { "Quill", "Ashdown", "Marsh", "Fenwick", "Cobb", "Thorne", "Hale", "Pike", "Rook", "Barlow", "Vance", "Gale",
                             "Holt", "Crane", "Moss", "Wilder", "Finch", "Stone", "Reed", "Dunmore", "Larkin", "Okafor", "Tanaka", "Silva",
                             "Novak", "Brand", "Kestrel", "Blythe", "Varga", "Lowe" };
} // namespace

const char* crowdStyleName(CrowdStyle s) {
    static const char* n[] = { "anyone", "villagers", "city", "soldiers", "scifi", "fantasy" };
    return size_t(s) < std::size(n) ? n[size_t(s)] : "anyone";
}
const char* crowdStyleLabel(CrowdStyle s) {
    static const char* n[] = { "Anyone", "Villagers", "City folk", "Soldiers", "Sci-fi crew", "Fantasy" };
    return size_t(s) < std::size(n) ? n[size_t(s)] : "Anyone";
}

std::string crowdName(CrowdStyle style, std::uint32_t seed) {
    return std::string("crowd:") + crowdStyleName(style) + ":" + std::to_string(seed);
}

bool parseCrowdName(const std::string& name, CrowdStyle& style, std::uint32_t& seed) {
    if (name.rfind("crowd:", 0) != 0) return false;
    const size_t colon = name.find(':', 6);
    if (colon == std::string::npos || colon + 1 >= name.size()) return false;
    const std::string st = name.substr(6, colon - 6), num = name.substr(colon + 1);
    bool found = false;
    for (int i = 0; i < int(CrowdStyle::Count); ++i)
        if (st == crowdStyleName(CrowdStyle(i))) { style = CrowdStyle(i); found = true; }
    if (!found) return false;
    std::uint64_t v = 0;
    for (char ch : num) { if (ch < '0' || ch > '9') return false; v = v * 10 + std::uint64_t(ch - '0'); if (v > 0xFFFFFFFFull) return false; }
    seed = std::uint32_t(v);
    return true;
}

std::string personName(std::uint32_t seed) {
    CrowdRng r(seed ^ 0x51ED27u);
    return std::string(kFirstNames[r.pick(int(std::size(kFirstNames)))]) + " " + kLastNames[r.pick(int(std::size(kLastNames)))];
}

std::vector<glm::vec2> crowdSpots(int count, float radius, std::uint32_t seed, float gap) {
    std::vector<glm::vec2> out;
    CrowdRng r(seed ^ 0xC0FFEEu);
    const float golden = 2.39996323f;
    count = std::clamp(count, 0, 500);
    for (int i = 0, tries = 0; int(out.size()) < count && tries < count * 40; ++tries) {
        // a sunflower spiral (even, no rows) with a little shake, then a random spot when the spiral's place is taken
        glm::vec2 p;
        if (tries < count * 2) {
            const float k = (float(i) + 0.5f) / float(std::max(count, 1));
            const float rad = radius * std::sqrt(k), ang = float(i) * golden + float(seed % 628u) * 0.01f;
            p = glm::vec2(std::cos(ang), std::sin(ang)) * rad + glm::vec2(r.range(-0.3f, 0.3f), r.range(-0.3f, 0.3f)) * gap;
            ++i;
        } else {
            const float rad = radius * std::sqrt(r.f()), ang = r.range(0.0f, 6.2831853f);
            p = glm::vec2(std::cos(ang), std::sin(ang)) * rad;
        }
        if (glm::length(p) > radius) p *= radius / glm::length(p);
        bool clear = true;
        for (const glm::vec2& q : out) if (glm::length(p - q) < gap) { clear = false; break; }
        if (clear) out.push_back(p);
    }
    return out;
}

CharacterDef makeCrowdPerson(CrowdStyle style, std::uint32_t seed) {
    CrowdRng r(seed);
    if (style == CrowdStyle::Anyone) style = CrowdStyle(1 + r.pick(int(CrowdStyle::Count) - 1));
    CharacterDef c;
    c.name = personName(seed);
    auto setPart = [&](PartSlot s, const char* asset) { c.parts[size_t(s)] = asset ? asset : ""; };

    // the body: most people are ordinary, a few are tall, short, broad or slight
    BodyShape& sh = c.shape;
    sh.height = r.range(1.55f, 1.95f);
    if (r.chance(0.08f)) sh.height = r.range(1.2f, 1.45f);             // a kid or a short one
    sh.build = r.range(0.8f, 1.3f);
    sh.shoulders = r.range(0.88f, 1.18f);
    sh.legs = r.range(0.93f, 1.07f);
    sh.arms = r.range(0.95f, 1.05f);
    sh.head = sh.height < 1.45f ? r.range(1.15f, 1.3f) : r.range(0.92f, 1.1f);
    sh.clamp();

    c.colour(ColourRole::Skin) = r.of(skinTones());
    const bool old = r.chance(0.18f);
    c.colour(ColourRole::Hair) = old ? hairColours()[5] : hairColours()[size_t(r.pick(5))];
    static const HairStyle hairs[] = { HairStyle::None, HairStyle::Short, HairStyle::Short, HairStyle::Long, HairStyle::Bun, HairStyle::Spiky,
                                       HairStyle::Ponytail, HairStyle::Curly, HairStyle::Mohawk };
    c.hair = hairs[r.pick(int(std::size(hairs)))];
    if (old && c.hair == HairStyle::Mohawk) c.hair = HairStyle::Short;

    c.face.eyes = std::uint8_t(r.pick(kEyeStyles));
    c.face.brows = std::uint8_t(r.pick(kBrowStyles));
    c.face.nose = std::uint8_t(r.pick(kNoseStyles));
    static const std::uint8_t mouths[] = { 0, 1, 1, 1, 2, 2, 3, 4 };
    c.face.mouth = mouths[r.pick(int(std::size(mouths)))];

    const auto& moves = moveStylePresets();
    c.move = moves[size_t(r.pick(int(moves.size())))].second;
    c.move.stride *= r.range(0.92f, 1.08f);
    c.move.fidget = r.range(0.2f, 0.9f);
    if (old) { c.move = moves[2].second; c.move.posture = -0.6f; }   // they shuffle
    c.move.clamp();

    // clothes, by style
    static const std::vector<glm::vec3> earthy = { { 0.45f, 0.33f, 0.2f }, { 0.55f, 0.48f, 0.32f }, { 0.35f, 0.4f, 0.25f }, { 0.6f, 0.25f, 0.18f },
                                                   { 0.72f, 0.66f, 0.5f }, { 0.3f, 0.32f, 0.38f } };
    static const std::vector<glm::vec3> bright = { { 0.85f, 0.2f, 0.2f }, { 0.2f, 0.45f, 0.85f }, { 0.95f, 0.75f, 0.15f }, { 0.25f, 0.65f, 0.35f },
                                                   { 0.9f, 0.9f, 0.9f }, { 0.12f, 0.12f, 0.14f }, { 0.55f, 0.3f, 0.7f }, { 0.95f, 0.5f, 0.6f } };
    static const std::vector<glm::vec3> darks = { { 0.12f, 0.12f, 0.14f }, { 0.2f, 0.22f, 0.3f }, { 0.3f, 0.3f, 0.32f }, { 0.25f, 0.2f, 0.16f } };
    static const std::vector<glm::vec3> camo = { { 0.33f, 0.38f, 0.22f }, { 0.45f, 0.4f, 0.28f }, { 0.25f, 0.3f, 0.2f } };
    static const std::vector<glm::vec3> scifi = { { 0.9f, 0.92f, 0.95f }, { 0.2f, 0.5f, 0.9f }, { 0.9f, 0.45f, 0.1f }, { 0.25f, 0.27f, 0.3f } };
    static const std::vector<glm::vec3> royal = { { 0.45f, 0.15f, 0.55f }, { 0.15f, 0.25f, 0.6f }, { 0.6f, 0.12f, 0.12f }, { 0.2f, 0.45f, 0.25f },
                                                  { 0.85f, 0.85f, 0.8f } };
    glm::vec3& top = c.colour(ColourRole::Top);
    glm::vec3& bottoms = c.colour(ColourRole::Bottoms);
    glm::vec3& shoes = c.colour(ColourRole::Shoes);
    glm::vec3& accent = c.colour(ColourRole::Accent);
    const bool feminine = r.chance(0.5f);
    switch (style) {
    case CrowdStyle::Villagers:
        top = jitter(r, r.of(earthy), 0.12f); bottoms = jitter(r, r.of(earthy), 0.12f); shoes = jitter(r, { 0.3f, 0.2f, 0.12f }, 0.2f);
        accent = jitter(r, r.of(earthy), 0.15f);
        setPart(PartSlot::Torso, r.of(std::vector<const char*>{ "body torso", "torso vest", "torso striped", "body torso" }));
        if (r.chance(0.35f)) setPart(PartSlot::UpperArm, "upper arm bare");
        if (feminine && r.chance(0.6f)) setPart(PartSlot::Hips, r.chance(0.5f) ? "hips skirt" : "hips robe");
        if (r.chance(0.5f)) setPart(PartSlot::Foot, "foot boot");
        if (r.chance(0.35f)) setPart(PartSlot::Hat, r.of(std::vector<const char*>{ "hat beanie", "hat cowboy", "hat hood" }));
        if (r.chance(0.15f)) setPart(PartSlot::Back, "back backpack");
        break;
    case CrowdStyle::City:
        top = jitter(r, r.of(bright), 0.1f); bottoms = jitter(r, r.of(darks), 0.1f); shoes = r.of(darks);
        accent = jitter(r, r.of(bright), 0.1f);
        setPart(PartSlot::Torso, r.of(std::vector<const char*>{ "body torso", "torso jacket", "torso striped", "torso coat", "body torso" }));
        if (r.chance(0.2f)) setPart(PartSlot::UpperArm, "upper arm bare");
        if (feminine && r.chance(0.4f)) setPart(PartSlot::Hips, "hips skirt");
        if (r.chance(0.15f)) setPart(PartSlot::LowerLeg, "lower leg bare");
        if (r.chance(0.25f)) setPart(PartSlot::Hat, r.of(std::vector<const char*>{ "hat cap", "hat beanie", "hat top hat" }));
        if (r.chance(0.3f)) setPart(PartSlot::Glasses, r.of(std::vector<const char*>{ "glasses round", "glasses shades" }));
        if (r.chance(0.25f)) setPart(PartSlot::Back, "back backpack");
        break;
    case CrowdStyle::Soldiers:
        top = jitter(r, r.of(camo), 0.06f); bottoms = jitter(r, top, 0.06f); shoes = { 0.12f, 0.1f, 0.08f };
        accent = jitter(r, r.of(camo), 0.06f);
        setPart(PartSlot::Torso, r.chance(0.5f) ? "torso vest" : "body torso");
        setPart(PartSlot::Foot, "foot boot");
        setPart(PartSlot::Hat, r.chance(0.8f) ? "hat helmet" : "hat cap");
        if (r.chance(0.6f)) setPart(PartSlot::Back, "back backpack");
        if (r.chance(0.2f)) setPart(PartSlot::Glasses, "glasses goggles");
        if (c.hair == HairStyle::Long || c.hair == HairStyle::Curly || c.hair == HairStyle::Mohawk) c.hair = HairStyle::Short;
        c.move = moves[1].second; c.move.fidget = r.range(0.1f, 0.4f);                 // they march
        break;
    case CrowdStyle::SciFi:
        top = jitter(r, r.of(scifi), 0.05f); bottoms = r.chance(0.5f) ? top : r.of(scifi); shoes = { 0.85f, 0.87f, 0.9f };
        accent = r.of(scifi);
        setPart(PartSlot::Torso, r.chance(0.4f) ? "torso armour" : "body torso");
        setPart(PartSlot::Foot, "foot boot");
        if (r.chance(0.4f)) setPart(PartSlot::Glasses, r.chance(0.6f) ? "glasses visor" : "glasses goggles");
        if (r.chance(0.3f)) setPart(PartSlot::Back, "back tank");
        if (r.chance(0.15f)) setPart(PartSlot::Hat, "hat helmet");
        break;
    case CrowdStyle::Fantasy:
    default:
        top = jitter(r, r.of(royal), 0.1f); bottoms = jitter(r, r.of(earthy), 0.1f); shoes = { 0.3f, 0.2f, 0.12f };
        accent = r.chance(0.5f) ? glm::vec3(0.62f, 0.62f, 0.66f) : jitter(r, r.of(royal), 0.1f);
        setPart(PartSlot::Torso, r.of(std::vector<const char*>{ "torso armour", "torso vest", "body torso", "torso coat" }));
        if (r.chance(0.35f)) setPart(PartSlot::Hips, "hips robe");
        setPart(PartSlot::Foot, "foot boot");
        if (r.chance(0.4f)) setPart(PartSlot::Back, r.of(std::vector<const char*>{ "back cape", "back quiver", "back sword" }));
        if (r.chance(0.3f)) setPart(PartSlot::Hat, r.of(std::vector<const char*>{ "hat hood", "hat helmet", "hat crown" }));
        break;
    }
    if (c.parts[size_t(PartSlot::Torso)] == "body torso") c.parts[size_t(PartSlot::Torso)].clear();     // the default needs no name
    if (!feminine && r.chance(old ? 0.6f : 0.25f) && style != CrowdStyle::SciFi)
        setPart(PartSlot::Beard, r.of(std::vector<const char*>{ "beard full", "beard moustache", "beard goatee" }));
    if (c.parts[size_t(PartSlot::Hat)] == "hat hood" || c.parts[size_t(PartSlot::Hat)] == "hat helmet")
        if (c.hair == HairStyle::Mohawk || c.hair == HairStyle::Spiky) c.hair = HairStyle::Short;
    // 1.5: the body itself, from a generator of its own (so everything above stays exactly as it was for each seed)
    CrowdRng q(seed * 2654435761u + 0x51ed27u);
    HumanLook& l = c.look;
    l = lookFromShape(c);
    l.gender = feminine ? q.range(0.0f, 0.22f) : q.range(0.78f, 1.0f);
    if (!c.parts[size_t(PartSlot::Beard)].empty()) l.gender = std::max(l.gender, 0.9f);
    l.age = old ? q.range(0.8f, 0.95f) : sh.height < 1.45f ? q.range(0.2f, 0.3f) : q.range(0.36f, 0.68f);
    l.muscle = style == CrowdStyle::Soldiers ? q.range(0.55f, 0.9f) : q.range(0.25f, 0.75f);
    l.weight = std::clamp(0.5f + (sh.build - 1.0f) * 0.9f + q.range(-0.12f, 0.12f), 0.0f, 1.0f);
    for (float& h : l.heritage) h = std::max(0.0f, h + q.range(-0.15f, 0.15f));
    static const glm::vec3 eyeColours[] = { { 0.30f, 0.20f, 0.12f }, { 0.22f, 0.14f, 0.08f }, { 0.36f, 0.48f, 0.62f }, { 0.36f, 0.45f, 0.26f },
                                            { 0.45f, 0.34f, 0.18f }, { 0.25f, 0.3f, 0.35f } };
    l.eyes = l.heritage[2] > 0.5f ? eyeColours[q.pick(int(std::size(eyeColours)))] : eyeColours[q.pick(2)];
    l.faceSeed = seed | 1u;
    l.clamp();
    return c;
}

// ---------------------------------------------------------------- the library

int CharacterLibrary::loadDirectory() {
    namespace fs = std::filesystem;
    skipped.clear();
    std::error_code ec;
    if (!fs::is_directory(directory, ec)) return 0;
    std::vector<fs::path> files;
    for (const auto& e : fs::directory_iterator(directory, ec))
        if (e.is_regular_file() && e.path().extension() == ".pxcharacter") files.push_back(e.path());
    std::sort(files.begin(), files.end());
    int n = 0;
    for (const fs::path& p : files) {
        CharacterDef c;
        std::string err;
        if (!loadCharacterFile(p.string(), c, &err)) { skipped.push_back(p.filename().string() + ": " + err); continue; }
        if (isPreset(c.name)) { skipped.push_back(p.filename().string() + ": the name '" + c.name + "' is a ready-made character"); continue; }
        mine[c.name] = c;
        ++n;
    }
    return n;
}

bool CharacterLibrary::save(const CharacterDef& c, std::string* error) {
    if (isPreset(c.name)) { if (error) *error = "that name belongs to a ready-made character"; return false; }
    if (!saveCharacterFile(c, directory + "/" + characterFileName(c.name) + ".pxcharacter", error)) return false;
    mine[c.name] = c;
    return true;
}

const CharacterDef* CharacterLibrary::find(const std::string& name) const {
    const auto it = mine.find(name);
    if (it != mine.end()) return &it->second;
    for (const CharacterDef& c : characterPresets()) if (c.name == name) return &c;
    return nullptr;
}

CharacterDef CharacterLibrary::get(const std::string& name) const {
    if (const CharacterDef* c = find(name)) return *c;
    CrowdStyle style; std::uint32_t seed;
    if (parseCrowdName(name, style, seed)) return makeCrowdPerson(style, seed);
    return characterPresets().front();
}

bool CharacterLibrary::has(const std::string& name) const {
    CrowdStyle style; std::uint32_t seed;
    return find(name) != nullptr || parseCrowdName(name, style, seed);
}

std::vector<std::string> CharacterLibrary::names() const {
    std::vector<std::string> out;
    for (const CharacterDef& c : characterPresets()) out.push_back(c.name);
    for (const auto& [n, c] : mine) out.push_back(n);
    return out;
}

bool CharacterLibrary::isPreset(const std::string& name) const {
    for (const CharacterDef& c : characterPresets()) if (c.name == name) return true;
    return false;
}

} // namespace px
