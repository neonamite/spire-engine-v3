#pragma once
// Procedural animation (v0.18): no animator, no clips. Each frame the body is posed from what the character is doing:
// standing (breathing), walking and running (a gait cycle driven by the distance travelled, so feet never slide), in the
// air (tucked) and landing (a dip), turning smoothly to face where it is going, looking at a point, and holding an item
// (arms reach for hand targets with two-bone IK). Last, the feet are put on the real ground (foot IK): on slopes, steps
// and rubble the pelvis drops and each leg bends so each foot lands where the ground is.
#include <array>
#include <functional>
#include <glm/glm.hpp>
#include "character/Character.h"

namespace px {

enum class HoldKind : std::uint8_t { None, OneHand, TwoHand, Melee };
enum class Mood : std::uint8_t { Calm, Happy, Angry, Scared, Sad, Talking, Count };
const char* moodLabel(Mood m);

// The little things people do while standing about.
enum class Fidget : std::uint8_t { None, LookAround, ShiftWeight, CrossArms, HandsOnHips, CheckWatch, Stretch, ScratchHead, Wave, Work, Count };
inline constexpr int kIdleFidgets = 7;      // LookAround .. ScratchHead happen on their own; Wave and Work are asked for
const char* fidgetLabel(Fidget f);

struct AnimInput {
    glm::vec3 position{ 0.0f };                 // the point between the feet (where the body stands), world
    glm::vec3 velocity{ 0.0f };
    bool grounded = true;
    glm::vec3 facing{ 0.0f, 0.0f, 1.0f };       // the way to face (the body turns towards it smoothly)
    bool hasLook = false;
    glm::vec3 lookAt{ 0.0f };                   // the head turns towards this, as far as a neck can
    float aimPitch = 0.0f;                      // degrees, up is positive: where the held item points
    HoldKind hold = HoldKind::None;
    // v0.19: personality. How this one moves, a number that makes their idle habits their own, and a mood on the face.
    MoveStyle style;
    std::uint32_t seed = 0;
    Mood mood = Mood::Calm;
    bool idleFidgets = true;                    // off for the player (who is being steered) and in tests
    // The ground height under a point, for foot IK. Empty: flat ground at position.y.
    std::function<bool(float x, float z, float& y)> ground;
};

struct AnimOutput {
    std::array<glm::mat4, kBoneCount> world{};  // every bone (rotation + joint position), world space
    glm::mat4 root{ 1.0f };                     // where the character stands and faces
    glm::mat4 item{ 1.0f };                     // where a held item's grip goes (its +z along the aim)
    glm::vec3 foot[2]{ glm::vec3(0.0f), glm::vec3(0.0f) };   // the ankles, left and right
    float pelvisDrop = 0.0f;                    // how far the pelvis was lowered to reach the lower foot
    bool blink = false;                         // the eyes are shut this frame
    int mouth = -1, brows = -1;                 // the face of the mood (-1: the character's own)
    Fidget fidget = Fidget::None;               // what they are doing while idle
    glm::vec3 sway{ 0.0f };                     // 1.6: how far loose things (hair ends, a skirt's hem) lag and swing, world metres
};

class CharacterAnimator {
public:
    bool footIK = true;

    void reset(float yawDegrees = 0.0f);
    const AnimOutput& update(const Skeleton& sk, const AnimInput& in, float dt);
    const AnimOutput& output() const { return out; }

    float yaw() const { return yawDeg; }       // which way the body faces (degrees, the objects' convention)
    float phase() const { return gait; }       // 0 .. 2 pi: where in the stride the legs are
    float moveAmount() const { return move; }  // 0 standing .. 1 walking
    float runAmount() const { return run; }    // 0 walking .. 1 running
    float airAmount() const { return air; }
    Fidget fidget() const { return fidgetShown; }
    void startFidget(Fidget f, float seconds = 3.0f);     // start one now (the Studio's "try it" buttons; tests)

private:
    AnimOutput out;
    float yawDeg = 0.0f, gait = 0.0f, move = 0.0f, run = 0.0f, air = 0.0f, land = 0.0f, time = 0.0f, prevVy = 0.0f;
    float drop = 0.0f;
    bool started = false;
    // personality
    float blinkTimer = 2.0f, blinkLeft = 0.0f, idleTime = 0.0f, fidgetTime = 0.0f, fidgetLength = 0.0f, fidgetBlend = 0.0f, talk = 0.0f;
    Fidget fidgetNow = Fidget::None, fidgetShown = Fidget::None;
    glm::vec3 swayPos{ 0.0f }, swayVel{ 0.0f }, swayPrevVel{ 0.0f };
    std::uint32_t rng = 1;
    float rand01();
};

// The world rotation for a bone whose own -y axis must point along `dir`, keeping its x axis as close to `xHint` as it can.
glm::quat boneAim(const glm::vec3& dir, const glm::vec3& xHint);

} // namespace px
