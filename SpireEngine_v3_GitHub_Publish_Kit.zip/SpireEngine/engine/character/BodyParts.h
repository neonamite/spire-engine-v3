#pragma once
// The built-in body parts (v0.18) and how a posed character becomes things to draw.
//
// A part is an ordinary asset (type Character part, tagged part:<slot>), so you can open one in the Workshop and make
// your own. Where it joins its bone is its socket named "joint" (without one: the top middle of the model, which is right
// for limbs that hang from their joint). The built-in parts are made for the standard 1.8 m body by the Workshop's own
// stamp code, the first time anything asks for them, and are stretched to each body's bones; they are white-ish so the
// character's colours tint them. Parts you make keep their own colours.
#include <string>
#include <vector>
#include "character/Animator.h"
#include "character/Character.h"
#include "render/Renderer.h"
#include "scene/Asset.h"

namespace px {

inline constexpr const char* kCharacterStandIn = "character stand-in";   // the invisible capsule a placed character is picked and bumped by

void registerBodyParts(AssetLibrary& lib);                     // the built-in parts and the stand-in (built when first used)
std::string builtinPartName(PartSlot s, HairStyle hair = HairStyle::Short);   // "body torso", "hair long"; "" for no hair
std::string partAssetFor(const CharacterDef& c, PartSlot s);   // the character's own choice, or the built-in part
std::vector<std::string> partsForSlot(const AssetLibrary& lib, PartSlot s);   // assets tagged part:<slot>, built-in first
glm::vec3 partJoint(const Asset& a, PartSlot s);              // where the part joins its bone, in the part's own space

// The colour a part is drawn with on this character (its role's, a tint:<role> tag's, or the part's own colour).
glm::vec3 partTint(const CharacterDef& c, PartSlot slot, const std::string& assetName, const Asset& a, const AssetLibrary& lib);

// Adds the character's parts, posed, to a draw list (and the held item when `item` is given).
// With skinning on (character/SkinnedBody.h) the trunk and limbs are one skinned body; `rigidOnly` forces separate parts
// (thumbnails, which are drawn on the CPU).
void characterDraws(const CharacterDef& c, const Skeleton& sk, const AnimOutput& pose, AssetLibrary& lib, std::vector<ObjectDraw>& out,
                    const glm::vec4& highlight = glm::vec4(0.0f), const AssetPtr& item = nullptr, bool rigidOnly = false);

} // namespace px
