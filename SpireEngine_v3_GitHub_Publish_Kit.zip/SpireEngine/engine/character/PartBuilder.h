#pragma once
// Internal to the character code: the little stamp-based builder the built-in body parts and the wardrobe are made with.
#include <algorithm>
#include <cmath>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "character/Character.h"
#include "scene/Asset.h"
#include "workshop/Workshop.h"

namespace px::partbuild {

using Sdf = std::function<float(const glm::vec3&)>;

inline float roundedBox(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
inline float ellipsoid(const glm::vec3& p, const glm::vec3& r) {
    const float k0 = glm::length(p / r), k1 = glm::length(p / (r * r));
    return k1 > 1e-6f ? k0 * (k0 - 1.0f) / k1 : -std::min(r.x, std::min(r.y, r.z));
}
inline float torusY(const glm::vec3& q, float R, float r) { return glm::length(glm::vec2(glm::length(glm::vec2(q.x, q.z)) - R, q.y)) - r; }
inline float capsule(const glm::vec3& p, const glm::vec3& a, const glm::vec3& b, float ra, float rb) {
    const glm::vec3 pa = p - a, ba = b - a;
    const float h = std::clamp(glm::dot(pa, ba) / glm::dot(ba, ba), 0.0f, 1.0f);
    return glm::length(pa - ba * h) - glm::mix(ra, rb, h);
}

// ---------------------------------------------------------------- shared anatomy (1.2)
// The built-in body is sculpted from overlapping, smoothly blended volumes the way a figure sculptor blocks one in:
// masses for the ribcage, belly and pelvis, muscles over them, then cloth or skin detail. The outfits in the wardrobe
// reuse these so a striped shirt has the same chest as the plain one.

constexpr MaterialId kSkinMat = MAT_SKIN, kHairMat = MAT_HAIR, kShoeMat = MAT_LEATHER, kSoleMat = MAT_PAINT_BLACK;

// Fine fabric folds: a few soft ridges running round a limb or across the body (amplitude in metres).
inline float folds(const glm::vec3& p, float amp, float freq, float seed) {
    return amp * (std::sin(p.y * freq + std::sin(p.x * 23.0f + seed) * 1.7f + p.z * 9.0f) * 0.6f +
                  std::sin(p.y * freq * 1.9f + p.x * 31.0f - seed) * 0.4f);
}

// Builds a part with the Workshop's own stamps, in a grid sized `metres` (the floor of the grid is y = 0).
struct PartBuilder {
    Workshop w;
    PartBuilder(const std::string& name, const glm::vec3& metres, float voxel = 0.0125f) {
        NewAssetSpec spec;
        spec.name = name;
        spec.voxelSize = voxel;
        spec.sizeMetres = metres;
        w.create(spec);
        w.beginStroke("Build part");
    }
    void add(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m, float blend = 0.0f) { w.stampSdf(f, lo - glm::vec3(0.03f), hi + glm::vec3(0.03f), StampMode::Add, m, blend); }
    void carve(const Sdf& f, glm::vec3 lo, glm::vec3 hi) { w.stampSdf(f, lo - glm::vec3(0.03f), hi + glm::vec3(0.03f), StampMode::Carve, MAT_STONE, 0.0f); }
    void paint(const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m) { w.stampSdf(f, lo - glm::vec3(0.03f), hi + glm::vec3(0.03f), StampMode::Paint, m, 0.0f); }
    void box(glm::vec3 c, glm::vec3 h, float r, MaterialId m, float blend = 0.0f) { add([=](const glm::vec3& p) { return roundedBox(p - c, h, r); }, c - h, c + h, m, blend); }
    void ball(glm::vec3 c, glm::vec3 r, MaterialId m, float blend = 0.0f) { add([=](const glm::vec3& p) { return ellipsoid(p - c, r); }, c - r, c + r, m, blend); }
    void limb(glm::vec3 a, glm::vec3 b, float ra, float rb, MaterialId m, float blend = 0.0f) {
        const float r = std::max(ra, rb);
        add([=](const glm::vec3& p) { return capsule(p, a, b, ra, rb); }, glm::min(a, b) - glm::vec3(r), glm::max(a, b) + glm::vec3(r), m, blend);
    }
    AssetPtr finish(PartSlot slot, const glm::vec3& joint, const char* extraTag = nullptr) {
        w.addSocket("joint", joint, glm::vec3(0, 1, 0));
        w.endStroke();
        w.remesh();
        auto a = std::make_shared<Asset>(w.asset);
        a->type = AssetType::CharacterPart;
        a->tags = { std::string("part:") + partSlotName(slot), "builtin body" };
        if (extraTag) a->tags.push_back(extraTag);
        a->userMade = false;
        return a;
    }
};



// ---- the torso (waist at y = 0, neck base at y = 0.42, chest toward +z)
inline void sculptTorso(PartBuilder& b, MaterialId m, bool shoulders = true, float wrinkle = 0.0025f) {
    // ribcage and belly, a gentle S of the spine (chest forward, small of the back hollow)
    b.add([=](const glm::vec3& p) {
              float d = ellipsoid(p - glm::vec3(0.0f, 0.285f, 0.005f), glm::vec3(0.158f, 0.155f, 0.098f));
              const float belly = ellipsoid(p - glm::vec3(0.0f, 0.115f, 0.0f), glm::vec3(0.13f, 0.125f, 0.077f));
              const float k = 0.06f;
              const float h = std::clamp(0.5f + 0.5f * (belly - d) / k, 0.0f, 1.0f);
              d = glm::mix(belly, d, h) - k * h * (1.0f - h);
              return d + folds(p, wrinkle, 70.0f, 1.3f) * std::clamp(0.3f - p.y, 0.0f, 0.3f) / 0.3f;   // creases round the waist
          }, { -0.2f, -0.03f, -0.12f }, { 0.2f, 0.45f, 0.12f }, m);
    for (float sx : { -1.0f, 1.0f }) {
        b.ball({ sx * 0.068f, 0.315f, 0.052f }, { 0.08f, 0.062f, 0.05f }, m, 0.035f);         // chest
        b.ball({ sx * 0.075f, 0.30f, -0.055f }, { 0.075f, 0.085f, 0.045f }, m, 0.035f);       // shoulder blades
        b.ball({ sx * 0.11f, 0.12f, 0.0f }, { 0.04f, 0.09f, 0.075f }, m, 0.04f);              // obliques: the waist's sides
    }
    if (shoulders)
        for (float sx : { -1.0f, 1.0f }) {
            b.limb({ 0.0f, 0.415f, -0.016f }, { sx * 0.15f, 0.378f, -0.008f }, 0.055f, 0.045f, m, 0.045f);   // trapezius: the slope of the shoulder
            b.ball({ sx * 0.168f, 0.355f, 0.0f }, { 0.062f, 0.07f, 0.066f }, m, 0.03f);                   // deltoid caps
        }
}

// A shirt's collar and a button placket (on top of sculptTorso).
inline void shirtDetails(PartBuilder& b, MaterialId m) {
    b.add([](const glm::vec3& p) {                                                      // a soft collar band round the neck
              const glm::vec3 q = p - glm::vec3(0.0f, 0.41f, -0.004f);
              return glm::length(glm::vec2(glm::length(glm::vec2(q.x, q.z * 1.12f)) - 0.062f, q.y * 1.4f)) - 0.012f;
          }, { -0.09f, 0.38f, -0.09f }, { 0.09f, 0.44f, 0.09f }, m, 0.006f);
    b.add([](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, 0.24f, 0.098f), glm::vec3(0.011f, 0.15f, 0.006f), 0.004f); },
          { -0.02f, 0.08f, 0.08f }, { 0.02f, 0.4f, 0.12f }, m, 0.004f);
    for (int i = 0; i < 5; ++i) {
        const float y = 0.12f + 0.065f * float(i);
        b.add([=](const glm::vec3& p) { return glm::length(p - glm::vec3(0.0f, y, 0.1f)) - 0.0048f; },
              { -0.01f, y - 0.01f, 0.09f }, { 0.01f, y + 0.01f, 0.115f }, MAT_MARBLE);
    }
}

// ---- arms (hang from their joint at the top; y up, the inside of the elbow toward +z)
inline void sculptUpperArm(PartBuilder& b, MaterialId m, bool sleeve) {
    b.limb({ 0.0f, 0.03f, 0.0f }, { 0.0f, 0.27f, 0.0f }, 0.041f, 0.05f, m);
    b.ball({ 0.0f, 0.15f, 0.014f }, { 0.04f, 0.075f, 0.036f }, m, 0.025f);                   // biceps
    b.ball({ 0.0f, 0.18f, -0.016f }, { 0.042f, 0.085f, 0.036f }, m, 0.025f);                 // triceps
    b.ball({ 0.0f, 0.275f, 0.0f }, { 0.056f, 0.05f, 0.058f }, m, 0.03f);
    if (sleeve) {
        b.add([](const glm::vec3& p) { return torusY(p - glm::vec3(0.0f, 0.045f, 0.0f), 0.043f, 0.008f); }, { -0.06f, 0.02f, -0.06f }, { 0.06f, 0.07f, 0.06f }, m, 0.006f);
        b.add([](const glm::vec3& p) {                                                          // creases inside the elbow
                  return capsule(p, glm::vec3(-0.03f, 0.075f, 0.036f), glm::vec3(0.03f, 0.085f, 0.04f), 0.006f, 0.004f);
              }, { -0.05f, 0.06f, 0.02f }, { 0.05f, 0.1f, 0.06f }, m, 0.008f);
    }
}
inline void sculptForearm(PartBuilder& b, MaterialId m) {
    // thick near the elbow (the muscle bellies), flattening into a wrist that is wider front to back than side to side
    b.add([](const glm::vec3& p) {
              const float t = std::clamp(p.y / 0.25f, 0.0f, 1.0f);
              const float rx = glm::mix(0.022f, 0.041f, t * t * (3.0f - 2.0f * t)), rz = glm::mix(0.03f, 0.043f, t);
              const float r = glm::length(glm::vec2(p.x / rx, p.z / rz));
              return std::max((r - 1.0f) * std::min(rx, rz), std::max(-0.012f - p.y, p.y - 0.255f));   // into the hand a little: no gap at the wrist
          }, { -0.05f, -0.02f, -0.05f }, { 0.05f, 0.27f, 0.05f }, m, 0.0f);
    b.ball({ 0.008f, 0.19f, 0.01f }, { 0.04f, 0.065f, 0.038f }, m, 0.02f);                  // brachioradialis
    b.ball({ 0.0f, 0.255f, -0.01f }, { 0.04f, 0.03f, 0.04f }, m, 0.02f);                     // the elbow
    b.ball({ 0.0f, 0.02f, -0.022f }, { 0.012f, 0.01f, 0.01f }, m, 0.006f);                   // the wrist bone
}
inline void sculptHand(PartBuilder& b, MaterialId m) {
    // the palm (thin in x), knuckles, four fingers relaxed and slightly apart, the thumb toward +z
    b.add([](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, 0.125f, 0.0f), glm::vec3(0.018f, 0.046f, 0.041f), 0.014f); }, { -0.03f, 0.07f, -0.05f }, { 0.03f, 0.18f, 0.05f }, m);
    b.limb({ 0.0f, 0.16f, 0.0f }, { 0.0f, 0.2f, 0.0f }, 0.02f, 0.021f, m, 0.012f);         // the wrist, up to (and a little past) the joint
    b.ball({ -0.006f, 0.135f, 0.026f }, { 0.016f, 0.03f, 0.018f }, m, 0.012f);               // the ball of the thumb
    b.ball({ -0.006f, 0.11f, -0.03f }, { 0.014f, 0.04f, 0.014f }, m, 0.01f);                 // the heel of the hand
    const float zs[4] = { 0.029f, 0.0095f, -0.0095f, -0.028f }, lens[4] = { 0.068f, 0.076f, 0.071f, 0.056f }, rad[4] = { 0.0095f, 0.0098f, 0.0092f, 0.008f };
    for (int i = 0; i < 4; ++i) {
        const glm::vec3 k(0.0f, 0.082f, zs[i]);
        const float spread = (float(i) - 1.5f) * 0.004f;
        const glm::vec3 j1 = k + glm::vec3(-0.004f, -lens[i] * 0.42f, spread);
        const glm::vec3 j2 = j1 + glm::vec3(-0.008f, -lens[i] * 0.31f, spread * 0.5f);
        const glm::vec3 tip = j2 + glm::vec3(-0.009f, -lens[i] * 0.25f, spread * 0.3f);
        b.limb(k, j1, rad[i], rad[i] * 0.95f, m, 0.006f);
        b.limb(j1, j2, rad[i] * 0.95f, rad[i] * 0.86f, m, 0.003f);
        b.limb(j2, tip, rad[i] * 0.86f, rad[i] * 0.75f, m, 0.003f);
        b.ball(k + glm::vec3(0.006f, 0.0f, 0.0f), glm::vec3(rad[i] * 1.05f), m, 0.006f);    // knuckle
    }
    const glm::vec3 t0(-0.004f, 0.14f, 0.032f), t1(-0.01f, 0.11f, 0.055f), t2(-0.014f, 0.082f, 0.066f);
    b.limb(t0, t1, 0.013f, 0.011f, m, 0.008f);
    b.limb(t1, t2, 0.011f, 0.0085f, m, 0.004f);
}

// ---- legs
inline void sculptThigh(PartBuilder& b, MaterialId m, float wrinkle = 0.002f) {
    b.add([=](const glm::vec3& p) { return capsule(p, glm::vec3(0.0f, 0.03f, 0.0f), glm::vec3(0.0f, 0.42f, 0.0f), 0.056f, 0.08f) + folds(p, wrinkle, 60.0f, 2.1f); },
          { -0.1f, -0.03f, -0.1f }, { 0.1f, 0.5f, 0.1f }, m);
    b.ball({ 0.008f, 0.24f, 0.022f }, { 0.062f, 0.14f, 0.058f }, m, 0.03f);                  // quadriceps
    b.ball({ 0.0f, 0.26f, -0.02f }, { 0.058f, 0.13f, 0.055f }, m, 0.03f);                    // hamstrings
    b.ball({ 0.0f, 0.42f, 0.0f }, { 0.085f, 0.05f, 0.085f }, m, 0.03f);
    b.ball({ 0.0f, 0.035f, 0.02f }, { 0.045f, 0.035f, 0.04f }, m, 0.02f);                    // the knee
}
inline void sculptShin(PartBuilder& b, MaterialId m, bool trouser) {
    b.limb({ 0.0f, -0.01f, 0.0f }, { 0.0f, 0.41f, 0.0f }, 0.036f, 0.05f, m);           // reaching a little into the shoe: no gap at the ankle
    b.ball({ 0.0f, 0.29f, -0.018f }, { 0.052f, 0.1f, 0.052f }, m, 0.03f);                    // calf
    b.ball({ 0.0f, 0.3f, 0.02f }, { 0.03f, 0.11f, 0.026f }, m, 0.02f);                       // shin
    b.ball({ 0.0f, 0.4f, 0.01f }, { 0.048f, 0.03f, 0.045f }, m, 0.02f);                      // below the knee
    if (trouser) {
        // trouser legs are looser: a straight fall over the calf, breaking softly over the shoe at the hem
        b.add([](const glm::vec3& p) {
                  const float r = glm::mix(0.052f, 0.058f, std::clamp(p.y / 0.4f, 0.0f, 1.0f));
                  return std::max(glm::length(glm::vec2(p.x, p.z * 1.08f)) - r + folds(p, 0.0018f, 55.0f, 0.7f), std::max(-p.y, p.y - 0.4f));
              }, { -0.07f, -0.01f, -0.07f }, { 0.07f, 0.41f, 0.07f }, m, 0.01f);
        b.add([](const glm::vec3& p) { return torusY(p - glm::vec3(0.0f, 0.012f, 0.004f), 0.052f, 0.01f); }, { -0.07f, -0.01f, -0.07f }, { 0.07f, 0.03f, 0.07f }, m, 0.008f);
    } else {
        for (float sx : { -1.0f, 1.0f }) b.ball({ sx * 0.03f, 0.03f, 0.0f }, { 0.012f, 0.014f, 0.014f }, m, 0.008f);   // ankle bones
    }
}
inline void sculptShoe(PartBuilder& b, MaterialId upper, float shaft) {
    // toe box, vamp, heel counter and an ankle collar (or a boot shaft), on a thicker rubber sole with a heel block
    b.ball({ 0.0f, 0.036f, 0.13f }, { 0.046f, 0.032f, 0.065f }, upper);
    b.ball({ 0.0f, 0.052f, 0.06f }, { 0.05f, 0.046f, 0.085f }, upper, 0.025f);
    b.ball({ 0.0f, 0.055f, -0.03f }, { 0.044f, 0.052f, 0.048f }, upper, 0.02f);
    b.limb({ 0.0f, 0.05f, 0.0f }, { 0.0f, 0.06f + shaft, 0.0f }, 0.044f, 0.042f + shaft * 0.03f, upper, 0.02f);
    if (shaft < 0.05f)
        b.carve([](const glm::vec3& p) { return capsule(p, glm::vec3(0.0f, 0.06f, 0.0f), glm::vec3(0.0f, 0.2f, 0.0f), 0.034f, 0.034f); }, { -0.04f, 0.06f, -0.04f }, { 0.04f, 0.2f, 0.04f });   // the opening
    b.add([](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, 0.009f, 0.055f), glm::vec3(0.052f, 0.011f, 0.132f), 0.008f); }, { -0.06f, -0.01f, -0.09f }, { 0.06f, 0.03f, 0.2f }, kSoleMat);
    b.add([](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, 0.015f, -0.03f), glm::vec3(0.046f, 0.016f, 0.044f), 0.006f); }, { -0.06f, -0.01f, -0.09f }, { 0.06f, 0.04f, 0.02f }, kSoleMat);
    if (shaft < 0.05f)
        for (int i = 0; i < 4; ++i) {                                                         // laces across the instep
            const float z = 0.03f + 0.022f * float(i), y = 0.094f - 0.012f * float(i);
            b.add([=](const glm::vec3& p) { return capsule(p, glm::vec3(-0.018f, y, z), glm::vec3(0.018f, y, z), 0.0035f, 0.0035f); },
                  { -0.025f, y - 0.008f, z - 0.008f }, { 0.025f, y + 0.008f, z + 0.008f }, MAT_SNOW);
        }
}


// ---- the head (head space: the top of the neck at the origin, the skull's middle 0.13 up, the face toward +z)
// The face styles keep their meaning but are sculpted: eyes are eyeballs in sockets under lids (the style sets how open
// the lids are), the mouth is a pair of lips whose corners turn up or down, noses have a bridge, a tip and nostrils.
inline void sculptHead(PartBuilder& b, const FaceStyle& f, bool shut) {
    const MaterialId m = kSkinMat;
    b.ball({ 0.0f, 0.148f, -0.012f }, { 0.087f, 0.104f, 0.098f }, m);                        // cranium
    b.ball({ 0.0f, 0.108f, 0.014f }, { 0.072f, 0.094f, 0.076f }, m, 0.03f);                  // the face's mass
    b.limb({ -0.042f, 0.163f, 0.083f }, { 0.042f, 0.163f, 0.083f }, 0.015f, 0.015f, m, 0.02f);   // brow ridge
    for (float sx : { -1.0f, 1.0f }) {
        b.ball({ sx * 0.052f, 0.117f, 0.068f }, { 0.026f, 0.02f, 0.024f }, m, 0.02f);          // cheekbones
        b.limb({ sx * 0.066f, 0.09f, -0.012f }, { sx * 0.032f, 0.036f, 0.058f }, 0.02f, 0.017f, m, 0.024f);   // the jaw line
        b.ball({ sx * 0.03f, 0.078f, 0.066f }, { 0.024f, 0.026f, 0.02f }, m, 0.02f);           // the cheeks round the mouth
    }
    b.ball({ 0.0f, 0.03f, 0.074f }, { 0.024f, 0.022f, 0.019f }, m, 0.016f);                  // chin
    b.ball({ 0.0f, 0.073f, 0.084f }, { 0.025f, 0.023f, 0.016f }, m, 0.014f);                 // the muzzle the lips sit on
    // ears: a flat shell with a rim, a bowl carved into it
    for (float sx : { -1.0f, 1.0f }) {
        b.add([=](const glm::vec3& p) {
                  const glm::vec3 q = p - glm::vec3(sx * 0.086f, 0.127f, -0.008f);
                  const float shell = ellipsoid(q, glm::vec3(0.012f, 0.029f, 0.019f));
                  const float rim = glm::length(glm::vec2(glm::length(glm::vec2(q.y / 1.5f, q.z)) - 0.016f, q.x - sx * 0.003f)) - 0.0045f;   // the helix
                  return std::min(shell, rim);
              }, { sx * 0.088f - 0.03f, 0.09f, -0.04f }, { sx * 0.088f + 0.03f, 0.17f, 0.03f }, m, 0.006f);
        b.carve([=](const glm::vec3& p) { return ellipsoid(p - glm::vec3(sx * 0.097f, 0.124f, -0.002f), glm::vec3(0.005f, 0.015f, 0.009f)); },
                { sx * 0.097f - 0.01f, 0.1f, -0.02f }, { sx * 0.097f + 0.01f, 0.15f, 0.02f });
    }
    // nose: the bridge from between the eyes, a tip, the wings either side, nostrils underneath
    const float scale = f.nose == 1 ? 1.2f : f.nose == 2 ? 1.0f : f.nose == 3 ? 0.8f : 0.95f;
    const float len = f.nose == 2 ? 1.25f : f.nose == 3 ? 0.8f : 1.0f;
    const float tipY = 0.142f - 0.046f * len, tipZ = 0.112f + 0.006f * scale;
    b.limb({ 0.0f, 0.143f, 0.094f }, { 0.0f, tipY + 0.008f, tipZ - 0.002f }, 0.0075f, 0.01f * scale, m, 0.012f);
    b.ball({ 0.0f, tipY, tipZ }, glm::vec3(0.0115f, 0.0105f, 0.0105f) * scale, m, 0.006f);
    for (float sx : { -1.0f, 1.0f }) {
        b.ball({ sx * 0.0125f * scale, tipY - 0.004f, tipZ - 0.01f }, glm::vec3(0.0085f, 0.0075f, 0.0085f) * scale, m, 0.005f);
        b.carve([=](const glm::vec3& p) { return ellipsoid(p - glm::vec3(sx * 0.0068f * scale, tipY - 0.0105f, tipZ - 0.005f), glm::vec3(0.0035f, 0.0022f, 0.0045f) * scale); },
                { sx * 0.007f - 0.008f, tipY - 0.02f, tipZ - 0.015f }, { sx * 0.007f + 0.008f, tipY, tipZ + 0.01f });
    }
    // eyes
    const float eyeY = 0.138f, eyeZ = 0.0795f;
    float upper = 0.0062f, lower = -0.0078f;                                                  // where the lids open to, around the eye's centre
    switch (f.eyes) {
    case 1: upper = 0.0085f; lower = -0.0088f; break;                                        // round
    case 2: upper = 0.003f; lower = -0.005f; break;                                           // narrow
    case 3: upper = 0.0012f; break;                                                           // sleepy
    case 4: upper = 0.0108f; lower = -0.0095f; break;                                        // wide
    default: break;
    }
    if (shut) { upper = -0.0035f; lower = -0.0036f; }
    for (float sx : { -1.0f, 1.0f }) {
        const glm::vec3 c(sx * 0.033f, eyeY, eyeZ);
        b.carve([=](const glm::vec3& p) { return ellipsoid(p - c - glm::vec3(0.0f, 0.0f, 0.015f), glm::vec3(0.0165f, 0.0105f, 0.007f)); }, c - glm::vec3(0.025f), c + glm::vec3(0.025f));   // the socket
        b.add([=](const glm::vec3& p) { return glm::length(p - c) - 0.0125f; }, c - glm::vec3(0.015f), c + glm::vec3(0.015f), MAT_MARBLE);   // the eyeball (marble: white, with faint veins)
        b.paint([=](const glm::vec3& p) {                                                     // the iris: a brown disc on the front
                    const glm::vec3 q = p - c;
                    return std::max(glm::length(glm::vec2(q.x, q.y)) - 0.0056f, 0.0085f - q.z);
                }, c - glm::vec3(0.012f), c + glm::vec3(0.016f), MAT_MUD);
        b.paint([=](const glm::vec3& p) {                                                     // the pupil
                    const glm::vec3 q = p - c;
                    return std::max(glm::length(glm::vec2(q.x, q.y)) - 0.0024f, 0.0105f - q.z);
                }, c - glm::vec3(0.012f), c + glm::vec3(0.016f), MAT_PAINT_BLACK);
        // lids: shells round the eyeball, kept above / below where they open
        const float up = upper, lo = lower;
        b.add([=](const glm::vec3& p) {
                  const glm::vec3 q = p - c;
                  const float shell = std::fabs(glm::length(q) - 0.0137f) - 0.0016f;
                  return std::max(std::max(shell, up - 15.0f * q.x * q.x - q.y), -0.004f - q.z);   // the lid's edge arches over the eye
              }, c - glm::vec3(0.02f), c + glm::vec3(0.02f), m, 0.002f);
        b.add([=](const glm::vec3& p) {
                  const glm::vec3 q = p - c;
                  const float shell = std::fabs(glm::length(q) - 0.0136f) - 0.0014f;
                  return std::max(std::max(shell, q.y - lo), -0.002f - q.z);
              }, c - glm::vec3(0.02f), c + glm::vec3(0.02f), m, 0.002f);
        // brows: a slightly raised band of short hair along the brow ridge
        if (f.brows != 0) {
            float innerDy = 0.0f, thick = 0.0032f;
            if (f.brows == 2) innerDy = -0.0065f;                                                 // angry: down toward the middle
            if (f.brows == 3) innerDy = 0.0065f;                                                  // worried: up toward the middle
            if (f.brows == 4) thick = 0.0048f;                                                    // bushy
            const glm::vec3 inner(sx * 0.014f, 0.162f + innerDy, 0.099f), outer(sx * 0.054f, 0.159f, 0.087f);   // just proud of the brow ridge
            const glm::vec3 mid = (inner + outer) * 0.5f + glm::vec3(0.0f, 0.004f, 0.004f);
            b.add([=](const glm::vec3& p) { return std::min(capsule(p, inner, mid, thick, thick * 0.95f), capsule(p, mid, outer, thick * 0.95f, thick * 0.55f)); },
                  glm::min(inner, outer) - glm::vec3(0.012f), glm::max(inner, outer) + glm::vec3(0.012f), kHairMat, 0.002f);   // the person's own hair colour
        }
    }
    // lips: an upper and a lower lip; the corners turn up (smile, grin) or down (frown); a grin parts them over teeth
    const float curve = (f.mouth == 1 || f.mouth == 3) ? 0.0045f : f.mouth == 4 ? -0.0045f : 0.0f;
    const float thin = f.mouth == 2 ? 0.65f : 1.0f;
    const float my = 0.068f, mz = 0.096f;
    auto lipShape = [=](const glm::vec3& p, float y0, float ry, float rz, float zOff) {
        const float t = p.x / 0.024f;
        const float bend = curve * t * t;
        return ellipsoid(glm::vec3(p.x, p.y - (y0 + bend), p.z - (mz + zOff - 0.012f * t * t)), glm::vec3(0.0235f, ry, rz));
    };
    b.add([=](const glm::vec3& p) { return lipShape(p, my + 0.0055f * thin, 0.0058f * thin, 0.0085f, 0.0f); }, { -0.03f, my - 0.01f, mz - 0.02f }, { 0.03f, my + 0.02f, mz + 0.02f }, m, 0.004f);
    b.add([=](const glm::vec3& p) { return lipShape(p, my - 0.0065f * thin, 0.0068f * thin, 0.0088f, -0.001f); }, { -0.03f, my - 0.02f, mz - 0.02f }, { 0.03f, my + 0.01f, mz + 0.02f }, m, 0.004f);
    if (f.mouth == 3) {
        b.carve([=](const glm::vec3& p) { const float t = p.x / 0.02f; return ellipsoid(glm::vec3(p.x, p.y - (my + curve * t * t - 0.001f), p.z - mz), glm::vec3(0.02f, 0.0055f, 0.02f)); },
                { -0.03f, my - 0.01f, mz - 0.03f }, { 0.03f, my + 0.015f, mz + 0.02f });
        b.add([=](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, my + 0.0015f, mz - 0.012f), glm::vec3(0.016f, 0.0035f, 0.006f), 0.003f); },
              { -0.02f, my - 0.005f, mz - 0.02f }, { 0.02f, my + 0.008f, mz }, MAT_MARBLE);
    } else {
        b.carve([=](const glm::vec3& p) {                                                    // the line where the lips meet: a shallow slot
                    const float t = p.x / 0.024f;
                    return std::max(std::max(std::fabs(p.y - (my - 0.0004f + curve * t * t)) - 0.0011f, std::fabs(p.x) - 0.021f), mz + 0.002f - p.z);
                }, { -0.026f, my - 0.01f, mz - 0.02f }, { 0.026f, my + 0.01f, mz + 0.03f });
    }
    // the groove from the nose to the lip
    b.carve([=](const glm::vec3& p) { return capsule(p, glm::vec3(0.0f, tipY - 0.014f, tipZ - 0.008f), glm::vec3(0.0f, my + 0.012f, mz + 0.005f), 0.0022f, 0.003f); },
            { -0.01f, my, mz - 0.01f }, { 0.01f, tipY, tipZ + 0.01f });
}


// ---- hair (head space as above, built `up` metres higher so long hair can hang below the head's joint)
// A cap of hair just outside the skull, combed: shallow grooves fan out from the crown, with a slight wave.
inline void hairShell(PartBuilder& b, float up, float thick) {
    b.add([=](const glm::vec3& p) {
              const glm::vec3 q = p - glm::vec3(0.0f, 0.148f + up, -0.01f);
              const float az = std::atan2(q.x, q.z + 0.03f);
              const float combed = 0.0022f * std::sin(az * 44.0f + q.y * 60.0f) + 0.0014f * std::sin(az * 97.0f - q.y * 90.0f);
              return ellipsoid(q, glm::vec3(0.097f + thick, 0.116f + thick, 0.108f + thick)) + combed;
          }, { -0.13f, up, -0.14f }, { 0.13f, up + 0.3f, 0.13f }, kHairMat);
}
// Clears the face, the ears and the neck, leaving a natural hairline with a slight widow's peak and sideburns.
inline void hairline(PartBuilder& b, float up) {
    b.carve([=](const glm::vec3& p) {
                const glm::vec3 q = p - glm::vec3(0.0f, up, 0.0f);
                const float line = 0.19f - 0.012f * std::exp(-q.x * q.x / 0.0004f) - 0.03f * std::pow(std::fabs(q.x) / 0.1f, 2.0f);   // higher at the temples
                const float front = 0.02f + 0.9f * std::max(0.0f, std::fabs(q.x) - 0.045f);           // the hairline runs back at the temples
                return std::max(q.y - line, front - q.z);
            }, { -0.14f, up - 0.03f, -0.02f }, { 0.14f, up + 0.22f, 0.18f });
    b.carve([=](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, up + 0.06f, 0.1f), glm::vec3(0.115f, 0.06f, 0.055f), 0.01f); },   // sideburns stop at the cheekbone
            { -0.13f, up - 0.01f, 0.03f }, { 0.13f, up + 0.13f, 0.17f });
    for (float sx : { -1.0f, 1.0f })                                                           // round the ears, above the sideburns
        b.carve([=](const glm::vec3& p) { return ellipsoid(p - glm::vec3(sx * 0.1f, up + 0.118f, -0.006f), glm::vec3(0.03f, 0.036f, 0.032f)); },
                { sx * 0.1f - 0.04f, up + 0.07f, -0.05f }, { sx * 0.1f + 0.04f, up + 0.17f, 0.04f });
    b.carve([=](const glm::vec3& p) { return roundedBox(p - glm::vec3(0.0f, up, 0.0f), glm::vec3(0.14f, 0.065f, 0.14f), 0.0f); },
            { -0.15f, up - 0.07f, -0.15f }, { 0.15f, up + 0.07f, 0.15f });
}

} // namespace px::partbuild
