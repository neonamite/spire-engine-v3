#pragma once
// The wardrobe (v0.19): every built-in choice for a character's look beyond the basic body. Outfits (shirts, stripes,
// jackets, armour, coats, vests, bare arms, shorts, skirts, robes, boots), hats, glasses, beards, things on the back,
// more hair, and faces (eyes, brows, nose and mouth, built into the head, with a blinking version of each).
// They are ordinary generated assets like the built-in body parts: made the first time they are worn, tagged
// part:<slot>, and tinted by the character's colours (a tint:<role> tag picks which colour; paint, glass and gold keep
// their own).
#include <string>
#include <vector>
#include "character/Character.h"
#include "scene/Asset.h"

namespace px {

struct WardrobeItem {
    const char* asset;          // the asset name ("hat cowboy")
    PartSlot    slot;
    const char* label;          // what the Studio calls it ("Cowboy hat")
    const char* tint;           // the colour role it takes ("accent"), or nullptr for the slot's own
};

const std::vector<WardrobeItem>& wardrobe();                      // every item, by slot, the default of each slot first
std::vector<const WardrobeItem*> wardrobeFor(PartSlot s);
const WardrobeItem* wardrobeItem(const std::string& asset);       // nullptr when it is not a wardrobe item

// The head with a face: "head e1 b1 n0 m1", and the same with its eyes shut ("... shut") for blinking.
std::string faceHeadName(const FaceStyle& f, bool shut = false);
bool parseFaceHeadName(const std::string& name, FaceStyle& f, bool& shut);

void registerWardrobe(AssetLibrary& lib);                        // called by registerBodyParts

} // namespace px
