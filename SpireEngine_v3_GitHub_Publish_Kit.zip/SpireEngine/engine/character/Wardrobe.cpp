#include "character/Wardrobe.h"
#include <cstdio>
#include <glm/gtc/quaternion.hpp>
#include "character/PartBuilder.h"

namespace px {

using namespace partbuild;

namespace {

constexpr MaterialId kCloth = MAT_CLOTH, kTint = MAT_PLASTER;

// A ring round the z axis (glasses frames).
float ringZ(const glm::vec3& p, const glm::vec3& c, float R, float r) {
    const glm::vec3 q = p - c;
    return glm::length(glm::vec2(glm::length(glm::vec2(q.x, q.y)) - R, q.z)) - r;
}

// ---------------------------------------------------------------- the head and its face

// Head space: the joint (top of the neck) at the origin; the skull's middle 0.13 up; the face looks along +z.
AssetPtr makeFaceHead(const std::string& name, const FaceStyle& f, bool shut) {
    PartBuilder b(name, { 0.28f, 0.30f, 0.30f }, 0.004f);
    sculptHead(b, f, shut);
    return b.finish(PartSlot::Head, { 0.0f, 0.0f, 0.0f });
}

// ---------------------------------------------------------------- outfits

void torsoBody(PartBuilder& b, MaterialId m, bool shoulders = true) { sculptTorso(b, m, shoulders); }

AssetPtr makeTorsoStriped() {
    PartBuilder b("torso striped", { 0.52f, 0.50f, 0.30f }, 0.007f);
    torsoBody(b, kCloth);
    shirtDetails(b, kCloth);
    for (float y = 0.05f; y < 0.42f; y += 0.075f)
        b.paint([=](const glm::vec3& p) { return std::fabs(p.y - y) - 0.014f; }, { -0.25f, y - 0.02f, -0.15f }, { 0.25f, y + 0.02f, 0.15f }, MAT_PAINT_BLACK);
    return b.finish(PartSlot::Torso, { 0.0f, 0.0f, 0.0f });
}

AssetPtr makeTorsoJacket() {
    PartBuilder b("torso jacket", { 0.52f, 0.50f, 0.30f }, 0.007f);
    torsoBody(b, kCloth);
    b.box({ 0.0f, 0.03f, 0.0f }, { 0.15f, 0.03f, 0.097f }, 0.02f, kCloth, 0.01f);           // hem
    // the shirt in the V of the jacket, and a tie down it
    b.paint([](const glm::vec3& p) { return std::max(std::fabs(p.x) - (p.y - 0.2f) * 0.42f, std::max(0.205f - p.y, p.y - 0.44f)); }, { -0.1f, 0.2f, 0.0f }, { 0.1f, 0.44f, 0.15f }, MAT_SNOW);
    b.paint([](const glm::vec3& p) { return std::max(std::fabs(p.x) - 0.012f, std::max(0.17f - p.y, p.y - 0.42f)); }, { -0.03f, 0.17f, 0.0f }, { 0.03f, 0.42f, 0.15f }, MAT_PAINT_BLACK);
    return b.finish(PartSlot::Torso, { 0.0f, 0.0f, 0.0f });
}

AssetPtr makeTorsoArmour() {
    PartBuilder b("torso armour", { 0.60f, 0.54f, 0.34f }, 0.008f);
    torsoBody(b, kCloth);
    b.box({ 0.0f, 0.295f, 0.008f }, { 0.182f, 0.125f, 0.108f }, 0.05f, MAT_METAL);          // breastplate
    for (float y : { 0.075f, 0.14f }) b.box({ 0.0f, y, 0.004f }, { 0.15f, 0.026f, 0.096f }, 0.015f, MAT_METAL);   // belly bands
    b.ball({ 0.175f, 0.385f, 0.0f }, { 0.082f, 0.05f, 0.082f }, MAT_METAL);                // pauldrons
    b.ball({ -0.175f, 0.385f, 0.0f }, { 0.082f, 0.05f, 0.082f }, MAT_METAL);
    return b.finish(PartSlot::Torso, { 0.0f, 0.0f, 0.0f });
}

// A long coat: the torso plus tails to mid-thigh. Built 0.4 m up so the tails can hang below the waist.
AssetPtr makeTorsoCoat() {
    const float up = 0.4f;
    PartBuilder b("torso coat", { 0.56f, 0.92f, 0.32f });
    auto at = [&](float x, float y, float z) { return glm::vec3(x, y + up, z); };
    b.box(at(0.0f, 0.12f, 0.0f), { 0.15f, 0.12f, 0.096f }, 0.06f, kCloth);
    b.box(at(0.0f, 0.30f, 0.0f), { 0.185f, 0.12f, 0.108f }, 0.07f, kCloth, 0.06f);
    b.ball(at(0.16f, 0.37f, 0.0f), { 0.072f, 0.062f, 0.072f }, kCloth, 0.04f);
    b.ball(at(-0.16f, 0.37f, 0.0f), { 0.072f, 0.062f, 0.072f }, kCloth, 0.04f);
    b.add([&](const glm::vec3& p) {                                                         // the tails flare out a little as they go down
        const glm::vec3 q = p - at(0.0f, -0.17f, 0.0f);
        const float grow = std::clamp((-q.y + 0.18f) / 0.36f, 0.0f, 1.0f) * 0.03f;
        return roundedBox(q, glm::vec3(0.17f + grow, 0.18f, 0.115f + grow), 0.03f);
    }, at(-0.22f, -0.37f, -0.16f), at(0.22f, 0.03f, 0.16f), kCloth, 0.03f);
    b.carve([&](const glm::vec3& p) { return roundedBox(p - at(0.0f, -0.2f, 0.12f), glm::vec3(0.012f, 0.17f, 0.04f), 0.0f); }, at(-0.03f, -0.4f, 0.06f), at(0.03f, 0.0f, 0.18f));   // the split at the front
    for (float y : { 0.05f, 0.13f, 0.21f, 0.29f })                                          // buttons
        b.paint([&, y](const glm::vec3& p) { return glm::length(p - at(0.03f, y, 0.1f)) - 0.012f; }, at(0.0f, y - 0.02f, 0.06f), at(0.06f, y + 0.02f, 0.14f), MAT_PAINT_BLACK);
    return b.finish(PartSlot::Torso, at(0.0f, 0.0f, 0.0f));
}

AssetPtr makeTorsoVest() {
    PartBuilder b("torso vest", { 0.52f, 0.50f, 0.30f }, 0.007f);
    torsoBody(b, kCloth, false);
    return b.finish(PartSlot::Torso, { 0.0f, 0.0f, 0.0f });
}

AssetPtr makeUpperArmBare() {
    PartBuilder b("upper arm bare", { 0.18f, 0.34f, 0.18f }, 0.007f);
    sculptUpperArm(b, kSkinMat, false);
    return b.finish(PartSlot::UpperArm, { 0.0f, 0.29f, 0.0f }, "tint:skin");
}

AssetPtr makeLowerLegBare() {
    PartBuilder b("lower leg bare", { 0.18f, 0.48f, 0.20f }, 0.008f);
    sculptShin(b, kSkinMat, false);
    return b.finish(PartSlot::LowerLeg, { 0.0f, 0.42f, 0.0f }, "tint:skin");
}

// Skirts and robes hang from the hips: built up so they can reach the knees or the ankles.
AssetPtr makeHipsSkirt(const char* name, float length, float flare) {
    const float up = length + 0.05f;
    PartBuilder b(name, { 0.62f, length + 0.32f, 0.62f });
    auto at = [&](float x, float y, float z) { return glm::vec3(x, y + up, z); };
    b.box(at(0.0f, 0.10f, 0.0f), { 0.155f, 0.085f, 0.10f }, 0.05f, kCloth);
    b.add([&](const glm::vec3& p) {
        const glm::vec3 q = p - at(0.0f, 0.0f, 0.0f);
        const float t = std::clamp((0.15f - q.y) / (length + 0.15f), 0.0f, 1.0f);   // 0 at the waist, 1 at the hem
        const float rx = 0.16f + flare * t, rz = 0.105f + flare * 0.8f * t;
        const float side = glm::length(glm::vec2(q.x / rx, q.z / rz)) - 1.0f;
        return std::max(side * std::min(rx, rz), std::max(q.y - 0.15f, -length - q.y));
    }, at(-0.2f - flare, -length, -0.2f - flare), at(0.2f + flare, 0.15f, 0.2f + flare), kCloth, 0.02f);
    return b.finish(PartSlot::Hips, at(0.0f, 0.075f, 0.0f));
}

AssetPtr makeBoot() {
    PartBuilder b("foot boot", { 0.16f, 0.30f, 0.34f }, 0.005f);
    sculptShoe(b, kShoeMat, 0.14f);
    b.add([](const glm::vec3& p) { return torusY(p - glm::vec3(0.0f, 0.205f, 0.0f), 0.046f, 0.007f); }, { -0.06f, 0.19f, -0.06f }, { 0.06f, 0.22f, 0.06f }, kShoeMat, 0.004f);   // a rolled top
    return b.finish(PartSlot::Foot, { 0.0f, 0.085f, 0.0f });
}

// ---------------------------------------------------------------- hair (more styles)

// Hair space as in BodyParts: the head joint 0.12 up.
void hairCap(PartBuilder& b, float up, float thick = 0.0f) { hairShell(b, up, thick); }
void hairClearFace(PartBuilder& b, float up) { hairline(b, up); }

AssetPtr makeHairExtra(HairStyle style) {
    const float up = 0.12f;
    PartBuilder b(std::string("hair ") + hairStyleName(style), { 0.32f, 0.46f, 0.34f }, 0.006f);
    switch (style) {
    case HairStyle::Ponytail:
        hairCap(b, up);
        hairClearFace(b, up);
        b.ball({ 0.0f, 0.19f + up, -0.115f }, { 0.03f, 0.03f, 0.03f }, kHairMat, 0.01f);
        b.limb({ 0.0f, 0.18f + up, -0.13f }, { 0.0f, 0.02f + up, -0.15f }, 0.03f, 0.018f, kHairMat, 0.01f);
        break;
    case HairStyle::Curly:
        hairCap(b, up, 0.006f);
        for (int i = 0; i < 26; ++i) {                                                     // curls all over
            const float a = float(i) * 2.399963f, h = 0.06f + 0.19f * float(i % 9) / 8.0f;
            const glm::vec3 c(std::cos(a) * 0.1f * std::sqrt(1.0f - std::pow((h - 0.14f) / 0.15f, 2.0f) * 0.5f), h + up, std::sin(a) * 0.11f - 0.01f);
            b.ball(c, glm::vec3(0.028f), kHairMat, 0.01f);
        }
        hairClearFace(b, up);
        break;
    case HairStyle::Mohawk:
        b.ball({ 0.0f, 0.14f + up, -0.008f }, { 0.097f, 0.121f, 0.107f }, kHairMat);           // shaved sides: a thin layer
        b.box({ 0.0f, 0.25f + up, -0.01f }, { 0.018f, 0.05f, 0.11f }, 0.015f, kHairMat, 0.02f);   // the crest
        hairClearFace(b, up);
        break;
    default: break;
    }
    return b.finish(PartSlot::Hair, { 0.0f, up, 0.0f });
}

// ---------------------------------------------------------------- hats, glasses, beards (head space, built 0.12 up)

constexpr float kUp = 0.12f;
glm::vec3 H(float x, float y, float z) { return glm::vec3(x, y + kUp, z); }

AssetPtr makeHat(const std::string& kind) {
    PartBuilder b("hat " + kind, { 0.44f, 0.60f, 0.44f }, 0.008f);
    const MaterialId kTint = kind == "helmet" ? MaterialId(MAT_METAL) : kind == "cowboy" ? MaterialId(MAT_LEATHER) : MaterialId(MAT_CLOTH);
    // The hair is an egg about (0, 0.14, -0.008) with radii (0.104, 0.128, 0.114): hats are shells just outside it, cut
    // off below a plane that is higher at the front (over the brows) than at the back.
    auto cutBelow = [&](float front, float back) {
        b.carve([=](const glm::vec3& p) { const float z = std::clamp((p.z + 0.13f) / 0.26f, 0.0f, 1.0f); return p.y - H(0, back + (front - back) * z, 0).y; },
                H(-0.2f, -0.05f, -0.2f), H(0.2f, std::max(front, back), 0.2f));
    };
    if (kind == "cap") {
        b.ball(H(0.0f, 0.145f, -0.008f), { 0.114f, 0.136f, 0.124f }, kTint);
        cutBelow(0.19f, 0.13f);
        b.add([](const glm::vec3& p) {                                                      // the peak, sloping down a little
            const glm::vec3 q = p - H(0.0f, 0.186f, 0.15f);
            return roundedBox(glm::vec3(q.x, q.y + q.z * 0.25f, q.z), glm::vec3(0.075f, 0.005f, 0.055f), 0.004f);
        }, H(-0.08f, 0.16f, 0.09f), H(0.08f, 0.21f, 0.21f), kTint);
    } else if (kind == "beanie") {
        b.ball(H(0.0f, 0.15f, -0.008f), { 0.118f, 0.142f, 0.128f }, kTint);
        cutBelow(0.18f, 0.1f);
        b.add([](const glm::vec3& p) {                                                      // the turned-up rim
            const glm::vec3 q = p - H(0.0f, 0.15f, -0.008f);
            const float z = std::clamp((p.z + 0.13f) / 0.26f, 0.0f, 1.0f);
            const float base = H(0, 0.1f + 0.08f * z, 0).y;
            return std::max(ellipsoid(q, glm::vec3(0.124f, 0.148f, 0.134f)), std::fabs(p.y - base - 0.016f) - 0.016f);
        }, H(-0.13f, 0.08f, -0.15f), H(0.13f, 0.22f, 0.15f), kTint);
        b.ball(H(0.0f, 0.3f, -0.01f), glm::vec3(0.03f), kTint, 0.01f);
    } else if (kind == "top hat") {
        b.limb(H(0.0f, 0.25f, -0.005f), H(0.0f, 0.46f, -0.005f), 0.086f, 0.086f, kTint);
        b.carve([](const glm::vec3& p) { return H(0, 0.43f, 0).y - p.y; }, H(-0.1f, 0.43f, -0.1f), H(0.1f, 0.56f, 0.1f));   // a flat top
        b.limb(H(0.0f, 0.245f, -0.005f), H(0.0f, 0.255f, -0.005f), 0.145f, 0.145f, kTint);
        b.paint([](const glm::vec3& p) { return std::fabs(p.y - H(0, 0.278f, 0).y) - 0.014f; }, H(-0.1f, 0.26f, -0.1f), H(0.1f, 0.3f, 0.1f), MAT_PAINT_BLACK);
    } else if (kind == "helmet") {
        b.ball(H(0.0f, 0.15f, -0.004f), { 0.124f, 0.146f, 0.136f }, kTint);
        cutBelow(0.19f, 0.09f);
        b.add([](const glm::vec3& p) {                                                      // a rim that sticks out a little
            const glm::vec3 q = p - H(0.0f, 0.15f, -0.004f);
            const float z = std::clamp((p.z + 0.13f) / 0.26f, 0.0f, 1.0f);
            const float base = H(0, 0.09f + 0.1f * z, 0).y;
            return std::max(ellipsoid(q, glm::vec3(0.136f, 0.158f, 0.148f)), std::fabs(p.y - base - 0.008f) - 0.008f);
        }, H(-0.15f, 0.07f, -0.16f), H(0.15f, 0.22f, 0.16f), kTint);
        b.box(H(0.0f, 0.29f, -0.01f), { 0.014f, 0.012f, 0.1f }, 0.008f, kTint, 0.01f);     // a ridge
    } else if (kind == "cowboy") {
        b.ball(H(0.0f, 0.255f, -0.005f), { 0.098f, 0.08f, 0.108f }, kTint);
        b.carve([](const glm::vec3& p) { return p.y - H(0, 0.218f, 0).y; }, H(-0.12f, 0.15f, -0.13f), H(0.12f, 0.218f, 0.13f));
        b.add([](const glm::vec3& p) {                                                      // the brim, turned up at the sides
            const glm::vec3 q = p - H(0.0f, 0.222f, -0.005f);
            const float curl = 0.8f * q.x * q.x;
            return ellipsoid(glm::vec3(q.x, q.y - curl, q.z), glm::vec3(0.2f, 0.014f, 0.18f));
        }, H(-0.21f, 0.2f, -0.19f), H(0.21f, 0.28f, 0.18f), kTint);
        b.paint([](const glm::vec3& p) { return std::fabs(p.y - H(0, 0.252f, 0).y) - 0.009f; }, H(-0.11f, 0.243f, -0.12f), H(0.11f, 0.262f, 0.11f), MAT_PAINT_BLACK);
    } else if (kind == "hood") {
        b.ball(H(0.0f, 0.14f, -0.02f), { 0.134f, 0.158f, 0.144f }, kCloth);
        b.carve([](const glm::vec3& p) { return ellipsoid(p - H(0.0f, 0.14f, -0.008f), glm::vec3(0.112f, 0.136f, 0.122f)); }, H(-0.12f, 0.0f, -0.14f), H(0.12f, 0.28f, 0.12f));
        b.carve([](const glm::vec3& p) { return roundedBox(p - H(0.0f, 0.11f, 0.13f), glm::vec3(0.085f, 0.105f, 0.07f), 0.04f); }, H(-0.09f, 0.0f, 0.05f), H(0.09f, 0.22f, 0.2f));
        b.carve([](const glm::vec3& p) { return p.y - H(0, 0.0f, 0).y; }, H(-0.15f, -0.1f, -0.17f), H(0.15f, 0.0f, 0.17f));
    } else if (kind == "crown") {
        b.limb(H(0.0f, 0.21f, 0.0f), H(0.0f, 0.26f, 0.0f), 0.088f, 0.09f, MAT_GOLD);
        b.carve([](const glm::vec3& p) { return capsule(p, H(0.0f, 0.2f, 0.0f), H(0.0f, 0.28f, 0.0f), 0.074f, 0.074f); }, H(-0.08f, 0.19f, -0.08f), H(0.08f, 0.29f, 0.08f));
        for (int i = 0; i < 6; ++i) {
            const float a = float(i) * 1.0472f;
            const glm::vec3 base = H(std::sin(a) * 0.085f, 0.255f, std::cos(a) * 0.085f);
            b.limb(base, base + glm::vec3(0.0f, 0.05f, 0.0f), 0.018f, 0.004f, MAT_GOLD);
        }
        b.paint([](const glm::vec3& p) { return glm::length(p - H(0.0f, 0.235f, 0.09f)) - 0.015f; }, H(-0.02f, 0.21f, 0.06f), H(0.02f, 0.26f, 0.12f), MAT_PAINT_RED);
    }
    AssetPtr a = b.finish(PartSlot::Hat, H(0.0f, 0.0f, 0.0f), kind == "crown" ? nullptr : "tint:accent");
    if (kind != "crown") a->tags.push_back("covers:hair");                 // big hair is tucked in under it
    return a;
}

AssetPtr makeGlasses(const std::string& kind) {
    PartBuilder b("glasses " + kind, { 0.30f, 0.30f, 0.30f }, 0.01f);
    if (kind == "round") {
        for (float s : { 1.0f, -1.0f }) {
            const glm::vec3 c = H(0.034f * s, 0.14f, 0.118f);
            b.add([=](const glm::vec3& p) { return ringZ(p, c, 0.021f, 0.0045f); }, c - glm::vec3(0.03f), c + glm::vec3(0.03f), kTint);
            b.add([=](const glm::vec3& p) { return std::max(glm::length(glm::vec2(p.x - c.x, p.y - c.y)) - 0.018f, std::fabs(p.z - c.z) - 0.002f); }, c - glm::vec3(0.02f), c + glm::vec3(0.02f), MAT_ICE);
            b.box(H(0.075f * s, 0.145f, 0.06f), { 0.004f, 0.004f, 0.055f }, 0.0f, kTint);  // arms to the ears
        }
        b.box(H(0.0f, 0.146f, 0.118f), { 0.014f, 0.004f, 0.004f }, 0.0f, kTint);          // bridge
    } else if (kind == "shades") {
        for (float s : { 1.0f, -1.0f }) {
            b.box(H(0.036f * s, 0.14f, 0.116f), { 0.027f, 0.017f, 0.006f }, 0.008f, MAT_PAINT_BLACK);
            b.box(H(0.078f * s, 0.147f, 0.06f), { 0.004f, 0.005f, 0.055f }, 0.0f, MAT_PAINT_BLACK);
        }
        b.box(H(0.0f, 0.148f, 0.116f), { 0.014f, 0.004f, 0.005f }, 0.0f, MAT_PAINT_BLACK);
    } else if (kind == "visor") {
        b.add([](const glm::vec3& p) {                                                      // a curved band of glowing glass
            const glm::vec3 q = p - H(0.0f, 0.14f, 0.0f);
            const float shell = std::fabs(ellipsoid(q, glm::vec3(0.108f, 0.13f, 0.12f))) - 0.006f;
            return std::max(shell, std::max(std::fabs(q.y) - 0.02f, 0.02f - q.z));
        }, H(-0.12f, 0.11f, 0.0f), H(0.12f, 0.17f, 0.13f), MAT_CRYSTAL);
    } else if (kind == "goggles") {
        for (float s : { 1.0f, -1.0f }) {
            const glm::vec3 c = H(0.036f * s, 0.142f, 0.112f);
            b.limb(c - glm::vec3(0, 0, 0.012f), c + glm::vec3(0, 0, 0.012f), 0.024f, 0.024f, kTint);
            b.paint([=](const glm::vec3& p) { return std::max(glm::length(glm::vec2(p.x - c.x, p.y - c.y)) - 0.016f, c.z + 0.006f - p.z); }, c - glm::vec3(0.03f), c + glm::vec3(0.03f), MAT_ICE);
        }
        b.add([](const glm::vec3& p) {                                                      // the strap round the head
            const glm::vec3 q = p - H(0.0f, 0.145f, 0.0f);
            return std::max(std::fabs(ellipsoid(q, glm::vec3(0.1f, 0.13f, 0.112f))) - 0.005f, std::fabs(q.y) - 0.01f);
        }, H(-0.12f, 0.13f, -0.12f), H(0.12f, 0.16f, 0.12f), MAT_PAINT_BLACK);
    }
    return b.finish(PartSlot::Glasses, H(0.0f, 0.0f, 0.0f), kind == "round" || kind == "goggles" ? "tint:accent" : nullptr);
}

AssetPtr makeBeard(const std::string& kind) {
    PartBuilder b("beard " + kind, { 0.26f, 0.30f, 0.30f }, 0.005f);
    auto moustache = [&](float w) {
        b.add([=](const glm::vec3& p) { const glm::vec3 q = p - H(0.0f, 0.084f, 0.108f); return roundedBox(glm::vec3(q.x, q.y + 0.25f * q.x * q.x / 0.004f * 0.004f, q.z), glm::vec3(w, 0.009f, 0.012f), 0.006f); },
              H(-w - 0.01f, 0.06f, 0.08f), H(w + 0.01f, 0.1f, 0.13f), kHairMat);
    };
    if (kind == "full") {
        b.add([](const glm::vec3& p) {
            const glm::vec3 q = p - H(0.0f, 0.065f, 0.03f);
            return std::max(ellipsoid(q, glm::vec3(0.098f, 0.085f, 0.094f)), H(0, 0.095f, 0).y - p.y > 0.0f ? -1.0f : (p.y - H(0, 0.095f, 0).y) * 3.0f);
        }, H(-0.11f, -0.03f, -0.07f), H(0.11f, 0.13f, 0.13f), kHairMat);
        b.carve([](const glm::vec3& p) { return ellipsoid(p - H(0.0f, 0.075f, 0.0f), glm::vec3(0.075f, 0.07f, 0.098f)); }, H(-0.08f, 0.0f, -0.1f), H(0.08f, 0.15f, 0.1f));
        b.carve([](const glm::vec3& p) { return roundedBox(p - H(0.0f, 0.07f, 0.12f), glm::vec3(0.022f, 0.008f, 0.03f), 0.004f); }, H(-0.03f, 0.05f, 0.08f), H(0.03f, 0.09f, 0.16f));
        b.carve([](const glm::vec3& p) { return p.z - H(0, 0, -0.035f).z; }, H(-0.12f, -0.05f, -0.1f), H(0.12f, 0.15f, -0.035f));
        moustache(0.034f);
    } else if (kind == "moustache") {
        moustache(0.036f);
    } else if (kind == "goatee") {
        moustache(0.026f);
        b.ball(H(0.0f, 0.032f, 0.096f), { 0.024f, 0.034f, 0.02f }, kHairMat);
    }
    return b.finish(PartSlot::Beard, H(0.0f, 0.0f, 0.0f), "tint:hair");
}

// ---------------------------------------------------------------- on the back (chest space: the waist at the joint)

AssetPtr makeBack(const std::string& kind) {
    const float up = kind == "cape" ? 0.62f : 0.05f;
    PartBuilder b("back " + kind, { 0.56f, kind == "cape" ? 1.1f : 0.56f, 0.5f });
    auto at = [&](float x, float y, float z) { return glm::vec3(x, y + up, z); };
    const char* tint = "tint:accent";
    if (kind == "backpack") {
        b.box(at(0.0f, 0.25f, -0.17f), { 0.125f, 0.15f, 0.065f }, 0.03f, kCloth);
        b.box(at(0.0f, 0.36f, -0.16f), { 0.115f, 0.035f, 0.07f }, 0.025f, kCloth, 0.01f);
        b.box(at(0.0f, 0.18f, -0.235f), { 0.08f, 0.06f, 0.02f }, 0.015f, kCloth, 0.01f);   // a pocket
        for (float s : { 1.0f, -1.0f }) b.box(at(0.09f * s, 0.3f, -0.11f), { 0.018f, 0.12f, 0.01f }, 0.005f, MAT_PAINT_BLACK);   // straps
    } else if (kind == "cape") {
        b.add([&](const glm::vec3& p) {
            const glm::vec3 q = p - at(0.0f, -0.08f, -0.14f);
            const float t = std::clamp((0.46f - q.y) / 0.92f, 0.0f, 1.0f);
            return roundedBox(glm::vec3(q.x, q.y, q.z + 0.03f * t), glm::vec3(0.19f + 0.08f * t, 0.46f, 0.012f), 0.008f);
        }, at(-0.3f, -0.56f, -0.2f), at(0.3f, 0.4f, -0.08f), kCloth);
        b.ball(at(0.0f, 0.4f, -0.1f), { 0.17f, 0.035f, 0.07f }, kCloth, 0.02f);             // across the shoulders
    } else if (kind == "quiver") {
        b.limb(at(0.07f, 0.05f, -0.15f), at(-0.07f, 0.38f, -0.15f), 0.04f, 0.045f, kCloth);
        for (int i = 0; i < 4; ++i) {
            const float o = (float(i) - 1.5f) * 0.012f;
            b.limb(at(-0.07f + o, 0.37f, -0.15f), at(-0.09f + o, 0.47f, -0.15f), 0.004f, 0.004f, MAT_WOOD);
            b.box(at(-0.09f + o, 0.47f, -0.15f), { 0.004f, 0.02f, 0.012f }, 0.0f, MAT_PAINT_RED);
        }
    } else if (kind == "tank") {
        for (float s : { 1.0f, -1.0f }) {
            b.limb(at(0.06f * s, 0.08f, -0.16f), at(0.06f * s, 0.36f, -0.16f), 0.055f, 0.055f, MAT_METAL);
            b.ball(at(0.06f * s, 0.4f, -0.16f), glm::vec3(0.02f), MAT_PAINT_BLACK);
        }
    } else if (kind == "sword") {
        b.limb(at(0.14f, 0.0f, -0.14f), at(-0.12f, 0.36f, -0.14f), 0.012f, 0.004f, MAT_METAL);   // blade
        b.limb(at(-0.15f, 0.36f, -0.14f), at(-0.09f, 0.4f, -0.14f), 0.008f, 0.008f, MAT_PAINT_BLACK);   // guard
        b.limb(at(-0.12f, 0.38f, -0.14f), at(-0.17f, 0.45f, -0.14f), 0.011f, 0.011f, MAT_WOOD);  // grip
        tint = nullptr;
    }
    return b.finish(PartSlot::Back, at(0.0f, 0.0f, 0.0f), tint);
}

} // namespace

// ---------------------------------------------------------------- the catalogue

const std::vector<WardrobeItem>& wardrobe() {
    static const std::vector<WardrobeItem> items = {
        { "body torso", PartSlot::Torso, "Shirt", nullptr },
        { "torso striped", PartSlot::Torso, "Striped", nullptr },
        { "torso jacket", PartSlot::Torso, "Jacket and tie", nullptr },
        { "torso vest", PartSlot::Torso, "Vest", nullptr },
        { "torso coat", PartSlot::Torso, "Long coat", nullptr },
        { "torso armour", PartSlot::Torso, "Armour", "accent" },
        { "body upper arm", PartSlot::UpperArm, "Sleeves", nullptr },
        { "upper arm bare", PartSlot::UpperArm, "Bare arms", "skin" },
        { "body hips", PartSlot::Hips, "Trousers", nullptr },
        { "hips skirt", PartSlot::Hips, "Skirt", nullptr },
        { "hips robe", PartSlot::Hips, "Robe", nullptr },
        { "body lower leg", PartSlot::LowerLeg, "Long", nullptr },
        { "lower leg bare", PartSlot::LowerLeg, "Shorts", "skin" },
        { "body foot", PartSlot::Foot, "Shoes", nullptr },
        { "foot boot", PartSlot::Foot, "Boots", nullptr },
        { "hat cap", PartSlot::Hat, "Cap", "accent" },
        { "hat beanie", PartSlot::Hat, "Beanie", "accent" },
        { "hat top hat", PartSlot::Hat, "Top hat", "accent" },
        { "hat helmet", PartSlot::Hat, "Helmet", "accent" },
        { "hat cowboy", PartSlot::Hat, "Cowboy hat", "accent" },
        { "hat hood", PartSlot::Hat, "Hood", "accent" },
        { "hat crown", PartSlot::Hat, "Crown", nullptr },
        { "glasses round", PartSlot::Glasses, "Round glasses", "accent" },
        { "glasses shades", PartSlot::Glasses, "Sunglasses", nullptr },
        { "glasses goggles", PartSlot::Glasses, "Goggles", "accent" },
        { "glasses visor", PartSlot::Glasses, "Glowing visor", nullptr },
        { "beard full", PartSlot::Beard, "Full beard", "hair" },
        { "beard moustache", PartSlot::Beard, "Moustache", "hair" },
        { "beard goatee", PartSlot::Beard, "Goatee", "hair" },
        { "back backpack", PartSlot::Back, "Backpack", "accent" },
        { "back cape", PartSlot::Back, "Cape", "accent" },
        { "back quiver", PartSlot::Back, "Quiver", "accent" },
        { "back tank", PartSlot::Back, "Air tanks", "accent" },
        { "back sword", PartSlot::Back, "Sword", nullptr },
    };
    return items;
}

std::vector<const WardrobeItem*> wardrobeFor(PartSlot s) {
    std::vector<const WardrobeItem*> out;
    for (const WardrobeItem& w : wardrobe()) if (w.slot == s) out.push_back(&w);
    return out;
}

const WardrobeItem* wardrobeItem(const std::string& asset) {
    for (const WardrobeItem& w : wardrobe()) if (asset == w.asset) return &w;
    return nullptr;
}

std::string faceHeadName(const FaceStyle& f, bool shut) {
    char b[48];
    std::snprintf(b, sizeof b, "head e%d b%d n%d m%d%s", int(f.eyes), int(f.brows), int(f.nose), int(f.mouth), shut ? " shut" : "");
    return b;
}

bool parseFaceHeadName(const std::string& name, FaceStyle& f, bool& shut) {
    int e, b, n, m;
    char rest[16] = {};
    const int got = std::sscanf(name.c_str(), "head e%d b%d n%d m%d %15s", &e, &b, &n, &m, rest);
    if (got < 4) return false;
    if (e < 0 || e >= kEyeStyles || b < 0 || b >= kBrowStyles || n < 0 || n >= kNoseStyles || m < 0 || m >= kMouthStyles) return false;
    f.eyes = std::uint8_t(e); f.brows = std::uint8_t(b); f.nose = std::uint8_t(n); f.mouth = std::uint8_t(m);
    shut = got == 5 && std::string(rest) == "shut";
    return got == 4 || shut;
}

void registerWardrobe(AssetLibrary& lib) {
    auto reg = [&](const WardrobeItem& w, std::function<AssetPtr()> make) {
        std::vector<std::string> tags = { std::string("part:") + partSlotName(w.slot), "builtin body" };
        if (w.tint) tags.push_back(std::string("tint:") + w.tint);
        lib.addGenerated(w.asset, std::move(tags), std::move(make));
    };
    for (const WardrobeItem& w : wardrobe()) {
        const std::string n = w.asset;
        if (n.rfind("body ", 0) == 0) continue;                  // the basic body: registered by registerBodyParts
        if (n == "torso striped") reg(w, makeTorsoStriped);
        else if (n == "torso jacket") reg(w, makeTorsoJacket);
        else if (n == "torso vest") reg(w, makeTorsoVest);
        else if (n == "torso coat") reg(w, makeTorsoCoat);
        else if (n == "torso armour") reg(w, makeTorsoArmour);
        else if (n == "upper arm bare") reg(w, makeUpperArmBare);
        else if (n == "hips skirt") reg(w, [] { return makeHipsSkirt("hips skirt", 0.42f, 0.07f); });
        else if (n == "hips robe") reg(w, [] { return makeHipsSkirt("hips robe", 0.84f, 0.1f); });
        else if (n == "lower leg bare") reg(w, makeLowerLegBare);
        else if (n == "foot boot") reg(w, makeBoot);
        else if (n.rfind("hat ", 0) == 0) reg(w, [k = n.substr(4)] { return makeHat(k); });
        else if (n.rfind("glasses ", 0) == 0) reg(w, [k = n.substr(8)] { return makeGlasses(k); });
        else if (n.rfind("beard ", 0) == 0) reg(w, [k = n.substr(6)] { return makeBeard(k); });
        else if (n.rfind("back ", 0) == 0) reg(w, [k = n.substr(5)] { return makeBack(k); });
    }
    for (HairStyle h : { HairStyle::Ponytail, HairStyle::Curly, HairStyle::Mohawk })
        lib.addGenerated(std::string("hair ") + hairStyleName(h), { "part:hair", "builtin body" }, [h] { return makeHairExtra(h); });
    // Every face: made when someone first wears it.
    lib.addFamily("head e", [](const std::string& name) -> AssetPtr {
        FaceStyle f; bool shut = false;
        if (!parseFaceHeadName(name, f, shut)) return nullptr;
        AssetPtr a = makeFaceHead(name, f, shut);
        a->tags = { "builtin body", "face" };                    // not part:head, so the Parts list shows only "Built-in"
        return a;
    });
}

} // namespace px
