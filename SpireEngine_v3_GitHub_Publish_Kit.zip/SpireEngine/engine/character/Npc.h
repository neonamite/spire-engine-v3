#pragma once
// NPCs that live (v0.20): what a person placed in the world does with their day. Pure (no window, no world): the editor
// gives each one the ground, the player and the time of day, and moves them where this says. Every rule is unit tested.
//
// A person has a job (role) and a way of meeting you (reaction):
//   Stand   - stays on their spot (and fidgets)            Wander - strolls about near their spot, stopping now and then
//   Patrol  - walks a path of points round and round       Guard  - keeps a post; walks up to anyone who comes close
//   Follow  - comes along with you when you are near       Work   - goes to a work spot and works there
// Reactions when you come close: Ignore (they just look), Friendly (they stop, smile, wave and say something), Shy (they
// back away), Scared (they run). A daily schedule can change the role by the hour (work at 8, wander at 12, home at 18).
#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "core/Json.h"
#include "character/Animator.h"

namespace px {

enum class NpcRole : std::uint8_t { Stand, Wander, Patrol, Guard, Follow, Work, Count };            // append only (saved)
enum class NpcReaction : std::uint8_t { Ignore, Friendly, Shy, Scared, Count };                     // append only (saved)
const char* npcRoleName(NpcRole r);          // "wander" (files)
const char* npcRoleLabel(NpcRole r);         // "Wander"
const char* npcRoleHint(NpcRole r);
const char* npcReactionName(NpcReaction r);
const char* npcReactionLabel(NpcReaction r);
const char* npcReactionHint(NpcReaction r);

struct NpcScheduleItem {
    float hour = 8.0f;                       // from this time of day (0 .. 24) ...
    NpcRole role = NpcRole::Work;            // ... they do this, until the next item
    bool operator==(const NpcScheduleItem&) const = default;
};

struct NpcSettings {
    NpcRole role = NpcRole::Stand;
    NpcReaction reaction = NpcReaction::Friendly;
    float radius = 6.0f;                     // how far they wander from their spot; a guard's watch; how far a follower comes
    float speed = 1.0f;                      // 0.5 .. 2: how quickly they walk
    float notice = 4.0f;                     // how close you come before they react
    bool nameTag = true;                     // their name over their head
    std::vector<std::string> lines;          // what they say (in turn), "" = nothing
    std::vector<glm::vec3> path;             // patrol points, world
    bool hasWorkSpot = false;
    glm::vec3 workSpot{ 0.0f };              // where they work (their own spot when unset)
    std::vector<NpcScheduleItem> schedule;   // empty: always `role`
    void clamp();
    bool operator==(const NpcSettings&) const = default;
};

Json npcToJson(const NpcSettings& s);
bool npcFromJson(const Json& j, NpcSettings& out);
std::string npcToText(const NpcSettings& s);                     // compact JSON, for the scene file
bool npcFromText(const std::string& text, NpcSettings& out);     // false: not settings (out unchanged)

NpcRole npcRoleAt(const NpcSettings& s, float hour);              // the schedule's role at that time of day

// What a person is doing right now (not saved: it starts again each time you play).
enum class NpcActivity : std::uint8_t { Idle, Walking, Waiting, Talking, Backing, Fleeing, Challenging, Following, Working };
const char* npcActivityLabel(NpcActivity a);

struct NpcState {
    glm::vec3 position{ 0.0f };
    float yaw = 0.0f;                        // degrees, the objects' convention (0 faces +z)
    NpcActivity activity = NpcActivity::Idle;
    NpcRole role = NpcRole::Stand;           // the role being followed now
    bool hasGoal = false;
    glm::vec3 goal{ 0.0f };
    float goalYaw = 0.0f;                    // which way to face on arriving
    bool faceOnArrive = false;
    float wait = 0.0f;                       // seconds left standing about before the next stroll
    int pathIndex = 0;
    float stuck = 0.0f;
    float moving = 0.0f;                     // metres per second this tick
    bool running = false;
    // meeting the player
    bool met = false;                        // the player is (still) close: said hello already
    float cooldown = 0.0f;
    int nextLine = 0;
    std::string speech;                      // what they are saying ("" = nothing)
    float speechLeft = 0.0f;
    Mood mood = Mood::Calm;
    Fidget gesture = Fidget::None;           // a one-off gesture to start this tick (wave, work)
    bool lookAtPlayer = false;
    std::uint32_t rng = 1;
    bool started = false;
};

struct NpcInput {
    glm::vec3 home{ 0.0f };                  // where they were placed
    float homeYaw = 0.0f;
    bool hasPlayer = false;
    glm::vec3 player{ 0.0f };
    float hour = 12.0f;
    float dt = 1.0f / 60.0f;
    std::uint32_t seed = 1;
    // Can they step from `from` to `to`? Sets the ground height there. Empty: flat open ground at home.y.
    std::function<bool(const glm::vec3& from, const glm::vec3& to, float& groundY)> step;
    std::vector<glm::vec3> others;           // other people near by (they keep a little apart)
};

inline constexpr float kNpcWalk = 1.35f, kNpcRun = 3.4f;         // metres per second at speed 1

void npcUpdate(const NpcSettings& s, NpcState& st, const NpcInput& in);

} // namespace px
