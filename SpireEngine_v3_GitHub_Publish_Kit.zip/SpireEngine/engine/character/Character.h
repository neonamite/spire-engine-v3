#pragma once
// Characters (v0.18): a standard 16-bone humanoid skeleton, a body you shape with sliders, parts (assets) on the bones,
// colours, and the .pxcharacter file that holds it all. Pure: no window, no GPU, so every rule is unit tested.
//
// Character space: metres, the feet on y = 0, facing +z, the character's left is +x. Every bone's rest frame is lined up
// with character space; a bone's joint is where it turns. Limbs hang down (-y) from their joint, the spine, neck and head
// go up (+y), a foot points forward (+z) from the ankle.
//
// First version, like Roblox R15: one rigid part per bone, posed by procedural animation (character/Animator.h).
#include <array>
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/quaternion.hpp>
#include "core/Json.h"

namespace px {

enum class Bone : std::uint8_t {
    Pelvis, Chest, Neck, Head,
    UpperArmL, LowerArmL, HandL, UpperArmR, LowerArmR, HandR,
    UpperLegL, LowerLegL, FootL, UpperLegR, LowerLegR, FootR,
    Count
};
inline constexpr int kBoneCount = int(Bone::Count);
const char* boneName(Bone b);                         // "upper_arm_l"
int boneParent(Bone b);                               // -1 for the pelvis

// What a part is for. Left and right share a part; Hair, Hat, Glasses and Beard sit on the head, Back on the chest.
// Hat, Glasses, Beard and Back are accessories: empty means none. (Append only: names are stored in files.)
enum class PartSlot : std::uint8_t { Hips, Torso, Neck, Head, Hair, UpperArm, LowerArm, Hand, UpperLeg, LowerLeg, Foot,
                                     Hat, Glasses, Beard, Back, Count };
inline constexpr int kPartSlotCount = int(PartSlot::Count);
const char* partSlotName(PartSlot s);                 // "upper_arm" (in files and tags: part:upper_arm)
const char* partSlotLabel(PartSlot s);                // "Upper arms"
PartSlot slotForBone(Bone b);

bool isAccessorySlot(PartSlot s);                     // Hat, Glasses, Beard, Back
Bone boneForAccessory(PartSlot s);                    // the head for Hat / Glasses / Beard, the chest for Back

// Which colour a built-in part takes (a part's tag tint:<role> can say otherwise: bare legs are skin).
enum class ColourRole : std::uint8_t { Skin, Hair, Top, Bottoms, Shoes, Accent, Count };
const char* colourRoleLabel(ColourRole r);
const char* colourRoleKey(ColourRole r);              // "skin", "accent" (files, tags)
bool colourRoleFromKey(const std::string& key, ColourRole& out);
ColourRole colourRoleFor(PartSlot s);

// The face, built into the head: eyes, brows, nose, mouth (each an index into a short list).
struct FaceStyle {
    std::uint8_t eyes = 1, brows = 1, nose = 0, mouth = 1;
    bool operator==(const FaceStyle&) const = default;
};
inline constexpr int kEyeStyles = 5, kBrowStyles = 5, kNoseStyles = 4, kMouthStyles = 5;
const char* eyeStyleLabel(int i);                     // Natural, Round, Narrow, Sleepy, Wide
const char* browStyleLabel(int i);                    // None, Soft, Angry, Worried, Bushy
const char* noseStyleLabel(int i);                    // Small, Round, Long, Button
const char* mouthStyleLabel(int i);                   // Relaxed, Smile, Pressed, Grin, Frown

// How someone moves: the same procedural animation, with their own numbers. A soldier marches, an old man shuffles,
// a kid bounces, a tough guy swaggers.
struct MoveStyle {
    float stride = 1.0f;        // 0.7 short steps .. 1.3 long strides
    float swagger = 0.0f;       // 0 .. 1: hips and shoulders roll
    float armSwing = 1.0f;      // 0 arms still .. 1.6 big swings
    float bounce = 1.0f;        // 0 smooth .. 2 springy
    float posture = 0.0f;       // -1 hunched .. 1 chest out
    float fidget = 0.5f;        // 0 stands still .. 1 always doing something when idle
    void clamp();
    bool operator==(const MoveStyle&) const = default;
};
const std::vector<std::pair<const char*, MoveStyle>>& moveStylePresets();   // Normal, March, Shuffle, Bouncy, Swagger, Sneak, Proud

struct BodyShape {
    float height = 1.80f;       // metres, head to toe (1.0 .. 2.4)
    float build = 1.0f;         // how broad and thick (0.7 .. 1.5)
    float shoulders = 1.0f;     // shoulder width (0.8 .. 1.3)
    float legs = 1.0f;          // leg length, as a share of the height (0.85 .. 1.15)
    float arms = 1.0f;          // arm length (0.85 .. 1.15)
    float head = 1.0f;          // head size (0.8 .. 1.5)
    void clamp();
    bool operator==(const BodyShape&) const = default;
};

// What the realistic body looks like (1.5): it is the MakeHuman body, shaped by these, then fitted to the skeleton.
struct HumanLook {
    float gender = 1.0f;        // 0 feminine .. 1 masculine
    float age = 0.5f;           // 0 child .. 0.5 young adult .. 1 old
    float muscle = 0.5f;        // 0 .. 1
    float weight = 0.5f;        // 0 thin .. 1 heavy
    std::array<float, 3> heritage{ 1.0f / 3.0f, 1.0f / 3.0f, 1.0f / 3.0f };   // African, Asian, European features (they add to 1)
    std::uint32_t faceSeed = 0; // small differences in nose, mouth, chin, cheeks, ears (0: none)
    glm::vec3 eyes{ 0.30f, 0.20f, 0.12f };   // eye colour
    void clamp();
    bool operator==(const HumanLook&) const = default;
};
const char* heritageLabel(int i);                      // "African", "Asian", "European"

enum class HairStyle : std::uint8_t { None, Short, Long, Bun, Spiky, Ponytail, Curly, Mohawk, Count };     // append only
const char* hairStyleName(HairStyle h);
const char* hairStyleLabel(HairStyle h);

struct CharacterDef {
    std::string name = "Character";
    BodyShape shape;
    std::array<glm::vec3, int(ColourRole::Count)> colours{ glm::vec3(0.85f, 0.64f, 0.50f), glm::vec3(0.22f, 0.15f, 0.10f),
                                                           glm::vec3(0.25f, 0.45f, 0.75f), glm::vec3(0.22f, 0.24f, 0.30f), glm::vec3(0.16f, 0.13f, 0.12f),
                                                           glm::vec3(0.75f, 0.62f, 0.30f) };
    HairStyle hair = HairStyle::Short;
    FaceStyle face;
    MoveStyle move;
    HumanLook look;
    std::array<std::string, kPartSlotCount> parts{};  // an asset per slot; "" = the built-in part (Hair: the hair style's; accessories: none)
    std::array<glm::vec4, kPartSlotCount> partColour{};   // a colour of its own for one part (w = 1 when set), over its role's
    glm::vec3& colour(ColourRole r) { return colours[size_t(r)]; }
    glm::vec3 colourOf(PartSlot s, ColourRole role) const {      // the part's own colour when it has one, else its role's
        const glm::vec4& c = partColour[size_t(s)];
        return c.w > 0.5f ? glm::vec3(c) : colours[size_t(role)];
    }
    const glm::vec3& colour(ColourRole r) const { return colours[size_t(r)]; }
    bool operator==(const CharacterDef&) const = default;
};

// A look to go with a character made before 1.5 (from its hair, build and skin tone).
HumanLook lookFromShape(const CharacterDef& c);

// ---------------------------------------------------------------- the skeleton

struct Skeleton {
    struct B {
        int parent = -1;
        glm::vec3 offset{ 0.0f };          // the joint, from the parent's joint, in the parent's rest frame
        float length = 0.0f;               // to the end of the bone (the child's joint, or the tip)
        glm::vec3 partScale{ 1.0f };       // how much the built-in part (made for the standard body) is stretched: x, length, z
    };
    std::array<B, kBoneCount> bones;
    float hipHeight = 0.0f;                // the pelvis joint above the feet
    float ankleHeight = 0.0f;              // the ankle above the sole
    float height = 0.0f;
    float scale = 1.0f;                    // height / 1.8, roughly: how much bigger than the standard body
    const B& bone(Bone b) const { return bones[size_t(b)]; }
};
Skeleton buildSkeleton(const BodyShape& shape);

// A pose: each bone's turn relative to its parent (rest = identity), and how far the pelvis is moved from its rest place.
struct Pose {
    std::array<glm::quat, kBoneCount> local;
    glm::vec3 pelvisOffset{ 0.0f };
    Pose() { local.fill(glm::quat(1.0f, 0.0f, 0.0f, 0.0f)); }
};

// Every bone's world transform (rotation and joint position) for a pose, with the character's root at `root`
// (the point between the feet, facing its +z).
std::array<glm::mat4, kBoneCount> poseToWorld(const Skeleton& sk, const Pose& p, const glm::mat4& root);
// The local turn a bone needs so that its world rotation becomes `worldRot`, given the world transforms so far.
glm::quat localFor(const Skeleton& sk, const std::array<glm::mat4, kBoneCount>& world, const glm::mat4& root, Bone b, const glm::quat& worldRot);

// Two-bone IK: the joints a (hip / shoulder), b (knee / elbow), c (ankle / wrist). Returns where b goes so that c reaches
// `target` (or gets as close as it can), bending towards `pole`. The bone lengths never change.
glm::vec3 solveTwoBone(const glm::vec3& a, const glm::vec3& b, const glm::vec3& c, const glm::vec3& target, const glm::vec3& pole, glm::vec3* reached = nullptr);

// ---------------------------------------------------------------- files and the library

Json characterToJson(const CharacterDef& c);
bool characterFromJson(const Json& j, CharacterDef& out, std::string* error = nullptr);
bool saveCharacterFile(const CharacterDef& c, const std::string& path, std::string* error = nullptr);   // atomic
bool loadCharacterFile(const std::string& path, CharacterDef& out, std::string* error = nullptr);
std::string characterFileName(const std::string& name);       // "Ada Lovelace!" -> "ada_lovelace"
std::string colourToHex(const glm::vec3& c);                  // "#c8916b"
bool colourFromHex(const std::string& s, glm::vec3& out);

const std::vector<CharacterDef>& characterPresets();
const std::vector<glm::vec3>& skinTones();
const std::vector<glm::vec3>& hairColours();

// Crowds: a person made from a number, in a style, so a hundred villagers are a hundred different people. A placed person
// can be named "crowd:<style>:<seed>" and is made again from that, exactly the same, whenever the world loads.
enum class CrowdStyle : std::uint8_t { Anyone, Villagers, City, Soldiers, SciFi, Fantasy, Count };
const char* crowdStyleName(CrowdStyle s);             // "villagers"
const char* crowdStyleLabel(CrowdStyle s);            // "Villagers"
CharacterDef makeCrowdPerson(CrowdStyle style, std::uint32_t seed);
std::string crowdName(CrowdStyle style, std::uint32_t seed);   // "crowd:villagers:1234"
bool parseCrowdName(const std::string& name, CrowdStyle& style, std::uint32_t& seed);
std::string personName(std::uint32_t seed);           // "Mara Quill": a first and last name to go with a seed
// Where `count` people stand in a circle of `radius` metres: spread out evenly but not in rows, never closer than `gap`
// (fewer come back when they cannot all fit). Offsets from the middle, x and z.
std::vector<glm::vec2> crowdSpots(int count, float radius, std::uint32_t seed, float gap = 0.9f);

// Every character the editor knows: the ready-made ones and every .pxcharacter in `directory`.
class CharacterLibrary {
public:
    std::string directory = "characters";
    int  loadDirectory();                                     // how many files loaded (damaged ones are skipped)
    bool save(const CharacterDef& c, std::string* error = nullptr);   // characters/<file name>.pxcharacter, and into the list
    const CharacterDef* find(const std::string& name) const;
    CharacterDef get(const std::string& name) const;          // the default character when there is no such one (crowd names are made)
    bool has(const std::string& name) const;                  // a ready-made one, one of yours, or a crowd name
    std::vector<std::string> names() const;                   // ready-made first, then yours, by name
    bool isPreset(const std::string& name) const;
    bool isYours(const std::string& name) const { return mine.count(name) != 0; }
    const std::vector<std::string>& problems() const { return skipped; }
private:
    std::map<std::string, CharacterDef> mine;
    std::vector<std::string> skipped;
};

} // namespace px
