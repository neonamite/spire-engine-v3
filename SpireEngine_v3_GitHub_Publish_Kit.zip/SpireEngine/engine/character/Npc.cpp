#include "character/Npc.h"
#include <algorithm>
#include <cmath>

namespace px {

namespace {
constexpr float kPi = 3.14159265f;

struct RoleInfo { const char* name; const char* label; const char* hint; };
const RoleInfo kRoles[] = {
    { "stand", "Stand", "Stays on their spot, and fidgets now and then" },
    { "wander", "Wander", "Strolls about near their spot, stopping now and then" },
    { "patrol", "Patrol", "Walks round a path of points you set" },
    { "guard", "Guard", "Keeps a post; walks up to anyone who comes too close, and goes back" },
    { "follow", "Follow", "Comes along with you when you are near" },
    { "work", "Work", "Goes to their work spot and works there" },
};
const RoleInfo kReactions[] = {
    { "ignore", "Ignore", "They look at you, and carry on" },
    { "friendly", "Friendly", "They stop, smile, wave and say something" },
    { "shy", "Shy", "They back away a little" },
    { "scared", "Scared", "They run away" },
};

float rnd(NpcState& st) {
    st.rng ^= st.rng << 13; st.rng ^= st.rng >> 17; st.rng ^= st.rng << 5;
    return float(st.rng % 10000u) / 10000.0f;
}
float flatDist(const glm::vec3& a, const glm::vec3& b) { return glm::length(glm::vec2(a.x - b.x, a.z - b.z)); }
float yawOf(const glm::vec3& d) { return glm::degrees(std::atan2(d.x, d.z)); }
float wrapDeg(float d) { d = std::fmod(d + 180.0f, 360.0f); if (d < 0.0f) d += 360.0f; return d - 180.0f; }

void say(NpcState& st, const std::string& text, float seconds = 3.5f) {
    if (text.empty()) return;
    st.speech = text;
    st.speechLeft = seconds;
}
std::string nextLine(const NpcSettings& s, NpcState& st, const char* fallback) {
    if (s.lines.empty()) return fallback ? fallback : "";
    const std::string l = s.lines[size_t(st.nextLine) % s.lines.size()];
    st.nextLine = (st.nextLine + 1) % int(s.lines.size());
    return l;
}
} // namespace

const char* npcRoleName(NpcRole r) { return size_t(r) < std::size(kRoles) ? kRoles[size_t(r)].name : "stand"; }
const char* npcRoleLabel(NpcRole r) { return size_t(r) < std::size(kRoles) ? kRoles[size_t(r)].label : "Stand"; }
const char* npcRoleHint(NpcRole r) { return size_t(r) < std::size(kRoles) ? kRoles[size_t(r)].hint : ""; }
const char* npcReactionName(NpcReaction r) { return size_t(r) < std::size(kReactions) ? kReactions[size_t(r)].name : "ignore"; }
const char* npcReactionLabel(NpcReaction r) { return size_t(r) < std::size(kReactions) ? kReactions[size_t(r)].label : "Ignore"; }
const char* npcReactionHint(NpcReaction r) { return size_t(r) < std::size(kReactions) ? kReactions[size_t(r)].hint : ""; }

const char* npcActivityLabel(NpcActivity a) {
    static const char* n[] = { "Standing", "Walking", "Waiting", "Talking", "Backing away", "Running away", "Challenging", "Following", "Working" };
    return size_t(a) < std::size(n) ? n[size_t(a)] : "";
}

void NpcSettings::clamp() {
    radius = std::clamp(std::isfinite(radius) ? radius : 6.0f, 1.0f, 60.0f);
    speed = std::clamp(std::isfinite(speed) ? speed : 1.0f, 0.4f, 2.0f);
    notice = std::clamp(std::isfinite(notice) ? notice : 4.0f, 1.0f, 20.0f);
    if (lines.size() > 32) lines.resize(32);
    for (std::string& l : lines) if (l.size() > 160) l.resize(160);
    if (path.size() > 64) path.resize(64);
    if (schedule.size() > 24) schedule.resize(24);
    for (NpcScheduleItem& it : schedule) {
        it.hour = std::isfinite(it.hour) ? std::fmod(std::fmod(it.hour, 24.0f) + 24.0f, 24.0f) : 0.0f;
        if (int(it.role) >= int(NpcRole::Count)) it.role = NpcRole::Stand;
    }
    std::stable_sort(schedule.begin(), schedule.end(), [](const NpcScheduleItem& a, const NpcScheduleItem& b) { return a.hour < b.hour; });
}

// ---------------------------------------------------------------- files

Json npcToJson(const NpcSettings& s) {
    Json j = Json::object();
    j.set("role", npcRoleName(s.role));
    j.set("reaction", npcReactionName(s.reaction));
    j.set("radius", s.radius);
    j.set("speed", s.speed);
    j.set("notice", s.notice);
    j.set("nameTag", s.nameTag);
    if (!s.lines.empty()) { Json l = Json::array(); for (const std::string& t : s.lines) l.push(t); j.set("lines", l); }
    if (!s.path.empty()) {
        Json p = Json::array();
        for (const glm::vec3& v : s.path) p.push(Json::array({ v.x, v.y, v.z }));
        j.set("path", p);
    }
    if (s.hasWorkSpot) j.set("work", Json::array({ s.workSpot.x, s.workSpot.y, s.workSpot.z }));
    if (!s.schedule.empty()) {
        Json sc = Json::array();
        for (const NpcScheduleItem& it : s.schedule) { Json e = Json::object(); e.set("hour", it.hour); e.set("role", npcRoleName(it.role)); sc.push(e); }
        j.set("schedule", sc);
    }
    return j;
}

bool npcFromJson(const Json& j, NpcSettings& out) {
    if (!j.isObject()) return false;
    NpcSettings s;
    auto roleFrom = [](const std::string& n, NpcRole fallback) {
        for (int i = 0; i < int(NpcRole::Count); ++i) if (n == npcRoleName(NpcRole(i))) return NpcRole(i);
        return fallback;
    };
    s.role = roleFrom(j.get("role").str(), NpcRole::Stand);
    const std::string re = j.get("reaction").str("friendly");
    for (int i = 0; i < int(NpcReaction::Count); ++i) if (re == npcReactionName(NpcReaction(i))) s.reaction = NpcReaction(i);
    s.radius = float(j.get("radius").num(6.0));
    s.speed = float(j.get("speed").num(1.0));
    s.notice = float(j.get("notice").num(4.0));
    s.nameTag = j.get("nameTag").boolean(true);
    const Json& l = j.get("lines");
    for (size_t i = 0; i < l.size(); ++i) if (l.at(i).isString()) s.lines.push_back(l.at(i).str());
    auto vec = [](const Json& a, glm::vec3& v) {
        if (a.size() != 3) return false;
        v = glm::vec3(float(a.at(0).num()), float(a.at(1).num()), float(a.at(2).num()));
        return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
    };
    const Json& p = j.get("path");
    for (size_t i = 0; i < p.size(); ++i) { glm::vec3 v; if (vec(p.at(i), v)) s.path.push_back(v); }
    s.hasWorkSpot = vec(j.get("work"), s.workSpot);
    const Json& sc = j.get("schedule");
    for (size_t i = 0; i < sc.size(); ++i) {
        NpcScheduleItem it;
        it.hour = float(sc.at(i).get("hour").num(8.0));
        it.role = roleFrom(sc.at(i).get("role").str(), NpcRole::Stand);
        s.schedule.push_back(it);
    }
    s.clamp();
    out = std::move(s);
    return true;
}

std::string npcToText(const NpcSettings& s) { return npcToJson(s).dump(-1); }

bool npcFromText(const std::string& text, NpcSettings& out) {
    Json j;
    return !text.empty() && Json::parse(text, j) && npcFromJson(j, out);
}

NpcRole npcRoleAt(const NpcSettings& s, float hour) {
    if (s.schedule.empty()) return s.role;
    hour = std::fmod(std::fmod(hour, 24.0f) + 24.0f, 24.0f);
    // the last item that has started today; before the first one, yesterday's last one is still going
    NpcRole r = s.schedule.back().role;
    for (const NpcScheduleItem& it : s.schedule) if (it.hour <= hour) r = it.role;
    return r;
}

// ---------------------------------------------------------------- living

void npcUpdate(const NpcSettings& s, NpcState& st, const NpcInput& in) {
    const float dt = std::clamp(in.dt, 0.0f, 0.1f);
    if (!st.started) {
        st.position = in.home; st.yaw = in.homeYaw;
        st.rng = (in.seed * 2654435761u) ^ 0x7F4A7C15u; if (!st.rng) st.rng = 1;
        st.wait = 1.0f + 3.0f * rnd(st);
        st.started = true;
    }
    st.gesture = Fidget::None;
    st.lookAtPlayer = false;
    st.running = false;
    st.moving = 0.0f;
    st.cooldown = std::max(0.0f, st.cooldown - dt);
    st.speechLeft = std::max(0.0f, st.speechLeft - dt);
    if (st.speechLeft <= 0.0f) st.speech.clear();

    const NpcRole role = npcRoleAt(s, in.hour);
    if (role != st.role) { st.role = role; st.hasGoal = false; st.wait = 0.0f; st.pathIndex = 0; }
    const float walk = kNpcWalk * s.speed, run = kNpcRun * s.speed;
    const float d = in.hasPlayer ? flatDist(st.position, in.player) : 1e9f;
    glm::vec3 toPlayer = in.hasPlayer ? in.player - st.position : glm::vec3(0.0f);
    toPlayer.y = 0.0f;
    const glm::vec3 awayDir = glm::length(toPlayer) > 1e-3f ? -glm::normalize(toPlayer) : glm::vec3(0, 0, -1);

    // ---- where to go and how: what is happening first (meeting the player), then the job
    glm::vec3 goal = st.position;
    bool go = false, faceGoalYaw = false;
    float goalYaw = st.yaw, stopAt = 0.3f, pace = walk;
    Mood mood = Mood::Calm;

    if (st.activity == NpcActivity::Fleeing && d > s.notice * 2.4f) st.activity = NpcActivity::Idle;
    const bool guarding = role == NpcRole::Guard && in.hasPlayer && flatDist(in.player, in.home) < s.radius;
    if (d > s.notice + 1.5f && !guarding) st.met = false;

    bool reacting = false;
    if (role == NpcRole::Guard) {
        const float fromPost = flatDist(in.player, in.home);
        if (in.hasPlayer && fromPost < s.radius) {
            reacting = true;
            st.activity = NpcActivity::Challenging;
            goal = in.player; go = true; stopAt = 1.8f; pace = walk * 1.25f;
            mood = Mood::Angry;
            st.lookAtPlayer = true;
            if (!st.met) { st.met = true; say(st, nextLine(s, st, "Halt! Who goes there?")); }
        }
    } else if (role == NpcRole::Follow) {
        if (in.hasPlayer && d < s.radius * 3.0f) {
            reacting = true;
            st.lookAtPlayer = d < 4.0f;
            if (d > 2.6f) {
                st.activity = NpcActivity::Following;
                goal = in.player; go = true; stopAt = 2.2f; pace = d > 7.0f ? run : walk * 1.2f;
            } else st.activity = NpcActivity::Waiting;
            mood = Mood::Happy;
            if (!st.met && d < s.notice) { st.met = true; say(st, nextLine(s, st, nullptr)); }
        }
    }
    const float reactRange = st.met ? s.notice + 1.5f : s.notice;             // once met, they keep reacting a little longer
    if (!reacting && in.hasPlayer && (d < reactRange || st.activity == NpcActivity::Fleeing)) {
        switch (s.reaction) {
        case NpcReaction::Friendly:
            reacting = true;
            st.activity = NpcActivity::Talking;
            st.lookAtPlayer = true;
            faceGoalYaw = true; goalYaw = yawOf(toPlayer);
            mood = st.speechLeft > 0.0f ? Mood::Talking : Mood::Happy;
            if (!st.met && st.cooldown <= 0.0f) {
                st.met = true; st.cooldown = 6.0f;
                st.gesture = Fidget::Wave;
                say(st, nextLine(s, st, nullptr));
            }
            break;
        case NpcReaction::Shy:
            reacting = true;
            st.activity = NpcActivity::Backing;
            if (d < s.notice * 0.75f) { goal = st.position + awayDir * 1.5f; go = true; stopAt = 0.2f; pace = walk * 0.8f; }
            faceGoalYaw = true; goalYaw = yawOf(toPlayer);      // they back away facing you
            mood = Mood::Sad;
            if (!st.met) { st.met = true; say(st, nextLine(s, st, nullptr), 2.5f); }
            break;
        case NpcReaction::Scared:
            reacting = true;
            st.activity = NpcActivity::Fleeing;
            goal = st.position + awayDir * 4.0f; go = true; stopAt = 0.2f; pace = run;
            mood = Mood::Scared;
            if (!st.met) { st.met = true; say(st, nextLine(s, st, "Aaah!"), 2.0f); }
            break;
        case NpcReaction::Ignore:
        case NpcReaction::Count:
            st.lookAtPlayer = d < s.notice;
            break;
        }
    }

    if (!reacting) {
        switch (role) {
        case NpcRole::Stand: case NpcRole::Guard: case NpcRole::Follow:
            goal = in.home; go = flatDist(st.position, in.home) > 0.35f; faceGoalYaw = true; goalYaw = in.homeYaw;
            st.activity = go ? NpcActivity::Walking : NpcActivity::Idle;
            if (!go) st.hasGoal = false;
            break;
        case NpcRole::Work: {
            const glm::vec3 spot = s.hasWorkSpot ? s.workSpot : in.home;
            goal = spot; go = flatDist(st.position, spot) > 0.4f; faceGoalYaw = true; goalYaw = in.homeYaw;
            if (!go) {
                if (st.activity != NpcActivity::Working) st.gesture = Fidget::Work;
                st.activity = NpcActivity::Working;
            } else st.activity = NpcActivity::Walking;
            break;
        }
        case NpcRole::Wander:
        case NpcRole::Patrol: {
            const bool patrol = role == NpcRole::Patrol && !s.path.empty();
            if (!st.hasGoal) {
                st.wait -= dt;
                st.activity = NpcActivity::Waiting;
                if (st.wait <= 0.0f) {
                    if (patrol) {
                        st.pathIndex %= int(s.path.size());
                        st.goal = s.path[size_t(st.pathIndex)];
                        st.pathIndex = (st.pathIndex + 1) % int(s.path.size());
                        st.hasGoal = true;
                    } else {
                        const float r = (role == NpcRole::Patrol ? 2.0f : s.radius) * std::sqrt(0.15f + 0.85f * rnd(st));
                        const float a = rnd(st) * 2.0f * kPi;
                        st.goal = in.home + glm::vec3(std::sin(a) * r, 0.0f, std::cos(a) * r);
                        st.hasGoal = true;
                    }
                    st.stuck = 0.0f;
                }
            }
            if (st.hasGoal) {
                goal = st.goal; go = true; stopAt = 0.35f;
                st.activity = NpcActivity::Walking;
                if (flatDist(st.position, st.goal) <= stopAt) {
                    st.hasGoal = false; go = false;
                    st.wait = patrol ? 1.0f + 1.5f * rnd(st) : 2.0f + 5.0f * rnd(st);
                }
            }
            break;
        }
        case NpcRole::Count: break;
        }
    }
    st.mood = mood;

    // ---- moving: straight for the goal, turning aside round anything in the way, keeping a little apart from others
    if (go && flatDist(st.position, goal) > stopAt) {
        glm::vec3 dir = goal - st.position; dir.y = 0.0f;
        dir = glm::length(dir) > 1e-4f ? glm::normalize(dir) : glm::vec3(0, 0, 1);
        for (const glm::vec3& o : in.others) {
            glm::vec3 away = st.position - o; away.y = 0.0f;
            const float dd = glm::length(away);
            if (dd > 1e-3f && dd < 0.9f) dir += away / dd * (0.9f - dd) * 1.5f;
        }
        if (glm::length(dir) > 1e-4f) dir = glm::normalize(dir);
        const float stepLen = std::min(pace * dt, std::max(0.0f, flatDist(st.position, goal) - stopAt * 0.5f));
        bool moved = false;
        for (float turn : { 0.0f, 35.0f, -35.0f, 70.0f, -70.0f, 105.0f, -105.0f }) {
            const float a = glm::radians(turn);
            const glm::vec3 dd(dir.x * std::cos(a) + dir.z * std::sin(a), 0.0f, -dir.x * std::sin(a) + dir.z * std::cos(a));
            glm::vec3 to = st.position + dd * stepLen;
            float gy = in.home.y;
            if (in.step && !in.step(st.position, to, gy)) continue;
            to.y = gy;
            st.position = to;
            st.moving = dt > 0.0f ? stepLen / dt : 0.0f;
            st.running = pace > walk * 1.6f;
            if (!faceGoalYaw || st.activity != NpcActivity::Backing) {
                const float want = yawOf(dd);
                st.yaw = wrapDeg(st.yaw + wrapDeg(want - st.yaw) * std::min(1.0f, dt * 8.0f));
            }
            moved = true;
            break;
        }
        if (!moved || stepLen < 1e-5f) {
            st.stuck += dt;
            if (st.stuck > 1.5f) { st.hasGoal = false; st.wait = 0.5f + rnd(st); st.stuck = 0.0f; if (st.activity == NpcActivity::Fleeing) st.activity = NpcActivity::Idle; }
        } else st.stuck = std::max(0.0f, st.stuck - dt);
        if (st.activity == NpcActivity::Backing) st.yaw = wrapDeg(st.yaw + wrapDeg(goalYaw - st.yaw) * std::min(1.0f, dt * 8.0f));
    } else if (faceGoalYaw) {
        st.yaw = wrapDeg(st.yaw + wrapDeg(goalYaw - st.yaw) * std::min(1.0f, dt * 5.0f));
    }
}

} // namespace px
