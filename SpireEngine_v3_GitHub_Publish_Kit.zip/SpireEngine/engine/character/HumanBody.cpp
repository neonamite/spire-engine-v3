#include "character/HumanBody.h"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <thread>
#include <unordered_map>
#include <glm/gtc/matrix_transform.hpp>
#include "character/BodyParts.h"
#include "scene/Asset.h"
#include "scene/SdfModel.h"
#include "world/Materials.h"
#include "third_party/stb/stb_image.h"

namespace px {

namespace {

bool gRealistic = true;

float sstep(float a, float b, float x) { const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }

// ---------------------------------------------------------------- the pack (tools/makehuman/convert.py writes it)

struct Target {
    std::vector<std::uint16_t> idx;
    std::vector<glm::vec3> d;
};

struct Pack {
    std::vector<glm::vec3> base;                              // every hm08 vertex, metres
    std::vector<std::uint32_t> rvBase;                        // render vertex -> base vertex
    std::vector<glm::vec2> rvUv;
    std::array<std::vector<std::uint32_t>, 4> tris;           // body, teeth, tongue, lashes (render vertex indices, 3 per triangle)
    std::vector<std::array<std::uint8_t, 4>> wBone, wVal;     // per base vertex
    std::unordered_map<std::string, std::vector<std::uint32_t>> joints;
    std::unordered_map<std::string, Target> targets;
    // eyes
    std::array<std::uint32_t, 3> eyeScaleA{}, eyeScaleB{};
    std::array<float, 3> eyeScaleDist{};
    std::vector<std::array<std::uint32_t, 3>> eyeRef;
    std::vector<glm::vec3> eyeW, eyeOff;
    std::vector<std::uint32_t> eyeRvVert;
    std::vector<glm::vec2> eyeRvUv;
    std::vector<std::uint32_t> eyeTris;
    int eyeImgW = 0, eyeImgH = 0;
    std::vector<std::uint8_t> eyeImg;                         // RGBA, rows bottom-up (so v = 0 is row 0, as the UVs are)
    std::vector<std::uint32_t> bodyVerts;                     // base vertices of the body surface
    std::vector<std::vector<std::uint32_t>> neighbours;       // per base vertex, the body vertices it shares an edge with
    float neutralHeight = 1.0f;
};

struct Reader {
    const std::vector<char>& b;
    size_t at = 0;
    bool ok = true;
    template <class T> T get() {
        T v{};
        if (at + sizeof(T) > b.size()) { ok = false; return v; }
        std::memcpy(&v, b.data() + at, sizeof(T));
        at += sizeof(T);
        return v;
    }
    std::string str() {
        const std::uint16_t n = get<std::uint16_t>();
        if (at + n > b.size()) { ok = false; return {}; }
        std::string s(b.data() + at, n);
        at += n;
        return s;
    }
    bool sane(std::uint32_t n, std::uint32_t limit) { if (n > limit) ok = false; return ok; }
};

std::vector<std::string> assetDirs() {
    std::vector<std::string> d = { "engine/assets/human" };
#ifdef PX_SOURCE_ASSETS
    d.push_back(std::string(PX_SOURCE_ASSETS) + "/human");
#endif
    return d;
}

std::unique_ptr<Pack> loadPack() {
    std::string dir;
    for (const std::string& d : assetDirs())
        if (std::filesystem::exists(d + "/human.pxh")) { dir = d; break; }
    if (dir.empty()) return nullptr;
    std::ifstream f(dir + "/human.pxh", std::ios::binary);
    std::vector<char> bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (bytes.size() < 16 || std::memcmp(bytes.data(), "PXHUMAN1", 8) != 0) return nullptr;
    Reader r{ bytes };
    r.at = 8;
    auto p = std::make_unique<Pack>();
    const std::uint32_t nbase = r.get<std::uint32_t>();
    if (!r.sane(nbase, 65535)) return nullptr;
    p->base.resize(nbase);
    for (auto& v : p->base) { v.x = r.get<float>(); v.y = r.get<float>(); v.z = r.get<float>(); }
    const std::uint32_t nrv = r.get<std::uint32_t>();
    if (!r.sane(nrv, 1u << 20)) return nullptr;
    p->rvBase.resize(nrv); p->rvUv.resize(nrv);
    for (std::uint32_t i = 0; i < nrv; ++i) {
        p->rvBase[i] = r.get<std::uint32_t>();
        p->rvUv[i].x = r.get<float>(); p->rvUv[i].y = r.get<float>();
        if (p->rvBase[i] >= nbase) r.ok = false;
    }
    for (auto& t : p->tris) {
        const std::uint32_t n = r.get<std::uint32_t>();
        if (!r.sane(n, 1u << 20)) return nullptr;
        t.resize(size_t(n) * 3);
        for (auto& i : t) { i = r.get<std::uint32_t>(); if (i >= nrv) r.ok = false; }
    }
    p->wBone.resize(nbase); p->wVal.resize(nbase);
    for (std::uint32_t i = 0; i < nbase; ++i) {
        for (int k = 0; k < 4; ++k) { p->wBone[i][size_t(k)] = r.get<std::uint8_t>(); if (p->wBone[i][size_t(k)] >= kBoneCount) r.ok = false; }
        for (int k = 0; k < 4; ++k) p->wVal[i][size_t(k)] = r.get<std::uint8_t>();
    }
    const std::uint32_t nj = r.get<std::uint32_t>();
    if (!r.sane(nj, 4096)) return nullptr;
    for (std::uint32_t j = 0; j < nj && r.ok; ++j) {
        std::string name = r.str();
        const std::uint32_t n = r.get<std::uint32_t>();
        if (!r.sane(n, nbase)) return nullptr;
        std::vector<std::uint32_t> idx(n);
        for (auto& i : idx) { i = r.get<std::uint32_t>(); if (i >= nbase) r.ok = false; }
        p->joints[name] = std::move(idx);
    }
    const std::uint32_t nt = r.get<std::uint32_t>();
    if (!r.sane(nt, 4096)) return nullptr;
    for (std::uint32_t t = 0; t < nt && r.ok; ++t) {
        std::string name = r.str();
        const std::uint32_t n = r.get<std::uint32_t>();
        if (!r.sane(n, nbase)) return nullptr;
        Target tg;
        tg.idx.resize(n); tg.d.resize(n);
        for (std::uint32_t k = 0; k < n; ++k) {
            tg.idx[k] = r.get<std::uint16_t>();
            const std::int16_t x = r.get<std::int16_t>(), y = r.get<std::int16_t>(), z = r.get<std::int16_t>();
            tg.d[k] = glm::vec3(float(x), float(y), float(z)) / 20000.0f;
            if (tg.idx[k] >= nbase) r.ok = false;
        }
        p->targets[name] = std::move(tg);
    }
    for (int a = 0; a < 3; ++a) {
        p->eyeScaleA[size_t(a)] = r.get<std::uint32_t>(); p->eyeScaleB[size_t(a)] = r.get<std::uint32_t>(); p->eyeScaleDist[size_t(a)] = r.get<float>();
        if (p->eyeScaleA[size_t(a)] >= nbase || p->eyeScaleB[size_t(a)] >= nbase) r.ok = false;
    }
    const std::uint32_t ne = r.get<std::uint32_t>();
    if (!r.sane(ne, 1u << 16)) return nullptr;
    p->eyeRef.resize(ne); p->eyeW.resize(ne); p->eyeOff.resize(ne);
    for (std::uint32_t i = 0; i < ne; ++i) {
        for (int k = 0; k < 3; ++k) { p->eyeRef[i][size_t(k)] = r.get<std::uint32_t>(); if (p->eyeRef[i][size_t(k)] >= nbase) r.ok = false; }
        for (int k = 0; k < 3; ++k) p->eyeW[i][k] = r.get<float>();
        for (int k = 0; k < 3; ++k) p->eyeOff[i][k] = r.get<float>();
    }
    const std::uint32_t nerv = r.get<std::uint32_t>();
    if (!r.sane(nerv, 1u << 16)) return nullptr;
    p->eyeRvVert.resize(nerv); p->eyeRvUv.resize(nerv);
    for (std::uint32_t i = 0; i < nerv; ++i) {
        p->eyeRvVert[i] = r.get<std::uint32_t>(); p->eyeRvUv[i].x = r.get<float>(); p->eyeRvUv[i].y = r.get<float>();
        if (p->eyeRvVert[i] >= ne) r.ok = false;
    }
    const std::uint32_t net = r.get<std::uint32_t>();
    if (!r.sane(net, 1u << 16)) return nullptr;
    p->eyeTris.resize(size_t(net) * 3);
    for (auto& i : p->eyeTris) { i = r.get<std::uint32_t>(); if (i >= nerv) r.ok = false; }
    if (!r.ok) return nullptr;

    // the eye picture (flipped so its rows run the way the UVs do)
    int w = 0, h = 0, n = 0;
    if (unsigned char* px = stbi_load((dir + "/eye.png").c_str(), &w, &h, &n, 4)) {
        p->eyeImgW = w; p->eyeImgH = h;
        p->eyeImg.resize(size_t(w) * size_t(h) * 4);
        for (int y = 0; y < h; ++y) std::memcpy(&p->eyeImg[size_t(y) * size_t(w) * 4], px + size_t(h - 1 - y) * size_t(w) * 4, size_t(w) * 4);
        stbi_image_free(px);
    }
    std::vector<char> isBody(nbase, 0);
    for (std::uint32_t i : p->tris[0]) isBody[p->rvBase[i]] = 1;
    float lo = 1e9f, hi = -1e9f;
    for (std::uint32_t i = 0; i < nbase; ++i) if (isBody[i]) { p->bodyVerts.push_back(i); lo = std::min(lo, p->base[i].y); hi = std::max(hi, p->base[i].y); }
    p->neutralHeight = hi - lo;
    p->neighbours.resize(nbase);
    for (size_t t = 0; t + 2 < p->tris[0].size(); t += 3)
        for (int k = 0; k < 3; ++k) {
            const std::uint32_t a = p->rvBase[p->tris[0][t + size_t(k)]], b = p->rvBase[p->tris[0][t + size_t((k + 1) % 3)]];
            auto& na = p->neighbours[a];
            if (std::find(na.begin(), na.end(), b) == na.end()) na.push_back(b);
            auto& nb = p->neighbours[b];
            if (std::find(nb.begin(), nb.end(), a) == nb.end()) nb.push_back(a);
        }
    return p;
}

const Pack* pack() {
    static std::unique_ptr<Pack> p = loadPack();
    return p.get();
}

glm::vec3 jointOf(const Pack& pk, const std::vector<glm::vec3>& pos, const std::string& name) {
    auto it = pk.joints.find(name);
    if (it == pk.joints.end() || it->second.empty()) return glm::vec3(0.0f);
    glm::vec3 s(0.0f);
    for (std::uint32_t i : it->second) s += pos[i];
    return s / float(it->second.size());
}

void applyTarget(const Pack& pk, std::vector<glm::vec3>& pos, const std::string& name, float w) {
    if (std::fabs(w) < 1e-4f) return;
    auto it = pk.targets.find(name);
    if (it == pk.targets.end()) return;
    const Target& t = it->second;
    for (size_t k = 0; k < t.idx.size(); ++k) pos[t.idx[k]] += t.d[k] * w;
}

// ---------------------------------------------------------------- shaping (MakeHuman's macro weights)

struct Weighted { std::string name; float w; };

std::vector<Weighted> shapeTargets(const CharacterDef& c) {
    const HumanLook& l = c.look;
    std::vector<Weighted> out;
    const float gw[2] = { 1.0f - l.gender, l.gender };
    const char* gn[2] = { "female", "male" };
    float aw[3];                                  // child, young, old
    if (l.age < 0.5f) {
        const float young = std::clamp((l.age - 0.1875f) * 3.2f, 0.0f, 1.0f);
        aw[0] = 1.0f - young; aw[1] = young; aw[2] = 0.0f;
    } else {
        aw[2] = std::clamp(l.age * 2.0f - 1.0f, 0.0f, 1.0f); aw[1] = 1.0f - aw[2]; aw[0] = 0.0f;
    }
    const char* an[3] = { "child", "young", "old" };
    auto three = [](float v, float out3[3]) {
        if (v < 0.5f) { out3[0] = 1.0f - v * 2.0f; out3[1] = v * 2.0f; out3[2] = 0.0f; }
        else { out3[0] = 0.0f; out3[2] = v * 2.0f - 1.0f; out3[1] = 1.0f - out3[2]; }
    };
    float mw[3], ww[3];
    three(l.muscle, mw); three(l.weight, ww);
    const char* mn[3] = { "minmuscle", "averagemuscle", "maxmuscle" };
    const char* wn[3] = { "minweight", "averageweight", "maxweight" };
    for (int g = 0; g < 2; ++g) for (int a = 0; a < 3; ++a) for (int m = 0; m < 3; ++m) for (int w = 0; w < 3; ++w) {
        const float k = gw[g] * aw[a] * mw[m] * ww[w];
        if (k > 1e-4f) out.push_back({ std::string("universal-") + gn[g] + "-" + an[a] + "-" + mn[m] + "-" + wn[w], k });
    }
    const char* en[3] = { "african", "asian", "caucasian" };
    for (int e = 0; e < 3; ++e) for (int g = 0; g < 2; ++g) for (int a = 0; a < 3; ++a) {
        const float k = l.heritage[size_t(e)] * gw[g] * aw[a];
        if (k > 1e-4f) out.push_back({ std::string(en[e]) + "-" + gn[g] + "-" + an[a], k });
    }
    // the face: the character's styles...
    auto face = [&](const char* n, float w) { out.push_back({ std::string("face:") + n, w }); };
    switch (c.face.eyes) {
    case 1: face("eyes-open-big", 0.6f); break;                                   // round
    case 2: face("eyes-open-small", 0.6f); face("eyes-up", 0.35f); break;         // narrow
    case 3: face("eyes-open-small", 0.45f); face("eyes-down", 0.5f); break;       // sleepy
    case 4: face("eyes-big", 0.5f); face("eyes-open-big", 0.6f); break;           // wide
    default: break;                                                               // natural
    }
    switch (c.face.nose) {
    case 0: face("nose-small", 0.5f); break;
    case 1: face("nose-wide", 0.6f); break;
    case 2: face("nose-long", 0.7f); face("nose-hump", 0.35f); break;
    case 3: face("nose-point-up", 0.7f); face("nose-small", 0.3f); break;
    default: break;
    }
    if (c.face.brows == 2) face("brows-angle-down", 0.5f);
    if (c.face.brows == 3) face("brows-angle-up", 0.5f);
    // ...and the small differences that make two people with the same styles look like two people
    if (l.faceSeed) {
        std::uint32_t s = l.faceSeed;
        auto rnd = [&]() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return float(s & 0xFFFF) / 65535.0f * 2.0f - 1.0f; };
        static const char* pairs[] = { "mouth", "lips", "chin", "jaw", "cheeks", "ears", "nose", "eyes" };
        for (const char* p : pairs) {
            const float v = rnd() * 0.45f;
            face((std::string(p) + (v > 0.0f ? "-big" : "-small")).c_str(), std::fabs(v));
        }
        const float hs = rnd();
        face(hs < -0.33f ? "head-round" : hs < 0.33f ? "head-oval" : "head-square", 0.25f + 0.25f * std::fabs(rnd()));
        if (rnd() > 0.6f) face("nose-hump", 0.3f);
    }
    return out;
}

// ---------------------------------------------------------------- clothes

struct Garment {
    bool skin = true;
    bool rigid = false;             // drawn as its part (shoes, skirts): the body under it stays
    bool hideBody = false;          // the body under the part is hidden (feet in shoes)
    MaterialId mat = MAT_CLOTH;
    glm::vec3 tint{ 1.0f };
    glm::vec3 tint2{ 1.0f };        // stripes
    bool stripes = false;
    bool top = false;               // worn on the upper body (it hangs over the waistband of what is below)
    float thick = 0.004f;
    bool operator==(const Garment& o) const {           // the same cloth (a jacket and its sleeves): one layer, its thickness varying
        return skin == o.skin && rigid == o.rigid && mat == o.mat && tint == o.tint && tint2 == o.tint2 && stripes == o.stripes && top == o.top;
    }
};

MaterialId dominantMaterial(const Asset& a) {
    std::map<int, int> count;
    for (const Vertex& v : a.mesh) ++count[v.layers[0]];
    int best = -1, n = 0;
    for (auto [k, c] : count) if (c > n) { best = k; n = c; }
    return best < 0 ? MaterialId(MAT_CLOTH) : MaterialId(best + 1);
}

bool skirted(const CharacterDef& c) {
    const std::string& h = c.parts[size_t(PartSlot::Hips)];
    return h == "hips skirt" || h == "hips robe";
}

Garment garmentFor(const CharacterDef& c, PartSlot slot, AssetLibrary& lib) {
    Garment g;
    const std::string& own = c.parts[size_t(slot)];
    const std::string name = own.empty() ? builtinPartName(slot, c.hair) : own;
    const glm::vec3 top = c.colourOf(slot, ColourRole::Top), bottoms = c.colourOf(slot, ColourRole::Bottoms);
    const glm::vec3 accent = c.colourOf(slot, ColourRole::Accent);
    auto cloth = [&](glm::vec3 t, float thick) { g.skin = false; g.mat = MAT_CLOTH; g.tint = t; g.thick = thick; };
    switch (slot) {
    case PartSlot::Torso:
        if (name == "body torso") cloth(top, 0.011f);
        else if (name == "torso striped") { cloth(top, 0.011f); g.stripes = true; g.tint2 = accent; }
        else if (name == "torso jacket") cloth(top, 0.018f);
        else if (name == "torso vest") cloth(top, 0.013f);
        else if (name == "torso coat") cloth(top, 0.022f);
        else if (name == "torso armour") { g.skin = false; g.mat = MAT_METAL; g.tint = accent; g.thick = 0.02f; }
        else break;
        return g;
    case PartSlot::UpperArm:
        if (name == "body upper arm") { cloth(top, 0.012f); return g; }
        if (name == "upper arm bare") return g;
        break;
    case PartSlot::LowerArm:
        if (name == "body lower arm") return g;
        break;
    case PartSlot::Hand:
        if (name == "body hand") return g;
        break;
    case PartSlot::Neck:
        if (name == "body neck") return g;
        break;
    case PartSlot::Hips:
        if (name == "body hips") { cloth(bottoms, 0.009f); return g; }
        if (name == "hips skirt" || name == "hips robe") { cloth(bottoms, 0.006f); return g; }   // the skirt itself is made below (1.6)
        break;
    case PartSlot::UpperLeg:
        if (name == "body upper leg" && skirted(c)) return g;        // bare legs under a skirt or robe
        if (name == "body upper leg") { cloth(bottoms, 0.016f); return g; }
        break;
    case PartSlot::LowerLeg:
        if (name == "body lower leg" && skirted(c)) return g;
        if (name == "body lower leg") { cloth(bottoms, 0.03f); return g; }
        if (name == "lower leg bare") return g;
        break;
    case PartSlot::Foot:
        g.rigid = true; g.hideBody = true;                 // shoes and boots stay the parts they are
        return g;
    default:
        return g;
    }
    // a part of your own: what it is mostly made of decides (skin: the body shows; anything else: a close-fitting layer)
    AssetPtr a = lib.get(name);
    if (!a || a->mesh.empty()) return g;
    const MaterialId m = dominantMaterial(*a);
    if (m == MAT_SKIN) return g;
    g.skin = false;
    g.mat = m;
    g.tint = partTint(c, slot, name, *a, lib);
    g.thick = 0.008f;
    if (slot == PartSlot::Torso && a->size.y * a->voxelSize > 0.7f) { g.rigid = true; }   // something long (a coat, a dress): as itself
    return g;
}

PartSlot slotOfBone(int b) { return slotForBone(Bone(b)); }

std::string keyFor(const CharacterDef& c, const Skeleton& sk) {
    std::string k;
    char buf[256];
    const HumanLook& l = c.look;
    std::snprintf(buf, sizeof buf, "%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%u|%d%d%d%d|", double(l.gender), double(l.age), double(l.muscle), double(l.weight),
                  double(l.heritage[0]), double(l.heritage[1]), double(l.heritage[2]), l.faceSeed, c.face.eyes, c.face.brows, c.face.nose, c.face.mouth);
    k += buf;
    for (const glm::vec3& col : c.colours) { std::snprintf(buf, sizeof buf, "%.3f,%.3f,%.3f;", double(col.x), double(col.y), double(col.z)); k += buf; }
    for (int i = 0; i < kPartSlotCount; ++i) {
        k += c.parts[size_t(i)];
        const glm::vec4& pc = c.partColour[size_t(i)];
        std::snprintf(buf, sizeof buf, "#%.3f,%.3f,%.3f,%.1f;", double(pc.x), double(pc.y), double(pc.z), double(pc.w));
        k += buf;
    }
    k += std::to_string(int(c.hair));
    for (int b = 0; b < kBoneCount; ++b) {
        const glm::vec3 o = sk.bone(Bone(b)).offset;
        std::snprintf(buf, sizeof buf, "%.4f,%.4f,%.4f;", double(o.x), double(o.y), double(o.z));
        k += buf;
    }
    std::snprintf(buf, sizeof buf, "%.4f,%.4f,%.3f", double(sk.height), double(sk.ankleHeight), double(c.shape.head));
    k += buf;
    return k;
}

std::unordered_map<std::string, std::shared_ptr<HumanBody>>& cache() {
    static std::unordered_map<std::string, std::shared_ptr<HumanBody>> c;
    return c;
}

// The rotation that takes a MakeHuman limb (its direction `along`, and a direction `fwd` that should end up in front) to
// the skeleton's rest frame, where limbs hang down (-y) and face forward (+z).
glm::mat3 limbFrame(const glm::vec3& along, const glm::vec3& fwd) {
    const glm::vec3 y = -glm::normalize(along);
    glm::vec3 z = fwd - y * glm::dot(fwd, y);
    z = glm::length(z) > 1e-6f ? glm::normalize(z) : glm::vec3(0.0f, 0.0f, 1.0f);
    const glm::vec3 x = glm::cross(y, z);
    return glm::transpose(glm::mat3(x, y, z));
}

// ---------------------------------------------------------------- hair

// The skull as an ellipsoid (head bone space), with how far the real surface lies from its middle in every direction.
struct HeadShape {
    glm::vec3 C{ 0.0f }, R{ 0.1f };
    static constexpr int kA = 48, kE = 24;
    std::array<float, kA * kE> r{};
    static int bin(const glm::vec3& u, int& e) {
        const float th = std::atan2(u.x, u.z);
        const int a = std::clamp(int((th + 3.14159265f) / 6.2831853f * float(kA)), 0, kA - 1);
        e = std::clamp(int((u.y * 0.5f + 0.5f) * float(kE)), 0, kE - 1);
        return a;
    }
    float radius(const glm::vec3& u) const { int e; const int a = bin(u, e); return r[size_t(a * kE + e)]; }
    glm::vec3 dirOf(const glm::vec3& p) const { const glm::vec3 d = (p - C) / R; const float l = glm::length(d); return l > 1e-6f ? d / l : glm::vec3(0, 1, 0); }
    float depth(const glm::vec3& p) const { return glm::length((p - C) / R); }   // 1 on the ellipsoid
    glm::vec3 normal(const glm::vec3& u) const { return glm::normalize(u / R); }
    glm::vec3 surface(const glm::vec3& u, float lift) const { return C + R * u * radius(u) + normal(u) * lift; }
    // where the hair grows, seen from the middle: high at the forehead, down to the ears, low at the nape
    static float hairline(const glm::vec3& u) {
        const float c = u.z / std::max(glm::length(glm::vec2(u.x, u.z)), 1e-5f);
        return c > 0.0f ? 0.42f * std::pow(c, 1.4f) - 0.02f : -0.5f * std::pow(-c, 0.8f);
    }
    float scalp(const glm::vec3& p) const {
        const glm::vec3 u = dirOf(p);
        if (depth(p) > radius(u) * 1.04f + 0.02f) return 0.0f;        // the ears stick out: no hair on them
        const float hl = hairline(u);
        const float t = std::clamp((u.y - (hl - 0.04f)) / 0.1f, 0.0f, 1.0f);
        return t * t * (3.0f - 2.0f * t);
    }
};

HeadShape headShape(const std::vector<glm::vec3>& headPts, float eyeY) {
    HeadShape h;
    float yhi = -1e9f;
    glm::vec3 lo(1e9f), hi(-1e9f);
    for (const glm::vec3& q : headPts) yhi = std::max(yhi, q.y);
    const float cut = eyeY + 0.015f;
    for (const glm::vec3& q : headPts) if (q.y > cut) { lo = glm::min(lo, q); hi = glm::max(hi, q); }
    h.C = glm::vec3((lo.x + hi.x) * 0.5f, eyeY + 0.02f, (lo.z + hi.z) * 0.5f + 0.004f);
    h.R = glm::vec3((hi.x - lo.x) * 0.5f * 0.97f, std::max(yhi - h.C.y, 0.05f), (hi.z - lo.z) * 0.5f);
    h.r.fill(0.0f);
    for (const glm::vec3& q : headPts) {
        const glm::vec3 d = (q - h.C) / h.R;
        const float l = glm::length(d);
        if (l < 1e-6f) continue;
        int e; const int a = HeadShape::bin(d / l, e);
        float& slot = h.r[size_t(a * HeadShape::kE + e)];
        slot = std::max(slot, std::min(l, 1.25f));
    }
    for (int pass = 0; pass < 6; ++pass)                                // fill directions nothing landed in
        for (int a = 0; a < HeadShape::kA; ++a)
            for (int e = 0; e < HeadShape::kE; ++e) {
                float& v = h.r[size_t(a * HeadShape::kE + e)];
                if (v > 0.0f) continue;
                float sum = 0.0f; int n = 0;
                for (int da = -1; da <= 1; ++da) for (int de = -1; de <= 1; ++de) {
                    const int aa = (a + da + HeadShape::kA) % HeadShape::kA, ee = std::clamp(e + de, 0, HeadShape::kE - 1);
                    const float w = h.r[size_t(aa * HeadShape::kE + ee)];
                    if (w > 0.0f) { sum += w; ++n; }
                }
                if (n) v = sum / float(n);
            }
    for (float& v : h.r) if (v <= 0.0f) v = 1.0f;
    return h;
}

struct Strand { std::vector<glm::vec3> p; float width; };

struct HairRng {
    std::uint32_t s;
    explicit HairRng(std::uint32_t seed) : s(seed * 747796405u + 2891336453u) { next(); }
    std::uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float f() { return float(next() & 0xFFFFFF) / float(0x1000000); }
    float range(float a, float b) { return a + (b - a) * f(); }
    glm::vec3 dir() {
        for (;;) { const glm::vec3 v(range(-1, 1), range(-1, 1), range(-1, 1)); const float l = glm::length(v); if (l > 0.05f && l <= 1.0f) return v / l; }
    }
};

glm::vec3 tangentOf(const glm::vec3& v, const glm::vec3& n) {
    const glm::vec3 t = v - n * glm::dot(v, n);
    return glm::length(t) > 1e-6f ? glm::normalize(t) : glm::vec3(0.0f, -1.0f, 0.0f);
}

// The strands of a hair style, in head bone space. `capped`: under a hat that covers the hair (only what shows below it).
std::vector<Strand> growHair(HairStyle style, const HeadShape& hs, std::uint32_t seed, bool capped) {
    std::vector<Strand> out;
    if (style == HairStyle::None || style == HairStyle::Count) return out;
    HairRng rng(seed ^ (std::uint32_t(style) * 0x9E3779B9u));
    const glm::vec3 whorl = glm::normalize(glm::vec3(0.0f, 0.8f, -0.6f));
    const float headSize = (hs.R.x + hs.R.z) * 0.5f;                     // about 0.09 m on an adult
    auto rootDir = [&](float maxUp, float xBand) -> glm::vec3 {
        for (int tries = 0; tries < 400; ++tries) {
            glm::vec3 u = rng.dir();
            if (u.y < HeadShape::hairline(u) + 0.02f) continue;
            if (u.y > maxUp) continue;
            if (xBand < 1.0f && std::fabs(u.x) > xBand) continue;
            return u;
        }
        return glm::vec3(0.0f, 1.0f, 0.0f);
    };
    const float capUp = capped ? 0.12f : 2.0f;
    // hugging the head: each step lands back on the surface, `lift` above it
    auto hug = [&](glm::vec3 u, float lift, float length, int segs, auto&& flow, float wobble, float stopDot, const glm::vec3& stopAt) {
        Strand st;
        glm::vec3 p = hs.surface(u, lift);
        st.p.push_back(p);
        glm::vec3 dir = tangentOf(flow(u), hs.normal(u));
        const float step = length / float(segs);
        const float phase = rng.range(0.0f, 6.28f);
        for (int k = 0; k < segs; ++k) {
            p += dir * step;
            u = hs.dirOf(p);
            if (stopDot < 1.0f && glm::dot(u, stopAt) > stopDot) { st.p.push_back(hs.surface(u, lift)); break; }
            glm::vec3 q = hs.surface(u, lift);
            if (wobble > 0.0f) q += glm::cross(dir, hs.normal(u)) * std::sin(phase + float(k) * 1.9f) * wobble;
            st.p.push_back(q);
            dir = tangentOf(glm::normalize(dir * 0.6f + tangentOf(flow(u), hs.normal(u)) * 0.4f), hs.normal(u));
        }
        return st;
    };
    auto falls = [&](Strand st, float length, int segs, const glm::vec3& drift) {   // on from the end, falling
        if (st.p.size() < 2) return st;
        glm::vec3 p = st.p.back(), dir = glm::normalize(st.p.back() - st.p[st.p.size() - 2]);
        const float step = length / float(segs);
        for (int k = 0; k < segs; ++k) {
            dir = glm::normalize(dir + glm::vec3(0.0f, -0.55f, 0.0f) + drift * 0.3f);
            if (p.z > hs.C.z - 0.02f) dir = glm::normalize(dir + glm::vec3(0.0f, 0.0f, -0.6f));   // the face stays clear
            p += dir * step;
            // keep outside the head, and below it outside a column as wide as the head (the neck and the back)
            const glm::vec3 u = hs.dirOf(p);
            if (p.y > hs.C.y) {
                const float need = hs.radius(u) + 0.012f / headSize * 0.09f;
                if (hs.depth(p) < need) p = hs.C + hs.R * u * need;
            } else {
                glm::vec2 xz((p.x - hs.C.x) / hs.R.x, (p.z - hs.C.z) / hs.R.z);
                const float l = glm::length(xz);
                if (l < 1.05f && l > 1e-5f) { xz *= 1.05f / l; p.x = hs.C.x + xz.x * hs.R.x; p.z = hs.C.z + xz.y * hs.R.z; }
            }
            st.p.push_back(p);
        }
        return st;
    };
    const float k = headSize / 0.09f;                                   // lengths scale with the head (a child's hair is shorter)
    switch (style) {
    case HairStyle::Short: {
        auto flow = [&](const glm::vec3& u) { return u - whorl * 1.2f + glm::vec3(0.0f, 0.0f, u.z > 0.55f ? 0.6f : 0.0f); };
        for (int i = 0; i < 1300; ++i) {
            const glm::vec3 u = rootDir(capUp, 1.0f);
            const float len = (u.z > 0.5f ? rng.range(0.025f, 0.04f) : rng.range(0.035f, 0.055f)) * k;
            Strand st = hug(u, rng.range(0.003f, 0.011f) * k, len, 4, flow, 0.0f, 1.0f, glm::vec3(0.0f));
            st.width = rng.range(0.009f, 0.013f) * k;
            out.push_back(std::move(st));
        }
        break;
    }
    case HairStyle::Curly: {
        auto flow = [&](const glm::vec3& u) { return u - whorl + glm::vec3(0.0f, -0.4f, 0.0f); };
        for (int i = 0; i < 1500; ++i) {
            const glm::vec3 u = rootDir(capUp, 1.0f);
            Strand st = hug(u, rng.range(0.008f, 0.03f) * k, rng.range(0.05f, 0.08f) * k, 7, flow, 0.008f * k, 1.0f, glm::vec3(0.0f));
            st.width = rng.range(0.01f, 0.015f) * k;
            out.push_back(std::move(st));
        }
        break;
    }
    case HairStyle::Long: case HairStyle::Ponytail: case HairStyle::Bun: {
        const bool pony = style == HairStyle::Ponytail, bun = style == HairStyle::Bun;
        const glm::vec3 tie = glm::normalize(pony ? glm::vec3(0.0f, 0.15f, -1.0f) : glm::vec3(0.0f, 0.55f, -0.83f));
        auto flow = [&](const glm::vec3& u) -> glm::vec3 {
            if (pony || bun) return tie - u;                               // gathered back
            // a middle parting: from the forehead up, back over the top, then down the back and sides
            const float side = u.x >= 0.0f ? 1.0f : -1.0f;
            if (u.z > 0.25f && u.y < 0.75f) return glm::vec3(side * 0.3f, 0.7f, -0.8f);
            if (u.y > 0.35f) return glm::vec3(side * 0.3f, 0.0f, -1.0f);
            return glm::vec3(side * 0.15f, -0.55f, -1.0f);                // behind the ears, never down over the face
        };
        for (int i = 0; i < 1300; ++i) {
            const glm::vec3 u = rootDir(capUp, 1.0f);
            Strand st = hug(u, rng.range(0.003f, 0.01f) * k, (pony || bun) ? 0.22f * k : rng.range(0.16f, 0.22f) * k, pony || bun ? 7 : 7, flow, 0.0f,
                            (pony || bun) ? 0.93f : 1.0f, tie);
            if (style == HairStyle::Long) st = falls(st, rng.range(0.14f, 0.24f) * k, 7, glm::vec3(0.0f, 0.0f, -0.6f));
            st.width = rng.range(0.012f, 0.017f) * k;
            out.push_back(std::move(st));
        }
        const glm::vec3 knot = hs.surface(tie, (bun ? 0.028f : 0.008f) * k);
        if (pony) {                                                        // the tail
            for (int i = 0; i < 160; ++i) {
                Strand st;
                const glm::vec3 off = rng.dir() * 0.008f * k;
                glm::vec3 p = knot + off;
                st.p.push_back(p);
                glm::vec3 dir = glm::normalize(glm::vec3(rng.range(-0.15f, 0.15f), 0.25f, -1.0f));
                const float len = rng.range(0.2f, 0.3f) * k;
                for (int s2 = 0; s2 < 9; ++s2) {
                    dir = glm::normalize(dir + glm::vec3(0.0f, -0.45f, 0.0f));
                    p += dir * (len / 9.0f) + glm::vec3(off.x, 0.0f, 0.0f) * 0.15f;
                    st.p.push_back(p);
                }
                st.width = rng.range(0.012f, 0.016f) * k;
                out.push_back(std::move(st));
            }
        }
        if (bun) {                                                         // the knot: strands wound round it
            const float rb = 0.034f * k;
            for (int i = 0; i < 90; ++i) {
                Strand st;
                const glm::vec3 a1 = rng.dir(), a2 = glm::normalize(glm::cross(a1, rng.dir()));
                const glm::vec3 a3 = glm::cross(a1, a2);
                const float r = rb * rng.range(0.75f, 1.0f), t0 = rng.range(0.0f, 6.28f);
                for (int s2 = 0; s2 <= 10; ++s2) {
                    const float t = t0 + float(s2) * 0.6f;
                    st.p.push_back(knot + (a2 * std::cos(t) + a3 * std::sin(t)) * r);
                }
                st.width = rng.range(0.014f, 0.02f) * k;
                out.push_back(std::move(st));
            }
        }
        break;
    }
    case HairStyle::Spiky: case HairStyle::Mohawk: {
        const bool mohawk = style == HairStyle::Mohawk;
        const int tufts = mohawk ? 26 : 70;
        for (int t = 0; t < tufts; ++t) {
            const glm::vec3 u = rootDir(capUp, mohawk ? 0.16f : 1.0f);
            const glm::vec3 n = hs.normal(u);
            const glm::vec3 lean = mohawk ? glm::vec3(0.0f, 0.25f, -0.35f) : tangentOf(u - whorl, n) * 0.35f + glm::vec3(0.0f, 0.35f, 0.0f);
            const glm::vec3 tip = hs.surface(u, 0.0f) + glm::normalize(n + lean + rng.dir() * 0.15f) * (mohawk ? rng.range(0.07f, 0.1f) : rng.range(0.04f, 0.065f)) * k;
            for (int i = 0; i < 9; ++i) {
                glm::vec3 v = glm::normalize(u + rng.dir() * 0.12f);
                if (v.y < HeadShape::hairline(v)) v = u;
                Strand st;
                const glm::vec3 root = hs.surface(v, 0.002f * k);
                for (int s2 = 0; s2 <= 4; ++s2) st.p.push_back(glm::mix(root, tip, float(s2) / 4.0f));
                st.width = rng.range(0.008f, 0.012f) * k;
                out.push_back(std::move(st));
            }
        }
        // the rest of the head: very short (cropped sides)
        for (int i = 0; i < (mohawk ? 500 : 700); ++i) {
            const glm::vec3 u = rootDir(capUp, 1.0f);
            if (mohawk && std::fabs(u.x) < 0.16f) continue;
            Strand st = hug(u, 0.002f * k, 0.014f * k, 2, [&](const glm::vec3& w) { return w - whorl; }, 0.0f, 1.0f, glm::vec3(0.0f));
            st.width = 0.008f * k;
            out.push_back(std::move(st));
        }
        break;
    }
    default: break;
    }
    return out;
}

} // namespace

// ---------------------------------------------------------------- the switch

bool humanBodyAvailable() { return pack() != nullptr; }
void setRealisticPeople(bool on) { gRealistic = on; }
bool realisticPeople() { return gRealistic; }
bool usesHumanBody(const CharacterDef& c) {
    return gRealistic && c.parts[size_t(PartSlot::Head)].empty() && humanBodyAvailable();
}

// ---------------------------------------------------------------- building a body

std::shared_ptr<HumanBody> buildHumanBody(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib) {
    const Pack* pkp = pack();
    if (!pkp) return nullptr;
    const Pack& pk = *pkp;
    const size_t nbase = pk.base.size();

    // 1. the shape: MakeHuman's targets for this look
    std::vector<glm::vec3> P = pk.base;
    for (const Weighted& t : shapeTargets(c)) applyTarget(pk, P, t.name, t.w);

    // 2. the size: feet on the ground, as tall as the skeleton
    float lo = 1e9f, hi = -1e9f;
    for (std::uint32_t i : pk.bodyVerts) { lo = std::min(lo, P[i].y); hi = std::max(hi, P[i].y); }
    const float s = sk.height / std::max(hi - lo, 0.1f);
    for (glm::vec3& v : P) v = (v - glm::vec3(0.0f, lo, 0.0f)) * s;

    // 3. the joints, and how each bone of the skeleton takes its piece of the body
    auto J = [&](const char* n) { return jointOf(pk, P, n); };
    struct Side { glm::vec3 hip, knee, ankle, toe, shoulder, elbow, wrist, knuckle, index, pinky; };
    Side sd[2];
    for (int k = 0; k < 2; ++k) {
        const std::string x = k == 0 ? ".L" : ".R";
        auto j = [&](const std::string& n) { return jointOf(pk, P, n); };
        sd[k] = { j("upperleg01" + x + ":head"), j("lowerleg01" + x + ":head"), j("foot" + x + ":head"), j("toe3-1" + x + ":head"),
                  j("upperarm01" + x + ":head"), j("lowerarm01" + x + ":head"), j("wrist" + x + ":head"), j("finger3-1" + x + ":head"),
                  j("finger2-1" + x + ":head"), j("finger5-1" + x + ":head") };
    }
    const glm::vec3 pelvis = glm::vec3(0.0f, (sd[0].hip.y + sd[1].hip.y) * 0.5f, (sd[0].hip.z + sd[1].hip.z) * 0.5f);
    const glm::vec3 chest = pelvis + glm::vec3(0.0f, sk.bone(Bone::Chest).offset.y, 0.0f);
    const glm::vec3 neck = J("neck01:head"), head = J("head:head");
    std::array<glm::vec3, kBoneCount> at{};
    std::array<glm::mat3, kBoneCount> rot;
    std::array<glm::vec3, kBoneCount> scl;
    rot.fill(glm::mat3(1.0f));
    scl.fill(glm::vec3(1.0f));
    at[size_t(Bone::Pelvis)] = pelvis; at[size_t(Bone::Chest)] = chest; at[size_t(Bone::Neck)] = neck; at[size_t(Bone::Head)] = head;
    auto ratio = [](float ours, float theirs) { return std::clamp(ours / std::max(theirs, 1e-4f), 0.4f, 2.5f); };
    scl[size_t(Bone::Pelvis)].x = ratio(sk.bone(Bone::UpperLegL).offset.x, std::fabs(sd[0].hip.x - pelvis.x));
    scl[size_t(Bone::Chest)].x = ratio(sk.bone(Bone::UpperArmL).offset.x, std::fabs(sd[0].shoulder.x - chest.x));
    scl[size_t(Bone::Chest)].y = ratio(sk.bone(Bone::Neck).offset.y, neck.y - chest.y);
    scl[size_t(Bone::Neck)].y = ratio(sk.bone(Bone::Head).offset.y, head.y - neck.y);
    scl[size_t(Bone::Head)] = glm::vec3(1.0f + (c.shape.head - 1.0f) * 0.4f);
    for (int k = 0; k < 2; ++k) {
        const Side& q = sd[k];
        const Bone up = k == 0 ? Bone::UpperArmL : Bone::UpperArmR, lo2 = k == 0 ? Bone::LowerArmL : Bone::LowerArmR, hand = k == 0 ? Bone::HandL : Bone::HandR;
        const Bone th = k == 0 ? Bone::UpperLegL : Bone::UpperLegR, sh = k == 0 ? Bone::LowerLegL : Bone::LowerLegR, foot = k == 0 ? Bone::FootL : Bone::FootR;
        const glm::vec3 thumbward = q.index - q.pinky, toeward = q.toe - q.ankle;
        at[size_t(up)] = q.shoulder; rot[size_t(up)] = limbFrame(q.elbow - q.shoulder, q.wrist - q.elbow);
        at[size_t(lo2)] = q.elbow; rot[size_t(lo2)] = limbFrame(q.wrist - q.elbow, thumbward);
        at[size_t(hand)] = q.wrist; rot[size_t(hand)] = limbFrame(q.knuckle - q.wrist, thumbward);
        at[size_t(th)] = q.hip; rot[size_t(th)] = limbFrame(q.knee - q.hip, toeward);
        at[size_t(sh)] = q.knee; rot[size_t(sh)] = limbFrame(q.ankle - q.knee, toeward);
        at[size_t(foot)] = q.ankle;
        scl[size_t(up)].y = ratio(glm::length(sk.bone(lo2).offset), glm::length(q.elbow - q.shoulder));
        scl[size_t(lo2)].y = ratio(glm::length(sk.bone(hand).offset), glm::length(q.wrist - q.elbow));
        scl[size_t(th)].y = ratio(glm::length(sk.bone(sh).offset), glm::length(q.knee - q.hip));
        scl[size_t(sh)].y = ratio(glm::length(sk.bone(foot).offset), glm::length(q.ankle - q.knee));
        scl[size_t(foot)].y = ratio(sk.ankleHeight, q.ankle.y);
    }
    auto body = std::make_shared<HumanBody>();
    auto mesh = std::make_shared<SkinnedMesh>();
    for (int b = 0; b < kMaxSkinBones; ++b)
        mesh->inverseBind[size_t(b)] = b < kBoneCount ? glm::scale(glm::mat4(1.0f), scl[size_t(b)]) * glm::mat4(rot[size_t(b)]) * glm::translate(glm::mat4(1.0f), -at[size_t(b)])
                                                      : glm::mat4(1.0f);
    mesh->expressionScale = s;

    // 4. smooth normals, per base vertex (so UV seams do not show)
    std::vector<glm::vec3> N(nbase, glm::vec3(0.0f));
    const auto& bt = pk.tris[0];
    for (size_t t = 0; t + 2 < bt.size(); t += 3) {
        const std::uint32_t a = pk.rvBase[bt[t]], b = pk.rvBase[bt[t + 1]], cc = pk.rvBase[bt[t + 2]];
        const glm::vec3 n = glm::cross(P[b] - P[a], P[cc] - P[a]);
        N[a] += n; N[b] += n; N[cc] += n;
    }
    for (int part = 1; part < 4; ++part) {
        const auto& tt = pk.tris[size_t(part)];
        for (size_t t = 0; t + 2 < tt.size(); t += 3) {
            const std::uint32_t a = pk.rvBase[tt[t]], b = pk.rvBase[tt[t + 1]], cc = pk.rvBase[tt[t + 2]];
            const glm::vec3 n = glm::cross(P[b] - P[a], P[cc] - P[a]);
            N[a] += n; N[b] += n; N[cc] += n;
        }
    }
    for (glm::vec3& n : N) n = glm::length(n) > 1e-12f ? glm::normalize(n) : glm::vec3(0.0f, 1.0f, 0.0f);

    // 5. what each bone wears
    std::array<Garment, kBoneCount> wear;
    for (int b = 0; b < kBoneCount; ++b) {
        wear[size_t(b)] = garmentFor(c, slotOfBone(b), lib);
        const PartSlot sl = slotOfBone(b);
        wear[size_t(b)].top = sl == PartSlot::Torso || sl == PartSlot::UpperArm || sl == PartSlot::LowerArm || sl == PartSlot::Neck || sl == PartSlot::Hand;
    }
    for (int b = 0; b < kBoneCount; ++b) {
        const PartSlot sl = slotOfBone(b);
        if (wear[size_t(b)].rigid && std::find(body->rigidSlots.begin(), body->rigidSlots.end(), sl) == body->rigidSlots.end()) body->rigidSlots.push_back(sl);
    }
    body->shoesAsParts = wear[size_t(Bone::FootL)].hideBody;
    // the distinct garments (trousers on the hips and both legs are one)
    std::vector<Garment> garments;
    std::array<int, kBoneCount> garmentOf{};
    for (int b = 0; b < kBoneCount; ++b) {
        garmentOf[size_t(b)] = -1;
        const Garment& g = wear[size_t(b)];
        if (g.skin) continue;
        auto it = std::find(garments.begin(), garments.end(), g);
        garmentOf[size_t(b)] = int(it - garments.begin());
        if (it == garments.end()) garments.push_back(g);
    }
    // per base vertex: how much of it each garment covers, and how much is hidden by shoes
    std::vector<std::array<float, 8>> cover(nbase), thickAt(nbase);
    std::vector<float> hidden(nbase, 0.0f), clothed(nbase, 0.0f);
    for (size_t i = 0; i < nbase; ++i) {
        cover[i].fill(0.0f);
        thickAt[i].fill(0.0f);
        for (int k = 0; k < 4; ++k) {
            const int b = pk.wBone[i][size_t(k)];
            const float w = float(pk.wVal[i][size_t(k)]) / 255.0f;
            const int g = garmentOf[size_t(b)];
            if (g >= 0 && g < 8) { cover[i][size_t(g)] += w; clothed[i] += w; thickAt[i][size_t(g)] += w * wear[size_t(b)].thick; }
            if (wear[size_t(b)].hideBody) hidden[i] += w;
        }
        for (size_t g = 0; g < 8; ++g) thickAt[i][g] = cover[i][g] > 1e-4f ? thickAt[i][g] / cover[i][g] : (g < garments.size() ? garments[g].thick : 0.004f);
    }
    // a top hangs a hand's width below the waist, over the trousers
    if (const int topG = garmentOf[size_t(Bone::Chest)]; topG >= 0 && topG < 8 && garmentOf[size_t(Bone::Pelvis)] != topG) {
        const float waist = chest.y;
        for (size_t i = 0; i < nbase; ++i) {
            float pw = 0.0f;
            for (int k = 0; k < 4; ++k) if (pk.wBone[i][size_t(k)] == std::uint8_t(Bone::Pelvis)) pw += float(pk.wVal[i][size_t(k)]) / 255.0f;
            if (pw <= 0.0f) continue;
            const float hang = pw * sstep(waist - 0.12f * s / 1.8f, waist - 0.07f * s / 1.8f, P[i].y);
            if (hang <= 0.0f) continue;
            const float before = cover[i][size_t(topG)];
            cover[i][size_t(topG)] = std::min(1.0f, before + hang);
            const float over = (garmentOf[size_t(Bone::Pelvis)] >= 0 ? wear[size_t(Bone::Pelvis)].thick : 0.0f) + 0.005f;
            thickAt[i][size_t(topG)] = glm::mix(thickAt[i][size_t(topG)], std::max(thickAt[i][size_t(topG)], over), std::min(1.0f, hang * 2.0f));
        }
    }

    // 5b. the head: its shape in head bone space, for the hair (and the scalp under it, as a thin layer in the hair colour)
    const glm::mat4 toHead = mesh->inverseBind[size_t(Bone::Head)];
    const glm::mat4 fromHead = glm::inverse(toHead);
    std::vector<glm::vec3> headPts;
    for (std::uint32_t i : pk.bodyVerts) {
        int hw = 0;
        for (int k = 0; k < 4; ++k) if (pk.wBone[i][size_t(k)] == std::uint8_t(Bone::Head)) hw += pk.wVal[i][size_t(k)];
        if (hw >= 230) headPts.push_back(glm::vec3(toHead * glm::vec4(P[i], 1.0f)));
    }
    const HeadShape hs = headShape(headPts, glm::vec3(toHead * glm::vec4(jointOf(pk, P, "eye.L:head"), 1.0f)).y);
    const bool cardHair = c.parts[size_t(PartSlot::Hair)].empty() && c.hair != HairStyle::None;
    bool hatCovers = false;
    if (const std::string hat = partAssetFor(c, PartSlot::Hat); !hat.empty())
        if (AssetPtr h = lib.get(hat)) hatCovers = std::find(h->tags.begin(), h->tags.end(), "covers:hair") != h->tags.end();
    const glm::vec3 hairColour = c.colourOf(PartSlot::Hair, ColourRole::Hair);
    if (cardHair && garments.size() < 8) {
        Garment scalpLayer;
        scalpLayer.skin = false; scalpLayer.mat = MAT_HAIR; scalpLayer.tint = hairColour; scalpLayer.thick = 0.0012f;
        const size_t gi = garments.size();
        garments.push_back(scalpLayer);
        for (size_t i = 0; i < nbase; ++i) {
            int hw = 0;
            for (int k = 0; k < 4; ++k) if (pk.wBone[i][size_t(k)] == std::uint8_t(Bone::Head)) hw += pk.wVal[i][size_t(k)];
            if (hw < 200) continue;
            float sc = hs.scalp(glm::vec3(toHead * glm::vec4(P[i], 1.0f)));
            if (c.hair == HairStyle::Mohawk || c.hair == HairStyle::Spiky) sc *= 0.0f;   // cropped: the skin shows (the short strands do the rest)
            cover[i][gi] = sc;
            thickAt[i][gi] = scalpLayer.thick;
        }
    }

    // 6. the vertices and triangles
    auto putVertex = [&](const glm::vec3& p, const glm::vec3& n, std::uint32_t baseIdx, MaterialId mat, const glm::vec3& tint, const glm::vec4& extra) {
        SkinVertex sv{};
        sv.v.position = p;
        sv.v.normal = n;
        sv.v.ao = 1.0f;
        const std::uint8_t layer = std::uint8_t(mat - 1);
        sv.v.layers[0] = sv.v.layers[1] = sv.v.layers[2] = layer; sv.v.layers[3] = 0;
        sv.v.bary[0] = 255; sv.v.bary[1] = 0; sv.v.bary[2] = 0; sv.v.bary[3] = 0;
        int given = 0;
        if (baseIdx == 0xFFFFFFFFu) {                               // eyes: the head alone
            sv.bones[0] = std::uint8_t(Bone::Head); sv.weights[0] = 255;
            for (int k = 1; k < 4; ++k) { sv.bones[k] = 0; sv.weights[k] = 0; }
        } else {
            for (int k = 0; k < 4; ++k) { sv.bones[k] = pk.wBone[baseIdx][size_t(k)]; sv.weights[k] = pk.wVal[baseIdx][size_t(k)]; given += sv.weights[k]; }
            if (given == 0) { sv.bones[0] = std::uint8_t(Bone::Chest); sv.weights[0] = 255; }
        }
        const glm::vec3 t = glm::clamp(tint, glm::vec3(0.0f), glm::vec3(1.0f));
        sv.tint[0] = std::uint8_t(std::lround(t.x * 255.0f)); sv.tint[1] = std::uint8_t(std::lround(t.y * 255.0f));
        sv.tint[2] = std::uint8_t(std::lround(t.z * 255.0f)); sv.tint[3] = 255;
        mesh->vertices.push_back(sv);
        mesh->extra.push_back(extra);
        return std::uint32_t(mesh->vertices.size() - 1);
    };
    const glm::vec3 skinTint = c.colourOf(PartSlot::Head, ColourRole::Skin);
    // the skin (render vertices, as many as the pack has; unused ones are harmless)
    std::vector<std::uint32_t> skinIndex(pk.rvBase.size());
    for (size_t r = 0; r < pk.rvBase.size(); ++r) {
        const std::uint32_t bi = pk.rvBase[r];
        skinIndex[r] = putVertex(P[bi], N[bi], bi, MAT_SKIN, skinTint, glm::vec4(pk.rvUv[r], float(bi), float(SurfaceMode::Skin)));
    }
    for (size_t t = 0; t + 2 < bt.size(); t += 3) {
        const std::uint32_t r0 = bt[t], r1 = bt[t + 1], r2 = bt[t + 2];
        const std::uint32_t b0 = pk.rvBase[r0], b1 = pk.rvBase[r1], b2 = pk.rvBase[r2];
        if (hidden[b0] > 0.5f && hidden[b1] > 0.5f && hidden[b2] > 0.5f) continue;           // in a shoe
        if (clothed[b0] > 0.85f && clothed[b1] > 0.85f && clothed[b2] > 0.85f) continue;     // under clothes
        mesh->indices.insert(mesh->indices.end(), { skinIndex[r0], skinIndex[r1], skinIndex[r2] });
    }
    // teeth and tongue (MakeHuman's lash helpers are fitting guides, not lashes: they are left out)
    for (int part = 1; part < 3; ++part) {
        const SurfaceMode mode = part == 1 ? SurfaceMode::Teeth : part == 2 ? SurfaceMode::Tongue : SurfaceMode::Lashes;
        std::unordered_map<std::uint32_t, std::uint32_t> made;
        for (std::uint32_t r : pk.tris[size_t(part)]) {
            auto it = made.find(r);
            if (it == made.end()) {
                const std::uint32_t bi = pk.rvBase[r];
                it = made.emplace(r, putVertex(P[bi], N[bi], bi, MAT_SKIN, skinTint, glm::vec4(pk.rvUv[r], float(bi), float(mode)))).first;
            }
            mesh->indices.push_back(it->second);
        }
    }
    // the eyes, fitted the way MakeHuman fits them
    if (!pk.eyeRef.empty()) {
        glm::vec3 es;
        for (int a = 0; a < 3; ++a)
            es[a] = std::fabs(P[pk.eyeScaleA[size_t(a)]][a] - P[pk.eyeScaleB[size_t(a)]][a]) / std::max(pk.eyeScaleDist[size_t(a)] * s, 1e-6f) * s;
        std::vector<glm::vec3> ep(pk.eyeRef.size());
        for (size_t i = 0; i < ep.size(); ++i) {
            const auto& r = pk.eyeRef[i];
            ep[i] = P[r[0]] * pk.eyeW[i].x + P[r[1]] * pk.eyeW[i].y + P[r[2]] * pk.eyeW[i].z + pk.eyeOff[i] * es;
        }
        // the eyeballs' centres, for their normals
        const glm::vec3 eyeL = jointOf(pk, P, "eye.L:head"), eyeR = jointOf(pk, P, "eye.R:head");
        std::vector<std::uint32_t> made(pk.eyeRvVert.size(), 0xFFFFFFFFu);
        auto alphaAt = [&](glm::vec2 uv) {
            if (pk.eyeImg.empty()) return 255;
            const int x = std::clamp(int(uv.x * float(pk.eyeImgW)), 0, pk.eyeImgW - 1), y = std::clamp(int(uv.y * float(pk.eyeImgH)), 0, pk.eyeImgH - 1);
            return int(pk.eyeImg[(size_t(y) * size_t(pk.eyeImgW) + size_t(x)) * 4 + 3]);
        };
        for (size_t t = 0; t + 2 < pk.eyeTris.size(); t += 3) {
            const std::uint32_t a = pk.eyeTris[t], b = pk.eyeTris[t + 1], cc = pk.eyeTris[t + 2];
            const glm::vec2 uv = (pk.eyeRvUv[a] + pk.eyeRvUv[b] + pk.eyeRvUv[cc]) / 3.0f;
            if (alphaAt(uv) < 128) continue;                                          // the clear cornea over the eye
            for (std::uint32_t r : { a, b, cc }) {
                if (made[r] == 0xFFFFFFFFu) {
                    const glm::vec3 p = ep[pk.eyeRvVert[r]];
                    const glm::vec3 centre = p.x > 0.0f ? eyeL : eyeR;
                    const glm::vec3 n = glm::length(p - centre) > 1e-6f ? glm::normalize(p - centre) : glm::vec3(0, 0, 1);
                    made[r] = putVertex(p, n, 0xFFFFFFFFu, MAT_SKIN, glm::vec3(1.0f), glm::vec4(pk.eyeRvUv[r], -1.0f, float(SurfaceMode::Eye)));
                }
                mesh->indices.push_back(made[r]);
            }
        }
    }
    // the clothes: shells around the body, one vertex per base vertex per garment (so they close over UV seams). Their
    // edges (hems, cuffs, collars) are cut where the garment's cover is exactly one half, so they run smoothly across the
    // body's triangles instead of following them in steps.
    auto blendVertex = [&](const std::vector<glm::vec3>& Q, const std::vector<glm::vec3>& QN, std::uint32_t a, std::uint32_t b, float t, float thick, MaterialId mat, const glm::vec3& tint) {
        float w[kBoneCount] = {};
        for (int k = 0; k < 4; ++k) {
            w[pk.wBone[a][size_t(k)]] += float(pk.wVal[a][size_t(k)]) * (1.0f - t);
            w[pk.wBone[b][size_t(k)]] += float(pk.wVal[b][size_t(k)]) * t;
        }
        int idx[4] = { 0, 0, 0, 0 };
        float val[4] = { -1, -1, -1, -1 };
        for (int bo = 0; bo < kBoneCount; ++bo) {
            if (w[bo] <= val[3]) continue;
            int k = 3;
            while (k > 0 && w[bo] > val[k - 1]) { val[k] = val[k - 1]; idx[k] = idx[k - 1]; --k; }
            val[k] = w[bo]; idx[k] = bo;
        }
        const float sum = std::max(val[0] + val[1] + val[2] + val[3], 1e-6f);
        const glm::vec3 n = glm::normalize(glm::mix(QN[a], QN[b], t));
        const std::uint32_t at = putVertex(glm::mix(Q[a], Q[b], t) + n * thick, n, a, mat, tint, glm::vec4(0.0f, 0.0f, -1.0f, float(SurfaceMode::Materials)));
        SkinVertex& sv = mesh->vertices[at];
        int given = 0;
        for (int k = 0; k < 4; ++k) {
            sv.bones[k] = std::uint8_t(idx[k]);
            sv.weights[k] = std::uint8_t(std::lround(std::max(val[k], 0.0f) / sum * 255.0f));
            given += sv.weights[k];
        }
        sv.weights[0] = std::uint8_t(std::clamp(int(sv.weights[0]) + 255 - given, 0, 255));
        return at;
    };
    // The body's tubes, for cloth: the trunk (a vertical axis through the hips' middle), and each arm and leg (a line
    // through its joints). Which tube a vertex belongs to, and where along it and round it it is.
    struct Tube { std::vector<glm::vec3> pts; };
    std::array<Tube, 5> tubes;                                         // trunk, arm L, arm R, leg L, leg R
    tubes[0].pts = { glm::vec3(0.0f, sd[0].hip.y - 0.25f * s / 1.8f, pelvis.z), glm::vec3(0.0f, neck.y + 0.1f * s / 1.8f, pelvis.z) };
    for (int k = 0; k < 2; ++k) {
        tubes[size_t(1 + k)].pts = { sd[k].shoulder, sd[k].elbow, sd[k].wrist };
        tubes[size_t(3 + k)].pts = { sd[k].hip, sd[k].knee, sd[k].ankle };
    }
    auto tubeOf = [&](std::uint32_t i, float& share) {
        float w[5] = {};
        for (int k = 0; k < 4; ++k) {
            const int b = pk.wBone[i][size_t(k)];
            const float v = float(pk.wVal[i][size_t(k)]) / 255.0f;
            const Bone bo = Bone(b);
            const int t = (bo == Bone::UpperArmL || bo == Bone::LowerArmL || bo == Bone::HandL) ? 1 : (bo == Bone::UpperArmR || bo == Bone::LowerArmR || bo == Bone::HandR) ? 2
                        : (bo == Bone::UpperLegL || bo == Bone::LowerLegL || bo == Bone::FootL) ? 3 : (bo == Bone::UpperLegR || bo == Bone::LowerLegR || bo == Bone::FootR) ? 4 : 0;
            w[t] += v;
        }
        int best = 0;
        for (int t = 1; t < 5; ++t) if (w[t] > w[best]) best = t;
        share = w[best];
        return best;
    };
    // along (metres from the tube's start), and the point on its axis
    auto onTube = [&](const Tube& tb, const glm::vec3& p, float& along) {
        float bestD = 1e9f, acc = 0.0f;
        glm::vec3 bestQ = tb.pts[0];
        along = 0.0f;
        for (size_t k = 0; k + 1 < tb.pts.size(); ++k) {
            const glm::vec3 a = tb.pts[k], b = tb.pts[k + 1];
            const glm::vec3 ab = b - a;
            const float len = glm::length(ab);
            const float t = std::clamp(glm::dot(p - a, ab) / std::max(len * len, 1e-8f), 0.0f, 1.0f);
            const glm::vec3 q = a + ab * t;
            const float d = glm::length(p - q);
            if (d < bestD) { bestD = d; bestQ = q; along = acc + len * t; }
            acc += len;
        }
        return bestQ;
    };
    const float armpitY = (sd[0].shoulder.y + sd[1].shoulder.y) * 0.5f - 0.07f * s / 1.8f;
    auto hangGarment = [&](std::vector<glm::vec3>& S, const std::vector<std::uint32_t>& list, size_t gi, const Garment& g) {
        if (g.mat == MAT_METAL) return;                                // armour is rigid: it keeps its shape
        constexpr int kA = 36;
        const float bin = 0.01f * s / 1.8f;
        struct Pt { std::uint32_t i; int tube; float share, along, ang, r; glm::vec3 axis, dir; };
        std::vector<Pt> pts;
        pts.reserve(list.size());
        for (std::uint32_t i : list) {
            Pt p;
            p.i = i;
            p.tube = tubeOf(i, p.share);
            if (p.tube == 0 && !g.top && P[i].y < pelvis.y - 0.04f * s / 1.8f) p.tube = P[i].x > 0.0f ? 3 : 4;   // trouser seat: the legs'
            p.axis = onTube(tubes[size_t(p.tube)], S[i], p.along);
            glm::vec3 d = S[i] - p.axis;
            if (p.tube == 0) d.y = 0.0f;
            p.r = glm::length(d);
            p.dir = p.r > 1e-6f ? d / p.r : glm::vec3(0.0f, 0.0f, 1.0f);
            p.ang = std::atan2(p.dir.x, p.dir.z);
            if (p.tube == 0) p.axis = glm::vec3(p.axis.x, S[i].y, p.axis.z);
            pts.push_back(p);
        }
        // per tube: the body's reach per height (and, for the trunk, per angle), then the envelope
        for (int tube = 0; tube < 5; ++tube) {
            float lo = 1e9f, hi = -1e9f;
            for (const Pt& p : pts) if (p.tube == tube) { const float h = tube == 0 ? S[p.i].y : p.along; lo = std::min(lo, h); hi = std::max(hi, h); }
            if (hi < lo) continue;
            const int nb = std::max(1, int((hi - lo) / bin) + 1);
            const int na = tube == 0 ? kA : 1;
            std::vector<float> reach(size_t(nb * na), 0.0f), env(size_t(nb * na), 0.0f);
            auto binOf = [&](const Pt& p) {
                const int h = std::clamp(int(((tube == 0 ? S[p.i].y : p.along) - lo) / bin), 0, nb - 1);
                const int a = tube == 0 ? std::clamp(int((p.ang + 3.14159265f) / 6.2831853f * float(kA)), 0, kA - 1) : 0;
                return h * na + a;
            };
            for (const Pt& p : pts) if (p.tube == tube) { float& r = reach[size_t(binOf(p))]; r = std::max(r, p.r); }
            if (tube == 0) {
                // a top hangs: going down from the armpits, no narrower than just above (a little taper)
                for (int a = 0; a < na; ++a) {
                    float carry = 0.0f;
                    for (int h = nb - 1; h >= 0; --h) {
                        const float y = lo + (float(h) + 0.5f) * bin;
                        const float own = reach[size_t(h * na + a)];
                        if (g.top && y < armpitY) carry = std::max(own, carry * 0.996f);
                        else carry = own;
                        env[size_t(h * na + a)] = carry;
                    }
                }
                // a little sideways smoothing round the trunk (no ridges from one angle to the next)
                for (int pass = 0; pass < 2; ++pass) {
                    std::vector<float> e2 = env;
                    for (int h = 0; h < nb; ++h)
                        for (int a = 0; a < na; ++a)
                            e2[size_t(h * na + a)] = std::max(env[size_t(h * na + a)], 0.25f * env[size_t(h * na + (a + na - 1) % na)] + 0.5f * env[size_t(h * na + a)] + 0.25f * env[size_t(h * na + (a + 1) % na)]);
                    env.swap(e2);
                }
            } else {
                // sleeves and trouser legs: round (as wide as the limb's widest side at that point), and smoothed along
                std::vector<float> r2 = reach;
                for (int h = 0; h < nb; ++h) {
                    float m = 0.0f;
                    for (int dh = -3; dh <= 3; ++dh) m = std::max(m, reach[size_t(std::clamp(h + dh, 0, nb - 1))]);
                    r2[size_t(h)] = m;
                }
                const bool leg = tube >= 3;
                const float knee = leg ? glm::length(tubes[size_t(tube)].pts[1] - tubes[size_t(tube)].pts[0]) : 1e9f;
                float kneeR = 0.0f;
                for (int h = 0; h < nb; ++h) {
                    const float along = lo + (float(h) + 0.5f) * bin;
                    if (leg && std::fabs(along - knee) < 0.03f * s / 1.8f) kneeR = std::max(kneeR, r2[size_t(h)]);
                }
                for (int h = 0; h < nb; ++h) {
                    const float along = lo + (float(h) + 0.5f) * bin;
                    float e = r2[size_t(h)];
                    if (leg && !g.top && along > knee) e = std::max(e, kneeR * 0.96f);   // trousers fall straight from the knee
                    env[size_t(h)] = e;
                }
            }
            for (const Pt& p : pts) {
                if (p.tube != tube) continue;
                const float e = env[size_t(binOf(p))];
                if (e <= p.r) continue;
                float k = sstep(0.45f, 0.8f, p.share);                        // full where the vertex is clearly on this tube
                if (tube != 0) k *= sstep(0.07f * s / 1.8f, 0.13f * s / 1.8f, p.along);   // not round the shoulder or the hip joint itself
                if (tube >= 3 && p.along < glm::length(tubes[size_t(tube)].pts[1] - tubes[size_t(tube)].pts[0])) k *= 0.55f;   // thighs: eased, not ballooned
                S[p.i] = p.axis + p.dir * glm::mix(p.r, e, k);
            }
        }
        // a few soft passes, so no step from one band to the next shows
        std::vector<glm::vec3> delta(list.size());
        for (int it = 0; it < 8; ++it) {
            const float f = (it & 1) ? -0.53f : 0.5f;
            for (size_t k = 0; k < list.size(); ++k) {
                const std::uint32_t i = list[k];
                glm::vec3 avg(0.0f);
                for (std::uint32_t j : pk.neighbours[i]) avg += S[j];
                delta[k] = (avg / float(pk.neighbours[i].size()) - S[i]) * f;
            }
            for (size_t k = 0; k < list.size(); ++k) S[list[k]] += delta[k];
        }
        (void)gi;
    };
    // folds where cloth bunches: the inside of the elbows, the back of the knees, above the ankles
    auto jointFolds = [&](std::uint32_t i) {
        float share;
        const int tube = tubeOf(i, share);
        if (tube == 0) return 0.0f;
        float along;
        const glm::vec3 axis = onTube(tubes[size_t(tube)], P[i], along);
        const float seg = glm::length(tubes[size_t(tube)].pts[1] - tubes[size_t(tube)].pts[0]);
        const float total = seg + glm::length(tubes[size_t(tube)].pts[2] - tubes[size_t(tube)].pts[1]);
        const float u = s / 1.8f;
        const glm::vec3 d = glm::normalize(P[i] - axis + glm::vec3(1e-6f));
        const float inside = tube <= 2 ? std::max(0.0f, d.z) : std::max(0.0f, -d.z);     // the side the joint folds to
        float f = 0.0f;
        const float j = std::exp(-std::pow((along - seg) / (0.05f * u), 2.0f)) * (0.35f + 0.65f * inside);
        f += j * 0.004f * std::sin(along / (0.022f * u) * 6.2831853f + 1.3f * float(tube));
        if (tube >= 3) {                                                 // trousers gather above the shoes
            const float ankle = sstep(total - 0.2f * u, total - 0.05f * u, along);
            f += ankle * 0.005f * std::sin(along / (0.035f * u) * 6.2831853f + std::atan2(d.x, d.z) * 2.0f);
        }
        return f;
    };
    for (size_t gi = 0; gi < garments.size() && gi < 8; ++gi) {
        const Garment& g = garments[gi];
        // Cloth does not follow every curve of the body: the layer is the body smoothed (Taubin, which does not shrink),
        // so it bridges hollows and passes over small bumps, then lifted off the skin, with soft folds in it.
        std::vector<glm::vec3> S = P;
        if (g.mat != MAT_HAIR) {
            std::vector<char> on(nbase, 0);
            std::vector<std::uint32_t> list;
            for (size_t i = 0; i < nbase; ++i)
                if (cover[i][gi] > 0.02f && !pk.neighbours[i].empty()) { on[i] = 1; list.push_back(std::uint32_t(i)); }
            std::vector<glm::vec3> delta(list.size());
            for (int it = 0; it < 90; ++it) {
                const float f = (it & 1) ? -0.53f : 0.5f;
                for (size_t k = 0; k < list.size(); ++k) {
                    const std::uint32_t i = list[k];
                    glm::vec3 avg(0.0f);
                    for (std::uint32_t j : pk.neighbours[i]) avg += S[j];
                    delta[k] = (avg / float(pk.neighbours[i].size()) - S[i]) * f;
                }
                for (size_t k = 0; k < list.size(); ++k) S[list[k]] += delta[k];
            }
            // where the legs meet, cloth bridges the crease instead of following it (a trouser crotch hangs)
            if (!g.top) {
                const float hipY = pelvis.y;
                std::vector<std::uint32_t> crotch;
                std::vector<float> wgt;
                for (std::uint32_t i : list) {
                    const float w = sstep(0.11f * s / 1.8f, 0.04f * s / 1.8f, std::fabs(P[i].x)) * sstep(hipY - 0.2f * s / 1.8f, hipY - 0.1f * s / 1.8f, P[i].y)
                                  * (1.0f - sstep(hipY - 0.01f * s / 1.8f, hipY + 0.04f * s / 1.8f, P[i].y));
                    if (w > 0.01f) { crotch.push_back(i); wgt.push_back(w); }
                }
                std::vector<glm::vec3> d2(crotch.size());
                for (int it = 0; it < 60; ++it) {
                    for (size_t k = 0; k < crotch.size(); ++k) {
                        const std::uint32_t i = crotch[k];
                        glm::vec3 avg(0.0f);
                        for (std::uint32_t j : pk.neighbours[i]) avg += S[j];
                        d2[k] = (avg / float(pk.neighbours[i].size()) - S[i]) * 0.5f * wgt[k];
                    }
                    for (size_t k = 0; k < crotch.size(); ++k) S[crotch[k]] += d2[k];
                }
            }
            using namespace sdf;
            for (size_t i = 0; i < nbase; ++i) {
                if (!on[i]) continue;
                const float sunk = std::max(0.0f, -glm::dot(S[i] - P[i], N[i]));
                const float visible = clothed[i] < 0.85f ? 1.0f : 0.3f;      // where the skin shows (hems), never inside it
                S[i] += N[i] * (sunk * visible);
            }
            // 1.6: how cloth hangs. Round the body's tubes (trunk, arms, legs), each vertex is moved out to the garment's
            // envelope: a top falls from the chest and shoulder blades instead of following the waist; sleeves and trouser
            // legs are round and loose; trousers fall straight from the knee.
            hangGarment(S, list, gi, g);
            // folds: soft everywhere, bunched at the inside of the elbows and knees and above the ankles
            for (std::uint32_t i : list) {
                const glm::vec3 q = P[i] / std::max(s, 1e-3f);
                float folds = 0.0035f * vnoise(q * glm::vec3(8.0f, 30.0f, 8.0f), 951u) + 0.0012f * vnoise(q * 70.0f, 953u);
                folds += jointFolds(i);
                S[i] += N[i] * (std::max(0.0f, folds + 0.0015f) * s / 1.8f);
            }
        }
        // the layer's own normals (the body's would shade in every detail the smoothing took out)
        std::vector<glm::vec3> NS(nbase, glm::vec3(0.0f));
        for (size_t t = 0; t + 2 < bt.size(); t += 3) {
            const std::uint32_t a = pk.rvBase[bt[t]], b = pk.rvBase[bt[t + 1]], cc = pk.rvBase[bt[t + 2]];
            const glm::vec3 n = glm::cross(S[b] - S[a], S[cc] - S[a]);
            NS[a] += n; NS[b] += n; NS[cc] += n;
        }
        for (size_t i = 0; i < nbase; ++i) NS[i] = glm::length(NS[i]) > 1e-12f ? glm::normalize(NS[i]) : N[i];
        std::vector<std::uint32_t> made(nbase, 0xFFFFFFFFu);
        std::unordered_map<std::uint64_t, std::uint32_t> edgeMade;
        const size_t firstIndex = mesh->indices.size();
        auto tintAt = [&](const glm::vec3& p) { return g.stripes ? ((int(std::floor(p.y / s * 11.0f)) & 1) ? g.tint2 : g.tint) : g.tint; };
        auto hemTint = [&](std::uint32_t bi, const glm::vec3& t) {       // the edge of a garment (a hem, a cuff, a waistband): a shade darker
            return g.mat == MAT_HAIR ? t : t * (1.0f - 0.22f * (1.0f - sstep(0.55f, 0.75f, cover[bi][gi])));
        };
        auto vert = [&](std::uint32_t bi) {
            if (made[bi] != 0xFFFFFFFFu) return made[bi];
            made[bi] = putVertex(S[bi] + NS[bi] * thickAt[bi][gi], NS[bi], bi, g.mat, hemTint(bi, tintAt(P[bi])), glm::vec4(0.0f, 0.0f, -1.0f, float(SurfaceMode::Materials)));
            return made[bi];
        };
        auto edge = [&](std::uint32_t a, std::uint32_t b) {
            const std::uint64_t key = a < b ? (std::uint64_t(a) << 32 | b) : (std::uint64_t(b) << 32 | a);
            if (auto it = edgeMade.find(key); it != edgeMade.end()) return it->second;
            const float ca = cover[a][gi], cb = cover[b][gi];
            const float t = std::clamp((0.5f - ca) / (cb - ca), 0.0f, 1.0f);
            const std::uint32_t v = blendVertex(S, NS, a, b, t, glm::mix(thickAt[a][gi], thickAt[b][gi], t), g.mat, tintAt(glm::mix(P[a], P[b], t)) * 0.78f);
            edgeMade.emplace(key, v);
            return v;
        };
        for (size_t t = 0; t + 2 < bt.size(); t += 3) {
            const std::uint32_t bb[3] = { pk.rvBase[bt[t]], pk.rvBase[bt[t + 1]], pk.rvBase[bt[t + 2]] };
            if (hidden[bb[0]] > 0.5f && hidden[bb[1]] > 0.5f && hidden[bb[2]] > 0.5f) continue;
            const bool in[3] = { cover[bb[0]][gi] > 0.5f, cover[bb[1]][gi] > 0.5f, cover[bb[2]][gi] > 0.5f };
            const int count = int(in[0]) + int(in[1]) + int(in[2]);
            if (count == 0) continue;
            if (count == 3) { mesh->indices.insert(mesh->indices.end(), { vert(bb[0]), vert(bb[1]), vert(bb[2]) }); continue; }
            // the covered part of the triangle, in order round it
            std::uint32_t poly[4];
            int np = 0;
            for (int k = 0; k < 3; ++k) {
                const std::uint32_t a = bb[k], b = bb[(k + 1) % 3];
                if (in[k]) poly[np++] = vert(a);
                if (in[k] != in[(k + 1) % 3]) poly[np++] = edge(a, b);
            }
            for (int k = 1; k + 1 < np; ++k) mesh->indices.insert(mesh->indices.end(), { poly[0], poly[k], poly[k + 1] });
        }
        // 1.6: the edges (hems, cuffs, collars) turned in, so the cloth has a thickness where it ends
        if (g.mat != MAT_HAIR) {
            std::unordered_map<std::uint64_t, int> edgeCount;
            std::unordered_map<std::uint64_t, std::pair<std::uint32_t, std::uint32_t>> edgeDir;
            for (size_t t = firstIndex; t + 2 < mesh->indices.size(); t += 3)
                for (int k = 0; k < 3; ++k) {
                    const std::uint32_t a = mesh->indices[t + size_t(k)], b = mesh->indices[t + size_t((k + 1) % 3)];
                    const std::uint64_t key = a < b ? (std::uint64_t(a) << 32 | b) : (std::uint64_t(b) << 32 | a);
                    ++edgeCount[key];
                    edgeDir[key] = { a, b };
                }
            std::unordered_map<std::uint32_t, std::uint32_t> inner;
            auto turned = [&](std::uint32_t v) {
                if (auto it = inner.find(v); it != inner.end()) return it->second;
                SkinVertex sv = mesh->vertices[v];
                const glm::vec4 ex = mesh->extra[v];
                const float depth = std::min(0.012f, 0.6f * glm::length(sv.v.normal) * 0.012f + 0.003f) * s / 1.8f;
                sv.v.position -= sv.v.normal * depth;
                for (int c2 = 0; c2 < 3; ++c2) sv.tint[c2] = std::uint8_t(float(sv.tint[c2]) * 0.7f);
                mesh->vertices.push_back(sv);
                mesh->extra.push_back(ex);
                const std::uint32_t at = std::uint32_t(mesh->vertices.size() - 1);
                inner.emplace(v, at);
                return at;
            };
            for (const auto& [key, n] : edgeCount) {
                if (n != 1) continue;
                const auto [a, b] = edgeDir[key];
                const std::uint32_t ai = turned(a), bi = turned(b);
                mesh->indices.insert(mesh->indices.end(), { a, b, bi, a, bi, ai, a, bi, b, a, ai, bi });
            }
        }
    }

    // 6a. 1.6: skirts, robes and the tails of a long coat: cloth that hangs from the waist round the legs (not a layer on
    // the body). Rings round the trunk's axis, each no narrower than the body inside it, flaring, pleated toward the hem;
    // skinned to the hips and, more and more toward the hem, to the leg on its side, so it swings as they walk; the hem
    // also sways (see the animator's sway).
    {
        struct Drape { bool on = false; glm::vec3 tint{ 1.0f }; float top = 0.0f, hem = 0.0f, open = 0.0f, flare = 0.2f, ease = 0.012f; };
        std::vector<Drape> drapes;
        const std::string& hips = c.parts[size_t(PartSlot::Hips)];
        const float u = s / 1.8f;
        // built in the skeleton's rest pose (legs straight down), then taken back to the body's bind pose vertex by vertex
        const std::array<glm::mat4, kBoneCount> rest = poseToWorld(sk, Pose(), glm::mat4(1.0f));
        auto restM = [&](const std::uint8_t* bones, const std::uint8_t* w) {
            glm::mat4 m(0.0f);
            for (int k = 0; k < 4; ++k) m += (rest[bones[k]] * mesh->inverseBind[bones[k]]) * (float(w[k]) / 255.0f);
            return m;
        };
        const float pelvisY = rest[size_t(Bone::Pelvis)][3].y, chestY = rest[size_t(Bone::Chest)][3].y;
        const float kneeY = rest[size_t(Bone::LowerLegL)][3].y, ankleY = rest[size_t(Bone::FootL)][3].y;
        if (hips == "hips skirt" || hips == "hips robe") {
            Drape d; d.on = true; d.tint = c.colourOf(PartSlot::Hips, ColourRole::Bottoms);
            d.top = pelvisY + 0.07f * u;
            d.hem = hips == "hips skirt" ? kneeY + 0.07f * u : ankleY + 0.03f * u;
            d.flare = hips == "hips skirt" ? 0.32f : 0.16f;
            drapes.push_back(d);
        }
        if (c.parts[size_t(PartSlot::Torso)] == "torso coat") {
            Drape d; d.on = true; d.tint = c.colourOf(PartSlot::Torso, ColourRole::Top);
            d.top = chestY - 0.03f * u;
            d.hem = kneeY - 0.02f * u;
            d.open = 0.42f;                                             // open down the front
            d.flare = 0.12f; d.ease = 0.045f;                          // clear of the trousers under it
            drapes.push_back(d);
        }
        for (const Drape& d : drapes) {
            if (!d.on || d.hem >= d.top) continue;
            constexpr int kA = 64, kR = 14;
            // the body's reach round the axis, per height and angle (the legs, the hips, the bottom)
            const float y0 = d.hem - 0.04f * u, y1 = d.top + 0.04f * u;
            const int nb = 24;
            std::vector<float> reach(size_t(nb * kA), 0.0f);
            const glm::vec2 axis(rest[size_t(Bone::Pelvis)][3].x, rest[size_t(Bone::Pelvis)][3].z);
            for (std::uint32_t i : pk.bodyVerts) {
                const glm::vec3 q = glm::vec3(restM(pk.wBone[i].data(), pk.wVal[i].data()) * glm::vec4(P[i], 1.0f));
                if (q.y < y0 || q.y > y1) continue;
                int trunk = 0;                                               // the hips, the legs and the bottom: not the hands beside them
                for (int k = 0; k < 4; ++k) {
                    const Bone bo = Bone(pk.wBone[i][size_t(k)]);
                    if (bo == Bone::Pelvis || bo == Bone::Chest || bo == Bone::UpperLegL || bo == Bone::UpperLegR || bo == Bone::LowerLegL || bo == Bone::LowerLegR)
                        trunk += pk.wVal[i][size_t(k)];
                }
                if (trunk < 200) continue;
                const glm::vec2 r(q.x - axis.x, q.z - axis.y);
                const float l = glm::length(r);
                const int a = std::clamp(int((std::atan2(r.x, r.y) + 3.14159265f) / 6.2831853f * float(kA)), 0, kA - 1);
                const int h = std::clamp(int((q.y - y0) / (y1 - y0) * float(nb)), 0, nb - 1);
                float& m = reach[size_t(h * kA + a)];
                m = std::max(m, l);
            }
            for (int pass = 0; pass < 3; ++pass)                          // widen each angle by its neighbours (a skirt is not that exact)
                for (int h = 0; h < nb; ++h) {
                    std::vector<float> row(kA);
                    for (int a = 0; a < kA; ++a)
                        row[size_t(a)] = std::max({ reach[size_t(h * kA + a)], reach[size_t(h * kA + (a + 1) % kA)], reach[size_t(h * kA + (a + kA - 1) % kA)] });
                    for (int a = 0; a < kA; ++a) reach[size_t(h * kA + a)] = row[size_t(a)];
                }
            auto reachAt = [&](float y, int a) {
                const int h = std::clamp(int((y - y0) / (y1 - y0) * float(nb)), 0, nb - 1);
                float m = 0.0f;
                for (int dh = -1; dh <= 1; ++dh) m = std::max(m, reach[size_t(std::clamp(h + dh, 0, nb - 1) * kA + a)]);
                return m;
            };
            const float a0 = d.open > 0.0f ? d.open : 0.0f, a1 = 6.2831853f - (d.open > 0.0f ? d.open : 0.0f);
            const int cols = d.open > 0.0f ? kA - 8 : kA;                    // a closed ring repeats its first column at the end
            std::vector<float> radius(size_t(cols + 1));
            const std::uint32_t first = std::uint32_t(mesh->vertices.size());
            for (int r = 0; r <= kR; ++r) {
                const float t = float(r) / float(kR);
                const float y = glm::mix(d.top, d.hem, t);
                for (int k = 0; k <= cols; ++k) {
                    const float th = d.open > 0.0f ? glm::mix(a0, a1, float(k) / float(cols)) : 6.2831853f * float(k) / float(cols);
                    const float thc = th > 3.14159265f ? th - 6.2831853f : th;
                    const int a = std::clamp(int((thc + 3.14159265f) / 6.2831853f * float(kA)), 0, kA - 1);
                    float rr = reachAt(y, a) + d.ease * u;
                    if (r > 0) rr = std::max(rr, radius[size_t(k)] + d.flare * (glm::mix(d.top, d.hem, float(r - 1) / float(kR)) - y) * 0.6f);
                    radius[size_t(k)] = rr;
                    const float pleat = 1.0f + 0.045f * t * std::sin(th * 14.0f + 0.7f * std::sin(th * 3.0f));
                    const glm::vec3 dir(std::sin(th), 0.0f, std::cos(th));
                    const glm::vec3 p = glm::vec3(axis.x, y, axis.y) + dir * (rr * pleat);
                    // skinned: the hips, and toward the hem the leg on its side
                    const float legW = 0.75f * sstep(0.0f, 0.85f, t);
                    const float side = std::sin(th);                              // + : the left leg
                    const float wl = legW * std::clamp(0.5f + side * 1.2f, 0.0f, 1.0f), wr = legW - wl;
                    SkinVertex sv{};
                    sv.v.position = p;
                    sv.v.normal = glm::normalize(dir + glm::vec3(0.0f, 0.15f, 0.0f));
                    sv.v.ao = 1.0f;
                    sv.v.layers[0] = sv.v.layers[1] = sv.v.layers[2] = std::uint8_t(MAT_CLOTH - 1);
                    sv.v.bary[0] = 255;
                    const int wp = std::clamp(int(std::lround((1.0f - wl - wr) * 255.0f)), 0, 255);
                    const int wL = std::clamp(int(std::lround(wl * 255.0f)), 0, 255 - wp);
                    sv.bones[0] = std::uint8_t(Bone::Pelvis); sv.weights[0] = std::uint8_t(wp);
                    sv.bones[1] = std::uint8_t(Bone::UpperLegL); sv.weights[1] = std::uint8_t(wL);
                    sv.bones[2] = std::uint8_t(Bone::UpperLegR); sv.weights[2] = std::uint8_t(255 - wp - wL);
                    sv.bones[3] = 0; sv.weights[3] = 0;
                    {   // back from the rest pose to the bind pose
                        const glm::mat4 back = glm::inverse(restM(sv.bones, sv.weights));
                        sv.v.position = glm::vec3(back * glm::vec4(sv.v.position, 1.0f));
                        sv.v.normal = glm::normalize(glm::mat3(back) * sv.v.normal);
                    }
                    const glm::vec3 tint = glm::clamp(d.tint * (r == kR ? 0.8f : 1.0f), glm::vec3(0.0f), glm::vec3(1.0f));
                    for (int c2 = 0; c2 < 3; ++c2) sv.tint[c2] = std::uint8_t(std::lround(tint[c2] * 255.0f));
                    sv.tint[3] = 255;
                    mesh->vertices.push_back(sv);
                    mesh->extra.push_back(glm::vec4(0.0f, 0.0f, -1.0f - t * t * 0.8f, float(SurfaceMode::Materials)));   // sway: more toward the hem
                }
            }
            const std::uint32_t row = std::uint32_t(cols + 1);
            for (int r = 0; r < kR; ++r)
                for (int k = 0; k < cols; ++k) {
                    const std::uint32_t a = first + std::uint32_t(r) * row + std::uint32_t(k), b = a + 1, c2 = a + row, d2 = c2 + 1;
                    mesh->indices.insert(mesh->indices.end(), { a, c2, b, b, c2, d2 });       // outside
                    mesh->indices.insert(mesh->indices.end(), { a, b, c2, b, d2, c2 });       // and the inside
                }
        }
    }

    // 6b. the hair: strands grown over the scalp, each a card (a strip, both sides) cut out by the hair texture
    if (cardHair) {
        const std::vector<Strand> strands = growHair(c.hair, hs, c.look.faceSeed ^ 0xA5u, hatCovers);
        auto hm = std::make_shared<SkinnedMesh>();
        hm->inverseBind = mesh->inverseBind;
        hm->expressionScale = s;
        HairRng rng(c.look.faceSeed + 77u);
        const glm::mat3 nm(fromHead);
        for (const Strand& st : strands) {
            if (st.p.size() < 2) continue;
            const float u0 = rng.f();
            float length = 0.0f;
            for (size_t k = 1; k < st.p.size(); ++k) length += glm::length(st.p[k] - st.p[k - 1]);
            const float loose = std::clamp(length / (0.22f * s / 1.8f), 0.12f, 1.3f);     // long hair swings, short hair barely
            const std::uint32_t first = std::uint32_t(hm->vertices.size());
            const size_t n = st.p.size();
            for (size_t k = 0; k < n; ++k) {
                const glm::vec3 p = st.p[k];
                const glm::vec3 along = glm::normalize(st.p[std::min(k + 1, n - 1)] - st.p[k > 0 ? k - 1 : 0]);
                glm::vec3 out = hs.normal(hs.dirOf(p));
                if (p.y < hs.C.y) out = glm::normalize(glm::vec3((p.x - hs.C.x) / hs.R.x, 0.0f, (p.z - hs.C.z) / hs.R.z) + glm::vec3(0.0f, 0.001f, 0.0f));
                glm::vec3 side = glm::cross(along, out);
                side = glm::length(side) > 1e-6f ? glm::normalize(side) : glm::vec3(1, 0, 0);
                const float t = float(k) / float(n - 1);
                const float w = st.width * (1.0f - 0.55f * t) * 0.5f;
                for (int e = 0; e < 2; ++e) {
                    SkinVertex sv{};
                    sv.v.position = glm::vec3(fromHead * glm::vec4(p + side * (e == 0 ? -w : w), 1.0f));
                    sv.v.normal = glm::normalize(nm * out);
                    sv.v.ao = 1.0f;
                    sv.v.layers[0] = sv.v.layers[1] = sv.v.layers[2] = std::uint8_t(MAT_HAIR - 1);
                    sv.v.bary[0] = 255;
                    sv.bones[0] = std::uint8_t(Bone::Head); sv.weights[0] = 255;
                    sv.tint[0] = sv.tint[1] = sv.tint[2] = sv.tint[3] = 255;
                    hm->vertices.push_back(sv);
                    hm->extra.push_back(glm::vec4(u0 + (e == 0 ? 0.0f : 0.22f), t, -1.0f - std::pow(t, 1.5f) * loose, float(SurfaceMode::HairCard)));
                }
            }
            for (size_t k = 0; k + 1 < n; ++k) {
                const std::uint32_t a = first + std::uint32_t(k * 2), b = a + 1, c2 = a + 2, d = a + 3;
                hm->indices.insert(hm->indices.end(), { a, c2, b, b, c2, d });          // one side
                hm->indices.insert(hm->indices.end(), { a, b, c2, b, d, c2 });          // and the other
            }
        }
        if (!hm->indices.empty()) { body->hair = hm; body->hairAsCards = true; }
    }
    // 6c. a beard (the built-in ones): short strands over the jaw, chin and upper lip, lying down the face
    const std::string beard = c.parts[size_t(PartSlot::Beard)];
    if (beard == "beard full" || beard == "beard moustache" || beard == "beard goatee") {
        const int kind = beard == "beard full" ? 0 : beard == "beard moustache" ? 1 : 2;
        auto local = [&](const glm::vec3& p) { return glm::vec3(toHead * glm::vec4(p, 1.0f)); };
        const glm::vec3 mouth = local(jointOf(pk, P, "oris05:head")), chin = local(jointOf(pk, P, "special04:head"));
        const glm::vec3 jawPivot = local(jointOf(pk, P, "jaw:head")), eye = local(jointOf(pk, P, "eye.L:head"));
        const glm::mat3 toHeadN(toHead);
        std::vector<Strand> strands;
        HairRng rng(c.look.faceSeed + 991u);
        const float kk = glm::length(eye - mouth) / 0.054f;                     // the face's size against the base body's
        for (std::uint32_t i : pk.bodyVerts) {
            int hw = 0;
            for (int k = 0; k < 4; ++k) if (pk.wBone[i][size_t(k)] == std::uint8_t(Bone::Head) || pk.wBone[i][size_t(k)] == std::uint8_t(Bone::Neck)) hw += pk.wVal[i][size_t(k)];
            if (hw < 200) continue;
            const glm::vec3 q = local(P[i]);
            const glm::vec3 n = glm::normalize(toHeadN * N[i]);
            const float ax = std::fabs(q.x);
            bool in = false;
            float len = 0.014f;
            const bool upperLip = q.y > mouth.y + 0.002f * kk && q.y < mouth.y + 0.017f * kk && ax < 0.027f * kk && n.z > 0.25f && q.z > mouth.z - 0.02f * kk;
            const bool onChin = q.y < mouth.y - 0.013f * kk && q.y > chin.y - 0.03f * kk && ax < 0.024f * kk && q.z > chin.z - 0.035f * kk;
            if (kind == 1) { in = upperLip; len = 0.009f; }
            else if (kind == 2) { in = upperLip || onChin; len = onChin ? 0.02f : 0.009f; }
            else {
                // the whole lower face: below the cheekbones, in front of the ears, down under the chin; not the lips or the nose
                const bool lowFace = q.y < eye.y - 0.032f * kk && q.y > chin.y - 0.035f * kk && q.z > jawPivot.z - 0.012f * kk && n.y < 0.85f;
                const bool lips = std::fabs(q.y - mouth.y + 0.004f * kk) < 0.009f * kk && ax < 0.021f * kk && q.z > mouth.z - 0.012f * kk;
                const bool nose = q.y > mouth.y + 0.016f * kk && ax < 0.022f * kk;
                in = lowFace && !lips && !nose;
                len = q.y < mouth.y - 0.01f * kk ? 0.026f : 0.016f;
            }
            if (!in) continue;
            const int per = kind == 0 ? 3 : 2;
            for (int r = 0; r < per; ++r) {
                Strand st;
                const glm::vec3 jit = (rng.dir() - n * glm::dot(rng.dir(), n)) * 0.003f * kk;
                glm::vec3 down = tangentOf(glm::vec3(q.x * 0.6f, -1.0f, q.y < mouth.y ? 0.25f : 0.0f), n);
                if (kind != 0 || upperLip) down = tangentOf(glm::vec3(q.x > 0.0f ? 0.6f : -0.6f, -1.0f, 0.0f), n);
                const float l = len * kk * rng.range(0.7f, 1.2f);
                const glm::vec3 root = q + jit + n * 0.0008f;
                for (int s2 = 0; s2 <= 3; ++s2) {
                    const float t = float(s2) / 3.0f;
                    st.p.push_back(root + down * (l * t) + n * (0.003f * kk * std::sin(t * 2.5f) + 0.0015f * t));
                }
                st.width = rng.range(0.003f, 0.005f) * kk;
                strands.push_back(std::move(st));
            }
        }
        if (!strands.empty()) {
            if (!body->hair) {
                body->hair = std::make_shared<SkinnedMesh>();
                body->hair->inverseBind = mesh->inverseBind;
            }
            SkinnedMesh& hm = *body->hair;
            const glm::mat3 nm(fromHead);
            for (const Strand& st : strands) {
                const std::uint32_t first = std::uint32_t(hm.vertices.size());
                const size_t n = st.p.size();
                const float u0 = rng.f();
                for (size_t k = 0; k < n; ++k) {
                    const glm::vec3 along = glm::normalize(st.p[std::min(k + 1, n - 1)] - st.p[k > 0 ? k - 1 : 0]);
                    glm::vec3 out = glm::normalize(st.p[k] - glm::vec3(0.0f, st.p[k].y, -0.02f));
                    glm::vec3 side = glm::cross(along, out);
                    side = glm::length(side) > 1e-6f ? glm::normalize(side) : glm::vec3(1, 0, 0);
                    const float w = st.width * (1.0f - 0.5f * float(k) / float(n - 1)) * 0.5f;
                    for (int e = 0; e < 2; ++e) {
                        SkinVertex sv{};
                        sv.v.position = glm::vec3(fromHead * glm::vec4(st.p[k] + side * (e == 0 ? -w : w), 1.0f));
                        sv.v.normal = glm::normalize(nm * out);
                        sv.v.ao = 1.0f;
                        sv.v.layers[0] = sv.v.layers[1] = sv.v.layers[2] = std::uint8_t(MAT_HAIR - 1);
                        sv.v.bary[0] = 255;
                        sv.bones[0] = std::uint8_t(Bone::Head); sv.weights[0] = 255;
                        sv.tint[0] = sv.tint[1] = sv.tint[2] = sv.tint[3] = 255;
                        hm.vertices.push_back(sv);
                        hm.extra.push_back(glm::vec4(u0 + (e == 0 ? 0.0f : 0.12f), float(k) / float(n - 1), -1.0f - 0.12f * float(k) / float(n - 1), float(SurfaceMode::HairCard)));
                    }
                }
                for (size_t k = 0; k + 1 < n; ++k) {
                    const std::uint32_t a = first + std::uint32_t(k * 2), b = a + 1, c2 = a + 2, d = a + 3;
                    hm.indices.insert(hm.indices.end(), { a, c2, b, b, c2, d, a, b, c2, b, d, c2 });
                }
            }
            body->beardAsCards = true;
        }
    }

    // 7. where the head's things go: the voxel head they were made for, onto this head
    {
        // the skull: the head above the eyes (the face differs too much between a sculpted voxel head and a real one)
        glm::vec3 hlo(1e9f), hhi(-1e9f);
        auto skullBox = [](const std::vector<glm::vec3>& pts, glm::vec3& lo3, glm::vec3& hi3) {
            float ylo = 1e9f, yhi = -1e9f;
            for (const glm::vec3& q : pts) { ylo = std::min(ylo, q.y); yhi = std::max(yhi, q.y); }
            const float cut = ylo + 0.5f * (yhi - ylo);
            for (const glm::vec3& q : pts) if (q.y >= cut) { lo3 = glm::min(lo3, q); hi3 = glm::max(hi3, q); }
        };
        skullBox(headPts, hlo, hhi);
        AssetPtr vh = lib.get(builtinPartName(PartSlot::Head));
        if (vh && !vh->mesh.empty() && hhi.x > hlo.x) {
            const glm::vec3 ps = sk.bone(Bone::Head).partScale;
            const glm::vec3 j = partJoint(*vh, PartSlot::Head);
            glm::vec3 vlo(1e9f), vhi(-1e9f);
            std::vector<glm::vec3> vpts;
            vpts.reserve(vh->mesh.size());
            for (const Vertex& v : vh->mesh) vpts.push_back((v.position - j) * ps);
            skullBox(vpts, vlo, vhi);
            const glm::vec3 k = glm::clamp((hhi - hlo) / glm::max(vhi - vlo, glm::vec3(1e-4f)), glm::vec3(0.6f), glm::vec3(1.6f));
            // line up the crown and the back of the skull (hats sit on the crown, hair grows from the back of the head)
            const glm::vec3 vc((vlo.x + vhi.x) * 0.5f, vhi.y, vlo.z), hc((hlo.x + hhi.x) * 0.5f, hhi.y, hlo.z);
            body->headFit = glm::translate(glm::mat4(1.0f), hc) * glm::scale(glm::mat4(1.0f), k) * glm::translate(glm::mat4(1.0f), -vc);
            // hats were made to sit on the voxel head's hair: with hair that lies flat they come down onto the head
            body->hatFit = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.014f * ps.y, 0.0f)) * body->headFit;
            // glasses (and beards) follow the eyes: the voxel face's eyes onto these
            const glm::vec3 eyeA = glm::vec3(toHead * glm::vec4(jointOf(pk, P, "eye.L:head"), 1.0f));
            const glm::vec3 eyeB = glm::vec3(toHead * glm::vec4(jointOf(pk, P, "eye.R:head"), 1.0f));
            const glm::vec3 vEyeA = glm::vec3(0.033f, 0.138f, 0.0795f) * ps, vEyeB = glm::vec3(-0.033f, 0.138f, 0.0795f) * ps;
            const float ks = std::clamp(glm::length(eyeA - eyeB) / std::max(glm::length(vEyeA - vEyeB), 1e-4f), 0.6f, 1.6f);
            body->faceFit = glm::translate(glm::mat4(1.0f), (eyeA + eyeB) * 0.5f + glm::vec3(0.0f, 0.0f, -0.006f * ks)) * glm::scale(glm::mat4(1.0f), glm::vec3(ks * 0.94f)) *
                            glm::translate(glm::mat4(1.0f), -(vEyeA + vEyeB) * 0.5f);
            if (std::getenv("PX_HUMAN_DEBUG"))
                std::printf("  head fit: body head %.3f %.3f %.3f .. %.3f %.3f %.3f, voxel head %.3f %.3f %.3f .. %.3f %.3f %.3f\n",
                            double(hlo.x), double(hlo.y), double(hlo.z), double(hhi.x), double(hhi.y), double(hhi.z),
                            double(vlo.x), double(vlo.y), double(vlo.z), double(vhi.x), double(vhi.y), double(vhi.z));
        }
    }
    body->mesh = mesh;
    return body;
}

std::shared_ptr<const HumanBody> humanBodyFor(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib) {
    if (!usesHumanBody(c)) return nullptr;
    const std::string key = keyFor(c, sk);
    auto& m = cache();
    if (auto it = m.find(key); it != m.end()) return it->second;
    using Clock = std::chrono::steady_clock;
    static Clock::time_point windowStart = Clock::now();
    static int builtInWindow = 0;
    if (Clock::now() - windowStart > std::chrono::milliseconds(100)) { windowStart = Clock::now(); builtInWindow = 0; }
    if (builtInWindow >= 2) return nullptr;
    ++builtInWindow;
    if (m.size() >= 64) m.clear();                                  // (about a megabyte each)
    auto b = buildHumanBody(c, sk, lib);
    m[key] = b;
    return b;
}

size_t humanBodyCacheSize() { return cache().size(); }
void clearHumanBodyCache() { cache().clear(); }

// ---------------------------------------------------------------- the face of the moment

Expressions expressionsFor(const CharacterDef& c, const AnimOutput& pose) {
    Expressions e{};
    auto set = [&](Expression x, float v) { e[size_t(x)] = std::max(e[size_t(x)], v); };
    const int mouth = pose.mouth >= 0 ? pose.mouth : c.face.mouth;
    const int brows = pose.brows >= 0 ? pose.brows : c.face.brows;
    switch (mouth) {                                            // Relaxed, Smile, Pressed, Grin, Frown
    case 1: set(Expression::Smile, 0.45f); break;
    case 2: set(Expression::Press, 0.6f); break;
    case 3: set(Expression::Smile, 0.8f); set(Expression::MouthOpen, 0.18f); break;
    case 4: set(Expression::Frown, 0.6f); break;
    default: break;
    }
    switch (brows) {                                            // None, Soft, Angry, Worried, Bushy
    case 2: set(Expression::BrowsDown, 0.7f); break;
    case 3: set(Expression::BrowsWorried, 0.75f); break;
    default: break;
    }
    if (pose.blink) set(Expression::Blink, 1.0f);
    return e;
}

// ---------------------------------------------------------------- the shared maps

namespace {

std::vector<float> magnitudes(const Pack& pk, const char* name) {
    std::vector<float> m(pk.base.size(), 0.0f);
    auto it = pk.targets.find(name);
    if (it == pk.targets.end()) return m;
    float mx = 1e-9f;
    for (size_t k = 0; k < it->second.idx.size(); ++k) { const float v = glm::length(it->second.d[k]); m[it->second.idx[k]] = v; mx = std::max(mx, v); }
    for (float& v : m) v /= mx;
    return m;
}


} // namespace

std::shared_ptr<HumanRenderData> bakeHumanRenderData(int size) {
    const Pack* pkp = pack();
    if (!pkp) return nullptr;
    const Pack& pk = *pkp;
    const size_t nbase = pk.base.size();
    auto out = std::make_shared<HumanRenderData>();
    out->mapSize = size;

    // per base vertex: the regions (from the shape targets that move them), and how creased the surface is there
    std::vector<float> lips = magnitudes(pk, "face:lips-big"), cheeks = magnitudes(pk, "face:cheeks-big"), nose = magnitudes(pk, "face:nose-big"),
                       ears = magnitudes(pk, "face:ears-big");
    const glm::vec3 eyeL = jointOf(pk, pk.base, "eye.L:head");
    const float eyeR = 0.0125f;                                        // about an eyeball's radius (the base body)
    std::vector<glm::vec3> N(nbase, glm::vec3(0.0f));
    std::vector<glm::vec3> nsum(nbase, glm::vec3(0.0f));
    std::vector<int> ncount(nbase, 0);
    const auto& bt = pk.tris[0];
    for (size_t t = 0; t + 2 < bt.size(); t += 3) {
        const std::uint32_t a = pk.rvBase[bt[t]], b = pk.rvBase[bt[t + 1]], c = pk.rvBase[bt[t + 2]];
        const glm::vec3 n = glm::cross(pk.base[b] - pk.base[a], pk.base[c] - pk.base[a]);
        N[a] += n; N[b] += n; N[c] += n;
        nsum[a] += pk.base[b] + pk.base[c]; ncount[a] += 2;
        nsum[b] += pk.base[a] + pk.base[c]; ncount[b] += 2;
        nsum[c] += pk.base[a] + pk.base[b]; ncount[c] += 2;
    }
    std::vector<float> crease(nbase, 0.0f);
    for (size_t i = 0; i < nbase; ++i) {
        N[i] = glm::length(N[i]) > 1e-12f ? glm::normalize(N[i]) : glm::vec3(0, 1, 0);
        if (ncount[i]) crease[i] = std::clamp(glm::dot(nsum[i] / float(ncount[i]) - pk.base[i], N[i]) / 0.0025f, 0.0f, 1.0f);
    }
    // the fingertips, for the nails: tip, last joint, and which way is the back of the finger
    struct Nail { glm::vec3 tip, joint, back; };
    std::vector<Nail> nails;
    float lo = 1e9f;
    for (std::uint32_t i : pk.bodyVerts) lo = std::min(lo, pk.base[i].y);
    for (const char* side : { ".L", ".R" }) {
        const std::string s = side;
        const glm::vec3 index = jointOf(pk, pk.base, "finger2-1" + s + ":head"), pinky = jointOf(pk, pk.base, "finger5-1" + s + ":head");
        const glm::vec3 wrist = jointOf(pk, pk.base, "wrist" + s + ":head"), knuckle = jointOf(pk, pk.base, "finger3-1" + s + ":head");
        // the back of the hand: across the knuckles x along the hand, the way that keeps a left and a right hand alike
        glm::vec3 back = glm::normalize(glm::cross(index - pinky, knuckle - wrist));
        if (s == ".R") back = -back;
        for (int f = 1; f <= 5; ++f) {
            const std::string fn = "finger" + std::to_string(f) + "-3" + s;
            nails.push_back({ jointOf(pk, pk.base, fn + ":tail"), jointOf(pk, pk.base, fn + ":head"), back });
        }
    }

    // rasterise the body's triangles into UV space: which triangle, and where in it, each texel is
    const int S = size;
    std::vector<std::int32_t> triOf(size_t(S) * size_t(S), -1);
    std::vector<glm::vec3> baryOf(size_t(S) * size_t(S));
    const size_t ntri = bt.size() / 3;
    for (size_t t = 0; t < ntri; ++t) {
        const glm::vec2 a = pk.rvUv[bt[t * 3]] * float(S), b = pk.rvUv[bt[t * 3 + 1]] * float(S), c = pk.rvUv[bt[t * 3 + 2]] * float(S);
        const float area = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
        if (std::fabs(area) < 1e-9f) continue;
        // a little wider than the triangle (a texel either way), so the edges between islands have no gaps
        const int x0 = std::max(0, int(std::floor(std::min({ a.x, b.x, c.x }))) - 1), x1 = std::min(S - 1, int(std::ceil(std::max({ a.x, b.x, c.x }))) + 1);
        const int y0 = std::max(0, int(std::floor(std::min({ a.y, b.y, c.y }))) - 1), y1 = std::min(S - 1, int(std::ceil(std::max({ a.y, b.y, c.y }))) + 1);
        const float pad = 1.0f / std::max(1.0f, std::sqrt(std::fabs(area)));
        for (int y = y0; y <= y1; ++y)
            for (int x = x0; x <= x1; ++x) {
                const glm::vec2 p(float(x) + 0.5f, float(y) + 0.5f);
                const float w0 = ((b.x - p.x) * (c.y - p.y) - (c.x - p.x) * (b.y - p.y)) / area;
                const float w1 = ((c.x - p.x) * (a.y - p.y) - (a.x - p.x) * (c.y - p.y)) / area;
                const float w2 = 1.0f - w0 - w1;
                const bool inside = w0 >= 0.0f && w1 >= 0.0f && w2 >= 0.0f;
                const size_t idx = size_t(y) * size_t(S) + size_t(x);
                if (!inside && (w0 < -pad || w1 < -pad || w2 < -pad || triOf[idx] >= 0)) continue;
                if (inside || triOf[idx] < 0) {
                    triOf[idx] = std::int32_t(t);
                    baryOf[idx] = glm::clamp(glm::vec3(w0, w1, w2), glm::vec3(0.0f), glm::vec3(1.0f));
                    baryOf[idx] /= std::max(baryOf[idx].x + baryOf[idx].y + baryOf[idx].z, 1e-6f);
                }
            }
    }
    // grow the islands a few texels into the empty space (so mip levels do not pull in the background)
    for (int pass = 0; pass < 6; ++pass) {
        std::vector<std::int32_t> next = triOf;
        std::vector<glm::vec3> nb = baryOf;
        for (int y = 0; y < S; ++y)
            for (int x = 0; x < S; ++x) {
                const size_t idx = size_t(y) * size_t(S) + size_t(x);
                if (triOf[idx] >= 0) continue;
                for (int k = 0; k < 4; ++k) {
                    const int nx = x + (k == 0) - (k == 1), ny = y + (k == 2) - (k == 3);
                    if (nx < 0 || ny < 0 || nx >= S || ny >= S) continue;
                    const size_t j = size_t(ny) * size_t(S) + size_t(nx);
                    if (triOf[j] >= 0) { next[idx] = triOf[j]; nb[idx] = baryOf[j]; break; }
                }
            }
        triOf.swap(next);
        baryOf.swap(nb);
    }

    out->map0.assign(size_t(S) * size_t(S) * 4, 0);
    out->map1.assign(size_t(S) * size_t(S) * 4, 0);
    for (size_t i = 0; i < size_t(S) * size_t(S); ++i) {       // empty texels: neutral
        out->map0[i * 4] = 128; out->map1[i * 4] = 128; out->map1[i * 4 + 1] = 128; out->map1[i * 4 + 2] = 150;
    }
    using namespace sdf;
    auto shade = [&](int yStart, int yEnd) {
        for (int y = yStart; y < yEnd; ++y)
            for (int x = 0; x < S; ++x) {
                const size_t idx = size_t(y) * size_t(S) + size_t(x);
                const std::int32_t t = triOf[idx];
                if (t < 0) continue;
                const glm::vec3 w = baryOf[idx];
                const std::uint32_t r0 = bt[size_t(t) * 3], r1 = bt[size_t(t) * 3 + 1], r2 = bt[size_t(t) * 3 + 2];
                const std::uint32_t i0 = pk.rvBase[r0], i1 = pk.rvBase[r1], i2 = pk.rvBase[r2];
                auto lerp = [&](const std::vector<float>& v) { return v[i0] * w.x + v[i1] * w.y + v[i2] * w.z; };
                const glm::vec3 p = pk.base[i0] * w.x + pk.base[i1] * w.y + pk.base[i2] * w.z;
                const glm::vec3 n = glm::normalize(N[i0] * w.x + N[i1] * w.y + N[i2] * w.z);
                // the triangle's UV frame on the surface (for the detail normal)
                const glm::vec3 e1 = pk.base[i1] - pk.base[i0], e2 = pk.base[i2] - pk.base[i0];
                const glm::vec2 d1 = pk.rvUv[r1] - pk.rvUv[r0], d2 = pk.rvUv[r2] - pk.rvUv[r0];
                const float det = d1.x * d2.y - d2.x * d1.y;
                glm::vec3 T = std::fabs(det) > 1e-12f ? (e1 * d2.y - e2 * d1.y) / det : glm::vec3(1, 0, 0);
                glm::vec3 B = std::fabs(det) > 1e-12f ? (e2 * d1.x - e1 * d2.x) / det : glm::vec3(0, 1, 0);
                T = glm::normalize(T - n * glm::dot(n, T)); B = glm::normalize(B - n * glm::dot(n, B));

                const float lip = sstep(0.28f, 0.6f, lerp(lips));
                const float cheek = sstep(0.25f, 0.9f, lerp(cheeks)), nos = sstep(0.4f, 0.95f, lerp(nose)), ear = sstep(0.3f, 0.9f, lerp(ears));
                const float creaseV = lerp(crease);
                // brows: an arch over each eye, thick at the inner end and thinning outward, made of hairs lying outward
                float browHair = 0.0f;
                {
                    const float out = std::fabs(p.x) - eyeL.x;                  // from above the eye's middle, outward
                    const float t = (out + 0.016f) / 0.042f;                    // 0 inner end .. 1 outer end
                    if (t > -0.1f && t < 1.1f && n.z > 0.2f && p.z > eyeL.z - 0.02f) {
                        const float arch = eyeL.y + eyeR + 0.0085f + 0.0045f * std::sin(std::clamp(t, 0.0f, 1.0f) * 2.6f);
                        const float half = glm::mix(0.0058f, 0.0026f, std::clamp(t, 0.0f, 1.0f));
                        const float across = 1.0f - sstep(half * 0.55f, half * 1.3f, std::fabs(p.y - arch));
                        const float ends = sstep(-0.08f, 0.08f, t) * (1.0f - sstep(0.85f, 1.05f, t));
                        const float strands = vnoise(glm::vec3(out * 55.0f + p.y * 260.0f, p.y * 1700.0f, 1.0f), 901u) * 0.5f + 0.5f;
                        browHair = across * ends * sstep(0.18f, 0.5f, strands * 0.7f + across * 0.45f);
                    }
                }
                // nails
                float nail = 0.0f;
                for (const Nail& nl : nails) {
                    const glm::vec3 axis = nl.tip - nl.joint;
                    const float len2 = std::max(glm::dot(axis, axis), 1e-8f);
                    const float u = glm::dot(p - nl.joint, axis) / len2;
                    if (u < -0.1f || u > 1.2f) continue;
                    const float dist = glm::length(p - (nl.joint + axis * std::clamp(u, 0.0f, 1.0f)));
                    if (dist > 0.012f) continue;
                    const float facing = sstep(0.35f, 0.7f, glm::dot(n, nl.back));
                    nail = std::max(nail, facing * sstep(0.05f, 0.25f, u) * (1.0f - sstep(0.95f, 1.15f, u)));
                }
                // albedo: blotches and freckles, a little darker in creases, the palms and soles paler
                float alb = 0.5f + 0.07f * fbm3(p * 22.0f, 3, 911u) + 0.035f * fbm3(p * 90.0f, 2, 913u);
                const float freckle = sstep(0.62f, 0.82f, vnoise(p * 420.0f, 917u)) * sstep(1.25f, 1.45f, p.y - lo) * 0.06f;
                alb -= freckle;
                alb -= creaseV * 0.08f;
                // the lash line: the rims of the lids, where they meet the eyeball, dark
                for (float sx : { 1.0f, -1.0f }) {
                    const glm::vec3 e(eyeL.x * sx, eyeL.y, eyeL.z);
                    const float d = glm::length(p - e);
                    if (p.z > e.z) alb -= 0.32f * sstep(eyeR * 1.32f, eyeR * 1.08f, d) * sstep(0.0f, 0.004f, p.z - e.z);
                }
                // redness: lips, cheeks, nose, ears, a little everywhere
                float red = std::max({ lip * 0.95f, cheek * 0.3f, nos * 0.22f, ear * 0.3f }) + 0.05f * (fbm3(p * 30.0f, 2, 919u) + 0.5f);
                red = std::clamp(red, 0.0f, 1.0f);
                // height detail: fine lines on the lips, soft bumps elsewhere (the pores come from the Skin material)
                auto height = [&](const glm::vec3& q) {
                    float h = 0.00012f * fbm3(q * 160.0f, 2, 921u);
                    h += lip * 0.00018f * std::sin(q.x * 2600.0f + 3.0f * vnoise(q * 300.0f, 923u));
                    return h;
                };
                const float eps = 0.0004f;
                const float h0 = height(p);
                const float gT = (height(p + T * eps) - h0) / eps, gB = (height(p + B * eps) - h0) / eps;
                glm::vec3 nt = glm::normalize(glm::vec3(-gT, -gB, 1.0f));
                // roughness: oily nose and forehead, wet lips, glossy nails
                float rough = 0.6f - nos * 0.12f - lip * 0.22f - nail * 0.3f + 0.05f * fbm3(p * 40.0f, 2, 927u);
                const glm::vec4 m0(std::clamp(alb, 0.0f, 1.0f), red, browHair, nail);
                const glm::vec4 m1(nt.x * 0.5f + 0.5f, nt.y * 0.5f + 0.5f, std::clamp(rough, 0.05f, 1.0f), std::clamp(creaseV * 0.8f, 0.0f, 1.0f));
                for (int k = 0; k < 4; ++k) {
                    out->map0[idx * 4 + size_t(k)] = std::uint8_t(std::lround(std::clamp(m0[k], 0.0f, 1.0f) * 255.0f));
                    out->map1[idx * 4 + size_t(k)] = std::uint8_t(std::lround(std::clamp(m1[k], 0.0f, 1.0f) * 255.0f));
                }
            }
    };
    const int threads = std::max(1, std::min(8, int(std::thread::hardware_concurrency())));
    std::vector<std::thread> pool;
    for (int k = 0; k < threads; ++k) pool.emplace_back(shade, S * k / threads, S * (k + 1) / threads);
    for (std::thread& th : pool) th.join();

    // the eyes
    out->eyeW = pk.eyeImgW; out->eyeH = pk.eyeImgH; out->eye = pk.eyeImg;
    // a hair card: fine strands along v, each its own shade and length, thinning to their tips
    {
        const int H = 512;
        out->hairSize = H;
        out->hair.assign(size_t(H) * size_t(H) * 4, 0);
        HairRng rng(4242u);
        std::vector<float> cov(size_t(H) * size_t(H), 0.0f), bright(size_t(H) * size_t(H), 0.0f), which(size_t(H) * size_t(H), 0.0f);
        for (int i = 0; i < 1400; ++i) {
            const float x0 = rng.range(0.0f, float(H)), width = rng.range(0.7f, 1.6f), shade = rng.range(0.5f, 1.0f), id = rng.f();
            const float len = rng.range(0.7f, 1.0f), start = rng.range(0.0f, 0.08f), wave = rng.range(-2.0f, 2.0f), ph = rng.range(0.0f, 6.28f);
            for (int y = 0; y < H; ++y) {
                const float v = (float(y) + 0.5f) / float(H);
                if (v < start || v > len) continue;
                const float thin = 1.0f - sstep(len - 0.25f, len, v);           // tapering to the tip
                const float cx = x0 + wave * std::sin(v * 6.0f + ph) + v * wave;
                const float w = width * (0.35f + 0.65f * thin);
                for (int dx = -2; dx <= 2; ++dx) {
                    const int x = ((int(std::floor(cx)) + dx) % H + H) % H;
                    const float d = std::fabs(float(int(std::floor(cx)) + dx) + 0.5f - cx);
                    const float a = std::clamp(w * 0.5f + 0.5f - d, 0.0f, 1.0f);
                    if (a <= 0.0f) continue;
                    const size_t idx = size_t(y) * size_t(H) + size_t(x);
                    if (a > cov[idx]) { bright[idx] = shade * (0.8f + 0.2f * std::sin(v * 40.0f + ph)); which[idx] = id; }
                    cov[idx] = std::min(1.0f, cov[idx] + a);
                }
            }
        }
        for (size_t i = 0; i < cov.size(); ++i) {
            out->hair[i * 4] = std::uint8_t(std::lround(std::clamp(bright[i], 0.0f, 1.0f) * 255.0f));
            out->hair[i * 4 + 1] = std::uint8_t(std::lround(which[i] * 255.0f));
            out->hair[i * 4 + 3] = std::uint8_t(std::lround(std::clamp(cov[i] * 1.6f, 0.0f, 1.0f) * 255.0f));
        }
    }
    // the expressions, dense over the base vertices
    static const char* exprNames[kMaxExpressions] = { "expr:blink", "expr:mouth-open", "expr:smile", "expr:frown", "expr:press",
                                                      "expr:brows-down", "expr:brows-up", "expr:brows-worried" };
    out->expressionVertices = int(nbase);
    out->expressions.assign(size_t(kMaxExpressions) * nbase * 3, 0.0f);
    for (int e = 0; e < kMaxExpressions; ++e) {
        auto it = pk.targets.find(exprNames[e]);
        if (it == pk.targets.end()) continue;
        for (size_t k = 0; k < it->second.idx.size(); ++k) {
            const size_t at = (size_t(e) * nbase + it->second.idx[k]) * 3;
            out->expressions[at] = it->second.d[k].x; out->expressions[at + 1] = it->second.d[k].y; out->expressions[at + 2] = it->second.d[k].z;
        }
    }
    static std::atomic<std::uint32_t> version{ 0 };
    out->version = ++version;
    return out;
}

void ensureHumanRenderData() {
    if (humanRenderData() || !humanBodyAvailable()) return;
    constexpr int kSize = 2048;
    constexpr int kCacheVersion = 4;
    namespace fs = std::filesystem;
    const std::string path = "cache/human/skin_" + std::to_string(kSize) + "_v" + std::to_string(kCacheVersion) + ".bin";
    const size_t bytes = size_t(kSize) * size_t(kSize) * 4;
    std::shared_ptr<HumanRenderData> d;
    {   // from the cache: the maps only (the rest is quick to make)
        std::ifstream f(path, std::ios::binary);
        std::vector<std::uint8_t> a(bytes), b(bytes);
        if (f && f.read(reinterpret_cast<char*>(a.data()), std::streamsize(bytes)) && f.read(reinterpret_cast<char*>(b.data()), std::streamsize(bytes))) {
            d = bakeHumanRenderData(16);                      // (cheap: the eyes and expressions, with tiny maps we replace)
            if (d) { d->mapSize = kSize; d->map0 = std::move(a); d->map1 = std::move(b); }
        }
    }
    if (!d) {
        d = bakeHumanRenderData(kSize);
        if (!d) return;
        std::error_code ec;
        fs::create_directories("cache/human", ec);
        std::ofstream f(path + ".tmp", std::ios::binary);
        f.write(reinterpret_cast<const char*>(d->map0.data()), std::streamsize(bytes));
        f.write(reinterpret_cast<const char*>(d->map1.data()), std::streamsize(bytes));
        f.close();
        if (f) fs::rename(path + ".tmp", path, ec);
    }
    humanRenderData() = d;
}

} // namespace px
