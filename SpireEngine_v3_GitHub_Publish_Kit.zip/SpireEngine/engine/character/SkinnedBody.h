#pragma once
// One continuous, smoothly skinned body for a character (1.2).
//
// The parts on the trunk and limbs (hips, torso, neck, arms, legs: whatever the character wears there, built-in or
// your own) are placed on the skeleton's rest pose and fused into one surface: their shapes are sampled together into
// a single voxel grid and meshed once, so where a sleeve meets a shoulder or a thigh meets the hips there is one skin,
// not two pieces touching. Every vertex then gets weights: it follows the bone of the part it came from, and near a
// joint it is shared with the bone on the other side, smoothly, so knees, elbows, hips and shoulders bend instead of
// parting. The hands and feet are fused in too, from finer grids; the head, hair and accessories stay as their own pieces
// on their bones (the face changes shape with every blink and mood).
//
// Bodies are cached by everything that changes them (parts, colours, body shape), so a crowd of the same person
// builds once.
#include <memory>
#include <string>
#include "character/Character.h"
#include "render/SkinnedMesh.h"

namespace px {

class AssetLibrary;

// The pose bodies are built in: arms out and legs a little apart, so nothing is fused that should not be.
Pose skinBindPose();
// The bones whose parts are fused into the skinned body.
bool boneIsSkinned(Bone b);
inline constexpr int kSkinnedBoneCount = 15;   // every bone but the head

// Draw characters as skinned bodies (true, the default) or as rigid parts (the 1.1 way; tests use it).
void setCharacterSkinning(bool on);
bool characterSkinning();

// The body for this character and skeleton (built the first time, then cached). nullptr if nothing could be built.
std::shared_ptr<const SkinnedMesh> skinnedBodyFor(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib);
// Builds one without the cache (tests). `voxel` is the sampling step in metres.
std::shared_ptr<SkinnedMesh> buildSkinnedBody(const CharacterDef& c, const Skeleton& sk, AssetLibrary& lib, float voxel = 0.008f);
// How many bodies are cached; empties the cache (when assets change).
size_t skinnedBodyCacheSize();
void clearSkinnedBodyCache();

} // namespace px
