// Procedurally generated starter sounds. Nothing here is a recording: every clip is
// synthesised from noise, sine partials and a few filters when the engine starts, so
// Spire Engine ships with no audio files and still has a voice for every surface.
// Deterministic: the same seed always gives the same clip.
#include "AudioEngine.h"
#include <algorithm>
#include <atomic>
#include <cmath>
#include <functional>
#include <thread>

namespace px {
namespace {

constexpr float kPi = 3.14159265358979f;
constexpr int   kRate = 48000;
using Buf = std::vector<float>;

// ---------------------------------------------------------------- small DSP toolbox

struct Rng {
    std::uint32_t s;
    explicit Rng(std::uint32_t seed) : s(seed * 2654435761u + 0x9E3779B9u) { for (int i = 0; i < 4; ++i) next(); }
    std::uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
    float uni() { return float(next() >> 8) * (1.0f / 16777216.0f); }       // 0..1
    float sig() { return uni() * 2.0f - 1.0f; }                              // -1..1
    float range(float a, float b) { return a + (b - a) * uni(); }
};

// Topology-preserving state-variable filter: stable when the cutoff moves every sample.
struct SVF {
    float ic1 = 0.0f, ic2 = 0.0f;
    struct Out { float lp, bp, hp; };
    Out tick(float x, float fc, float q) {
        fc = std::clamp(fc, 20.0f, 0.45f * float(kRate));
        const float g = std::tan(kPi * fc / float(kRate)), k = 1.0f / std::max(q, 0.1f);
        const float a1 = 1.0f / (1.0f + g * (g + k)), a2 = g * a1, a3 = g * a2;
        const float v3 = x - ic2;
        const float v1 = a1 * ic1 + a2 * v3;
        const float v2 = ic2 + a2 * ic1 + a3 * v3;
        ic1 = 2.0f * v1 - ic1; ic2 = 2.0f * v2 - ic2;
        return { v2, v1, x - k * v1 - v2 };
    }
};

enum class Ft { Low, Band, High };
Buf filtered(const Buf& in, Ft t, float fc, float q = 0.707f) {
    SVF f; Buf out(in.size());
    for (size_t i = 0; i < in.size(); ++i) {
        auto o = f.tick(in[i], fc, q);
        out[i] = t == Ft::Low ? o.lp : t == Ft::Band ? o.bp * (1.0f / std::max(q, 0.5f)) * 2.0f : o.hp;
    }
    return out;
}
// Cutoff given per sample (0..1 progress through the clip).
Buf filteredSweep(const Buf& in, Ft t, const std::function<float(float)>& fc, float q) {
    SVF f; Buf out(in.size());
    const float inv = 1.0f / float(std::max<size_t>(in.size(), 1));
    for (size_t i = 0; i < in.size(); ++i) {
        auto o = f.tick(in[i], fc(float(i) * inv), q);
        out[i] = t == Ft::Low ? o.lp : t == Ft::Band ? o.bp * (1.0f / std::max(q, 0.5f)) * 2.0f : o.hp;
    }
    return out;
}

// Two cascaded low-pass filters (12 dB/octave): takes the fizz off broadband noise.
Buf softened(const Buf& in, float hz) { return filtered(filtered(in, Ft::Low, hz, 0.707f), Ft::Low, hz, 0.707f); }

size_t samples(float seconds) { return size_t(seconds * float(kRate)); }
Buf noise(Rng& r, float seconds) { Buf b(samples(seconds)); for (auto& s : b) s = r.sig(); return b; }
Buf silence(float seconds) { return Buf(samples(seconds), 0.0f); }

// Exponential decay envelope: attack (s) then e^(-t/decay).
float env(float t, float attack, float decay) {
    if (t < 0.0f) return 0.0f;
    const float a = attack > 0.0f ? std::min(1.0f, t / attack) : 1.0f;
    return a * a * std::exp(-t / std::max(decay, 1e-4f));
}

void applyEnv(Buf& b, float attack, float decay) {
    for (size_t i = 0; i < b.size(); ++i) b[i] *= env(float(i) / float(kRate), attack, decay);
}
void mixInto(Buf& dst, const Buf& src, float gain = 1.0f, float delaySeconds = 0.0f) {
    const size_t off = samples(delaySeconds);
    if (dst.size() < off + src.size()) dst.resize(off + src.size(), 0.0f);
    for (size_t i = 0; i < src.size(); ++i) dst[off + i] += src[i] * gain;
}
// A sine whose pitch glides f0 -> f1 (exponentially) with its own envelope.
Buf sweepTone(float f0, float f1, float seconds, float attack, float decay, float phase0 = 0.0f) {
    Buf b(samples(seconds));
    double ph = phase0;
    const float n = float(std::max<size_t>(b.size(), 1));
    for (size_t i = 0; i < b.size(); ++i) {
        const float u = float(i) / n;
        const float f = f0 * std::pow(f1 / f0, u);
        ph += 2.0 * kPi * f / kRate;
        b[i] = std::sin(float(ph)) * env(float(i) / kRate, attack, decay);
    }
    return b;
}
// Short decaying clicks scattered through a time span (crunch, gravel, snow).
Buf crackle(Rng& r, float seconds, int count, float decay, float spreadPow = 1.0f) {
    Buf b = silence(seconds);
    for (int c = 0; c < count; ++c) {
        const float t = std::pow(r.uni(), spreadPow) * (seconds - 0.02f);
        const float amp = r.range(0.3f, 1.0f);
        const size_t start = samples(t), len = samples(decay * 6.0f);
        for (size_t i = 0; i < len && start + i < b.size(); ++i)
            b[start + i] += r.sig() * amp * std::exp(-float(i) / (decay * kRate));
    }
    return b;
}

void normalize(Buf& b, float peak) {
    float m = 1e-9f;
    for (float s : b) m = std::max(m, std::fabs(s));
    const float g = peak / m;
    for (float& s : b) s *= g;
}
// Fades the first and last few ms so one-shots never click.
void declick(Buf& b, float ms = 3.0f) {
    const size_t n = std::min(samples(ms * 0.001f), b.size() / 2);
    for (size_t i = 0; i < n; ++i) {
        const float g = float(i) / float(n);
        b[i] *= g; b[b.size() - 1 - i] *= g;
    }
}
// Loops: render L + X samples, then cross-fade the extra X back onto the start so the
// end meets the beginning without a seam.
Buf makeLoop(const Buf& gen, float seconds, float xfadeSeconds = 1.2f) {
    const size_t L = samples(seconds), X = std::min(samples(xfadeSeconds), L / 2);
    Buf out(L);
    for (size_t i = 0; i < L; ++i) out[i] = gen[i];
    for (size_t i = 0; i < X; ++i) {
        const float t = float(i) / float(X);
        out[i] = gen[i] * std::sin(t * kPi * 0.5f) + gen[L + i] * std::cos(t * kPi * 0.5f);
    }
    return out;
}
// Slow wandering modulation 0..1: a few incommensurate sines.
float wander(float t, float seed, float speed) {
    return 0.5f + 0.5f * (0.55f * std::sin(t * speed * 0.9f + seed) + 0.30f * std::sin(t * speed * 2.3f + seed * 1.7f) +
                          0.15f * std::sin(t * speed * 5.1f + seed * 2.9f));
}

std::shared_ptr<Clip> make(const std::string& name, Buf&& data) {
    auto c = std::make_shared<Clip>();
    c->name = name; c->sampleRate = kRate; c->samples = std::move(data);
    return c;
}

// ---------------------------------------------------------------- footsteps

struct StepProfile {
    // body: filtered noise burst
    Ft    bodyType = Ft::Low; float bodyHz = 1200, bodyQ = 0.8f, bodyAttack = 0.004f, bodyDecay = 0.04f, bodyLevel = 1.0f;
    // thud: a falling sine under the step
    float thudHz = 0, thudDecay = 0.05f, thudLevel = 0.0f;
    // crackle: grit (gravel, snow, dry leaves)
    int   grit = 0; float gritHz = 3000, gritDecay = 0.004f, gritLevel = 0.0f, gritSpan = 0.12f;
    // ring: inharmonic partials (metal, wood)
    float ringHz[3] = { 0, 0, 0 }; float ringDecay = 0.1f, ringLevel = 0.0f;
    float postLowHz = 0;                 // > 0: soften the whole step (grass, sand, snow...)
    float length = 0.2f;
};

Buf synthStep(const StepProfile& p, std::uint32_t seed) {
    Rng r(seed);
    const float vary = r.range(0.88f, 1.14f);                     // every footfall a little different
    Buf out = silence(p.length);
    Buf body = noise(r, p.length);
    body = filtered(body, p.bodyType, p.bodyHz * vary, p.bodyQ);
    applyEnv(body, p.bodyAttack, p.bodyDecay * r.range(0.9f, 1.15f));
    mixInto(out, body, p.bodyLevel);
    if (p.thudLevel > 0.0f) {
        Buf t = sweepTone(p.thudHz * vary * 1.5f, p.thudHz * vary * 0.6f, p.length, 0.002f, p.thudDecay);
        mixInto(out, t, p.thudLevel);
    }
    if (p.grit > 0) {
        Buf g = crackle(r, p.gritSpan, p.grit, p.gritDecay);
        g = filtered(g, Ft::Band, p.gritHz * vary, 1.2f);
        mixInto(out, g, p.gritLevel);
    }
    if (p.ringLevel > 0.0f) {
        for (float hz : p.ringHz) {
            if (hz <= 0.0f) continue;
            Buf t = sweepTone(hz * vary, hz * vary * 0.995f, p.length, 0.0005f, p.ringDecay * r.range(0.8f, 1.2f), r.uni() * 6.28f);
            mixInto(out, t, p.ringLevel / 3.0f);
        }
    }
    out.resize(samples(p.length));
    if (p.postLowHz > 0.0f) out = softened(out, p.postLowHz * vary);
    declick(out, 2.0f);
    normalize(out, 0.55f);
    return out;
}

StepProfile profileFor(const std::string& m) {
    StepProfile p;
    if (m == "grass") {          // soft swish with a dull thump
        p.bodyType = Ft::Band; p.bodyHz = 2600; p.bodyQ = 0.7f; p.bodyAttack = 0.012f; p.bodyDecay = 0.05f; p.bodyLevel = 0.8f;
        p.thudHz = 90; p.thudDecay = 0.04f; p.thudLevel = 0.6f; p.postLowHz = 3000; p.length = 0.22f;
    } else if (m == "dirt") {    // thud + a bit of crumble
        p.bodyType = Ft::Low; p.bodyHz = 700; p.bodyQ = 0.9f; p.bodyAttack = 0.003f; p.bodyDecay = 0.045f; p.bodyLevel = 0.9f;
        p.thudHz = 80; p.thudDecay = 0.05f; p.thudLevel = 0.9f;
        p.grit = 9; p.gritHz = 1800; p.gritDecay = 0.003f; p.gritLevel = 0.35f; p.gritSpan = 0.10f; p.postLowHz = 4500; p.length = 0.2f;
    } else if (m == "stone") {   // sharp tick + knock
        p.bodyType = Ft::High; p.bodyHz = 1500; p.bodyQ = 0.8f; p.bodyAttack = 0.0005f; p.bodyDecay = 0.012f; p.bodyLevel = 0.7f;
        p.thudHz = 130; p.thudDecay = 0.04f; p.thudLevel = 0.9f;
        p.ringHz[0] = 1900; p.ringHz[1] = 3100; p.ringDecay = 0.015f; p.ringLevel = 0.4f; p.length = 0.16f;
    } else if (m == "sand") {    // long hush
        p.bodyType = Ft::Band; p.bodyHz = 3400; p.bodyQ = 0.6f; p.bodyAttack = 0.03f; p.bodyDecay = 0.07f; p.bodyLevel = 1.0f;
        p.thudHz = 70; p.thudDecay = 0.05f; p.thudLevel = 0.35f;
        p.grit = 22; p.gritHz = 4200; p.gritDecay = 0.0015f; p.gritLevel = 0.3f; p.gritSpan = 0.2f; p.postLowHz = 4800; p.length = 0.3f;
    } else if (m == "snow") {    // crunch: many fine clicks
        p.bodyType = Ft::Band; p.bodyHz = 2200; p.bodyQ = 0.8f; p.bodyAttack = 0.01f; p.bodyDecay = 0.05f; p.bodyLevel = 0.45f;
        p.thudHz = 75; p.thudDecay = 0.04f; p.thudLevel = 0.4f;
        p.grit = 34; p.gritHz = 3200; p.gritDecay = 0.0025f; p.gritLevel = 0.9f; p.gritSpan = 0.2f; p.postLowHz = 5200; p.length = 0.28f;
    } else if (m == "wood") {    // hollow knock
        p.bodyType = Ft::Band; p.bodyHz = 650; p.bodyQ = 3.0f; p.bodyAttack = 0.001f; p.bodyDecay = 0.04f; p.bodyLevel = 0.9f;
        p.thudHz = 175; p.thudDecay = 0.07f; p.thudLevel = 0.9f;
        p.ringHz[0] = 330; p.ringHz[1] = 560; p.ringDecay = 0.05f; p.ringLevel = 0.5f; p.length = 0.22f;
    } else if (m == "metal") {   // clank
        p.bodyType = Ft::High; p.bodyHz = 3000; p.bodyQ = 0.8f; p.bodyAttack = 0.0003f; p.bodyDecay = 0.008f; p.bodyLevel = 0.6f;
        p.thudHz = 150; p.thudDecay = 0.03f; p.thudLevel = 0.5f;
        p.ringHz[0] = 420; p.ringHz[1] = 1130; p.ringHz[2] = 2210; p.ringDecay = 0.12f; p.ringLevel = 1.2f; p.length = 0.45f;
    } else if (m == "brick") {   // duller stone
        p.bodyType = Ft::Low; p.bodyHz = 2200; p.bodyQ = 0.8f; p.bodyAttack = 0.001f; p.bodyDecay = 0.02f; p.bodyLevel = 0.8f;
        p.thudHz = 110; p.thudDecay = 0.05f; p.thudLevel = 1.0f;
        p.ringHz[0] = 1200; p.ringHz[1] = 2100; p.ringDecay = 0.012f; p.ringLevel = 0.3f; p.length = 0.18f;
    }
    return p;
}

Buf synthWaterStep(std::uint32_t seed) {          // a foot through shallow water
    Rng r(seed);
    Buf out = silence(0.4f);
    Buf s = noise(r, 0.4f);
    s = filteredSweep(s, Ft::Band, [](float u) { return 1400.0f + 1600.0f * u; }, 1.1f);
    applyEnv(s, 0.01f, 0.09f);
    mixInto(out, s, 0.9f);
    for (int i = 0; i < 5; ++i) {                  // bubbles
        const float f = r.range(500.0f, 1400.0f);
        Buf b = sweepTone(f, f * 1.5f, 0.09f, 0.002f, 0.025f);
        mixInto(out, b, r.range(0.15f, 0.4f), r.range(0.0f, 0.18f));
    }
    out.resize(samples(0.4f));
    out = softened(out, 5000);
    declick(out);
    normalize(out, 0.5f);
    return out;
}

// ---------------------------------------------------------------- movement

Buf synthLand(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.35f);
    mixInto(out, sweepTone(120, 45, 0.35f, 0.002f, 0.09f), 1.0f);
    Buf n = filtered(noise(r, 0.3f), Ft::Low, 900, 0.8f); applyEnv(n, 0.002f, 0.05f);
    mixInto(out, n, 0.7f);
    out.resize(samples(0.35f)); declick(out); normalize(out, 0.7f);
    return out;
}
Buf synthJump(std::uint32_t seed) {
    Rng r(seed);
    Buf n = filteredSweep(noise(r, 0.22f), Ft::Band, [](float u) { return 500.0f + 1800.0f * u; }, 1.2f);
    applyEnv(n, 0.04f, 0.07f);
    n = softened(n, 4000);
    declick(n); normalize(n, 0.4f);
    return n;
}
Buf synthSplash(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.8f);
    Buf s = filteredSweep(noise(r, 0.8f), Ft::Band, [](float u) { return 3200.0f - 2200.0f * u; }, 0.7f);
    applyEnv(s, 0.006f, 0.16f);
    mixInto(out, s, 1.0f);
    Buf low = filtered(noise(r, 0.5f), Ft::Low, 350, 0.9f); applyEnv(low, 0.01f, 0.12f);
    mixInto(out, low, 0.8f);
    for (int i = 0; i < 12; ++i) {
        const float f = r.range(600.0f, 2200.0f);
        mixInto(out, sweepTone(f, f * r.range(1.3f, 1.8f), 0.1f, 0.002f, 0.03f), r.range(0.08f, 0.3f), r.range(0.0f, 0.5f));
    }
    out.resize(samples(0.8f)); out = softened(out, 6500); declick(out, 5.0f); normalize(out, 0.7f);
    return out;
}
Buf synthSwim(std::uint32_t seed) {
    Rng r(seed);
    Buf s = noise(r, 0.55f);
    s = filteredSweep(s, Ft::Band, [](float u) { return 600.0f + 900.0f * std::sin(u * kPi); }, 0.9f);
    for (size_t i = 0; i < s.size(); ++i) {
        const float u = float(i) / float(s.size());
        s[i] *= std::sin(u * kPi) * (0.6f + 0.4f * std::sin(u * 30.0f));
    }
    Buf out = s;
    for (int i = 0; i < 3; ++i) {
        const float f = r.range(400.0f, 1000.0f);
        mixInto(out, sweepTone(f, f * 1.6f, 0.08f, 0.002f, 0.025f), 0.25f, r.range(0.05f, 0.4f));
    }
    out = softened(out, 3500);
    declick(out, 8.0f); normalize(out, 0.45f);
    return out;
}

// ---------------------------------------------------------------- tools & powers

Buf synthDig(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.32f);
    Buf n = filteredSweep(noise(r, 0.32f), Ft::Low, [](float u) { return 3000.0f * std::exp(-3.0f * u) + 250.0f; }, 0.9f);
    applyEnv(n, 0.004f, 0.08f);
    mixInto(out, n, 1.0f);
    mixInto(out, sweepTone(110, 50, 0.3f, 0.002f, 0.08f), 0.9f);
    mixInto(out, filtered(crackle(r, 0.25f, 14, 0.004f, 1.8f), Ft::Band, 2200, 1.0f), 0.5f);
    out.resize(samples(0.32f)); declick(out); normalize(out, 0.7f);
    return out;
}
Buf synthBuild(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.28f);
    mixInto(out, sweepTone(160, 300, 0.26f, 0.004f, 0.1f), 1.0f);
    Buf n = filtered(noise(r, 0.2f), Ft::Band, 1100, 1.0f); applyEnv(n, 0.01f, 0.05f);
    mixInto(out, n, 0.6f);
    mixInto(out, filtered(crackle(r, 0.2f, 8, 0.003f), Ft::Band, 2500, 1.0f), 0.3f);
    out.resize(samples(0.28f)); declick(out); normalize(out, 0.65f);
    return out;
}
Buf synthSmooth(std::uint32_t seed) {
    Rng r(seed);
    Buf n = filteredSweep(noise(r, 0.4f), Ft::Band, [](float u) { return 900.0f + 1200.0f * std::sin(u * kPi); }, 0.8f);
    for (size_t i = 0; i < n.size(); ++i) { const float u = float(i) / float(n.size()); n[i] *= std::sin(u * kPi) * std::sin(u * kPi); }
    n = softened(n, 4500);
    declick(n); normalize(n, 0.45f);
    return n;
}
Buf synthPaint(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.22f);
    mixInto(out, sweepTone(300, 950, 0.12f, 0.002f, 0.04f), 0.8f);
    Buf n = filtered(noise(r, 0.16f), Ft::Band, 1800, 1.5f); applyEnv(n, 0.003f, 0.03f);
    mixInto(out, n, 0.35f);
    mixInto(out, sweepTone(520, 1500, 0.1f, 0.002f, 0.03f), 0.4f, 0.07f);
    out.resize(samples(0.22f)); declick(out); normalize(out, 0.5f);
    return out;
}
Buf synthStamp(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.45f);
    mixInto(out, sweepTone(100, 38, 0.45f, 0.002f, 0.12f), 1.0f);
    Buf n = filtered(noise(r, 0.3f), Ft::Low, 1400, 0.8f); applyEnv(n, 0.002f, 0.05f);
    mixInto(out, n, 0.8f);
    mixInto(out, filtered(crackle(r, 0.3f, 16, 0.004f, 1.6f), Ft::Band, 1800, 1.0f), 0.4f, 0.03f);
    out.resize(samples(0.45f)); declick(out); normalize(out, 0.75f);
    return out;
}
Buf synthClick() {
    Buf out = silence(0.06f);
    mixInto(out, sweepTone(1900, 1900, 0.05f, 0.0003f, 0.012f), 0.8f);
    mixInto(out, sweepTone(3800, 3800, 0.03f, 0.0003f, 0.006f), 0.25f);
    declick(out, 1.0f); normalize(out, 0.4f);
    return out;
}
Buf synthWhoosh(std::uint32_t seed) {
    Rng r(seed);
    Buf n = filteredSweep(noise(r, 0.6f), Ft::Band, [](float u) { return 300.0f + 3200.0f * std::sin(u * kPi) * std::sin(u * kPi * 0.5f); }, 1.3f);
    for (size_t i = 0; i < n.size(); ++i) { const float u = float(i) / float(n.size()); n[i] *= std::pow(std::sin(u * kPi), 1.5f); }
    n = softened(n, 5500);
    declick(n); normalize(n, 0.6f);
    return n;
}
Buf synthZap(std::uint32_t seed) {
    Rng r(seed);
    Buf out(samples(0.4f), 0.0f);
    double ph = 0.0;
    for (size_t i = 0; i < out.size(); ++i) {
        const float t = float(i) / kRate, u = t / 0.4f;
        const float f = 2400.0f * std::exp(-4.5f * u) + 160.0f;
        ph += f / kRate;
        const float saw = 2.0f * float(ph - std::floor(ph)) - 1.0f;
        const float sq = std::sin(2.0f * kPi * float(ph) * 2.01f);
        out[i] = (0.7f * saw + 0.4f * sq + 0.25f * r.sig()) * env(t, 0.001f, 0.1f);
    }
    out = filtered(out, Ft::Low, 5500, 0.9f);
    declick(out); normalize(out, 0.55f);
    return out;
}
// ---- game rules (v0.21): pickups, chimes, doors, teleports, winning and losing
Buf notes(const std::vector<float>& freqs, float gap, float len, float decay, float gain = 1.0f) {
    Buf out = silence(gap * float(freqs.size()) + len);
    for (size_t i = 0; i < freqs.size(); ++i) {
        mixInto(out, sweepTone(freqs[i], freqs[i], len, 0.002f, decay), gain, gap * float(i));
        mixInto(out, sweepTone(freqs[i] * 2.0f, freqs[i] * 2.0f, len, 0.002f, decay * 0.5f), gain * 0.25f, gap * float(i));
    }
    return out;
}
Buf synthPickup() { Buf b = notes({ 988.0f, 1319.0f }, 0.07f, 0.25f, 0.09f); declick(b); normalize(b, 0.45f); return b; }
Buf synthChime() { Buf b = notes({ 784.0f, 988.0f, 1175.0f }, 0.09f, 0.6f, 0.25f); declick(b); normalize(b, 0.4f); return b; }
Buf synthWin() { Buf b = notes({ 523.0f, 659.0f, 784.0f, 1047.0f }, 0.14f, 0.7f, 0.3f); declick(b); normalize(b, 0.5f); return b; }
Buf synthLose() { Buf b = notes({ 392.0f, 349.0f, 311.0f, 262.0f }, 0.22f, 0.7f, 0.3f); b = filtered(b, Ft::Low, 2500, 0.7f); declick(b); normalize(b, 0.5f); return b; }
Buf synthDoor(std::uint32_t seed, bool opening) {
    Rng r(seed);
    Buf out = silence(0.7f);
    Buf creak = filteredSweep(noise(r, 0.55f), Ft::Band, [opening](float u) { return opening ? 500.0f + 900.0f * u : 1300.0f - 700.0f * u; }, 6.0f);
    for (size_t i = 0; i < creak.size(); ++i) { const float u = float(i) / float(creak.size()); creak[i] *= std::sin(u * kPi) * (0.6f + 0.4f * std::sin(u * 60.0f)); }
    mixInto(out, creak, 0.6f);
    if (!opening) mixInto(out, sweepTone(120, 70, 0.2f, 0.001f, 0.06f), 1.0f, 0.5f);       // the thud of it shutting
    declick(out); normalize(out, 0.5f);
    return out;
}
Buf synthTeleport() {
    Buf out(samples(0.6f), 0.0f);
    double ph = 0.0;
    for (size_t i = 0; i < out.size(); ++i) {
        const float t = float(i) / kRate, u = t / 0.6f;
        const float f = 300.0f + 1800.0f * u * u + 60.0f * std::sin(t * 90.0f);
        ph += f / kRate;
        out[i] = std::sin(2.0f * kPi * float(ph)) * std::sin(u * kPi);
    }
    declick(out); normalize(out, 0.4f);
    return out;
}

// ---- items: guns, launchers, reloading, bullets hitting things
Buf synthShot(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.6f);
    Buf crack = filteredSweep(noise(r, 0.3f), Ft::Low, [](float u) { return 7000.0f * std::exp(-9.0f * u) + 350.0f; }, 0.8f);
    applyEnv(crack, 0.0004f, 0.04f);
    mixInto(out, crack, 1.2f);
    mixInto(out, sweepTone(190, 52, 0.3f, 0.001f, 0.055f), 0.9f);
    Buf tail = filtered(noise(r, 0.5f), Ft::Low, 1100, 0.7f);
    applyEnv(tail, 0.01f, 0.14f);
    mixInto(out, tail, 0.28f, 0.015f);
    out.resize(samples(0.6f)); declick(out, 1.5f); normalize(out, 0.85f);
    return out;
}
Buf synthLaunch(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(1.0f);
    mixInto(out, sweepTone(110, 38, 0.6f, 0.002f, 0.14f), 1.0f);
    Buf hiss = filteredSweep(noise(r, 0.9f), Ft::Band, [](float u) { return 700.0f + 2600.0f * u; }, 0.9f);
    applyEnv(hiss, 0.04f, 0.28f);
    mixInto(out, hiss, 0.7f);
    Buf pop = filtered(noise(r, 0.12f), Ft::Low, 2400, 0.8f); applyEnv(pop, 0.0005f, 0.02f);
    mixInto(out, pop, 0.9f);
    out.resize(samples(1.0f)); declick(out, 2.0f); normalize(out, 0.8f);
    return out;
}
Buf synthReload(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.9f);
    auto click = [&](float at, float hz, float gain) {
        Buf c = sweepTone(hz, hz * 0.75f, 0.05f, 0.0003f, 0.012f);
        Buf n = filtered(noise(r, 0.03f), Ft::High, 2500, 0.8f); applyEnv(n, 0.0002f, 0.006f);
        mixInto(out, c, gain, at);
        mixInto(out, n, gain * 0.6f, at);
    };
    click(0.00f, 1500, 0.6f);          // the magazine comes out
    click(0.30f, 900, 0.9f);           // and goes in
    Buf scrape = filteredSweep(noise(r, 0.12f), Ft::Band, [](float u) { return 1800.0f + 1800.0f * u; }, 1.2f);
    applyEnv(scrape, 0.004f, 0.05f);
    mixInto(out, scrape, 0.5f, 0.56f); // the slide
    click(0.70f, 2100, 0.8f);          // and it clacks home
    out.resize(samples(0.9f)); declick(out, 1.5f); normalize(out, 0.55f);
    return out;
}
Buf synthBulletHit(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(0.4f);
    Buf crack = filtered(noise(r, 0.12f), Ft::Band, 2600, 0.9f); applyEnv(crack, 0.0003f, 0.012f);
    mixInto(out, crack, 0.9f);
    mixInto(out, sweepTone(260, 95, 0.22f, 0.001f, 0.045f), 0.8f);
    mixInto(out, filtered(crackle(r, 0.3f, 10, 0.004f, 1.5f), Ft::Band, 3200, 1.0f), 0.45f, 0.01f);
    out.resize(samples(0.4f)); declick(out, 1.0f); normalize(out, 0.7f);
    return out;
}

Buf synthBoom(std::uint32_t seed) {
    Rng r(seed);
    Buf out = silence(1.6f);
    mixInto(out, sweepTone(85, 28, 1.6f, 0.004f, 0.35f), 1.0f);
    Buf n = filteredSweep(noise(r, 1.4f), Ft::Low, [](float u) { return 2800.0f * std::exp(-5.0f * u) + 90.0f; }, 0.8f);
    applyEnv(n, 0.003f, 0.25f);
    mixInto(out, n, 1.1f);
    Buf rumble = filtered(noise(r, 1.6f), Ft::Low, 120, 1.0f); applyEnv(rumble, 0.05f, 0.5f);
    mixInto(out, rumble, 0.9f);
    out.resize(samples(1.6f)); declick(out, 6.0f); normalize(out, 0.85f);
    return out;
}

// ---------------------------------------------------------------- ambient loops (all seamless)

Buf synthWind(std::uint32_t seed, float seconds, float strength) {
    Rng r(seed);
    const float xf = 1.5f;
    Buf n = noise(r, seconds + xf);
    SVF a, b;
    Buf out(n.size());
    for (size_t i = 0; i < n.size(); ++i) {
        const float t = float(i) / kRate;
        const float gust = wander(t, 1.3f + float(seed), 0.9f);
        const float fc = (180.0f + 700.0f * gust) * (0.6f + strength * 0.9f);
        const float whistle = 900.0f + 700.0f * wander(t, 4.1f + float(seed), 0.5f);
        auto o1 = a.tick(n[i], fc, 0.8f);
        auto o2 = b.tick(n[i], whistle, 6.0f + 6.0f * strength);
        out[i] = o1.lp * (0.4f + 1.2f * gust) + o2.bp * (0.04f + 0.2f * strength) * gust * gust;
    }
    Buf loop = makeLoop(out, seconds, xf);
    normalize(loop, 0.5f);
    return loop;
}
Buf synthCave(std::uint32_t seed) {
    Rng r(seed);
    const float seconds = 12.0f, xf = 2.0f;
    Buf n = noise(r, seconds + xf);
    SVF a;
    Buf out(n.size());
    for (size_t i = 0; i < n.size(); ++i) {
        const float t = float(i) / kRate;
        const float m = wander(t, 2.2f, 0.35f);
        out[i] = a.tick(n[i], 90.0f + 110.0f * m, 1.2f).lp * (0.5f + 0.7f * m)
               + 0.25f * std::sin(2.0f * kPi * 46.0f * t + 1.5f * std::sin(t * 0.7f)) * (0.4f + 0.6f * m);
    }
    Buf loop = makeLoop(out, seconds, xf);
    normalize(loop, 0.5f);
    return loop;
}
Buf synthWaterLap(std::uint32_t seed) {
    Rng r(seed);
    const float seconds = 10.0f, xf = 1.5f;
    Buf n = noise(r, seconds + xf);
    SVF a;
    Buf out(n.size());
    for (size_t i = 0; i < n.size(); ++i) {
        const float t = float(i) / kRate;
        // Swells arrive every ~4 s, a little irregular.
        const float swell = std::pow(0.5f + 0.5f * std::sin(t * 1.55f + 1.2f * std::sin(t * 0.37f)), 2.0f);
        out[i] = a.tick(n[i], 350.0f + 900.0f * swell, 0.9f).lp * (0.15f + 0.85f * swell);
    }
    for (int i = 0; i < 40; ++i) {                  // little plops and trickles
        const float f = r.range(700.0f, 2400.0f);
        mixInto(out, sweepTone(f, f * r.range(1.2f, 1.7f), 0.08f, 0.002f, 0.02f), r.range(0.04f, 0.14f), r.range(0.0f, seconds + xf - 0.1f));
    }
    out.resize(samples(seconds + xf));
    Buf loop = makeLoop(out, seconds, xf);
    normalize(loop, 0.45f);
    return loop;
}
Buf synthCrickets(std::uint32_t seed) {
    Rng r(seed);
    const float seconds = 9.0f, xf = 1.5f;
    Buf out = silence(seconds + xf);
    for (int c = 0; c < 7; ++c) {                   // seven insects, each with its own pitch and rhythm
        const float hz = r.range(3900.0f, 5200.0f);
        const float rate = r.range(24.0f, 36.0f);   // pulses per second inside a chirp
        const float period = r.range(0.55f, 0.95f);
        const float chirp = r.range(0.18f, 0.32f);
        const float offset = r.uni() * period;
        const float amp = r.range(0.4f, 1.0f);
        for (size_t i = 0; i < out.size(); ++i) {
            const float t = float(i) / kRate;
            const float ph = std::fmod(t + offset, period);
            if (ph > chirp) continue;
            const float pulse = std::max(0.0f, std::sin(2.0f * kPi * rate * ph));
            const float shape = std::sin(kPi * ph / chirp);
            out[i] += std::sin(2.0f * kPi * hz * t) * pulse * pulse * shape * amp;
        }
    }
    Buf loop = makeLoop(out, seconds, xf);
    normalize(loop, 0.35f);
    return loop;
}
Buf synthDayAir(std::uint32_t seed) {
    Rng r(seed);
    const float seconds = 10.0f, xf = 1.5f;
    Buf n = noise(r, seconds + xf);
    SVF a, b;
    Buf out(n.size());
    for (size_t i = 0; i < n.size(); ++i) {
        const float t = float(i) / kRate;
        const float m = wander(t, 0.7f, 0.6f);
        const float rustle = a.tick(n[i], 4200.0f + 1500.0f * m, 0.9f).bp;
        const float air = b.tick(n[i], 500.0f, 0.7f).lp;
        out[i] = rustle * (0.1f + 0.5f * m * m) + air * 0.25f;
    }
    Buf loop = makeLoop(out, seconds, xf);
    normalize(loop, 0.4f);
    return loop;
}

// ---------------------------------------------------------------- birds & drips

Buf synthBird(int variant) {
    Rng r(1000u + std::uint32_t(variant) * 77u);
    Buf out;
    const int notes = 2 + variant % 4 + int(r.uni() * 3.0f);
    const float base = r.range(2300.0f, 4800.0f);
    float t0 = 0.0f;
    for (int n = 0; n < notes; ++n) {
        const float dur = r.range(0.06f, 0.17f);
        const float f0 = base * r.range(0.8f, 1.35f);
        const float f1 = f0 * (variant % 2 ? r.range(0.65f, 0.95f) : r.range(1.1f, 1.5f));
        const float vib = r.range(0.0f, 40.0f), vibHz = r.range(18.0f, 40.0f);
        Buf note(samples(dur));
        double ph = 0.0;
        for (size_t i = 0; i < note.size(); ++i) {
            const float u = float(i) / float(note.size());
            const float f = f0 + (f1 - f0) * u + vib * std::sin(2.0f * kPi * vibHz * u * dur);
            ph += 2.0 * kPi * f / kRate;
            const float shape = std::sin(kPi * u);
            note[i] = (std::sin(float(ph)) + 0.28f * std::sin(2.0f * float(ph)) + 0.08f * std::sin(3.0f * float(ph))) * shape * shape;
        }
        mixInto(out, note, 1.0f, t0);
        t0 += dur + r.range(0.025f, 0.11f);
    }
    declick(out, 4.0f); normalize(out, 0.4f);
    return out;
}
Buf synthDrip(int variant) {
    Rng r(2000u + std::uint32_t(variant) * 31u);
    const float f = r.range(700.0f, 1500.0f);
    Buf out = silence(0.6f);
    mixInto(out, sweepTone(f, f * 1.35f, 0.25f, 0.001f, 0.045f), 1.0f);
    mixInto(out, sweepTone(f * 2.1f, f * 2.7f, 0.15f, 0.001f, 0.02f), 0.25f);
    // a faint cave-tail: two quiet, darker repeats
    Buf copy = filtered(out, Ft::Low, 1800, 0.7f);
    mixInto(out, copy, 0.28f, 0.11f);
    mixInto(out, copy, 0.12f, 0.23f);
    out.resize(samples(0.6f));
    declick(out); normalize(out, 0.45f);
    return out;
}

} // namespace

// ---------------------------------------------------------------- the bank

void generateSoundBank(AudioEngine& audio) {
    std::vector<std::function<void()>> jobs;
    auto add = [&](const std::string& name, std::function<Buf()> fn) {
        jobs.push_back([&audio, name, fn] { audio.addClip(make(name, fn())); });
    };

    const char* mats[] = { "grass", "dirt", "stone", "sand", "snow", "wood", "metal", "brick" };
    for (const char* m : mats)
        for (int v = 0; v < 4; ++v) {
            const std::string mat = m;
            add("step_" + mat + "_" + std::to_string(v), [mat, v] { return synthStep(profileFor(mat), 100u + std::uint32_t(v) * 13u + std::uint32_t(mat[0])); });
        }
    for (int v = 0; v < 4; ++v) add("step_water_" + std::to_string(v), [v] { return synthWaterStep(500u + std::uint32_t(v) * 11u); });

    add("land",   [] { return synthLand(1); });
    add("jump",   [] { return synthJump(2); });
    add("splash", [] { return synthSplash(3); });
    add("swim_0", [] { return synthSwim(4); });
    add("swim_1", [] { return synthSwim(5); });
    add("swim_2", [] { return synthSwim(6); });

    add("dig_0",    [] { return synthDig(10); });
    add("dig_1",    [] { return synthDig(11); });
    add("dig_2",    [] { return synthDig(12); });
    add("build_0",  [] { return synthBuild(20); });
    add("build_1",  [] { return synthBuild(21); });
    add("smooth_0", [] { return synthSmooth(30); });
    add("smooth_1", [] { return synthSmooth(31); });
    add("paint_0",  [] { return synthPaint(40); });
    add("paint_1",  [] { return synthPaint(41); });
    add("stamp",    [] { return synthStamp(50); });
    add("ui_click", [] { return synthClick(); });
    add("whoosh",   [] { return synthWhoosh(60); });
    add("zap",      [] { return synthZap(70); });
    add("boom",     [] { return synthBoom(80); });
    for (int i = 0; i < 3; ++i) add("shot_" + std::to_string(i), [i] { return synthShot(100u + std::uint32_t(i) * 7u); });
    add("launch",   [] { return synthLaunch(110); });
    add("pickup",     [] { return synthPickup(); });
    add("chime",      [] { return synthChime(); });
    add("win",        [] { return synthWin(); });
    add("lose",       [] { return synthLose(); });
    add("door open",  [] { return synthDoor(140, true); });
    add("door close", [] { return synthDoor(141, false); });
    add("teleport",   [] { return synthTeleport(); });
    add("reload",   [] { return synthReload(120); });
    for (int i = 0; i < 3; ++i) add("bullet_hit_" + std::to_string(i), [i] { return synthBulletHit(130u + std::uint32_t(i) * 5u); });

    add("wind",        [] { return synthWind(90, 10.0f, 0.3f); });
    add("wind_strong", [] { return synthWind(91, 10.0f, 1.0f); });
    add("cave",        [] { return synthCave(92); });
    add("water_lap",   [] { return synthWaterLap(93); });
    add("crickets",    [] { return synthCrickets(94); });
    add("day_air",     [] { return synthDayAir(95); });

    for (int i = 0; i < 6; ++i) add("bird_" + std::to_string(i), [i] { return synthBird(i); });
    for (int i = 0; i < 3; ++i) add("drip_" + std::to_string(i), [i] { return synthDrip(i); });

    // A small pool of threads works through the list; the heavy ones (loops) are first
    // in line by virtue of being cheap to schedule last, so just share evenly.
    std::atomic<size_t> next{ 0 };
    const unsigned workers = std::clamp(std::thread::hardware_concurrency(), 1u, 8u);
    auto work = [&] { for (size_t i; (i = next.fetch_add(1)) < jobs.size();) jobs[i](); };
    std::vector<std::thread> pool;
    for (unsigned i = 1; i < workers; ++i) pool.emplace_back(work);
    work();
    for (auto& t : pool) t.join();
}

} // namespace px
