#pragma once
// Spire Engine audio: a small software mixer on top of SDL3's audio device.
//
//   * Clips are mono float samples. The engine GENERATES its own starter sounds
//     (footsteps for every material, wind, birds, water, tool sounds...) when it
//     starts, so there are no sound files to ship. Your own .wav files load too.
//   * Voices play clips with volume, pitch, looping and fades. Spatial voices are
//     panned and attenuated from where they are relative to the listener, with
//     distance muffling; under water everything goes dull.
//   * Four buses (sfx, ambient, music, ui) plus master, each with a volume.
//
// Threading: everything here can be called from the main thread. The audio device
// thread only runs render(), which takes the same lock for a few hundred microseconds.
#include <array>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>
#include <glm/glm.hpp>

struct SDL_AudioStream;

namespace px {

struct Clip {
    std::string        name;
    std::vector<float> samples;       // mono
    int                sampleRate = 48000;
    float duration() const { return sampleRate > 0 ? float(samples.size()) / float(sampleRate) : 0.0f; }
};
using ClipPtr = std::shared_ptr<const Clip>;

enum class Bus { Sfx, Ambient, Music, Ui, Count };

struct PlayParams {
    Bus   bus    = Bus::Sfx;
    float volume = 1.0f;
    float pitch  = 1.0f;
    bool  loop   = false;
    float fadeIn = 0.0f;                    // seconds
    // Spatial voices come from `position`: full volume inside minDistance, fading to
    // silence at maxDistance, panned left/right, muffled with distance.
    bool      spatial     = false;
    glm::vec3 position{ 0.0f };
    float     minDistance = 2.0f;
    float     maxDistance = 70.0f;
};

using VoiceId = std::uint32_t;            // 0 = no voice

class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();

    // Opens the default playback device. Returns false if there is none; the engine
    // then stays silent (everything still works, nothing is heard).
    bool init();
    // No device: the caller pulls audio itself with render(). Used by tests and tools.
    void initOffline(int sampleRate = 48000);
    void shutdown();
    bool deviceOpen() const { return stream != nullptr; }
    int  sampleRate() const { return outRate; }

    // ---- clips
    ClipPtr clip(const std::string& name) const;                 // nullptr if unknown
    void    addClip(std::shared_ptr<Clip> c);
    bool    loadWav(const std::string& name, const std::string& path);   // mono-ised, resampled
    bool    saveWav(const std::string& name, const std::string& path) const;   // 16-bit mono
    int     exportAll(const std::string& folder) const;                  // every clip as <name>.wav
    std::vector<std::string> clipNames() const;

    // ---- playing
    VoiceId play(const ClipPtr& c, const PlayParams& p = {});
    VoiceId play(const std::string& clipName, const PlayParams& p = {});
    // Pick one of name_0, name_1, ... at random (footsteps, birds, drips).
    VoiceId playVariant(const std::string& baseName, const PlayParams& p = {});
    VoiceId playAt(const std::string& clipName, const glm::vec3& pos, float volume = 1.0f, Bus bus = Bus::Sfx);
    void    stop(VoiceId id, float fadeOut = 0.08f);
    void    stopAll(float fadeOut = 0.1f);
    bool    isPlaying(VoiceId id) const;
    // Live control of a running (usually looping) voice.
    void    setVoice(VoiceId id, float volume, float pitch = -1.0f);
    void    setVoicePosition(VoiceId id, const glm::vec3& pos);

    // ---- listener & mix
    void setListener(const glm::vec3& pos, const glm::vec3& forward, const glm::vec3& up = { 0, 1, 0 });
    void setUnderwater(bool u);
    void setBusVolume(Bus b, float v);
    float busVolume(Bus b) const { return busVol[size_t(b)]; }
    void setMasterVolume(float v) { master = v; }
    float masterVolume() const { return master; }
    void setMuted(bool m) { muted = m; }
    bool muted_() const { return muted; }

    // Mixes `frames` stereo frames (interleaved) into out. Called by the device thread.
    void render(float* out, int frames);
    int  activeVoices() const;

    static constexpr int kMaxVoices = 64;

private:
    struct Voice {
        bool        active = false;
        VoiceId     id = 0;
        ClipPtr     clip;
        double      pos = 0.0;                 // in source samples
        float       pitch = 1.0f, volume = 1.0f;
        bool        loop = false, spatial = false;
        glm::vec3   position{ 0.0f };
        float       minD = 2.0f, maxD = 70.0f;
        Bus         bus = Bus::Sfx;
        float       fade = 0.0f, fadeTarget = 1.0f, fadeRate = 0.0f;   // per-sample step
        bool        stopping = false;
        float       gL = 0.0f, gR = 0.0f;       // gains used at the end of the last block
        float       lp = 0.0f;                  // one-pole low-pass state
        std::uint64_t born = 0;
        bool        fresh = true;               // first block: start at full gain, no ramp-up click
    };

    Voice* findVoice(VoiceId id);
    const Voice* findVoice(VoiceId id) const;

    mutable std::mutex lock;
    std::unordered_map<std::string, ClipPtr> clips;
    std::array<Voice, kMaxVoices> voices;
    VoiceId nextId = 1;
    std::uint64_t counter = 0;

    glm::vec3 listenerPos{ 0.0f }, listenerRight{ 1, 0, 0 };
    bool underwater = false;
    float lpL = 0.0f, lpR = 0.0f;               // master low-pass (under water)
    float uwBlend = 0.0f;                       // 0..1, smoothed "under water" amount
    std::array<float, size_t(Bus::Count)> busVol{ 1.0f, 1.0f, 0.7f, 1.0f };
    float master = 0.8f;
    bool muted = false;

    SDL_AudioStream* stream = nullptr;
    bool sdlAudioInit = false;
    int outRate = 48000;
    std::vector<float> mixBuf;
};

// Procedurally generated starter sounds (audio/SoundBank.cpp).
void generateSoundBank(AudioEngine& audio);

} // namespace px
