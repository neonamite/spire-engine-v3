#include "AudioEngine.h"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <SDL3/SDL.h>

namespace px {

namespace {
constexpr float kPi = 3.14159265358979f;

void SDLCALL deviceCallback(void* user, SDL_AudioStream* stream, int additional, int /*total*/) {
    auto* engine = static_cast<AudioEngine*>(user);
    constexpr int kBlock = 1024;
    float buf[kBlock * 2];
    int frames = additional / int(sizeof(float) * 2);
    while (frames > 0) {
        const int n = std::min(frames, kBlock);
        engine->render(buf, n);
        SDL_PutAudioStreamData(stream, buf, n * int(sizeof(float) * 2));
        frames -= n;
    }
}
float smoothstep(float a, float b, float x) { const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }
} // namespace

AudioEngine::AudioEngine() = default;
AudioEngine::~AudioEngine() { shutdown(); }

bool AudioEngine::init() {
    shutdown();
    if (!SDL_InitSubSystem(SDL_INIT_AUDIO)) return false;
    sdlAudioInit = true;
    SDL_AudioSpec spec{};
    spec.format = SDL_AUDIO_F32;
    spec.channels = 2;
    spec.freq = 48000;
    stream = SDL_OpenAudioDeviceStream(SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK, &spec, deviceCallback, this);
    if (!stream) {
        SDL_QuitSubSystem(SDL_INIT_AUDIO);
        sdlAudioInit = false;
        initOffline();                       // sounds still exist (tests, tools), nothing is played
        return false;
    }
    outRate = 48000;
    generateSoundBank(*this);
    SDL_ResumeAudioStreamDevice(stream);
    return true;
}

void AudioEngine::initOffline(int sampleRate) {
    outRate = sampleRate;
    generateSoundBank(*this);
}

void AudioEngine::shutdown() {
    if (stream) { SDL_DestroyAudioStream(stream); stream = nullptr; }
    if (sdlAudioInit) { SDL_QuitSubSystem(SDL_INIT_AUDIO); sdlAudioInit = false; }
    std::lock_guard g(lock);
    for (auto& v : voices) v = Voice{};
}

// ---------------------------------------------------------------- clips

ClipPtr AudioEngine::clip(const std::string& name) const {
    std::lock_guard g(lock);
    auto it = clips.find(name);
    return it == clips.end() ? nullptr : it->second;
}

void AudioEngine::addClip(std::shared_ptr<Clip> c) {
    std::lock_guard g(lock);
    const std::string name = c->name;
    clips[name] = std::move(c);
}

bool AudioEngine::loadWav(const std::string& name, const std::string& path) {
    SDL_AudioSpec src{};
    Uint8* data = nullptr; Uint32 len = 0;
    if (!SDL_LoadWAV(path.c_str(), &src, &data, &len)) return false;
    SDL_AudioSpec dst{};
    dst.format = SDL_AUDIO_F32; dst.channels = 1; dst.freq = outRate;
    Uint8* out = nullptr; int outLen = 0;
    const bool ok = SDL_ConvertAudioSamples(&src, data, int(len), &dst, &out, &outLen);
    SDL_free(data);
    if (!ok) return false;
    auto c = std::make_shared<Clip>();
    c->name = name; c->sampleRate = outRate;
    c->samples.assign(reinterpret_cast<float*>(out), reinterpret_cast<float*>(out) + outLen / int(sizeof(float)));
    SDL_free(out);
    addClip(std::move(c));
    return true;
}

bool AudioEngine::saveWav(const std::string& name, const std::string& path) const {
    ClipPtr c = clip(name);
    if (!c) return false;
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    const std::uint32_t n = std::uint32_t(c->samples.size()), rate = std::uint32_t(c->sampleRate);
    auto w32 = [&](std::uint32_t x) { f.write(reinterpret_cast<const char*>(&x), 4); };
    auto w16 = [&](std::uint16_t x) { f.write(reinterpret_cast<const char*>(&x), 2); };
    f.write("RIFF", 4); w32(36 + n * 2); f.write("WAVEfmt ", 8);
    w32(16); w16(1); w16(1); w32(rate); w32(rate * 2); w16(2); w16(16);
    f.write("data", 4); w32(n * 2);
    for (float s : c->samples) w16(std::uint16_t(std::int16_t(std::clamp(s, -1.0f, 1.0f) * 32767.0f)));
    return bool(f);
}

int AudioEngine::exportAll(const std::string& folder) const {
    std::filesystem::create_directories(folder);
    int n = 0;
    for (const auto& name : clipNames()) n += saveWav(name, folder + "/" + name + ".wav") ? 1 : 0;
    return n;
}

std::vector<std::string> AudioEngine::clipNames() const {
    std::lock_guard g(lock);
    std::vector<std::string> n;
    for (auto& [k, _] : clips) n.push_back(k);
    std::sort(n.begin(), n.end());
    return n;
}

// ---------------------------------------------------------------- playing

AudioEngine::Voice* AudioEngine::findVoice(VoiceId id) {
    if (!id) return nullptr;
    for (auto& v : voices) if (v.active && v.id == id) return &v;
    return nullptr;
}
const AudioEngine::Voice* AudioEngine::findVoice(VoiceId id) const {
    if (!id) return nullptr;
    for (auto& v : voices) if (v.active && v.id == id) return &v;
    return nullptr;
}

VoiceId AudioEngine::play(const ClipPtr& c, const PlayParams& p) {
    if (!c || c->samples.empty()) return 0;
    std::lock_guard g(lock);
    Voice* slot = nullptr;
    for (auto& v : voices) if (!v.active) { slot = &v; break; }
    if (!slot) {
        // All busy: steal the oldest one-shot (looping beds are never stolen).
        for (auto& v : voices)
            if (!v.loop && (!slot || v.born < slot->born)) slot = &v;
        if (!slot) return 0;
    }
    Voice v;
    v.active = true; v.id = nextId++; v.clip = c; v.pos = 0.0;
    v.pitch = std::max(0.05f, p.pitch); v.volume = p.volume;
    v.loop = p.loop; v.spatial = p.spatial; v.position = p.position;
    v.minD = std::max(0.1f, p.minDistance); v.maxD = std::max(v.minD + 0.1f, p.maxDistance);
    v.bus = p.bus;
    v.fade = p.fadeIn > 0.0f ? 0.0f : 1.0f; v.fadeTarget = 1.0f;
    v.fadeRate = p.fadeIn > 0.0f ? 1.0f / (p.fadeIn * float(outRate)) : 0.0f;
    v.born = ++counter;
    *slot = std::move(v);
    return slot->id;
}

VoiceId AudioEngine::play(const std::string& clipName, const PlayParams& p) { return play(clip(clipName), p); }

VoiceId AudioEngine::playVariant(const std::string& baseName, const PlayParams& p) {
    std::vector<ClipPtr> found;
    for (int i = 0; i < 16; ++i) {
        ClipPtr c = clip(baseName + "_" + std::to_string(i));
        if (!c) break;
        found.push_back(c);
    }
    if (found.empty()) return play(baseName, p);      // no numbered variants: the plain clip
    static std::uint32_t rng = 0x9E3779B9u;
    rng = rng * 1664525u + 1013904223u;
    return play(found[(rng >> 8) % found.size()], p);
}

VoiceId AudioEngine::playAt(const std::string& clipName, const glm::vec3& pos, float volume, Bus bus) {
    PlayParams p;
    p.spatial = true; p.position = pos; p.volume = volume; p.bus = bus;
    return play(clipName, p);
}

void AudioEngine::stop(VoiceId id, float fadeOut) {
    std::lock_guard g(lock);
    if (Voice* v = findVoice(id)) {
        v->stopping = true; v->fadeTarget = 0.0f;
        v->fadeRate = 1.0f / (std::max(fadeOut, 0.002f) * float(outRate));
    }
}

void AudioEngine::stopAll(float fadeOut) {
    std::lock_guard g(lock);
    for (auto& v : voices)
        if (v.active) { v.stopping = true; v.fadeTarget = 0.0f; v.fadeRate = 1.0f / (std::max(fadeOut, 0.002f) * float(outRate)); }
}

bool AudioEngine::isPlaying(VoiceId id) const {
    std::lock_guard g(lock);
    const Voice* v = findVoice(id);
    return v && !v->stopping;
}

void AudioEngine::setVoice(VoiceId id, float volume, float pitch) {
    std::lock_guard g(lock);
    if (Voice* v = findVoice(id)) { v->volume = volume; if (pitch > 0.0f) v->pitch = pitch; }
}

void AudioEngine::setVoicePosition(VoiceId id, const glm::vec3& pos) {
    std::lock_guard g(lock);
    if (Voice* v = findVoice(id)) v->position = pos;
}

void AudioEngine::setListener(const glm::vec3& pos, const glm::vec3& forward, const glm::vec3& up) {
    std::lock_guard g(lock);
    listenerPos = pos;
    glm::vec3 r = glm::cross(forward, up);
    listenerRight = glm::length(r) > 1e-4f ? glm::normalize(r) : glm::vec3(1, 0, 0);
}

void AudioEngine::setUnderwater(bool u) { std::lock_guard g(lock); underwater = u; }
void AudioEngine::setBusVolume(Bus b, float v) { busVol[size_t(b)] = std::clamp(v, 0.0f, 2.0f); }

int AudioEngine::activeVoices() const {
    std::lock_guard g(lock);
    int n = 0;
    for (auto& v : voices) n += v.active;
    return n;
}

// ---------------------------------------------------------------- mixing

void AudioEngine::render(float* out, int frames) {
    std::fill(out, out + size_t(frames) * 2, 0.0f);
    std::lock_guard g(lock);
    const float invFrames = 1.0f / float(std::max(frames, 1));

    for (auto& v : voices) {
        if (!v.active) continue;
        const Clip& c = *v.clip;
        const size_t n = c.samples.size();

        // Target gains for this block.
        float panL = 0.70711f, panR = 0.70711f, atten = 1.0f, lpc = 1.0f;
        if (v.spatial) {
            const glm::vec3 d = v.position - listenerPos;
            const float dist = glm::length(d);
            atten = dist <= v.minD ? 1.0f : v.minD / dist;
            atten *= 1.0f - smoothstep(0.6f * v.maxD, v.maxD, dist);
            float pan = dist > 1e-3f ? glm::dot(d / dist, listenerRight) : 0.0f;
            pan *= smoothstep(0.0f, std::max(v.minD * 0.6f, 0.5f), dist);      // right next to you = centred
            const float ang = (pan + 1.0f) * kPi * 0.25f;
            panL = std::cos(ang); panR = std::sin(ang);
            // Far things lose their highs, like air absorbing treble: ~13 kHz at 4 m, ~4 kHz at 40 m.
            if (dist > v.minD) {
                const float fc = std::max(1200.0f, 16000.0f / (1.0f + (dist - v.minD) / 12.0f));
                lpc = 1.0f - std::exp(-2.0f * kPi * fc / float(outRate));
            }
        }
        const float gain = v.volume * busVol[size_t(v.bus)] * atten;
        const float tL = gain * panL, tR = gain * panR;
        if (v.fresh) { v.gL = tL; v.gR = tR; v.fresh = false; }   // no ramp-up click on a new voice

        const double step = double(v.pitch) * double(c.sampleRate) / double(outRate);
        for (int i = 0; i < frames; ++i) {
            if (!v.active) break;
            size_t idx = size_t(v.pos);
            if (idx >= n) {
                if (v.loop) { v.pos = std::fmod(v.pos, double(n)); idx = size_t(v.pos); }
                else { v.active = false; break; }
            }
            const float frac = float(v.pos - double(idx));
            const float s0 = c.samples[idx];
            const float s1 = c.samples[idx + 1 < n ? idx + 1 : (v.loop ? 0 : idx)];
            float s = s0 + (s1 - s0) * frac;

            if (v.fadeRate > 0.0f) {
                if (v.fade < v.fadeTarget) v.fade = std::min(v.fade + v.fadeRate, v.fadeTarget);
                else if (v.fade > v.fadeTarget) v.fade = std::max(v.fade - v.fadeRate, v.fadeTarget);
            }
            if (lpc < 0.999f) { v.lp += (s - v.lp) * lpc; s = v.lp; }

            const float t = float(i) * invFrames;
            const float gl = v.gL + (tL - v.gL) * t, gr = v.gR + (tR - v.gR) * t;
            out[i * 2]     += s * gl * v.fade;
            out[i * 2 + 1] += s * gr * v.fade;
            v.pos += step;
        }
        v.gL = tL; v.gR = tR;
        if (v.stopping && v.fade <= 0.0001f) v.active = false;
        if (!v.loop && v.active && size_t(v.pos) >= n) v.active = false;
    }

    // Master: under water everything goes muffled; then volume and a soft limiter.
    const float uwTarget = underwater ? 1.0f : 0.0f;
    const float mg = muted ? 0.0f : master;
    for (int i = 0; i < frames; ++i) {
        uwBlend += (uwTarget - uwBlend) * 0.0004f;
        float l = out[i * 2], r = out[i * 2 + 1];
        lpL += (l - lpL) * 0.065f; lpR += (r - lpR) * 0.065f;
        l = glm::mix(l, lpL * 0.8f, uwBlend); r = glm::mix(r, lpR * 0.8f, uwBlend);
        out[i * 2]     = std::tanh(l * mg);
        out[i * 2 + 1] = std::tanh(r * mg);
    }
}

} // namespace px
