#include "Ambience.h"
#include <algorithm>
#include <cmath>

namespace px {

namespace {
float smoothstep(float a, float b, float x) { const float t = std::clamp((x - a) / (b - a), 0.0f, 1.0f); return t * t * (3.0f - 2.0f * t); }
}

float Ambience::rand01() {
    rng = rng * 1664525u + 1013904223u;
    return float(rng >> 8) * (1.0f / 16777216.0f);
}

void Ambience::ensureBeds() {
    if (!beds.empty()) return;
    for (const char* n : { "wind", "wind_strong", "cave", "water_lap", "crickets", "day_air" }) {
        Bed b; b.clip = n;
        beds.push_back(b);
    }
}

float Ambience::level(const std::string& bed) const {
    for (auto& b : beds) if (b.clip == bed) return b.level;
    return 0.0f;
}

// Moves a bed's level toward its target and keeps its looping voice in step: the voice
// only exists while the bed is audible, so silent beds cost nothing.
void Ambience::driveBed(AudioEngine& audio, Bed& b, float dt, float tau) {
    b.level += (b.target - b.level) * (1.0f - std::exp(-dt / tau));
    if (b.level < 0.002f && b.target < 0.002f) {
        b.level = 0.0f;
        if (b.voice) { audio.stop(b.voice, 0.3f); b.voice = 0; }
        return;
    }
    if (b.voice && !audio.isPlaying(b.voice)) b.voice = 0;
    if (!b.voice) {
        PlayParams p; p.bus = Bus::Ambient; p.loop = true; p.volume = b.level * b.gain * volume; p.fadeIn = 0.5f;
        b.voice = audio.play(b.clip, p);
    } else {
        audio.setVoice(b.voice, b.level * b.gain * volume);
    }
}

void Ambience::update(AudioEngine& audio, const AmbienceInputs& in, float dt) {
    ensureBeds();
    dt = std::clamp(dt, 0.0f, 0.25f);

    const bool on = enabled && volume > 0.001f;
    const float open = 1.0f - in.enclosure;
    const float day = in.daylight, night = 1.0f - in.daylight;
    const float uw = in.underwater ? 1.0f : 0.0f;

    // Targets per bed.
    auto set = [&](const char* name, float t) {
        for (auto& b : beds) if (b.clip == name) b.target = on ? std::clamp(t, 0.0f, 1.0f) : 0.0f;
    };
    set("wind",        (0.18f + 0.82f * in.wind) * (1.0f - 0.9f * in.enclosure) * (1.0f - uw) * 0.7f);
    set("wind_strong", smoothstep(0.55f, 1.0f, in.wind) * open * (1.0f - uw) * 0.9f);
    set("cave",        std::max(in.enclosure * 0.85f, uw * 0.75f));
    set("water_lap",   std::max(in.water * open * 0.75f * (1.0f - uw), uw * 0.35f));
    set("crickets",    night * (0.25f + 0.75f * in.greenery) * open * (1.0f - 0.6f * in.water) * (1.0f - uw) * 0.55f);
    set("day_air",     day * (0.35f + 0.65f * in.greenery) * open * (1.0f - uw) * 0.6f);
    for (auto& b : beds) driveBed(audio, b, dt, 1.4f);

    // ---- one-shots: birds by day among greenery, drips in caves
    const bool birdWeather = on && !in.underwater && day > 0.35f && open > 0.6f && in.greenery > 0.15f;
    birdTimer -= dt;
    if (birdTimer <= 0.0f) {
        const float busy = std::clamp(day * in.greenery, 0.0f, 1.0f);
        birdTimer = 3.0f + (1.0f - busy) * 11.0f + rand01() * 6.0f;
        if (birdWeather) {
            const float ang = rand01() * 6.2831853f, dist = 12.0f + rand01() * 28.0f;
            PlayParams p; p.bus = Bus::Ambient; p.spatial = true; p.minDistance = 6.0f; p.maxDistance = 70.0f;
            p.position = in.listener + glm::vec3(std::cos(ang) * dist, 3.0f + rand01() * 10.0f, std::sin(ang) * dist);
            p.volume = 0.5f + rand01() * 0.5f; p.pitch = 0.85f + rand01() * 0.35f;
            audio.playVariant("bird", p);
        }
    }
    dripTimer -= dt;
    if (dripTimer <= 0.0f) {
        dripTimer = 1.2f + rand01() * 4.5f;
        if (on && in.enclosure > 0.45f && !in.underwater) {
            const float ang = rand01() * 6.2831853f, dist = 2.0f + rand01() * 11.0f;
            PlayParams p; p.bus = Bus::Ambient; p.spatial = true; p.minDistance = 3.0f; p.maxDistance = 40.0f;
            p.position = in.listener + glm::vec3(std::cos(ang) * dist, 1.0f + rand01() * 3.0f, std::sin(ang) * dist);
            p.volume = (0.4f + rand01() * 0.5f) * in.enclosure; p.pitch = 0.9f + rand01() * 0.25f;
            audio.playVariant("drip", p);
        }
    }

    // ---- game-defined zones
    for (size_t i = 0; i < zones.size(); ++i) {
        const AmbientZone& z = zones[i];
        const std::string key = z.name + "#" + std::to_string(i);
        ZoneVoice* zv = nullptr;
        for (auto& v : zoneVoices) if (v.key == key) { zv = &v; break; }
        if (!zv) { zoneVoices.push_back({ key, 0, 0.0f }); zv = &zoneVoices.back(); }

        const float d = glm::length(in.listener - z.center);
        float target = 0.0f;
        if (on) target = z.positional ? (d < z.radius * 1.4f ? 1.0f : 0.0f)
                                      : 1.0f - smoothstep(z.radius * 0.5f, z.radius, d);
        zv->level += (target - zv->level) * (1.0f - std::exp(-dt / 0.6f));
        if (zv->level < 0.003f && target == 0.0f) {
            zv->level = 0.0f;
            if (zv->voice) { audio.stop(zv->voice, 0.3f); zv->voice = 0; }
            continue;
        }
        if (zv->voice && !audio.isPlaying(zv->voice)) zv->voice = 0;
        if (!zv->voice) {
            PlayParams p; p.bus = Bus::Ambient; p.loop = true; p.pitch = z.pitch; p.volume = zv->level * z.volume * volume; p.fadeIn = 0.4f;
            if (z.positional) { p.spatial = true; p.position = z.center; p.minDistance = std::max(1.0f, z.radius * 0.3f); p.maxDistance = z.radius * 1.4f; }
            zv->voice = audio.play(z.clip, p);
        } else {
            audio.setVoice(zv->voice, zv->level * z.volume * volume);
        }
    }
    // Zones that were removed: let their voices go.
    for (auto& v : zoneVoices) {
        bool alive = false;
        for (size_t i = 0; i < zones.size(); ++i) if (v.key == zones[i].name + "#" + std::to_string(i)) { alive = true; break; }
        if (!alive && v.voice) { audio.stop(v.voice, 0.3f); v.voice = 0; v.level = 0.0f; }
    }
}

void Ambience::stopAll(AudioEngine& audio) {
    for (auto& b : beds) { if (b.voice) audio.stop(b.voice, 0.2f); b.voice = 0; b.level = b.target = 0.0f; }
    for (auto& v : zoneVoices) { if (v.voice) audio.stop(v.voice, 0.2f); v.voice = 0; v.level = 0.0f; }
}

} // namespace px
