#pragma once
// Ambient sound beds that follow the world: wind that rises with altitude, water that
// laps near the shore, a cave drone when you are enclosed, crickets at night, birdsong
// in daylight, drips underground. The engine measures the surroundings (AmbienceInputs)
// and Ambience crossfades the beds smoothly. Games can add their own AmbientZones:
// spheres in the world that fade a clip in as you walk into them.
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "AudioEngine.h"

namespace px {

struct AmbientZone {
    std::string name;
    glm::vec3   center{ 0.0f };
    float       radius = 20.0f;
    std::string clip   = "wind";       // any clip in the AudioEngine (looped)
    float       volume = 0.6f;
    float       pitch  = 1.0f;
    // false: heard evenly everywhere inside, fading over the outer half of the radius.
    // true : a point source at the centre (a fountain, a campfire): panned and attenuated.
    bool        positional = false;
};

// What the world sounds like right here. All 0..1 unless noted.
struct AmbienceInputs {
    glm::vec3 listener{ 0.0f };
    float daylight   = 1.0f;     // 0 = night, 1 = day
    float wind       = 0.2f;     // exposure to wind (altitude, open ground)
    float water      = 0.0f;     // closeness to open water
    float enclosure  = 0.0f;     // 1 = deep inside a cave or tunnel
    float greenery   = 0.5f;     // how alive the ground is (birds, crickets, leaves)
    bool  underwater = false;
};

class Ambience {
public:
    bool  enabled = true;
    float volume  = 1.0f;
    std::vector<AmbientZone> zones;

    void update(AudioEngine& audio, const AmbienceInputs& in, float dt);
    void stopAll(AudioEngine& audio);

    // Current (smoothed) loudness of a bed: "wind", "wind_strong", "cave", "water_lap",
    // "crickets", "day_air". 0 for an unknown name. Used by the tests and the debug UI.
    float level(const std::string& bed) const;

private:
    struct Bed {
        std::string clip;
        VoiceId     voice = 0;
        float       level = 0.0f;
        float       target = 0.0f;
        float       gain = 1.0f;        // overall trim for this bed
    };
    struct ZoneVoice { std::string key; VoiceId voice = 0; float level = 0.0f; };

    void ensureBeds();
    void driveBed(AudioEngine& audio, Bed& b, float dt, float tau);
    float rand01();

    std::vector<Bed> beds;
    std::vector<ZoneVoice> zoneVoices;
    float birdTimer = 3.0f, dripTimer = 2.0f;
    std::uint32_t rng = 0xC0FFEEu;
};

} // namespace px
