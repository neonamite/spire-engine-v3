#pragma once
// Walking character that collides directly with the voxel density field.
// The density field is (approximately) a signed distance field, so collision is
// just "if a body sphere is closer to the surface than its radius, push it out
// along the gradient". No physics library needed for terrain walking; Jolt is
// on the roadmap for rigid-body debris and vehicles.
#include <glm/glm.hpp>
#include "physics/Solid.h"

namespace px {

class ChunkManager;

class CharacterController {
public:
    glm::vec3 position{ 0.0f, 80.0f, 0.0f };   // feet
    glm::vec3 velocity{ 0.0f };
    bool grounded = false;
    bool swimming = false;            // body is in water deep enough to float in
    bool wasSwimming = false;         // last frame (for splash sounds)
    float waterLevel = -1e9f;         // world Y of the water surface (set by the application)
    bool dive = false;                // while swimming: sink instead of float

    float radius     = 0.4f;
    float height     = 1.8f;
    float eyeHeight  = 1.62f;
    float walkSpeed  = 6.0f;
    float sprintMul  = 1.7f;
    float jumpSpeed  = 7.5f;
    float gravity    = 22.0f;
    float swimSpeed  = 3.6f;

    // Extra solid things to stand on and bump into besides the terrain (the scene's objects). Not owned.
    const SolidProvider* extraSolids = nullptr;

    // wishDir is horizontal, unit length or zero.
    void update(const ChunkManager& world, const glm::vec3& wishDir, bool sprint, bool jump, float dt);
    void addImpulse(const glm::vec3& impulse) { velocity += impulse; grounded = false; }
    glm::vec3 eye() const { return position + glm::vec3(0, eyeHeight, 0); }

private:
    void resolve(const ChunkManager& world);
};

} // namespace px
