#include "CharacterController.h"
#include "world/ChunkManager.h"
#include <algorithm>
#include <cmath>

namespace px {

void CharacterController::update(const ChunkManager& world, const glm::vec3& wishDir, bool sprint, bool jump, float dt) {
    // Freeze until the ground under us has streamed in, so we never fall through the world.
    if (!world.isLoaded(position) || !world.isLoaded(position - glm::vec3(0, 4, 0))) return;

    dt = std::min(dt, 1.0f / 30.0f);

    // In water deeper than the waist you float: buoyancy holds the shoulders near the
    // surface, movement is slower and heavily damped, jump swims up, dive sinks.
    wasSwimming = swimming;
    swimming = position.y + height * 0.55f < waterLevel;
    if (swimming) {
        const float floatY = waterLevel - height * 0.82f;            // feet height when floating
        const float lift = std::clamp((floatY - position.y) * 9.0f, -10.0f, 14.0f);
        velocity.y += (dive ? -9.0f : lift) * dt;
        if (jump) velocity.y += 9.0f * dt;
        velocity.y *= std::exp(-2.6f * dt);
        const glm::vec3 target = wishDir * swimSpeed * (sprint ? 1.5f : 1.0f);
        const float k = 1.0f - std::exp(-4.0f * dt);
        velocity.x += (target.x - velocity.x) * k;
        velocity.z += (target.z - velocity.z) * k;
        grounded = false;
        const int steps = std::clamp(int(glm::length(velocity) * dt / (radius * 0.5f)) + 1, 1, 8);
        for (int i = 0; i < steps; ++i) { position += velocity * (dt / steps); resolve(world); }
        return;
    }

    const float speed = walkSpeed * (sprint ? sprintMul : 1.0f) * (position.y < waterLevel ? 0.7f : 1.0f);   // wading
    const glm::vec3 target = wishDir * speed;

    // Snappy on the ground, floaty in the air.
    const float accel = grounded ? 14.0f : 3.0f;
    const float k = 1.0f - std::exp(-accel * dt);
    velocity.x += (target.x - velocity.x) * k;
    velocity.z += (target.z - velocity.z) * k;

    if (grounded && jump) { velocity.y = jumpSpeed; grounded = false; }
    velocity.y -= gravity * dt;
    velocity.y = std::max(velocity.y, -60.0f);

    // Sub-step so fast dashes don't tunnel through thin walls.
    const int steps = std::clamp(int(glm::length(velocity) * dt / (radius * 0.5f)) + 1, 1, 8);
    grounded = false;
    for (int i = 0; i < steps; ++i) {
        position += velocity * (dt / steps);
        resolve(world);
    }
}

void CharacterController::resolve(const ChunkManager& world) {
    // Body = three spheres stacked along the capsule.
    const float offsets[3] = { radius, height * 0.5f, height - radius };
    for (int iter = 0; iter < 4; ++iter) {
        bool moved = false;
        for (float off : offsets) {
            const glm::vec3 c = position + glm::vec3(0, off, 0);
            float d = world.density(c);
            glm::vec3 n(0, 1, 0);
            bool onObject = false;
            if (extraSolids) {
                const float de = extraSolids->density(c);
                if (de < d) { d = de; onObject = true; }
            }
            if (d >= radius) continue;
            n = onObject ? extraSolids->gradient(c) : world.densityGradient(c);
            moved = true;
            if (off == offsets[0] && n.y > 0.6f) {
                // Walkable ground: lift straight up so standing on a slope doesn't
                // slowly slide you downhill.
                position.y += (radius - d) / n.y;
                if (velocity.y < 0.0f) velocity.y = 0.0f;
                grounded = true;
            } else {
                position += n * (radius - d);
                const float into = glm::dot(velocity, n);
                if (into < 0.0f) velocity -= n * into;      // slide along walls / ceilings
            }
        }
        if (!moved) break;
    }
}

} // namespace px
