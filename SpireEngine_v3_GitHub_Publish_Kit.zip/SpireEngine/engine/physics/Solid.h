#pragma once
// Anything that is solid but isn't terrain (placed objects, a game's own props) can join the
// collision the character controller already does by answering two questions.
#include <glm/glm.hpp>

namespace px {

struct SolidProvider {
    virtual ~SolidProvider() = default;
    // Distance-like value: negative inside, 0 on the surface, positive in air. Large when nothing is near.
    virtual float density(const glm::vec3& p) const = 0;
    virtual glm::vec3 gradient(const glm::vec3& p) const = 0;      // unit vector pointing toward air
};

} // namespace px
