// --demo share_...: the Share window (v0.23), and a self test that builds a game, shares it into a folder and checks
// what is in it, printing "[sharetest] ok / FAIL" lines. (Running the shared folder is checked from outside: see the
// test script, which starts it and takes a screenshot.)
#include "core/Application.h"
#include "core/DemoSpot.h"
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>

namespace px {

namespace fs = std::filesystem;

void Application::setupShareDemo() {
    if (demo == "share_selftest") { runShareSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    const glm::vec3 c = demospot::calmSpot(world);
    camera.position = c + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    buildGameTemplate(GameTemplate::CoinHunt);
    toasts.clear();
    share.open = true;
    share.filled = true;
    share.name = "Coin Hunt Island";
    share.author = "Neonamite";
    share.description = "Find every coin and gem before the clock runs out.";
    share.folder = "shared/" + shareFolderName(share.name);
}

void Application::runShareSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[sharetest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    std::error_code ec;
    // keep the real world file as it was (sharing saves the world first)
    const std::string worldFile = worldSavePath(), keep = worldFile + ".sharetest";
    const bool hadWorld = fs::exists(worldFile, ec);
    if (hadWorld) fs::copy_file(worldFile, keep, fs::copy_options::overwrite_existing, ec);

    const glm::vec3 c = demospot::calmSpot(world);
    camera.position = c + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    buildGameTemplate(GameTemplate::CoinHunt);
    const size_t objects = scene.size();
    GameManifest m;
    m.name = "Share Test Game"; m.author = "Tester"; m.description = "A test"; m.thirdPerson = true;
    const SharePlan plan = makeSharePlan(m);
    check(!plan.programName.empty() && plan.manifest.world == worldSavePath() && plan.manifest.engineVersion == kEngineVersion, "the plan has the program and the world");
    const std::string out = "/tmp/claude-0/sharetest/" + shareFolderName(m.name);
    const char* env = std::getenv("PX_SHARE_DIR");
    const std::string folder = env ? std::string(env) : out;
    const ShareResult r = shareGame(m, folder);
    check(r.ok, "Share Game makes the folder" + (r.ok ? std::string() : ": " + r.error));
    const fs::path p(folder);
    check(fs::exists(p / plan.programName) && fs::exists(p / "engine/assets/fonts/Geist-Medium.ttf"), "...with the program and its fonts");
    check(fs::exists(p / worldSavePath()) && fs::exists(p / kManifestFile) && fs::exists(p / "play.sh") && fs::exists(p / "Play.bat") && fs::exists(p / "README.txt"),
          "...the world, game.pxgame, the launchers and a read-me");
    GameManifest back;
    std::string err;
    check(loadManifest((p / kManifestFile).string(), back, &err) && back.name == m.name && back.thirdPerson && back.game == "sandbox", "game.pxgame says what to open");
    // the shared world is the game: same objects, same rules
    check(fs::file_size(p / worldSavePath(), ec) > 100, "the world file is there and not empty");
    check(objects > 10 && !scene.gameRules().empty(), "the game shared has its objects and rules");

    // put the real world back
    if (hadWorld) { fs::copy_file(keep, worldFile, fs::copy_options::overwrite_existing, ec); fs::remove(keep, ec); }
    std::cerr << "[sharetest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
