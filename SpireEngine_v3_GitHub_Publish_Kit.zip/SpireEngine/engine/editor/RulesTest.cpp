// --demo rule_...: screenshots of rules and gadgets (v0.21), and a self test that drives the real code (placing gadgets,
// writing a rule, playing: plates, gates, doors, coins, the finish) and prints "[ruletest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "rules/Gadgets.h"
#include <cmath>
#include <iostream>
#include <string>

namespace px {

namespace {
template <class Cam>
void lookFromTo(Cam& cam, const glm::vec3& from, const glm::vec3& at) {
    const glm::vec3 d = at - from;
    cam.position = from;
    cam.yaw = glm::degrees(std::atan2(d.z, d.x));
    cam.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
}
glm::vec3 ground(const ChunkManager& world, float x, float z) { return glm::vec3(x, demospot::groundHeight(world, x, z), z); }
} // namespace

// A little course: a sign, coins along a path, a pressure plate that lifts a gate in a wall, a door, a gem, the finish.
ObjectId Application::buildRuleCourse(const glm::vec3& c, std::vector<ObjectId>* all) {
    world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 10.0f), 20.0f);
    world.paint(glm::vec3(c.x, c.y, c.z - 10.0f), 12.0f, MAT_DIRT);
    auto put = [&](const char* asset, float x, float z, float yaw = 0.0f, float size = 1.0f) {
        const ObjectId id = placeObject(asset, ground(world, c.x + x, c.z + z), yaw, size);
        if (all) all->push_back(id);
        return id;
    };
    const ObjectId sign = put("gadget sign", -2.2f, -3.0f, 20.0f);
    {
        RuleSet r = *rulesOf(sign);
        r.rules[0].actions[0].text = "Collect the coins, step on the plate to open the gate, and reach the flag!";
        setRules(sign, r, "Sign");
    }
    for (int i = 0; i < 5; ++i) put("gadget coin", -0.5f + float(i % 2) * 1.0f, -4.5f - float(i) * 1.4f);
    // a wall with a gate in it
    for (float x : { -6.0f, -4.1f, -2.2f, 2.2f, 4.1f, 6.0f }) put("crate", x, -13.0f, 0.0f, 0.62f);
    const ObjectId gate = put("gadget gate", 0.0f, -13.0f);
    put("gadget pressure plate", 2.6f, -10.0f);
    const ObjectId door = put("gadget door", -3.0f, -9.0f, 90.0f);
    put("gadget gem", 0.0f, -16.0f);
    put("gadget finish flag", 0.0f, -19.0f);
    (void)gate;
    return door;
}

void Application::setupRuleDemo() {
    if (demo == "rule_selftest") { runRuleSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    showHints = false;
    const glm::vec3 c = demospot::calmSpot(world);
    toasts.clear();
    if (demo == "rule_gadgets") {
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 5.0f), 12.0f);
        world.paint(glm::vec3(c.x, c.y, c.z - 5.0f), 7.0f, MAT_DIRT);
        const auto& list = gadgetPresets();
        float x = -1.25f * float(list.size() - 1) * 0.5f;
        for (const GadgetPreset& g : list) { placeObject(g.asset, ground(world, c.x + x, c.z - 5.0f), 0.0f); x += 1.25f; }
        selection.clear();
        lookFromTo(camera, glm::vec3(c.x, c.y + 2.3f, c.z + 1.5f), glm::vec3(c.x, c.y + 0.8f, c.z - 5.0f));
        previewMotion = true;
        for (int i = 0; i < 10; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    std::vector<ObjectId> all;
    const ObjectId door = buildRuleCourse(c, &all);
    if (demo == "rule_editor") {
        tool = Tool::Select;
        ObjectId plate = 0;
        for (ObjectId id : all) if (scene.find(id) && scene.find(id)->asset == "gadget pressure plate") plate = id;
        selectObject(plate);
        settleFronts = { "Details" }; settleFrames = 5;
        lookFromTo(camera, glm::vec3(c.x + 7.0f, c.y + 7.5f, c.z - 1.0f), glm::vec3(c.x + 0.5f, c.y, c.z - 11.0f));
        for (int i = 0; i < 6; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = false;
        return;
    }
    // play: walk the course a little way
    lookFromTo(camera, ground(world, c.x, c.z) + glm::vec3(0, 1.7f, 0), glm::vec3(c.x, c.y + 1.0f, c.z - 10.0f));
    setMode(Mode::Play);
    auto walkTo = [&](float x, float z, int frames) {
        for (int i = 0; i < frames; ++i) { player.position = ground(world, c.x + x, c.z + z); player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); }
    };
    if (demo == "rule_play") {
        walkTo(0.0f, -1.0f, 5);
        walkTo(-0.5f, -4.5f, 5); walkTo(0.5f, -5.9f, 5);                      // two coins
        walkTo(2.6f, -10.0f, 10);                                              // the plate: the gate lifts
        walkTo(-0.8f, -7.4f, 50);
        const Evaluated* e = scene.evaluatedFor(door);
        const glm::vec3 dc = e ? glm::vec3(e->world * glm::vec4(0.0f, 1.2f, 0.0f, 1.0f)) : glm::vec3(c.x - 3.0f, c.y + 1.2f, c.z - 9.0f);
        lookFromTo(camera, player.eye(), dc);
        for (int i = 0; i < 3; ++i) update(1.0f / 30.0f);
        ruleBanners.push_back({ "Collect the coins, step on the plate to open the gate, and reach the flag!", 30.0f, 30.0f });
    } else if (demo == "rule_win") {
        walkTo(-0.5f, -4.5f, 5); walkTo(0.5f, -5.9f, 5); walkTo(-0.5f, -7.3f, 5);
        walkTo(2.6f, -10.0f, 10);
        walkTo(0.0f, -16.0f, 60);
        walkTo(0.0f, -19.0f, 5);
    }
    npcsFrozen = true;
    toasts.clear();
}

void Application::runRuleSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[ruletest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto key = [&](SDL_Keycode k) { SDL_Event e{}; e.type = SDL_EVENT_KEY_DOWN; e.key.key = k; e.key.down = true; handleEvent(e); };
    setMode(Mode::Editor);
    tool = Tool::Select;
    uiHidden = false;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    const glm::vec3 c = demospot::calmSpot(world);
    world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 10.0f), 20.0f);

    // ---- placing a gadget with a click
    const glm::vec3 doorAt = ground(world, c.x, c.z - 8.0f);
    startPlacing("gadget door");
    camera.position = doorAt + glm::vec3(0.0f, 14.0f, 0.0f); camera.yaw = -90.0f; camera.pitch = -89.0f;
    updateObjects(0.0f);
    glm::vec2 sp;
    gizmoView().project(doorAt, sp);
    mouseX = sp.x; mouseY = sp.y;
    updateObjects(1.0f / 60.0f);
    selectToolMouseDown(false);
    stopPlacing();
    ObjectId door = 0;
    for (const SceneObject& o : scene.objects()) if (o.asset == "gadget door") door = o.id;
    check(door && scene.find(door)->name == "Door" && rulesOf(door) && rulesOf(door)->usable(), "a door placed from Gadgets comes with its rule (E opens it)");

    // ---- writing a rule, one undo step
    {
        RuleSet r = *rulesOf(door);
        Rule hello; hello.when = RuleWhen::Near; hello.number = 2.5f;
        hello.actions.push_back(RuleAction{ RuleDo::Message, kRuleSelf, "A door!", 0.0f, 0.0f });
        r.rules.push_back(hello);
        setRules(door, r, "Add a rule");
        check(rulesOf(door)->rules.size() == 2, "a rule added in Properties");
        cmdUndo();
        check(rulesOf(door)->rules.size() == 1, "Ctrl+Z takes it away");
        cmdRedo();
        check(rulesOf(door)->rules.size() == 2, "...Ctrl+Y brings it back");
        Scene again;
        check(again.fromText(scene.toText()) && again.find(door) && again.find(door)->rules == scene.find(door)->rules, "rules are saved with the world");
    }
    // a plate that opens a gate, a coin, the finish
    const ObjectId plate = placeObject("gadget pressure plate", ground(world, c.x + 4.0f, c.z - 4.0f));
    const ObjectId gate = placeObject("gadget gate", ground(world, c.x + 4.0f, c.z - 12.0f));
    const ObjectId coin = placeObject("gadget coin", ground(world, c.x - 4.0f, c.z - 4.0f));
    const ObjectId flag = placeObject("gadget finish flag", ground(world, c.x - 6.0f, c.z - 14.0f));
    check(plate && gate && coin && flag && scene.find(coin)->motion.kind == MotionSettings::Kind::Spin, "a coin spins");
    const glm::vec3 gateRest = glm::vec3(scene.restWorld(gate)[3]);

    // ---- playing
    camera.position = ground(world, c.x, c.z) + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    setMode(Mode::Play);
    auto standAt = [&](const glm::vec3& p, int frames) {
        for (int i = 0; i < frames; ++i) { player.position = p; player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); }
    };
    standAt(ground(world, c.x + 4.0f, c.z - 4.0f) + glm::vec3(0, 0.12f, 0), 5);
    check(ruleEngine.isOpen(gate), "step on the plate: the gate hears it");
    standAt(ground(world, c.x + 1.0f, c.z - 2.0f), 75);
    {
        const Evaluated* e = scene.evaluatedFor(gate);
        check(e && e->world[3].y > gateRest.y + 1.5f, "...and lifts up out of the way");
    }
    // the door: look at it, press E
    const glm::vec3 eyeSpot = ground(world, c.x, c.z - 6.0f);
    standAt(eyeSpot, 2);
    {
        const glm::vec3 eye = player.eye();
        const glm::vec3 target = doorAt + glm::vec3(0.0f, 1.2f, 0.0f);
        const glm::vec3 d = target - eye;
        camera.yaw = glm::degrees(std::atan2(d.z, d.x)); camera.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
    }
    standAt(eyeSpot, 2);
    check(useTarget == door && useLabel == "Open", "looking at the door: \"E  Open\"");
    bool heardNear = false;
    for (const RuleBanner& b : ruleBanners) heardNear = heardNear || b.text == "A door!";
    check(heardNear, "...and the rule you wrote says \"A door!\" as you come near");
    key(SDLK_E);
    standAt(eyeSpot, 30);
    {
        const Evaluated* e = scene.evaluatedFor(door);
        const glm::vec3 x = glm::normalize(glm::vec3(e->world[0]));
        check(ruleEngine.isOpen(door) && std::fabs(x.x) < 0.2f, "E: the door swings open");
        check(scene.find(door)->rotation == glm::vec3(0.0f), "...without changing the door you placed");
    }
    {
        const Evaluated* e = scene.evaluatedFor(door);     // look at where the door is now
        const glm::vec3 target = glm::vec3(e->world * glm::vec4(0.0f, 1.2f, 0.0f, 1.0f));
        const glm::vec3 d = target - player.eye();
        camera.yaw = glm::degrees(std::atan2(d.z, d.x)); camera.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
        standAt(eyeSpot, 2);
    }
    check(useTarget == door && useLabel == "Close", "...and now, looking at it, E would close it");
    // a coin: walk into it
    standAt(ground(world, c.x - 4.0f, c.z - 4.0f), 3);
    check(ruleEngine.hidden(coin) && ruleEngine.score() == 1 && anyScoreRules, "walk into a coin: it is collected, one point");
    {
        const Evaluated* e = scene.evaluatedFor(coin);
        check(e && !e->visible && !e->solid, "...and it is gone");
    }
    // the finish
    standAt(ground(world, c.x - 6.0f, c.z - 14.0f), 3);
    check(gameOver && gameWon && gameOverText == "You made it!", "reach the flag: you win");
    key(SDLK_R);
    standAt(ground(world, c.x, c.z), 2);
    check(!gameOver && !ruleEngine.hidden(coin) && ruleEngine.score() == 0, "R plays again from the start (the coin is back)");
    // back to the editor: everything where it was
    setMode(Mode::Editor);
    updateObjects(1.0f / 60.0f);
    {
        const Evaluated* g = scene.evaluatedFor(gate);
        const Evaluated* k = scene.evaluatedFor(coin);
        check(g && glm::length(glm::vec3(g->world[3]) - gateRest) < 1e-3f && k && k->visible && !rulesRunning, "back in the editor, the gate is down and the coin is back");
    }
    std::cerr << "[ruletest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
