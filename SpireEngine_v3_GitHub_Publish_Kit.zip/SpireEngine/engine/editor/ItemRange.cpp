#include "editor/ItemRange.h"
#include <algorithm>
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {

float roundedBox(const glm::vec3& q, const glm::vec3& half, float r) {
    const glm::vec3 d = glm::abs(q) - (half - glm::vec3(r));
    return glm::length(glm::max(d, glm::vec3(0.0f))) + std::min(std::max(d.x, std::max(d.y, d.z)), 0.0f) - r;
}
float capsule(const glm::vec3& p, const glm::vec3& a, const glm::vec3& b, float r) {
    const glm::vec3 pa = p - a, ba = b - a;
    const float h = std::clamp(glm::dot(pa, ba) / std::max(1e-9f, glm::dot(ba, ba)), 0.0f, 1.0f);
    return glm::length(pa - ba * h) - r;
}
// A round plate facing -Z: radius r, half thickness t.
float disc(const glm::vec3& q, float r, float t) {
    const float dx = glm::length(glm::vec2(q.x, q.y)) - r, dz = std::fabs(q.z) - t;
    return std::min(std::max(dx, dz), 0.0f) + glm::length(glm::vec2(std::max(dx, 0.0f), std::max(dz, 0.0f)));
}
// An upright drum: radius r, half height h, edges rounded by e.
float drum(const glm::vec3& q, float r, float h, float e) {
    const float dx = glm::length(glm::vec2(q.x, q.z)) - (r - e), dy = std::fabs(q.y) - (h - e);
    return std::min(std::max(dx, dy), 0.0f) + glm::length(glm::vec2(std::max(dx, 0.0f), std::max(dy, 0.0f))) - e;
}

using Sdf = std::function<float(const glm::vec3&)>;

void add(Workshop& w, const Sdf& f, glm::vec3 lo, glm::vec3 hi, MaterialId m, float blend = 0.0f) {
    w.stampSdf(f, lo - glm::vec3(0.05f), hi + glm::vec3(0.05f), StampMode::Add, m, blend);
}

AssetPtr finish(Workshop& w, const std::string& name) {
    w.remesh();
    w.asset.name = name;
    w.asset.userMade = false;
    return std::make_shared<Asset>(w.asset);
}

AssetPtr buildPlate() {
    NewAssetSpec s; s.name = "range plate"; s.voxelSize = 0.03125f; s.sizeMetres = { 1.1f, 1.95f, 0.36f };
    Workshop w; w.create(s);
    add(w, [](const glm::vec3& p) { return roundedBox(p - glm::vec3(0, 0.03f, 0), { 0.30f, 0.03f, 0.17f }, 0.01f); }, { -0.3f, 0, -0.17f }, { 0.3f, 0.07f, 0.17f }, MAT_METAL);
    add(w, [](const glm::vec3& p) { return capsule(p, { 0, 0.04f, 0 }, { 0, 1.15f, 0 }, 0.04f); }, { -0.05f, 0, -0.05f }, { 0.05f, 1.2f, 0.05f }, MAT_METAL);
    const glm::vec3 c(0, 1.45f, 0);
    add(w, [c](const glm::vec3& p) { return disc(p - c, 0.42f, 0.035f); }, c - glm::vec3(0.45f, 0.45f, 0.05f), c + glm::vec3(0.45f, 0.45f, 0.05f), MAT_SNOW);
    add(w, [c](const glm::vec3& p) { return disc(p - c, 0.33f, 0.045f); }, c - glm::vec3(0.36f, 0.36f, 0.06f), c + glm::vec3(0.36f, 0.36f, 0.06f), MAT_BRICK);
    add(w, [c](const glm::vec3& p) { return disc(p - c, 0.24f, 0.050f); }, c - glm::vec3(0.27f, 0.27f, 0.07f), c + glm::vec3(0.27f, 0.27f, 0.07f), MAT_SNOW);
    add(w, [c](const glm::vec3& p) { return disc(p - c, 0.11f, 0.055f); }, c - glm::vec3(0.14f, 0.14f, 0.07f), c + glm::vec3(0.14f, 0.14f, 0.07f), MAT_BRICK);
    return finish(w, "range plate");
}

AssetPtr buildDrum() {
    NewAssetSpec s; s.name = "range drum"; s.voxelSize = 0.03125f; s.sizeMetres = { 0.72f, 1.05f, 0.72f };
    Workshop w; w.create(s);
    const glm::vec3 c(0, 0.47f, 0);
    add(w, [c](const glm::vec3& p) { return drum(p - c, 0.30f, 0.47f, 0.035f); }, c - glm::vec3(0.33f, 0.5f, 0.33f), c + glm::vec3(0.33f, 0.5f, 0.33f), MAT_BRICK);
    for (float y : { 0.12f, 0.47f, 0.82f }) {
        const glm::vec3 b(0, y, 0);
        add(w, [b](const glm::vec3& p) { return drum(p - b, 0.315f, 0.028f, 0.01f); }, b - glm::vec3(0.34f, 0.05f, 0.34f), b + glm::vec3(0.34f, 0.05f, 0.34f), MAT_METAL);
    }
    return finish(w, "range drum");
}

AssetPtr buildDummy() {
    NewAssetSpec s; s.name = "range dummy"; s.tmpl = WorkshopTemplate::Mannequin;
    Workshop w; w.create(s);
    return finish(w, "range dummy");
}

} // namespace

// ------------------------------------------------------------------ targets

glm::mat4 ItemRange::Target::matrix() const {
    const float swing = alive() ? wobble * std::sin(wobbleT * 22.0f) : 0.0f;
    const float tilt = glm::radians(fall * 88.0f + swing);
    glm::mat4 m = glm::translate(glm::mat4(1.0f), base);
    m = glm::rotate(m, tilt, glm::vec3(1, 0, 0));
    m = glm::rotate(m, glm::radians(yaw), glm::vec3(0, 1, 0));
    return m;
}

// ------------------------------------------------------------------ building

ItemRange::ItemRange() {
    items.library = &library;
    items.enabled = false;
    build();
}

void ItemRange::build() {
    buildTargets();
    buildDents();
    built = true;
}

void ItemRange::buildTargets() {
    stand.clear();
    const AssetPtr plate = buildPlate(), drumAsset = buildDrum(), dummy = buildDummy();
    auto put = [&](const char* label, const AssetPtr& a, glm::vec3 base, float yaw, float hp) {
        Target t;
        t.label = label; t.asset = a; t.base = base; t.yaw = yaw; t.maxHealth = t.health = hp;
        t.centre = a->center();
        t.radius = std::max(0.3f, 0.5f * glm::length(a->extent()));
        stand.push_back(std::move(t));
    };
    // +Z is straight ahead. (Facing +Z, +X is on your left.)
    put("plate 8 m",  plate,     { 2.2f, 0, 8.0f },   0.0f, 40.0f);
    put("dummy",      dummy,     { 0.0f, 0, 11.0f },  180.0f, 120.0f);
    put("plate 14 m", plate,     { -3.0f, 0, 14.0f }, 0.0f, 40.0f);
    put("drum",       drumAsset, { -1.2f, 0, 17.0f }, 0.0f, 60.0f);
    put("dummy",      dummy,     { 6.5f, 0, 18.0f },  180.0f, 120.0f);
    put("plate 22 m", plate,     { 4.5f, 0, 22.0f },  0.0f, 40.0f);
    put("dummy",      dummy,     { -7.0f, 0, 24.0f }, 180.0f, 120.0f);
    put("drum",       drumAsset, { 1.5f, 0, 25.0f },  0.0f, 60.0f);
    put("plate 30 m", plate,     { -5.5f, 0, 30.0f }, 0.0f, 40.0f);
}

void ItemRange::buildDents() {
    dents.clear();
    dents.resize(2);

    {   // the wall at the far end: a stone plinth, brick, a stone cap
        Dent& d = dents[0];
        NewAssetSpec s; s.name = "range wall"; s.voxelSize = 0.1f; s.sizeMetres = { 16.0f, 4.6f, 1.4f };
        d.model.create(s);
        d.origin = glm::vec3(0.0f, 0.0f, kFarZ);
        const glm::vec3 lo = d.model.gridMin(), hi = d.model.gridMax();
        const float vs = d.model.asset.voxelSize;
        const glm::vec3 a(lo.x + vs * 1.5f, lo.y - 1.0f, lo.z + vs * 1.5f), b(hi.x - vs * 1.5f, hi.y - vs * 1.5f, hi.z - vs * 1.5f);
        auto slab = [&](float y0, float y1, MaterialId m) {
            const glm::vec3 c((a.x + b.x) * 0.5f, (y0 + y1) * 0.5f, (a.z + b.z) * 0.5f), h((b.x - a.x) * 0.5f, (y1 - y0) * 0.5f, (b.z - a.z) * 0.5f);
            d.model.stampSdf([=](const glm::vec3& p) { return roundedBox(p - c, h, 0.06f); }, c - h - glm::vec3(0.05f), c + h + glm::vec3(0.05f), StampMode::Add, m, 0.0f);
        };
        slab(a.y, 0.55f, MAT_STONE);
        slab(0.45f, b.y - 0.35f, MAT_BRICK);
        slab(b.y - 0.40f, b.y, MAT_STONE);
        d.model.remesh();
        d.lo = d.origin + lo; d.hi = d.origin + hi;
    }
    {   // a block of sand to dig in
        Dent& d = dents[1];
        NewAssetSpec s; s.name = "range sand"; s.voxelSize = 0.1f; s.sizeMetres = { 10.0f, 1.8f, 8.0f };
        d.model.create(s);
        d.origin = glm::vec3(-14.0f, 0.0f, 12.0f);
        const glm::vec3 lo = d.model.gridMin(), hi = d.model.gridMax();
        const float vs = d.model.asset.voxelSize;
        const glm::vec3 a(lo.x + vs * 1.5f, lo.y - 1.0f, lo.z + vs * 1.5f), b(hi.x - vs * 1.5f, 1.45f, hi.z - vs * 1.5f);
        const glm::vec3 c = (a + b) * 0.5f, h = (b - a) * 0.5f;
        d.model.stampSdf([=](const glm::vec3& p) { return roundedBox(p - c, h, 0.25f); }, c - h - glm::vec3(0.05f), c + h + glm::vec3(0.05f), StampMode::Add, MAT_SAND, 0.0f);
        d.model.remesh();
        d.lo = d.origin + lo; d.hi = d.origin + hi;
    }
}

// ------------------------------------------------------------------ the item

void ItemRange::setDraft(const ItemDef& def, AssetPtr model) {
    ItemDef d = def;
    d.userMade = true;
    library.add(d);                         // replaces in place: pointers the item system holds stay good
    draftModel = std::move(model);
    items.library = &library;
    items.findAsset = [this](const std::string&) { return draftModel; };
    items.enabled = true;
    if (items.slots.size() != 1 || items.slots[0].item != d.name) {
        items.setHotbar({ d.name }, 0);
        items.reset();
    }
    if (!items.slots.empty()) {
        const ItemDef* now = library.find(d.name);
        if (now && now->stats.magazine > 0 && items.slots[0].ammo > now->stats.magazine) items.slots[0].ammo = now->stats.magazine;
    }
}

void ItemRange::clearDraft() {
    items.enabled = false;
    items.setHotbar({}, 0);
    items.reset();
    draftModel.reset();
}

void ItemRange::reset() {
    buildDents();
    for (Target& t : stand) { t.health = t.maxHealth; t.fall = 0.0f; t.downFor = 0.0f; t.wobble = 0.0f; t.flash = 0.0f; }
    floaters.clear();
    recent.clear();
    clearScore();
    position = glm::vec3(0.0f, 0.0f, kLineZ);
    velocity = glm::vec3(0.0f);
    items.reset();
    if (!items.slots.empty())
        if (const ItemDef* d = items.currentDef()) items.slots[size_t(std::max(0, items.current))].ammo = d->stats.magazine;
}

void ItemRange::clearScore() {
    items.totals = ItemSystem::Totals{};
    tally = Score{};
    splashHits = 0;
    recent.clear();
}

ItemRange::Score ItemRange::score() const {
    Score s = tally;
    s.shots = items.totals.shots;
    s.hits = items.totals.hits + splashHits;
    s.explosions = items.totals.explosions;
    float sum = 0.0f;
    for (const auto& e : recent) sum += e.second;
    if (!recent.empty()) s.perSecond = sum / std::clamp(clock - recent.front().first, 1.0f, 4.0f);
    return s;
}

// ------------------------------------------------------------------ every frame

void ItemRange::update(float dt, float yawDeg, float pitchDeg, float moveForward, float moveRight, bool run) {
    clock += dt;

    // walking, with a little gravity so a blast can throw you
    const float yr = glm::radians(yawDeg);
    const glm::vec3 fwd(std::cos(yr), 0.0f, std::sin(yr)), right(-fwd.z, 0.0f, fwd.x);
    glm::vec3 want = fwd * moveForward + right * moveRight;
    if (glm::length(want) > 1.0f) want = glm::normalize(want);
    want *= run ? 8.0f : 4.5f;
    const float k = std::min(1.0f, (grounded ? 10.0f : 1.2f) * dt);
    velocity.x += (want.x - velocity.x) * k;
    velocity.z += (want.z - velocity.z) * k;
    if (!grounded || velocity.y > 0.0f) velocity.y -= 24.0f * dt;
    position += velocity * dt;
    if (position.y <= 0.0f) { position.y = 0.0f; if (velocity.y < 0.0f) velocity.y = 0.0f; grounded = true; }
    else grounded = false;
    position.x = std::clamp(position.x, -11.5f, 11.5f);
    position.z = std::clamp(position.z, -5.0f, kFarZ - 2.5f);

    lastView = ItemView::fromAngles(eye(), yawDeg, pitchDeg, grounded ? glm::length(glm::vec2(velocity.x, velocity.z)) : 0.0f);
    items.update(dt, *this, lastView);

    // targets: hits shake them, a dead one topples and stands up again after a moment
    for (Target& t : stand) {
        t.flash = std::max(0.0f, t.flash - dt * 4.0f);
        t.wobble *= std::exp(-dt * 4.5f);
        t.wobbleT += dt;
        if (t.alive()) t.fall = std::max(0.0f, t.fall - dt * 2.5f);
        else {
            t.fall = std::min(1.0f, t.fall + dt * 3.4f);
            t.downFor += dt;
            if (t.downFor > 2.6f) { t.health = t.maxHealth; t.downFor = 0.0f; }
        }
    }
    for (Number& n : floaters) n.age += dt;
    floaters.erase(std::remove_if(floaters.begin(), floaters.end(), [](const Number& n) { return n.age > 1.2f; }), floaters.end());
    while (!recent.empty() && clock - recent.front().first > 4.0f) recent.pop_front();
}

void ItemRange::collect(std::vector<ObjectDraw>& out) const {
    for (const Dent& d : dents)
        if (d.model.asset.valid() && !d.model.asset.mesh.empty())
            out.push_back({ AssetPtr(AssetPtr(), const_cast<Asset*>(&d.model.asset)), dentMatrix(d), 1.0f, glm::vec4(0.0f) });
    for (const Target& t : stand) {
        ObjectDraw o;
        o.asset = t.asset; o.model = t.matrix(); o.scale = 1.0f;
        o.highlight = glm::vec4(1.0f, 0.95f, 0.8f, t.flash * 0.7f);
        out.push_back(std::move(o));
    }
    ObjectDraw held;
    if (items.heldDraw(lastView, held)) out.push_back(std::move(held));
}

// ------------------------------------------------------------------ ItemWorld

bool ItemRange::raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDistance, ItemRayHit& hit) {
    bool got = false;
    float best = maxDistance;
    auto take = [&](float distance, const glm::vec3& point, const glm::vec3& normal, std::uint32_t object, int target, MaterialId material) {
        if (distance < 0.0f || distance > best) return;
        best = distance; got = true;
        hit.point = point; hit.normal = normal; hit.distance = distance; hit.object = object; hit.target = target; hit.material = material;
    };

    if (dir.y < -1e-5f && origin.y > 0.0f) {                                   // the floor
        const float t = -origin.y / dir.y;
        take(t, origin + dir * t, glm::vec3(0, 1, 0), 0, -1, MAT_STONE);
    }
    for (const Dent& d : dents) {                                              // things you can dent
        const WorkshopHit h = d.model.raycast(origin - d.origin, dir, best);
        if (h.hit && !h.floor) take(h.distance, h.point + d.origin, h.normal, 0, -1, d.model.asset.materialNear(h.point - h.normal * 0.05f));
    }
    for (size_t i = 0; i < stand.size(); ++i) {                                // targets
        const Target& t = stand[i];
        if (!t.alive()) continue;
        const glm::mat4 m = t.matrix(), inv = glm::inverse(m);
        const glm::vec3 lo = glm::vec3(inv * glm::vec4(origin, 1.0f));
        const glm::vec3 ld = glm::normalize(glm::vec3(inv * glm::vec4(dir, 0.0f)));
        float th = 0.0f;
        if (!t.asset->raycast(lo, ld, best, th)) continue;
        const glm::vec3 lp = lo + ld * th;
        const glm::vec3 n = glm::normalize(glm::vec3(m * glm::vec4(t.asset->gradient(lp), 0.0f)));
        take(th, glm::vec3(m * glm::vec4(lp, 1.0f)), n, 100u + std::uint32_t(i), int(i), t.asset->materialNear(lp));
    }
    if (got && hit.material == MAT_NATURAL) hit.material = MAT_STONE;
    return got;
}

void ItemRange::crater(const glm::vec3& centre, float radius, bool build, MaterialId material) {
    if (material == MAT_NATURAL) material = MAT_STONE;
    for (Dent& d : dents) {
        if (centre.x < d.lo.x - radius || centre.x > d.hi.x + radius || centre.y < d.lo.y - radius || centre.y > d.hi.y + radius ||
            centre.z < d.lo.z - radius || centre.z > d.hi.z + radius) continue;
        const glm::vec3 c = centre - d.origin;
        const float r = radius;
        // a slightly lumpy sphere, so holes do not all look alike
        d.model.stampSdf([c, r](const glm::vec3& p) {
                             const glm::vec3 q = p - c;
                             return glm::length(q) - r * (1.0f + 0.10f * std::sin(q.x * 9.0f + 1.0f) * std::sin(q.y * 8.0f + 2.0f) * std::sin(q.z * 7.0f + 3.0f));
                         },
                         c - glm::vec3(r * 1.2f + 0.1f), c + glm::vec3(r * 1.2f + 0.1f), build ? StampMode::Add : StampMode::Carve, material, 0.0f);
        d.model.remesh();
    }
}

void ItemRange::blast(const glm::vec3& centre, float radius, float push) {
    const glm::vec3 body = position + glm::vec3(0.0f, 0.9f, 0.0f);
    glm::vec3 d = body - centre;
    const float dist = glm::length(d);
    const float reach = radius * 2.5f + 1.0f;
    if (dist >= reach) return;
    d = dist > 1e-3f ? d / dist : glm::vec3(0, 1, 0);
    const glm::vec3 dir = glm::normalize(d + glm::vec3(0.0f, 0.35f, 0.0f));
    const float fall = 1.0f - dist / reach;
    velocity += dir * push * fall * fall * 1.6f;
    grounded = false;
}

void ItemRange::sound(const std::string& clip, const glm::vec3& at, float volume, float pitch) {
    if (onSound) onSound(clip, at, volume, pitch);
}

void ItemRange::knock(Target& t, float damage, const glm::vec3& at) {
    if (!t.alive() || damage <= 0.0f) return;
    t.health -= damage;
    t.flash = 1.0f;
    t.wobble = std::min(9.0f, t.wobble + 3.0f + damage * 0.05f);
    t.wobbleT = 0.0f;
    tally.damage += damage;
    recent.emplace_back(clock, damage);
    const bool kill = !t.alive();
    if (kill) { ++tally.down; t.downFor = 0.0f; }
    Number n; n.at = at + glm::vec3(0.0f, 0.2f, 0.0f); n.amount = damage; n.kill = kill;
    floaters.push_back(n);
    if (floaters.size() > 40) floaters.erase(floaters.begin());
}

void ItemRange::hit(const ItemHit& h) {
    if (h.explosion) {
        bool any = false;
        for (Target& t : stand) {
            if (!t.alive()) continue;
            const glm::vec3 mid = t.base + t.centre;
            const float reach = h.radius * 1.6f + t.radius;
            const float d = glm::length(mid - h.point);
            if (d >= reach) continue;
            const float f = 1.0f - d / reach;
            knock(t, h.damage * (0.25f + 0.75f * f), mid);
            any = true;
        }
        if (any) ++splashHits;
        return;
    }
    if (h.target >= 0 && size_t(h.target) < stand.size()) knock(stand[size_t(h.target)], h.damage, h.point);
}

} // namespace px
