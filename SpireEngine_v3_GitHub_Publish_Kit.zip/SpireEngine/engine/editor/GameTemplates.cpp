// Starter templates (v0.22): a whole little game in one click, built in front of you out of ordinary objects, gadgets,
// people and rules - so everything in it can be opened up, changed and learned from. Tools > New Game From Template.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "rules/Gadgets.h"
#include "character/BodyParts.h"
#include <algorithm>
#include <cmath>

namespace px {

namespace {
constexpr float kTau = 6.2831853f;
RuleAction doIt(RuleDo d, std::string text = {}, float number = 0.0f, RuleObjectId target = kRuleSelf) {
    RuleAction a; a.what = d; a.text = std::move(text); a.number = number; a.target = target;
    return a;
}
Rule when(RuleWhen w, std::vector<RuleAction> acts, float number = 3.0f, std::string text = {}, bool once = false) {
    Rule r; r.when = w; r.actions = std::move(acts); r.number = number; r.text = std::move(text); r.once = once;
    return r;
}
} // namespace

const char* Application::gameTemplateLabel(GameTemplate t) {
    switch (t) {
    case GameTemplate::Parkour: return "Parkour";
    case GameTemplate::CoinHunt: return "Coin Hunt";
    case GameTemplate::CaptureTheFlag: return "Capture the Flag";
    case GameTemplate::Survival: return "Survival";
    case GameTemplate::Sandbox: return "Sandbox";
    case GameTemplate::Count: break;
    }
    return "";
}
const char* Application::gameTemplateHint(GameTemplate t) {
    switch (t) {
    case GameTemplate::Parkour: return "Jump up a tower of blocks to the flag. Checkpoints on the way; fall and you go back to the last one.";
    case GameTemplate::CoinHunt: return "Find every coin and gem before the time runs out.";
    case GameTemplate::CaptureTheFlag: return "Sneak past the guards, take their flag and bring it home. Three lives.";
    case GameTemplate::Survival: return "Hunters are after you. Last 90 seconds; gems give you points and extra time.";
    case GameTemplate::Sandbox: return "No goal, no clock: just play. (Takes the game rules away; your objects stay.)";
    case GameTemplate::Count: break;
    }
    return "";
}

void Application::buildGameTemplate(GameTemplate t) {
    setMode(Mode::Editor);
    stopPlacing();
    const glm::vec3 ahead = camera.position + camera.flatFront() * 24.0f;
    const glm::vec3 c(ahead.x, demospot::groundHeight(world, ahead.x, ahead.z), ahead.z);
    auto ground = [&](float x, float z) { return glm::vec3(c.x + x, demospot::groundHeight(world, c.x + x, c.z + z) + 0.02f, c.z + z); };
    std::vector<ObjectId> made;
    auto place = [&](const std::string& asset, const glm::vec3& at, float yaw = 0.0f, float size = 1.0f) {
        SceneObject o;
        o.asset = asset;
        o.position = at; o.rotation = glm::vec3(0.0f, yaw, 0.0f); o.scale = size;
        o.name = asset;
        if (const GadgetPreset* g = gadgetFor(asset)) { o.name = g->label; o.rules = rulesToText(g->rules); o.motion = g->motion; }
        const ObjectId id = scene.add(o);
        made.push_back(id);
        return id;
    };
    auto person = [&](const std::string& who, const glm::vec3& at, float yaw, const NpcSettings& st, const RuleSet* rules = nullptr) {
        if (!characters.has(who)) return ObjectId(0);
        const CharacterDef def = characters.get(who);
        SceneObject o;
        o.asset = kCharacterStandIn; o.character = who; o.name = def.name;
        o.position = at; o.rotation = glm::vec3(0.0f, yaw, 0.0f); o.scale = def.shape.height / 1.8f;
        o.npc = npcToText(st);
        if (rules) o.rules = rulesToText(*rules);
        const ObjectId id = scene.add(o);
        made.push_back(id);
        return id;
    };
    auto setRulesOn = [&](ObjectId id, const RuleSet& r) { if (SceneObject* m = scene.mutate(id)) m->rules = rulesToText(r); };
    GameRules g;
    const AssetPtr crate = assets.get("crate");
    const float crateTop = crate ? crate->boundsMax.y : 2.5f;

    switch (t) {
    case GameTemplate::Parkour: {
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z), 14.0f);
        // a spiral of blocks, each a little higher, round a centre
        const int n = 16;
        float h = 0.0f, firstYaw = 0.0f;
        glm::vec3 start(0.0f);
        for (int i = 0; i < n; ++i) {
            const float a = float(i) * 0.62f;
            const float r = 7.5f - float(i) * 0.12f;
            h = 1.0f + float(i) * 0.75f;
            const glm::vec3 top(c.x + std::cos(a) * r, c.y + h, c.z + std::sin(a) * r);
            const float size = i == 0 || i == n - 1 ? 0.8f : 0.55f;
            place("crate", top - glm::vec3(0.0f, crateTop * size, 0.0f), float(i) * 23.0f, size);
            if (i == 0) start = top;
            if (i == 1) { const glm::vec3 d = top - start; firstYaw = glm::degrees(std::atan2(d.z, d.x)); }
            if (i == 5 || i == 10) {
                const ObjectId cp = place("gadget pressure plate", top);
                RuleSet r; r.rules.push_back(when(RuleWhen::Touch, { doIt(RuleDo::Checkpoint), doIt(RuleDo::Sound, "chime") }, 3.0f, {}, true));
                setRulesOn(cp, r);
                scene.mutate(cp)->name = i == 5 ? "Checkpoint 1" : "Checkpoint 2";
            } else if (i % 3 == 2) {
                place("gadget coin", top + glm::vec3(0.0f, 0.1f, 0.0f));
            }
            if (i == n - 1) place("gadget finish flag", top);
        }
        place("gadget sign", ground(-3.0f, 9.5f), 180.0f);
        RuleSet sign; sign.rules.push_back(when(RuleWhen::Near, { doIt(RuleDo::Message, "Climb the tower to the flag! Fall, and you go back to your last checkpoint.") }, 4.0f));
        setRulesOn(made.back(), sign);
        g.goal = GameGoal::Finish;
        g.fallLimit = 3.0f;
        g.hasSpawn = true; g.spawn = start + glm::vec3(0.0f, 0.05f, 0.0f); g.spawnYaw = firstYaw;
        g.startText = "Parkour: climb to the flag!";
        g.winText = "You reached the top!";
        break;
    }
    case GameTemplate::CoinHunt: {
        std::uint32_t r = 12345u;
        auto rnd = [&]() { r ^= r << 13; r ^= r >> 17; r ^= r << 5; return float(r % 10000u) / 10000.0f; };
        for (int i = 0; i < 18; ++i) {
            const float a = rnd() * kTau, d = 4.0f + rnd() * 26.0f;
            place(i % 6 == 5 ? "gadget gem" : "gadget coin", ground(std::cos(a) * d, std::sin(a) * d) + glm::vec3(0.0f, 0.15f, 0.0f));
        }
        const ObjectId sign = place("gadget sign", ground(0.0f, 2.5f), 180.0f);
        RuleSet sr; sr.rules.push_back(when(RuleWhen::Near, { doIt(RuleDo::Message, "Find every coin and gem in two minutes. Gems are worth five!") }, 4.0f));
        setRulesOn(sign, sr);
        g.goal = GameGoal::CollectAll;
        g.timeLimit = 120.0f;
        g.hasSpawn = true; g.spawn = ground(0.0f, 0.0f); g.spawnYaw = camera.yaw;
        g.startText = "Coin Hunt: find them all before time runs out!";
        g.winText = "You found everything!";
        g.loseText = "Out of time!";
        break;
    }
    case GameTemplate::CaptureTheFlag: {
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z), 22.0f);
        world.paint(glm::vec3(c.x, c.y, c.z), 20.0f, MAT_DIRT);
        // home base (you) at -z, their flag at +z, guards round it, crates for cover
        const glm::vec3 home = ground(0.0f, -16.0f), theirs = ground(0.0f, 16.0f);
        const ObjectId flag = place("gadget finish flag", theirs);
        scene.mutate(flag)->name = "Their flag";
        RuleSet fr; fr.rules.push_back(when(RuleWhen::Touch, { doIt(RuleDo::Hide), doIt(RuleDo::Message, "You have their flag! Bring it home!"), doIt(RuleDo::Send, "flag taken"),
                                                              doIt(RuleDo::Sound, "pickup") }, 3.0f, {}, true));
        setRulesOn(flag, fr);
        const ObjectId base = place("gadget pressure plate", home);
        scene.mutate(base)->name = "Home base";
        RuleSet br; br.startsHidden = true;
        br.rules.push_back(when(RuleWhen::Hears, { doIt(RuleDo::Show), doIt(RuleDo::Message, "Get back to your base!") }, 3.0f, "flag taken"));
        br.rules.push_back(when(RuleWhen::Touch, { doIt(RuleDo::Win, "Flag captured!") }, 3.0f, {}, true));
        setRulesOn(base, br);
        const ObjectId homeFlag = place("gadget finish flag", home + glm::vec3(2.5f, 0.0f, -1.0f));
        scene.mutate(homeFlag)->name = "Your flag";
        scene.mutate(homeFlag)->rules.clear();
        for (int i = 0; i < 8; ++i) {
            const float x = (i % 2 ? 1.0f : -1.0f) * (3.0f + float(i % 4) * 2.5f), z = -6.0f + float(i) * 2.2f;
            place("crate", ground(x, z), float(i) * 37.0f, 0.45f);
        }
        NpcSettings guard; guard.role = NpcRole::Guard; guard.radius = 9.0f; guard.reaction = NpcReaction::Ignore; guard.speed = 1.1f;
        guard.lines = { "Halt!", "Intruder!", "Get away from our flag!" };
        RuleSet caught; caught.rules.push_back(when(RuleWhen::Near, { doIt(RuleDo::LoseLife), doIt(RuleDo::Message, "Caught! Back to base.") }, 1.9f));
        for (int i = 0; i < 3; ++i) {
            const float a = float(i) / 3.0f * kTau + 0.5f;
            person(crowdName(CrowdStyle::Soldiers, 900u + std::uint32_t(i)), ground(std::cos(a) * 5.0f, 16.0f + std::sin(a) * 5.0f), glm::degrees(a) + 90.0f, guard, &caught);
        }
        g.goal = GameGoal::Finish;
        g.lives = 3;
        g.hasSpawn = true; g.spawn = home + glm::vec3(0.0f, 0.15f, -2.0f); g.spawnYaw = camera.yaw;
        {
            const glm::vec3 d = theirs - home;
            g.spawnYaw = glm::degrees(std::atan2(d.z, d.x));
        }
        g.startText = "Capture the Flag: take their flag and bring it home. Don't get caught!";
        g.loseText = "Caught too many times!";
        break;
    }
    case GameTemplate::Survival: {
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z), 22.0f);
        NpcSettings hunter; hunter.role = NpcRole::Guard; hunter.radius = 45.0f; hunter.reaction = NpcReaction::Ignore; hunter.speed = 1.25f;
        hunter.lines = { "There you are!", "You can't hide!" };
        RuleSet caught; caught.rules.push_back(when(RuleWhen::Near, { doIt(RuleDo::LoseLife), doIt(RuleDo::Message, "Caught!") }, 1.9f));
        for (int i = 0; i < 4; ++i) {
            const float a = float(i) / 4.0f * kTau;
            person(crowdName(CrowdStyle::Fantasy, 700u + std::uint32_t(i)), ground(std::cos(a) * 18.0f, std::sin(a) * 18.0f), glm::degrees(a) + 180.0f, hunter, &caught);
        }
        std::uint32_t r = 777u;
        auto rnd = [&]() { r ^= r << 13; r ^= r >> 17; r ^= r << 5; return float(r % 10000u) / 10000.0f; };
        for (int i = 0; i < 8; ++i) {
            const float a = rnd() * kTau, d = 4.0f + rnd() * 16.0f;
            const ObjectId gem = place("gadget gem", ground(std::cos(a) * d, std::sin(a) * d) + glm::vec3(0.0f, 0.1f, 0.0f));
            RuleSet gr; gr.rules.push_back(when(RuleWhen::Touch, { doIt(RuleDo::Collect, {}, 5.0f), doIt(RuleDo::AddTime, {}, -5.0f) }));
            setRulesOn(gem, gr);
        }
        for (int i = 0; i < 6; ++i) {
            const float a = float(i) / 6.0f * kTau + 0.3f;
            place("crate", ground(std::cos(a) * 9.0f, std::sin(a) * 9.0f), float(i) * 40.0f, 0.5f);
        }
        g.goal = GameGoal::Survive;
        g.timeLimit = 90.0f;
        g.lives = 3;
        g.hasSpawn = true; g.spawn = ground(0.0f, 0.0f); g.spawnYaw = camera.yaw;
        g.startText = "Survival: last 90 seconds! Gems take 5 seconds off the clock.";
        g.winText = "You survived!";
        g.loseText = "They got you!";
        break;
    }
    case GameTemplate::Sandbox:
    case GameTemplate::Count:
        break;
    }
    scene.setGameRules(gameRulesToText(g));
    commitScene(std::string("New game: ") + gameTemplateLabel(t));
    if (!made.empty()) setSelection({});
    if (g.hasSpawn) {
        camera.position = g.spawn + glm::vec3(0.0f, 3.5f, 0.0f) - glm::vec3(std::cos(glm::radians(g.spawnYaw)), 0.0f, std::sin(glm::radians(g.spawnYaw))) * 6.0f;
        camera.yaw = g.spawnYaw; camera.pitch = -18.0f;
    }
    toast(t == GameTemplate::Sandbox ? std::string("Sandbox: no goal, no clock. Have fun!")
                                     : std::string(gameTemplateLabel(t)) + " is ready. Press Play (Tab) to try it; Tools > Game Rules to change it.", Toast::Kind::Success);
}

} // namespace px
