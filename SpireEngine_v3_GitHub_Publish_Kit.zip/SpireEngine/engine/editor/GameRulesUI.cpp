// The Game Rules window (v0.22): the goal of the whole game, the clock, lives, falling, where you start, and what it says
// at the start and the end. Tools > Game Rules... The rules themselves are in rules/GameRules.* (pure, unit tested).
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <imgui.h>

namespace px {

using namespace ui;

GameRules Application::gameRulesOf() const {
    GameRules g;
    gameRulesFromText(scene.gameRules(), g);
    return g;
}

void Application::setGameRules(const GameRules& in, const std::string& undoLabel) {
    GameRules g = in;
    g.clamp();
    scene.setGameRules(gameRulesToText(g));
    commitScene(undoLabel);
}

void Application::drawGameRulesWindow() {
    if (!showGameRules) return;
    const float s = scale();
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowSize(ImVec2(420 * s, 0), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.5f, vp->WorkPos.y + 70 * s), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.0f));
    if (!ImGui::Begin("Game Rules###gamerules", &showGameRules, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::End();
        return;
    }
    GameRules g = gameRulesOf();
    bool changed = false, commit = false;

    ImGui::TextDisabled("What is the game about?");
    {
        float x = 0.0f;
        const float avail = ImGui::GetContentRegionAvail().x;
        for (int i = 0; i < int(GameGoal::Count); ++i) {
            const char* l = gameGoalLabel(GameGoal(i));
            const float w = ImGui::CalcTextSize(l).x + ImGui::GetStyle().FramePadding.x * 2.0f;
            if (i && x + 4 * s + w <= avail) { ImGui::SameLine(0, 4 * s); x += 4 * s; } else x = 0.0f;
            x += w;
            const bool on = g.goal == GameGoal(i);
            if (on) pushSelectedButton();
            ImGui::PushID(i);
            if (ImGui::Button(l)) { g.goal = GameGoal(i); changed = commit = true; if (g.goal == GameGoal::Survive && g.timeLimit <= 0.0f) g.timeLimit = 60.0f; }
            ImGui::PopID();
            if (on) popSelectedButton();
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", gameGoalHint(GameGoal(i)));
        }
    }
    pushFont(fonts.small);
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextDisabled("%s", gameGoalHint(g.goal));
    ImGui::PopTextWrapPos();
    popFont();
    ImGui::Dummy(ImVec2(0, 4 * s));
    if (beginProps("##gameprops", 120.0f)) {
        auto after = [&]() { if (ImGui::IsItemDeactivatedAfterEdit()) commit = true; };
        if (g.goal == GameGoal::Points) {
            prop("Points to win");
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::DragInt("##pts", &g.points, 0.2f, 1, 100000)) changed = true;
            after();
        }
        prop(g.goal == GameGoal::Survive ? "Survive for" : "Time limit", "0 = no limit");
        ImGui::SetNextItemWidth(-FLT_MIN);
        char tl[32];
        if (g.timeLimit <= 0.0f) std::snprintf(tl, sizeof tl, "no limit");
        else std::snprintf(tl, sizeof tl, "%s", gameClock(g.timeLimit).c_str());
        if (ImGui::SliderFloat("##time", &g.timeLimit, 0.0f, 900.0f, tl)) { g.timeLimit = std::round(g.timeLimit / 5.0f) * 5.0f; changed = true; }
        after();
        prop("Lives", "0 = you can't run out");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderInt("##lives", &g.lives, 0, 9, g.lives == 0 ? "unlimited" : "%d")) changed = true;
        after();
        prop("Falling", "Falling this far below where you start (or your last checkpoint) costs a life and puts you back. 0 = off");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::SliderFloat("##fall", &g.fallLimit, 0.0f, 50.0f, g.fallLimit <= 0.0f ? "off" : "%.0f m down")) { g.fallLimit = std::round(g.fallLimit); changed = true; }
        after();
        prop("You start", "Where play begins");
        if (g.hasSpawn) {
            ImGui::Text("%.0f, %.0f, %.0f", double(g.spawn.x), double(g.spawn.y), double(g.spawn.z));
            ImGui::SameLine();
            if (ImGui::SmallButton("Here instead")) {
                g.spawn = glm::vec3(camera.position.x, demospot::groundHeight(world, camera.position.x, camera.position.z) + 0.05f, camera.position.z);
                g.spawnYaw = camera.yaw; changed = commit = true;
            }
            ImGui::SameLine();
            if (ImGui::SmallButton("Clear")) { g.hasSpawn = false; changed = commit = true; }
        } else {
            ImGui::TextDisabled("where you are");
            ImGui::SameLine();
            if (ImGui::SmallButton("Start here")) {
                g.hasSpawn = true;
                g.spawn = glm::vec3(camera.position.x, demospot::groundHeight(world, camera.position.x, camera.position.z) + 0.05f, camera.position.z);
                g.spawnYaw = camera.yaw; changed = commit = true;
            }
        }
        auto text = [&](const char* lab, const char* tip, std::string& v) {
            prop(lab, tip);
            char buf[220];
            std::snprintf(buf, sizeof buf, "%s", v.c_str());
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::InputText((std::string("##") + lab).c_str(), buf, sizeof buf)) { v = buf; changed = true; }
            after();
        };
        text("At the start", "A message when play begins", g.startText);
        text("Winning says", "Empty: \"You win!\"", g.winText);
        text("Losing says", "Empty: \"Game over\"", g.loseText);
        endProps();
    }
    ImGui::Dummy(ImVec2(0, 4 * s));
    if (ImGui::Button("Play it", ImVec2(-FLT_MIN, 30 * s))) { showGameRules = false; setMode(Mode::Play); }
    ImGui::TextDisabled("Rules on objects (Properties > Rules) can also win, lose, add points and time.");
    if (changed) {
        GameRules c = g; c.clamp();
        scene.setGameRules(gameRulesToText(c));
        if (commit) commitScene("Change the game rules");
    }
    ImGui::End();
}

} // namespace px
