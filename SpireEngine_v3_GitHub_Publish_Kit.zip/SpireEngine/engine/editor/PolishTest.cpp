// --demo polish_...: screenshots of the tutorial, the Controls and Accessibility settings and the bigger HUD (v0.24),
// and a self test that drives the real code (changing a key and using it, toggle run, colour-blind colours, captions,
// reduced motion, every step of the tutorial) and prints "[polishtest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <string>

namespace px {

void Application::setupPolishDemo() {
    if (demo == "polish_selftest") { runPolishSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    const glm::vec3 c = demospot::calmSpot(world);
    camera.position = c + glm::vec3(0.0f, 4.0f, 8.0f); camera.yaw = -90.0f; camera.pitch = -15.0f;
    toasts.clear();
    if (demo == "polish_tutorial") { showHints = false; startTutorial(); tutorial.next(); return; }
    if (demo == "polish_controls") { openSettingsTab(4); rebinding = int(Action::Use); return; }
    if (demo == "polish_access") { settings.colourBlind = true; settings.bigHud = true; settings.captions = true; applySettings(); openSettingsTab(5); return; }
    if (demo == "polish_hud") {
        settings.colourBlind = true; settings.bigHud = true; settings.captions = true; applySettings();
        buildGameTemplate(GameTemplate::CoinHunt);
        const ObjectId door = placeObject("gadget door", glm::vec3(camera.position.x, demospot::groundHeight(world, camera.position.x, camera.position.z - 3.0f), camera.position.z - 3.0f));
        (void)door;
        const GameRules g = gameRulesOf();
        camera.position = glm::vec3(camera.position.x, demospot::groundHeight(world, camera.position.x, camera.position.z) + 1.7f, camera.position.z + 0.5f);
        camera.yaw = -90.0f; camera.pitch = -12.0f;
        GameRules nostart = g; nostart.hasSpawn = false;
        setGameRules(nostart, "demo");
        setMode(Mode::Play);
        for (int i = 0; i < 4; ++i) update(1.0f / 30.0f);
        caption("pickup"); caption("door open");
        for (Caption& cp : captions) cp.left = 1000.0f;                          // hold them for the picture
        ruleBanners.push_back({ "A bigger message for everyone", 30.0f, 30.0f });
        toasts.clear();
        return;
    }
}

void Application::runPolishSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[polishtest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto press = [&](SDL_Scancode sc) {
        SDL_Event e{}; e.type = SDL_EVENT_KEY_DOWN; e.key.scancode = sc; e.key.key = SDL_GetKeyFromScancode(sc, SDL_KMOD_NONE, false); e.key.down = true;
        handleEvent(e);
    };
    const UserSettings saved = settings;
    setMode(Mode::Editor);
    tool = Tool::Select;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    const glm::vec3 c = demospot::calmSpot(world);
    world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 6.0f), 12.0f);

    // ---- changing a key, and using it
    settings.keys = KeyBindings();
    rebinding = int(Action::Use);
    press(SDL_SCANCODE_F);
    check(rebinding == -1 && settings.keys[Action::Use] == SDL_SCANCODE_F, "Settings > Controls: click Use, press F: F uses things now");
    rebinding = int(Action::Jump);
    press(SDL_SCANCODE_ESCAPE);
    check(rebinding == -1 && settings.keys[Action::Jump] == SDL_SCANCODE_SPACE, "...and Esc leaves a key as it was");
    const glm::vec3 doorAt(c.x, demospot::groundHeight(world, c.x, c.z - 6.0f), c.z - 6.0f);
    const ObjectId door = placeObject("gadget door", doorAt);
    camera.position = doorAt + glm::vec3(0.0f, 1.7f, 2.5f); camera.yaw = -90.0f; camera.pitch = -8.0f;
    setMode(Mode::Play);
    for (int i = 0; i < 3; ++i) { player.position = doorAt + glm::vec3(0.0f, 0.0f, 2.5f); player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); }
    check(useTarget == door, "looking at a door");
    press(SDL_SCANCODE_E);
    update(1.0f / 30.0f);
    check(!ruleEngine.isOpen(door), "E does nothing any more");
    press(SDL_SCANCODE_F);
    update(1.0f / 30.0f);
    check(ruleEngine.isOpen(door), "F opens the door");
    // toggle run
    settings.toggleRun = true;
    runToggled = false;
    press(SDL_SCANCODE_LSHIFT);
    check(runToggled, "toggle run: tap Shift to run...");
    press(SDL_SCANCODE_LSHIFT);
    check(!runToggled, "...tap it again to walk");
    settings.toggleRun = false;
    // captions
    settings.captions = true;
    captions.clear();
    press(SDL_SCANCODE_F);
    update(1.0f / 30.0f);
    bool heard = false;
    for (const Caption& cp : captions) heard = heard || cp.text == "Door thuds shut";
    check(heard, "captions: closing the door shows [Door thuds shut]");
    setMode(Mode::Editor);

    // ---- colour-blind friendly colours
    const ImU32 usualDanger = ui::col::danger, usualX = ui::axisColour(0);
    settings.colourBlind = true; applySettings();
    check(ui::col::danger != usualDanger && ui::axisColour(0) != usualX && ui::colourBlindFriendly(), "colour-blind friendly: other colours for bad and for the gizmo");
    settings.colourBlind = false; applySettings();
    check(ui::col::danger == usualDanger && ui::axisColour(0) == usualX, "...and back");

    // ---- reduce motion: bookmarks jump instead of gliding
    settings.reduceMotion = true;
    const glm::vec3 target = camera.position + glm::vec3(50.0f, 10.0f, 0.0f);
    flyTo.start(camera, target, camera.yaw + 40.0f, -10.0f);
    update(1.0f / 60.0f);
    check(glm::length(camera.position - target) < 0.01f && !flyTo.active, "reduce motion: the camera goes straight to a bookmark");
    settings.reduceMotion = false;

    // ---- the tutorial, step by step, by doing each thing
    settings.tutorialDone = false;
    camera.position = c + glm::vec3(0.0f, 6.0f, 6.0f); camera.yaw = -90.0f; camera.pitch = -35.0f;
    startTutorial();
    check(tutorial.active && tutorial.step == TutorialStep::Welcome, "the tutorial starts with a welcome");
    tutorial.next();
    tutorialCam = camera.position; tutorialYaw = camera.yaw;
    auto runFrames = [&](int n) { for (int i = 0; i < n; ++i) update(1.0f / 30.0f); };
    camera.position += glm::vec3(8.0f, 0.0f, 0.0f);
    runFrames(45);
    check(tutorial.step == TutorialStep::ShapeGround, "look around: done when the camera has moved");
    tool = Tool::Carve;
    cursorHitValid = world.raycast(camera.position, camera.front(), 300.0f, cursorHit);
    useToolAtCursor(true);
    runFrames(45);
    check(tutorial.step == TutorialStep::PlaceGadget, "shape the ground: done after digging");
    tool = Tool::Select;
    placeObject("gadget coin", doorAt + glm::vec3(2.0f, 0.0f, 0.0f));
    runFrames(45);
    check(tutorial.step == TutorialStep::AddRule, "place a gadget: done after placing a coin");
    runFrames(180);
    check(tutorial.step == TutorialStep::PlayIt, "give it a rule: the coin has one");
    setMode(Mode::Play);
    runFrames(45);
    check(tutorial.step == TutorialStep::BackToEditor, "play it");
    setMode(Mode::Editor);
    runFrames(45);
    check(tutorial.step == TutorialStep::Done && tutorial.active, "back to the editor: you're ready");
    tutorial.next();
    updateTutorial(0.0f);
    check(!tutorial.active && settings.tutorialDone, "...and it is not shown again");

    settings = saved;
    applySettings();
    std::cerr << "[polishtest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
