// Every editor action as a Command, for the command palette (Ctrl+P). Menus and shortcuts
// still work exactly as before; this is the searchable list of the same things.
#include "core/Application.h"
#include "rules/Gadgets.h"
#include <cmath>
#include <string>

namespace px {

namespace {
const char* kToolNames[] = { "Carve", "Build", "Smooth", "Flatten", "Paint", "Stamp", "Bake", "Select" };
static_assert(sizeof(kToolNames) / sizeof(kToolNames[0]) == size_t(Tool::Count), "a name for every tool");
}

void Application::registerCommands() {
    auto add = [this](const char* id, const std::string& title, const char* category, const char* shortcut,
                      std::function<void()> run, std::function<bool()> enabled = nullptr) {
        commands.add({ id, title, category, shortcut, std::move(run), std::move(enabled) });
    };
    const bool editor = true;     // commands are only reachable from the editor
    (void)editor;
    auto inEditor = [this] { return mode == Mode::Editor; };

    // ---- tools
    for (int i = 0; i < int(Tool::Count); ++i) {
        const std::string key = std::to_string(i + 1);
        add(("tool." + std::string(kToolNames[i])).c_str(), std::string("Tool: ") + kToolNames[i], "Tools", key.c_str(), [this, i] { tool = Tool(i); });
    }
    add("world.road.start", "World Builder: Pick Road Start", "World Builder", "", [this] { captureRoadStart(); }, inEditor);
    add("world.road.finish", "World Builder: Build Road to Crosshair", "World Builder", "", [this] { finishRoad(); }, [this] { return mode == Mode::Editor && roadStartSelected; });
    add("world.road.cancel", "World Builder: Cancel Road", "World Builder", "", [this] { roadStartSelected = false; });
    add("brush.bigger",  "Brush: Bigger",  "Tools", "]", [this] { brushRadius = std::min(12.0f, brushRadius + 1.0f); });
    add("brush.smaller", "Brush: Smaller", "Tools", "[", [this] { brushRadius = std::max(1.0f, brushRadius - 1.0f); });

    // ---- file / edit
    add("file.save",       "File: Save World",            "File", "Ctrl+S", [this] { cmdSave(); });
    add("file.load",       "File: Load World",            "File", "Ctrl+O", [this] { cmdLoad(); });
    add("file.wizard", "File: New Project / World Wizard", "File", "", [this] { openNewProjectWizard(); });
    add("file.new",        "File: New World",             "File", "",       [this] { cmdNewBlankCanvas(); });
    add("file.blank",      "World Builder: New Blank Canvas", "World Builder", "", [this] { cmdNewBlankCanvas(); });
    add("file.generate",   "World Builder: New Generated Terrain (Advanced)", "World Builder", "", [this] { cmdNewWorld(); });
    add("file.autosave",   "File: Open Latest Autosave",  "File", "",       [this] { const auto l = autosave.list(); if (!l.empty()) cmdOpenAutosave(l.front().path); },
        [this] { return !autosave.list().empty(); });
    add("file.screenshot", "File: Take Screenshot",       "File", "F12",    [this] { cmdScreenshot(); });
    add("file.settings",   "File: Settings",              "File", "",       [this] { openSettings = true; });
    add("file.hub",        "File: Back to Project Hub",   "File", "",       [this] { requestCloseGame(); });
    add("file.quit",       "File: Quit Spire Engine",        "File", "",       [this] { cmdQuit(); });
    add("edit.undo",       "Edit: Undo",                  "Edit", "Ctrl+Z", [this] { cmdUndo(); }, [this] { return canUndo(); });
    add("edit.redo",       "Edit: Redo",                  "Edit", "Ctrl+Y", [this] { cmdRedo(); }, [this] { return canRedo(); });

    // ---- objects
    auto hasSelection = [this] { return !selection.empty(); };
    add("obj.gizmo.move",   "Objects: Move Handles",   "Objects", "W", [this] { cmdSetGizmoMode(GizmoMode::Move); });
    add("obj.gizmo.rotate", "Objects: Turn Handles",   "Objects", "E", [this] { cmdSetGizmoMode(GizmoMode::Rotate); });
    add("obj.gizmo.scale",  "Objects: Size Handle",    "Objects", "R", [this] { cmdSetGizmoMode(GizmoMode::Scale); });
    add("obj.space",        "Objects: Handles World / Local", "Objects", "X", [this] { gizmoSpace = gizmoSpace == GizmoSpace::World ? GizmoSpace::Local : GizmoSpace::World; });
    add("obj.snap",         "Objects: Toggle Snapping", "Objects", "", [this] { gizmoSnap.on = !gizmoSnap.on; });
    add("obj.delete",       "Objects: Delete Selected",  "Objects", "Del",    [this] { cmdDeleteSelection(); }, hasSelection);
    add("obj.duplicate",    "Objects: Duplicate Selected", "Objects", "Ctrl+D", [this] { cmdDuplicateSelection(); }, hasSelection);
    add("obj.group",        "Objects: Group Selected",   "Objects", "Ctrl+G", [this] { cmdGroupSelection(); }, hasSelection);
    add("obj.ungroup",      "Objects: Ungroup Selected", "Objects", "Ctrl+Shift+G", [this] { cmdUngroupSelection(); }, hasSelection);
    add("obj.focus",        "Objects: Focus Camera on Selected", "Objects", "F", [this] { cmdFocusSelection(); }, hasSelection);
    add("obj.drop",         "Objects: Drop Selected to the Ground", "Objects", "", [this] { cmdDropToGround(); }, hasSelection);
    add("obj.selectall",    "Objects: Select All", "Objects", "Ctrl+A", [this] { cmdSelectAll(); tool = Tool::Select; }, [this] { return !scene.empty(); });
    add("obj.motion",       "Objects: Preview Motion On / Off", "Objects", "", [this] { previewMotion = !previewMotion; });
    add("obj.cancelplace",  "Objects: Stop Placing", "Objects", "Esc", [this] { stopPlacing(); }, [this] { return !placingAsset.empty(); });

    // ---- the Asset Workshop
    add("ws.new",  "Workshop: New Asset...", "Workshop", "Ctrl+Shift+W", [this] { enterWorkshopNew(); }, inEditor);
    add("ws.edit", "Workshop: Edit the Selected Object's Asset", "Workshop", "", [this] {
        if (const SceneObject* o = scene.find(primaryObject())) editAssetInWorkshop(o->asset);
    }, [this] { const SceneObject* o = scene.find(primaryObject()); return mode == Mode::Editor && o && !o->isGroup() && assets.get(o->asset); });

    add("game.play",       "Play: Start Playing From Here", "Play", "Tab",  [this] { setMode(Mode::Play); }, inEditor);

    // ---- the four modes and the quick wheel
    add("mode.shape",  "Mode: Shape (the ground)",          "Modes", "", [this] { setEditMode(EditMode::Shape); }, inEditor);
    add("mode.build",  "Mode: Build (objects and buildings)", "Modes", "", [this] { setEditMode(EditMode::Build); }, inEditor);
    add("mode.people", "Mode: People",                      "Modes", "", [this] { setEditMode(EditMode::People); }, inEditor);
    add("mode.logic",  "Mode: Logic (gadgets, rules, goals)", "Modes", "", [this] { setEditMode(EditMode::Logic); }, inEditor);

    // ---- view and panels
    add("view.hideui",   "View: Hide All UI",              "View", "H",  [this] { uiHidden = true; });
    add("view.hints",    "View: All Shortcuts",    "View", "F1", [this] { showShortcutList = !showShortcutList; });
    add("view.wire",     "View: Toggle Wireframe",         "View", "",   [this] { renderSettings.wireframe = !renderSettings.wireframe; });
    add("view.shadows",  "View: Toggle Shadows",           "View", "",   [this] { renderSettings.shadows = !renderSettings.shadows; });
    add("view.bloom",    "View: Toggle Bloom",             "View", "",   [this] { renderSettings.bloom = !renderSettings.bloom; });
    add("view.fxaa",     "View: Toggle Anti-aliasing",     "View", "",   [this] { renderSettings.fxaa = !renderSettings.fxaa; });
    add("panel.tools",   "Panel: Show Tool Strip",         "Panels", "", [this] { showToolbar = true; });
    add("panel.tool",    "Panel: Show Details",            "Panels", "", [this] { showProperties = true; forceInspectorTab = 0; });
    add("panel.outliner","Panel: Show Scene",           "Panels", "", [this] { showOutliner = true; });
    add("panel.assets",  "Panel: Show Shelf",              "Panels", "", [this] { showShelf(-1, false); });
    add("panel.kits",    "Panel: Show Kits",               "Panels", "", [this] { showKits = true; });
    add("help.tutorial", "Help: Tutorial", "Help", "", [this] { startTutorial(); });
    add("file.share",    "File: Share Game...", "File", "", [this] { share.open = true; });
    add("game.rules",    "Game: Game Rules...", "Game", "", [this] { showGameRules = true; });
    for (int t = 0; t < int(GameTemplate::Count); ++t)
        commands.add({ std::string("game.template.") + std::to_string(t), std::string("Game: New Game From Template: ") + gameTemplateLabel(GameTemplate(t)), "Game", "",
                       [this, t] { buildGameTemplate(GameTemplate(t)); }, nullptr });
    for (const GadgetPreset& g : gadgetPresets())
        commands.add({ std::string("gadget.") + g.label, std::string("Gadgets: Place a ") + g.label, "Objects", "", [this, asset = std::string(g.asset)] { startPlacing(asset); }, nullptr });
    add("cc.crowd",      "Characters: Make a Crowd...", "Objects", "", [this] { crowd.open = true; });
    add("cc.open",       "Characters: Open the Character Studio...", "Objects", "Ctrl+Shift+C", [this] { openCharacterStudio(); });
    add("cc.edit",       "Characters: Edit the Selected Character",  "Objects", "", [this] { if (const SceneObject* o = scene.find(primaryObject())) openCharacterStudio(o->character); },
        [this] { const SceneObject* o = scene.find(primaryObject()); return o && !o->character.empty(); });
    add("cc.third",      "Play: Third Person (V)",                   "Play", "V", [this] { thirdPerson = !thirdPerson; toast(thirdPerson ? "Play mode starts in third person" : "Play mode starts in first person"); });
    add("bp.open",       "Blueprint: Draw a Building...",   "Objects", "Ctrl+B", [this] { openBlueprintEditor(); });
    add("bp.place",      "Blueprint: Place the Building",   "Objects", "", [this] { bpStartPlacing(); }, [this] { return !bp.plan.empty(); });
    add("bp.edit",       "Blueprint: Edit the Selected Building's Plan", "Objects", "", [this] { editBuildingBlueprint(primaryObject()); }, [this] { return blueprintBuildingOf(primaryObject()) != 0; });
    add("kit.rotate",    "Kits: Rotate the Piece",         "Objects", "R", [this] { kitRotate(); }, [this] { return placingKit(); });
    add("kit.up",        "Kits: Build One Storey Up",      "Objects", "]", [this] { kitLevelStep(1); }, [this] { return placingKit(); });
    add("kit.down",      "Kits: Build One Storey Down",    "Objects", "[", [this] { kitLevelStep(-1); }, [this] { return placingKit(); });
        add("panel.world",   "Panel: Show World",              "Panels", "", [this] { forceInspectorTab = 1; });
    add("panel.env",     "Panel: Show Sky",        "Panels", "", [this] { forceInspectorTab = 2; });
    add("layout.default",  "Layout: Default",              "Layout", "", [this] { applyLayout(Layout::Default); });
    add("layout.stacked",  "Layout: Stacked (everything on the right)", "Layout", "", [this] { applyLayout(Layout::Stacked); });
    add("layout.twosides", "Layout: Two Sides",            "Layout", "", [this] { applyLayout(Layout::TwoSides); });
    add("layout.objects",  "Layout: Objects (Scene and Shelf on the left)", "Layout", "", [this] { applyLayout(Layout::Objects); });
    add("layout.save",     "Layout: Save Current Layout",  "Layout", "", [this] { openSaveLayout = true; });

    // ---- graphics and display
    for (Quality q : { Quality::Low, Quality::Medium, Quality::High, Quality::Ultra })
        add((std::string("gfx.") + qualityName(q)).c_str(), std::string("Graphics: Quality ") + qualityName(q), "Graphics", "", [this, q] { setQuality(q); },
            [this, q] { return quality() != q; });
    add("gfx.settings",   "Graphics: Open Graphics Settings", "Graphics", "", [this] { openSettingsTab(1); });
    add("display.full",   "Display: Toggle Fullscreen",       "Display", "F11", [this] { toggleFullscreen(); });
    add("display.vsync",  "Display: Toggle V-Sync",           "Display", "",    [this] { settings.vsync = !settings.vsync; applyDisplay(); });
    add("display.fps",    "Display: Cycle Frame Rate Limit",  "Display", "",    [this] { cycleFpsCap(); });
    add("display.uibig",  "Display: Interface Bigger",        "Display", "Ctrl+=", [this] { nudgeUiScale(0.05f); });
    add("display.uismall","Display: Interface Smaller",       "Display", "Ctrl+-", [this] { nudgeUiScale(-0.05f); });
    add("display.uireset","Display: Interface Normal Size",   "Display", "Ctrl+0", [this] { nudgeUiScale(0.0f); });
    add("display.settings","Display: Open Display Settings",  "Display", "",    [this] { openSettingsTab(2); });

    // ---- time, world, sound
    const struct { const char* id; const char* name; float t; } times[] = {
        { "time.dawn", "Dawn", 6.3f }, { "time.noon", "Noon", 12.0f }, { "time.sunset", "Sunset", 17.7f }, { "time.night", "Night", 22.5f } };
    for (const auto& t : times) {
        const float hour = t.t;
        add(t.id, std::string("Time: ") + t.name, "Environment", "", [this, hour] { timeOfDay = hour; });
    }
    add("time.flow", "Time: Pause / Resume the Day", "Environment", "", [this] { timeFlowing = !timeFlowing; });
    add("world.sea", "World: Toggle Sea", "World", "", [this] {
        if (world.isPlanetaryPrototype()) {
            toast("Sea toggle is only available for flat worlds", Toast::Kind::Warning);
            return;
        }
        pendingTerrain.water = !pendingTerrain.water;
        world.setSettings(pendingTerrain);
    });
    add("audio.mute", "Audio: Mute / Unmute", "Audio", "", [this] { settings.muteAudio = !settings.muteAudio; });
    add("audio.ambience", "Audio: Ambience in the Editor On / Off", "Audio", "", [this] { settings.ambienceInEditor = !settings.ambienceInEditor; });

    // ---- camera
    for (int i = 0; i < EditorState::kBookmarks; ++i) {
        const std::string n = std::to_string(i + 1);
        add(("cam.go" + n).c_str(),   "Camera: Go to Bookmark " + n,   "Camera", ("Ctrl+" + n).c_str(),
            [this, i] { gotoBookmark(i); }, [this, i] { return bookmarks[size_t(i)].used; });
    }
    add("cam.save", "Camera: Save Bookmark Here (next free slot)", "Camera", "Ctrl+Shift+1..9", [this] {
        int slot = EditorState::kBookmarks - 1;
        for (int i = 0; i < EditorState::kBookmarks; ++i) if (!bookmarks[size_t(i)].used) { slot = i; break; }
        saveBookmark(slot);
    });
    add("cam.reset", "Camera: Back to the Start View", "Camera", "", [this] {
        flyTo.start(camera, glm::vec3(0.0f, world.terrain().surfaceHeight(0, 0) + 25.0f, 30.0f), -90.0f, -20.0f);
    });
}

} // namespace px
