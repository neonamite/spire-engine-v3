#include "editor/Gizmo.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <imgui.h>

namespace px {

namespace {
constexpr float kPi = 3.14159265358979f;

// axis colours: ui::axisColour (they change with colour-blind friendly colours)
const ImU32 kLit = IM_COL32(255, 222, 90, 255);

float segDist(const glm::vec2& p, const glm::vec2& a, const glm::vec2& b) {
    const glm::vec2 ab = b - a;
    const float l2 = glm::dot(ab, ab);
    const float t = l2 > 1e-6f ? std::clamp(glm::dot(p - a, ab) / l2, 0.0f, 1.0f) : 0.0f;
    return glm::length(p - (a + ab * t));
}

bool inQuad(const glm::vec2& p, const glm::vec2 q[4]) {
    float sign = 0.0f;
    for (int i = 0; i < 4; ++i) {
        const glm::vec2 e = q[(i + 1) % 4] - q[i], d = p - q[i];
        const float c = e.x * d.y - e.y * d.x;
        if (std::fabs(c) < 1e-6f) continue;
        if (sign == 0.0f) sign = c; else if ((c > 0.0f) != (sign > 0.0f)) return false;
    }
    return true;
}

// Where along the line (pivot + t * axis) is the point nearest to the ray? false if they are parallel.
bool axisParam(const glm::vec3& pivot, const glm::vec3& axis, const glm::vec3& o, const glm::vec3& d, float& t) {
    const glm::vec3 w = pivot - o;
    const float b = glm::dot(axis, d), aw = glm::dot(axis, w), dw = glm::dot(d, w);
    const float den = 1.0f - b * b;
    if (den < 1e-4f) return false;
    t = (b * dw - aw) / den;
    return true;
}

bool planeHit(const glm::vec3& point, const glm::vec3& n, const glm::vec3& o, const glm::vec3& d, glm::vec3& out) {
    const float dn = glm::dot(d, n);
    if (std::fabs(dn) < 1e-4f) return false;
    const float t = glm::dot(point - o, n) / dn;
    if (t <= 0.0f) return false;
    out = o + d * t;
    return true;
}

float wrapPi(float a) {
    while (a > kPi) a -= 2.0f * kPi;
    while (a < -kPi) a += 2.0f * kPi;
    return a;
}

float roundTo(float v, float step) { return step > 1e-6f ? std::round(v / step) * step : v; }

// Basis (u, v) of the plane a handle rotates in, such that u x v = the axis.
void ringBasis(const glm::mat3& axes, int i, glm::vec3& u, glm::vec3& v) { u = axes[(i + 1) % 3]; v = axes[(i + 2) % 3]; }
} // namespace

void GizmoView::update() {
    viewProj = camera ? camera->projection(w / std::max(h, 1.0f)) * camera->view() : glm::mat4(1.0f);
}

bool GizmoView::project(const glm::vec3& world, glm::vec2& out) const {
    const glm::vec4 c = viewProj * glm::vec4(world, 1.0f);
    if (c.w <= 0.02f) return false;
    out = glm::vec2(x + (c.x / c.w * 0.5f + 0.5f) * w, y + (1.0f - (c.y / c.w * 0.5f + 0.5f)) * h);
    return true;
}

void GizmoView::ray(const glm::vec2& mouse, glm::vec3& origin, glm::vec3& dir) const {
    origin = camera->position;
    dir = camera->rayThroughPixel(mouse.x - x, mouse.y - y, w, h);
}

float Gizmo::handleLength(const GizmoView& v) const {
    if (!v.camera) return 1.0f;
    const float depth = std::max(0.5f, glm::dot(pivot - v.camera->position, v.camera->front()));
    return depth * std::tan(glm::radians(v.camera->fovDegrees) * 0.5f) * 2.0f * 0.17f;
}

int Gizmo::pick(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse) const {
    glm::vec2 c;
    if (!v.camera || !v.project(pivot, c)) return kNone;
    const float len = handleLength(v), tol = 9.0f * v.uiScale;

    if (glm::length(mouse - c) <= 10.0f * v.uiScale && mode != GizmoMode::Rotate) return kCentre;

    if (mode == GizmoMode::Rotate) {
        int best = kNone; float bestD = tol;
        const glm::vec3 toCam = glm::normalize(v.camera->position - pivot);
        for (int i = 0; i < 3; ++i) {
            glm::vec3 u, w; ringBasis(axes, i, u, w);
            glm::vec2 prev(0.0f); bool havePrev = false;
            for (int k = 0; k <= 64; ++k) {
                const float a = float(k) / 64.0f * 2.0f * kPi;
                const glm::vec3 dir = u * std::cos(a) + w * std::sin(a);
                glm::vec2 s(0.0f);
                const bool ok = glm::dot(dir, toCam) > -0.05f && v.project(pivot + dir * len * 0.95f, s);
                if (ok && havePrev) { const float d = segDist(mouse, prev, s); if (d < bestD) { bestD = d; best = i; } }
                prev = s; havePrev = ok;
            }
        }
        return best;
    }

    int best = kNone; float bestD = tol;
    for (int i = 0; i < 3; ++i) {
        glm::vec2 a, b;
        if (!v.project(pivot + axes[i] * len * 0.15f, a) || !v.project(pivot + axes[i] * len, b)) continue;
        const float d = segDist(mouse, a, b);
        if (d < bestD) { bestD = d; best = i; }
    }
    if (best != kNone) return best;
    if (mode == GizmoMode::Move) {
        for (int i = 0; i < 3; ++i) {                                   // the squares between two arrows
            const glm::vec3 u = axes[(i + 1) % 3], w = axes[(i + 2) % 3];
            glm::vec2 q[4]; bool ok = true;
            const glm::vec3 corners[4] = { pivot + (u * 0.25f + w * 0.25f) * len, pivot + (u * 0.5f + w * 0.25f) * len,
                                           pivot + (u * 0.5f + w * 0.5f) * len, pivot + (u * 0.25f + w * 0.5f) * len };
            for (int k = 0; k < 4; ++k) ok = ok && v.project(corners[k], q[k]);
            if (ok && inQuad(mouse, q)) return 3 + i;
        }
    }
    return kNone;
}

bool Gizmo::begin(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse, int h) {
    if (!v.camera || h == kNone) return false;
    glm::vec3 o, d;
    v.ray(mouse, o, d);
    handle = h; mouse0 = mouse; len0 = handleLength(v); accum = 0.0f;

    if (mode == GizmoMode::Rotate) {
        if (h > 2) return false;
        planeNormal = axes[h];
        glm::vec3 hit;
        if (!planeHit(pivot, planeNormal, o, d, hit)) return false;
        glm::vec3 u, w; ringBasis(axes, h, u, w);
        const glm::vec3 r = hit - pivot;
        lastRaw = std::atan2(glm::dot(r, w), glm::dot(r, u));
        active = true;
        return true;
    }
    if (h <= 2) {
        if (!axisParam(pivot, axes[h], o, d, t0)) return false;
        active = true;
        return true;
    }
    if (mode == GizmoMode::Scale) { active = true; return true; }       // the centre: driven by mouse movement
    planeNormal = h == kCentre ? v.camera->front() : axes[h - 3];
    if (!planeHit(pivot, planeNormal, o, d, p0)) return false;
    active = true;
    return true;
}

Gizmo::Delta Gizmo::drag(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse, const GizmoSnap& snap) {
    Delta out;
    if (!active || !v.camera) return out;
    glm::vec3 o, d;
    v.ray(mouse, o, d);

    if (mode == GizmoMode::Rotate) {
        out.axis = planeNormal;
        glm::vec3 hit;
        if (planeHit(pivot, planeNormal, o, d, hit)) {
            glm::vec3 u, w; ringBasis(axes, handle, u, w);
            const glm::vec3 r = hit - pivot;
            const float raw = std::atan2(glm::dot(r, w), glm::dot(r, u));
            accum += wrapPi(raw - lastRaw);
            lastRaw = raw;
        }
        out.angle = snap.on ? glm::radians(roundTo(glm::degrees(accum), snap.rotate)) : accum;
        return out;
    }

    if (mode == GizmoMode::Scale) {
        if (handle == kCentre) {
            out.scale = std::exp(((mouse.x - mouse0.x) - (mouse.y - mouse0.y)) / (220.0f * v.uiScale));
        } else {
            float t;
            if (axisParam(pivot, axes[handle], o, d, t)) out.scale = 1.0f + (t - t0) / std::max(len0, 1e-3f);
        }
        out.scale = std::max(0.05f, out.scale);
        if (snap.on) out.scale = std::max(snap.scale, roundTo(out.scale, snap.scale));
        return out;
    }

    // Move
    if (handle <= 2) {
        float t;
        if (!axisParam(pivot, axes[handle], o, d, t)) return out;
        float dist = t - t0;
        if (snap.on) dist = roundTo(dist, snap.move);
        out.translate = axes[handle] * dist;
        return out;
    }
    glm::vec3 hit;
    if (!planeHit(pivot, planeNormal, o, d, hit)) return out;
    glm::vec3 delta = hit - p0;
    if (snap.on) {
        if (handle == kCentre) delta = glm::vec3(roundTo(delta.x, snap.move), roundTo(delta.y, snap.move), roundTo(delta.z, snap.move));
        else {
            const glm::vec3 u = axes[(handle - 3 + 1) % 3], w = axes[(handle - 3 + 2) % 3];
            delta = u * roundTo(glm::dot(delta, u), snap.move) + w * roundTo(glm::dot(delta, w), snap.move);
        }
    }
    out.translate = delta;
    return out;
}

void Gizmo::draw(ImDrawList* dl, const GizmoView& v, GizmoMode mode, int hover) const {
    glm::vec2 c;
    if (!v.camera || !v.project(pivot, c)) return;
    const float len = handleLength(v), s = v.uiScale;
    const int lit = active ? handle : hover;
    auto iv = [](const glm::vec2& p) { return ImVec2(p.x, p.y); };
    auto colorOf = [&](int i, int alpha = 255) {
        ImU32 col = lit == i ? kLit : ui::axisColour(i % 3);
        return (col & 0x00FFFFFFu) | (ImU32(alpha) << 24);
    };

    if (mode == GizmoMode::Rotate) {
        const glm::vec3 toCam = glm::normalize(v.camera->position - pivot);
        for (int i = 0; i < 3; ++i) {
            glm::vec3 u, w; ringBasis(axes, i, u, w);
            glm::vec2 prev(0.0f); bool havePrev = false; bool prevFront = false;
            for (int k = 0; k <= 64; ++k) {
                const float a = float(k) / 64.0f * 2.0f * kPi;
                const glm::vec3 dir = u * std::cos(a) + w * std::sin(a);
                glm::vec2 sp(0.0f);
                const bool ok = v.project(pivot + dir * len * 0.95f, sp);
                const bool front = glm::dot(dir, toCam) > -0.05f;
                if (ok && havePrev)
                    dl->AddLine(iv(prev), iv(sp), colorOf(i, (front && prevFront) ? 255 : 70), (lit == i ? 4.0f : 2.5f) * s);
                prev = sp; havePrev = ok; prevFront = front;
            }
        }
        dl->AddCircleFilled(iv(c), 3.0f * s, IM_COL32(255, 255, 255, 200));
        return;
    }

    if (mode == GizmoMode::Move) {
        for (int i = 0; i < 3; ++i) {                                   // squares first, arrows over them
            const glm::vec3 u = axes[(i + 1) % 3], w = axes[(i + 2) % 3];
            const glm::vec3 corners[4] = { pivot + (u * 0.25f + w * 0.25f) * len, pivot + (u * 0.5f + w * 0.25f) * len,
                                           pivot + (u * 0.5f + w * 0.5f) * len, pivot + (u * 0.25f + w * 0.5f) * len };
            glm::vec2 q[4]; bool ok = true;
            for (int k = 0; k < 4; ++k) ok = ok && v.project(corners[k], q[k]);
            if (!ok) continue;
            const ImU32 base = lit == 3 + i ? kLit : ui::axisColour(i);
            dl->AddQuadFilled(iv(q[0]), iv(q[1]), iv(q[2]), iv(q[3]), (base & 0x00FFFFFFu) | (lit == 3 + i ? 150u << 24 : 70u << 24));
            dl->AddQuad(iv(q[0]), iv(q[1]), iv(q[2]), iv(q[3]), (base & 0x00FFFFFFu) | (200u << 24), 1.5f * s);
        }
    }

    for (int i = 0; i < 3; ++i) {
        glm::vec2 a, b, shaft;
        if (!v.project(pivot + axes[i] * len * 0.1f, a) || !v.project(pivot + axes[i] * len, b) || !v.project(pivot + axes[i] * len * 0.82f, shaft)) continue;
        const ImU32 col = colorOf(i);
        dl->AddLine(iv(a), mode == GizmoMode::Move ? iv(shaft) : iv(b), col, (lit == i ? 4.0f : 3.0f) * s);
        if (mode == GizmoMode::Move) {
            const glm::vec2 dir = glm::normalize(b - shaft + glm::vec2(1e-4f, 0.0f));
            const glm::vec2 perp(-dir.y, dir.x);
            dl->AddTriangleFilled(iv(b + dir * 2.0f * s), iv(shaft + perp * 6.0f * s), iv(shaft - perp * 6.0f * s), col);
        } else {
            const float r = 5.5f * s;
            dl->AddRectFilled(ImVec2(b.x - r, b.y - r), ImVec2(b.x + r, b.y + r), col, 1.5f * s);
        }
    }
    const float r = (mode == GizmoMode::Scale ? 6.5f : 5.0f) * s;
    const ImU32 cc = lit == kCentre ? kLit : IM_COL32(240, 242, 248, 235);
    if (mode == GizmoMode::Scale) dl->AddRectFilled(ImVec2(c.x - r, c.y - r), ImVec2(c.x + r, c.y + r), cc, 1.5f * s);
    else dl->AddCircle(iv(c), r, cc, 16, 2.0f * s);
}

} // namespace px
