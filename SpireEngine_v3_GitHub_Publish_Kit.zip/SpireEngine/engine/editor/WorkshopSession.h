#pragma once
// Everything the Asset Workshop screen remembers while it is open: the model being built, the
// orbit camera, the current tool and its settings, and the state of its dialogs. The behaviour
// lives in editor/WorkshopUI.cpp (Application::enterWorkshop and friends).
#include <cstdint>
#include <string>
#include <glm/glm.hpp>
#include <memory>
#include "core/Camera.h"
#include "items/Item.h"
#include "scene/Asset.h"
#include "workshop/Workshop.h"

namespace px {

class ItemRange;

enum class WTool : std::uint8_t { Add, Carve, Paint, Smooth, Socket, Count };

struct WorkshopSession {
    bool active = false;
    Workshop model;

    // ---- where it came from
    std::string originalName;                 // the asset this was opened from ("" for a new one)
    std::string sourceAsset;                  // the built-in asset a copy was made from (to find its item stats)
    bool        copyOfBuiltin = false;        // opened from a built-in asset: saving makes your own version

    // ---- what the world editor looked like, restored when the Workshop closes
    Camera      savedCamera;
    float       savedTime = 10.0f;
    bool        savedTimeFlowing = true;
    bool        savedWireframe = false, savedShadows = true;
    float       savedShadowRange = 90.0f;
    int         savedTool = 0;
    bool        savedUiHidden = false;

    // ---- orbit camera
    glm::vec3   target{ 0.0f, 1.0f, 0.0f };
    float       distance = 6.0f;

    // ---- tools
    WTool       tool = WTool::Add;
    Shape       shape = Shape::Box;
    glm::vec3   size{ 0.5f };                 // the stamp's full size along its own axes, metres
    bool        linkSize = true;
    float       round = 0.0f, blend = 0.0f, yaw = 0.0f;
    MaterialId  material = MAT_STONE;
    bool        paintFill = false;            // Paint: recolour a whole connected patch instead of a brush
    Mirror      mirror;
    bool        snap = false;
    int         snapVoxels = 4;
    float       smoothRadius = 0.4f, smoothStrength = 0.5f;
    std::string selectedSocket;

    // ---- view
    bool        showGrid = true, showBounds = true, showFigure = false, wireframe = false;
    float       lightTime = 10.5f;

    // ---- the pointer
    WorkshopHit hover;
    bool        hoverValid = false;
    glm::vec3   hoverCentre{ 0.0f };          // where the stamp would land
    bool        orbiting = false, panning = false;
    bool        stroking = false;             // left button held on the model
    glm::vec3   lastCentre{ 0.0f };
    glm::vec3   planePoint{ 0.0f }, planeNormal{ 0, 1, 0 };   // Add strokes slide over the surface they started on
    float       smoothTimer = 0.0f;
    bool        draggingSocket = false;
    glm::vec3   socketDragPos{ 0.0f }, socketDragDir{ 0, 1, 0 };

    // ---- dialogs
    bool        askNew = false, askLeave = false;
    NewAssetSpec spec;
    char        nameBuf[96] = {};
    char        tagBuf[160] = {};
    std::string afterLeave;                   // what to do once unsaved work is dealt with: "close", "place", "new" or "quit"

    // ---- the item this asset is, when its type is Item (editor/WorkshopItems.cpp)
    ItemDef     item;                         // behaviour, stats, effect, feel and hold pose: saved as a .pxitem beside the asset
    bool        itemLoaded = false;           // `item` has been filled in for the asset being edited
    bool        itemEdited = false;           // changed since the last save
    int         panelTab = 0;                 // 0 = Model, 1 = Item
    bool        rangeOn = false;              // the firing range is showing instead of the orbit view
    bool        rangeCaptured = false;        // the mouse is looking round inside the range
    std::shared_ptr<ItemRange> range;
    float       orbitYaw = -62.0f, orbitPitch = -20.0f;     // the building view to come back to
    int         itemSection = 0;              // which Item panel group is open (0 = all)

    // ---- scenery drawn around the model
    AssetPtr    floor, figure;
};

} // namespace px
