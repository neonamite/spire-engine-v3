// --demo kit_...: screenshots of the building kits (v0.16), and a self test that drives the real placement code
// (the same functions the mouse and keyboard reach) and prints "[kittest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "editor/Panels.h"
#include "workshop/KitPieces.h"
#include <cmath>
#include <iostream>
#include <string>

namespace px {

namespace {

// Builds a little house with the same snapping the player's clicks use. The footprint is w x d cells starting at cell (i0, j0);
// the front (door side) is at the largest z, so a camera looking towards -Z sees it. A two-wide house gets a gable roof with the
// ridge along z. With `stairs`, a flight climbs along the left column and the floor above is left open over it.
struct HouseSpec {
    std::string style = "Brick house";
    int i0 = 0, j0 = 0, w = 2, d = 3, storeys = 1;
    float plane = 0.0f;
    bool roof = true, stairs = false, doorFront = true;
};

int buildHouse(Application& a, const HouseSpec& h) {
    int placed = 0;
    a.kits.update(a.assets);
    a.kitGroup = 0;
    auto put = [&](KitRole role, float plane, float ax, float az, int turns) {
        const std::string name = a.kits.piece(h.style, role);
        if (name.empty()) return;
        const KitSpot s = kitSnap(role, glm::vec3(ax, plane, az), plane, turns);
        if (a.kitPlaceAt(name, role, s)) ++placed;
    };
    const float cell = kKitCell;
    for (int level = 0; level < h.storeys; ++level) {
        const float plane = h.plane + float(level) * kKitStorey;
        for (int i = 0; i < h.w; ++i)
            for (int j = 0; j < h.d; ++j) {
                const bool hole = h.stairs && i == 0 && j < 2 && level > 0;                    // the stairwell
                if (!hole) put(KitRole::Floor, plane, (float(h.i0 + i) + 0.5f) * cell, (float(h.j0 + j) + 0.5f) * cell, 0);
            }
        if (h.stairs && level + 1 < h.storeys) put(KitRole::Stairs, plane, (float(h.i0) + 0.5f) * cell, float(h.j0 + 2) * cell, 3);
        // walls along x (the long edges at the back and front) and along z (the sides)
        for (int i = 0; i < h.w; ++i)
            for (int e = 0; e <= h.d; e += h.d) {
                const bool front = e == h.d;
                KitRole role = KitRole::Window;
                if (front && level == 0 && h.doorFront && i == h.w - 1) role = KitRole::Doorway;
                else if (front && level == 0 && h.doorFront) role = KitRole::Window;
                else if (!front) role = (i % 2 == 0) ? KitRole::Window : KitRole::Wall;
                put(role, plane, (float(h.i0 + i) + 0.5f) * cell, float(h.j0 + e) * cell, front ? 0 : 1);
            }
        for (int j = 0; j < h.d; ++j)
            for (int e = 0; e <= h.w; e += h.w)
                put((j % 2 == 1) ? KitRole::Window : KitRole::Wall, plane, float(h.i0 + e) * cell, (float(h.j0 + j) + 0.5f) * cell, 0);
    }
    if (h.roof) {
        const float plane = h.plane + float(h.storeys) * kKitStorey;
        for (int i = 0; i < h.w; ++i)
            for (int j = 0; j < h.d; ++j) put(KitRole::Roof, plane, (float(h.i0 + i) + 0.5f) * cell, (float(h.j0 + j) + 0.5f) * cell, i < h.w / 2 ? 0 : 2);
    }
    return placed;
}

// The ground level for a house at the given cell: the highest ground under its footprint, rounded up a little so nothing sinks.
float groundFor(const ChunkManager& world, int i0, int j0, int w, int d) {
    float y = -1e9f;
    for (int i = 0; i <= w; ++i)
        for (int j = 0; j <= d; ++j) y = std::max(y, demospot::groundHeight(world, float(i0 + i) * kKitCell, float(j0 + j) * kKitCell));
    return std::round(y * 4.0f) / 4.0f;
}

// Flattens a square so a house can stand on it whatever the generator made there.
void levelSquare(ChunkManager& world, float x0, float z0, float x1, float z1, float y) {
    const glm::vec3 c((x0 + x1) * 0.5f, y + 0.1f, (z0 + z1) * 0.5f);      // the ground ends up a hand's width above the slab's underside
    const float r = std::max(x1 - x0, z1 - z0) * 0.75f;
    world.flatten(c, r);
}

// Points a camera from one place at another (yaw/pitch in the engine's convention: yaw 0 looks along +x, 90 along +z).
template <class Cam>
void aimCamera(Cam& cam, const glm::vec3& from, const glm::vec3& at) {
    const glm::vec3 d = at - from;
    cam.position = from;
    cam.yaw = glm::degrees(std::atan2(d.z, d.x));
    cam.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
}

} // namespace

void Application::setupKitDemo() {
    if (demo == "kit_selftest") { runKitSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    const glm::vec3 spot = demospot::calmSpot(world);
    const float gx = std::round(spot.x / kKitCell) * kKitCell, gz = std::round(spot.z / kKitCell) * kKitCell;
    timeOfDay = 11.0f; timeFlowing = false;

    if (demo == "kit_styles") {
        // One small house in each of the five styles, side by side.
        const int n = int(builtinKitStyles().size());
        const int i0 = int(gx / kKitCell) - n * 3;                      // 2-wide houses with 1-cell gaps, centred on the spot
        const int j0 = int(gz / kKitCell) - 8;
        float ground = -1e9f;
        for (int k = 0; k < n; ++k) ground = std::max(ground, groundFor(world, i0 + k * 3, j0, 2, 2));
        levelSquare(world, float(i0) * kKitCell - 6.0f, float(j0) * kKitCell - 6.0f, float(i0 + n * 3) * kKitCell + 6.0f, float(j0 + 2) * kKitCell + 6.0f, ground);
        for (int k = 0; k < n; ++k) {
            HouseSpec h;
            h.style = builtinKitStyles()[size_t(k)].name;
            h.i0 = i0 + k * 3; h.j0 = j0; h.w = 2; h.d = 2; h.storeys = 1; h.plane = ground;
            buildHouse(*this, h);
        }
        commitScene("Build five houses");
        const float midX = (float(i0) + float(n) * 1.5f - 0.5f) * kKitCell, midZ = float(j0 + 1) * kKitCell;
        aimCamera(camera, glm::vec3(midX + 2.0f, ground + 2.4f, midZ + 16.5f), glm::vec3(midX, ground + 1.7f, midZ));
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "kit_house" || demo == "kit_inside" || demo == "kit_dollhouse") {
        const int i0 = int(gx / kKitCell) - 1, j0 = int(gz / kKitCell) - 6;
        const float ground = groundFor(world, i0, j0, 2, 3);
        levelSquare(world, float(i0) * kKitCell - 5.0f, float(j0) * kKitCell - 5.0f, float(i0 + 2) * kKitCell + 5.0f, float(j0 + 3) * kKitCell + 5.0f, ground);
        HouseSpec h;
        h.style = "Brick house"; h.i0 = i0; h.j0 = j0; h.w = 2; h.d = 3; h.storeys = 2; h.plane = ground; h.stairs = true;
        buildHouse(*this, h);
        commitScene("Build a house");
        const glm::vec3 centre((float(i0) + 1.0f) * kKitCell, ground, (float(j0) + 1.5f) * kKitCell);
        if (demo == "kit_house") {
            aimCamera(camera, centre + glm::vec3(7.5f, 2.6f, 12.5f), centre + glm::vec3(0.0f, 2.2f, 0.0f));
        } else if (demo == "kit_dollhouse") {            // from above, with the roof left off, to see the rooms and the stairs
            for (const SceneObject& o : scene.objects()) if (!o.isGroup() && kitRoleOfAsset(o.asset) == KitRole::Roof) scene.mutate(o.id)->visible = false;
            aimCamera(camera, centre + glm::vec3(1.8f, 9.0f, 3.6f), centre + glm::vec3(0.0f, 1.6f, 0.0f));
        } else {                                         // standing in the ground-floor room, looking at the stairs
            const float backZ = float(j0) * kKitCell + 0.7f;
            aimCamera(camera, glm::vec3(centre.x + 0.1f, ground + 1.55f, backZ), glm::vec3(centre.x - 0.5f, ground + 1.15f, backZ + 6.0f));
        }
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "kit_panel" || demo == "kit_build") {
        // The editor with the Kits panel in front, a half-built house, and a doorway being placed: the ghost, the grid, the hint bar.
        const int i0 = int(gx / kKitCell) - 1, j0 = int(gz / kKitCell) - 6;
        const float ground = groundFor(world, i0, j0, 2, 3);
        levelSquare(world, float(i0) * kKitCell - 5.0f, float(j0) * kKitCell - 5.0f, float(i0 + 2) * kKitCell + 5.0f, float(j0 + 3) * kKitCell + 5.0f, ground);
        HouseSpec h;
        h.style = "Brick house"; h.i0 = i0; h.j0 = j0; h.w = 2; h.d = 3; h.storeys = 1; h.plane = ground; h.roof = false; h.doorFront = false;
        buildHouse(*this, h);
        commitScene("Build the walls");
        kitBaseY = ground; kitBaseSet = true; kitLevel = 0;
        kitStyle = "Brick house";
        // a door in the middle of the front wall: aim at the edge between the two front windows
        const float fz = float(j0 + 3) * kKitCell, fx = (float(i0) + 1.0f) * kKitCell;
        aimCamera(camera, glm::vec3(fx + 4.5f, ground + 4.2f, fz + 7.5f), glm::vec3(fx - 0.5f, ground + 0.8f, fz - 1.0f));
        showHints = false;
        startPlacingKit(KitRole::Doorway);
        settleFronts = { "Details", "Kits" }; settleFrames = 5;
        glm::vec2 sp;
        if (gizmoView().project(glm::vec3(fx - 1.0f, ground + 0.5f, fz + 0.1f), sp)) { mouseX = sp.x; mouseY = sp.y; }       // the cursor on the front wall's middle edge
        toasts.clear();
        return;
    }
}

void Application::runKitSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[kittest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto near3 = [](const glm::vec3& a, const glm::vec3& b, float e = 1e-3f) { return glm::length(a - b) <= e; };

    setMode(Mode::Editor);
    tool = Tool::Select;
    uiHidden = false;
    placingAsset.clear(); stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    kitGroup = 0; kitBaseSet = false; kitLevel = 0; kitTurns = 0; kitSnapOn = true; kitStyle = "Brick house";

    // ---- the pieces are there and sorted into kits
    kits.update(assets);
    check(kits.styles().size() >= 5 && kits.styles()[0].name == "Brick house" && kits.styles()[0].pieces() == 7, "five built-in kits of seven pieces are listed");
    check(!assets.isUserMade("Brick house wall") && assets.isGenerated("Brick house wall"), "the built-in pieces are not files: they are made when first used");

    // A flat place to build and a camera looking straight down at it, so the cursor can be put on any spot of the ground.
    const glm::vec3 spot = demospot::calmSpot(world);
    const float ground = std::round(demospot::groundHeight(world, spot.x, spot.z) * 4.0f) / 4.0f;
    const float cx = std::round(spot.x / kKitCell) * kKitCell, cz = std::round(spot.z / kKitCell) * kKitCell;
    world.flatten(glm::vec3(cx, ground, cz), 14.0f);
    undoLog.clear(); redoLog.clear();                                    // levelling the ground is not part of what is tested
    auto cursorOn = [&](const glm::vec3& p) {
        glm::vec2 sp;
        const bool ok = gizmoView().project(p, sp);
        mouseX = sp.x; mouseY = sp.y;
        return ok;
    };
    auto lookDownAt = [&](const glm::vec3& p, float height) {
        camera.position = p + glm::vec3(0.0f, height, 0.0f);
        camera.yaw = -90.0f; camera.pitch = -89.0f;
    };
    auto groundAt = [&](float x, float z) { return glm::vec3(x, demospot::groundHeight(world, x, z), z); };
    auto step = [&](const glm::vec3& at) { lookDownAt(at, 12.0f); updateObjects(0.0f); return cursorOn(at); };
    const size_t objectsBefore = scene.size();

    // ---- start placing a wall and look at the ghost
    startPlacingKit(KitRole::Wall);
    check(placingAsset == "Brick house wall" && placingKit() && placingKitRole() == KitRole::Wall, "picking Wall in the Kits panel starts placing that kit's wall");
    check(step(groundAt(cx + 1.0f, cz + 0.2f)), "the cursor is on the ground");
    updateObjects(0.0f);
    check(ghostValid, "the ghost is shown on the ground");
    check(near3(glm::vec3(ghostPos.x, 0.0f, ghostPos.z), glm::vec3(cx + 1.0f, 0.0f, cz), 1e-3f) && ghostYaw == 0.0f, "...snapped to the middle of the cell edge nearest the cursor");
    check(std::fabs(ghostPos.y - (ground + kKitSlab)) < 0.3f, "...standing on the floor slab of a storey that starts at the ground");
    check(ghostKitState == 0, "...as a new piece");

    // ---- click
    selectToolMouseDown(false);
    objectsMouseUp();
    check(kitBaseSet && std::fabs(kitBaseY - ground) < 0.3f, "the first piece fixes where the ground floor is");
    check(scene.size() == objectsBefore + 2, "one click adds the piece and a Building group to hold it");
    const ObjectId building = kitGroup;
    check(building != 0 && scene.find(building) && scene.find(building)->isGroup() && scene.find(building)->name.rfind("Building", 0) == 0, "the group is called Building");
    ObjectId wallId = 0;
    for (const SceneObject& o : scene.objects()) if (o.asset == "Brick house wall") wallId = o.id;
    check(wallId && scene.find(wallId)->parent == building, "the wall is inside the Building");
    check(wallId && near3(glm::vec3(scene.find(wallId)->position.x, 0.0f, scene.find(wallId)->position.z), glm::vec3(cx + 1.0f, 0.0f, cz)), "it stands on the grid");
    check(undoLog.size() == 1 && scene.undoLabel() == "Place Brick house wall", "the click is one undo step");
    check(selection.empty(), "building does not select what it places");

    // ---- the same piece again: nothing happens
    updateObjects(0.0f);
    step(groundAt(cx + 1.0f, cz + 0.4f));
    check(ghostKitState == 2, "pointing at a piece that is already there shows it faintly");
    selectToolMouseDown(false); objectsMouseUp();
    check(scene.size() == objectsBefore + 2 && undoLog.size() == 1, "clicking there again changes nothing and records nothing");

    // ---- a window in the same slot replaces the wall
    startPlacingKit(KitRole::Window);
    step(groundAt(cx + 1.0f, cz - 0.3f));
    check(ghostKitState == 1, "a window over a wall shows that it will replace it");
    selectToolMouseDown(false); objectsMouseUp();
    check(scene.size() == objectsBefore + 2 && !scene.find(wallId) && undoLog.size() == 2, "...and replaces it: still one piece, one more undo step");
    cmdUndo();
    check(scene.find(wallId) != nullptr && scene.size() == objectsBefore + 2, "undo brings the wall back");
    cmdRedo();

    // ---- turning, and the other roles
    startPlacingKit(KitRole::Wall);
    kitRotate();
    step(groundAt(cx + 1.0f, cz + 0.2f));
    check(ghostYaw == 180.0f, "Rotate flips a wall");
    kitTurns = 0;
    step(groundAt(cx + 0.15f, cz + 1.0f));
    check(ghostYaw == 90.0f && near3(glm::vec3(ghostPos.x, 0.0f, ghostPos.z), glm::vec3(cx, 0.0f, cz + 1.0f)), "near the other grid line a wall runs the other way");
    startPlacingKit(KitRole::Floor);
    step(groundAt(cx + 1.2f, cz + 1.3f));
    check(near3(glm::vec3(ghostPos.x, 0.0f, ghostPos.z), glm::vec3(cx + 1.0f, 0.0f, cz + 1.0f)) && std::fabs(ghostPos.y - kitBaseY) < 1e-3f, "a floor tile fills the cell and sits on the storey's plane");
    kitRotate(); step(groundAt(cx + 1.2f, cz + 1.3f));
    check(ghostYaw == 90.0f, "...and Rotate turns it a quarter");
    kitTurns = 0;
    startPlacingKit(KitRole::Pillar);
    step(groundAt(cx + 1.8f, cz + 0.3f));
    check(near3(glm::vec3(ghostPos.x, 0.0f, ghostPos.z), glm::vec3(cx + 2.0f, 0.0f, cz)), "a pillar goes on the nearest corner");

    // ---- storeys
    startPlacingKit(KitRole::Floor);
    kitLevelStep(1);
    step(groundAt(cx + 1.0f, cz + 1.0f));
    check(std::fabs(ghostPlane - (kitBaseY + kKitStorey)) < 1e-3f && ghostLevel == 1, "one storey up lifts the plane by 2.5 m");
    kitLevelStep(-1);
    kitLevelStep(-1);
    step(groundAt(cx + 1.0f, cz + 1.0f));
    check(ghostLevel == -1 && std::fabs(ghostPlane - (kitBaseY - kKitStorey)) < 1e-3f, "...and down a storey puts it below the ground");
    kitLevel = 0;
    // pointing at the top of a wall builds on the storey above it
    startPlacingKit(KitRole::Wall);
    lookDownAt(glm::vec3(cx + 1.0f, ground + kKitStorey, cz), 12.0f);
    updateObjects(0.0f);
    cursorOn(glm::vec3(cx + 1.0f, ground + kKitStorey, cz));
    updateObjects(0.0f);
    check(ghostValid && std::fabs(ghostPlane - (kitBaseY + kKitStorey)) < 0.02f, "pointing at the top of a wall builds on the storey above it");
    kitLevel = 0;

    // ---- drag a run of walls
    startPlacingKit(KitRole::Wall);
    const size_t beforeRun = scene.size();
    const size_t undoBefore = undoLog.size();
    {
        simulateLeftButton = true;
        step(groundAt(cx + 3.0f, cz + 4.0f + 0.1f));
        selectToolMouseDown(false);                                       // press on the first slot...
        check(kitDragging, "pressing starts a stroke");
        for (int k = 1; k <= 3; ++k) {                                    // ...and drag along the edge, one more cell each time
            step(groundAt(cx + 3.0f + 2.0f * float(k), cz + 4.0f + 0.1f));
            kitDragStep(true);
        }
        simulateLeftButton = false;
        objectsMouseUp();
    }
    check(scene.size() == beforeRun + 4, "dragging over four cells places four walls");
    check(undoLog.size() == undoBefore + 1 && scene.undoLabel() == "Build 4 pieces", "...as one undo step");
    {
        int inRow = 0;
        for (const SceneObject& o : scene.objects())
            if (o.asset == "Brick house wall" && std::fabs(o.position.z - (cz + 4.0f)) < 1e-3f) {
                const float dx = o.position.x - cx;
                for (float want : { 3.0f, 5.0f, 7.0f, 9.0f }) if (std::fabs(dx - want) < 1e-3f) ++inRow;
            }
        check(inRow == 4, "...in a straight row, a wall to a cell, on the grid");
    }
    cmdUndo();
    check(scene.size() == beforeRun, "undoing takes the whole run away at once");
    cmdRedo();

    // ---- taking pieces away
    stopPlacing();
    const size_t beforeErase = scene.size();
    camera.position = glm::vec3(cx + 9.0f, ground + kKitSlab + 1.2f, cz + 10.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    updateObjects(0.0f);
    cursorOn(glm::vec3(cx + 9.0f, ground + kKitSlab + 1.2f, cz + 4.0f));
    const bool removed = kitRemoveUnderCursor();
    if (removed) commitScene("Remove a building piece");
    check(removed && scene.size() == beforeErase - 1 && undoLog.size() == undoBefore + 2, "removing the piece under the cursor takes one piece away");
    cmdUndo();
    check(scene.size() == beforeErase, "...and undo brings it back");
    {   // a crate in the way is not a kit piece: it stays
        const ObjectId crate = placeObject("crate", glm::vec3(cx - 6.0f, ground, cz), 0.0f, 1.0f);
        updateObjects(0.0f);
        camera.position = glm::vec3(cx - 6.0f, ground + 0.5f, cz + 6.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
        updateObjects(0.0f);
        cursorOn(glm::vec3(cx - 6.0f, ground + 0.5f, cz));
        check(!kitRemoveUnderCursor() && scene.find(crate) != nullptr, "removing never takes anything that is not a kit piece");
        scene.remove(crate);
        commitScene("remove crate");
    }
    stopPlacing();

    // ---- changing the look
    {
        std::vector<ObjectId> all = kitBuildingOf(wallId > 0 && scene.find(wallId) ? wallId : kitGroup);
        check(all.size() >= 5, "the whole building can be found from one of its pieces");
        const size_t steps = undoLog.size();
        const int n = restyleObjects(all, "Sci-fi");
        check(n == int(all.size()) && undoLog.size() == steps + 1, "swapping the whole building to Sci-fi changes every piece in one undo step");
        bool allSciFi = true;
        for (ObjectId id : all) if (const SceneObject* o = scene.find(id)) { std::string st; allSciFi = allSciFi && kitRoleOfAsset(o->asset, &st) != KitRole::None && st == "Sci-fi"; }
        check(allSciFi, "...and they are all Sci-fi pieces now");
        check(restyleObjects(all, "Sci-fi") == 0, "swapping to the style it already is changes nothing");
        check(restyleObjects(all, "No such kit") == 0, "...and an unknown kit changes nothing");
        cmdUndo();
        bool allBrick = true;
        for (ObjectId id : all) if (const SceneObject* o = scene.find(id)) { std::string st; kitRoleOfAsset(o->asset, &st); allBrick = allBrick && st == "Brick house"; }
        check(allBrick, "undo gives the old look back");
    }

    // ---- saved with the world, and the pieces come back by name
    {
        const std::string text = scene.toText();
        Scene again;
        check(again.fromText(text) && again.size() == scene.size(), "the building is saved in the scene text");
        again.evaluate(assets, 0.0, false);
        bool resolved = true;
        for (const Evaluated& e : again.evaluated()) if (!e.asset) { resolved = resolved && true; }
        for (const SceneObject& o : again.objects()) if (!o.isGroup()) resolved = resolved && assets.get(o.asset) != nullptr;
        check(resolved, "...and every piece in it can be found again by name");
    }

    // ---- with snapping off, a kit piece is placed like any other asset
    {
        kitSnapOn = false;
        startPlacing("Brick house wall");
        check(!placingKit(), "with snapping off the piece is not placed on the grid");
        step(groundAt(cx - 9.3f, cz + 7.7f));
        const size_t before = scene.size();
        selectToolMouseDown(false);
        check(scene.size() == before + 1, "...a click still places it");
        const SceneObject& o = scene.objects().back();
        check(std::fabs(o.position.x - (cx - 9.3f)) < 0.6f && std::fabs(std::fmod(std::fabs(o.position.x), 2.0f) - 1.0f) > 0.05f, "...where the cursor is, not on a grid line");
        cmdUndo();
        stopPlacing();
        kitSnapOn = true;
    }

    // ---- the Esc key and a stroke that is cut short
    {
        startPlacingKit(KitRole::Floor);
        step(groundAt(cx - 4.0f, cz - 6.0f));
        const size_t before = scene.size();
        selectToolMouseDown(false);
        check(kitDragging, "a stroke is under way");
        stopPlacing();
        check(!kitDragging && placingAsset.empty() && scene.size() == before + 1, "stopping in the middle of a stroke finishes it cleanly");
        cmdUndo();
    }

    std::cerr << "[kittest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
