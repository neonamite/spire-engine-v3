#pragma once
// Pieces shared by the editor's panel code (EditorUI.cpp, ObjectPanels.cpp, WorkshopUI.cpp).
#include <string>
#include <imgui.h>
#include "render/Renderer.h"
#include "world/Materials.h"

namespace px {

class Application;
class ItemSystem;

// A dockable panel. Returns true when its contents should be drawn (then call ImGui::End()).
// `focus` brings its tab to the front, and reopens it if it was closed.
bool beginPanel(const char* title, bool* open, bool focus);

// A small picture of an asset as a GL texture (the Asset Browser's thumbnail, made on first use). 0 if the asset is unknown.
unsigned assetThumbnailTexture(Application& app, const std::string& assetName);

// The crosshair (it opens with the weapon's spread and flashes on a hit) and the item panel (name, ammo, reload bar),
// shared by play mode and the Workshop's firing range. `s` is the UI scale.
void drawItemCrosshair(ImDrawList* dl, const ItemSystem& inv, ImVec2 centre, float viewHeight, float s);
void drawItemPanel(ImDrawList* dl, const ItemSystem& inv, ImVec2 topLeft, float s);

// Frees the GL textures behind the shelf's pictures (call while the GL context is alive).
void releaseAssetThumbnails();
// Forgets the people's portraits on the shelf (someone changed in the Character Studio): they are drawn again when next shown.
void forgetPersonThumbnails();

// A material's texture in a rounded square. Natural shows the four things it can become.
void drawMaterialSwatch(ImDrawList* dl, const Renderer& r, MaterialId id, ImVec2 a, ImVec2 b, float rounding);
// Grid of material swatches; returns true when the selection changed.
bool materialPalette(const Renderer& r, MaterialId& selected, bool allowNatural);

} // namespace px
