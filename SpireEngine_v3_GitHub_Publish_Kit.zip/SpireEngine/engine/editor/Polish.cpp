// Polish (v0.24): the first-run tutorial (core/Tutorial.* decides the steps; this watches what you do and draws the
// card), and captions: words on screen for the game's sounds (Settings > Accessibility).
#include "core/Application.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <imgui.h>

namespace px {

using namespace ui;

void Application::startTutorial() {
    tutorial.start();
    tutorialCam = camera.position; tutorialYaw = camera.yaw;
    tutorialEdits = int(std::count(undoLog.begin(), undoLog.end(), 'T'));
    tutorialObjects = scene.size();
}

void Application::updateTutorial(float dt) {
    if (!tutorial.active) { if (tutorial.finished() && !settings.tutorialDone) settings.tutorialDone = true; return; }
    if (mode == Mode::Hub || playerMode) return;
    TutorialSignals sig;
    float turned = std::fabs(std::fmod(camera.yaw - tutorialYaw + 540.0f, 360.0f) - 180.0f);
    sig.cameraMoved = mode == Mode::Editor ? glm::length(camera.position - tutorialCam) + turned / 10.0f : 0.0f;
    sig.terrainEdits = int(std::count(undoLog.begin(), undoLog.end(), 'T')) - tutorialEdits;
    sig.objectsAdded = int(scene.size()) - int(tutorialObjects);
    for (const SceneObject& o : scene.objects()) if (!o.rules.empty()) { sig.anyRules = true; break; }
    sig.playing = mode == Mode::Play;
    if (tutorial.update(sig, dt)) {                      // a new step: measure from here
        tutorialCam = camera.position; tutorialYaw = camera.yaw;
        tutorialEdits = int(std::count(undoLog.begin(), undoLog.end(), 'T'));
        tutorialObjects = scene.size();
        playUiSound("ui_click", 0.6f, 1.3f);
    }
    if (!tutorial.active && !settings.tutorialDone) settings.tutorialDone = true;
}

void Application::drawTutorial() {
    if (!tutorial.active || mode == Mode::Hub || playerMode) return;
    const float s = scale();
    const ImGuiIO& io = ImGui::GetIO();
    const bool playing = mode == Mode::Play;
    const float w = 400 * s;
    // bottom middle of the view (in play: of the screen, above the hotbar)
    const ImVec2 pos = playing ? ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y - 150 * s) : ImVec2(viewRect.x + viewRect.w * 0.5f, viewRect.y + viewRect.h - 24 * s);
    ImGui::SetNextWindowPos(pos, ImGuiCond_Always, ImVec2(0.5f, 1.0f));
    ImGui::SetNextWindowSize(ImVec2(w, 0), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.95f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(16 * s, 14 * s));
    ImGui::PushStyleColor(ImGuiCol_Border, col::accent);
    const ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize |
                                   ImGuiWindowFlags_NoFocusOnAppearing | (playing ? ImGuiWindowFlags_NoInputs : 0);
    if (ImGui::Begin("##tutorial", nullptr, flags)) {
        const TutorialStep step = tutorial.step;
        // progress dots
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 p0 = ImGui::GetCursorScreenPos();
        for (int i = 0; i < Tutorial::kSteps; ++i) {
            const ImVec2 c(p0.x + 5 * s + float(i) * 14 * s, p0.y + 5 * s);
            dl->AddCircleFilled(c, 4 * s, i < tutorial.index() ? col::success : i == tutorial.index() ? col::accent : withAlpha(col::textDim, 0.5f));
        }
        ImGui::Dummy(ImVec2(0, 14 * s));
        pushFont(fonts.title);
        if (tutorial.doneFlash > 0.0f) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::success), "Done!");
        else ImGui::TextUnformatted(tutorialTitle(step));
        popFont();
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextUnformatted(tutorialText(step));
        ImGui::PopTextWrapPos();
        if (!playing) {
            ImGui::Dummy(ImVec2(0, 4 * s));
            if (tutorialHasNext(step)) {
                if (primaryButton(step == TutorialStep::Done ? "Let's go" : "Next", ImVec2(120 * s, 0))) {
                    tutorial.next();
                    tutorialCam = camera.position; tutorialYaw = camera.yaw;
                    tutorialEdits = int(std::count(undoLog.begin(), undoLog.end(), 'T'));
                    tutorialObjects = scene.size();
                    if (!tutorial.active) settings.tutorialDone = true;
                }
                ImGui::SameLine();
            }
            if (step != TutorialStep::Done) {
                ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(0, 0, 0, 0));
                if (ImGui::Button("Skip the tutorial")) { tutorial.skip(); settings.tutorialDone = true; }
                ImGui::PopStyleColor();
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("Help > Tutorial starts it again");
            }
        }
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);
}

void Application::caption(const std::string& sound) {
    if (!settings.captions) return;
    static const std::pair<const char*, const char*> words[] = {
        { "door open", "Door creaks open" }, { "door close", "Door thuds shut" }, { "pickup", "Pick-up chime" }, { "chime", "Chime" },
        { "teleport", "Teleport whoosh" }, { "win", "Victory fanfare" }, { "lose", "Sad notes" }, { "boom", "Explosion" }, { "zap", "Zap" },
        { "whoosh", "Whoosh" },
    };
    std::string text = sound;
    for (const auto& [k, v] : words) if (sound == k) text = v;
    for (Caption& c : captions) if (c.text == text) { c.left = 2.5f; return; }      // the same sound again: keep it up
    captions.push_back({ text, 2.5f });
    if (captions.size() > 5) captions.erase(captions.begin());
}

void Application::drawCaptions() {
    const float dt = ImGui::GetIO().DeltaTime;
    for (Caption& c : captions) c.left -= dt;
    captions.erase(std::remove_if(captions.begin(), captions.end(), [](const Caption& c) { return c.left <= 0.0f; }), captions.end());
    if (captions.empty() || !settings.captions) return;
    const float s = scale() * hudScale();
    const ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    pushFont(fonts.bold);
    const float size = ImGui::GetFontSize() * hudScale();
    float y = ds.y - 130 * scale();
    for (auto it = captions.rbegin(); it != captions.rend(); ++it) {
        const std::string t = "[" + it->text + "]";
        const ImVec2 ts = ImGui::CalcTextSize(t.c_str());
        const float tw = ts.x * hudScale(), th = ts.y * hudScale();
        const float a = std::clamp(it->left / 0.4f, 0.0f, 1.0f);
        dl->AddRectFilled(ImVec2(24 * s, y - th - 8 * s), ImVec2(24 * s + tw + 20 * s, y), IM_COL32(0, 0, 0, int(180 * a)), 6 * s);
        dl->AddText(ImGui::GetFont(), size, ImVec2(34 * s, y - th - 4 * s), IM_COL32(255, 255, 255, int(255 * a)), t.c_str());
        y -= th + 14 * s;
    }
    popFont();
}

} // namespace px
