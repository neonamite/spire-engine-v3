#pragma once
// The firing range inside the Asset Workshop: a flat stone floor, target plates, training dummies, drums,
// a brick wall and a block of sand that really dent when shot, with the item you are building in your
// hand. It is the "test" step of the Item Builder: change a number, shoot, change it again.
//
// The range is an ItemWorld, so the item rules are exactly the ones the game uses. It has no window and
// no OpenGL; the Workshop screen (editor/WorkshopItems.cpp) drives it and draws it.
#include <deque>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "items/ItemSystem.h"
#include "render/Renderer.h"
#include "workshop/Workshop.h"

namespace px {

class ItemRange : public ItemWorld {
public:
    ItemRange();
    ItemRange(const ItemRange&) = delete;
    ItemRange& operator=(const ItemRange&) = delete;

    // ---- the item being tested
    ItemSystem  items;                       // the hand (a hotbar of one: the draft)
    ItemLibrary library;                     // holds the draft only
    // Called for every sound; the Workshop plays it through the engine's mixer.
    std::function<void(const std::string& clip, const glm::vec3& at, float volume, float pitch)> onSound;

    // The item as it is right now (an unsaved draft is fine) and the model that goes with it. Cheap: call every frame.
    void setDraft(const ItemDef& def, AssetPtr model);
    void clearDraft();

    // ---- the range
    void reset();                            // targets stand up, walls and sand are rebuilt, score and ammo start over, you go back to the line
    // yaw/pitch: where you look (degrees). move: -1..1 each. run: faster. dt in seconds.
    void update(float dt, float yawDeg, float pitchDeg, float moveForward, float moveRight, bool run);
    float takeViewKick() { return items.takeViewKick(); }     // degrees to add to the pitch this frame

    glm::vec3 eye() const { return position + glm::vec3(0.0f, kEyeHeight, 0.0f); }
    ItemView view() const { return lastView; }
    void collect(std::vector<ObjectDraw>& out) const;         // everything to draw: dents, targets, the item in the hand

    // ---- score
    struct Score {
        int   shots = 0, hits = 0, down = 0, explosions = 0;
        float damage = 0.0f;                 // dealt to targets, splash included
        float perSecond = 0.0f;              // over the last few seconds
        float accuracy() const { return shots > 0 ? float(hits) / float(shots) : 0.0f; }
    };
    Score score() const;
    void clearScore();

    // Floating damage numbers, for the overlay to draw.
    struct Number { glm::vec3 at{ 0.0f }; float amount = 0.0f; float age = 0.0f; bool kill = false; };
    const std::vector<Number>& numbers() const { return floaters; }

    // ---- what is out there (the overlay draws distance marks from this)
    static constexpr float kEyeHeight = 1.65f;
    static constexpr float kLineZ = 0.0f;                // you start here, facing +Z
    static constexpr float kFarZ = 36.0f;                // the wall

    // ---- ItemWorld
    bool raycast(const glm::vec3& origin, const glm::vec3& dir, float maxDistance, ItemRayHit& hit) override;
    void crater(const glm::vec3& centre, float radius, bool build, MaterialId material) override;
    void blast(const glm::vec3& centre, float radius, float push) override;
    void sound(const std::string& clip, const glm::vec3& at, float volume, float pitch) override;
    void hit(const ItemHit& h) override;

    struct Target {
        std::string label;
        AssetPtr    asset;
        glm::vec3   base{ 0.0f };            // where it stands (its feet)
        float       yaw = 0.0f;              // degrees
        float       maxHealth = 100.0f, health = 100.0f;
        float       fall = 0.0f;             // 0 = standing, 1 = flat on its back
        float       downFor = 0.0f;          // seconds spent knocked down
        float       wobble = 0.0f;           // a hit shakes it: amplitude in degrees, fading
        float       wobbleT = 0.0f;
        float       flash = 0.0f;            // white-hot for a moment after a hit
        glm::vec3   centre{ 0.0f };          // the middle of it, standing (for blasts)
        float       radius = 0.5f;
        bool alive() const { return health > 0.0f; }
        glm::mat4 matrix() const;
    };
    const std::vector<Target>& targets() const { return stand; }

private:
    struct Dent {                            // a block you can shoot holes in, kept as a Workshop model
        Workshop    model;
        glm::vec3   origin{ 0.0f };          // where its model space sits in the range
        glm::vec3   lo{ 0.0f }, hi{ 0.0f };  // its box in range space
    };

    void build();
    void buildTargets();
    void buildDents();
    void knock(Target& t, float damage, const glm::vec3& at);
    static glm::mat4 dentMatrix(const Dent& d) { return glm::translate(glm::mat4(1.0f), d.origin); }

    std::vector<Target> stand;
    std::vector<Dent> dents;
    std::vector<Number> floaters;
    std::deque<std::pair<float, float>> recent;   // (time, damage) for the damage-per-second readout
    float clock = 0.0f;
    Score tally;
    int splashHits = 0;                           // blasts that hurt a target count as a hit
    AssetPtr draftModel;                          // the model in the hand (the Workshop's own, unsaved one)

    glm::vec3 position{ 0.0f, 0.0f, kLineZ }, velocity{ 0.0f };
    bool grounded = true;
    ItemView lastView;
    bool built = false;
};

} // namespace px
