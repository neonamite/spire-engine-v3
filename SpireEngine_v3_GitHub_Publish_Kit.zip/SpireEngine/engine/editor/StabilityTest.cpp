// --demo soak_selftest (1.0): a long, rough session in one go - minutes of play with people chasing you, a village going
// about its day through the night, play started and stopped again and again, a hundred and fifty edits undone and redone -
// checking that nothing drifts, leaks or turns into NaN. Prints "[soaktest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <string>

namespace px {

namespace {
long residentKb() {
    std::ifstream f("/proc/self/statm");
    long pages = 0, rss = 0;
    if (!(f >> pages >> rss)) return 0;
    return rss * 4;                                              // 4 KB pages
}
bool finite3(const glm::vec3& v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }
} // namespace

void Application::runSoakSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[soaktest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto everythingFinite = [&]() {
        for (const Evaluated& e : scene.evaluated())
            for (int c = 0; c < 4; ++c) if (!finite3(glm::vec3(e.world[c]))) return false;
        for (const auto& [id, live] : npcLive) if (!finite3(live.state.position) || !std::isfinite(live.state.yaw)) return false;
        return finite3(player.position) && finite3(camera.position);
    };
    setMode(Mode::Editor);
    tool = Tool::Select;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    const glm::vec3 c = demospot::calmSpot(world);
    camera.position = c + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;

    // ---- two minutes of Survival: hunters chasing you round and round
    buildGameTemplate(GameTemplate::Survival);
    {
        GameRules g = gameRulesOf(); g.lives = 0; g.timeLimit = 0.0f; g.goal = GameGoal::None;   // endless, for the soak
        setGameRules(g, "Endless");
    }
    const size_t objects = scene.size();
    setMode(Mode::Play);
    for (int i = 0; i < 60; ++i) update(1.0f / 30.0f);
    const long memBefore = residentKb();
    bool finite = true;
    int maxDraws = 0;
    for (int i = 0; i < 30 * 120; ++i) {
        // run in a circle so the hunters keep chasing
        const float a = float(i) * 0.01f;
        player.position = c + glm::vec3(std::cos(a) * 9.0f, 0.0f, std::sin(a) * 9.0f) + glm::vec3(0.0f, demospot::groundHeight(world, c.x + std::cos(a) * 9.0f, c.z + std::sin(a) * 9.0f) - c.y, 0.0f);
        player.velocity = glm::vec3(0.0f);
        update(1.0f / 30.0f);
        if ((i % 300) == 0) finite = finite && everythingFinite();
        maxDraws = std::max(maxDraws, lastCharacterDraws);
    }
    const long memAfter = residentKb();
    check(finite && everythingFinite(), "two minutes of being chased: every position stays a real number");
    check(scene.size() == objects && maxDraws < 400, "...nothing is added or lost");
    char b[128];
    std::snprintf(b, sizeof b, "...memory steady (%ld KB -> %ld KB)", memBefore, memAfter);
    check(memBefore == 0 || memAfter - memBefore < 60 * 1024, b);
    // nobody walked through the floor or flew off
    bool grounded = true;
    for (const auto& [id, live] : npcLive) {
        const float gy = demospot::groundHeight(world, live.state.position.x, live.state.position.z);
        if (std::fabs(live.state.position.y - gy) > 3.0f) grounded = false;
    }
    check(grounded, "...and everyone is still on the ground");

    // ---- play started and stopped fifty times
    for (int i = 0; i < 50; ++i) {
        setMode(Mode::Editor); updateObjects(1.0f / 60.0f);
        setMode(Mode::Play); update(1.0f / 30.0f);
    }
    setMode(Mode::Editor);
    updateObjects(1.0f / 60.0f);
    check(npcLive.empty() && !scene.hasLive() && !rulesRunning, "fifty plays and stops: back in the editor, nothing left running");

    // ---- a village through a whole day and night
    scene.clear(); scene.resetHistory();
    buildNpcVillage(c);
    setMode(Mode::Play);
    player.position = c + glm::vec3(0.0f, 0.0f, 30.0f);
    timeFlowing = false;
    bool villageFinite = true;
    for (int h = 0; h < 24; ++h) {
        timeOfDay = float(h);
        for (int i = 0; i < 60; ++i) update(1.0f / 30.0f);
        villageFinite = villageFinite && everythingFinite();
    }
    check(villageFinite, "a village through 24 hours: everyone accounted for");
    setMode(Mode::Editor);
    timeOfDay = 10.0f;

    // ---- a hundred and fifty edits (the history keeps 200), all undone, all redone
    scene.clear(); scene.resetHistory();
    std::uint32_t r = 99u;
    auto rnd = [&]() { r ^= r << 13; r ^= r >> 17; r ^= r << 5; return r; };
    const std::string empty = scene.toText();
    std::vector<ObjectId> placed;
    for (int i = 0; i < 150; ++i) {
        const int what = int(rnd() % 4);
        if (what == 0 || placed.empty()) {
            const float x = float(rnd() % 40) - 20.0f, z = float(rnd() % 40) - 20.0f;
            placed.push_back(placeObject(rnd() % 2 ? "gadget coin" : "crate", c + glm::vec3(x, 0.0f, z)));
        } else if (what == 1) {
            const ObjectId id = placed[rnd() % placed.size()];
            if (SceneObject* m = scene.mutate(id)) { m->position.x += 1.0f; commitScene("Move"); }
        } else if (what == 2) {
            const ObjectId id = placed[rnd() % placed.size()];
            if (scene.find(id)) { RuleSet rs; Rule rule; rule.when = RuleWhen::Touch; rule.actions.push_back(RuleAction{ RuleDo::Message, kRuleSelf, "hi", 0.0f, 0.0f }); rs.rules.push_back(rule); setRules(id, rs, "Rule"); }
        } else {
            GameRules g; g.goal = GameGoal(rnd() % int(GameGoal::Count)); g.timeLimit = float(rnd() % 100);
            setGameRules(g, "Game");
        }
    }
    const std::string full = scene.toText();
    int undos = 0;
    while (scene.canUndo() && undos < 1000) { scene.undo(); ++undos; }
    const bool backToStart = scene.toText() == empty || scene.empty();
    int redos = 0;
    while (scene.canRedo() && redos < 1000) { scene.redo(); ++redos; }
    check(backToStart && undos == redos && undos >= 100, "150 edits: undo all the way back...");
    check(scene.toText() == full, "...and redo all the way forward, exactly");

    std::cerr << "[soaktest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
