// Spire Engine editor UI (Director mode): menu bar, tool rail, inspector, status bar, overlays.
// Styling and widgets come from UiKit; keep this file about layout and wiring.
#include "core/Application.h"
#include "rules/Gadgets.h"
#include "ui/UiKit.h"
#include "editor/Panels.h"
#include <imgui_internal.h>      // DockBuilder: layout presets and the 3D view rectangle
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>
#include <glm/gtc/constants.hpp>

namespace px {

using namespace ui;

namespace {

struct ToolInfo { Tool tool; Icon icon; const char* name; const char* key; const char* blurb; };
const ToolInfo kTools[] = {
    { Tool::Carve,   Icon::Carve,   "Carve",   "1", "Dig into terrain. Hold to keep digging." },
    { Tool::Build,   Icon::Build,   "Add",     "2", "Add ground in the chosen material where you point." },
    { Tool::Smooth,  Icon::Smooth,  "Smooth",  "3", "Soften bumps, sharp edges and blobby sculpting." },
    { Tool::Flatten, Icon::Flatten, "Flatten", "4", "Level ground to the height you click." },
    { Tool::Paint,   Icon::Paint,   "Paint",   "5", "Change what the surface is made of without changing its shape." },
    { Tool::Stamp,   Icon::Stamp,   "Stamp",   "6", "Place a prefab from your library." },
    { Tool::Bake,    Icon::Bake,    "Bake",    "7", "Save a sculpture (shape and materials) as a reusable prefab." },
    { Tool::Select,  Icon::Select,  "Select",  "8", "Click objects to select them, then move, turn or resize them." },
};
static_assert(sizeof(kTools) / sizeof(kTools[0]) == size_t(Tool::Count), "one entry per tool, in enum order");

ImTextureRef texRef(unsigned glTex) { return ImTextureRef(ImTextureID(std::uintptr_t(glTex))); }

} // namespace

// A material's texture in a rounded square. Natural shows the four things it can become.
void drawMaterialSwatch(ImDrawList* dl, const Renderer& r, MaterialId id, ImVec2 a, ImVec2 b, float rounding) {
    if (id == MAT_NATURAL) {
        const ImVec2 m((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f);
        dl->AddImageRounded(texRef(r.materialPreview(MAT_GRASS)), a, m, ImVec2(0, 0), ImVec2(0.5f, 0.5f), IM_COL32_WHITE, rounding, ImDrawFlags_RoundCornersTopLeft);
        dl->AddImageRounded(texRef(r.materialPreview(MAT_SNOW)), ImVec2(m.x, a.y), ImVec2(b.x, m.y), ImVec2(0.5f, 0), ImVec2(1, 0.5f), IM_COL32_WHITE, rounding, ImDrawFlags_RoundCornersTopRight);
        dl->AddImageRounded(texRef(r.materialPreview(MAT_DIRT)), ImVec2(a.x, m.y), ImVec2(m.x, b.y), ImVec2(0, 0.5f), ImVec2(0.5f, 1), IM_COL32_WHITE, rounding, ImDrawFlags_RoundCornersBottomLeft);
        dl->AddImageRounded(texRef(r.materialPreview(MAT_STONE)), m, b, ImVec2(0.5f, 0.5f), ImVec2(1, 1), IM_COL32_WHITE, rounding, ImDrawFlags_RoundCornersBottomRight);
    } else {
        dl->AddImageRounded(texRef(r.materialPreview(id)), a, b, ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, rounding);
    }
}

// Grid of material swatches; returns true when the selection changed.
bool materialPalette(const Renderer& r, MaterialId& selected, bool allowNatural) {
    const float s = scale();
    const int cols = 5;                       // 36 materials: five to a row keeps the palette short
    const float gap = 6 * s;
    const float cw = (ImGui::GetContentRegionAvail().x - gap * (cols - 1)) / cols;
    const float labelH = ImGui::GetFontSize() * 0.9f + 6 * s;
    bool changed = false;
    int n = 0;
    MaterialGroup group = MaterialGroup(255);
    // Grouped by kind (new materials are added at the end of the list, but belong with their kind).
    std::vector<int> order;
    for (int g = int(MaterialGroup::Natural); g <= int(MaterialGroup::People); ++g)
        for (int id = allowNatural ? 0 : 1; id < MAT_COUNT; ++id)
            if (int(materialInfo(MaterialId(id)).group) == g) order.push_back(id);
    for (int id : order) {
        const MaterialGroup g = materialInfo(MaterialId(id)).group;
        if (g != group) {                                    // a heading for each kind of material, starting a new row
            group = g;
            if (n % cols) n += cols - n % cols;
            if (g != MaterialGroup::Natural) {
                if (n > 0) ImGui::Dummy(ImVec2(0, 4 * s));
                pushFont(fonts.small);
                ImGui::PushStyleColor(ImGuiCol_Text, col::textDim);
                ImGui::TextUnformatted(materialGroupName(g));
                ImGui::PopStyleColor();
                popFont();
            }
        }
        if (n % cols) ImGui::SameLine(0, gap);
        ImGui::PushID(id);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        if (ImGui::InvisibleButton("##mat", ImVec2(cw, cw + labelH))) { selected = MaterialId(id); changed = true; }
        const bool hov = ImGui::IsItemHovered(), sel = selected == id;
        if (hov) ImGui::SetTooltip("%s\n%s", materialInfo(MaterialId(id)).name, materialInfo(MaterialId(id)).blurb);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 a(p.x + 3 * s, p.y + 3 * s), b(p.x + cw - 3 * s, p.y + cw - 3 * s);
        drawMaterialSwatch(dl, r, MaterialId(id), a, b, 6 * s);
        if (materialInfo(MaterialId(id)).glow > 0.0f)        // a soft halo marks the ones that glow
            dl->AddRect(ImVec2(a.x - 1, a.y - 1), ImVec2(b.x + 1, b.y + 1), IM_COL32(255, 220, 140, 120), 7 * s, 0, 2.0f * s);
        if (sel || hov)
            dl->AddRect(ImVec2(p.x, p.y), ImVec2(p.x + cw, p.y + cw), sel ? col::accent : col::border, 8 * s, 0, sel ? 2.5f * s : 1.5f * s);
        pushFont(fonts.small);
        const char* name = materialInfo(MaterialId(id)).name;
        const float tw = ImGui::CalcTextSize(name).x;
        dl->AddText(ImVec2(p.x + (cw - tw) * 0.5f, p.y + cw + 3 * s), sel ? col::text : col::textDim, name);
        popFont();
        ImGui::PopID();
        ++n;
    }
    return changed;
}

namespace {
const ToolInfo& toolInfo(Tool t) { return kTools[int(t)]; }

// Where the 3D view sits on screen (window points); brush previews project into it.
ImVec4 gView(0, 0, 1, 1);     // x, y, w, h

} // namespace

// A dockable panel. Returns true when its contents should be drawn (then call ImGui::End()).
// `focus` brings its tab to the front, and reopens it if it was closed.
bool beginPanel(const char* title, bool* open, bool focus) {
    const float s = scale();
    if (focus) { *open = true; ImGui::SetNextWindowFocus(); }
    if (!*open) return false;
    ImGui::SetNextWindowPos(ImVec2(120 * s, 120 * s), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(360 * s, 560 * s), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSizeConstraints(ImVec2(220 * s, 100 * s), ImVec2(FLT_MAX, FLT_MAX));
    // No close button on the tab: panels are put away and brought back with View > Panels, never lost by a stray click.
    const bool visible = ImGui::Begin(title, nullptr, ImGuiWindowFlags_NoCollapse);
    if (!visible) ImGui::End();
    return visible;
}

namespace {

const ImGuiWindowFlags kFixedPanel = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus;

// ---- projection helpers for the 3D brush preview
bool toScreen(const glm::mat4& vp, const glm::vec3& p, ImVec2& out) {
    const glm::vec4 c = vp * glm::vec4(p, 1.0f);
    if (c.w <= 0.05f) return false;
    out = ImVec2(gView.x + (c.x / c.w * 0.5f + 0.5f) * gView.z, gView.y + (1.0f - (c.y / c.w * 0.5f + 0.5f)) * gView.w);
    return true;
}

void drawRing(ImDrawList* dl, const glm::mat4& vp, glm::vec3 center, glm::vec3 n, float r, ImU32 color, float thick) {
    const glm::vec3 a = glm::normalize(std::abs(n.y) < 0.95f ? glm::cross(n, glm::vec3(0, 1, 0)) : glm::cross(n, glm::vec3(1, 0, 0)));
    const glm::vec3 b = glm::cross(n, a);
    constexpr int N = 48;
    for (int i = 0; i <= N; ++i) {
        const float t = float(i) / N * glm::two_pi<float>();
        ImVec2 sp;
        if (!toScreen(vp, center + (a * std::cos(t) + b * std::sin(t)) * r, sp)) { dl->PathClear(); return; }
        dl->PathLineTo(sp);
    }
    dl->PathStroke(color, 0, thick);
}

void drawBox(ImDrawList* dl, const glm::mat4& vp, glm::vec3 mn, glm::vec3 mx, ImU32 color, float thick) {
    glm::vec3 c[8];
    for (int i = 0; i < 8; ++i) c[i] = glm::vec3(i & 1 ? mx.x : mn.x, i & 2 ? mx.y : mn.y, i & 4 ? mx.z : mn.z);
    const int e[12][2] = { {0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7} };
    for (auto& ed : e) {
        ImVec2 a, b;
        if (toScreen(vp, c[ed[0]], a) && toScreen(vp, c[ed[1]], b)) dl->AddLine(a, b, color, thick);
    }
}

} // namespace

// Toasts are shared with the player HUD.
void drawToasts(const std::vector<Toast>& toasts, float topY) {
    const float s = scale();
    const ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImDrawList* fg = ImGui::GetForegroundDrawList();
    float y = topY;
    for (const auto& t : toasts) {
        const float a = std::clamp(std::min(t.age / 0.15f, (4.0f - t.age) / 0.5f), 0.0f, 1.0f);
        const ImU32 accentCol = t.kind == Toast::Kind::Success ? col::success : t.kind == Toast::Kind::Warning ? col::warning : col::accent;
        pushFont(fonts.bold);
        const ImVec2 ts = ImGui::CalcTextSize(t.text.c_str());
        const ImVec2 pad(16 * s, 9 * s);
        const ImVec2 mn(ds.x * 0.5f - ts.x * 0.5f - pad.x, y);
        const ImVec2 mx(ds.x * 0.5f + ts.x * 0.5f + pad.x, y + ts.y + pad.y * 2);
        fg->AddRectFilled(mn, mx, withAlpha(IM_COL32(19, 21, 27, 240), a), 8 * s);
        fg->AddRectFilled(mn, ImVec2(mn.x + 4 * s, mx.y), withAlpha(accentCol, a), 8 * s, ImDrawFlags_RoundCornersLeft);
        fg->AddText(ImVec2(mn.x + pad.x, mn.y + pad.y), withAlpha(col::text, a), t.text.c_str());
        popFont();
        y += (mx.y - mn.y) + 6 * s;
    }
}

// ---- Settings window (shared by the editor, the pause menu and the Project Hub)

namespace {

bool comboList(const char* id, int& idx, const std::vector<std::string>& items) {
    bool changed = false;
    idx = std::clamp(idx, 0, std::max(0, int(items.size()) - 1));
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (ImGui::BeginCombo(id, items.empty() ? "" : items[size_t(idx)].c_str())) {
        for (int i = 0; i < int(items.size()); ++i)
            if (ImGui::Selectable(items[size_t(i)].c_str(), i == idx)) { idx = i; changed = true; }
        ImGui::EndCombo();
    }
    return changed;
}

std::string sizeText(int w, int h) { return std::to_string(w) + " x " + std::to_string(h); }

void settingsGeneral(Application& e) {
    section("Controls");
    if (beginProps("##ctl", 150)) {
        prop("Mouse sensitivity");
        if (sliderFloat("##sens", &e.settings.mouseSensitivity, 0.03f, 0.4f, "%.2f")) e.applySettings();
        prop("Invert Y");
        ImGui::Checkbox("##inv", &e.settings.invertY);
        endProps();
    }
    section("Safety");
    if (beginProps("##safe", 150)) {
        prop("Autosave", "Saves a copy of your world now and then (only when something changed). If the editor ever crashes, it offers to bring it back.");
        static const float kMinutes[] = { 0.0f, 1.0f, 2.0f, 3.0f, 5.0f, 10.0f };
        int idx = 3;
        for (int i = 0; i < 6; ++i) if (std::fabs(e.settings.autosaveMinutes - kMinutes[i]) < 0.01f) idx = i;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::Combo("##autosave", &idx, "Off\0Every minute\0Every 2 minutes\0Every 3 minutes\0Every 5 minutes\0Every 10 minutes\0"))
            e.settings.autosaveMinutes = kMinutes[idx];
        endProps();
    }
    ImGui::Dummy(ImVec2(0, 6 * scale()));
    pushFont(fonts.small);
    ImGui::TextDisabled("Settings are saved automatically in config/settings.cfg.");
    popFont();
}

void settingsGraphics(Application& e) {
    const float s = scale();
    GraphicsValues g = e.graphics();
    const Quality q = detectQuality(g);
    bool changed = false;

    section("Quality");
    if (beginProps("##gq", 150)) {
        prop("Preset", "Sets everything on this page at once. Change any one setting and it becomes Custom.");
        int idx = int(q);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::Combo("##preset", &idx, "Low\0Medium\0High\0Ultra\0Custom\0") && idx < int(Quality::Custom)) {
            e.setQuality(Quality(idx));
            g = e.graphics();
        }
        prop("Graphics card load", "A rough guide, not a benchmark. High = 100%.");
        const float cost = relativeCost(g);
        char label[32];
        std::snprintf(label, sizeof label, "%.0f%%", double(cost * 100.0f));
        ImGui::PushStyleColor(ImGuiCol_PlotHistogram, withAlpha(cost > 1.45f ? col::danger : cost > 1.0f ? col::warning : col::accent, 0.5f));
        ImGui::ProgressBar(std::min(cost / 2.0f, 1.0f), ImVec2(-FLT_MIN, ImGui::GetFrameHeight()), label);
        ImGui::PopStyleColor();
        endProps();
    }
    pushFont(fonts.small);
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextDisabled("%s", qualityBlurb(q));
    ImGui::PopTextWrapPos();
    popFont();

    section("Picture");
    if (beginProps("##gp", 150)) {
        prop("3D resolution", "Below 100% the 3D picture is drawn smaller and stretched: faster but softer. Above 100% it is drawn bigger and shrunk: sharper but slower. The menus always stay sharp.");
        float pct = g.renderScale * 100.0f;
        if (sliderFloat("##rs", &pct, 50.0f, 150.0f, "%.0f%%")) { g.renderScale = std::round(pct / 5.0f) * 0.05f; changed = true; }
        prop("Edge smoothing", "FXAA: removes jagged edges.");
        changed |= ImGui::Checkbox("##fxaa", &g.fxaa);
        prop("Bloom", "Soft glow around bright things like the sun.");
        changed |= ImGui::Checkbox("##bloom", &g.bloom);
        endProps();
    }
    {
        const ImVec2 ds = ImGui::GetIO().DisplaySize, fb = ImGui::GetIO().DisplayFramebufferScale;
        const int pw = int(ds.x * fb.x), ph = int(ds.y * fb.y);
        pushFont(fonts.small);
        ImGui::TextDisabled("The window is %s pixels; the 3D picture is drawn at %s.", sizeText(pw, ph).c_str(),
                            sizeText(std::max(1, int(std::lround(pw * g.renderScale))), std::max(1, int(std::lround(ph * g.renderScale)))).c_str());
        popFont();
    }

    section("Surfaces");
    if (beginProps("##gt", 150)) {
        prop("Texture detail", "How sharp ground, walls and every other material look up close. Ultra (4K) needs a graphics card with about 2 GB of video memory. A new size is built in the background the first time (a minute or two), then loads instantly.");
        int td = g.textureSize <= 512 ? 0 : g.textureSize <= 1024 ? 1 : g.textureSize <= 2048 ? 2 : 3;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::Combo("##td", &td, "Low (512)\0Medium (1K)\0High (2K)\0Ultra (4K)\0")) { g.textureSize = 512 << td; changed = true; }
        prop("Ambient occlusion", "Soft contact shadows in corners, under objects and between stones. Makes things sit in the world.");
        changed |= ImGui::Checkbox("##ao", &g.ssao);
        prop("Texture pack", "Your own photo textures in place of the built-in ones. Put a folder in textures/ with one folder per material inside it (grass, brick, cobblestone...). See docs/TEXTURE_PACKS.md.");
        {
            static std::vector<std::string> packs;
            static double lastScan = -10.0;
            if (ImGui::GetTime() - lastScan > 2.0) { packs = listTexturePacks(); lastScan = ImGui::GetTime(); }
            const std::string current = e.settings.texturePack.empty() ? std::string("Built-in") : e.settings.texturePack;
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::BeginCombo("##pack", current.c_str())) {
                if (ImGui::Selectable("Built-in", e.settings.texturePack.empty())) e.settings.texturePack.clear();
                for (const std::string& p : packs)
                    if (ImGui::Selectable(p.c_str(), p == e.settings.texturePack)) e.settings.texturePack = p;
                if (packs.empty()) { ImGui::TextDisabled("No packs in the textures folder yet."); }
                ImGui::EndCombo();
            }
        }
        endProps();
    }
    if (const TexturePack* pack = e.renderer.texturePack()) {
        pushFont(fonts.small);
        ImGui::TextDisabled("%s: %d of %d materials from the pack.", pack->name.c_str(), pack->count(), kTextureImages);
        for (const std::string& f : pack->unknownFolders) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "Folder \"%s\" is not a material name, so it is skipped.", f.c_str());
        for (const std::string& p : e.renderer.texturePackProblems()) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s", p.c_str());
        popFont();
    }
    if (e.renderer.texturesBuilding()) {
        pushFont(fonts.small);
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::accent), "Building %dpx textures in the background...", g.textureSize);
        popFont();
    }

    section("Shadows");
    if (beginProps("##gs", 150)) {
        prop("Shadows");
        changed |= ImGui::Checkbox("##sh", &g.shadows);
        ImGui::BeginDisabled(!g.shadows);
        prop("Shadow detail", "Sharper shadows use more video memory.");
        int sd = g.shadowSize <= 1024 ? 0 : g.shadowSize <= 2048 ? 1 : 2;
        if (ImGui::Combo("##sd", &sd, "Low (1024)\0Medium (2048)\0High (4096)\0")) { g.shadowSize = sd == 0 ? 1024 : sd == 1 ? 2048 : 4096; changed = true; }
        prop("Shadow distance", "How far from the camera things cast shadows. Farther shadows are blurrier.");
        changed |= sliderFloat("##sr", &g.shadowRange, 40.0f, 200.0f, "%.0f m");
        ImGui::EndDisabled();
        endProps();
    }

    section("Nature and distance");
    if (beginProps("##gn", 150)) {
        prop("Grass");
        changed |= ImGui::Checkbox("##gr", &g.grass);
        ImGui::BeginDisabled(!g.grass);
        prop("Grass amount");
        changed |= sliderFloat("##gd", &g.grassDensity, 0.05f, 1.0f, "%.2f");
        prop("Grass distance");
        changed |= sliderFloat("##gdi", &g.grassDistance, 20.0f, 160.0f, "%.0f m");
        ImGui::EndDisabled();
        prop("Trees", "The trees and bushes the world grows on grass.");
        changed |= ImGui::Checkbox("##trees", &g.trees);
        ImGui::BeginDisabled(!g.trees);
        prop("Tree distance", "How far away trees are still drawn.");
        changed |= sliderFloat("##tdi", &g.treeDistance, 40.0f, 400.0f, "%.0f m");
        ImGui::EndDisabled();
        prop("View distance", "How many chunks around you are loaded and drawn. The biggest cost on slower computers.");
        changed |= sliderInt("##vd", &g.viewDistance, 2, 10, "%d chunks");
        endProps();
    }
    (void)s;
    if (changed) e.setGraphics(g);
}

void settingsDisplay(Application& e) {
    DisplaySettings& d = e.settings.display;
    static std::vector<MonitorInfo> mons;
    static std::vector<Resolution> fsRes;
    static int fsFor = -1;
    if (ImGui::IsWindowAppearing() || mons.empty()) { mons = listMonitors(); fsFor = -1; }
    if (fsFor != d.monitor) {
        fsFor = d.monitor;
        fsRes = mons.empty() ? std::vector<Resolution>{} : fullscreenResolutions(mons[size_t(std::clamp(d.monitor, 0, int(mons.size()) - 1))].id);
    }
    const MonitorInfo mon = mons.empty() ? MonitorInfo{} : mons[size_t(std::clamp(d.monitor, 0, int(mons.size()) - 1))];

    section("Window");
    if (beginProps("##dw", 150)) {
        prop("Window mode", "F11 (or Alt+Enter) switches between Windowed and Borderless at any time.");
        int mode = int(d.mode);
        if (comboList("##mode", mode, { "Windowed", "Borderless fullscreen", "Fullscreen (exclusive)" })) { d.mode = WindowMode(mode); e.applyDisplay(); }

        if (mons.size() > 1) {
            prop("Monitor");
            std::vector<std::string> names;
            for (size_t i = 0; i < mons.size(); ++i) names.push_back(std::to_string(i + 1) + ": " + mons[i].name + "  (" + sizeText(mons[i].width, mons[i].height) + ")");
            int m = d.monitor;
            if (comboList("##mon", m, names)) { d.monitor = m; e.applyDisplay(); }
        }

        prop("Resolution");
        if (d.mode == WindowMode::Windowed) {
            std::vector<Resolution> sizes = windowSizesFor(mon.width > 0 ? mon.width : 1920, mon.height > 0 ? mon.height : 1080);
            const Resolution cur(d.width, d.height);
            const bool listed = std::find(sizes.begin(), sizes.end(), cur) != sizes.end();
            std::vector<std::string> items;
            if (!listed) items.push_back("Current  (" + sizeText(cur.first, cur.second) + ")");
            for (const auto& r : sizes) items.push_back(sizeText(r.first, r.second));
            int idx = listed ? int(std::find(sizes.begin(), sizes.end(), cur) - sizes.begin()) : 0;
            if (comboList("##res", idx, items)) {
                const int k = listed ? idx : idx - 1;
                if (k >= 0 && k < int(sizes.size())) { d.width = sizes[size_t(k)].first; d.height = sizes[size_t(k)].second; e.applyDisplay(); }
            }
        } else if (d.mode == WindowMode::Borderless) {
            ImGui::AlignTextToFramePadding();
            ImGui::TextDisabled("Desktop  (%s)", sizeText(mon.width, mon.height).c_str());
        } else {
            std::vector<std::string> items = { "Desktop  (" + sizeText(mon.width, mon.height) + ")" };
            int idx = 0;
            for (size_t i = 0; i < fsRes.size(); ++i) {
                items.push_back(sizeText(fsRes[i].first, fsRes[i].second));
                if (fsRes[i].first == d.fullscreenWidth && fsRes[i].second == d.fullscreenHeight) idx = int(i) + 1;
            }
            if (comboList("##fsres", idx, items)) {
                d.fullscreenWidth  = idx == 0 ? 0 : fsRes[size_t(idx - 1)].first;
                d.fullscreenHeight = idx == 0 ? 0 : fsRes[size_t(idx - 1)].second;
                e.applyDisplay();
            }
        }
        endProps();
    }

    section("Smoothness");
    if (beginProps("##ds", 150)) {
        prop("V-Sync", "Waits for the monitor so the picture never tears. Turn it off for the lowest delay.");
        if (ImGui::Checkbox("##vsync", &e.settings.vsync)) e.applyDisplay();
        prop("Frame rate limit", "Stops the engine from using more power than it needs. It can be lower than the monitor's rate.");
        const auto& caps = fpsCapChoices();
        std::vector<std::string> items;
        int idx = 0;
        for (size_t i = 0; i < caps.size(); ++i) {
            items.push_back(caps[i] == 0 ? "Unlimited" : std::to_string(caps[i]) + " FPS");
            if (caps[i] == d.fpsCap) idx = int(i);
        }
        if (comboList("##fps", idx, items)) d.fpsCap = caps[size_t(idx)];
        prop("Slow down in background", "Drops to 30 FPS while this window is not in front, so it does not heat up your computer.");
        ImGui::Checkbox("##bgfps", &d.reduceInBackground);
        endProps();
    }

    section("Interface");
    if (beginProps("##di", 150)) {
        prop("Interface size", "Makes every menu and panel bigger or smaller. Ctrl + and Ctrl - do the same anywhere in the editor, Ctrl+0 resets it.");
        float pct = d.uiScale * 100.0f;
        sliderFloat("##uis", &pct, 75.0f, 200.0f, "%.0f%%");
        d.uiScale = std::round(pct / 5.0f) * 0.05f;
        if (ImGui::IsItemDeactivatedAfterEdit()) e.applyUiScale();           // only when you let go: resizing under the pointer mid-drag would jump
        prop("Field of view");
        if (sliderFloat("##fov2", &e.settings.fov, 50.0f, 110.0f, "%.0f deg")) e.applySettings();
        endProps();
    }
    ImGui::Dummy(ImVec2(0, 4 * scale()));
    pushFont(fonts.small);
    if (mon.refresh > 1.0f) ImGui::TextDisabled("%s: %s at %.0f Hz", mon.name.empty() ? "Display" : mon.name.c_str(), sizeText(mon.width, mon.height).c_str(), double(mon.refresh));
    else                    ImGui::TextDisabled("%s: %s", mon.name.empty() ? "Display" : mon.name.c_str(), sizeText(mon.width, mon.height).c_str());
    popFont();
}

void settingsAudio(Application& e) {
    if (!e.audio.deviceOpen()) ImGui::TextDisabled("No sound device found: sounds are off.");
    section("Volume");
    if (beginProps("##aud", 150)) {
        prop("Master volume");
        sliderFloat("##vm", &e.settings.volMaster, 0.0f, 1.0f, "%.2f");
        prop("Effects", "Footsteps, tools, powers.");
        sliderFloat("##vs", &e.settings.volSfx, 0.0f, 1.0f, "%.2f");
        prop("Ambience", "Wind, water, birds, crickets, caves.");
        sliderFloat("##va", &e.settings.volAmbient, 0.0f, 1.0f, "%.2f");
        prop("Music");
        sliderFloat("##vmu", &e.settings.volMusic, 0.0f, 1.0f, "%.2f");
        prop("Interface");
        sliderFloat("##vu", &e.settings.volUi, 0.0f, 1.0f, "%.2f");
        endProps();
    }
    section("Behaviour");
    if (beginProps("##audb", 150)) {
        prop("Mute");
        ImGui::Checkbox("##mute", &e.settings.muteAudio);
        prop("Mute in background", "Silence while this window is not in front.");
        ImGui::Checkbox("##mutebg", &e.settings.muteUnfocused);
        prop("Ambience in editor", "Hear wind and water while sculpting.");
        ImGui::Checkbox("##ambed", &e.settings.ambienceInEditor);
        endProps();
    }
}

void settingsControls(Application& e) {
    const float s = scale();
    section("Keys while playing");
    pushFont(fonts.small);
    ImGui::TextDisabled("Click a key, then press the one you want. A key already in use swaps over. Esc cancels.");
    popFont();
    if (beginProps("##keys", 190)) {
        for (int i = 0; i < kActionCount; ++i) {
            prop(actionLabel(Action(i)));
            ImGui::PushID(i);
            const bool waiting = e.rebinding == i;
            const char* name = SDL_GetScancodeName(SDL_Scancode(e.settings.keys.key[size_t(i)]));
            std::string label = waiting ? std::string("Press a key...") : (name && *name ? std::string(name) : std::string("(none)"));
            if (waiting) pushSelectedButton();
            if (ImGui::Button(label.c_str(), ImVec2(-FLT_MIN, 0))) e.rebinding = waiting ? -1 : i;
            if (waiting) popSelectedButton();
            ImGui::PopID();
        }
        endProps();
    }
    ImGui::TextDisabled("Always: Esc pause menu, Tab editor, 1-9 items, mouse buttons use items.");
    ImGui::Dummy(ImVec2(0, 4 * s));
    section("How it feels");
    if (beginProps("##feel", 190)) {
        prop("Toggle run", "Tap Run to start running and again to stop, instead of holding it down");
        ImGui::Checkbox("##togglerun", &e.settings.toggleRun);
        prop("Mouse sensitivity");
        if (sliderFloat("##sens2", &e.settings.mouseSensitivity, 0.03f, 0.4f, "%.2f")) e.applySettings();
        prop("Invert mouse Y");
        if (ImGui::Checkbox("##invy2", &e.settings.invertY)) e.applySettings();
        endProps();
    }
}

void settingsAccessibility(Application& e) {
    section("Seeing");
    if (beginProps("##see", 190)) {
        prop("Colour-blind friendly", "Colours that red-green colour-blind people can tell apart, for good / careful / bad, the gizmo's arrows and the like");
        if (ImGui::Checkbox("##cb", &e.settings.colourBlind)) e.applySettings();
        prop("Bigger crosshair and messages", "A larger crosshair, use prompt and messages while playing");
        ImGui::Checkbox("##bighud", &e.settings.bigHud);
        prop("Interface size", "Every menu and panel bigger or smaller (also Ctrl + and Ctrl -)");
        float pct = e.settings.display.uiScale * 100.0f;
        sliderFloat("##uis2", &pct, 75.0f, 200.0f, "%.0f%%");
        e.settings.display.uiScale = std::round(pct / 5.0f) * 0.05f;
        if (ImGui::IsItemDeactivatedAfterEdit()) e.applyUiScale();
        endProps();
    }
    section("Hearing");
    if (beginProps("##hear", 190)) {
        prop("Captions", "Words on screen for game sounds: doors, pick-ups, teleports, winning...");
        ImGui::Checkbox("##captions", &e.settings.captions);
        endProps();
    }
    section("Comfort");
    if (beginProps("##comfort", 190)) {
        prop("Reduce motion", "No screen shake from explosions, and the camera jumps to bookmarks instead of gliding");
        ImGui::Checkbox("##reducemotion", &e.settings.reduceMotion);
        prop("Field of view", "Wider can feel less closed in");
        if (sliderFloat("##fov3", &e.settings.fov, 50.0f, 110.0f, "%.0f deg")) e.applySettings();
        endProps();
    }
    section("Learning");
    if (ImGui::Button("Start the tutorial again")) { e.openSettings = false; ImGui::CloseCurrentPopup(); e.startTutorial(); }
}

const char* const kSettingsTabs[] = { "General", "Graphics", "Display", "Audio", "Controls", "Accessibility" };
constexpr int kSettingsTabCount = 6;

void restoreDefaults(Application& e, int tab) {
    const UserSettings d;
    switch (tab) {
    case 0:
        e.settings.mouseSensitivity = d.mouseSensitivity; e.settings.invertY = d.invertY; e.settings.autosaveMinutes = d.autosaveMinutes;
        e.applySettings();
        break;
    case 1: e.setGraphics(qualityPreset(Quality::High)); break;
    case 2: {
        const int w = e.settings.display.width, h = e.settings.display.height;      // the window keeps its size
        e.settings.display = d.display;
        e.settings.display.width = w; e.settings.display.height = h;
        e.settings.vsync = d.vsync; e.settings.fov = d.fov;
        e.applySettings(); e.applyDisplay(); e.applyUiScale();
        break;
    }
    case 4:
        e.settings.keys = d.keys; e.settings.toggleRun = d.toggleRun;
        e.settings.mouseSensitivity = d.mouseSensitivity; e.settings.invertY = d.invertY;
        e.applySettings();
        break;
    case 5:
        e.settings.colourBlind = d.colourBlind; e.settings.bigHud = d.bigHud; e.settings.captions = d.captions; e.settings.reduceMotion = d.reduceMotion;
        e.applySettings();
        break;
    case 3:
        e.settings.volMaster = d.volMaster; e.settings.volSfx = d.volSfx; e.settings.volAmbient = d.volAmbient;
        e.settings.volMusic = d.volMusic; e.settings.volUi = d.volUi; e.settings.muteAudio = d.muteAudio;
        e.settings.muteUnfocused = d.muteUnfocused; e.settings.ambienceInEditor = d.ambienceInEditor;
        break;
    }
}

} // namespace

void drawSettingsModal(Application& e) {
    const float s = scale();
    const ImVec2 ds = ImGui::GetIO().DisplaySize;
    if (e.openSettings) { ImGui::OpenPopup("Settings"); e.openSettings = false; }
    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min(600 * s, ds.x - 24 * s), std::min(660 * s, ds.y - 40 * s)));
    if (ImGui::BeginPopupModal("Settings", nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
        const float footer = ImGui::GetFrameHeight() + 18 * s;
        if (ImGui::BeginTabBar("##settabs")) {
            for (int t = 0; t < kSettingsTabCount; ++t) {
                if (ImGui::BeginTabItem(kSettingsTabs[t], nullptr, e.settingsTabForce == t ? ImGuiTabItemFlags_SetSelected : 0)) {
                    e.settingsTab = t;
                    if (ImGui::BeginChild("##body", ImVec2(0, -footer))) {
                        switch (t) {
                        case 0: settingsGeneral(e); break;
                        case 1: settingsGraphics(e); break;
                        case 2: settingsDisplay(e); break;
                        case 3: settingsAudio(e); break;
                        case 4: settingsControls(e); break;
                        case 5: settingsAccessibility(e); break;
                        }
                    }
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }
            }
            ImGui::EndTabBar();
        }
        e.settingsTabForce = -1;
        ImGui::Dummy(ImVec2(0, 2 * s));
        if (ImGui::Button("Restore defaults")) restoreDefaults(e, e.settingsTab);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Resets only the %s tab.", kSettingsTabs[std::clamp(e.settingsTab, 0, kSettingsTabCount - 1)]);
        ImGui::SameLine(ImGui::GetWindowWidth() - 120 * s - ImGui::GetStyle().WindowPadding.x);
        if (primaryButton("Done", ImVec2(120 * s, 0)) || (ImGui::IsKeyPressed(ImGuiKey_Escape) && e.rebinding < 0)) { e.rebinding = -1; ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
}

// The current tool's settings, shown in Details when nothing is selected (or a shaping tool is in hand).
void Application::drawToolDetails() {
    const float s = scale();
    const ToolInfo& ti = toolInfo(tool);
    ImGui::Dummy(ImVec2(0, 2 * s));
    const ImVec2 ip = ImGui::GetCursorScreenPos();
    const float iconBox = 40 * s;
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(ip, ImVec2(ip.x + iconBox, ip.y + iconBox), col::accentDim, 8 * s);
    dl->AddRect(ip, ImVec2(ip.x + iconBox, ip.y + iconBox), withAlpha(col::accent, 0.35f), 8 * s);
    drawIcon(dl, ti.icon, ImVec2(ip.x + iconBox * 0.5f, ip.y + iconBox * 0.5f), iconBox * 0.5f, col::accent);
    ImGui::Dummy(ImVec2(iconBox, iconBox));
    ImGui::SameLine(0, 12 * s);
    ImGui::BeginGroup();
    pushFont(fonts.title); ImGui::TextUnformatted(ti.name); popFont();
    ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
    ImGui::TextDisabled("%s", ti.blurb);
    ImGui::PopTextWrapPos();
    ImGui::EndGroup();

    if (tool == Tool::Select) drawObjectsToolSection();

    if (tool != Tool::Stamp && tool != Tool::Select) {
        section("Brush");
        if (beginProps("##brush")) {
            if (tool == Tool::Carve || tool == Tool::Build || tool == Tool::Flatten || tool == Tool::Smooth || tool == Tool::Paint) {
                prop("Radius", "Mouse wheel or [ ] to change");
                sliderFloat("##radius", &brushRadius, 1.0f, 12.0f, "%.1f m");
            }
            if (tool == Tool::Smooth) {
                prop("Strength", "How much each stroke step softens");
                sliderFloat("##smooth", &smoothStrength, 0.05f, 1.0f, "%.2f");
            }
            if (tool == Tool::Bake) {
                prop("Prefab name");
                ImGui::InputText("##bakename", bakeName, sizeof(bakeName));
                prop("Capture size", "Half-width of the box that gets saved");
                sliderInt("##bakeradius", &bakeRadius, 2, 16, "%d m");
            }
            endProps();
        }
        if (tool == Tool::Bake) {
            ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
            ImGui::TextDisabled("Click the base of a sculpture. The blue box shows exactly what will be captured.");
            ImGui::PopTextWrapPos();
        }
    }

    if (tool == Tool::Build || tool == Tool::Paint) {
        section("Material");
        // Build can't make "Natural" matter; painting Natural restores the terrain's own look.
        if (tool == Tool::Build && brushMaterial == MAT_NATURAL) brushMaterial = MAT_STONE;
        materialPalette(renderer, brushMaterial, tool == Tool::Paint);
    }

    if (tool == Tool::Stamp || tool == Tool::Bake) {
        section("Shapes to stamp");
        ImGui::PushStyleColor(ImGuiCol_FrameBg, col::panelAlt);
        if (ImGui::BeginListBox("##prefabs", ImVec2(-FLT_MIN, 200 * s))) {
            for (const auto& n : prefabs.names()) {
                const bool builtin = (n == "stone_pillar" || n == "boulder");
                const bool sel = n == stampPrefab;
                const float rowH = ImGui::GetFrameHeight() + 4 * s;
                const ImVec2 rp = ImGui::GetCursorScreenPos();
                if (ImGui::Selectable(("##" + n).c_str(), sel, 0, ImVec2(0, rowH))) { stampPrefab = n; tool = Tool::Stamp; }
                ImDrawList* ldl = ImGui::GetWindowDrawList();
                drawIcon(ldl, Icon::Bake, ImVec2(rp.x + 14 * s, rp.y + rowH * 0.5f), 15 * s, sel ? col::accent : col::textDim);
                ldl->AddText(ImVec2(rp.x + 30 * s, rp.y + (rowH - ImGui::GetFontSize()) * 0.5f), col::text, n.c_str());
                pushFont(fonts.small);
                const char* tag = builtin ? "built-in" : "custom";
                const float tw = ImGui::CalcTextSize(tag).x;
                const float rx = rp.x + ImGui::GetContentRegionAvail().x - tw - 8 * s;
                ldl->AddText(ImVec2(rx, rp.y + (rowH - ImGui::GetFontSize()) * 0.5f), builtin ? col::textDim : col::success, tag);
                popFont();
            }
            ImGui::EndListBox();
        }
        ImGui::PopStyleColor();
    }
}

// ============================================================== main entry

void Application::drawEditorUI() {
    const ImGuiIO& io = ImGui::GetIO();
    const float s = scale();
    const ImVec2 ds = io.DisplaySize;

    // ------------------------------------------------ brush preview (under all panels)
    if (cursorHitValid && tool != Tool::Select && placingAsset.empty()) {
        ImDrawList* bg = ImGui::GetBackgroundDrawList();
        const glm::vec3 p = cursorHit.position, n = cursorHit.normal;
        const float th = 2.0f * s;
        switch (tool) {
        case Tool::Carve:
            drawRing(bg, viewProj, p, n, brushRadius, withAlpha(col::danger, 0.95f), th);
            drawRing(bg, viewProj, p + n * 0.05f, n, brushRadius * 0.5f, withAlpha(col::danger, 0.35f), 1.0f * s);
            break;
        case Tool::Build:
            drawRing(bg, viewProj, p, n, brushRadius, withAlpha(col::success, 0.95f), th);
            drawRing(bg, viewProj, p + n * (brushRadius * 0.5f), n, brushRadius * 0.7f, withAlpha(col::success, 0.35f), 1.0f * s);
            break;
        case Tool::Smooth:
            drawRing(bg, viewProj, p, n, brushRadius * 1.25f, withAlpha(col::accent, 0.95f), th);
            drawRing(bg, viewProj, p + n * 0.05f, n, brushRadius * 0.45f, withAlpha(col::accent, 0.35f), 1.0f * s);
            break;
        case Tool::Paint: {
            drawRing(bg, viewProj, p, n, brushRadius, IM_COL32(240, 240, 248, 235), th);
            ImVec2 sc;
            if (toScreen(viewProj, p, sc)) {          // the chosen material, next to the cursor
                const float sw = 22 * s;
                const ImVec2 a(sc.x + 14 * s, sc.y + 10 * s);
                bg->AddRectFilled(ImVec2(a.x - 2 * s, a.y - 2 * s), ImVec2(a.x + sw + 2 * s, a.y + sw + 2 * s), IM_COL32(0, 0, 0, 150), 6 * s);
                drawMaterialSwatch(bg, renderer, brushMaterial, a, ImVec2(a.x + sw, a.y + sw), 5 * s);
            }
            break;
        }
        case Tool::Flatten:
            drawRing(bg, viewProj, p, glm::vec3(0, 1, 0), brushRadius * 1.5f, withAlpha(col::warning, 0.95f), th);
            drawRing(bg, viewProj, p, glm::vec3(0, 1, 0), brushRadius * 0.8f, withAlpha(col::warning, 0.35f), 1.0f * s);
            break;
        case Tool::Stamp:
            if (auto pf = prefabs.get(stampPrefab)) {
                const glm::vec3 mn = glm::vec3(pf->minCornerFor(p));
                drawBox(bg, viewProj, mn, mn + glm::vec3(float(pf->size)), withAlpha(col::accent, 0.85f), 1.5f * s);
            }
            break;
        case Tool::Bake: {
            const glm::vec3 mn(std::floor(p.x) - bakeRadius, std::floor(p.y) - 1, std::floor(p.z) - bakeRadius);
            drawBox(bg, viewProj, mn, mn + glm::vec3(float(bakeRadius * 2)), withAlpha(col::accent, 0.95f), 2.0f * s);
            break;
        }
        case Tool::Select:
        case Tool::Count: break;
        }
        ImVec2 sc;
        if (toScreen(viewProj, p, sc)) bg->AddCircleFilled(sc, 2.5f * s, IM_COL32(255, 255, 255, 220));
    }

    drawNpcOverlay();
    if (!uiHidden) drawTutorial();
    if (uiHidden) {
        ImDrawList* fg = ImGui::GetForegroundDrawList();
        pushFont(fonts.small);
        fg->AddText(ImVec2(14 * s, 12 * s), col::textDim, "UI hidden  -  press H to show");
        popFont();
        drawToasts(toasts, 16 * s);
        return;
    }
    drawObjectOverlay();

    // ------------------------------------------------ the frame: top bar, status bar, tool strip (editor/Shell.cpp)
    // Side bars take their strip out of the area the dock space gets, in this order.
    drawTopBar();
    drawStatusBar();
    drawToolStrip();

    // ------------------------------------------------ dock space
    // Everything between the menu bar and the status bar is one dock space. Panels dock into
    // it; the empty middle (the central node) is the 3D view, and the renderer draws into it.
    const ImGuiID dockId = ImGui::GetID("SpireDock");
    ImGuiViewport* mainVp = ImGui::GetMainViewport();
    if (layoutRequest >= 0 || (!layoutDefaultsBuilt && ImGui::DockBuilderGetNode(dockId) == nullptr)) {
        buildLayout(dockId, layoutRequest >= 0 ? Layout(layoutRequest) : Layout::Default);
        layoutRequest = -1;
    }
    layoutDefaultsBuilt = true;
    ImGui::PushStyleColor(ImGuiCol_DockingEmptyBg, IM_COL32(0, 0, 0, 0));
    ImGui::DockSpaceOverViewport(dockId, mainVp, ImGuiDockNodeFlags_PassthruCentralNode | ImGuiDockNodeFlags_NoDockingOverCentralNode);
    ImGui::PopStyleColor();
    if (ImGuiDockNode* central = ImGui::DockBuilderGetCentralNode(dockId); central && central->Size.x > 8 && central->Size.y > 8)
        viewRect = { central->Pos.x, central->Pos.y, central->Size.x, central->Size.y };
    else
        viewRect = { mainVp->WorkPos.x, mainVp->WorkPos.y, mainVp->WorkSize.x, mainVp->WorkSize.y };
    gView = ImVec4(viewRect.x, viewRect.y, viewRect.w, viewRect.h);

    const float top = viewRect.y, bottom = viewRect.y + viewRect.h;

    // ------------------------------------------------ panels (dockable windows)
    // The old inspector tabs are now windows of their own: drag a tab to move a panel, drop it
    // on an edge to split, or pull it out to float it.
    {
        {
            {
                // ---------------- Scene and Details first, so they lead their tab bars (editor/ObjectPanels.cpp)
                drawOutliner();
                drawProperties();

                // ---------------- WORLD
                if (beginPanel("World", &showWorldPanel, forceInspectorTab == 1 || settleFront("World"))) {
                    ImGui::Dummy(ImVec2(0, 2 * s));
                    beginCard("##stats");
                    const float cw = ImGui::GetContentRegionAvail().x / 3.0f;
                    char a[32], b[32], c[32];
                    std::snprintf(a, sizeof a, "%zu", world.chunks().size());
                    std::snprintf(b, sizeof b, "%.2fM", renderer.triangleCount() / 1.0e6);
                    std::snprintf(c, sizeof c, "%zu", world.editCount());
                    const float x0 = ImGui::GetCursorPosX();
                    statTile("CHUNKS", a); ImGui::SameLine(x0 + cw);
                    statTile("TRIANGLES", b); ImGui::SameLine(x0 + cw * 2);
                    statTile("EDITS", c);
                    if (world.pendingCount()) {
                        pushFont(fonts.small);
                        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "Streaming %zu chunks...", world.pendingCount());
                        popFont();
                    }
                    endCard();

                    // Planet worlds must never expose the flat-world Regenerate
                    // button: setSettings() deliberately exits planetary mode.
                    if (const auto* planetSettings = world.currentPlanetSettings()) {
                        const auto& planet = planetSettings->planet;
                        section("Planet World (Experimental)");
                        if (beginProps("##planet")) {
                            prop("Name"); ImGui::TextWrapped("%s", planet.name.c_str());
                            prop("Radius"); ImGui::Text("%.1f m", planet.radiusMeters);
                            prop("Gravity"); ImGui::Text("%.2f m/s^2 (not yet applied to play physics)", planet.surfaceGravity);
                            prop("Seed"); ImGui::Text("%llu", static_cast<unsigned long long>(planet.seed));
                            prop("Relief"); ImGui::Text("%.1f m", planet.terrainAmplitudeMeters);
                            prop("Save file"); ImGui::TextWrapped("%s", planetSavePath().c_str());
                            endProps();
                        }
                        ImGui::TextDisabled("Prototype: local spherical chunks, editor flight only.");
                        ImGui::Dummy(ImVec2(0, 3 * s));
                        if (primaryButton("Fly to Surface")) {
                            positionPlanetCamera(*planetSettings);
                            toast("Moved camera to planetary surface", Toast::Kind::Info);
                        }
                        if (ImGui::Button("Local Aerial View")) {
                            camera.position = glm::vec3(0.0f,
                                static_cast<float>(planet.radiusMeters + planet.terrainAmplitudeMeters + 48.0),
                                12.0f);
                            camera.setUpVector(world.localUp(camera.position));
                            camera.lookAt(glm::vec3(0.0f));
                            flyTo.cancel();
                            toast("Local aerial camera ready", Toast::Kind::Info);
                        }
                        if (ImGui::Button("Orbital Preview (Experimental)")) {
                            // Move far enough to reveal the whole planet without
                            // changing its sculptable chunk/physics mode.
                            const float distance = static_cast<float>(
                                std::max(planet.radiusMeters * 3.0,
                                         planet.radiusMeters + planet.terrainAmplitudeMeters * 2.0 + 100.0));
                            camera.position = glm::vec3(0.0f, distance, 0.01f);
                            camera.setUpVector(world.localUp(camera.position));
                            camera.lookAt(glm::vec3(0.0f));
                            flyTo.cancel();
                            toast("Experimental orbital surface LOD preview (sculpted edits not yet included)", Toast::Kind::Info);
                        }
                        ImGui::TextDisabled("Orbit preview uses a separate surface mesh; volume edits may differ.");
                        section("Planet Streaming");
                        if (beginProps("##planetstream")) {
                            prop("Chunk radius", "Number of nearby 3D voxel chunks streamed around the editor camera");
                            sliderInt("##planetradius", &world.planetLoadRadius, 1, 4, "%d chunks");
                            endProps();
                        }
                        section("Planet Tools");
                        if (ImGui::Button("Create Another Planet...")) openPlanetCreator();
                        ImGui::TextDisabled("To return to flat terrain use File > New World.");
                    } else {
                    section("World Builder");
                    ImGui::TextWrapped("Choose a tool, then work directly in the viewport. The canvas is yours; generation is optional.");
                    if (ImGui::Button("New Blank Canvas")) cmdNewBlankCanvas();
                    ImGui::SameLine();
                    if (ImGui::Button("Sculpt / Carve")) { setEditMode(EditMode::Shape); tool = Tool::Carve; }
                    if (ImGui::Button("Add Terrain")) { setEditMode(EditMode::Shape); tool = Tool::Build; }
                    ImGui::SameLine();
                    if (ImGui::Button("Paint Terrain")) { setEditMode(EditMode::Shape); tool = Tool::Paint; }
                    if (ImGui::Button("Place Objects")) setEditMode(EditMode::Build);
                    ImGui::SameLine();
                    if (ImGui::Button("Flatten Land")) { setEditMode(EditMode::Shape); tool = Tool::Flatten; }
                    ImGui::TextDisabled("Changes affect the current world. Save first before creating a new canvas.");
                    section("Construction Workspace");
                    ImGui::TextWrapped("Build by hand. Use architectural blueprints, snap-together kits, or your own assets.");
                    if (ImGui::Button("Draw House / Building Plan")) openBlueprintEditor();
                    if (ImGui::Button("Modular Building Kits")) { showKits = true; setEditMode(EditMode::Build); }
                    ImGui::SameLine();
                    if (ImGui::Button("Asset Browser")) { showShelf(-1, false); setEditMode(EditMode::Build); }
                    if (ImGui::Button("Create Custom Asset")) enterWorkshopNew();
                    ImGui::TextDisabled("Buildings and props use the existing scene save system.");

                    section("Manual Road Builder");
                    ImGui::TextWrapped("Look at the ground, select a road start, then look at the endpoint and build. Roads use saved voxel edits.");
                    ImGui::SliderFloat("Road width (m)", &roadWidth, 2.0f, 16.0f, "%.1f");
                    ImGui::Checkbox("Grade the ground", &roadGrade);
                    if (ImGui::Button("Stone road")) roadMaterial = MAT_COBBLESTONE;
                    ImGui::SameLine();
                    if (ImGui::Button("Dirt road")) roadMaterial = MAT_DIRT;
                    if (ImGui::Button("1. Pick Road Start")) captureRoadStart();
                    ImGui::SameLine();
                    ImGui::BeginDisabled(!roadStartSelected);
                    if (ImGui::Button("2. Build Road")) finishRoad();
                    ImGui::EndDisabled();
                    if (roadStartSelected) {
                        ImGui::Text("Start: %.1f, %.1f, %.1f", roadStart.x, roadStart.y, roadStart.z);
                        if (ImGui::SmallButton("Cancel Road")) roadStartSelected = false;
                    }
                    ImGui::TextDisabled("Roads are 1-160 m per segment. Planet roads are a future milestone.");

                    ImGui::Spacing();
                    if (ImGui::TreeNodeEx("Advanced Procedural Terrain", ImGuiTreeNodeFlags_None)) {
                    if (beginProps("##terrain")) {
                        prop("Seed");
                        int seed = int(pendingTerrain.seed);
                        const float rb = ImGui::GetFrameHeight();
                        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - rb - 6 * s);
                        if (ImGui::InputInt("##seed", &seed, 0)) pendingTerrain.seed = std::uint32_t(seed);
                        ImGui::SameLine(0, 6 * s);
                        const ImVec2 dp = ImGui::GetCursorScreenPos();
                        if (ImGui::Button("##rand", ImVec2(rb, rb))) pendingTerrain.seed = std::uint32_t(SDL_GetTicks() * 2654435761u) & 0x7FFFFFFF;
                        drawIcon(ImGui::GetWindowDrawList(), Icon::Redo, ImVec2(dp.x + rb * 0.5f, dp.y + rb * 0.5f), rb * 0.55f, col::text);
                        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Random seed");
                        prop("Ground level");
                        sliderFloat("##base", &pendingTerrain.baseHeight, 10.0f, 70.0f, "%.0f m");
                        prop("Hill height");
                        sliderFloat("##hamp", &pendingTerrain.hillAmplitude, 0.0f, 40.0f, "%.0f m");
                        prop("Hill size", "Lower = wider, gentler hills");
                        sliderFloat("##hfreq", &pendingTerrain.hillFrequency, 0.002f, 0.03f, "%.4f");
                        prop("Caves", "Strength of overhangs and cave noise");
                        sliderFloat("##camp", &pendingTerrain.caveAmplitude, 0.0f, 20.0f, "%.1f");
                        prop("Cave size");
                        sliderFloat("##cfreq", &pendingTerrain.caveFrequency, 0.01f, 0.1f, "%.3f");
                        prop("Sea", "Fill low ground with water, with sandy beaches");
                        ImGui::Checkbox("##sea", &pendingTerrain.water);
                        ImGui::SameLine();
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        ImGui::BeginDisabled(!pendingTerrain.water);
                        sliderFloat("##sealevel", &pendingTerrain.waterLevel, 5.0f, 60.0f, "level %.0f m");
                        ImGui::EndDisabled();
                        prop("Props", "Scatter pillars and boulders across the land");
                        ImGui::Checkbox("##scatter", &pendingTerrain.scatterProps);
                        ImGui::SameLine();
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        ImGui::BeginDisabled(!pendingTerrain.scatterProps);
                        sliderFloat("##sdens", &pendingTerrain.scatterChance, 0.0f, 1.0f, "density %.2f");
                        ImGui::EndDisabled();
                        endProps();
                    }
                    ImGui::Dummy(ImVec2(0, 2 * s));
                    if (primaryButton("Regenerate World")) { world.setSettings(pendingTerrain); toast("Regenerating. Your edits are kept."); }
                    pushFont(fonts.small);
                    ImGui::TextDisabled("Your sculpting is replayed onto the new terrain.");
                    popFont();
                    ImGui::TreePop(); // Advanced Procedural Terrain
                    } // collapsed advanced procedural settings

                    section("Streaming");
                    if (beginProps("##stream")) {
                        prop("View distance", "Chunks loaded around the camera");
                        sliderInt("##radius", &world.loadRadius, 2, 10, "%d chunks");
                        endProps();
                    }

                    } // flat-world-only terrain controls

                    section("File");
                    if (iconTextButton("save", Icon::Save, "Save World")) cmdSave();
                    ImGui::SameLine();
                    if (iconTextButton("load", Icon::Open, "Load World")) cmdLoad();
                    ImGui::SameLine();
                    if (iconTextButton("new", Icon::Globe, "New")) {
                        if (world.isPlanetaryPrototype()) openPlanetCreator();
                        else cmdNewWorld();
                    }
                    ImGui::Dummy(ImVec2(0, 4 * s));
                    if (dangerButton("Clear All Edits")) ImGui::OpenPopup("Clear all edits?");

                    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
                    if (ImGui::BeginPopupModal("Clear all edits?", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
                        ImGui::TextUnformatted("This removes every carve, build and stamp\nin this world. It can't be undone.");
                        ImGui::Dummy(ImVec2(0, 6 * s));
                        if (dangerButton("Clear", ImVec2(120 * s, 0))) {
                            if (const auto* active = world.currentPlanetSettings()) {
                                // Re-entering the same planet preserves its parameters while
                                // dropping the planet edit log; never convert to flat world.
                                (void)active;
                                world.clearPlanetEdits();
                                clearSceneState();
                            } else world.clearEdits();
                            toast("All edits cleared");
                            ImGui::CloseCurrentPopup();
                        }
                        ImGui::SameLine();
                        if (ImGui::Button("Cancel", ImVec2(120 * s, 0))) ImGui::CloseCurrentPopup();
                        ImGui::EndPopup();
                    }
                    ImGui::End();
                }

                // ---------------- ENVIRONMENT
                if (beginPanel("Sky", &showEnvPanel, forceInspectorTab == 2 || settleFront("Sky"))) {
                    RenderSettings& rs = renderSettings;
                    section("Time of Day");
                    {
                        // Big clock + play/pause
                        pushFont(fonts.display);
                        ImGui::TextUnformatted(timeOfDayText().c_str());
                        popFont();
                        ImGui::SameLine();
                        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10 * s);
                        if (iconTextButton("timeplay", timeFlowing ? Icon::Pause : Icon::Play, timeFlowing ? "Pause" : "Play")) timeFlowing = !timeFlowing;
                        if (beginProps("##time")) {
                            prop("Time");
                            char fmt[16];
                            std::snprintf(fmt, sizeof fmt, "%s", timeOfDayText().c_str());
                            if (sliderFloat("##tod", &timeOfDay, 0.0f, 23.99f, fmt)) updateSunDirection();
                            prop("Day length", "Real minutes for one full day");
                            sliderFloat("##daylen", &dayLengthMinutes, 1.0f, 120.0f, "%.0f min");
                            endProps();
                        }
                        const struct { const char* name; float t; } presets[] = { { "Dawn", 6.3f }, { "Noon", 12.0f }, { "Sunset", 17.7f }, { "Night", 22.5f } };
                        const float pw = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3) / 4.0f;
                        for (int k = 0; k < 4; ++k) {
                            if (k) ImGui::SameLine();
                            if (ImGui::Button(presets[k].name, ImVec2(pw, 0))) { timeOfDay = presets[k].t; updateSunDirection(); }
                        }
                    }

                    section("Sun & Shadows");
                    if (beginProps("##sun")) {
                        prop("Sun path", "Compass direction the sun travels along");
                        sliderFloat("##heading", &sunHeading, 0.0f, 360.0f, "%.0f deg");
                        prop("Noon height", "How high the sun climbs. Low = long shadows all day");
                        sliderFloat("##maxel", &sunMaxElevation, 15.0f, 90.0f, "%.0f deg");
                        prop("Sun strength");
                        sliderFloat("##sunint", &rs.sunIntensity, 0.5f, 8.0f, "%.1f");
                        prop("Shadows");
                        ImGui::Checkbox("##shadows", &rs.shadows);
                        prop("Shadow range", "Bigger = shadows further away, but softer");
                        sliderFloat("##srange", &rs.shadowRange, 40.0f, 200.0f, "%.0f m");
                        endProps();
                    }

                    section("Sky & Atmosphere");
                    if (beginProps("##atmo")) {
                        prop("Sky brightness");
                        sliderFloat("##skyint", &rs.skyIntensity, 0.2f, 2.0f, "%.2f");
                        prop("Haze", "0 = crisp deep blue, 1 = hazy white horizon");
                        sliderFloat("##haze", &rs.haze, 0.0f, 1.0f, "%.2f");
                        prop("Fog amount");
                        sliderFloat("##fogd", &rs.fogDensity, 0.0f, 2.0f, "%.2f");
                        prop("Fog distance");
                        sliderFloat("##fog", &rs.fogDistance, 60.0f, 600.0f, "%.0f m");
                        prop("Night brightness", "How visible the world stays at night");
                        sliderFloat("##night", &rs.nightBrightness, 0.0f, 1.0f, "%.2f");
                        prop("Stars");
                        sliderFloat("##stars", &rs.starBrightness, 0.0f, 2.0f, "%.2f");
                        endProps();
                    }

                    section("Camera & Colour");
                    if (beginProps("##post")) {
                        prop("Exposure");
                        sliderFloat("##exp", &rs.exposure, 0.2f, 3.0f, "%.2f");
                        prop("Bloom", "Glow around bright things like the sun");
                        ImGui::Checkbox("##bloom", &rs.bloom);
                        ImGui::SameLine();
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        ImGui::BeginDisabled(!rs.bloom);
                        sliderFloat("##bloomi", &rs.bloomIntensity, 0.0f, 1.5f, "%.2f");
                        ImGui::EndDisabled();
                        prop("Contrast");
                        sliderFloat("##con", &rs.contrast, 0.7f, 1.5f, "%.2f");
                        prop("Saturation");
                        sliderFloat("##sat", &rs.saturation, 0.0f, 2.0f, "%.2f");
                        prop("Temperature", "Cool (blue) to warm (orange)");
                        sliderFloat("##temp", &rs.temperature, -1.0f, 1.0f, "%.2f");
                        prop("Vignette");
                        sliderFloat("##vig", &rs.vignette, 0.0f, 1.0f, "%.2f");
                        prop("Anti-aliasing", "FXAA: smooths jagged edges");
                        ImGui::Checkbox("##fxaa", &rs.fxaa);
                        endProps();
                    }
                    if (ImGui::Button("Reset Look to Defaults", ImVec2(-FLT_MIN, 0))) {
                        const glm::vec3 sun = rs.sunDirection;
                        rs = RenderSettings{};
                        rs.sunDirection = sun;
                    }

                    section("Materials");
                    if (beginProps("##surf")) {
                        prop("Texture size", "Metres covered by one repeat of a texture");
                        sliderFloat("##texscale", &rs.textureScale, 1.0f, 12.0f, "%.1f m");
                        prop("Bumpiness", "Strength of the surface detail lighting");
                        sliderFloat("##bump", &rs.normalStrength, 0.0f, 2.0f, "%.2f");
                        endProps();
                    }
                    if (ImGui::TreeNode("Tint each material")) {
                        if (beginProps("##tints")) {
                            for (int l = 0; l < kMaterialSlots; ++l) {
                                ImGui::PushID(l);
                                prop(materialInfo(MaterialId(l + 1)).name, "Tint (white = original colours)");
                                ImGui::ColorEdit3("##tint", &rs.materialTint[l].x, ImGuiColorEditFlags_NoInputs);
                                ImGui::PopID();
                            }
                            endProps();
                        }
                        ImGui::TreePop();
                    }
                    section("Trees");
                    if (beginProps("##trees")) {
                        prop("Trees", "Oaks, pines, birches and bushes the world grows on grass: forests in places, a lone tree in the meadows");
                        ImGui::Checkbox("##treesOn", &rs.trees);
                        ImGui::BeginDisabled(!rs.trees);
                        prop("How many", "Thins the forests out (or fills them back in) without moving a single tree");
                        sliderFloat("##tdens", &rs.treeDensity, 0.0f, 1.0f, "%.2f");
                        prop("Draw distance");
                        sliderFloat("##tdist", &rs.treeDistance, 40.0f, 400.0f, "%.0f m");
                        ImGui::EndDisabled();
                        endProps();
                    }
                    section("Grass & Wind");
                    if (beginProps("##grass")) {
                        prop("Grass", "Instanced blades and flowers on grass surfaces");
                        ImGui::Checkbox("##grassOn", &rs.grass);
                        ImGui::BeginDisabled(!rs.grass);
                        prop("Density");
                        sliderFloat("##gdens", &rs.grassDensity, 0.05f, 1.0f, "%.2f");
                        prop("Draw distance");
                        sliderFloat("##gdist", &rs.grassDistance, 20.0f, 160.0f, "%.0f m");
                        prop("Blade height");
                        sliderFloat("##gh", &rs.grassHeight, 0.3f, 2.5f, "%.2f");
                        ImGui::EndDisabled();
                        prop("Wind strength");
                        sliderFloat("##wstr", &rs.windStrength, 0.0f, 3.0f, "%.2f");
                        prop("Wind speed");
                        sliderFloat("##wspd", &rs.windSpeed, 0.0f, 3.0f, "%.2f");
                        prop("Wind direction", "Compass heading the wind blows toward");
                        sliderFloat("##whead", &rs.windHeading, 0.0f, 360.0f, "%.0f deg");
                        endProps();
                    }

                    section("Water");
                    if (beginProps("##water")) {
                        prop("Clarity", "How far you can see into the water");
                        sliderFloat("##clarity", &rs.waterClarity, 2.0f, 40.0f, "%.0f m");
                        prop("Waves", "Wave height");
                        sliderFloat("##waves", &rs.waveStrength, 0.0f, 3.0f, "%.2f");
                        prop("Wave speed");
                        sliderFloat("##wspeed", &rs.waveSpeed, 0.0f, 3.0f, "%.2f");
                        prop("Foam");
                        sliderFloat("##foam", &rs.foam, 0.0f, 1.0f, "%.2f");
                        prop("Shallow colour");
                        ImGui::ColorEdit3("##wshallow", &rs.waterShallow.x, ImGuiColorEditFlags_NoInputs);
                        prop("Deep colour");
                        ImGui::ColorEdit3("##wdeep", &rs.waterDeep.x, ImGuiColorEditFlags_NoInputs);
                        endProps();
                    }
                    pushFont(fonts.small);
                    ImGui::TextDisabled("Sea level itself is a world setting (World panel).");
                    popFont();

                    section("Sound");
                    if (beginProps("##snd")) {
                        prop("Ambience", "Beds the world is playing right now. They follow where you are: altitude, shore, caves, time of day.");
                        ImGui::Checkbox("##ambon", &ambience.enabled);
                        static const struct { const char* id; const char* label; } beds[] = {
                            { "wind", "Wind" }, { "wind_strong", "Gale" }, { "water_lap", "Water" },
                            { "cave", "Cave" }, { "day_air", "Daytime" }, { "crickets", "Night" } };
                        for (auto& b : beds) {
                            prop(b.label);
                            ImGui::ProgressBar(std::min(1.0f, ambience.level(b.id) * 1.4f), ImVec2(-1, 8 * s), "");
                        }
                        prop("Voices", "Sounds playing right now (64 max).");
                        ImGui::Text("%d / %d", audio.activeVoices(), AudioEngine::kMaxVoices);
                        endProps();
                    }
                    if (!audio.deviceOpen()) {
                        pushFont(fonts.small);
                        ImGui::TextDisabled("No sound device: audio is silent on this machine.");
                        popFont();
                    }

                    section("Debug");
                    if (beginProps("##dbg")) {
                        prop("Wireframe");
                        ImGui::Checkbox("##wire", &rs.wireframe);
                        endProps();
                    }
                    ImGui::End();
                }

                // ---------------- the game's own panel (e.g. Vanguard's Character tab)
                if (game) {
                    const std::string title = std::string(game->name()) + "###game";
                    if (detailsDock) ImGui::SetNextWindowDockID(detailsDock, ImGuiCond_FirstUseEver);   // a game opened after the layout was made
                    if (beginPanel(title.c_str(), &showGamePanel, forceInspectorTab >= kFirstGameTab)) {
                        if (ImGui::BeginTabBar("##gametabs")) { game->drawInspectorTabs(*this); ImGui::EndTabBar(); }
                        ImGui::End();
                    }
                }

                // ---------------- the shelf and the kits (editor/Shell.cpp, editor/KitTools.cpp). Shaping the ground has
                // nothing to put on a shelf: leaving them out hands their space to the 3D view.
                static bool shelfWasShown = true;
                if (editMode != EditMode::Shape) {
                    if (!shelfWasShown) shelfFront = 3;          // back from Shape mode: the shelf in front, not the kits
                    drawShelf();
                    drawKitPanel();
                    if (shelfFront > 0) --shelfFront;
                }
                shelfWasShown = editMode != EditMode::Shape;
            }
            drawBlueprintWindow();
            drawCrowdWindow();
            drawGameRulesWindow();
            drawShareWindow();
        }
        forceInspectorTab = -1;
        if (settleFrames > 0) --settleFrames;
    }

    // ------------------------------------------------ viewport overlays
    const float vx0 = viewRect.x;
    drawToasts(toasts, top + 54 * s);
    drawViewportControls();
    drawContextBar();
    drawQuickWheel();

    if (showShortcutList) {
        struct Hint { const char* keys; const char* what; };
        const Hint brushHints[] = {
            { "RMB", "Look + fly  (WASD, Q/E)" }, { "LMB", "Use tool" }, { "Wheel", "Brush size" },
            { "1-7", "Shaping tools" }, { "[ ]", "Brush size" }, { "Ctrl+Z", "Undo" }, { "Ctrl+K", "Find anything" },
            { "Tab", "Play" }, { "H", "Hide UI" }, { "F1", "Hide this list" },
        };
        const Hint selectHints[] = {
            { "RMB", "Look + fly  (WASD, Q/E)" }, { "LMB", "Select / drag handles" }, { "W E R", "Move / Turn / Size" },
            { "X", "World or local axes" }, { "F", "Focus selection" }, { "Del", "Delete" }, { "Ctrl+D", "Duplicate" },
            { "Space", "Quick wheel (hold)" }, { "V P K B", "Select, Place, Kits, Blueprint" }, { "G", "Gadgets" },
            { "Ctrl+Z", "Undo" }, { "Ctrl+K", "Find anything" }, { "Tab", "Play" }, { "F1", "Hide this list" },
        };
        const Hint* hints = tool == Tool::Select ? selectHints : brushHints;
        ImDrawList* fg = ImGui::GetBackgroundDrawList();
        pushFont(fonts.small);
        const float lineH = ImGui::GetFontSize() + 10 * s;
        const int n = tool == Tool::Select ? int(sizeof(selectHints) / sizeof(selectHints[0])) : int(sizeof(brushHints) / sizeof(brushHints[0]));
        const float boxW = 300 * s, boxH = lineH * n + 14 * s;
        const ImVec2 mn(vx0 + 12 * s, bottom - boxH - 12 * s);
        fg->AddRectFilled(mn, ImVec2(mn.x + boxW, mn.y + boxH), IM_COL32(11, 12, 16, 220), 9 * s);
        fg->AddRect(mn, ImVec2(mn.x + boxW, mn.y + boxH), col::border, 9 * s);
        float y = mn.y + 8 * s;
        for (int hi = 0; hi < n; ++hi) {
            const Hint& h = hints[hi];
            keyCap(fg, ImVec2(mn.x + 10 * s, y), h.keys, col::text);
            fg->AddText(ImVec2(mn.x + 86 * s, y + 2.5f * s), col::textDim, h.what);
            y += lineH;
        }
        popFont();
    }

    // ------------------------------------------------ modals
    drawSettingsModal(*this);

    if (openRecovery) { ImGui::OpenPopup("Recover your work?"); openRecovery = false; }
    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("Recover your work?", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("Spire Engine did not close properly last time.");
        if (recovery) ImGui::Text("There is an autosave from %s, newer than your saved world.", recovery->label.c_str());
        ImGui::Dummy(ImVec2(0, 6 * s));
        if (primaryButton("Recover autosave", ImVec2(0, 0))) { if (recovery) cmdOpenAutosave(recovery->path); recovery.reset(); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine();
        if (ImGui::Button("Keep saved world")) { recovery.reset(); ImGui::CloseCurrentPopup(); }
        pushFont(fonts.small);
        ImGui::TextDisabled("Recovering loads the autosave. Nothing is overwritten until you save.");
        popFont();
        ImGui::EndPopup();
    }

    if (openSaveLayout) { ImGui::OpenPopup("Save layout"); openSaveLayout = false; }
    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("Save layout", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("Name this panel layout:");
        if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        ImGui::SetNextItemWidth(280 * s);
        const bool enter = ImGui::InputText("##layoutname", layoutName, sizeof layoutName, ImGuiInputTextFlags_EnterReturnsTrue);
        ImGui::Dummy(ImVec2(0, 4 * s));
        if (primaryButton("Save", ImVec2(0, 0)) || enter) { saveLayoutAs(layoutName); ImGui::CloseCurrentPopup(); }
        ImGui::SameLine();
        if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
    if (openAbout) { ImGui::OpenPopup("About Spire Engine"); openAbout = false; }
    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("About Spire Engine", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        {
            const ImVec2 p = ImGui::GetCursorScreenPos();
            drawSpireMark(ImGui::GetWindowDrawList(), ImVec2(p.x + 10 * s, p.y + 42 * s), 42 * s, col::text);
            ImGui::PushFont(fonts.brand, 30 * s);
            ImGui::GetWindowDrawList()->AddText(ImVec2(p.x + 32 * s, p.y + 4 * s), col::text, "SPIRE");
            popFont();
            ImGui::Dummy(ImVec2(220 * s, 48 * s));
        }
        ImGui::TextDisabled("Spire Engine %s  \xC2\xB7  a voxel game engine by Black Spire Studios", kEngineVersion);
        if (game) ImGui::Text("Running game: %s", game->name());
        ImGui::Dummy(ImVec2(0, 6 * s));
        ImGui::TextUnformatted("C++20  |  SDL3  |  OpenGL 3.3  |  Dear ImGui  |  FastNoiseLite");
        ImGui::TextUnformatted("Fonts: Geist and Unbounded (SIL Open Font License)");
        ImGui::Dummy(ImVec2(0, 8 * s));
        if (primaryButton("Close")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }

    drawCommandPalette();
}

// ---- layout presets (DockBuilder). Window names are the dock ids: keep them stable.
void Application::buildLayout(unsigned dockIdU, Layout l) {
    const ImGuiID dockId = dockIdU;
    const float s = scale();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const ImVec2 size = vp->WorkSize.x > 200.0f ? vp->WorkSize : ImVec2(1280.0f, 720.0f);

    ImGui::DockBuilderRemoveNode(dockId);
    ImGui::DockBuilderAddNode(dockId, ImGuiDockNodeFlags_DockSpace);
    ImGui::DockBuilderSetNodeSize(dockId, size);

    ImGuiID center = dockId;
    const std::string gameTitle = game ? std::string(game->name()) + "###game" : std::string();
    struct Front { ImGuiID node; const char* window; };
    std::vector<Front> fronts;                               // the tab that should be in front in each node
    auto dockGame = [&](ImGuiID node) { if (game) ImGui::DockBuilderDockWindow(gameTitle.c_str(), node); };
    auto dockDetails = [&](ImGuiID node) {                   // what you look at most in front; the world's settings behind it
        detailsDock = node;
        ImGui::DockBuilderDockWindow("Details", node);
        ImGui::DockBuilderDockWindow("World", node);
        ImGui::DockBuilderDockWindow("Sky", node);
        dockGame(node);
    };
    auto dockShelf = [&](ImGuiID node) {
        ImGui::DockBuilderDockWindow("Shelf", node);
        ImGui::DockBuilderDockWindow("Kits", node);
    };
    const float shelfH = 206.0f * s;
    switch (l) {
    case Layout::Default: {
        // Right: the scene over the details. Under the 3D view: the shelf.
        const ImGuiID right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 360.0f * s / size.x, nullptr, &center);
        ImGuiID details = 0;
        const ImGuiID sceneNode = ImGui::DockBuilderSplitNode(right, ImGuiDir_Up, 0.34f, nullptr, &details);
        const ImGuiID shelf = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, shelfH / size.y, nullptr, &center);
        ImGui::DockBuilderDockWindow("Scene", sceneNode);
        dockDetails(details);
        dockShelf(shelf);
        fronts = { { details, "Details" }, { shelf, "Shelf" } };
        break;
    }
    case Layout::Stacked: {
        // Everything in one column on the right, the 3D view as big as it gets.
        const ImGuiID right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 380.0f * s / size.x, nullptr, &center);
        ImGuiID rest = 0, details = 0;
        const ImGuiID sceneNode = ImGui::DockBuilderSplitNode(right, ImGuiDir_Up, 0.28f, nullptr, &rest);
        const ImGuiID shelf = ImGui::DockBuilderSplitNode(rest, ImGuiDir_Down, 0.36f, nullptr, &details);
        ImGui::DockBuilderDockWindow("Scene", sceneNode);
        dockDetails(details);
        dockShelf(shelf);
        fronts = { { details, "Details" }, { shelf, "Shelf" } };
        break;
    }
    case Layout::TwoSides: {
        const ImGuiID leftSide = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 300.0f * s / size.x, nullptr, &center);
        const ImGuiID rightSide = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 340.0f * s / (size.x - 300.0f * s), nullptr, &center);
        const ImGuiID shelf = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, shelfH / size.y, nullptr, &center);
        ImGui::DockBuilderDockWindow("Scene", leftSide);
        dockDetails(rightSide);
        dockShelf(shelf);
        fronts = { { rightSide, "Details" }, { shelf, "Shelf" } };
        break;
    }
    case Layout::Objects: {
        // Left: what is in the world over what you can add. Right: the details.
        ImGuiID leftBottom = 0;
        const ImGuiID leftSide = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 300.0f * s / size.x, nullptr, &center);
        const ImGuiID leftTop = ImGui::DockBuilderSplitNode(leftSide, ImGuiDir_Up, 0.45f, nullptr, &leftBottom);
        const ImGuiID right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 340.0f * s / (size.x - 300.0f * s), nullptr, &center);
        ImGui::DockBuilderDockWindow("Scene", leftTop);
        dockShelf(leftBottom);
        dockDetails(right);
        fronts = { { right, "Details" }, { leftBottom, "Shelf" } };
        break;
    }
    case Layout::Count: break;
    }
    ImGui::DockBuilderFinish(dockId);
    // Panels join their node as they are first drawn, and the last one drawn would end up in front.
    // A window can only be focused (brought to the front of its tabs) once its node has a tab bar,
    // which is a frame later, so the panels ask for the front tab again for a few frames.
    settleFronts.clear();
    for (const Front& f : fronts) {
        if (ImGuiDockNode* n = ImGui::DockBuilderGetNode(f.node)) n->SelectedTabId = ImHashStr(f.window);
        settleFronts.push_back(f.window);
    }
    settleFrames = 4;
    // One close button per panel (on its tab) is enough; View > Panels brings them back.
    {
        std::vector<ImGuiDockNode*> stack;
        if (ImGuiDockNode* root = ImGui::DockBuilderGetNode(dockId)) stack.push_back(root);
        while (!stack.empty()) {
            ImGuiDockNode* n = stack.back(); stack.pop_back();
            for (ImGuiDockNode* c : n->ChildNodes) if (c) stack.push_back(c);
            if (n->IsLeafNode() && !n->IsCentralNode()) n->SetLocalFlags(n->LocalFlags | ImGuiDockNodeFlags_NoCloseButton | ImGuiDockNodeFlags_NoWindowMenuButton);
        }
    }

    // A fresh layout shows every panel again, with Details in front.
    showToolbar = showToolPanel = showWorldPanel = showEnvPanel = showGamePanel = true;
    showOutliner = showProperties = showAssets = showKits = true;
    forceInspectorTab = 0;
}

} // namespace px
