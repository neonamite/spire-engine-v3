#pragma once
// Small pieces the Workshop's two source files share (WorkshopTools.cpp: behaviour, WorkshopUI.cpp: drawing).
#include <utility>
#include <vector>
#include <glm/glm.hpp>
#include <imgui.h>
#include "editor/WorkshopSession.h"
#include "scene/Asset.h"
#include "workshop/Workshop.h"

namespace px::wsui {

const char* toolName(WTool t);
const char* toolKey(WTool t);
const char* toolBlurb(WTool t);
const char* shapeLabel(Shape s);

using Seg = std::pair<glm::vec3, glm::vec3>;
// The edges of a stamp's shape in asset space (what the ghost under the cursor is drawn from).
void shapeWire(const Stamp& s, std::vector<Seg>& out);

AssetPtr makeFloor();      // the studio floor: a big slab whose top is y = 0
AssetPtr makeFigure();     // a 1.8 m mannequin, for a sense of scale

// Projects points into the 3D view (window points) for overlays; lines are clipped at the camera's near plane.
struct View {
    glm::mat4 vp{ 1.0f };
    float x = 0, y = 0, w = 1, h = 1;
    bool point(const glm::vec3& p, ImVec2& out) const {
        const glm::vec4 c = vp * glm::vec4(p, 1.0f);
        if (c.w <= 0.02f) return false;
        out = ImVec2(x + (c.x / c.w * 0.5f + 0.5f) * w, y + (1.0f - (c.y / c.w * 0.5f + 0.5f)) * h);
        return true;
    }
    bool line(const glm::vec3& a, const glm::vec3& b, ImVec2& pa, ImVec2& pb) const {
        glm::vec4 ca = vp * glm::vec4(a, 1.0f), cb = vp * glm::vec4(b, 1.0f);
        const float nearW = 0.05f;
        if (ca.w < nearW && cb.w < nearW) return false;
        if (ca.w < nearW) ca = glm::mix(ca, cb, (nearW - ca.w) / (cb.w - ca.w));
        else if (cb.w < nearW) cb = glm::mix(cb, ca, (nearW - cb.w) / (ca.w - cb.w));
        pa = ImVec2(x + (ca.x / ca.w * 0.5f + 0.5f) * w, y + (1.0f - (ca.y / ca.w * 0.5f + 0.5f)) * h);
        pb = ImVec2(x + (cb.x / cb.w * 0.5f + 0.5f) * w, y + (1.0f - (cb.y / cb.w * 0.5f + 0.5f)) * h);
        return true;
    }
};

} // namespace px::wsui
