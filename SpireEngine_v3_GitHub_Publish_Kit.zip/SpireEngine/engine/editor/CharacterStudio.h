#pragma once
// The Character Studio (v0.18): a screen of its own, like the Asset Workshop, where you make a person: shape the body,
// pick colours and hair, swap parts for ones made in the Workshop, and watch them stand, walk, run, jump and hold things.
// The behaviour is in editor/CharacterStudio.cpp.
#include <string>
#include <vector>
#include "character/Animator.h"
#include "character/Character.h"
#include "core/Camera.h"
#include "scene/Asset.h"

namespace px {

enum class StudioMove : int { Stand, Walk, Run, Jump, Look, Count };
const char* studioMoveLabel(StudioMove m);

// Make a crowd (v0.19): a style, how many, how spread out. Each person is "crowd:<style>:<seed>", made the same every
// time the world loads, and each is different.
struct CrowdTool {
    bool open = false;
    int style = 1;                           // CrowdStyle
    int count = 12;
    float radius = 5.0f;
    std::uint32_t nextSeed = 1000;
    std::vector<ObjectId> last;              // the crowd just made (Try again swaps them for new people)
};

struct CharacterStudio {
    bool active = false;
    CharacterDef def;
    std::string originalName;                // the character this was opened from ("" for a new one)
    CharacterDef savedDef;                   // what was last saved (or opened): to know when there are changes
    std::vector<CharacterDef> undo, redo;
    CharacterDef sliderBefore;               // when a slider was grabbed: one undo step per drag
    int tab = 0;                             // 0 Body, 1 Look, 2 Clothes, 3 Personality, 4 Parts
    int tabForce = -1;                       // a tab to switch to on the next frame (demos, tests)
    Mood mood = Mood::Calm;                  // the preview's mood (not saved: a mood is a moment, not who they are)
    std::uint32_t surprise = 1;              // Surprise me: the next random person

    // ---- the preview
    CharacterAnimator anim;
    StudioMove move = StudioMove::Stand;
    std::string heldItem;                    // an item from the item library to hold ("" = empty hands)
    float clock = 0.0f;
    float turn = 0.0f;                       // the character's own turn on the turntable (degrees)

    // ---- the orbit camera
    glm::vec3 target{ 0.0f, 1.0f, 0.0f };
    float distance = 4.0f, yaw = -90.0f, pitch = -6.0f;
    bool orbiting = false, panning = false, turning = false;

    // ---- what the world editor looked like, put back when the Studio closes
    Camera savedCamera;
    float savedTime = 10.0f, savedShadowRange = 90.0f;
    bool savedTimeFlowing = true, savedShadows = true, savedUiHidden = false;

    // ---- dialogs
    bool askLeave = false;
    std::string afterLeave;                  // "close", "place", "new:<name>", "open:<name>" or "quit"
    AssetPtr floor;
};

} // namespace px
