// NPCs that live (v0.20): while you play, the people you placed get on with their day - they wander, patrol, keep
// watch, follow you, go to work - and react when you come close (a wave and a hello, backing away, running off, "Halt!").
// What they do is decided by character/Npc.* (pure, unit tested); this file gives them the world (the ground, walls,
// water, the time of day, you), moves their stand-ins, and draws their name tags and what they say. In the editor, the
// Behaviour section of Properties sets it all, and the selected person's range, path and work spot are drawn.
#include "core/Application.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <imgui.h>

namespace px {

using namespace ui;

namespace {
// Where the ground is under a step, and whether the step can be taken (not up a wall, not off a cliff, not into deep water,
// not through an object).
struct StepProbe {
    const ChunkManager& world;
    const Scene& scene;
    float water;
    bool operator()(const glm::vec3& from, const glm::vec3& to, float& gy) const {
        const glm::vec3 top(to.x, from.y + 1.2f, to.z);
        RayHit h;
        float best = -1e9f;
        if (world.raycast(top, glm::vec3(0, -1, 0), 3.0f, h)) best = h.position.y;
        Scene::Hit sh;
        if (scene.raycast(top, glm::vec3(0, -1, 0), 3.0f, sh, false, true)) best = std::max(best, sh.point.y);
        if (best < -1e8f) return false;                          // a drop with no bottom near
        if (best > from.y + 0.6f || best < from.y - 1.2f) return false;   // a wall, or a cliff
        if (best < water - 0.5f) return false;                   // deep water
        // something in the way at knee and chest height
        glm::vec3 d = to - from; d.y = 0.0f;
        const float len = glm::length(d);
        if (len > 1e-4f) {
            d /= len;
            for (float hgt : { 0.7f, 1.3f }) {
                const glm::vec3 o(from.x, std::max(from.y, best) + hgt, from.z);
                if (scene.raycast(o, d, len + 0.3f, sh, false, true)) return false;
                if (world.raycast(o, d, len + 0.3f, h)) return false;
            }
        }
        gy = best;
        return true;
    }
};

struct Projector {
    glm::mat4 vp;
    float x, y, w, h;
    bool operator()(const glm::vec3& p, ImVec2& out) const {
        const glm::vec4 c = vp * glm::vec4(p, 1.0f);
        if (c.w <= 0.05f) return false;
        out = ImVec2(x + (c.x / c.w * 0.5f + 0.5f) * w, y + (1.0f - (c.y / c.w * 0.5f + 0.5f)) * h);
        return true;
    }
};
} // namespace

NpcSettings Application::npcSettingsOf(ObjectId id) const {
    NpcSettings s;
    if (const SceneObject* o = scene.find(id)) npcFromText(o->npc, s);
    return s;
}

void Application::setNpcSettings(ObjectId id, const NpcSettings& in, const std::string& undoLabel) {
    SceneObject* o = scene.mutate(id);
    if (!o) return;
    NpcSettings s = in;
    s.clamp();
    o->npc = npcToText(s);
    commitScene(undoLabel);
}

const NpcState* Application::npcStateOf(ObjectId id) const {
    const auto it = npcLive.find(id);
    return it == npcLive.end() ? nullptr : &it->second.state;
}

void Application::stopNpcs() {
    npcLive.clear();
    scene.clearLive();
}

void Application::updateNpcs(float dt) {
    if (npcsFrozen) return;                                      // screenshots: everyone holds still, mid-sentence
    // Everyone with a character, at the top level (people inside groups stay put).
    std::vector<ObjectId> people;
    for (const SceneObject& o : scene.objects())
        if (!o.character.empty() && o.parent == 0 && o.visible) people.push_back(o.id);
    for (auto it = npcLive.begin(); it != npcLive.end();) {
        if (!scene.find(it->first)) it = npcLive.erase(it); else ++it;
    }
    const StepProbe probe{ world, scene, player.waterLevel };
    std::vector<glm::vec3> where;
    where.reserve(people.size());
    for (ObjectId id : people) { auto it = npcLive.find(id); where.push_back(it != npcLive.end() ? it->second.state.position : scene.find(id)->position); }
    for (size_t i = 0; i < people.size(); ++i) {
        const SceneObject& o = *scene.find(people[i]);
        NpcLive& live = npcLive[o.id];
        if (live.text != o.npc || !live.state.started) {                 // new, or changed while playing
            live.text = o.npc;
            live.settings = NpcSettings();
            if (!o.npc.empty()) npcFromText(o.npc, live.settings);
            else live.settings.reaction = NpcReaction::Ignore;          // people with no behaviour just stand and look
        }
        NpcInput in;
        in.home = o.position;
        in.homeYaw = o.rotation.y;
        in.hasPlayer = true;
        in.player = player.position;
        in.hour = timeOfDay;
        in.dt = dt;
        in.seed = o.id;
        in.step = probe;
        for (size_t k = 0; k < people.size(); ++k)
            if (k != i && glm::length(where[k] - where[i]) < 2.0f) in.others.push_back(where[k]);
        npcUpdate(live.settings, live.state, in);
        where[i] = live.state.position;
        scene.setLive(o.id, live.state.position, live.state.yaw);
    }
}

bool Application::npcPickClick() {
    const SceneObject* o = scene.find(npcPicking);
    if (!o) { npcPicking = 0; return false; }
    glm::vec3 pos, n;
    if (!findPlacementSpot(pos, n)) { toast("Point at the ground", Toast::Kind::Warning); return true; }
    NpcSettings s = npcSettingsOf(npcPicking);
    if (npcPickingWork) {
        s.hasWorkSpot = true; s.workSpot = pos;
        if (s.role != NpcRole::Work && s.schedule.empty()) s.role = NpcRole::Work;
        setNpcSettings(npcPicking, s, "Set " + o->name + "'s work spot");
        npcPicking = 0;
        toast("Work spot set");
    } else {
        s.path.push_back(pos);
        if (s.role != NpcRole::Patrol && s.schedule.empty()) s.role = NpcRole::Patrol;
        setNpcSettings(npcPicking, s, "Add a point to " + o->name + "'s path");
    }
    return true;
}

// ---------------------------------------------------------------- what you see

void Application::drawNpcOverlay() {
    const bool playing = mode == Mode::Play;
    if (mode == Mode::Hub || inCharacterStudio() || inWorkshop()) return;
    const ImGuiIO& io = ImGui::GetIO();
    const float s = scale();
    Projector proj;
    if (playing) { proj.x = 0; proj.y = 0; proj.w = io.DisplaySize.x; proj.h = io.DisplaySize.y; }
    else { proj.x = viewRect.x; proj.y = viewRect.y; proj.w = std::max(1.0f, viewRect.w); proj.h = std::max(1.0f, viewRect.h); }
    proj.vp = camera.projection(proj.w / proj.h) * camera.view();
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const glm::vec3 eye = playing ? player.eye() : camera.position;

    // ---- the selected person's range, path and work spot (editor)
    if (!playing && !uiHidden) {
        for (ObjectId id : selection) {
            const SceneObject* o = scene.find(id);
            if (!o || o->character.empty()) continue;
            const NpcSettings st = npcSettingsOf(id);
            auto ring = [&](const glm::vec3& c, float r, ImU32 colour) {
                for (int i = 0; i <= 64; ++i) {
                    const float a = float(i) / 64.0f * 6.2831853f;
                    ImVec2 p;
                    if (!proj(c + glm::vec3(std::cos(a) * r, 0.08f, std::sin(a) * r), p)) { dl->PathClear(); return; }
                    dl->PathLineTo(p);
                }
                dl->PathStroke(colour, 0, 1.6f * s);
            };
            const NpcRole role = st.role;
            if (!o->npc.empty() && (role == NpcRole::Wander || role == NpcRole::Guard || role == NpcRole::Follow))
                ring(o->position, st.radius, role == NpcRole::Guard ? IM_COL32(255, 110, 90, 200) : IM_COL32(120, 200, 255, 190));
            if (!o->npc.empty() && st.reaction != NpcReaction::Ignore) ring(o->position, st.notice, IM_COL32(255, 220, 120, 110));
            for (size_t i = 0; i < st.path.size(); ++i) {
                ImVec2 a, b;
                const glm::vec3 p = st.path[i] + glm::vec3(0, 0.1f, 0), q = st.path[(i + 1) % st.path.size()] + glm::vec3(0, 0.1f, 0);
                if (st.path.size() > 1 && proj(p, a) && proj(q, b)) dl->AddLine(a, b, IM_COL32(120, 255, 160, 200), 2.0f * s);
                if (proj(p, a)) {
                    dl->AddCircleFilled(a, 6.0f * s, IM_COL32(40, 170, 90, 230));
                    char n[16]; std::snprintf(n, sizeof n, "%d", int(i) + 1);
                    dl->AddText(ImVec2(a.x - 3.5f * s, a.y - 7.0f * s), IM_COL32(255, 255, 255, 255), n);
                }
            }
            if (st.hasWorkSpot) {
                ImVec2 a;
                if (proj(st.workSpot + glm::vec3(0, 0.1f, 0), a)) {
                    dl->AddRectFilled(ImVec2(a.x - 6 * s, a.y - 6 * s), ImVec2(a.x + 6 * s, a.y + 6 * s), IM_COL32(230, 160, 40, 230), 2.0f * s);
                    dl->AddText(ImVec2(a.x + 9 * s, a.y - 8 * s), IM_COL32(255, 230, 180, 255), "work");
                }
            }
        }
        if (npcPicking) {
            pushFont(fonts.small);
            const char* hint = npcPickingWork ? "Click where they work.  Esc to stop." : "Click to add points to the path.  Esc or right-click when done.";
            const ImVec2 ts = ImGui::CalcTextSize(hint);
            const ImVec2 at(viewRect.x + (viewRect.w - ts.x) * 0.5f, viewRect.y + 40 * s);
            dl->AddRectFilled(ImVec2(at.x - 10 * s, at.y - 6 * s), ImVec2(at.x + ts.x + 10 * s, at.y + ts.y + 6 * s), IM_COL32(20, 24, 32, 220), 8 * s);
            dl->AddText(at, IM_COL32(255, 255, 255, 240), hint);
            popFont();
        }
    }

    // ---- name tags and what they are saying
    if (!showNameTags) return;
    pushFont(fonts.small);
    for (const Evaluated& e : scene.evaluated()) {
        const SceneObject& o = scene.objects()[size_t(e.index)];
        if (o.character.empty() || !e.visible || o.npc.empty()) continue;
        const NpcLive* live = nullptr;
        if (auto it = npcLive.find(o.id); it != npcLive.end()) live = &it->second;
        NpcSettings st;
        if (live) st = live->settings; else npcFromText(o.npc, st);
        const bool talking = live && !live->state.speech.empty();
        if (!st.nameTag && !talking) continue;
        const float height = 1.8f * e.scale;
        const glm::vec3 head = glm::vec3(e.world[3]) + glm::vec3(0.0f, height + 0.14f, 0.0f);
        const float dist = glm::length(head - eye);
        if (dist > (talking ? 22.0f : 14.0f)) continue;
        ImVec2 p;
        if (!proj(head, p)) continue;
        if (p.x < proj.x || p.x > proj.x + proj.w || p.y < proj.y || p.y > proj.y + proj.h) continue;
        const float fade = std::clamp((14.0f - dist) / 4.0f, 0.0f, 1.0f);
        if (st.nameTag && fade > 0.0f) {
            const std::string& name = o.name;
            const ImVec2 ts = ImGui::CalcTextSize(name.c_str());
            const ImVec2 a(p.x - ts.x * 0.5f - 6 * s, p.y - ts.y - 4 * s), b(p.x + ts.x * 0.5f + 6 * s, p.y);
            dl->AddRectFilled(a, b, IM_COL32(16, 18, 24, int(150 * fade)), 6 * s);
            dl->AddText(ImVec2(p.x - ts.x * 0.5f, p.y - ts.y - 2 * s), IM_COL32(255, 255, 255, int(235 * fade)), name.c_str());
            p.y -= ts.y + 8 * s;
        }
        if (talking) {
            const std::string& text = live->state.speech;
            const float wrap = 220 * s;
            const ImVec2 ts = ImGui::CalcTextSize(text.c_str(), nullptr, false, wrap);
            const ImVec2 a(p.x - ts.x * 0.5f - 10 * s, p.y - ts.y - 16 * s), b(p.x + ts.x * 0.5f + 10 * s, p.y - 6 * s);
            const int alpha = int(240 * std::clamp(live->state.speechLeft / 0.4f, 0.0f, 1.0f));
            dl->AddRectFilled(a, b, IM_COL32(250, 250, 246, alpha), 10 * s);
            dl->AddTriangleFilled(ImVec2(p.x - 7 * s, b.y), ImVec2(p.x + 7 * s, b.y), ImVec2(p.x, b.y + 8 * s), IM_COL32(250, 250, 246, alpha));
            dl->AddText(nullptr, 0.0f, ImVec2(a.x + 10 * s, a.y + 5 * s), IM_COL32(20, 22, 28, alpha), text.c_str(), nullptr, wrap);
        }
    }
    popFont();
}

// ---------------------------------------------------------------- the Behaviour section of Properties

void Application::drawNpcPanel(ObjectId id) {
    const SceneObject* o = scene.find(id);
    if (!o || o->character.empty()) return;
    const float s = scale();
    const bool has = !o->npc.empty();
    if (!has) {
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextDisabled("They stand where you put them. Give them something to do and they will do it while you play.");
        ImGui::PopTextWrapPos();
        if (ImGui::Button("Give them a life", ImVec2(-FLT_MIN, 0))) {
            NpcSettings st;
            st.role = NpcRole::Wander;
            st.lines = { "Hello there!", "Lovely day, isn't it?" };
            setNpcSettings(id, st, "Give " + o->name + " a life");
        }
        return;
    }
    NpcSettings st = npcSettingsOf(id);
    const NpcSettings before = st;
    bool changed = false, liveWrite = false;
    std::string label = "Change " + o->name + "'s behaviour";
    auto chips = [&](const char* idTag, int count, int selected, const char* (*name)(int), const char* (*hint)(int)) {
        int hit = -1;
        float x = 0.0f;
        const float avail = ImGui::GetContentRegionAvail().x;
        ImGui::PushID(idTag);
        for (int i = 0; i < count; ++i) {
            const char* l = name(i);
            const float w = ImGui::CalcTextSize(l).x + ImGui::GetStyle().FramePadding.x * 2.0f;
            if (i && x + 4 * s + w <= avail) { ImGui::SameLine(0, 4 * s); x += 4 * s; } else x = 0.0f;
            x += w;
            const bool on = i == selected;
            if (on) pushSelectedButton();
            ImGui::PushID(i);
            if (ImGui::Button(l)) hit = i;
            if (ImGui::IsItemHovered() && hint) ImGui::SetTooltip("%s", hint(i));
            ImGui::PopID();
            if (on) popSelectedButton();
        }
        ImGui::PopID();
        return hit;
    };
    ImGui::TextDisabled("What they do");
    if (const int h = chips("role", int(NpcRole::Count), int(st.role), [](int i) { return npcRoleLabel(NpcRole(i)); }, [](int i) { return npcRoleHint(NpcRole(i)); }); h >= 0) {
        st.role = NpcRole(h); changed = true;
    }
    ImGui::TextDisabled("When you come close");
    if (const int h = chips("reaction", int(NpcReaction::Count), int(st.reaction), [](int i) { return npcReactionLabel(NpcReaction(i)); }, [](int i) { return npcReactionHint(NpcReaction(i)); }); h >= 0) {
        st.reaction = NpcReaction(h); changed = true;
    }
    if (beginProps("##npcprops", 96.0f)) {
        auto slider = [&](const char* lab, const char* tip, float* v, float lo, float hi, const char* fmt) {
            prop(lab, tip);
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::SliderFloat((std::string("##npc") + lab).c_str(), v, lo, hi, fmt)) liveWrite = true;
            if (ImGui::IsItemDeactivatedAfterEdit()) changed = true;
        };
        slider(st.role == NpcRole::Guard ? "Watch" : "Range", "How far they wander, how much ground a guard watches, how far a follower comes", &st.radius, 1.0f, 40.0f, "%.1f m");
        slider("Notice", "How close you come before they react", &st.notice, 1.0f, 15.0f, "%.1f m");
        slider("Speed", "How quickly they walk", &st.speed, 0.4f, 2.0f, "%.2fx");
        prop("Name tag", "Their name over their head");
        if (ImGui::Checkbox("##npcname", &st.nameTag)) changed = true;
        endProps();
    }
    // what they say
    ImGui::TextDisabled("What they say (one line each time you meet)");
    {
        static char buf[1024];
        static ObjectId bufFor = 0;
        static std::string bufText;
        std::string joined;
        for (size_t i = 0; i < st.lines.size(); ++i) { if (i) joined += "\n"; joined += st.lines[i]; }
        if (bufFor != id || (!ImGui::IsAnyItemActive() && bufText != joined)) {
            std::snprintf(buf, sizeof buf, "%s", joined.c_str());
            bufFor = id; bufText = joined;
        }
        ImGui::InputTextMultiline("##npclines", buf, sizeof buf, ImVec2(-FLT_MIN, 70 * s));
        if (ImGui::IsItemDeactivatedAfterEdit()) {
            st.lines.clear();
            const char* p = buf;
            while (*p) {
                const char* e = std::strchr(p, '\n');
                std::string line = e ? std::string(p, size_t(e - p)) : std::string(p);
                while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
                if (!line.empty()) st.lines.push_back(line);
                if (!e) break;
                p = e + 1;
            }
            bufText.clear();
            changed = true; label = "Change what " + o->name + " says";
        }
    }
    // the path and the work spot
    ImGui::Dummy(ImVec2(0, 2 * s));
    {
        const float w = (ImGui::GetContentRegionAvail().x - 6 * s) * 0.5f;
        const bool pickingPath = npcPicking == id && !npcPickingWork;
        if (pickingPath) pushSelectedButton();
        char pl[48]; std::snprintf(pl, sizeof pl, pickingPath ? "Done (%d points)" : "Path: %d points...", int(st.path.size()));
        if (ImGui::Button(pl, ImVec2(w, 0))) { if (pickingPath) npcPicking = 0; else { npcPicking = id; npcPickingWork = false; } }
        if (pickingPath) popSelectedButton();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Click in the world to add the points of a patrol path");
        ImGui::SameLine(0, 6 * s);
        const bool pickingWork = npcPicking == id && npcPickingWork;
        if (pickingWork) pushSelectedButton();
        if (ImGui::Button(st.hasWorkSpot ? "Move work spot..." : "Set work spot...", ImVec2(-FLT_MIN, 0))) { npcPicking = pickingWork ? 0 : id; npcPickingWork = true; }
        if (pickingWork) popSelectedButton();
        if (!st.path.empty() && ImGui::SmallButton("Clear the path")) { st.path.clear(); changed = true; label = "Clear " + o->name + "'s path"; }
        if (st.hasWorkSpot) { if (!st.path.empty()) ImGui::SameLine(); if (ImGui::SmallButton("Clear the work spot")) { st.hasWorkSpot = false; changed = true; } }
    }
    // the day
    ImGui::Dummy(ImVec2(0, 2 * s));
    ImGui::TextDisabled("Their day (empty: always the same)");
    int remove = -1;
    for (size_t i = 0; i < st.schedule.size(); ++i) {
        ImGui::PushID(int(i));
        NpcScheduleItem& it = st.schedule[i];
        ImGui::SetNextItemWidth(90 * s);
        int hh = int(it.hour), mm = int(std::round((it.hour - float(hh)) * 60.0f / 15.0f)) * 15;
        if (mm >= 60) { mm = 0; ++hh; }
        char t[16]; std::snprintf(t, sizeof t, "%02d:%02d", hh % 24, mm);
        float hour = it.hour;
        if (ImGui::SliderFloat("##h", &hour, 0.0f, 23.75f, t)) { it.hour = std::round(hour * 4.0f) / 4.0f; liveWrite = true; }
        if (ImGui::IsItemDeactivatedAfterEdit()) changed = true;
        ImGui::SameLine(0, 4 * s);
        ImGui::SetNextItemWidth(-30 * s);
        if (ImGui::BeginCombo("##r", npcRoleLabel(it.role))) {
            for (int r = 0; r < int(NpcRole::Count); ++r) if (ImGui::Selectable(npcRoleLabel(NpcRole(r)), it.role == NpcRole(r))) { it.role = NpcRole(r); changed = true; }
            ImGui::EndCombo();
        }
        ImGui::SameLine(0, 4 * s);
        if (ImGui::Button("x", ImVec2(-FLT_MIN, 0))) remove = int(i);
        ImGui::PopID();
    }
    if (remove >= 0) { st.schedule.erase(st.schedule.begin() + remove); changed = true; }
    if (ImGui::Button("Add a time", ImVec2(-FLT_MIN, 0))) {
        NpcScheduleItem it;
        it.hour = st.schedule.empty() ? 8.0f : std::fmod(st.schedule.back().hour + 4.0f, 24.0f);
        it.role = st.schedule.empty() ? NpcRole::Work : NpcRole::Wander;
        if (st.schedule.empty()) st.schedule.push_back({ 8.0f, NpcRole::Work }), st.schedule.push_back({ 12.0f, NpcRole::Wander }), st.schedule.push_back({ 18.0f, NpcRole::Stand });
        else st.schedule.push_back(it);
        changed = true; label = "Change " + o->name + "'s day";
    }
    if (const NpcState* live = npcStateOf(id)) ImGui::TextDisabled("Now: %s", npcActivityLabel(live->activity));
    else if (!st.schedule.empty()) ImGui::TextDisabled("At %02d:%02d they %s", int(timeOfDay), int(std::fmod(timeOfDay, 1.0f) * 60.0f), npcRoleLabel(npcRoleAt(st, timeOfDay)));
    if (ImGui::SmallButton("Stop their behaviour")) { SceneObject* m = scene.mutate(id); m->npc.clear(); commitScene("Stop " + o->name + "'s behaviour"); return; }
    if (liveWrite && !changed) { NpcSettings c = st; c.clamp(); scene.mutate(id)->npc = npcToText(c); }   // while dragging: no undo step yet
    if (changed) setNpcSettings(id, st, label);
    (void)before;
}

} // namespace px
