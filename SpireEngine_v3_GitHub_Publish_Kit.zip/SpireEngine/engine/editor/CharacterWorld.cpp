// Characters in the world (v0.18): people you place (standing, breathing, looking at whoever comes near, with their feet on
// the real ground), and you yourself in third person (V in play mode), walking, running, jumping and holding your item.
#include "core/Application.h"
#include "character/BodyParts.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {
// The ground under a point for foot IK: the terrain and whatever objects stand there, looked for a little above and below.
struct GroundProbe {
    const ChunkManager& world;
    const Scene& scene;
    float around;
    bool operator()(float x, float z, float& y) const {
        const glm::vec3 from(x, around + 0.9f, z);
        RayHit h;
        float best = -1e9f;
        if (world.raycast(from, glm::vec3(0, -1, 0), 2.0f, h)) best = h.position.y;
        Scene::Hit sh;                                   // objects too (a floor in a house), but not people: their stand-ins are not ground
        if (scene.raycast(from, glm::vec3(0, -1, 0), 2.0f, sh, false, true)) best = std::max(best, sh.point.y);
        if (best < -1e8f) return false;
        y = best;
        return true;
    }
};
} // namespace

const CharacterDef* Application::characterOf(ObjectId id) const {
    const SceneObject* o = scene.find(id);
    return o && !o->character.empty() ? characters.find(o->character) : nullptr;
}

void Application::setPlayerCharacter(const std::string& name) {
    playerCharacter = name;
    toast("You will look like " + characters.get(name).name + " in third person (V while playing)", Toast::Kind::Success);
}

HoldKind Application::holdKindFor(const ItemDef* item) {
    if (!item) return HoldKind::None;
    switch (item->behaviour) {
    case Behaviour::Melee: return HoldKind::Melee;
    case Behaviour::Thrown: case Behaviour::Tool: return HoldKind::OneHand;
    default: break;
    }
    // Guns: a small one in one hand, a long one in two.
    const AssetPtr a = assets.get(item->asset);
    const glm::vec3 e = a ? a->extent() : glm::vec3(0.0f);
    return std::max(e.x, e.z) < 0.5f ? HoldKind::OneHand : HoldKind::TwoHand;
}

void Application::startPlacingCharacter(const std::string& name) {
    if (!characters.has(name)) { toast("There is no character called " + name, Toast::Kind::Warning); return; }
    startPlacing(kCharacterStandIn);
    placingCharacter = name;
    toast("Click in the world to put " + name + " there.  Wheel turns them, Esc stops.");
}

ObjectId Application::placeCharacter(const std::string& name, const glm::vec3& at, float yawDegrees) {
    if (!characters.has(name) || !assets.get(kCharacterStandIn)) return 0;
    const CharacterDef def = characters.get(name);
    const CharacterDef* c = &def;
    SceneObject o;
    o.asset = kCharacterStandIn;
    o.character = name;
    o.name = def.name;                                    // a crowd person goes by their own name
    o.position = at;
    o.rotation = glm::vec3(0.0f, yawDegrees, 0.0f);
    o.scale = c->shape.height / 1.8f;                     // the stand-in (what you click and bump into) is as tall as they are
    const ObjectId id = scene.add(o);
    commitScene("Place " + scene.find(id)->name);
    selectObject(id);
    playSfxAt("stamp", at, 0.7f, 1.2f);
    return id;
}

void Application::characterWorldDraws(std::vector<ObjectDraw>& draws, float dt) {
    lastCharacterDraws = 0;
    const bool editing = mode == Mode::Editor;
    const glm::vec3 viewer = mode == Mode::Play ? player.eye() : camera.position;
    std::unordered_set<ObjectId> glow;
    if (editing) for (ObjectId id : selection) { glow.insert(id); for (ObjectId d : scene.descendants(id)) glow.insert(d); }

    for (const Evaluated& e : scene.evaluated()) {
        const SceneObject& o = scene.objects()[size_t(e.index)];
        if (o.character.empty() || !e.visible) continue;
        CharacterDef def = characters.get(o.character);
        def.shape.height = std::clamp(1.8f * e.scale, 0.5f, 3.0f);   // resized with the gizmo: the body follows
        const Skeleton sk = buildSkeleton(def.shape);
        const glm::vec3 pos(e.world[3]);
        glm::vec3 fwd = glm::vec3(e.world * glm::vec4(0, 0, 1, 0));
        fwd.y = 0.0f;
        if (glm::length(fwd) < 1e-4f) fwd = glm::vec3(0, 0, 1);
        CharacterAnimator& an = npcAnim[o.id];
        AnimInput in;
        in.position = pos;
        in.facing = glm::normalize(fwd);
        auto last = npcLastPos.find(o.id);
        if (last != npcLastPos.end() && dt > 1e-4f) {
            const glm::vec3 v = (pos - last->second) / dt;
            if (glm::length(v) < 20.0f) in.velocity = glm::vec3(v.x, 0.0f, v.z);   // an object with motion walks; a teleport does not
        }
        npcLastPos[o.id] = pos;
        // People look at whoever is close and in front of them.
        const glm::vec3 toViewer = viewer - pos;
        const NpcState* life = npcStateOf(o.id);
        const bool lookHere = life ? life->lookAtPlayer || glm::length(glm::vec2(toViewer.x, toViewer.z)) < 5.0f : glm::length(glm::vec2(toViewer.x, toViewer.z)) < 9.0f;
        if (lookHere && glm::dot(glm::normalize(glm::vec3(toViewer.x, 0.0f, toViewer.z) + glm::vec3(1e-4f, 0, 0)), in.facing) > -0.2f) {
            in.hasLook = true;
            in.lookAt = viewer;
        }
        if (life) {
            in.mood = life->mood;
            if (life->gesture != Fidget::None) an.startFidget(life->gesture, life->gesture == Fidget::Work ? 1e6f : 2.2f);
            else if (an.fidget() == Fidget::Work && life->activity != NpcActivity::Working) an.startFidget(Fidget::None, 0.0f);
        }
        in.ground = GroundProbe{ world, scene, pos.y };
        in.style = def.move;
        in.seed = std::uint32_t(o.id) * 2654435761u;
        an.update(sk, in, dt);
        glm::vec4 hl(0.0f);
        if (editing) {
            if (glow.count(o.id)) hl = glm::vec4(1.0f, 0.60f, 0.14f, 0.85f);
            else if (o.id == hoverObject) hl = glm::vec4(0.55f, 0.75f, 1.0f, 0.55f);
        }
        const size_t before = draws.size();
        characterDraws(def, sk, an.output(), assets, draws, hl);
        lastCharacterDraws += int(draws.size() - before);
    }
    // forget the animators of people who are gone
    for (auto it = npcAnim.begin(); it != npcAnim.end();) {
        if (!scene.find(it->first)) { npcLastPos.erase(it->first); it = npcAnim.erase(it); } else ++it;
    }

    // Placing someone: they stand where they will go, see-through blue.
    if (editing && ghostValid && !placingCharacter.empty()) {
        const CharacterDef def = characters.get(placingCharacter);
        const Skeleton sk = buildSkeleton(def.shape);
        static CharacterAnimator ghost;
        AnimInput in;
        in.position = ghostPos;
        in.facing = glm::vec3(std::sin(glm::radians(ghostYaw)), 0.0f, std::cos(glm::radians(ghostYaw)));
        in.style = def.move;
        in.idleFidgets = false;
        ghost.reset(ghostYaw);
        ghost.update(sk, in, 0.0f);
        characterDraws(def, sk, ghost.output(), assets, draws, glm::vec4(0.25f, 0.85f, 1.0f, 0.9f));
    }
}

void Application::updateThirdPersonCamera() {
    // Behind and a little to the right of your head, pulled in when a wall is in the way.
    const glm::vec3 head = player.position + glm::vec3(0.0f, player.eyeHeight * 0.95f, 0.0f);
    const glm::vec3 pivot = head + camera.right() * 0.45f;
    const glm::vec3 back = -camera.front();
    float dist = 3.2f;
    RayHit h;
    if (world.raycast(pivot, back, dist + 0.3f, h)) dist = std::max(0.4f, h.distance - 0.3f);
    Scene::Hit sh;
    if (scene.raycast(pivot, back, dist + 0.3f, sh)) dist = std::max(0.4f, std::min(dist, sh.distance - 0.3f));
    camera.position = pivot + back * dist;
}

void Application::drawPlayerBody(float dt) {
    CharacterDef def = characters.get(playerCharacter);
    const Skeleton sk = buildSkeleton(def.shape);
    const ItemDef* item = inventory.enabled ? inventory.currentDef() : nullptr;
    AnimInput in;
    in.position = player.position;
    in.velocity = player.velocity;
    in.grounded = player.grounded || player.swimming;
    in.hold = holdKindFor(item);
    in.aimPitch = camera.pitch;
    const glm::vec3 flat = camera.flatFront();
    const glm::vec2 hv(player.velocity.x, player.velocity.z);
    // Holding something: face where you aim. Otherwise: face where you are going.
    if (in.hold != HoldKind::None || glm::length(hv) < 0.3f) in.facing = in.hold != HoldKind::None ? flat : glm::vec3(std::sin(glm::radians(playerAnim.yaw())), 0.0f, std::cos(glm::radians(playerAnim.yaw())));
    else in.facing = glm::normalize(glm::vec3(hv.x, 0.0f, hv.y));
    if (playerAnimFresh) { playerAnim.reset(glm::degrees(std::atan2(flat.x, flat.z))); playerAnimFresh = false; }
    in.ground = GroundProbe{ world, scene, player.position.y };
    in.style = def.move;
    in.seed = 7;
    playerAnim.update(sk, in, dt);
    std::vector<ObjectDraw> draws;
    AssetPtr itemAsset = item ? assets.get(item->asset) : nullptr;
    characterDraws(def, sk, playerAnim.output(), assets, draws, glm::vec4(0.0f), itemAsset);
    lastCharacterDraws += int(draws.size());
    for (ObjectDraw& d : draws) renderer.addObject(std::move(d));
}

} // namespace px
