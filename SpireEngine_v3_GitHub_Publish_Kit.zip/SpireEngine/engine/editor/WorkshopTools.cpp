// The Asset Workshop's behaviour: opening and closing it, the orbit camera, the tools under the
// mouse, saving. Drawing it is editor/WorkshopUI.cpp. The model itself (voxels, stamps, undo,
// files) is workshop/Workshop.h and knows nothing about windows.
#include "core/Application.h"
#include "editor/ItemRange.h"
#include "editor/WorkshopCommon.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <glm/gtc/constants.hpp>

namespace px {

using namespace ui;

// ================================================================ names, shapes, scenery

namespace wsui {

const char* toolName(WTool t) {
    switch (t) {
    case WTool::Add: return "Add";
    case WTool::Carve: return "Carve";
    case WTool::Paint: return "Paint";
    case WTool::Smooth: return "Smooth";
    case WTool::Socket: return "Socket";
    case WTool::Count: break;
    }
    return "";
}
const char* toolKey(WTool t) {
    static const char* keys[] = { "1", "2", "3", "4", "5" };
    return t == WTool::Count ? "" : keys[int(t)];
}
const char* toolBlurb(WTool t) {
    switch (t) {
    case WTool::Add: return "Stick a shape onto the model. Click, or drag to draw with it.";
    case WTool::Carve: return "Cut a shape out of the model. Click, or drag to keep cutting.";
    case WTool::Paint: return "Change what it is made of without changing its shape.";
    case WTool::Smooth: return "Soften bumps and sharp edges. Hold and drag.";
    case WTool::Socket: return "Mark where things attach: a grip, a muzzle, a seat.";
    case WTool::Count: break;
    }
    return "";
}
const char* shapeLabel(Shape s) {
    switch (s) {
    case Shape::Box: return "Box";
    case Shape::Sphere: return "Sphere";
    case Shape::Cylinder: return "Cylinder";
    case Shape::Cone: return "Cone";
    case Shape::Wedge: return "Ramp";
    }
    return "Box";
}

void shapeWire(const Stamp& s, std::vector<Seg>& out) {
    const float r = glm::radians(s.yaw), c = std::cos(r), sn = std::sin(r);
    auto W = [&](const glm::vec3& l) { return s.centre + glm::vec3(c * l.x + sn * l.z, l.y, -sn * l.x + c * l.z); };
    const glm::vec3 h = glm::max(s.half, glm::vec3(1e-3f));
    auto seg = [&](const glm::vec3& a, const glm::vec3& b) { out.emplace_back(W(a), W(b)); };
    constexpr int N = 28;
    // An ellipse in one of the three planes, centred at `at`.
    auto ellipse = [&](int plane, const glm::vec3& at, float ra, float rb) {
        glm::vec3 prev(0.0f);
        for (int i = 0; i <= N; ++i) {
            const float t = float(i) / float(N) * glm::two_pi<float>();
            const float u = std::cos(t) * ra, v = std::sin(t) * rb;
            const glm::vec3 p = plane == 0 ? at + glm::vec3(u, v, 0) : plane == 1 ? at + glm::vec3(u, 0, v) : at + glm::vec3(0, u, v);
            if (i) seg(prev, p);
            prev = p;
        }
    };
    switch (s.shape) {
    case Shape::Box: {
        glm::vec3 k[8];
        for (int i = 0; i < 8; ++i) k[i] = glm::vec3(i & 1 ? h.x : -h.x, i & 2 ? h.y : -h.y, i & 4 ? h.z : -h.z);
        static const int e[12][2] = { {0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7} };
        for (auto& ed : e) seg(k[ed[0]], k[ed[1]]);
        break;
    }
    case Shape::Sphere:
        ellipse(0, glm::vec3(0), h.x, h.y);
        ellipse(1, glm::vec3(0), h.x, h.z);
        ellipse(2, glm::vec3(0), h.y, h.z);
        break;
    case Shape::Cylinder:
        ellipse(1, glm::vec3(0, -h.y, 0), h.x, h.z);
        ellipse(1, glm::vec3(0, h.y, 0), h.x, h.z);
        seg(glm::vec3(h.x, -h.y, 0), glm::vec3(h.x, h.y, 0)); seg(glm::vec3(-h.x, -h.y, 0), glm::vec3(-h.x, h.y, 0));
        seg(glm::vec3(0, -h.y, h.z), glm::vec3(0, h.y, h.z)); seg(glm::vec3(0, -h.y, -h.z), glm::vec3(0, h.y, -h.z));
        break;
    case Shape::Cone:
        ellipse(1, glm::vec3(0, -h.y, 0), h.x, h.z);
        seg(glm::vec3(h.x, -h.y, 0), glm::vec3(0, h.y, 0)); seg(glm::vec3(-h.x, -h.y, 0), glm::vec3(0, h.y, 0));
        seg(glm::vec3(0, -h.y, h.z), glm::vec3(0, h.y, 0)); seg(glm::vec3(0, -h.y, -h.z), glm::vec3(0, h.y, 0));
        break;
    case Shape::Wedge:
        for (float x : { -h.x, h.x }) {                    // a ramp: tall at the back (-z), flat at the front (+z)
            const glm::vec3 a(x, -h.y, -h.z), b(x, h.y, -h.z), d(x, -h.y, h.z);
            seg(a, b); seg(b, d); seg(d, a);
        }
        seg(glm::vec3(-h.x, -h.y, -h.z), glm::vec3(h.x, -h.y, -h.z));
        seg(glm::vec3(-h.x, h.y, -h.z), glm::vec3(h.x, h.y, -h.z));
        seg(glm::vec3(-h.x, -h.y, h.z), glm::vec3(h.x, -h.y, h.z));
        break;
    }
}

AssetPtr makeFloor() {
    // A flat slab of 4 m voxels, 400 m across, with its top at y = 0: cheap to draw, and far too big to see the edge of.
    auto a = std::make_shared<Asset>();
    a->name = "studio floor";
    a->voxelSize = 4.0f;
    a->size = glm::ivec3(100, 5, 100);
    a->pivot = glm::vec3(49.5f, 3.0f, 49.5f);
    a->grid.resize(size_t(a->size.x) * size_t(a->size.y) * size_t(a->size.z));
    a->materials.assign(a->grid.size(), MaterialId(MAT_STONE));
    for (int z = 0; z < a->size.z; ++z)
        for (int y = 0; y < a->size.y; ++y)
            for (int x = 0; x < a->size.x; ++x) {
                const float height = (float(y) - a->pivot.y) * a->voxelSize;
                a->grid[size_t(a->index(x, y, z))] = std::clamp((height + 0.005f) / a->voxelSize, -DENSITY_CLAMP, DENSITY_CLAMP);
            }
    a->buildMesh();
    return a;
}

AssetPtr makeFigure() {
    Workshop w;
    NewAssetSpec spec;
    spec.name = "scale figure";
    spec.tmpl = WorkshopTemplate::Mannequin;
    w.create(spec);
    w.remesh();
    auto a = std::make_shared<Asset>(w.asset);
    a->userMade = false;
    return a;
}

} // namespace wsui

using namespace wsui;

// ================================================================ opening and closing

void Application::startWorkshop() {
    ws.savedCamera = camera;
    ws.savedTime = timeOfDay;
    ws.savedTimeFlowing = timeFlowing;
    ws.savedWireframe = renderSettings.wireframe;
    ws.savedShadows = renderSettings.shadows;
    ws.savedShadowRange = renderSettings.shadowRange;
    ws.savedUiHidden = uiHidden;
    stopPlacing();
    gizmo.end();
    looking = lmbHeld = false;
    flyTo.cancel();
    paletteOpen = false;
    uiHidden = false;
    SDL_SetWindowRelativeMouseMode(window, false);
    ws.active = true;
    ws.orbiting = ws.panning = ws.stroking = ws.draggingSocket = false;
    ws.askNew = ws.askLeave = false;
    ws.afterLeave.clear();
    ws.hoverValid = false;
    ws.rangeOn = ws.rangeCaptured = false;
    ws.panelTab = 0;
    renderSettings.drawWorld = false;
    renderSettings.wireframe = ws.wireframe;
    renderSettings.shadows = true;
    if (!ws.floor) ws.floor = makeFloor();
}

void Application::enterWorkshopNew() {
    if (ws.active || mode != Mode::Editor) return;
    startWorkshop();
    ws.model = Workshop();
    ws.originalName.clear();
    ws.copyOfBuiltin = false;
    ws.spec = NewAssetSpec();
    std::snprintf(ws.nameBuf, sizeof ws.nameBuf, "%s", "New asset");
    ws.askNew = true;
    workshopApplyCamera();
}

void Application::enterWorkshopWith(const NewAssetSpec& spec) {
    if (!ws.active) {
        if (mode != Mode::Editor) return;
        startWorkshop();
    }
    ws.model.create(spec);
    ws.originalName.clear();
    ws.sourceAsset.clear();
    ws.copyOfBuiltin = false;
    ws.itemLoaded = ws.itemEdited = false;
    ws.panelTab = 0;
    if (ws.rangeOn) workshopLeaveRange();
    ws.askNew = false;
    workshopSyncInfo();
    workshopResetBrush();
    workshopFrame();
    status = "New asset: " + ws.model.asset.name;
}

void Application::editAssetInWorkshop(const std::string& name) {
    if (mode != Mode::Editor && !ws.active) return;
    AssetPtr a = assets.get(name);
    if (!a) { toast("That asset isn't available", Toast::Kind::Warning); return; }
    if (!ws.active) startWorkshop();
    const bool mine = assets.isUserMade(name);
    if (mine) {
        ws.model.adopt(*a);
        ws.originalName = name;
        ws.copyOfBuiltin = false;
    } else {
        // Built-in assets are chunky 1 m voxels with no room around them: re-sample onto a finer grid with space to build on.
        // (assets that are already fine, like the built-in weapons, keep their detail and only gain a little room)
        ws.model.adoptResampled(*a, std::min(0.25f, a->voxelSize), a->voxelSize < 0.2f ? 0.25f : 1.5f);
        ws.model.setName(name + " (mine)");
        ws.originalName.clear();
        ws.copyOfBuiltin = true;
    }
    ws.sourceAsset = name;
    ws.itemLoaded = ws.itemEdited = false;
    ws.panelTab = 0;
    if (ws.rangeOn) workshopLeaveRange();
    ws.askNew = false;
    workshopSyncInfo();
    workshopResetBrush();
    workshopFrame();
    status = mine ? "Editing " + name : "Editing your own copy of " + name;
}

void Application::leaveWorkshop() {
    if (ws.rangeOn) workshopLeaveRange();
    workshopFinishStroke();
    if (ws.draggingSocket) ws.draggingSocket = false;
    ws.active = false;
    ws.orbiting = ws.panning = false;
    ws.askNew = ws.askLeave = false;
    SDL_SetWindowRelativeMouseMode(window, false);
    camera = ws.savedCamera;
    timeOfDay = ws.savedTime;
    timeFlowing = ws.savedTimeFlowing;
    renderSettings.wireframe = ws.savedWireframe;
    renderSettings.shadows = ws.savedShadows;
    renderSettings.shadowRange = ws.savedShadowRange;
    renderSettings.drawWorld = true;
    uiHidden = ws.savedUiHidden;
    renderer.setObjects({});
    updateSunDirection();
    status = "Back in the editor";
}

void Application::workshopRunAfter(const std::string& action) {
    ws.askLeave = false;
    if (action == "close") leaveWorkshop();
    else if (action == "place") {
        const std::string n = ws.model.asset.name;
        leaveWorkshop();
        startPlacing(n);
    }
    else if (action == "new") {
        ws.spec = NewAssetSpec();
        std::snprintf(ws.nameBuf, sizeof ws.nameBuf, "%s", "New asset");
        ws.askNew = true;
    }
    else if (action == "quit") running = false;
    ws.afterLeave.clear();
}

void Application::workshopLeaveWith(const std::string& action) {
    workshopFinishStroke();
    if (ws.model.asset.valid() && workshopModified()) { ws.askLeave = true; ws.afterLeave = action; }
    else workshopRunAfter(action);
}

void Application::requestLeaveWorkshop() { if (ws.active) workshopLeaveWith("close"); }

bool Application::workshopNameProblem(std::string* why) {
    auto say = [&](const char* text) { if (why) *why = text; return true; };
    const std::string& n = ws.model.asset.name;
    if (n.empty() || n.find_first_not_of(' ') == std::string::npos) return say("Give it a name first");
    if (AssetLibrary::fileNameFor(n).empty()) return say("Use letters or numbers in the name");
    if (n != ws.originalName && assets.get(n) && !assets.isUserMade(n)) return say("A built-in asset already has that name. Pick another.");
    if (ws.model.asset.type == AssetType::Item) {
        std::string itemWhy;
        if (itemNameProblem(n, &itemWhy)) { if (why) *why = itemWhy; return true; }
    }
    return false;
}

bool Application::workshopSave() {
    if (!ws.model.asset.valid()) return false;
    workshopFinishStroke();
    std::string why;
    if (workshopNameProblem(&why)) { toast(why, Toast::Kind::Warning); return false; }
    ws.model.remesh();
    ws.model.asset.userMade = true;
    if (assets.directory.empty()) assets.directory = "assets";
    const std::string name = ws.model.asset.name;
    if (!assets.saveAsset(ws.model.asset, assets.directory)) { toast("Could not write " + assets.directory + "/" + AssetLibrary::fileNameFor(name) + ".pxasset", Toast::Kind::Warning); return false; }
    ws.model.markSaved();
    workshopSaveItem();
    const bool copy = !ws.originalName.empty() && ws.originalName != name;
    ws.originalName = name;
    ws.copyOfBuiltin = false;
    toast(copy ? "Saved '" + name + "' as a new asset" : "Saved '" + name + "'", Toast::Kind::Success);
    return true;
}

void Application::workshopSaveAndPlace() {
    if (workshopSave()) workshopRunAfter("place");
}

// ================================================================ small helpers

void Application::workshopSyncInfo() {
    const Asset& a = ws.model.asset;
    std::snprintf(ws.nameBuf, sizeof ws.nameBuf, "%s", a.name.c_str());
    std::string tags;
    for (const std::string& t : a.tags) { if (!tags.empty()) tags += ", "; tags += t; }
    std::snprintf(ws.tagBuf, sizeof ws.tagBuf, "%s", tags.c_str());
}

void Application::workshopResetBrush() {
    const glm::vec3 g = ws.model.gridMax() - ws.model.gridMin();
    const float longest = std::max(g.x, std::max(g.y, g.z));
    const float vs = ws.model.asset.voxelSize;
    const float base = std::clamp(longest / 12.0f, 3.0f * vs, std::max(3.0f * vs, longest * 0.5f));
    ws.size = glm::vec3(base);
    ws.round = ws.blend = ws.yaw = 0.0f;
    ws.smoothRadius = std::clamp(longest / 12.0f, 2.5f * vs, std::max(2.5f * vs, longest * 0.3f));
    ws.selectedSocket.clear();
    ws.hoverValid = false;
}

void Application::workshopSizeRange(float& lo, float& hi) const {
    const glm::vec3 g = ws.model.gridMax() - ws.model.gridMin();
    lo = 1.5f * ws.model.asset.voxelSize;
    hi = std::max(lo * 2.0f, std::max(g.x, std::max(g.y, g.z)));
}

void Application::workshopScaleSize(float factor) {
    float lo, hi;
    workshopSizeRange(lo, hi);
    if (ws.tool == WTool::Smooth) { ws.smoothRadius = std::clamp(ws.smoothRadius * factor, lo, hi * 0.5f); return; }
    ws.size = glm::clamp(ws.size * factor, glm::vec3(lo), glm::vec3(hi));
    ws.round = std::min(ws.round, std::min(ws.size.x, std::min(ws.size.y, ws.size.z)) * 0.5f);
}

void Application::workshopSetTool(WTool t) {
    if (t == ws.tool) return;
    workshopFinishStroke();
    ws.tool = t;
    ws.draggingSocket = false;
}

void Application::workshopFinishStroke() {
    if (ws.stroking) { ws.model.endStroke(); ws.stroking = false; }
}

void Application::workshopUndo() {
    workshopFinishStroke();
    const std::string label = ws.model.undoLabel();
    if (ws.model.undo()) { status = "Undid: " + label; if (!ws.model.findSocket(ws.selectedSocket)) ws.selectedSocket.clear(); }
}

void Application::workshopRedo() {
    workshopFinishStroke();
    const std::string label = ws.model.redoLabel();
    if (ws.model.redo()) { status = "Redid: " + label; if (!ws.model.findSocket(ws.selectedSocket)) ws.selectedSocket.clear(); }
}

void Application::workshopSound(const char* clip, float volume, float pitch) {
    const float now = float(SDL_GetTicks()) * 0.001f;
    if (now - lastEditSound < 0.09f) return;
    lastEditSound = now;
    playUiSound(clip, volume, pitch);
}

// ================================================================ camera

void Application::workshopApplyCamera() {
    ws.distance = std::clamp(ws.distance, 0.15f, 160.0f);
    ws.target.y = std::max(ws.target.y, -0.5f);
    camera.position = ws.target - camera.front() * ws.distance;
}

void Application::workshopFrame() {
    const Asset& a = ws.model.asset;
    glm::vec3 lo = ws.model.gridMin(), hi = ws.model.gridMax();
    if (!a.mesh.empty()) { lo = a.boundsMin; hi = a.boundsMax; }
    else lo.y = 0.0f;
    lo.y = std::min(lo.y, 0.0f);
    ws.target = (lo + hi) * 0.5f;
    const float radius = std::max(0.2f, 0.5f * glm::length(hi - lo));
    ws.distance = radius / std::sin(glm::radians(camera.fovDegrees) * 0.5f) * 1.12f;
    camera.yaw = -62.0f;
    camera.pitch = -20.0f;
    workshopApplyCamera();
}

// ================================================================ the pointer and the tools

bool Application::workshopRay(glm::vec3& origin, glm::vec3& dir) const {
    if (viewRect.w < 2.0f || viewRect.h < 2.0f) return false;
    if (mouseX < viewRect.x || mouseX > viewRect.x + viewRect.w || mouseY < viewRect.y || mouseY > viewRect.y + viewRect.h) return false;
    origin = camera.position;
    dir = camera.rayThroughPixel(mouseX - viewRect.x, mouseY - viewRect.y, viewRect.w, viewRect.h);
    return true;
}

Stamp Application::workshopStamp(const glm::vec3& centre) const {
    Stamp s;
    s.shape = ws.shape;
    s.mode = ws.tool == WTool::Carve ? StampMode::Carve : ws.tool == WTool::Paint ? StampMode::Paint : StampMode::Add;
    s.centre = centre;
    s.half = ws.size * 0.5f;
    s.yaw = ws.yaw;
    s.round = ws.round;
    s.blend = ws.blend;
    s.material = ws.material;
    return s;
}

// Where the stamp's centre goes for a surface point: Add rests the shape on the surface (a touch sunk in so it
// fuses with it); Carve and Paint centre it on the surface.
bool Application::workshopCentreFor(const WorkshopHit& hit, glm::vec3& centre) const {
    if (!hit.hit) return false;
    const float vs = ws.model.asset.voxelSize;
    glm::vec3 c = hit.point;
    if (ws.tool == WTool::Add) {
        const Stamp s = workshopStamp(glm::vec3(0.0f));
        c += hit.normal * std::max(0.0f, stampReach(s, hit.normal) - vs * 0.35f);
    }
    if (ws.snap) {
        const float step = vs * float(std::max(1, ws.snapVoxels));
        const glm::vec3 origin = ws.model.gridMin();
        for (int i = 0; i < 3; ++i)
            if (std::fabs(hit.normal[i]) < 0.5f || ws.tool != WTool::Add) c[i] = origin[i] + std::round((c[i] - origin[i]) / step) * step;
    }
    centre = c;
    return true;
}

void Application::workshopComputeHover() {
    ws.hoverValid = false;
    if (!ws.model.asset.valid()) return;
    glm::vec3 o, d;
    if (!workshopRay(o, d)) return;
    ws.hover = ws.model.raycast(o, d);
    if (!ws.hover.hit) return;
    ws.hoverValid = true;
    ws.hoverCentre = ws.hover.point;
    if (ws.tool == WTool::Add || ws.tool == WTool::Carve || ws.tool == WTool::Paint) workshopCentreFor(ws.hover, ws.hoverCentre);
}

void Application::workshopApplyStamp(const glm::vec3& centre) {
    ws.model.stamp(workshopStamp(centre), ws.mirror);
    const float big = std::clamp(ws.size.x + ws.size.y + ws.size.z, 0.2f, 8.0f);
    const float pitch = std::clamp(1.35f - big * 0.1f, 0.7f, 1.3f);
    if (ws.tool == WTool::Add) workshopSound("build", 0.7f, pitch);
    else if (ws.tool == WTool::Carve) workshopSound("dig", 0.7f, pitch);
    else workshopSound("paint", 0.5f, 1.0f);
}

wsui::View Application::workshopView() const {
    wsui::View v;
    v.x = viewRect.x; v.y = viewRect.y; v.w = std::max(1.0f, viewRect.w); v.h = std::max(1.0f, viewRect.h);
    v.vp = camera.projection(v.w / v.h) * camera.view();
    return v;
}

void Application::workshopPointerDown(bool shift) {
    if (!ws.model.asset.valid()) return;
    workshopApplyCamera();
    workshopComputeHover();
    const std::string shapeName = shapeLabel(ws.shape);
    switch (ws.tool) {
    case WTool::Add:
    case WTool::Carve:
        if (!ws.hoverValid) return;
        ws.model.beginStroke(std::string(ws.tool == WTool::Add ? "Add " : "Carve ") + shapeName);
        ws.stroking = true;
        ws.planePoint = ws.hover.point;
        ws.planeNormal = ws.hover.normal;
        ws.lastCentre = ws.hoverCentre;
        workshopApplyStamp(ws.hoverCentre);
        break;
    case WTool::Paint:
        if (!ws.hoverValid) return;
        if (ws.paintFill != shift) {
            ws.model.beginStroke("Fill");
            ws.model.fill(ws.hover.point, ws.material, ws.mirror);
            ws.model.endStroke();
            workshopSound("paint", 0.6f, 0.9f);
            return;
        }
        ws.model.beginStroke("Paint");
        ws.stroking = true;
        ws.lastCentre = ws.hoverCentre;
        workshopApplyStamp(ws.hoverCentre);
        break;
    case WTool::Smooth:
        if (!ws.hoverValid) return;
        ws.model.beginStroke("Smooth");
        ws.stroking = true;
        ws.smoothTimer = 0.0f;
        ws.model.smooth(ws.hover.point, ws.smoothRadius, ws.smoothStrength, ws.mirror);
        workshopSound("smooth", 0.5f, 1.0f);
        break;
    case WTool::Socket: {
        // Grab a marker that is close to the pointer, otherwise put a new socket where the pointer is.
        const View v = workshopView();
        float best = 16.0f * scale();
        std::string pick;
        for (const Socket& sk : ws.model.asset.sockets) {
            ImVec2 sp;
            if (!v.point(sk.position, sp)) continue;
            const float d = std::hypot(sp.x - mouseX, sp.y - mouseY);
            if (d < best) { best = d; pick = sk.name; }
        }
        if (!pick.empty()) {
            ws.selectedSocket = pick;
            ws.draggingSocket = true;
            if (const Socket* sk = ws.model.findSocket(pick)) { ws.socketDragPos = sk->position; ws.socketDragDir = sk->direction; }
        } else if (ws.hoverValid) {
            const std::string name = ws.model.freeSocketName("socket");
            if (ws.model.addSocket(name, ws.hover.point, ws.hover.normal)) { ws.selectedSocket = name; status = "Added socket '" + name + "'"; workshopSound("stamp", 0.5f, 1.2f); }
        } else ws.selectedSocket.clear();
        break;
    }
    case WTool::Count: break;
    }
}

void Application::workshopPointerUp() {
    if (ws.draggingSocket) {
        ws.draggingSocket = false;
        if (const Socket* sk = ws.model.findSocket(ws.selectedSocket))
            if (glm::distance(sk->position, ws.socketDragPos) > 1e-5f || glm::dot(sk->direction, ws.socketDragDir) < 0.9999f)
                ws.model.moveSocket(ws.selectedSocket, ws.socketDragPos, ws.socketDragDir);
    }
    workshopFinishStroke();
}

// Called every frame: the hover, and the continuing part of a stroke.
void Application::workshopPointerUpdate(float dt) {
    const ImGuiIO& io = ImGui::GetIO();
    const bool busy = ws.askNew || ws.askLeave || ws.orbiting || ws.panning;
    const bool overUi = io.WantCaptureMouse && !ws.stroking && !ws.draggingSocket;
    if (busy || overUi) { ws.hoverValid = false; return; }

    if (!ws.stroking && !ws.draggingSocket) { workshopComputeHover(); return; }

    const float vs = ws.model.asset.voxelSize;
    if (ws.draggingSocket) {
        workshopComputeHover();
        if (ws.hoverValid) { ws.socketDragPos = ws.hover.point; ws.socketDragDir = ws.hover.normal; }
        return;
    }
    if (ws.tool == WTool::Smooth) {
        ws.smoothTimer += dt;
        workshopComputeHover();
        if (ws.hoverValid && ws.smoothTimer >= 0.05f) {
            ws.smoothTimer = 0.0f;
            ws.model.smooth(ws.hover.point, ws.smoothRadius, ws.smoothStrength, ws.mirror);
            workshopSound("smooth", 0.4f, 1.0f);
        }
        return;
    }
    // Add / Carve / Paint: stamp along the path the pointer takes, with a spacing tied to the brush size.
    glm::vec3 centre;
    if (ws.tool == WTool::Add) {
        // Slide over the surface the stroke began on instead of climbing onto what it has just built.
        glm::vec3 o, d;
        if (!workshopRay(o, d)) { ws.hoverValid = false; return; }
        const float denom = glm::dot(d, ws.planeNormal);
        if (std::fabs(denom) < 1e-4f) return;
        const float t = glm::dot(ws.planePoint - o, ws.planeNormal) / denom;
        if (t <= 0.0f || t > 400.0f) return;
        WorkshopHit h;
        h.hit = true; h.point = o + d * t; h.normal = ws.planeNormal;
        if (!ws.model.asset.valid()) return;
        workshopCentreFor(h, centre);
        ws.hover = h; ws.hoverValid = true; ws.hoverCentre = centre;
    } else {
        workshopComputeHover();
        if (!ws.hoverValid) return;
        centre = ws.hoverCentre;
    }
    const float minSide = std::min(ws.size.x, std::min(ws.size.y, ws.size.z));
    const float spacing = std::max(vs, 0.3f * minSide);
    glm::vec3 delta = centre - ws.lastCentre;
    float dist = glm::length(delta);
    int guard = 0;
    while (dist >= spacing && guard++ < 48) {
        ws.lastCentre += delta / dist * spacing;
        workshopApplyStamp(ws.lastCentre);
        delta = centre - ws.lastCentre;
        dist = glm::length(delta);
    }
}

// ================================================================ events

void Application::workshopHandleEvent(const SDL_Event& e) {
    const ImGuiIO& io = ImGui::GetIO();
    const SDL_Keymod mod = SDL_GetModState();
    const bool ctrl = (mod & SDL_KMOD_CTRL) != 0, shift = (mod & SDL_KMOD_SHIFT) != 0, alt = (mod & SDL_KMOD_ALT) != 0;
    const bool dialog = ws.askNew || ws.askLeave;
    if (ws.rangeOn && !dialog && workshopRangeEvent(e)) return;

    switch (e.type) {
    case SDL_EVENT_KEY_DOWN: {
        const SDL_Keycode k = e.key.key;
        if (e.key.repeat && k != SDLK_LEFTBRACKET && k != SDLK_RIGHTBRACKET) break;
        if (k == SDLK_F11 || (k == SDLK_RETURN && alt)) { toggleFullscreen(); break; }
        if (k == SDLK_F12) { cmdScreenshot(); break; }
        if (dialog) {
            if (k == SDLK_ESCAPE) {
                if (ws.askLeave) { ws.askLeave = false; ws.afterLeave.clear(); }
                else if (!ws.model.asset.valid()) leaveWorkshop();
                else ws.askNew = false;
            }
            break;
        }
        if (ctrl && k == SDLK_Z) { if (shift) workshopRedo(); else workshopUndo(); break; }
        if (ctrl && k == SDLK_Y) { workshopRedo(); break; }
        if (ctrl && k == SDLK_S) { if (shift) workshopSaveAndPlace(); else workshopSave(); break; }
        if (io.WantTextInput) break;
        if (ctrl || alt) break;
        if (!ws.model.asset.valid()) break;
        if (k >= SDLK_1 && k < SDLK_1 + int(WTool::Count)) { workshopSetTool(WTool(int(k - SDLK_1))); break; }
        switch (k) {
        case SDLK_X: ws.mirror.x = !ws.mirror.x; break;
        case SDLK_Y: ws.mirror.y = !ws.mirror.y; break;
        case SDLK_Z: ws.mirror.z = !ws.mirror.z; break;
        case SDLK_R: ws.yaw = std::fmod(ws.yaw + (shift ? -15.0f : 15.0f) + 360.0f, 360.0f); break;
        case SDLK_LEFTBRACKET:  workshopScaleSize(1.0f / 1.12f); break;
        case SDLK_RIGHTBRACKET: workshopScaleSize(1.12f); break;
        case SDLK_F: workshopFrame(); break;
        case SDLK_G: ws.showGrid = !ws.showGrid; break;
        case SDLK_F1: showHints = !showHints; break;
        case SDLK_DELETE:
        case SDLK_BACKSPACE:
            if (!ws.selectedSocket.empty() && ws.model.removeSocket(ws.selectedSocket)) { status = "Removed socket '" + ws.selectedSocket + "'"; ws.selectedSocket.clear(); }
            break;
        case SDLK_ESCAPE:
            if (ws.stroking) { workshopFinishStroke(); workshopUndo(); }
            else ws.selectedSocket.clear();
            break;
        default: break;
        }
        break;
    }

    case SDL_EVENT_MOUSE_MOTION:
        mouseX = e.motion.x; mouseY = e.motion.y;
        if (ws.orbiting) {
            camera.look(e.motion.xrel, settings.invertY ? -e.motion.yrel : e.motion.yrel);
            workshopApplyCamera();
        } else if (ws.panning) {
            const glm::vec3 right = camera.right();
            const glm::vec3 up = glm::normalize(glm::cross(right, camera.front()));
            ws.target += (-right * e.motion.xrel + up * e.motion.yrel) * (ws.distance * 0.0016f);
            workshopApplyCamera();
        }
        break;

    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (dialog || io.WantCaptureMouse) break;
        if (e.button.button == SDL_BUTTON_RIGHT || e.button.button == SDL_BUTTON_MIDDLE) {
            ws.panning = e.button.button == SDL_BUTTON_MIDDLE || shift;
            ws.orbiting = !ws.panning;
            SDL_SetWindowRelativeMouseMode(window, true);
        } else if (e.button.button == SDL_BUTTON_LEFT) {
            if (alt) { ws.orbiting = true; SDL_SetWindowRelativeMouseMode(window, true); }
            else workshopPointerDown(shift);
        }
        break;

    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (e.button.button == SDL_BUTTON_LEFT) {
            if (ws.orbiting && !ws.panning && (SDL_GetMouseState(nullptr, nullptr) & SDL_BUTTON_RMASK) == 0) { ws.orbiting = false; SDL_SetWindowRelativeMouseMode(window, false); }
            workshopPointerUp();
        } else if ((e.button.button == SDL_BUTTON_RIGHT || e.button.button == SDL_BUTTON_MIDDLE) && (ws.orbiting || ws.panning)) {
            ws.orbiting = ws.panning = false;
            SDL_SetWindowRelativeMouseMode(window, false);
        }
        break;

    case SDL_EVENT_MOUSE_WHEEL:
        if (dialog || io.WantCaptureMouse) break;
        if (ctrl) ws.yaw = std::fmod(ws.yaw + 15.0f * e.wheel.y + 360.0f, 360.0f);
        else if (shift) workshopScaleSize(std::pow(1.12f, e.wheel.y));
        else { ws.distance *= std::pow(0.88f, e.wheel.y); workshopApplyCamera(); }
        break;

    default: break;
    }
}

// ================================================================ every frame

void Application::workshopSceneForRenderer() {
    std::vector<ObjectDraw> list;
    if (ws.floor) list.push_back({ ws.floor, glm::mat4(1.0f), 1.0f, glm::vec4(0.0f) });
    if (ws.rangeOn && ws.range) {                       // the firing range: the model is in your hand, not on the floor
        ws.range->collect(list);
        renderer.setObjects(std::move(list));
        return;
    }
    if (ws.model.asset.valid() && !ws.model.asset.mesh.empty())
        list.push_back({ AssetPtr(AssetPtr(), &ws.model.asset), glm::mat4(1.0f), 1.0f, glm::vec4(0.0f) });   // not owned: the Workshop outlives the frame
    if (ws.showFigure) {
        if (!ws.figure) ws.figure = makeFigure();
        const float x = ws.model.asset.valid() ? ws.model.gridMax().x + 1.2f : 2.0f;
        list.push_back({ ws.figure, glm::translate(glm::mat4(1.0f), glm::vec3(x, 0.0f, 0.0f)), 1.0f, glm::vec4(0.0f) });
    }
    renderer.setObjects(std::move(list));
}

void Application::updateWorkshop(float dt) {
    if (ws.rangeOn) { updateWorkshopRange(dt); return; }
    timeFlowing = false;
    timeOfDay = ws.lightTime;
    updateSunDirection();
    renderSettings.wireframe = ws.wireframe;
    renderSettings.water = false;                                   // no sea in here, whatever height the camera is at
    renderSettings.shadowRange = std::clamp(ws.distance * 1.5f + 3.0f, 6.0f, 90.0f);   // a tight shadow box keeps small models' shadows sharp
    renderSettings.interactor = glm::vec4(0.0f, -1e5f, 0.0f, 0.0f);
    cursorHitValid = false;
    flyTo.cancel();

    workshopApplyCamera();
    if (ws.model.asset.valid()) {
        workshopPointerUpdate(dt);
        if (ws.model.meshDirty()) ws.model.remesh();
    } else ws.hoverValid = false;
    workshopSceneForRenderer();
}

} // namespace px
