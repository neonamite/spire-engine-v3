// Share (v0.23): File > Share Game... packs the game into a folder anyone can run, and the program, started from such a
// folder, plays the game straight away with no editor (player mode). What goes in the folder is in share/Share.*.
#include "core/Application.h"
#include "character/Character.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <chrono>
#include <cstdio>
#include <ctime>
#include <filesystem>
#include <imgui.h>
#include <iostream>

namespace px {

using namespace ui;
namespace fs = std::filesystem;

namespace {
std::string today() {
    const std::time_t t = std::time(nullptr);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char b[16];
    std::strftime(b, sizeof b, "%Y-%m-%d", &tm);
    return b;
}
bool isLibrary(const fs::path& p) {
    const std::string n = p.filename().string(), ext = p.extension().string();
    return ext == ".dll" || ext == ".dylib" || ext == ".so" || n.find(".so.") != std::string::npos;
}
std::string sizeLabel(std::uintmax_t bytes) {
    char b[32];
    if (bytes > 1024ull * 1024ull) std::snprintf(b, sizeof b, "%.1f MB", double(bytes) / (1024.0 * 1024.0));
    else std::snprintf(b, sizeof b, "%.0f KB", double(bytes) / 1024.0);
    return b;
}
} // namespace

SharePlan Application::makeSharePlan(const GameManifest& in) {
    SharePlan plan;
    plan.manifest = in;
    plan.manifest.game = gameInfo ? gameInfo->id : std::string("sandbox");
    plan.manifest.world = worldSavePath();
    plan.manifest.engineVersion = kEngineVersion;
    if (plan.manifest.created.empty()) plan.manifest.created = today();
    std::error_code ec;
    // the program and the libraries beside it
    fs::path prog = programPath.empty() ? fs::path() : fs::path(programPath);
    if (!prog.empty() && fs::exists(prog, ec)) {
        plan.programName = prog.filename().string();
        plan.files.push_back({ prog.string(), plan.programName });
        for (const auto& e : fs::directory_iterator(prog.parent_path(), ec))
            if (e.is_regular_file() && isLibrary(e.path())) plan.files.push_back({ e.path().string(), e.path().filename().string() });
    } else plan.notes.push_back("Could not find the Spire Engine program to copy: add it to the folder by hand.");
    // the engine's own files, and your prefabs
    plan.folders.push_back({ "engine/assets", "engine/assets" });
    if (fs::is_directory("prefabs", ec)) plan.folders.push_back({ "prefabs", "prefabs" });
    // the world
    plan.files.push_back({ worldSavePath(), worldSavePath() });
    // what the world uses that you made: assets, people, and every item (the hotbar can hand out any of them)
    const SceneUses uses = sceneUses(scene.toText());
    for (const std::string& a : uses.assets) {
        if (!assets.isUserMade(a)) continue;
        const std::string file = assets.directory + "/" + AssetLibrary::fileNameFor(a) + ".pxasset";
        if (fs::exists(file, ec)) plan.files.push_back({ file, file });
        else plan.notes.push_back("The asset \"" + a + "\" has no file to copy (save it in the Workshop first).");
    }
    std::set<std::string> people = uses.characters;
    people.insert(playerCharacter);
    for (const std::string& c : people) {
        if (!characters.isYours(c)) continue;                   // ready-made people and crowds are built in
        const std::string file = characters.directory + "/" + characterFileName(c) + ".pxcharacter";
        if (fs::exists(file, ec)) plan.files.push_back({ file, file });
    }
    if (fs::is_directory(assets.directory, ec))
        for (const auto& e : fs::directory_iterator(assets.directory, ec))
            if (e.is_regular_file() && e.path().extension() == ".pxitem") plan.files.push_back({ e.path().string(), assets.directory + "/" + e.path().filename().string() });
    return plan;
}

ShareResult Application::shareGame(const GameManifest& m, const std::string& outDir) {
    if (mode == Mode::Play) setMode(Mode::Editor);
    cmdSave();                                                   // the package gets the world as it is now
    const SharePlan plan = makeSharePlan(m);
    ShareResult r = writeShare(plan, outDir);
    if (r.ok) for (const std::string& n : plan.notes) toast(n, Toast::Kind::Warning);
    return r;
}

bool Application::startPlayerMode(const std::string& manifestPath) {
    std::string err;
    if (!loadManifest(manifestPath, playerManifest, &err)) { std::cerr << "Can't open the game: " << err << "\n"; return false; }
    playerMode = true;
    const GameInfo* gi = playerManifest.game == "sandbox" ? nullptr : findGame(playerManifest.game);
    openGame(gi, false);
    SDL_SetWindowTitle(window, playerManifest.name.c_str());
    // start where the game says (or where the world was last seen)
    const GameRules g = gameRulesOf();
    if (g.hasSpawn) { camera.position = g.spawn + glm::vec3(0.0f, player.eyeHeight, 0.0f); camera.yaw = g.spawnYaw; camera.pitch = 0.0f; }
    thirdPerson = playerManifest.thirdPerson;
    showHints = false;
    setMode(Mode::Play);
    toasts.clear();
    return true;
}

void Application::drawShareWindow() {
    if (!share.open) return;
    const float s = scale();
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowSize(ImVec2(460 * s, 0), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.5f, vp->WorkPos.y + 80 * s), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.0f));
    if (!ImGui::Begin("Share Game###share", &share.open, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::End();
        return;
    }
    if (!share.filled) {
        share.name = gameInfo ? gameInfo->name : std::string("My game");
        share.folder = "shared/" + shareFolderName(share.name);
        share.filled = true;
    }
    ImGui::PushTextWrapPos(0.0f);
    ImGui::TextDisabled("Packs your game into one folder that runs on its own: no editor, nothing to install. Zip the folder and send it.");
    ImGui::PopTextWrapPos();
    ImGui::Dummy(ImVec2(0, 4 * s));
    auto line = [&](const char* label, std::string& v, size_t max) {
        char b[420];
        std::snprintf(b, sizeof b, "%s", v.c_str());
        prop(label);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::InputText((std::string("##share") + label).c_str(), b, std::min(sizeof b, max))) { v = b; return true; }
        return false;
    };
    if (beginProps("##shareprops", 110.0f)) {
        if (line("Name", share.name, 80)) share.folder = "shared/" + shareFolderName(share.name);
        line("Made by", share.author, 80);
        line("About it", share.description, 400);
        prop("Start in", "How the player sees at the start (V switches)");
        if (ImGui::RadioButton("First person", !share.thirdPerson)) share.thirdPerson = false;
        ImGui::SameLine();
        if (ImGui::RadioButton("Third person", share.thirdPerson)) share.thirdPerson = true;
        line("Folder", share.folder, 300);
        endProps();
    }
    // what will go in
    {
        GameManifest m; m.name = share.name;
        const SharePlan plan = makeSharePlan(m);
        const SceneUses uses = sceneUses(scene.toText());
        const GameRules g = gameRulesOf();
        int made = 0;
        for (const ShareFile& f : plan.files) {
            const std::string ext = fs::path(f.to).extension().string();
            made += ext == ".pxasset" || ext == ".pxcharacter" || ext == ".pxitem";
        }
        const std::string rulesText = g.active() ? ", the game rules (" + std::string(gameGoalLabel(g.goal)) + ")" : std::string();
        pushFont(fonts.small);
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextDisabled("In it: the program, the world (%d objects), %d thing%s you made%s.", int(scene.size()), made, made == 1 ? "" : "s", rulesText.c_str());
        ImGui::PopTextWrapPos();
        for (const std::string& n : plan.notes) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s", n.c_str());
        (void)uses;
        popFont();
    }
    ImGui::Dummy(ImVec2(0, 4 * s));
    if (primaryButton("Make the game folder", ImVec2(-FLT_MIN, 36 * s))) {
        GameManifest m;
        m.name = share.name.empty() ? std::string("My game") : share.name;
        m.author = share.author; m.description = share.description; m.thirdPerson = share.thirdPerson;
        const std::string folder = share.folder.empty() ? "shared/" + shareFolderName(m.name) : share.folder;
        share.last = shareGame(m, folder);
        share.lastFolder = folder;
        if (share.last.ok) toast("Shared: " + folder + " (" + sizeLabel(share.last.bytes) + ")", Toast::Kind::Success);
        else toast("Could not share: " + share.last.error, Toast::Kind::Warning);
    }
    if (!share.lastFolder.empty()) {
        if (share.last.ok) {
            std::error_code ec;
            const std::string abs = fs::absolute(share.lastFolder, ec).string();
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::success), "Done: %d files, %s", share.last.files, sizeLabel(share.last.bytes).c_str());
            ImGui::PushTextWrapPos(0.0f);
            ImGui::TextDisabled("%s", abs.c_str());
            ImGui::PopTextWrapPos();
            if (ImGui::Button("Open the folder")) SDL_OpenURL(("file://" + abs).c_str());
            ImGui::SameLine();
            ImGui::TextDisabled("Players run Play.bat (Windows) or play.sh.");
        } else ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s", share.last.error.c_str());
    }
    ImGui::End();
}

} // namespace px
