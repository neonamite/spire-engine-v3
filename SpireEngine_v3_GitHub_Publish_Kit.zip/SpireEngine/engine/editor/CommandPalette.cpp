// The command palette (Ctrl+P): type a few letters, press Enter. Searches every Command in
// Application::commands (see core/Commands.h and editor/EditorCommands.cpp).
#include "core/Application.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>

namespace px {

using namespace ui;

void Application::drawCommandPalette() {
    if (!paletteOpen) return;
    const float s = scale();
    const ImVec2 ds = ImGui::GetIO().DisplaySize;

    if (!ImGui::IsPopupOpen("##palette")) ImGui::OpenPopup("##palette");

    // Find results first so the window can be sized to fit them.
    const std::vector<int> results = commands.search(paletteQuery);
    const int n = int(results.size());
    constexpr int kMaxRows = 9;
    const int rows = std::max(1, std::min(n, kMaxRows));
    const float rowH = ImGui::GetFontSize() + 16 * s;
    const float pad = 14 * s;
    const float inputH = ImGui::GetFrameHeight() + 6 * s;
    const float width = std::min(640.0f * s, ds.x * 0.92f);
    const float height = pad * 2 + inputH + 8 * s + rows * rowH + (n > kMaxRows ? 22 * s : 0.0f);

    ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, std::max(40.0f * s, ds.y * 0.14f)), ImGuiCond_Always, ImVec2(0.5f, 0.0f));
    ImGui::SetNextWindowSize(ImVec2(width, height));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pad, pad));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 12 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 4 * s));
    ImGui::PushStyleColor(ImGuiCol_PopupBg, IM_COL32(26, 29, 37, 255));
    const bool open = ImGui::BeginPopupModal("##palette", nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(3);
    if (!open) { paletteOpen = false; return; }          // closed with Esc or a click outside

    if (paletteFocus) { ImGui::SetKeyboardFocusHere(); paletteFocus = false; }
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (ImGui::InputTextWithHint("##q", "Type a command...   try: carve, save, sunset, bookmark", paletteQuery, sizeof paletteQuery)) paletteSel = 0;

    if (ImGui::IsKeyPressed(ImGuiKey_DownArrow)) paletteSel = std::min(paletteSel + 1, std::max(n - 1, 0));
    if (ImGui::IsKeyPressed(ImGuiKey_UpArrow))   paletteSel = std::max(paletteSel - 1, 0);
    paletteSel = std::clamp(paletteSel, 0, std::max(n - 1, 0));
    const int first = std::clamp(paletteSel - kMaxRows / 2, 0, std::max(n - kMaxRows, 0));

    ImGui::Dummy(ImVec2(0, 4 * s));
    std::string run;
    if (n == 0) {
        ImGui::Dummy(ImVec2(0, 8 * s));
        ImGui::TextDisabled("No command matches \"%s\"", paletteQuery);
    }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    for (int i = first; i < std::min(n, first + kMaxRows); ++i) {
        const Command& c = commands.all()[size_t(results[size_t(i)])];
        const bool enabled = commands.isEnabled(c);
        ImGui::PushID(i);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float w = ImGui::GetContentRegionAvail().x;
        if (ImGui::Selectable("##row", i == paletteSel, enabled ? 0 : ImGuiSelectableFlags_Disabled, ImVec2(w, rowH))) { paletteSel = i; run = c.id; }
        if (ImGui::IsItemHovered() && (ImGui::GetIO().MouseDelta.x != 0.0f || ImGui::GetIO().MouseDelta.y != 0.0f)) paletteSel = i;
        const ImU32 tc = enabled ? col::text : col::textDim;
        const float ty = p.y + (rowH - ImGui::GetFontSize()) * 0.5f;
        dl->AddText(ImVec2(p.x + 10 * s, ty), tc, c.title.c_str());
        if (!c.shortcut.empty()) {
            pushFont(fonts.small);
            keyCap(dl, ImVec2(p.x + w - keyCapWidth(c.shortcut.c_str()) - 10 * s, p.y + (rowH - ImGui::GetFontSize() - 8 * s) * 0.5f), c.shortcut.c_str(), col::textDim);
            popFont();
        }
        ImGui::PopID();
    }
    if (n > kMaxRows) {
        pushFont(fonts.small);
        ImGui::TextDisabled("%d more... keep typing to narrow down", n - kMaxRows);
        popFont();
    }

    if ((ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_KeypadEnter)) && n > 0)
        run = commands.all()[size_t(results[size_t(paletteSel)])].id;
    if (!run.empty()) { pendingCommand = run; paletteOpen = false; ImGui::CloseCurrentPopup(); }
    ImGui::EndPopup();

    // Run it after the popup is gone, so a command can open other dialogs.
    if (!pendingCommand.empty()) {
        const std::string id = std::move(pendingCommand);
        pendingCommand.clear();
        commands.run(id);
    }
}

} // namespace px
