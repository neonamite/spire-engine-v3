#pragma once
// The Blueprint Tool's editor state (v0.17). The plan and its rules are in scene/Blueprint.h; the window, the mouse and
// placing the building in the world are in editor/BlueprintTools.cpp.
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include "scene/Blueprint.h"
#include "scene/Scene.h"

namespace px {

enum class BpTool : int { Room, Erase, Door, Window, Wall, Open, Auto, Stairs, Count };
const char* bpToolLabel(BpTool t);
const char* bpToolHint(BpTool t);

struct BlueprintEditor {
    bool open = false;                    // the Blueprint window
    bool focus = false;                   // bring it to the front next frame
    bool started = false;                 // a plan has been put in it (the first time it opens: a ready-made one)
    Blueprint plan;
    int level = 0;                        // the storey being drawn
    BpTool tool = BpTool::Room;
    int room = 1;                         // the room Shift+drag adds to, and the one the room list shows
    int stairsDir = 1;                    // the way new stairs climb (bpDir)
    std::vector<Blueprint> undo, redo;    // the plan's own history (Ctrl+Z while the window has focus)
    bool windowFocused = false;

    // a drag on the plan
    bool dragging = false;
    glm::ivec2 dragFrom{ 0 }, dragTo{ 0 };
    bool dragAdd = false;                 // Shift: add to the current room instead of making a new one
    bool edgeStroke = false;              // an edge tool is being dragged along edges
    std::uint32_t lastEdge = 0xFFFFFFFFu;
    Blueprint sliderBefore;               // the plan when a slider or text box was grabbed (one undo step per edit)

    // the plan, generated, for drawing it (refreshed when the plan changes)
    Blueprint previewOf;
    BpResult preview;
    bool previewValid = false;

    // placing the building in the world
    bool placing = false;
    int turns = 0;                        // quarter turns (R)
    bool levelGround = true;              // flatten the ground under it first
    ObjectId target = 0;                  // the Building this plan came from (0: a new one): Rebuild replaces its pieces
    glm::vec3 spot{ 0.0f };               // where the footprint's corner goes (x, z on the 2 m grid) and the ground height (y)
    bool spotValid = false;
    Blueprint ghostOf;                    // the generated pieces for the ghost, for this plan and turn
    int ghostTurns = -1;
    BpResult ghost;
    glm::vec3 lastAim{ 1e9f };            // the cursor's spot the ground height was measured for
    char fileName[64] = "";
};

} // namespace px
