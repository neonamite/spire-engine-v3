// The Character Studio (v0.18): make a person. A screen of its own (like the Asset Workshop): the character stands on
// an endless studio floor and moves while you change them. Right-drag orbits, middle-drag pans, the wheel zooms, left-drag
// turns the character. The side panel has Body (sliders), Look (colours and hair) and Parts (swap any part for one made in
// the Workshop). Saved as characters/<name>.pxcharacter, placed in the world, or used as how you look in third person.
#include "core/Application.h"
#include "character/BodyParts.h"
#include "character/Wardrobe.h"
#include "editor/Panels.h"
#include "editor/WorkshopCommon.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

using namespace ui;

const char* studioMoveLabel(StudioMove m) {
    switch (m) {
    case StudioMove::Stand: return "Stand";
    case StudioMove::Walk: return "Walk";
    case StudioMove::Run: return "Run";
    case StudioMove::Jump: return "Jump";
    case StudioMove::Look: return "Look around";
    case StudioMove::Count: break;
    }
    return "";
}

namespace {
float gStudioMenuH = 30.0f;

const glm::vec3 kClothes[] = { { 0.93f, 0.93f, 0.93f }, { 0.11f, 0.11f, 0.13f }, { 0.40f, 0.42f, 0.46f }, { 0.88f, 0.22f, 0.20f }, { 0.95f, 0.50f, 0.12f },
                               { 0.95f, 0.82f, 0.25f }, { 0.30f, 0.55f, 0.28f }, { 0.25f, 0.45f, 0.75f }, { 0.20f, 0.30f, 0.50f }, { 0.50f, 0.30f, 0.62f },
                               { 0.58f, 0.50f, 0.32f }, { 0.35f, 0.25f, 0.18f } };

bool swatch(const char* id, const glm::vec3& c, bool selected, float size) {
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton(id, ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float s = scale();
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), ImGui::ColorConvertFloat4ToU32(ImVec4(c.r, c.g, c.b, 1.0f)), 5 * s);
    if (selected) dl->AddRect(ImVec2(p.x - 2 * s, p.y - 2 * s), ImVec2(p.x + size + 2 * s, p.y + size + 2 * s), col::accent, 6 * s, 0, 2.0f * s);
    else if (ImGui::IsItemHovered()) dl->AddRect(p, ImVec2(p.x + size, p.y + size), col::text, 5 * s, 0, 1.0f * s);
    return pressed;
}

bool near3(const glm::vec3& a, const glm::vec3& b) { return glm::length(a - b) < 0.01f; }
} // namespace

// ================================================================ opening and closing

void Application::openCharacterStudio(const std::string& name) {
    if (ws.active) return;
    if (!cs.active) {
        if (mode != Mode::Editor) return;
        cs.savedCamera = camera;
        cs.savedTime = timeOfDay;
        cs.savedTimeFlowing = timeFlowing;
        cs.savedShadows = renderSettings.shadows;
        cs.savedShadowRange = renderSettings.shadowRange;
        cs.savedUiHidden = uiHidden;
        stopPlacing();
        bp.placing = false;
        gizmo.end();
        looking = lmbHeld = false;
        flyTo.cancel();
        paletteOpen = false;
        uiHidden = false;
        SDL_SetWindowRelativeMouseMode(window, false);
        cs.active = true;
        renderSettings.drawWorld = false;
        renderSettings.shadows = true;
        if (!cs.floor) cs.floor = wsui::makeFloor();
    }
    cs.askLeave = false;
    cs.afterLeave.clear();
    cs.undo.clear(); cs.redo.clear();
    const bool found = !name.empty() && characters.has(name);
    if (found && characters.isYours(name)) {
        cs.def = characters.get(name);
        cs.originalName = name;
    } else {
        cs.def = found ? characters.get(name) : characterPresets().front();
        std::string base = found ? (name.rfind("crowd:", 0) == 0 ? cs.def.name : name + " (mine)") : std::string("New character");
        std::string n = base;
        for (int k = 2; characters.find(n); ++k) n = base + " " + std::to_string(k);
        cs.def.name = n;
        cs.originalName.clear();
    }
    cs.savedDef = cs.def;
    cs.anim = CharacterAnimator();
    cs.anim.reset(0.0f);
    cs.turn = 0.0f;
    cs.clock = 0.0f;
    studioFrame();
    status = found && characters.isYours(name) ? "Editing " + name : "A new character: " + cs.def.name;
}

void Application::leaveCharacterStudio() {
    cs.active = false;
    cs.orbiting = cs.panning = cs.turning = false;
    cs.askLeave = false;
    SDL_SetWindowRelativeMouseMode(window, false);
    camera = cs.savedCamera;
    timeOfDay = cs.savedTime;
    timeFlowing = cs.savedTimeFlowing;
    renderSettings.shadows = cs.savedShadows;
    renderSettings.shadowRange = cs.savedShadowRange;
    renderSettings.drawWorld = true;
    uiHidden = cs.savedUiHidden;
    renderer.setObjects({});
    updateSunDirection();
    status = "Back in the editor";
}

void Application::requestLeaveCharacterStudio() {
    if (cs.afterLeave.empty()) cs.afterLeave = "close";
    if (!(cs.def == cs.savedDef)) { cs.askLeave = true; return; }
    studioRunAfter(cs.afterLeave);
}

void Application::studioRunAfter(std::string action) {      // by value: it clears cs.afterLeave, which is often what it was given
    cs.askLeave = false;
    cs.afterLeave.clear();
    if (action == "close") leaveCharacterStudio();
    else if (action == "quit") running = false;
    else if (action == "place") { const std::string n = cs.def.name; leaveCharacterStudio(); startPlacingCharacter(n); }
    else if (action.rfind("open:", 0) == 0) openCharacterStudio(action.substr(5));
    else if (action.rfind("part:", 0) == 0) { leaveCharacterStudio(); editAssetInWorkshop(action.substr(5)); }
}

std::string Application::studioNameProblem() const {
    const std::string& n = cs.def.name;
    if (n.empty()) return "Give the character a name";
    if (characters.isPreset(n)) return "'" + n + "' is one of the ready-made characters: pick another name";
    if (characters.isYours(n) && n != cs.originalName) return "You already have a character called '" + n + "'";
    return {};
}

bool Application::studioSave() {
    forgetPersonThumbnails();                                    // the shelf draws them again, as they are now
    const std::string why = studioNameProblem();
    if (!why.empty()) { toast(why, Toast::Kind::Warning); return false; }
    std::string err;
    if (!characters.save(cs.def, &err)) { toast("Could not save: " + err, Toast::Kind::Warning); return false; }
    cs.originalName = cs.def.name;
    cs.savedDef = cs.def;
    toast("Saved " + cs.def.name + "  (characters/" + characterFileName(cs.def.name) + ".pxcharacter)", Toast::Kind::Success);
    return true;
}

void Application::studioChanged(const CharacterDef& before) {
    if (before == cs.def) return;
    cs.undo.push_back(before);
    if (cs.undo.size() > 100) cs.undo.erase(cs.undo.begin());
    cs.redo.clear();
}

void Application::studioUndo() {
    if (cs.undo.empty()) return;
    cs.redo.push_back(cs.def);
    cs.def = cs.undo.back();
    cs.undo.pop_back();
}

void Application::studioRedo() {
    if (cs.redo.empty()) return;
    cs.undo.push_back(cs.def);
    cs.def = cs.redo.back();
    cs.redo.pop_back();
}

void Application::studioFrame() {
    const float h = cs.def.shape.height;
    cs.target = glm::vec3(0.0f, h * 0.55f, 0.0f);
    cs.distance = h * 1.25f / std::tan(glm::radians(camera.fovDegrees) * 0.5f) * 0.62f + 0.6f;
    cs.yaw = -90.0f + 22.0f;
    cs.pitch = -6.0f;
    studioApplyCamera();
}

void Application::studioApplyCamera() {
    cs.pitch = std::clamp(cs.pitch, -80.0f, 80.0f);
    cs.distance = std::clamp(cs.distance, 0.6f, 25.0f);
    camera.yaw = cs.yaw;
    camera.pitch = cs.pitch;
    camera.position = cs.target - camera.front() * cs.distance;
}

// ================================================================ input

void Application::studioHandleEvent(const SDL_Event& e) {
    const ImGuiIO& io = ImGui::GetIO();
    const SDL_Keymod mod = SDL_GetModState();
    const bool ctrl = (mod & SDL_KMOD_CTRL) != 0, shift = (mod & SDL_KMOD_SHIFT) != 0;
    switch (e.type) {
    case SDL_EVENT_KEY_DOWN: {
        if (e.key.repeat) break;
        const SDL_Keycode k = e.key.key;
        if (k == SDLK_F11) { toggleFullscreen(); break; }
        if (k == SDLK_F12) { cmdScreenshot(); break; }
        if (cs.askLeave) { if (k == SDLK_ESCAPE) { cs.askLeave = false; cs.afterLeave.clear(); } break; }
        if (ctrl && k == SDLK_Z) { if (shift) studioRedo(); else studioUndo(); break; }
        if (ctrl && k == SDLK_Y) { studioRedo(); break; }
        if (ctrl && k == SDLK_S) { studioSave(); break; }
        if (io.WantTextInput || ctrl) break;
        if (k == SDLK_F) studioFrame();
        else if (k >= SDLK_1 && k < SDLK_1 + int(StudioMove::Count)) cs.move = StudioMove(int(k - SDLK_1));
        else if (k == SDLK_ESCAPE) requestLeaveCharacterStudio();
        break;
    }
    case SDL_EVENT_MOUSE_MOTION:
        mouseX = e.motion.x; mouseY = e.motion.y;
        if (cs.orbiting) { cs.yaw += e.motion.xrel * camera.sensitivity; cs.pitch -= e.motion.yrel * camera.sensitivity; studioApplyCamera(); }
        else if (cs.panning) {
            const glm::vec3 right = camera.right(), up = glm::normalize(glm::cross(right, camera.front()));
            cs.target += (-right * e.motion.xrel + up * e.motion.yrel) * (cs.distance * 0.0016f);
            studioApplyCamera();
        } else if (cs.turning) cs.turn = std::fmod(cs.turn + e.motion.xrel * 0.5f, 360.0f);
        break;
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (cs.askLeave || io.WantCaptureMouse) break;
        if (e.button.button == SDL_BUTTON_RIGHT || e.button.button == SDL_BUTTON_MIDDLE) {
            cs.panning = e.button.button == SDL_BUTTON_MIDDLE || shift;
            cs.orbiting = !cs.panning;
            SDL_SetWindowRelativeMouseMode(window, true);
        } else if (e.button.button == SDL_BUTTON_LEFT) cs.turning = true;
        break;
    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (e.button.button == SDL_BUTTON_LEFT) cs.turning = false;
        else if (cs.orbiting || cs.panning) { cs.orbiting = cs.panning = false; SDL_SetWindowRelativeMouseMode(window, false); }
        break;
    case SDL_EVENT_MOUSE_WHEEL:
        if (cs.askLeave || io.WantCaptureMouse) break;
        cs.distance *= std::pow(0.88f, e.wheel.y);
        studioApplyCamera();
        break;
    default: break;
    }
}

// ================================================================ every frame

void Application::updateCharacterStudio(float dt) {
    timeFlowing = false;
    timeOfDay = 10.5f;
    updateSunDirection();
    renderSettings.water = false;
    renderSettings.wireframe = false;
    renderSettings.shadowRange = std::clamp(cs.distance * 1.5f + 3.0f, 6.0f, 40.0f);
    renderSettings.interactor = glm::vec4(0.0f, -1e5f, 0.0f, 0.0f);
    cursorHitValid = false;
    studioApplyCamera();
    cs.clock += dt;

    // The preview: the character moves on the spot (the floor runs under them like a treadmill).
    const Skeleton sk = buildSkeleton(cs.def.shape);
    const float t = glm::radians(cs.turn);
    AnimInput in;
    in.facing = glm::vec3(std::sin(t), 0.0f, std::cos(t));
    const glm::vec3 fwd = in.facing;
    switch (cs.move) {
    case StudioMove::Walk: in.velocity = fwd * (1.4f * sk.scale); break;
    case StudioMove::Run: in.velocity = fwd * (5.6f * sk.scale); break;
    case StudioMove::Jump: {
        const float c = std::fmod(cs.clock, 1.6f);                          // a hop on the spot, over and over
        if (c > 0.3f && c < 1.0f) {
            const float u = (c - 0.3f) / 0.7f;
            in.grounded = false;
            in.position.y = 4.0f * 0.55f * u * (1.0f - u);
            in.velocity.y = 0.55f * 4.0f * (1.0f - 2.0f * u) / 0.7f;
        }
        break;
    }
    case StudioMove::Look:
        in.hasLook = true;
        in.lookAt = glm::vec3(std::sin(cs.clock * 0.9f) * 3.0f, sk.height * (0.9f + 0.25f * std::sin(cs.clock * 0.55f)), 3.0f);
        break;
    default: break;
    }
    const ItemDef* item = cs.heldItem.empty() ? nullptr : itemLibrary.find(cs.heldItem);
    in.hold = holdKindFor(item);
    in.aimPitch = cs.move == StudioMove::Look ? 12.0f * std::sin(cs.clock * 0.55f) : 0.0f;
    in.style = cs.def.move;
    in.mood = cs.mood;
    in.seed = 11;
    cs.anim.update(sk, in, dt);

    std::vector<ObjectDraw> list;
    if (cs.floor) list.push_back({ cs.floor, glm::mat4(1.0f), 1.0f, glm::vec4(0.0f) });
    characterDraws(cs.def, sk, cs.anim.output(), assets, list, glm::vec4(0.0f), item ? assets.get(item->asset) : nullptr);
    lastCharacterDraws = int(list.size()) - 1;
    renderer.setObjects(std::move(list));
}

// ================================================================ the screen

void Application::drawStudioMenuBar() {
    const float s = scale();
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10 * s, 7 * s));
    if (ImGui::BeginMainMenuBar()) {
        gStudioMenuH = ImGui::GetWindowHeight();
        screenHeader("Character Studio");
        if (ImGui::BeginMenu("File")) {
            if (ImGui::BeginMenu("New Character From")) {
                for (const CharacterDef& p : characterPresets())
                    if (ImGui::MenuItem(p.name.c_str())) { cs.afterLeave = "open:" + p.name; requestLeaveCharacterStudio(); }
                ImGui::EndMenu();
            }
            if (ImGui::BeginMenu("Open")) {
                bool any = false;
                for (const std::string& n : characters.names())
                    if (characters.isYours(n)) { any = true; if (ImGui::MenuItem(n.c_str())) { cs.afterLeave = "open:" + n; requestLeaveCharacterStudio(); } }
                if (!any) ImGui::TextDisabled("You have not saved a character yet");
                ImGui::EndMenu();
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Save", "Ctrl+S")) studioSave();
            if (ImGui::MenuItem("Save and Place in the World")) { if (studioSave()) { cs.afterLeave = "place"; requestLeaveCharacterStudio(); } }
            if (ImGui::MenuItem("Save and Play as This Character")) { if (studioSave()) setPlayerCharacter(cs.def.name); }
            ImGui::Separator();
            if (ImGui::MenuItem("Close Studio", "Esc")) requestLeaveCharacterStudio();
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Edit")) {
            if (ImGui::MenuItem("Undo", "Ctrl+Z", false, !cs.undo.empty())) studioUndo();
            if (ImGui::MenuItem("Redo", "Ctrl+Y", false, !cs.redo.empty())) studioRedo();
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("View")) {
            if (ImGui::MenuItem("Frame the Character", "F")) studioFrame();
            ImGui::Separator();
            for (int m = 0; m < int(StudioMove::Count); ++m) {
                char key[4]; std::snprintf(key, sizeof key, "%d", m + 1);
                if (ImGui::MenuItem(studioMoveLabel(StudioMove(m)), key, cs.move == StudioMove(m))) cs.move = StudioMove(m);
            }
            ImGui::EndMenu();
        }
        const float bh = ImGui::GetFontSize() + 8 * s;
        const float doneW = ImGui::CalcTextSize("Done").x + 38 * s, saveW = ImGui::CalcTextSize("Save *").x + 34 * s;
        const bool modified = !(cs.def == cs.savedDef);
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - doneW - saveW - 24 * s);
        ImGui::SetCursorPosY((ImGui::GetWindowHeight() - bh) * 0.5f);
        if (ImGui::Button(modified ? "Save *" : "Save", ImVec2(saveW, bh))) studioSave();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Save this character  (Ctrl+S)");
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - doneW - 12 * s);
        ImGui::SetCursorPosY((ImGui::GetWindowHeight() - bh) * 0.5f);
        if (primaryButton("Done", ImVec2(doneW, bh))) requestLeaveCharacterStudio();
        ImGui::EndMainMenuBar();
    }
    ImGui::PopStyleVar();
}

void Application::drawStudioPanel(float top, float bottom) {
    const float s = scale();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const float panelW = 350 * s;
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x - panelW, top));
    ImGui::SetNextWindowSize(ImVec2(panelW, bottom - top));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14 * s, 12 * s));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, col::panel);
    if (ImGui::Begin("##studiopanel", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus)) {
        CharacterDef& d = cs.def;
        const CharacterDef frameStart = d;
        auto track = [&]() {
            if (ImGui::IsItemActivated()) cs.sliderBefore = frameStart;
            if (ImGui::IsItemDeactivatedAfterEdit()) studioChanged(cs.sliderBefore);
        };
        bool clicked = false;

        // ---- the name
        char name[64];
        std::snprintf(name, sizeof name, "%s", d.name.c_str());
        pushFont(fonts.title);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::InputText("##ccname", name, sizeof name)) d.name = name;
        track();
        popFont();
        const std::string problem = studioNameProblem();
        pushFont(fonts.small);
        if (!problem.empty()) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s", problem.c_str());
        else ImGui::TextDisabled("%s", cs.originalName.empty() ? "Not saved yet" : (cs.def == cs.savedDef ? "Saved" : "Changed since it was saved"));
        popFont();
        ImGui::Dummy(ImVec2(0, 4 * s));

        const float useH = ImGui::GetFrameHeight() * 2 + ImGui::GetFrameHeightWithSpacing() + 40 * s;
        ImGui::BeginChild("##cctabscroll", ImVec2(0, -useH), ImGuiChildFlags_None, ImGuiWindowFlags_None);
        if (ImGui::BeginTabBar("##cctabs", ImGuiTabBarFlags_FittingPolicyResizeDown)) {
            if (ImGui::BeginTabItem("Body", nullptr, cs.tabForce == 0 ? ImGuiTabItemFlags_SetSelected : 0)) {
                cs.tab = 0;
                section("Shape");
                if (beginProps("##body", 96.0f)) {
                    auto slider = [&](const char* label, const char* tip, float* v, float lo, float hi, const char* fmt) {
                        prop(label, tip);
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        sliderFloat((std::string("##") + label).c_str(), v, lo, hi, fmt);
                        track();
                    };
                    slider("Height", "Head to toe", &d.shape.height, 1.0f, 2.4f, "%.2f m");
                    slider("Build", "Slim to broad", &d.shape.build, 0.7f, 1.5f, "%.2f");
                    slider("Shoulders", "How wide the shoulders are", &d.shape.shoulders, 0.8f, 1.3f, "%.2f");
                    slider("Legs", "How long the legs are, for the same height", &d.shape.legs, 0.85f, 1.15f, "%.2f");
                    slider("Arms", "How long the arms are", &d.shape.arms, 0.85f, 1.15f, "%.2f");
                    slider("Head", "How big the head is", &d.shape.head, 0.8f, 1.5f, "%.2f");
                    endProps();
                }
                d.shape.clamp();
                section("Body");
                if (beginProps("##look", 96.0f)) {
                    auto slider = [&](const char* label, const char* tip, float* v, const char* left, const char* right) {
                        prop(label, tip);
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        const float pct = *v;
                        char fmt[64];
                        std::snprintf(fmt, sizeof fmt, "%s", pct < 0.35f ? left : pct > 0.65f ? right : "In between");
                        sliderFloat((std::string("##") + label).c_str(), v, 0.0f, 1.0f, fmt);
                        track();
                    };
                    slider("Gender", "Feminine to masculine", &d.look.gender, "Feminine", "Masculine");
                    slider("Age", "Child, young, middle-aged, old", &d.look.age, "Young", "Older");
                    slider("Muscle", "How muscular", &d.look.muscle, "Soft", "Muscular");
                    slider("Weight", "Thin to heavy", &d.look.weight, "Thin", "Heavy");
                    endProps();
                }
                section("Features");
                if (beginProps("##heritage", 96.0f)) {
                    for (int i = 0; i < 3; ++i) {
                        prop(heritageLabel(i), "How much the face and body have these features (the three always add up)");
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        float v = d.look.heritage[size_t(i)];
                        if (sliderFloat((std::string("##her") + std::to_string(i)).c_str(), &v, 0.0f, 1.0f, "%.2f")) {
                            // move this one, and share the change out over the other two, keeping their balance
                            const float others = 1.0f - d.look.heritage[size_t(i)];
                            for (int k = 0; k < 3; ++k) if (k != i)
                                d.look.heritage[size_t(k)] = others > 1e-4f ? d.look.heritage[size_t(k)] / others * (1.0f - v) : (1.0f - v) * 0.5f;
                            d.look.heritage[size_t(i)] = v;
                        }
                        track();
                    }
                    endProps();
                }
                d.look.clamp();
                if (ImGui::Button("A new face", ImVec2(-FLT_MIN, 0))) {
                    d.look.faceSeed = d.look.faceSeed * 1664525u + 1013904223u;
                    if (!d.look.faceSeed) d.look.faceSeed = 1;
                    clicked = true;
                }
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("Small differences in the nose, mouth, chin, cheeks and ears");
                if (ImGui::Button("Reset the body", ImVec2(-FLT_MIN, 0))) { d.shape = BodyShape(); d.look = HumanLook(); clicked = true; }
                ImGui::Dummy(ImVec2(0, 6 * s));
                section("Start from");
                const float bw = (ImGui::GetContentRegionAvail().x - 8 * s) / 3.0f;
                int i = 0;
                for (const CharacterDef& p : characterPresets()) {
                    if (i++ % 3) ImGui::SameLine(0, 4 * s);
                    if (ImGui::Button(p.name.c_str(), ImVec2(bw, 0))) { const std::string keep = d.name; d = p; d.name = keep; clicked = true; }
                    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Take %s's body, colours and hair (your name stays)", p.name.c_str());
                }
                ImGui::EndTabItem();
            }
            // a row of choices that wraps; returns the one clicked (-1: none)
            auto chips = [&](const char* id, const std::vector<std::string>& labels, int selected) {
                int hit = -1;
                float x = 0.0f;
                const float avail = ImGui::GetContentRegionAvail().x;
                ImGui::PushID(id);
                for (int i = 0; i < int(labels.size()); ++i) {
                    const float w = ImGui::CalcTextSize(labels[size_t(i)].c_str()).x + ImGui::GetStyle().FramePadding.x * 2.0f;
                    if (i && x + 4 * s + w <= avail) { ImGui::SameLine(0, 4 * s); x += 4 * s; }
                    else x = 0.0f;
                    x += w;
                    const bool on = i == selected;
                    if (on) pushSelectedButton();
                    ImGui::PushID(i);
                    if (ImGui::Button(labels[size_t(i)].c_str())) hit = i;
                    ImGui::PopID();
                    if (on) popSelectedButton();
                }
                ImGui::PopID();
                return hit;
            };
            const float sw = 26 * s;
            auto colourRow = [&](ColourRole role, const std::vector<glm::vec3>& choices) {
                section(colourRoleLabel(role));
                glm::vec3& c = d.colour(role);
                int n = 0;
                const int perRow = std::max(1, int((ImGui::GetContentRegionAvail().x - sw - 10 * s) / (sw + 6 * s)));
                for (const glm::vec3& ch : choices) {
                    if (n % perRow) ImGui::SameLine(0, 6 * s);
                    ImGui::PushID(int(role) * 100 + n);
                    if (swatch("##sw", ch, near3(ch, c), sw)) { c = ch; clicked = true; }
                    ImGui::PopID();
                    ++n;
                }
                ImGui::SameLine(0, 10 * s);
                float v[3] = { c.r, c.g, c.b };
                const std::string id = std::string("##pick") + colourRoleLabel(role);
                if (ImGui::ColorEdit3(id.c_str(), v, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel)) c = glm::vec3(v[0], v[1], v[2]);
                track();
            };
            if (ImGui::BeginTabItem("Look", nullptr, cs.tabForce == 1 ? ImGuiTabItemFlags_SetSelected : 0)) {
                cs.tab = 1;
                colourRow(ColourRole::Skin, skinTones());
                {   // the eyes' colour
                    section("Eye colour");
                    static const glm::vec3 eyeChoices[] = { { 0.22f, 0.14f, 0.08f }, { 0.30f, 0.20f, 0.12f }, { 0.45f, 0.34f, 0.18f }, { 0.36f, 0.45f, 0.26f },
                                                            { 0.36f, 0.48f, 0.62f }, { 0.25f, 0.3f, 0.35f } };
                    int n = 0;
                    for (const glm::vec3& ch : eyeChoices) {
                        if (n) ImGui::SameLine(0, 6 * s);
                        ImGui::PushID(900 + n);
                        if (swatch("##eye", ch, near3(ch, d.look.eyes), sw)) { d.look.eyes = ch; clicked = true; }
                        ImGui::PopID();
                        ++n;
                    }
                }
                auto faceRow = [&](const char* label, std::uint8_t& v, int count, const char* (*name)(int)) {
                    section(label);
                    std::vector<std::string> labels;
                    for (int i = 0; i < count; ++i) labels.push_back(name(i));
                    const int hit = chips(label, labels, int(v));
                    if (hit >= 0 && hit != int(v)) { v = std::uint8_t(hit); clicked = true; }
                };
                faceRow("Eyes", d.face.eyes, kEyeStyles, eyeStyleLabel);
                faceRow("Brows", d.face.brows, kBrowStyles, browStyleLabel);
                faceRow("Nose", d.face.nose, kNoseStyles, noseStyleLabel);
                faceRow("Mouth", d.face.mouth, kMouthStyles, mouthStyleLabel);
                section("Hair");
                {
                    std::vector<std::string> labels;
                    for (int h = 0; h < int(HairStyle::Count); ++h) labels.push_back(hairStyleLabel(HairStyle(h)));
                    const int hit = chips("hair", labels, int(d.hair));
                    if (hit >= 0) { d.hair = HairStyle(hit); clicked = true; }
                }
                ImGui::Dummy(ImVec2(0, 2 * s));
                colourRow(ColourRole::Hair, hairColours());
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Clothes", nullptr, cs.tabForce == 2 ? ImGuiTabItemFlags_SetSelected : 0)) {
                cs.tab = 2;
                auto slotRow = [&](const char* label, PartSlot slot) {
                    section(label);
                    const std::vector<const WardrobeItem*> items = wardrobeFor(slot);
                    std::string& cur = d.parts[size_t(slot)];
                    std::vector<std::string> labels;
                    const bool optional = isAccessorySlot(slot);
                    if (optional) labels.push_back("None");
                    int selected = optional && cur.empty() ? 0 : -1;
                    for (size_t i = 0; i < items.size(); ++i) {
                        labels.push_back(items[i]->label);
                        const bool isBody = std::string(items[i]->asset).rfind("body ", 0) == 0;
                        if (cur == items[i]->asset || (cur.empty() && isBody)) selected = int(i) + (optional ? 1 : 0);
                    }
                    const int hit = chips(label, labels, selected);
                    if (hit >= 0 && hit != selected) {
                        const int k = hit - (optional ? 1 : 0);
                        if (k < 0) cur.clear();
                        else cur = std::string(items[size_t(k)]->asset).rfind("body ", 0) == 0 ? std::string() : std::string(items[size_t(k)]->asset);
                        clicked = true;
                    }
                };
                slotRow("Top", PartSlot::Torso);
                slotRow("Arms", PartSlot::UpperArm);
                slotRow("Waist", PartSlot::Hips);
                slotRow("Legs", PartSlot::LowerLeg);
                slotRow("Feet", PartSlot::Foot);
                slotRow("Hat", PartSlot::Hat);
                slotRow("Glasses", PartSlot::Glasses);
                slotRow("Beard", PartSlot::Beard);
                slotRow("On the back", PartSlot::Back);
                const std::vector<glm::vec3> clothes(std::begin(kClothes), std::end(kClothes));
                colourRow(ColourRole::Top, clothes);
                colourRow(ColourRole::Bottoms, clothes);
                colourRow(ColourRole::Shoes, clothes);
                colourRow(ColourRole::Accent, clothes);
                section("A part in its own colour");
                if (beginProps("##owncol", 96.0f)) {
                    for (PartSlot slot : { PartSlot::Torso, PartSlot::Hips, PartSlot::Foot, PartSlot::Hat, PartSlot::Back }) {
                        if (isAccessorySlot(slot) && d.parts[size_t(slot)].empty()) continue;
                        prop(partSlotLabel(slot));
                        glm::vec4& pc = d.partColour[size_t(slot)];
                        bool own = pc.w > 0.5f;
                        ImGui::PushID(int(slot));
                        if (ImGui::Checkbox("##own", &own)) {
                            pc = own ? glm::vec4(d.colourOf(slot, colourRoleFor(slot)), 1.0f) : glm::vec4(0.0f);
                            clicked = true;
                        }
                        if (own) {
                            ImGui::SameLine();
                            float v[3] = { pc.r, pc.g, pc.b };
                            if (ImGui::ColorEdit3("##c", v, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel)) pc = glm::vec4(v[0], v[1], v[2], 1.0f);
                            track();
                        }
                        ImGui::PopID();
                    }
                    endProps();
                }
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Personality", nullptr, cs.tabForce == 3 ? ImGuiTabItemFlags_SetSelected : 0)) {
                cs.tab = 3;
                section("How they move");
                {
                    std::vector<std::string> labels;
                    int selected = -1;
                    const auto& presets = moveStylePresets();
                    for (size_t i = 0; i < presets.size(); ++i) { labels.push_back(presets[i].first); if (presets[i].second == d.move) selected = int(i); }
                    const int hit = chips("movepresets", labels, selected);
                    if (hit >= 0) { d.move = presets[size_t(hit)].second; clicked = true; if (cs.move == StudioMove::Stand) cs.move = StudioMove::Walk; }
                }
                ImGui::Dummy(ImVec2(0, 4 * s));
                if (beginProps("##move", 96.0f)) {
                    auto slider = [&](const char* label, const char* tip, float* v, float lo, float hi, const char* fmt) {
                        prop(label, tip);
                        ImGui::SetNextItemWidth(-FLT_MIN);
                        sliderFloat((std::string("##") + label).c_str(), v, lo, hi, fmt);
                        track();
                    };
                    slider("Stride", "Short steps or long strides", &d.move.stride, 0.7f, 1.3f, "%.2f");
                    slider("Swagger", "How much the hips and shoulders roll", &d.move.swagger, 0.0f, 1.0f, "%.2f");
                    slider("Arm swing", "Arms still, or swinging big", &d.move.armSwing, 0.0f, 1.6f, "%.2f");
                    slider("Bounce", "Smooth, or springy", &d.move.bounce, 0.0f, 2.0f, "%.2f");
                    slider("Posture", "Hunched over, or chest out", &d.move.posture, -1.0f, 1.0f, "%.2f");
                    slider("Fidgety", "Stands still, or always doing something while waiting", &d.move.fidget, 0.0f, 1.0f, "%.2f");
                    endProps();
                }
                d.move.clamp();
                section("Try a habit");
                {
                    std::vector<std::string> labels;
                    for (int f = 1; f < int(Fidget::Count); ++f) labels.push_back(fidgetLabel(Fidget(f)));
                    const int hit = chips("fidgets", labels, int(cs.anim.fidget()) - 1);
                    if (hit >= 0) { cs.move = StudioMove::Stand; cs.anim.startFidget(Fidget(hit + 1), 4.0f); }
                }
                ImGui::Dummy(ImVec2(0, 4 * s));
                section("Mood (to see the face)");
                {
                    std::vector<std::string> labels;
                    for (int m = 0; m < int(Mood::Count); ++m) labels.push_back(moodLabel(Mood(m)));
                    const int hit = chips("moods", labels, int(cs.mood));
                    if (hit >= 0) cs.mood = Mood(hit);
                }
                pushFont(fonts.small);
                ImGui::PushTextWrapPos(0.0f);
                ImGui::TextDisabled("They blink on their own. Moods are for trying faces here; in a game, what is happening sets them.");
                ImGui::PopTextWrapPos();
                popFont();
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Parts", nullptr, cs.tabForce == 4 ? ImGuiTabItemFlags_SetSelected : 0)) {
                cs.tab = 4;
                pushFont(fonts.small);
                ImGui::PushTextWrapPos(0.0f);
                ImGui::TextDisabled("Swap any part for one made in the Asset Workshop. A part is an asset tagged part:<slot> (for example part:head); "
                                    "its socket named joint is where it joins the body. The built-in parts take the character's colours.");
                ImGui::PopTextWrapPos();
                popFont();
                ImGui::Dummy(ImVec2(0, 4 * s));
                if (beginProps("##parts", 96.0f)) {
                    for (int sl = 0; sl < kPartSlotCount; ++sl) {
                        const PartSlot slot = PartSlot(sl);
                        prop(partSlotLabel(slot));
                        std::string& cur = d.parts[size_t(sl)];
                        const std::string builtinLabel = slot == PartSlot::Hair ? "Hair style (Look tab)" : isAccessorySlot(slot) ? "None (Clothes tab)" : "Built-in";
                        const WardrobeItem* wi = cur.empty() ? nullptr : wardrobeItem(cur);
                        const std::string shown = cur.empty() ? builtinLabel : wi ? std::string(wi->label) + " (Clothes tab)" : cur;
                        ImGui::PushID(sl);
                        ImGui::SetNextItemWidth(-30 * s);
                        if (ImGui::BeginCombo("##part", shown.c_str())) {
                            if (ImGui::Selectable(builtinLabel.c_str(), cur.empty())) { cur.clear(); clicked = true; }
                            for (const std::string& n : partsForSlot(assets, slot)) {
                                if (assets.isGenerated(n)) continue;                // the built-in ones are the line above
                                if (ImGui::Selectable(n.c_str(), cur == n)) { cur = n; clicked = true; }
                            }
                            ImGui::EndCombo();
                        }
                        ImGui::SameLine(0, 4 * s);
                        const std::string part = partAssetFor(d, slot);
                        ImGui::BeginDisabled(part.empty());
                        if (ImGui::Button("...")) { cs.afterLeave = "part:" + part; requestLeaveCharacterStudio(); }
                        ImGui::EndDisabled();
                        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("Open this part in the Asset Workshop to make your own version");
                        ImGui::PopID();
                    }
                    endProps();
                }
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }
        cs.tabForce = -1;
        ImGui::EndChild();

        // ---- the bottom of the panel: what to do with them
        ImGui::Dummy(ImVec2(0, 4 * s));
        section("Use");
        const float bw = (ImGui::GetContentRegionAvail().x - 6 * s) * 0.5f;
        if (ImGui::Button("Surprise me", ImVec2(-FLT_MIN, 0))) {
            const std::string keep = d.name;
            d = makeCrowdPerson(CrowdStyle::Anyone, 0x5EED0000u + cs.surprise++ * 7919u);
            d.name = keep;
            clicked = true;
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("A whole new person: body, face, clothes and way of moving (your name stays; Ctrl+Z goes back)");
        if (ImGui::Button("Place in the world", ImVec2(bw, 0))) { if (studioSave()) { cs.afterLeave = "place"; requestLeaveCharacterStudio(); } }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Saves, closes the Studio, and the next click in the world puts them there");
        ImGui::SameLine(0, 6 * s);
        const bool isPlayer = playerCharacter == d.name && !cs.originalName.empty();
        ImGui::BeginDisabled(isPlayer);
        if (ImGui::Button(isPlayer ? "This is you" : "Play as them", ImVec2(bw, 0))) { if (studioSave()) setPlayerCharacter(d.name); }
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("How you look in play mode in third person (press V while playing)");
        if (clicked) studioChanged(frameStart);
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);
}

void Application::drawStudioView() {
    const float s = scale();
    // Over the view: how they are moving, and what they hold.
    ImGui::SetNextWindowPos(ImVec2(viewRect.x + 14 * s, viewRect.y + viewRect.h - 14 * s), ImGuiCond_Always, ImVec2(0.0f, 1.0f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10 * s, 8 * s));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(11, 12, 16, 220));
    if (ImGui::Begin("##studiomoves", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {
        for (int m = 0; m < int(StudioMove::Count); ++m) {
            if (m) ImGui::SameLine(0, 4 * s);
            const bool on = cs.move == StudioMove(m);
            if (on) pushSelectedButton();
            if (ImGui::Button(studioMoveLabel(StudioMove(m)))) cs.move = StudioMove(m);
            if (on) popSelectedButton();
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Key %d", m + 1);
        }
        ImGui::SameLine(0, 14 * s);
        ImGui::AlignTextToFramePadding();
        ImGui::TextDisabled("Holding");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(170 * s);
        if (ImGui::BeginCombo("##held", cs.heldItem.empty() ? "Nothing" : cs.heldItem.c_str())) {
            if (ImGui::Selectable("Nothing", cs.heldItem.empty())) cs.heldItem.clear();
            for (const std::string& n : itemLibrary.names()) if (ImGui::Selectable(n.c_str(), cs.heldItem == n)) cs.heldItem = n;
            ImGui::EndCombo();
        }
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);

    if (showHints) {
        ImDrawList* dl = ImGui::GetForegroundDrawList();
        pushFont(fonts.small);
        const char* hint = "Right-drag: orbit    Middle-drag: pan    Wheel: zoom    Left-drag: turn them    F: frame    1-5: how they move";
        dl->AddText(ImVec2(viewRect.x + 14 * s, viewRect.y + 12 * s), IM_COL32(255, 255, 255, 170), hint);
        popFont();
    }
}

void Application::drawCharacterStudioUI() {
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const float s = scale();
    drawStudioMenuBar();
    const float statusH = ImGui::GetFontSize() + 14 * s;
    const float top = gStudioMenuH, bottom = vp->Pos.y + vp->Size.y - statusH;
    const float panelW = 350 * s;
    viewRect = { vp->Pos.x, top, std::max(8.0f, vp->Size.x - panelW), std::max(8.0f, bottom - top) };
    drawStudioView();
    drawStudioPanel(top, bottom);

    // status bar
    ImGui::SetNextWindowPos(ImVec2(0, bottom));
    ImGui::SetNextWindowSize(ImVec2(vp->Size.x, statusH));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10 * s, 0));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, col::bg);
    if (ImGui::Begin("##ccstatus", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus)) {
        ImGui::SetCursorPosY((statusH - ImGui::GetFrameHeight()) * 0.5f);
        pill("STUDIO", col::accentDim, col::accent);
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(cs.def.name.c_str());
        if (!(cs.def == cs.savedDef)) { ImGui::SameLine(0, 4 * s); ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "*"); }
        ImGui::SameLine();
        ImGui::TextDisabled("|  %.2f m  |  %s", double(cs.def.shape.height), studioMoveLabel(cs.move));
        ImGui::SameLine();
        ImGui::TextDisabled("|");
        ImGui::SameLine();
        ImGui::TextUnformatted(status.c_str());
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(2);

    // unsaved changes
    if (cs.askLeave && !ImGui::IsPopupOpen("Unsaved character")) ImGui::OpenPopup("Unsaved character");
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("Unsaved character", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove)) {
        if (!cs.askLeave) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); }
        else {
            pushFont(fonts.title); ImGui::Text("Save %s?", cs.def.name.c_str()); popFont();
            ImGui::TextDisabled("There are changes that are not saved.");
            ImGui::Dummy(ImVec2(0, 6 * s));
            const std::string after = cs.afterLeave;
            if (ImGui::Button("Save", ImVec2(110 * s, 0))) { if (studioSave()) studioRunAfter(after); else cs.askLeave = false; }
            ImGui::SameLine();
            if (ImGui::Button("Don't save", ImVec2(110 * s, 0))) { cs.savedDef = cs.def; studioRunAfter(after); }
            ImGui::SameLine();
            if (ImGui::Button("Cancel", ImVec2(110 * s, 0))) { cs.askLeave = false; cs.afterLeave.clear(); }
            ImGui::EndPopup();
        }
    }
    drawToasts(toasts, top + 12 * s);
}

} // namespace px
