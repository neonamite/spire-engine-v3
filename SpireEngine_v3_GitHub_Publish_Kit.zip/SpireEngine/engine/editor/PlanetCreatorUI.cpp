// C8: experimental planet creation in the existing ImGui Project Hub/editor.
// All destructive world changes are queued for Application's next frame.
#include "core/Application.h"
#include "world/PlanetCreatorModel.h"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <string>
#include <system_error>

namespace px {

// World Builder project wizard. Uses the existing deferred Hub/sandbox path
// and the existing planet creator; no competing terrain runtime or save format.
void Application::openNewProjectWizard() {
    newProjectType = 0;
    newProjectReplaceAcknowledged = false;
    newProjectWizardVisible = true;
}

void Application::drawNewProjectWizard() {
    if (newProjectWizardVisible) {
        ImGui::OpenPopup("New Project##spire");
        newProjectWizardVisible = false;
    }
    ImGui::SetNextWindowSize(ImVec2(540, 0), ImGuiCond_Appearing);
    if (!ImGui::BeginPopupModal("New Project##spire", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
        return;

    ImGui::TextUnformatted("SPIRE ENGINE  /  NEW WORLD BUILDER PROJECT");
    ImGui::Separator();
    ImGui::TextWrapped("Start with manual construction. Procedural terrain is optional and can be selected separately.");
    ImGui::Spacing();
    ImGui::RadioButton("Blank Construction Canvas (Recommended)", &newProjectType, 0);
    ImGui::TextDisabled("Flat, editable terrain with no hills, caves, water or scattered props.");
    ImGui::Spacing();
    ImGui::RadioButton("Generated Terrain (Advanced)", &newProjectType, 1);
    ImGui::TextDisabled("Generate a starting landscape, then sculpt, paint and build manually.");
    ImGui::Spacing();
    ImGui::RadioButton("Spherical Planet (Experimental)", &newProjectType, 2);
    ImGui::TextDisabled("Configure a small planet; editor flight only, player gravity unfinished.");

    if (mode == Mode::Editor) {
        ImGui::Separator();
        ImGui::TextWrapped("Creating a new world replaces the active editor session. Save your changes first.");
        if (ImGui::Button("Save Current World")) cmdSave();
        ImGui::Checkbox("Replace current editor session", &newProjectReplaceAcknowledged);
    }
    ImGui::Spacing();
    const bool canCreate = mode == Mode::Hub || newProjectReplaceAcknowledged;
    ImGui::BeginDisabled(!canCreate);
    if (ImGui::Button("Continue", ImVec2(175, 36))) {
        const int requested = newProjectType;
        ImGui::CloseCurrentPopup();
        if (requested == 2) {
            // The planet creator validates and queues the destructive world switch.
            newProjectWizardPopupRequested = true;
        } else if (mode == Mode::Hub) {
            requestSandbox(requested == 0 ? -2 : -3);
        } else if (requested == 0) {
            cmdNewBlankCanvas();
        } else {
            cmdNewWorld();
        }
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(100, 36))) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

void Application::openPlanetCreator() {
    planetPreset = 0;
    planetDraft = planetPresetSettings(PlanetPreset::Rocky);
    std::strncpy(planetNameInput, "New Planet", sizeof(planetNameInput) - 1);
    planetNameInput[sizeof(planetNameInput) - 1] = '\0';
    planetReplaceAcknowledged = false;
    planetCreatorVisible = true;
}

void Application::drawPlanetCreatorUI() {
    if (newProjectWizardPopupRequested) {
        newProjectWizardPopupRequested = false;
        openPlanetCreator();
    }
    if (planetCreatorVisible) {
        ImGui::OpenPopup("Create Planet##spire");
        planetCreatorVisible = false;
    }
    ImGui::SetNextWindowSize(ImVec2(520, 0), ImGuiCond_Appearing);
    if (!ImGui::BeginPopupModal("Create Planet##spire", nullptr, ImGuiWindowFlags_AlwaysAutoResize))
        return;

    ImGui::TextUnformatted("SPIRE ENGINE  /  PLANET CREATOR");
    ImGui::Separator();
    ImGui::TextWrapped("Create a spherical world-building canvas. Fly, sculpt terrain, place structures and save a .vxplanet project. The initial terrain is generated; authoring tools are the focus.");
    ImGui::Spacing();
    ImGui::InputText("Planet Name", planetNameInput, sizeof(planetNameInput));
    constexpr const char* presets[] = {"Rocky world", "Desert terrain", "Icy terrain", "Low-gravity moon", "Custom"};
    int selection = planetPreset;
    if (ImGui::Combo("Starting preset", &selection, presets, 5)) {
        planetPreset = selection;
        if (selection < 4) {
            const auto seed = planetDraft.planet.seed;
            planetDraft = planetPresetSettings(static_cast<PlanetPreset>(selection));
            planetDraft.planet.seed = seed; // never reset a seed entered by the creator
        }
    }

    ImGui::InputDouble("Radius (meters)", &planetDraft.planet.radiusMeters, 1.0, 10.0, "%.1f");
    ImGui::InputDouble("Terrain relief (m)", &planetDraft.planet.terrainAmplitudeMeters, 0.5, 2.0, "%.1f");
    ImGui::InputDouble("Gravity (m/s^2)", &planetDraft.planet.surfaceGravity, 0.1, 1.0, "%.2f");
    ImGui::InputScalar("Generation seed", ImGuiDataType_U64, &planetDraft.planet.seed);
    if (ImGui::TreeNode("Advanced procedural terrain (optional)")) {
        ImGui::InputFloat("Hill frequency", &planetDraft.hillFrequency, 0.1f, 1.0f, "%.3f");
        ImGui::InputFloat("Cave frequency", &planetDraft.caveFrequency, 0.005f, 0.02f, "%.3f");
        ImGui::InputFloat("Cave relief", &planetDraft.caveAmplitude, 0.25f, 1.0f, "%.2f");
        ImGui::InputDouble("Sea-level offset", &planetDraft.planet.seaLevelMeters, 0.5, 2.0, "%.1f");
        ImGui::TreePop();
    }

    planetDraft.planet.name = planetNameInput;
    planetDraft.planet.id = planetFileStem(planetDraft.planet.name);
    const std::string error = planetCreatorValidation(planetDraft);
    if (!error.empty()) ImGui::TextWrapped("Invalid setting: %s", error.c_str());
    ImGui::TextDisabled("Limits: radius 48-512 m; editor flight only; no orbit-scale LOD or radial player physics.");
    ImGui::TextDisabled("Presets affect terrain relief/noise, not biome materials yet.");
    if (mode == Mode::Editor) {
        ImGui::Separator();
        ImGui::TextWrapped("Creating a planet replaces the active unsaved editor session. Existing world save files are not overwritten.");
        if (ImGui::Button("Save current world first")) cmdSave();
        ImGui::Checkbox("I understand the active session will be replaced", &planetReplaceAcknowledged);
    }
    ImGui::Spacing();
    const bool allow = error.empty() && (mode == Mode::Hub || planetReplaceAcknowledged);
    ImGui::BeginDisabled(!allow);
    if (ImGui::Button("Create Planet", ImVec2(195, 36))) {
        pendingPlanetCreation = planetDraft;
        planetCreateRequested = true;
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Cancel", ImVec2(100, 36))) ImGui::CloseCurrentPopup();
    ImGui::EndPopup();
}

} // namespace px

namespace px {
void Application::drawPlanetOpenConfirmation() {
    if (planetOpenConfirmVisible) {
        ImGui::OpenPopup("Switch Planet##spire");
        planetOpenConfirmVisible = false;
    }
    if (!ImGui::BeginPopupModal("Switch Planet##spire", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) return;
    ImGui::TextWrapped("Open %s? Unsaved changes in the current editor session may be lost.",
                       std::filesystem::path(pendingPlanetOpenPath).filename().string().c_str());
    if (ImGui::Button("Save Current World")) cmdSave();
    ImGui::SameLine();
    if (ImGui::Button("Open Selected Planet")) {
        planetOpenRequested = true;
        ImGui::CloseCurrentPopup();
    }
    ImGui::SameLine();
    if (ImGui::Button("Cancel")) {
        pendingPlanetOpenPath.clear();
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}
} // namespace px
