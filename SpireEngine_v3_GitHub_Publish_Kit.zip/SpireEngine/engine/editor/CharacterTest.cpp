#include <algorithm>
// --demo cc_...: screenshots of characters (v0.18), and a self test that drives the real code (the Studio's keys and
// changes, placing a character with a click, third person in play mode) and prints "[cctest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "character/BodyParts.h"
#include "character/Wardrobe.h"
#include "character/SkinnedBody.h"
#include "character/HumanBody.h"
#include <cmath>
#include <filesystem>
#include <iostream>
#include <set>
#include <string>

namespace px {

namespace {
template <class Cam>
void aimFrom(Cam& cam, const glm::vec3& from, const glm::vec3& at) {
    const glm::vec3 d = at - from;
    cam.position = from;
    cam.yaw = glm::degrees(std::atan2(d.z, d.x));
    cam.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
}
std::string itemLike(const ItemLibrary& lib, const char* part) {
    for (const std::string& n : lib.names()) {
        std::string l = n;
        for (char& c : l) c = char(std::tolower(static_cast<unsigned char>(c)));
        if (l.find(part) != std::string::npos) return n;
    }
    return {};
}
} // namespace

void Application::setupCharacterDemo() {
    if (demo == "cc_selftest") { runCharacterSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.5f; timeFlowing = false;
    showHints = false;
    toasts.clear();
    const glm::vec3 c = demospot::calmSpot(world);

    if (demo == "cc_studio" || demo == "cc_studiolook" || demo == "cc_studioparts" || demo == "cc_studioclothes" || demo == "cc_studiopersonality") {
        openCharacterStudio(demo == "cc_studio" ? "Builder" : demo == "cc_studioclothes" ? "Explorer" : demo == "cc_studiopersonality" ? "Kid" : "Scientist");
        cs.move = demo == "cc_studio" ? StudioMove::Walk : demo == "cc_studiopersonality" ? StudioMove::Stand : StudioMove::Look;
        cs.heldItem = demo == "cc_studio" ? itemLike(itemLibrary, "rifle") : std::string();
        cs.tabForce = demo == "cc_studiolook" ? 1 : demo == "cc_studioclothes" ? 2 : demo == "cc_studiopersonality" ? 3 : demo == "cc_studioparts" ? 4 : 0;
        if (demo == "cc_studiopersonality") { cs.mood = Mood::Happy; cs.anim.startFidget(Fidget::HandsOnHips, 1000.0f); }
        if (demo == "cc_studiolook") cs.mood = Mood::Calm;
        cs.turn = 25.0f;
        showHints = true;
        toasts.clear();
        status = "";
        return;
    }
    if (demo == "cc_bend") {                                               // 1.3: knees and elbows bending (run, side on)
        openCharacterStudio("Explorer");
        cs.move = StudioMove::Run;
        cs.tabForce = 0;
        cs.turn = 80.0f;
        cs.distance = 2.6f;
        for (int i = 0; i < 37; ++i) updateCharacterStudio(1.0f / 60.0f);
        toasts.clear();
        status = "";
        return;
    }
    if (demo == "hm_skirt" || demo == "hm_robe" || demo == "hm_run") {      // 1.6: a skirt, a robe; long hair and a coat on the run
        openCharacterStudio(demo == "hm_run" ? "Scientist" : "Explorer");
        CharacterDef& d = cs.def;
        if (demo == "hm_run") {
            d.hair = HairStyle::Long; d.parts[size_t(PartSlot::Glasses)].clear();
            cs.move = StudioMove::Run;
            cs.turn = -80.0f;
        } else {
            d.look.gender = 0.05f; d.hair = demo == "hm_skirt" ? HairStyle::Ponytail : HairStyle::Long;
            d.parts[size_t(PartSlot::Hips)] = demo == "hm_skirt" ? "hips skirt" : "hips robe";
            d.parts[size_t(PartSlot::Hat)].clear(); d.parts[size_t(PartSlot::Back)].clear();
            d.colour(ColourRole::Bottoms) = glm::vec3(0.55f, 0.12f, 0.16f);
            cs.move = StudioMove::Walk;
            cs.turn = 30.0f;
        }
        cs.mood = Mood::Calm;
        cs.tabForce = 0;
        cs.distance *= 0.8f;
        cs.pitch = -4.0f;
        toasts.clear();
        status = "";
        return;
    }
    if (demo.rfind("hm_face", 0) == 0 || demo.rfind("hm_body", 0) == 0) {    // 1.5: a realistic face (hm_face<n>) or body (hm_body<n>), front on
        static const char* who[] = { "Explorer", "Scientist", "Agent", "Builder", "Kid", "Giant" };
        const bool face = demo.rfind("hm_face", 0) == 0;
        const int n = demo.size() > 7 ? std::clamp(demo[7] - '0', 0, 5) : 0;
        openCharacterStudio(who[n]);
        cs.move = StudioMove::Stand;
        cs.mood = Mood::Calm;
        cs.tabForce = 0;
        cs.turn = face ? 8.0f : 20.0f;
        if (face) { cs.target.y *= 1.68f; cs.distance = 0.62f; } else { cs.distance *= 0.8f; }
        cs.pitch = face ? -2.0f : -4.0f;
        toasts.clear();
        status = "";
        return;
    }
    if (demo == "cc_portrait" || demo == "cc_portrait2") {                // a close look at a face (1.2's sculpted heads)
        openCharacterStudio(demo == "cc_portrait" ? "Scientist" : "Builder");
        cs.move = StudioMove::Stand;
        cs.mood = Mood::Calm;
        cs.tabForce = 1;
        cs.turn = demo == "cc_portrait" ? 18.0f : -60.0f;
        cs.target.y *= 1.66f;                                             // from the middle of the body up to the eyes
        cs.distance = 0.75f;
        cs.pitch = -2.0f;
        toasts.clear();
        status = "";
        return;
    }
    if (demo == "cc_lineup") {
        // Everyone ready-made, in a row, looking at you.
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 6.0f), 14.0f);
        world.paint(glm::vec3(c.x, c.y, c.z - 5.0f), 7.0f, MAT_DIRT);              // a bare patch, so the grass does not hide their feet
        const auto& people = characterPresets();
        const float gap = 1.45f;
        float x = -gap * float(people.size() - 1) * 0.5f;
        for (const CharacterDef& p : people) {
            const float gy = demospot::groundHeight(world, c.x + x, c.z - 6.0f);
            placeCharacter(p.name, glm::vec3(c.x + x, gy, c.z - 6.0f), 0.0f);
            x += gap;
        }
        selection.clear();
        aimFrom(camera, glm::vec3(c.x, c.y + 1.9f, c.z + 0.6f), glm::vec3(c.x, c.y + 1.0f, c.z - 6.0f));
        for (int i = 0; i < 40; ++i) updateObjects(1.0f / 30.0f);                 // let them turn their heads
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "cc_crowd" || demo == "cc_wardrobe" || demo == "cc_faces") {
        // A crowd: everyone different. cc_wardrobe: a close row of people from every crowd style. cc_faces: their faces.
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 8.0f), 18.0f);
        world.paint(glm::vec3(c.x, c.y, c.z - 8.0f), 10.0f, MAT_DIRT);
        if (demo == "cc_crowd") {
            makeCrowd(CrowdStyle::Villagers, 30, glm::vec3(c.x, c.y, c.z - 9.0f), 6.5f, 1000);
            aimFrom(camera, glm::vec3(c.x + 1.0f, c.y + 3.4f, c.z + 1.5f), glm::vec3(c.x, c.y + 0.8f, c.z - 8.0f));
        } else {
            const bool faces = demo == "cc_faces";
            const int n = faces ? 5 : 7;
            const float gap = faces ? 0.62f : 1.15f, z = c.z - (faces ? 3.0f : 5.0f);
            float x = -gap * float(n - 1) * 0.5f;
            const CrowdStyle styles[] = { CrowdStyle::Villagers, CrowdStyle::City, CrowdStyle::Soldiers, CrowdStyle::SciFi, CrowdStyle::Fantasy,
                                          CrowdStyle::City, CrowdStyle::Villagers };
            for (int i = 0; i < n; ++i) {
                const std::string who = crowdName(styles[i], std::uint32_t(faces ? 40 + i * 3 : 20 + i));
                const float gy = demospot::groundHeight(world, c.x + x, z);
                placeCharacter(who, glm::vec3(c.x + x, gy, z), 0.0f);
                x += gap;
            }
            if (faces) aimFrom(camera, glm::vec3(c.x, c.y + 1.62f, c.z - 1.25f), glm::vec3(c.x, c.y + 1.5f, z));
            else aimFrom(camera, glm::vec3(c.x, c.y + 1.6f, c.z - 0.6f), glm::vec3(c.x, c.y + 1.0f, z));
        }
        selection.clear();
        for (int i = 0; i < 40; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "cc_hats" || demo == "cc_glasses" || demo == "cc_outfits" || demo == "cc_backs") {
        // Every item of one kind, each on the same plain person, close up (to check how they sit).
        world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 4.0f), 12.0f);
        world.paint(glm::vec3(c.x, c.y, c.z - 4.0f), 6.0f, MAT_DIRT);
        std::vector<CharacterDef> people;
        auto dressed = [&](PartSlot slot, const char* asset) {
            CharacterDef d;
            d.name = std::string("cc demo ") + asset;
            d.parts[size_t(slot)] = asset;
            d.colour(ColourRole::Accent) = glm::vec3(0.2f, 0.45f, 0.8f);
            people.push_back(d);
        };
        if (demo == "cc_hats") for (const WardrobeItem* w : wardrobeFor(PartSlot::Hat)) dressed(PartSlot::Hat, w->asset);
        if (demo == "cc_glasses") {
            for (const WardrobeItem* w : wardrobeFor(PartSlot::Glasses)) dressed(PartSlot::Glasses, w->asset);
            for (const WardrobeItem* w : wardrobeFor(PartSlot::Beard)) dressed(PartSlot::Beard, w->asset);
        }
        if (demo == "cc_backs") for (const WardrobeItem* w : wardrobeFor(PartSlot::Back)) dressed(PartSlot::Back, w->asset);
        if (demo == "cc_outfits") {
            for (PartSlot sl : { PartSlot::Torso, PartSlot::Hips, PartSlot::UpperArm, PartSlot::LowerLeg, PartSlot::Foot })
                for (const WardrobeItem* w : wardrobeFor(sl)) if (std::string(w->asset).rfind("body ", 0) != 0) dressed(sl, w->asset);
        }
        const bool close = demo == "cc_hats" || demo == "cc_glasses";
        const float gap = close ? 0.5f : 0.9f, z = c.z - 4.0f;
        float x = -gap * float(people.size() - 1) * 0.5f;
        for (CharacterDef& d : people) {
            if (demo == "cc_backs") d.name += " ";
            std::string err;
            characters.save(d, &err);                                                 // into the library for this run...
            std::error_code ec;
            std::filesystem::remove(characters.directory + "/" + characterFileName(d.name) + ".pxcharacter", ec);   // ...but not left on disk
            const float gy = demospot::groundHeight(world, c.x + x, z);
            const ObjectId id = placeCharacter(d.name, glm::vec3(c.x + x, gy, z), demo == "cc_backs" ? 150.0f : 0.0f);
            (void)id;
            x += gap;
        }
        const float back = close ? 2.1f : 4.6f;
        aimFrom(camera, glm::vec3(c.x, c.y + (close ? 1.75f : 1.3f), z + back), glm::vec3(c.x, c.y + (close ? 1.62f : 0.95f), z));
        selection.clear();
        for (int i = 0; i < 40; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "cc_third" || demo == "cc_thirdsword") {
        // You, in third person, holding something, standing in the world.
        thirdPerson = true;
        playerCharacter = demo == "cc_third" ? "Agent" : "Explorer";
        camera.position = glm::vec3(c.x, c.y + 1.7f, c.z);
        camera.yaw = -90.0f + 25.0f; camera.pitch = -4.0f;
        setMode(Mode::Play);
        if (inventory.enabled) {
            const std::string want = itemLike(itemLibrary, demo == "cc_third" ? "rifle" : "sword");
            for (int i = 0; i < 9; ++i) if (const ItemDef* d = inventory.defAt(i); d && d->name == want) { inventory.select(i); break; }
        }
        itemsFrozen = true;
        toasts.clear();
        return;
    }
    if (demo == "cc_steps") {
        // Foot IK: someone standing at the edge of a crate, one foot up on it, one on the ground.
        const glm::vec3 g(c.x, c.y, c.z - 5.0f);
        world.flatten(glm::vec3(g.x, g.y + 0.05f, g.z), 10.0f);
        world.paint(glm::vec3(g.x, g.y, g.z), 4.0f, MAT_DIRT);
        const float gy = demospot::groundHeight(world, g.x, g.z);
        SceneObject block;
        block.asset = "crate";
        block.name = "step";
        block.scale = 0.3f;
        const ObjectId bid = scene.add(block);
        updateObjects(0.0f);
        glm::vec3 mn, mx;
        scene.worldBounds(bid, mn, mx);
        scene.mutate(bid)->scale = 0.3f * 0.30f / std::max(0.05f, mx.y - mn.y);          // a 30 cm step
        updateObjects(0.0f);
        scene.worldBounds(bid, mn, mx);
        mn -= scene.find(bid)->position; mx -= scene.find(bid)->position;
        // the crate's right side ends just left of where the person stands, its bottom on the ground
        scene.mutate(bid)->position = glm::vec3(g.x + 0.02f - mn.x, gy - mn.y - 0.02f, g.z - (mn.z + mx.z) * 0.5f);
        commitScene("step");
        updateObjects(0.0f);
        placeCharacter("Explorer", glm::vec3(g.x, gy, g.z), 0.0f);
        selection.clear();
        aimFrom(camera, glm::vec3(g.x - 0.9f, gy + 1.0f, g.z + 2.4f), glm::vec3(g.x + 0.1f, gy + 0.6f, g.z));
        for (int i = 0; i < 40; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
}

void Application::runCharacterSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[cctest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto key = [&](SDL_Keycode k, SDL_Keymod mod = SDL_KMOD_NONE) {
        SDL_SetModState(mod);
        SDL_Event e{};
        e.type = SDL_EVENT_KEY_DOWN; e.key.key = k; e.key.mod = mod; e.key.down = true; e.key.repeat = false;
        handleEvent(e);
        SDL_SetModState(SDL_KMOD_NONE);
    };
    setMode(Mode::Editor);
    tool = Tool::Select;
    uiHidden = false;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    std::error_code ec;
    std::filesystem::remove("characters/cc_selftest_person.pxcharacter", ec);
    const Camera before = camera;

    // ---- the Studio
    key(SDLK_C, SDL_KMOD_CTRL | SDL_KMOD_SHIFT);
    check(cs.active && !renderSettings.drawWorld, "Ctrl+Shift+C opens the Character Studio, with the world put away");
    check(cs.def.name == "New character" && cs.originalName.empty(), "...with a new character to start from");
    updateCharacterStudio(1.0f / 60.0f);
    // a part per bone (or, skinned: one body plus the head, hands and feet), hair, and each accessory worn
    const int bodyDraws = characterSkinning() ? kBoneCount - kSkinnedBoneCount + 1 : kBoneCount;
    auto voxelParts = [bodyDraws](const CharacterDef& d) {
        int n = bodyDraws + (d.hair != HairStyle::None || !d.parts[size_t(PartSlot::Hair)].empty());
        for (PartSlot s : { PartSlot::Hat, PartSlot::Glasses, PartSlot::Beard, PartSlot::Back }) n += !d.parts[size_t(s)].empty();
        return n;
    };
    // 1.5: a realistic body is one draw (skirts and coats are part of it), its hair and beard strands another, shoes as parts,
    // and what they wear
    auto humanParts = [](const CharacterDef& d) {
        const std::string& beard = d.parts[size_t(PartSlot::Beard)];
        const bool builtInBeard = beard == "beard full" || beard == "beard moustache" || beard == "beard goatee";
        const bool cardHair = d.parts[size_t(PartSlot::Hair)].empty() && d.hair != HairStyle::None;
        int n = 1 + 2 + ((cardHair || builtInBeard) ? 1 : 0) + (d.parts[size_t(PartSlot::Hair)].empty() ? 0 : 1);
        for (PartSlot s : { PartSlot::Hat, PartSlot::Glasses, PartSlot::Back }) n += !d.parts[size_t(s)].empty();
        n += (!beard.empty() && !builtInBeard) ? 1 : 0;
        return n;
    };
    // (a body still waiting its turn to be built is drawn the 1.4 way for a frame or two: either count is right)
    auto partsOf = [&](const CharacterDef& d, int extra = 0) {
        return lastCharacterDraws == voxelParts(d) + extra || (usesHumanBody(d) && lastCharacterDraws == humanParts(d) + extra);
    };
    check(partsOf(cs.def), "the character is drawn: a part on every bone, hair and what they wear");
    const CharacterDef start = cs.def;
    CharacterDef was = cs.def;
    cs.def.shape.height = 2.05f;
    studioChanged(was);
    check(cs.undo.size() == 1 && !(cs.def == cs.savedDef), "changing the height is one undo step, and counts as unsaved");
    key(SDLK_Z, SDL_KMOD_CTRL);
    check(std::fabs(cs.def.shape.height - start.shape.height) < 1e-5f, "Ctrl+Z puts the height back");
    key(SDLK_Y, SDL_KMOD_CTRL);
    check(std::fabs(cs.def.shape.height - 2.05f) < 1e-5f, "Ctrl+Y does it again");
    key(SDLK_2);
    for (int i = 0; i < 40; ++i) updateCharacterStudio(1.0f / 60.0f);
    check(cs.move == StudioMove::Walk && cs.anim.moveAmount() > 0.8f, "2 makes them walk on the spot");
    key(SDLK_3);
    for (int i = 0; i < 60; ++i) updateCharacterStudio(1.0f / 60.0f);
    check(cs.anim.runAmount() > 0.8f, "3 makes them run");
    const std::string rifle = itemLike(itemLibrary, "rifle");
    cs.heldItem = rifle;
    key(SDLK_1);
    updateCharacterStudio(1.0f / 60.0f);
    check(!rifle.empty() && partsOf(cs.def, 1), "they can hold an item from the item library");
    cs.heldItem.clear();

    // names and saving
    cs.def.name = "Explorer";
    check(!studioNameProblem().empty() && !studioSave(), "a ready-made character's name can't be saved over");
    cs.def.name = "cc selftest person";
    was = cs.def;
    cs.def.colour(ColourRole::Top) = glm::vec3(0.9f, 0.1f, 0.1f);
    cs.def.hair = HairStyle::Long;
    studioChanged(was);
    key(SDLK_S, SDL_KMOD_CTRL);
    check(std::filesystem::exists("characters/cc_selftest_person.pxcharacter") && characters.isYours("cc selftest person"), "Ctrl+S saves it as a .pxcharacter file");
    check(cs.def == cs.savedDef && cs.originalName == "cc selftest person", "...and it is no longer unsaved");
    {
        CharacterDef back;
        check(loadCharacterFile("characters/cc_selftest_person.pxcharacter", back) && back.hair == HairStyle::Long && back.shape == cs.def.shape, "the file has everything in it");
    }
    // leaving with changes asks first
    was = cs.def;
    cs.def.shape.build = 1.3f;
    studioChanged(was);
    key(SDLK_ESCAPE);
    check(cs.askLeave && cs.active, "leaving with unsaved changes asks first");
    key(SDLK_ESCAPE);
    check(!cs.askLeave && cs.active, "...and Esc cancels the question");
    cs.def = cs.savedDef;
    key(SDLK_ESCAPE);
    check(!cs.active && renderSettings.drawWorld, "with nothing unsaved, Esc goes straight back to the world");
    check(glm::length(camera.position - before.position) < 1e-3f, "...and the camera is where it was");

    // ---- in the world
    const glm::vec3 c = demospot::calmSpot(world);
    const glm::vec3 g(c.x, demospot::groundHeight(world, c.x, c.z - 6.0f), c.z - 6.0f);
    startPlacingCharacter("cc selftest person");
    check(placingAsset == kCharacterStandIn && placingCharacter == "cc selftest person", "placing a character");
    camera.position = g + glm::vec3(0.0f, 12.0f, 0.0f); camera.yaw = -90.0f; camera.pitch = -89.0f;
    updateObjects(0.0f);
    glm::vec2 sp;
    gizmoView().project(g, sp);
    mouseX = sp.x; mouseY = sp.y;
    updateObjects(1.0f / 60.0f);
    check(ghostValid && lastCharacterDraws == 0, "the character follows the cursor before the click");
    const size_t n0 = scene.size();
    selectToolMouseDown(false);
    ObjectId who = 0;
    for (const SceneObject& o : scene.objects()) if (o.character == "cc selftest person") who = o.id;
    check(scene.size() == n0 + 1 && who != 0, "a click puts them in the world");
    check(who && std::fabs(scene.find(who)->scale - 2.05f / 1.8f) < 1e-3f, "...their stand-in as tall as they are");
    stopPlacing();
    updateObjects(1.0f / 60.0f);
    check(partsOf(characters.get("cc selftest person")), "they are drawn as a posed body, not as the stand-in");
    check(characterOf(who) && characterOf(who)->hair == HairStyle::Long, "the object knows who they are");
    {
        Scene again;
        check(again.fromText(scene.toText()) && again.find(who) && again.find(who)->character == "cc selftest person", "they are saved with the world");
    }
    // looking at you when you come close
    camera.position = g + glm::vec3(1.5f, 1.7f, 3.0f); camera.yaw = -100.0f; camera.pitch = -5.0f;
    for (int i = 0; i < 30; ++i) updateObjects(1.0f / 30.0f);
    {
        const glm::mat4& head = npcAnim[who].output().world[size_t(Bone::Head)];
        const glm::vec3 face = glm::vec3(head * glm::vec4(0, 0, 1, 0));
        check(face.x > 0.15f, "they turn their head to look at you");
    }
    cmdUndo();
    check(!scene.find(who), "Ctrl+Z takes them away again");
    cmdRedo();

    // ---- you, in third person
    setPlayerCharacter("cc selftest person");
    camera.position = g + glm::vec3(0.0f, 1.7f, 5.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    setMode(Mode::Play);
    key(SDLK_V);
    check(thirdPerson, "V in play mode switches to third person");
    for (int i = 0; i < 20; ++i) update(1.0f / 60.0f);
    const glm::vec3 eye = player.eye();
    check(glm::length(camera.position - eye) > 1.0f && glm::dot(camera.front(), eye - camera.position) > 0.0f, "the camera is behind you");
    check(lastCharacterDraws >= bodyDraws + 1, "and you can see yourself");
    key(SDLK_V);
    update(1.0f / 60.0f);
    check(!thirdPerson && glm::length(camera.position - player.eye()) < 1e-3f, "V again: back to your own eyes");
    setMode(Mode::Editor);

    // ---- v0.19: a crowd, everyone different, one undo step
    {
        const size_t n0 = scene.size();
        const std::vector<ObjectId> ids = makeCrowd(CrowdStyle::City, 10, g + glm::vec3(0.0f, 0.0f, -6.0f), 4.0f, 500);
        check(ids.size() == 10 && scene.size() == n0 + 10, "Make a Crowd puts ten people in the world");
        std::set<std::string> names, who2;
        bool apart = true;
        for (ObjectId a : ids) {
            const SceneObject* o = scene.find(a);
            if (!o) continue;
            names.insert(o->name); who2.insert(o->character);
            for (ObjectId b : ids) if (a < b && scene.find(b) && glm::length(o->position - scene.find(b)->position) < 0.85f) apart = false;
        }
        check(who2.size() == 10 && names.size() >= 8 && apart, "...each a different person, with their own name, not on top of each other");
        updateObjects(1.0f / 60.0f);
        check(lastCharacterDraws >= bodyDraws * 10, "...and they are drawn as people");
        Scene again;
        check(again.fromText(scene.toText()) && again.find(ids[0]) && again.find(ids[0])->character == scene.find(ids[0])->character, "...saved with the world by their crowd name");
        cmdUndo();
        check(scene.size() == n0, "one Ctrl+Z takes the whole crowd away");
        cmdRedo();
        // a crowd person opens in the Studio as themselves
        const std::string first = scene.find(ids[0]) ? scene.find(ids[0])->character : std::string();
        openCharacterStudio(first);
        check(cs.active && cs.def.name == characters.get(first).name && cs.def.parts == characters.get(first).parts, "a crowd person opens in the Studio as they are");
        leaveCharacterStudio();
        cmdUndo();
    }
    // ---- the face and personality in the Studio
    openCharacterStudio("Explorer");
    {
        const CharacterDef before = cs.def;
        cs.def.face.mouth = 4; cs.def.parts[size_t(PartSlot::Hat)] = "hat top hat"; cs.def.move = moveStylePresets()[1].second;
        studioChanged(before);
        updateCharacterStudio(1.0f / 60.0f);
        check(partsOf(cs.def), "a top hat in the Studio is drawn on them");
        studioUndo();
        check(cs.def == before, "...and Ctrl+Z takes the change back");
        cs.mood = Mood::Angry;
        updateCharacterStudio(1.0f / 60.0f);
        check(cs.anim.output().mouth == 4 && cs.anim.output().brows == 2, "a mood changes their face");
        cs.anim.startFidget(Fidget::CrossArms, 2.0f);
        for (int i = 0; i < 30; ++i) updateCharacterStudio(1.0f / 60.0f);
        check(cs.anim.fidget() == Fidget::CrossArms, "Try a habit: they cross their arms");
        cs.mood = Mood::Calm;
        leaveCharacterStudio();
    }

    std::filesystem::remove("characters/cc_selftest_person.pxcharacter", ec);
    std::cerr << "[cctest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
