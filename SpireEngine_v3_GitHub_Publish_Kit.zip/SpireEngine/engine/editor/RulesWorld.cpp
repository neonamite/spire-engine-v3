// "When this happens -> do that" in the editor and in play (v0.21). The rules themselves are in rules/Rules.* (pure,
// unit tested); this file hands them the world each frame (you, what you press E on, where everything is), applies what
// comes back (doors swing, coins vanish, messages show, sounds play, you get teleported, people speak, points add up,
// the game is won or lost), and draws the Rules section of Properties where you write them, one sentence at a time.
#include "core/Application.h"
#include "editor/Panels.h"
#include "rules/Gadgets.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <glm/gtc/matrix_transform.hpp>
#include <imgui.h>

namespace px {

using namespace ui;

const RuleSet* Application::rulesOf(ObjectId id) {
    const SceneObject* o = scene.find(id);
    if (!o || o->rules.empty()) { ruleCache.erase(id); return nullptr; }
    RuleCacheEntry& c = ruleCache[id];
    if (c.text != o->rules) {
        c.text = o->rules;
        c.set = RuleSet();
        if (!rulesFromText(o->rules, c.set)) c.set = RuleSet();
    }
    return &c.set;
}

void Application::setRules(ObjectId id, const RuleSet& in, const std::string& undoLabel) {
    SceneObject* o = scene.mutate(id);
    if (!o) return;
    RuleSet r = in;
    r.clamp();
    o->rules = r.rules.empty() && !r.startsOpen && !r.startsHidden ? std::string() : rulesToText(r);
    commitScene(undoLabel);
}

// ---------------------------------------------------------------- play

void Application::startRules() {
    ruleEngine.reset();
    ruleBanners.clear();
    gameOver = gameWon = false;
    gameOverText.clear();
    useRequested = false;
    useTarget = 0;
    ruleObjects.clear();
    anyScoreRules = false;
    scene.evaluate(assets, 0.0, false);                      // where everything is at the start
    // Everything with rules, and everything a rule points at.
    std::vector<ObjectId> ids;
    for (const SceneObject& o : scene.objects()) {
        const RuleSet* r = rulesOf(o.id);
        if (!r) continue;
        ids.push_back(o.id);
        for (const Rule& rule : r->rules)
            for (const RuleAction& a : rule.actions) {
                if (a.target != kRuleSelf && a.target != kRulePlayer && scene.find(a.target)) ids.push_back(a.target);
                if (a.what == RuleDo::AddScore || (a.what == RuleDo::Collect && a.number != 0.0f)) anyScoreRules = true;
            }
    }
    std::sort(ids.begin(), ids.end());
    ids.erase(std::unique(ids.begin(), ids.end()), ids.end());
    for (ObjectId id : ids) {
        RuleObject ro;
        ro.id = id;
        if (!scene.worldBounds(id, ro.boundsMin, ro.boundsMax)) {
            const glm::mat4 w = scene.restWorld(id);
            ro.boundsMin = ro.boundsMax = glm::vec3(w[3]);
        }
        ro.position = glm::vec3(scene.restWorld(id)[3]);
        ro.name = scene.find(id)->name;
        ruleObjects.push_back(ro);
    }
    // the game's own rules: where you start, lives, the clock, what there is to collect
    gameRulesNow = gameRulesOf();
    int collectables = 0;
    for (const RuleObject& ro : ruleObjects) {
        const RuleSet* r = rulesOf(ro.id);
        bool collects = false;
        if (r) for (const Rule& rule : r->rules) for (const RuleAction& a : rule.actions) collects = collects || (a.what == RuleDo::Collect && a.target == kRuleSelf);
        collectables += collects;
    }
    if (gameRulesNow.hasSpawn) {
        player.position = gameRulesNow.spawn;
        player.velocity = glm::vec3(0.0f);
        camera.yaw = gameRulesNow.spawnYaw; camera.pitch = 0.0f;
        camera.position = player.eye();
    }
    gameStart(gameRulesNow, gameState, player.position, collectables);
    playStartPos = player.position; playStartYaw = camera.yaw;
    if (gameRulesNow.goal == GameGoal::Points) anyScoreRules = true;
    if (!gameRulesNow.startText.empty()) ruleBanners.push_back({ gameRulesNow.startText, 5.0f, 5.0f });
    rulesRunning = true;
}

void Application::stopRules() {
    rulesRunning = false;
    ruleEngine.reset();
    ruleBanners.clear();
    gameOver = gameWon = false;
    useTarget = 0;
    ruleObjects.clear();
    scene.clearLive();
}

void Application::restartPlay() {
    const glm::vec3 at = playStartPos;
    const float yaw = playStartYaw;
    const bool wasPlayer = playerMode;
    playerMode = false;                                          // (a shared game passes through the editor for a moment)
    setMode(Mode::Editor);
    playerMode = wasPlayer;
    camera.position = at + glm::vec3(0.0f, player.eyeHeight, 0.0f);
    camera.yaw = yaw; camera.pitch = 0.0f;
    setMode(Mode::Play);
}

void Application::updateRules(float dt) {
    for (RuleBanner& b : ruleBanners) b.left -= dt;
    ruleBanners.erase(std::remove_if(ruleBanners.begin(), ruleBanners.end(), [](const RuleBanner& b) { return b.left <= 0.0f; }), ruleBanners.end());
    if (!rulesRunning || gameOver) { useRequested = false; return; }

    // What E would use: the thing you look at, within reach, that has a "press E" rule (or a part of one).
    useTarget = 0;
    useLabel.clear();
    {
        const glm::vec3 eye = player.eye(), dir = camera.front();
        Scene::Hit h;
        RayHit th;
        const float reach = 3.2f;
        const bool terrain = world.raycast(eye, dir, reach, th);
        if (scene.raycast(eye, dir, terrain ? th.distance : reach, h, true)) {
            for (ObjectId id = h.id; id; ) {
                const RuleSet* r = rulesOf(id);
                if (r && r->usable() && !ruleEngine.hidden(id)) { useTarget = id; break; }
                const SceneObject* o = scene.find(id);
                id = o ? o->parent : 0;
            }
        }
        if (useTarget) {
            const RuleSet* r = rulesOf(useTarget);
            for (const Rule& rule : r->rules) {
                if (rule.when != RuleWhen::Use || rule.actions.empty()) continue;
                switch (rule.actions.front().what) {
                case RuleDo::Toggle: useLabel = ruleEngine.isOpen(useTarget) ? "Close" : "Open"; break;
                case RuleDo::Open: useLabel = "Open"; break;
                case RuleDo::Close: useLabel = "Close"; break;
                case RuleDo::Say: useLabel = "Talk"; break;
                case RuleDo::Message: useLabel = "Read"; break;
                case RuleDo::Collect: useLabel = "Take"; break;
                default: useLabel = "Use"; break;
                }
                break;
            }
            const SceneObject* o = scene.find(useTarget);
            if (o && !o->character.empty() && useLabel == "Use") useLabel = "Talk";
        }
    }

    // The objects as the rules see them (their rules may have been changed in the editor since; people move about)
    for (RuleObject& ro : ruleObjects) {
        ro.rules = rulesOf(ro.id);
        const SceneObject* so = scene.find(ro.id);
        if (so && !so->character.empty()) scene.worldBounds(ro.id, ro.boundsMin, ro.boundsMax);
    }
    RuleInput in;
    in.dt = dt;
    in.player = player.position;
    in.playerHeight = player.eyeHeight + 0.15f;
    in.used = useRequested ? useTarget : 0;
    in.objects = ruleObjects;
    useRequested = false;
    RuleEffects fx;
    ruleEngine.tick(in, fx);

    for (const RuleEffects::Message& m : fx.messages) {
        if (m.text.empty()) continue;
        ruleBanners.push_back({ m.text, m.seconds, m.seconds });
        if (ruleBanners.size() > 4) ruleBanners.erase(ruleBanners.begin());
    }
    for (const RuleEffects::Sound& snd : fx.sounds) { playSfxAt(snd.name, snd.at, 0.9f); caption(snd.name); }
    if (fx.teleport) { player.position = fx.teleportTo; player.velocity = glm::vec3(0.0f); playerAnimFresh = true; }
    for (const auto& [who, text] : fx.says) {
        auto it = npcLive.find(who);
        if (it != npcLive.end()) { it->second.state.speech = text; it->second.state.speechLeft = 2.0f + 0.06f * float(text.size()); }
        else ruleBanners.push_back({ (scene.find(who) ? scene.find(who)->name + ": " : std::string()) + text, 4.0f, 4.0f });
    }
    // the game: lives, falls, checkpoints, the clock, the goal
    {
        GameTick t;
        t.dt = dt;
        t.score = ruleEngine.score();
        t.collectedNow = int(fx.collected.size());
        t.livesLost = fx.livesLost;
        t.fell = gameRulesNow.fallLimit > 0.0f && player.position.y < gameState.restart.y - gameRulesNow.fallLimit;
        t.ruleWon = fx.won; t.ruleLost = fx.lost; t.ruleText = fx.endText;
        t.checkpoint = fx.checkpoint; t.checkpointAt = fx.checkpointAt;
        t.addTime = fx.addTime;
        if (fx.checkpoint) ruleBanners.push_back({ "Checkpoint!", 1.6f, 1.6f });
        if (fx.addTime > 0.0f) { char b[48]; std::snprintf(b, sizeof b, "+%.0f seconds", double(fx.addTime)); ruleBanners.push_back({ b, 1.6f, 1.6f }); }
        const GameEvents ev = gameUpdate(gameRulesNow, gameState, t);
        if (ev.respawn && !gameState.over) {
            player.position = gameState.restart; player.velocity = glm::vec3(0.0f); playerAnimFresh = true;
            if (gameRulesNow.lives > 0) {
                char b[64]; std::snprintf(b, sizeof b, gameState.lives == 1 ? "Last life!" : "%d lives left", gameState.lives);
                ruleBanners.push_back({ b, 2.0f, 2.0f });
            }
            if (t.fell && fx.livesLost == 0) playUiSound("lose", 0.5f, 1.4f);
        }
        if (ev.ended) {
            gameOver = true; gameWon = gameState.won;
            gameOverText = gameState.text;
            playUiSound(gameWon ? "win" : "lose", 0.9f);
        }
    }

    // Doors swing, gates lift, collected things vanish.
    for (const RuleObject& ro : ruleObjects) {
        const SceneObject* o = scene.find(ro.id);
        if (!o) continue;
        scene.setLiveHidden(ro.id, ruleEngine.hidden(ro.id));
        if (!o->character.empty()) continue;                         // people are moved by their own lives (NpcWorld)
        const float a = ruleEngine.openAmount(ro.id);
        if (a <= 1e-4f) { scene.clearLiveTransform(ro.id); continue; }
        const AssetPtr asset = o->isGroup() ? nullptr : assets.get(o->asset);
        glm::vec3 mn(-0.5f, 0.0f, -0.1f), mx(0.5f, 2.0f, 0.1f);
        if (asset && !asset->mesh.empty()) { mn = asset->boundsMin; mx = asset->boundsMax; }
        const RuleSet* r = ro.rules;
        const OpenStyle style = r ? r->open : OpenStyle::Swing;
        const float e = a * a * (3.0f - 2.0f * a);                 // ease in and out
        glm::mat4 local(1.0f);
        switch (style) {
        case OpenStyle::Swing: {
            const glm::vec3 hinge(mn.x, 0.0f, (mn.z + mx.z) * 0.5f);
            local = glm::translate(glm::mat4(1.0f), hinge) * glm::rotate(glm::mat4(1.0f), glm::radians(90.0f * e), glm::vec3(0, 1, 0)) * glm::translate(glm::mat4(1.0f), -hinge);
            break;
        }
        case OpenStyle::Slide: local = glm::translate(glm::mat4(1.0f), glm::vec3(-(mx.x - mn.x) * 0.95f * e, 0.0f, 0.0f)); break;
        case OpenStyle::Lift: local = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, (mx.y - mn.y) * 0.95f * e, 0.0f)); break;
        case OpenStyle::Sink: local = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -(mx.y - mn.y) * 1.02f * e, 0.0f)); break;
        case OpenStyle::Count: break;
        }
        scene.setLiveMatrix(ro.id, scene.restWorld(ro.id) * local);
    }
}

void Application::drawRulesHUD() {
    const ImGuiIO& io = ImGui::GetIO();
    const float s = scale();
    const ImVec2 ds = io.DisplaySize;
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    // messages, newest at the bottom, high in the middle of the screen (bigger with Settings > Accessibility > bigger HUD)
    const float hud = hudScale();
    float y = ds.y * 0.2f;
    pushFont(fonts.title);
    for (const RuleBanner& b : ruleBanners) {
        const float fade = std::clamp(std::min(b.left, b.total - b.left + 0.2f) / 0.25f, 0.0f, 1.0f);
        const float wrap = std::min(640 * s * hud, ds.x - 80 * s);
        const ImVec2 ts0 = ImGui::CalcTextSize(b.text.c_str(), nullptr, false, wrap / hud);
        const ImVec2 ts(ts0.x * hud, ts0.y * hud);
        const ImVec2 a(ds.x * 0.5f - ts.x * 0.5f - 18 * s, y), c(ds.x * 0.5f + ts.x * 0.5f + 18 * s, y + ts.y + 16 * s);
        dl->AddRectFilled(a, c, IM_COL32(14, 16, 22, int(200 * fade)), 12 * s);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize() * hud, ImVec2(a.x + 18 * s, a.y + 8 * s), IM_COL32(255, 255, 255, int(250 * fade)), b.text.c_str(), nullptr, wrap);
        y = c.y + 8 * s;
    }
    popFont();
    // the E prompt
    if (useTarget && !gameOver && !paused) {
        pushFont(fonts.small);
        const std::string label = useLabel.empty() ? std::string("Use") : useLabel;
        const float hs = hudScale(), fs = ImGui::GetFontSize() * hs;
        const char* keyName = SDL_GetScancodeName(SDL_Scancode(settings.keys[Action::Use]));
        const std::string keyText = keyName && *keyName ? keyName : "E";
        const ImVec2 ts0 = ImGui::CalcTextSize(label.c_str()), ks0 = ImGui::CalcTextSize(keyText.c_str());
        const ImVec2 ts(ts0.x * hs, ts0.y * hs), ks(ks0.x * hs, ks0.y * hs);
        const ImVec2 at(ds.x * 0.5f + 22 * s * hs, ds.y * 0.5f + 18 * s * hs);
        const float k = 22 * s * hs, kw = std::max(k, ks.x + 10 * s);
        dl->AddRectFilled(at, ImVec2(at.x + kw, at.y + k), IM_COL32(245, 245, 245, 235), 5 * s);
        dl->AddText(ImGui::GetFont(), fs, ImVec2(at.x + kw * 0.5f - ks.x * 0.5f, at.y + (k - ts.y) * 0.5f), IM_COL32(20, 22, 28, 255), keyText.c_str());
        dl->AddRectFilled(ImVec2(at.x + kw + 4 * s, at.y), ImVec2(at.x + kw + 16 * s + ts.x, at.y + k), IM_COL32(14, 16, 22, 190), 5 * s);
        dl->AddText(ImGui::GetFont(), fs, ImVec2(at.x + kw + 10 * s, at.y + (k - ts.y) * 0.5f), IM_COL32(255, 255, 255, 240), label.c_str());
        popFont();
    }
    // the clock, lives and what is left to collect, top middle
    if (rulesRunning) {
        const GameRules& g = gameRulesNow;
        std::string line;
        if (g.timeLimit > 0.0f) line = gameClock(gameState.timeLeft(g));
        else if (g.goal == GameGoal::Finish) line = gameClock(gameState.time);
        if (g.goal == GameGoal::CollectAll && gameState.collectTotal > 0) {
            char b[48]; std::snprintf(b, sizeof b, "%s%d / %d collected", line.empty() ? "" : "    ", gameState.collected, gameState.collectTotal);
            line += b;
        }
        if (!line.empty()) {
            pushFont(fonts.title);
            const ImVec2 ts = ImGui::CalcTextSize(line.c_str());
            const ImVec2 a(ds.x * 0.5f - ts.x * 0.5f - 16 * s, 16 * s);
            const bool hurry = g.timeLimit > 0.0f && gameState.timeLeft(g) < 10.0f && g.goal != GameGoal::Survive;
            dl->AddRectFilled(a, ImVec2(a.x + ts.x + 32 * s, a.y + ts.y + 14 * s), hurry ? IM_COL32(120, 24, 20, 210) : IM_COL32(14, 16, 22, 190), 10 * s);
            dl->AddText(ImVec2(a.x + 16 * s, a.y + 7 * s), IM_COL32(255, 255, 255, 250), line.c_str());
            popFont();
        }
        if (g.lives > 0) {
            for (int i = 0; i < g.lives; ++i) {
                const ImVec2 c(28 * s + float(i) * 26 * s, 34 * s);
                const ImU32 colr = i < gameState.lives ? IM_COL32(235, 70, 80, 255) : IM_COL32(80, 80, 90, 200);
                dl->AddCircleFilled(ImVec2(c.x - 5 * s, c.y - 3 * s), 6.5f * s, colr);
                dl->AddCircleFilled(ImVec2(c.x + 5 * s, c.y - 3 * s), 6.5f * s, colr);
                dl->AddTriangleFilled(ImVec2(c.x - 11.2f * s, c.y - 1 * s), ImVec2(c.x + 11.2f * s, c.y - 1 * s), ImVec2(c.x, c.y + 11 * s), colr);
            }
        }
    }
    // points
    if (anyScoreRules) {
        pushFont(fonts.title);
        char b[48];
        if (gameRulesNow.goal == GameGoal::Points) std::snprintf(b, sizeof b, "%d / %d", ruleEngine.score(), gameRulesNow.points);
        else std::snprintf(b, sizeof b, "%d", ruleEngine.score());
        const ImVec2 ts = ImGui::CalcTextSize(b);
        const ImVec2 a(ds.x - ts.x - 70 * s, 18 * s);
        dl->AddRectFilled(a, ImVec2(ds.x - 18 * s, a.y + ts.y + 14 * s), IM_COL32(14, 16, 22, 190), 10 * s);
        dl->AddCircleFilled(ImVec2(a.x + 18 * s, a.y + (ts.y + 14 * s) * 0.5f), 8 * s, IM_COL32(250, 200, 60, 255));
        dl->AddText(ImVec2(a.x + 34 * s, a.y + 7 * s), IM_COL32(255, 255, 255, 250), b);
        popFont();
    }
    // the end
    if (gameOver) {
        dl->AddRectFilled(ImVec2(0, 0), ds, IM_COL32(8, 10, 14, 150));
        pushFont(fonts.title);
        const char* head = gameWon ? "You win!" : "Game over";
        const ImVec2 hs = ImGui::CalcTextSize(head);
        const float big = 2.2f;
        dl->AddText(nullptr, ImGui::GetFontSize() * big, ImVec2(ds.x * 0.5f - hs.x * big * 0.5f, ds.y * 0.38f), gameWon ? IM_COL32(255, 214, 90, 255) : IM_COL32(255, 120, 110, 255), head);
        if (gameOverText != head) {
            const ImVec2 ts = ImGui::CalcTextSize(gameOverText.c_str());
            dl->AddText(ImVec2(ds.x * 0.5f - ts.x * 0.5f, ds.y * 0.38f + hs.y * big + 14 * s), IM_COL32(255, 255, 255, 240), gameOverText.c_str());
        }
        popFont();
        pushFont(fonts.small);
        const char* tail = playerMode ? "Esc for the menu" : "Tab for the editor";
        char sc[128];
        if (anyScoreRules) std::snprintf(sc, sizeof sc, "%d points    R to play again    %s", ruleEngine.score(), tail);
        else std::snprintf(sc, sizeof sc, "R to play again    %s", tail);
        const char* hint = sc;
        const ImVec2 hs2 = ImGui::CalcTextSize(hint);
        dl->AddText(ImVec2(ds.x * 0.5f - hs2.x * 0.5f, ds.y * 0.56f), IM_COL32(220, 225, 235, 230), hint);
        popFont();
    }
}

// ---------------------------------------------------------------- the Rules section of Properties

namespace {
bool inputLine(const char* id, std::string& value, float width) {
    char buf[256];
    std::snprintf(buf, sizeof buf, "%s", value.c_str());
    ImGui::SetNextItemWidth(width);
    if (ImGui::InputText(id, buf, sizeof buf)) { value = buf; return true; }
    return false;
}
} // namespace

void Application::drawRulesPanel(ObjectId id) {
    const SceneObject* o = scene.find(id);
    if (!o) return;
    const float s = scale();
    RuleSet rs;
    if (const RuleSet* cur = rulesOf(id)) rs = *cur;
    bool changed = false, commitNow = false;
    std::string label = "Change " + o->name + "'s rules";
    auto nameOf = [&](RuleObjectId t) -> std::string { const SceneObject* x = scene.find(t); return x ? x->name : std::string("(gone)"); };

    if (rs.rules.empty()) {
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextDisabled("When something happens, make something else happen. No code: pick from the lists.");
        ImGui::PopTextWrapPos();
    }
    int removeRule = -1;
    for (size_t ri = 0; ri < rs.rules.size(); ++ri) {
        Rule& r = rs.rules[ri];
        ImGui::PushID(int(ri));
        ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(255, 255, 255, 10));
        ImGui::BeginChild("##rule", ImVec2(0, 0), ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_Borders);
        pushFont(fonts.small);
        ImGui::PushTextWrapPos(0.0f);
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::accent), "%s", ruleSentence(r, nameOf).c_str());
        ImGui::PopTextWrapPos();
        popFont();
        // when
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted("When");
        ImGui::SameLine();
        ImGui::SetNextItemWidth(ruleWhenTakesNumber(r.when) || ruleWhenTakesText(r.when) ? 150 * s : -30 * s);
        if (ImGui::BeginCombo("##when", ruleWhenLabel(r.when))) {
            for (int w = 0; w < int(RuleWhen::Count); ++w)
                if (ImGui::Selectable(ruleWhenLabel(RuleWhen(w)), r.when == RuleWhen(w))) {
                    r.when = RuleWhen(w);
                    if (r.when == RuleWhen::Every && r.number < 0.5f) r.number = 5.0f;
                    changed = commitNow = true;
                }
            ImGui::EndCombo();
        }
        if (ruleWhenTakesNumber(r.when)) {
            ImGui::SameLine();
            ImGui::SetNextItemWidth(-30 * s);
            if (ImGui::DragFloat("##wn", &r.number, 0.1f, 0.1f, 600.0f, r.when == RuleWhen::Near ? "%.1f m" : "%.1f s")) changed = true;
            if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
        } else if (ruleWhenTakesText(r.when)) {
            ImGui::SameLine();
            if (inputLine("##wt", r.text, -30 * s)) changed = true;
            if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
        }
        ImGui::SameLine();
        if (ImGui::Button("x", ImVec2(-FLT_MIN, 0))) removeRule = int(ri);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Delete this rule");
        // do
        int removeAct = -1;
        for (size_t ai = 0; ai < r.actions.size(); ++ai) {
            RuleAction& a = r.actions[ai];
            ImGui::PushID(int(ai));
            ImGui::AlignTextToFramePadding();
            ImGui::TextDisabled(ai == 0 ? "  do" : "then");
            ImGui::SameLine();
            ImGui::SetNextItemWidth(ruleDoTakesTarget(a.what) ? 130 * s : 150 * s);
            if (ImGui::BeginCombo("##do", ruleDoLabel(a.what))) {
                for (int d = 0; d < int(RuleDo::Count); ++d)
                    if (ImGui::Selectable(ruleDoLabel(RuleDo(d)), a.what == RuleDo(d))) {
                        a.what = RuleDo(d);
                        if (a.what == RuleDo::AddScore && a.number == 0.0f) a.number = 1.0f;
                        if (a.what == RuleDo::Teleport && a.target == kRuleSelf) a.target = 0;
                        changed = commitNow = true;
                    }
                ImGui::EndCombo();
            }
            if (ruleDoTakesTarget(a.what)) {
                ImGui::SameLine();
                ImGui::SetNextItemWidth(-30 * s);
                const std::string cur = a.target == kRuleSelf ? std::string("it (this)") : nameOf(a.target);
                if (ImGui::BeginCombo("##target", cur.c_str())) {
                    if (ImGui::Selectable("it (this)", a.target == kRuleSelf)) { a.target = kRuleSelf; changed = commitNow = true; }
                    for (const SceneObject& x : scene.objects()) {
                        if (x.id == id) continue;
                        ImGui::PushID(int(x.id));
                        if (ImGui::Selectable(x.name.c_str(), a.target == x.id)) { a.target = x.id; changed = commitNow = true; }
                        ImGui::PopID();
                    }
                    ImGui::EndCombo();
                }
            }
            if (ruleDoTakesText(a.what)) {
                if (ruleDoTakesTarget(a.what)) { ImGui::Dummy(ImVec2(40 * s, 0)); }
                ImGui::SameLine();
                if (inputLine("##text", a.text, -30 * s)) changed = true;
                if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
                if (ImGui::IsItemHovered() && a.what == RuleDo::Sound) ImGui::SetTooltip("chime, pickup, door open, door close, teleport, win, lose, boom, zap, whoosh...");
            }
            if (ruleDoTakesNumber(a.what)) {
                ImGui::SameLine();
                ImGui::SetNextItemWidth(-30 * s);
                if (ImGui::DragFloat("##num", &a.number, 0.1f, -1000.0f, 1000.0f, a.what == RuleDo::AddTime ? "%+.0f s" : "%+.0f points")) { a.number = std::round(a.number); changed = true; }
                if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
            }
            ImGui::SameLine();
            if (ImGui::Button("-", ImVec2(-FLT_MIN, 0))) removeAct = int(ai);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Remove this");
            // after a delay
            ImGui::Dummy(ImVec2(40 * s, 0));
            ImGui::SameLine();
            ImGui::SetNextItemWidth(130 * s);
            if (ImGui::DragFloat("##delay", &a.delay, 0.05f, 0.0f, 600.0f, a.delay > 0.0f ? "after %.1f s" : "straight away")) changed = true;
            if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
            ImGui::PopID();
        }
        if (removeAct >= 0) { r.actions.erase(r.actions.begin() + removeAct); changed = commitNow = true; }
        if (ImGui::SmallButton("+ and then...")) { RuleAction a; a.what = RuleDo::Message; a.text = "Something happened!"; r.actions.push_back(a); changed = commitNow = true; }
        ImGui::SameLine();
        if (ImGui::Checkbox("Only the first time", &r.once)) changed = commitNow = true;
        ImGui::EndChild();
        ImGui::PopStyleColor();
        ImGui::PopID();
        ImGui::Dummy(ImVec2(0, 2 * s));
    }
    if (removeRule >= 0) { rs.rules.erase(rs.rules.begin() + removeRule); changed = commitNow = true; label = "Delete a rule from " + o->name; }

    // add a rule, from a few starting points
    if (ImGui::Button("+ Add a rule", ImVec2(-FLT_MIN, 0))) ImGui::OpenPopup("##addrule");
    if (ImGui::BeginPopup("##addrule")) {
        auto starter = [&](const char* text, RuleWhen w, RuleDo d, const char* t = "", float n = 0.0f) {
            if (!ImGui::Selectable(text)) return;
            Rule r; r.when = w; r.number = w == RuleWhen::Every ? 5.0f : 3.0f;
            if (w == RuleWhen::Hears) r.text = "open the gate";
            RuleAction a; a.what = d; a.text = t; a.number = n;
            r.actions.push_back(a);
            rs.rules.push_back(r);
            changed = commitNow = true; label = "Add a rule to " + o->name;
        };
        starter("When you touch it: show a message", RuleWhen::Touch, RuleDo::Message, "Hello!");
        starter("When you press E on it: open or close it", RuleWhen::Use, RuleDo::Toggle);
        starter("When you touch it: collect it (+1 point)", RuleWhen::Touch, RuleDo::Collect, "", 1.0f);
        starter("When you come near: show a message", RuleWhen::Near, RuleDo::Message, "You are getting close...");
        starter("When it hears \"open the gate\": open it", RuleWhen::Hears, RuleDo::Open);
        starter("When you touch it: send \"open the gate\"", RuleWhen::Touch, RuleDo::Send, "open the gate");
        starter("When you press E on it: say something", RuleWhen::Use, RuleDo::Say, "Hi there!");
        starter("When you touch it: you win", RuleWhen::Touch, RuleDo::Win, "You made it!");
        starter("When you touch it: you lose", RuleWhen::Touch, RuleDo::Lose, "Ouch!");
        starter("Every 5 seconds: play a sound", RuleWhen::Every, RuleDo::Sound, "chime");
        ImGui::EndPopup();
    }
    // how it opens
    bool opens = false;
    for (const Rule& r : rs.rules) for (const RuleAction& a : r.actions) opens = opens || ((a.what == RuleDo::Open || a.what == RuleDo::Close || a.what == RuleDo::Toggle) && a.target == kRuleSelf);
    for (const SceneObject& x : scene.objects()) {                // or another object's rules open this one
        if (x.rules.empty() || x.id == id) continue;
        RuleSet other;
        if (!rulesFromText(x.rules, other)) continue;
        for (const Rule& r : other.rules) for (const RuleAction& a : r.actions) opens = opens || ((a.what == RuleDo::Open || a.what == RuleDo::Close || a.what == RuleDo::Toggle) && a.target == id);
    }
    if (opens || rs.startsOpen) {
        ImGui::Dummy(ImVec2(0, 2 * s));
        if (beginProps("##opening", 96.0f)) {
            prop("Opens by", "How it moves when it opens");
            for (int k = 0; k < int(OpenStyle::Count); ++k) {
                if (k) ImGui::SameLine(0, 4 * s);
                const bool on = rs.open == OpenStyle(k);
                if (on) pushSelectedButton();
                if (ImGui::Button(openStyleLabel(OpenStyle(k)))) { rs.open = OpenStyle(k); changed = commitNow = true; }
                if (on) popSelectedButton();
            }
            prop("Takes", "How long opening takes");
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::SliderFloat("##opensec", &rs.openSeconds, 0.1f, 5.0f, "%.1f s")) changed = true;
            if (ImGui::IsItemDeactivatedAfterEdit()) commitNow = true;
            prop("Starts open");
            if (ImGui::Checkbox("##startsopen", &rs.startsOpen)) changed = commitNow = true;
            endProps();
        }
    }
    if (beginProps("##ruleflags", 96.0f)) {
        prop("Starts hidden", "Not there until a rule shows it");
        if (ImGui::Checkbox("##startshidden", &rs.startsHidden)) changed = commitNow = true;
        endProps();
    }
    if (rulesRunning && !rs.rules.empty()) {
        pushFont(fonts.small);
        ImGui::TextDisabled("Playing: %s%s", ruleEngine.isOpen(id) ? "open, " : "", ruleEngine.hidden(id) ? "hidden" : "showing");
        popFont();
    }

    if (changed) {
        RuleSet c = rs;
        c.clamp();
        SceneObject* m = scene.mutate(id);
        m->rules = c.rules.empty() && !c.startsOpen && !c.startsHidden ? std::string() : rulesToText(c);
        ruleCache.erase(id);
        if (commitNow) commitScene(label);
    }
}

} // namespace px
