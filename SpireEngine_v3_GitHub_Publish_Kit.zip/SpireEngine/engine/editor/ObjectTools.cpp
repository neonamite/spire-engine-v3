// Objects in the editor: selecting, placing, moving with the gizmo, deleting and so on, and the
// one undo history that mixes terrain edits and object changes in the order they happened.
#include "core/Application.h"
#include <filesystem>
#include "rules/Gadgets.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <unordered_set>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/constants.hpp>
#include <imgui.h>

namespace px {

using namespace ui;

namespace {
std::string niceName(std::string s) {
    std::replace(s.begin(), s.end(), '_', ' ');
    if (!s.empty()) s[0] = char(std::toupper(static_cast<unsigned char>(s[0])));
    return s;
}
} // namespace

// ------------------------------------------------------------------ selection

void Application::selectObject(ObjectId id, bool additive) {
    if (id == 0 || !scene.find(id)) { if (!additive) selection.clear(); return; }
    auto it = std::find(selection.begin(), selection.end(), id);
    if (additive) {
        if (it != selection.end()) selection.erase(it); else selection.push_back(id);
    } else {
        selection.assign(1, id);
    }
}

void Application::setSelection(std::vector<ObjectId> ids) {
    selection.clear();
    for (ObjectId id : ids)
        if (scene.find(id) && !isSelected(id)) selection.push_back(id);
}

std::vector<ObjectId> Application::selectionRoots() const {
    std::vector<ObjectId> out;
    for (ObjectId id : selection) {
        bool inside = false;
        for (ObjectId other : selection) if (other != id && scene.isAncestor(other, id)) { inside = true; break; }
        if (!inside && scene.find(id)) out.push_back(id);
    }
    return out;
}

// ------------------------------------------------------------------ one history for everything

void Application::noteTerrainEdit() {
    undoLog.push_back('T');
    redoLog.clear();
    scene.clearRedo();
    if (undoLog.size() > 30000) undoLog.erase(undoLog.begin(), undoLog.begin() + 10000);
}

bool Application::commitScene(const std::string& label) {
    if (!scene.commit(label)) return false;
    undoLog.push_back('S');
    redoLog.clear();
    world.clearRedo();
    if (undoLog.size() > 30000) undoLog.erase(undoLog.begin(), undoLog.begin() + 10000);
    return true;
}

void Application::cmdUndo() {
    if (gizmo.dragging()) return;
    const char kind = undoLog.empty() ? 'T' : undoLog.back();
    std::string what;
    bool ok;
    if (kind == 'S') { what = scene.undoLabel(); ok = scene.undo(); }
    else ok = world.undo();
    if (!undoLog.empty()) undoLog.pop_back();
    if (!ok) { toast("Nothing to undo"); return; }
    redoLog.push_back(kind);
    selection.erase(std::remove_if(selection.begin(), selection.end(), [&](ObjectId id) { return !scene.find(id); }), selection.end());
    toast(kind == 'S' && !what.empty() ? "Undo: " + what : "Undo");
}

void Application::cmdRedo() {
    if (gizmo.dragging()) return;
    if (redoLog.empty()) { toast("Nothing to redo"); return; }
    const char kind = redoLog.back();
    redoLog.pop_back();
    const bool ok = kind == 'S' ? scene.redo() : world.redo();
    if (!ok) { toast("Nothing to redo"); return; }
    undoLog.push_back(kind);
    selection.erase(std::remove_if(selection.begin(), selection.end(), [&](ObjectId id) { return !scene.find(id); }), selection.end());
    toast(kind == 'S' && !scene.undoLabel().empty() ? "Redo: " + scene.undoLabel() : "Redo");
}

void Application::syncSceneFromWorld() {
    if (!scene.fromText(world.extraBlob())) scene.clear();
    sceneRevSynced = scene.revision();
    selection.clear();
    undoLog.clear(); redoLog.clear();
    placingAsset.clear();
    kitGroup = 0; kitBaseSet = false; kitDragging = false;
    bp.placing = false; bp.target = 0;
    gizmo.end();
    hoverObject = 0;
}

void Application::clearSceneState() {
    scene.clear();
    world.setExtraBlob("");
    sceneRevSynced = scene.revision();
    selection.clear();
    undoLog.clear(); redoLog.clear();
    placingAsset.clear();
    kitGroup = 0; kitBaseSet = false; kitDragging = false;
    gizmo.end();
    hoverObject = 0;
}

// ------------------------------------------------------------------ per frame

GizmoView Application::gizmoView() const {
    GizmoView v;
    v.camera = &camera;
    v.x = viewRect.x; v.y = viewRect.y; v.w = std::max(1.0f, viewRect.w); v.h = std::max(1.0f, viewRect.h);
    v.uiScale = scale();
    v.update();
    return v;
}

bool Application::findPlacementSpot(glm::vec3& pos, glm::vec3& normal, ObjectId* hitObject) const {
    const glm::vec3 d = cursorRay();
    RayHit th;
    const bool terrain = world.raycast(camera.position, d, 400.0f, th);
    Scene::Hit oh;
    const bool object = scene.raycast(camera.position, d, terrain ? th.distance : 400.0f, oh, true);
    if (hitObject) *hitObject = object ? oh.id : 0;
    if (object) { pos = oh.point; normal = oh.normal; return true; }
    if (terrain) { pos = th.position; normal = th.normal; return true; }
    return false;
}

void Application::updateObjects(float dt) {
    const ImGuiIO& io = ImGui::GetIO();
    if (mode == Mode::Hub) { renderer.setObjects({}); return; }

    if (mode == Mode::Play) { if (!paused) sceneClock += double(dt); }
    else if (previewMotion) sceneClock += double(dt);
    if (mode == Mode::Play) { if (!paused) { updateNpcs(dt); updateRules(dt); } }
    else if (scene.hasLive() || !npcLive.empty()) stopNpcs();
    scene.evaluate(assets, sceneClock, mode == Mode::Play || previewMotion);
    updateGrassClearings();

    // The world file carries the scene; keep its copy current (not on every frame of a drag).
    if (!gizmo.dragging() && scene.revision() != sceneRevSynced) {
        world.setExtraBlob(scene.empty() && scene.gameRules().empty() ? std::string() : scene.toText());
        sceneRevSynced = scene.revision();
    }
    selection.erase(std::remove_if(selection.begin(), selection.end(), [&](ObjectId id) { return !scene.find(id); }), selection.end());

    const bool editing = mode == Mode::Editor;
    const std::vector<ObjectId> roots = selectionRoots();

    // The gizmo sits on the selection (and stays put while it is being dragged).
    if (editing && !roots.empty() && !gizmo.dragging()) {
        glm::vec3 c(0.0f);
        int n = 0;
        for (ObjectId id : roots) if (const Evaluated* e = scene.evaluatedFor(id)) { c += glm::vec3(e->world[3]); ++n; }
        if (n) gizmo.pivot = c / float(n);
        gizmo.axes = glm::mat3(1.0f);
        if (gizmoSpace == GizmoSpace::Local) {
            if (const Evaluated* e = scene.evaluatedFor(primaryObject())) {
                const glm::vec3 x = glm::normalize(glm::vec3(e->world[0])), y0 = glm::vec3(e->world[1]);
                const glm::vec3 z = glm::normalize(glm::cross(x, y0)), y = glm::cross(z, x);
                gizmo.axes = glm::mat3(x, y, z);
            }
        }
    }

    gizmoHover = Gizmo::kNone;
    hoverObject = 0;
    ghostValid = false;
    const bool mouseFree = editing && !looking && !io.WantCaptureMouse && !uiHidden;
    if (mouseFree && !gizmo.dragging()) {
        const GizmoView v = gizmoView();
        if (tool == Tool::Select && !roots.empty() && !previewMotion && placingAsset.empty())
            gizmoHover = gizmo.pick(v, gizmoMode, glm::vec2(mouseX, mouseY));
        if (tool == Tool::Select && placingAsset.empty() && gizmoHover == Gizmo::kNone) {
            Scene::Hit h;
            RayHit th;
            const glm::vec3 d = cursorRay();
            const bool terrain = world.raycast(camera.position, d, 400.0f, th);
            if (scene.raycast(camera.position, d, terrain ? th.distance : 400.0f, h)) hoverObject = h.id;
        }
    }
    if (editing && !placingAsset.empty() && !io.WantCaptureMouse && !uiHidden) {
        if (placingKit()) {
            // A building-kit piece: it snaps to the grid, and shows whether it is new, replaces another piece, or is already there.
            const KitRole role = placingKitRole();
            KitSpot spot;
            float plane = 0.0f;
            ghostValid = kitSpotUnderCursor(role, spot, &plane, nullptr, kitDragging && !kitErasing ? &kitDragPlane : nullptr);
            if (ghostValid) {
                ghostPos = spot.position; ghostYaw = spot.yaw; ghostPlane = plane; ghostNormal = glm::vec3(0, 1, 0);
                ghostLevel = kitBaseSet ? int(std::lround((plane - kitBaseY) / kKitStorey)) : kitLevel;
                ghostKitState = 0;
                const std::vector<ObjectId> clash = kitClash(role, spot);
                if (clash.size() == 1) {
                    const SceneObject* c = scene.find(clash[0]);
                    ghostKitState = (c && c->asset == placingAsset && glm::length(glm::vec3(scene.restWorld(c->id)[3]) - spot.position) < 0.02f) ? 2 : 1;
                } else if (!clash.empty()) ghostKitState = 1;
            }
        } else {
            ghostValid = findPlacementSpot(ghostPos, ghostNormal);
            ghostYaw = placeYaw;
        }
    }
    if (editing && kitDragging) kitDragStep(simulateLeftButton || (SDL_GetMouseState(nullptr, nullptr) & SDL_BUTTON_LMASK) != 0);

    updateGizmoDrag();

    // What to draw.
    std::unordered_set<ObjectId> glow;
    if (editing) for (ObjectId id : selection) { glow.insert(id); for (ObjectId d : scene.descendants(id)) glow.insert(d); }
    std::vector<ObjectDraw> draws;
    draws.reserve(scene.evaluated().size() + 1);
    for (const Evaluated& e : scene.evaluated()) {
        if (!e.asset || !e.visible) continue;
        if (!scene.objects()[size_t(e.index)].character.empty()) continue;      // a person: drawn posed, below, not as its stand-in
        ObjectDraw d;
        d.asset = e.asset; d.model = e.world; d.scale = e.scale;
        if (editing) {
            if (glow.count(e.id)) d.highlight = glm::vec4(1.0f, 0.60f, 0.14f, 0.85f);
            else if (e.id == hoverObject) d.highlight = glm::vec4(0.55f, 0.75f, 1.0f, 0.55f);
        }
        draws.push_back(std::move(d));
    }
    if (editing && ghostValid && placingCharacter.empty()) {
        if (AssetPtr a = assets.get(placingAsset)) {
            ObjectDraw d;
            const bool kit = placingKit();
            d.asset = a; d.scale = kit ? 1.0f : placeScale;
            d.model = composeTransform(ghostPos, glm::vec3(0.0f, ghostYaw, 0.0f), d.scale);
            d.highlight = kit && ghostKitState == 1 ? glm::vec4(1.0f, 0.70f, 0.20f, 0.9f)         // replaces something: amber
                        : kit && ghostKitState == 2 ? glm::vec4(0.45f, 0.60f, 0.70f, 0.55f)       // already there: faint
                        : glm::vec4(0.25f, 0.85f, 1.0f, 0.9f);
            draws.push_back(std::move(d));
        }
    }
    if (editing && bp.placing) bpGhostDraws(draws);
    treeDraws(draws);
    characterWorldDraws(draws, dt);
    renderer.setObjects(std::move(draws));
}

// ------------------------------------------------------------------ mouse

bool Application::selectToolMouseDown(bool additive) {
    if (mode != Mode::Editor) return false;

    if (npcPicking && npcPickClick()) return true;
    if (!placingAsset.empty()) {
        if (placingKit()) {
            // Building: a click places a piece on the grid; holding it down and dragging builds a run; Shift removes. One undo step per stroke.
            kitErasing = (SDL_GetModState() & SDL_KMOD_SHIFT) != 0;
            kitDragging = true; kitStrokeCount = 0; kitLastKey.clear();
            if (kitErasing) {
                if (kitRemoveUnderCursor()) ++kitStrokeCount;
            } else {
                KitSpot spot;
                float plane = 0.0f;
                ObjectId onPiece = 0;
                const KitRole role = placingKitRole();
                if (!kitSpotUnderCursor(role, spot, &plane, &onPiece)) { kitDragging = false; toast("Point at the ground to build", Toast::Kind::Warning); return true; }
                if (!kitBaseSet && !onPiece) { kitBaseY = plane - float(kitLevel) * kKitStorey; kitBaseSet = true; }       // the first piece fixes where the ground floor is
                if (onPiece) if (const SceneObject* po = scene.find(onPiece); po && po->parent && scene.find(po->parent) && scene.find(po->parent)->isGroup()) kitGroup = po->parent;   // carry on with that building
                kitDragPlane = plane;
                char key[96];
                std::snprintf(key, sizeof key, "%d %.2f %.2f %.2f %.0f", int(role), double(spot.position.x), double(spot.position.y), double(spot.position.z), double(spot.yaw));
                kitLastKey = key;
                if (kitPlaceAt(placingAsset, role, spot)) ++kitStrokeCount;
            }
            return true;
        }
        glm::vec3 pos, n;
        if (!findPlacementSpot(pos, n)) { toast("Point at the ground to place it", Toast::Kind::Warning); return true; }
        if (!placingCharacter.empty()) placeCharacter(placingCharacter, pos, placeYaw);
        else placeObject(placingAsset, pos, placeYaw, placeScale);
        return true;
    }
    if (tool != Tool::Select) return false;

    // A gizmo handle wins over whatever is behind it.
    if (!selection.empty() && !previewMotion && gizmoHover != Gizmo::kNone) {
        gdrag.start.clear();
        for (ObjectId id : selectionRoots())
            if (const SceneObject* o = scene.find(id); o && !o->locked) gdrag.start.emplace_back(id, scene.restWorld(id));
        if (gdrag.start.empty()) { toast("Locked objects can't be moved. Unlock them in the Outliner.", Toast::Kind::Warning); return true; }
        gdrag.pivot = gizmo.pivot;
        const char* verb = gizmoMode == GizmoMode::Move ? "Move " : gizmoMode == GizmoMode::Rotate ? "Rotate " : "Resize ";
        gdrag.label = verb + (gdrag.start.size() == 1 ? scene.find(gdrag.start[0].first)->name : std::to_string(gdrag.start.size()) + " objects");
        if (!gizmo.begin(gizmoView(), gizmoMode, glm::vec2(mouseX, mouseY), gizmoHover)) gdrag.start.clear();
        return true;
    }

    const glm::vec3 d = cursorRay();
    RayHit th;
    const bool terrain = world.raycast(camera.position, d, 400.0f, th);
    Scene::Hit h;
    if (scene.raycast(camera.position, d, terrain ? th.distance : 400.0f, h)) selectObject(h.id, additive);
    else if (!additive) selectObject(0);
    return true;
}

void Application::updateGizmoDrag() {
    if (!gizmo.dragging()) return;
    if (gdrag.start.empty() || mode != Mode::Editor) { gizmo.end(); return; }
    const Gizmo::Delta d = gizmo.drag(gizmoView(), gizmoMode, glm::vec2(mouseX, mouseY), gizmoSnap);
    if (d.translate == glm::vec3(0.0f) && d.angle == 0.0f && d.scale == 1.0f) { scene.discardUncommitted(); return; }   // back where it began
    const glm::vec3 p = gdrag.pivot;
    glm::mat4 change(1.0f);
    switch (gizmoMode) {
    case GizmoMode::Move:   change = glm::translate(glm::mat4(1.0f), d.translate); break;
    case GizmoMode::Rotate: change = glm::translate(glm::mat4(1.0f), p) * glm::rotate(glm::mat4(1.0f), d.angle, d.axis) * glm::translate(glm::mat4(1.0f), -p); break;
    case GizmoMode::Scale:  change = glm::translate(glm::mat4(1.0f), p) * glm::scale(glm::mat4(1.0f), glm::vec3(d.scale)) * glm::translate(glm::mat4(1.0f), -p); break;
    }
    for (const auto& [id, w0] : gdrag.start) scene.setRestWorld(id, change * w0);
}

void Application::objectsMouseUp() {
    if (kitDragging) { kitStrokeEnd(); return; }
    if (!gizmo.dragging()) return;
    gizmo.end();
    commitScene(gdrag.label);
    gdrag.start.clear();
}

// ------------------------------------------------------------------ commands

ObjectId Application::placeObject(const std::string& asset, const glm::vec3& at, float yawDegrees, float scaleFactor) {
    if (!assets.get(asset)) { toast("Unknown asset: " + asset, Toast::Kind::Warning); return 0; }
    SceneObject o;
    o.asset = asset;
    o.name = niceName(asset);
    o.position = at;
    o.rotation = glm::vec3(0.0f, yawDegrees, 0.0f);
    o.scale = scaleFactor;
    if (const GadgetPreset* g = gadgetFor(asset)) {             // a gadget comes with its rules
        o.name = g->label;
        o.rules = rulesToText(g->rules);
        o.motion = g->motion;
    }
    const ObjectId id = scene.add(o);
    commitScene("Place " + scene.find(id)->name);
    selectObject(id);
    playSfxAt("stamp", at, 0.9f);
    return id;
}

void Application::startPlacing(const std::string& asset) {
    if (!assets.get(asset)) { toast("Unknown asset: " + asset, Toast::Kind::Warning); return; }
    placingAsset = asset;
    placingCharacter.clear();
    recentAssets.erase(std::remove(recentAssets.begin(), recentAssets.end(), asset), recentAssets.end());   // the shelf's Recent row
    recentAssets.insert(recentAssets.begin(), asset);
    if (recentAssets.size() > 24) recentAssets.resize(24);
    bp.placing = false;
    placeYaw = 0.0f; placeScale = 1.0f;
    kitTurns = 0;
    tool = Tool::Select;
    if (placingKit()) toast("Click to build with " + niceName(asset) + ". Drag for a run, R turns it, wheel changes storey, Shift removes.");
    else toast("Click in the world to place " + niceName(asset) + ".  Esc to stop.");
}

void Application::stopPlacing() { kitStrokeEnd(); placingAsset.clear(); placingCharacter.clear(); }

void Application::cmdDeleteSelection() {
    const std::vector<ObjectId> roots = selectionRoots();
    if (roots.empty()) return;
    int removed = 0, kept = 0;
    std::string first;
    for (ObjectId id : roots) {
        const SceneObject* o = scene.find(id);
        if (!o) continue;
        if (o->locked) { ++kept; continue; }
        if (first.empty()) first = o->name;
        scene.remove(id);
        ++removed;
    }
    selection.clear();
    if (removed) commitScene(removed == 1 ? "Delete " + first : "Delete " + std::to_string(removed) + " objects");
    if (kept) toast(std::to_string(kept) + (kept == 1 ? " locked object was kept" : " locked objects were kept"), Toast::Kind::Warning);
    else if (removed) toast(removed == 1 ? "Deleted " + first : "Deleted " + std::to_string(removed) + " objects");
}

void Application::cmdDuplicateSelection() {
    const std::vector<ObjectId> roots = selectionRoots();
    if (roots.empty()) return;
    std::vector<ObjectId> made;
    for (ObjectId id : roots) if (ObjectId c = scene.duplicate(id)) made.push_back(c);
    if (made.empty()) return;
    setSelection(made);
    commitScene(made.size() == 1 ? "Duplicate " + scene.find(made[0])->name : "Duplicate " + std::to_string(made.size()) + " objects");
}

void Application::cmdGroupSelection() {
    const std::vector<ObjectId> roots = selectionRoots();
    if (roots.empty()) return;
    const ObjectId g = scene.group(roots, "Group");
    if (!g) return;
    selectObject(g);
    commitScene("Group " + std::to_string(roots.size()) + (roots.size() == 1 ? " object" : " objects"));
}

void Application::cmdUngroupSelection() {
    std::vector<ObjectId> freed;
    for (ObjectId id : selectionRoots()) {
        const SceneObject* o = scene.find(id);
        if (!o || !o->isGroup()) continue;
        const std::vector<ObjectId> kids = scene.children(id);
        if (scene.ungroup(id)) freed.insert(freed.end(), kids.begin(), kids.end());
    }
    if (freed.empty()) { toast("Select a group to ungroup it"); return; }
    setSelection(freed);
    commitScene("Ungroup");
}

void Application::cmdFocusSelection() {
    glm::vec3 mn(1e9f), mx(-1e9f);
    bool any = false;
    for (ObjectId id : selectionRoots()) {
        glm::vec3 a, b;
        if (scene.worldBounds(id, a, b)) { mn = glm::min(mn, a); mx = glm::max(mx, b); any = true; }
    }
    if (!any) { toast("Select something first"); return; }
    const glm::vec3 centre = (mn + mx) * 0.5f;
    const float radius = std::max(1.5f, glm::length(mx - mn) * 0.5f);
    const float dist = radius / std::tan(glm::radians(camera.fovDegrees) * 0.5f) * 1.15f + 1.0f;
    flyTo.start(camera, centre - camera.front() * dist, camera.yaw, camera.pitch);
}

void Application::cmdDropToGround() {
    int moved = 0;
    for (ObjectId id : selectionRoots()) {
        const SceneObject* o = scene.find(id);
        if (!o || o->locked) continue;
        glm::mat4 w = scene.restWorld(id);
        RayHit hit;
        if (!world.raycast(glm::vec3(w[3]) + glm::vec3(0, 40.0f, 0), glm::vec3(0, -1, 0), 400.0f, hit)) continue;
        w[3] = glm::vec4(glm::vec3(w[3].x, hit.position.y, w[3].z), 1.0f);
        scene.setRestWorld(id, w);
        ++moved;
    }
    if (moved) commitScene("Drop to ground");
    else toast("Nothing to drop here", Toast::Kind::Warning);
}

void Application::cmdSelectAll() {
    std::vector<ObjectId> all;
    for (const auto& o : scene.objects()) if (!o.locked) all.push_back(o.id);
    setSelection(all);
}

// ------------------------------------------------------------------ viewport overlay

void Application::drawObjectOverlay() {
    if (mode != Mode::Editor || uiHidden) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const float s = scale();
    const GizmoView v = gizmoView();
    auto line = [&](const glm::vec3& a, const glm::vec3& b, ImU32 col, float thick) {
        glm::vec2 pa, pb;
        if (v.project(a, pa) && v.project(b, pb)) dl->AddLine(ImVec2(pa.x, pa.y), ImVec2(pb.x, pb.y), col, thick);
    };

    // Outline boxes: orange for the selection, a faint one for what the mouse is over.
    auto box = [&](ObjectId id, ImU32 col, float thick) {
        glm::vec3 mn, mx;
        if (!scene.worldBounds(id, mn, mx)) return;
        glm::vec3 c[8];
        for (int i = 0; i < 8; ++i) c[i] = glm::vec3(i & 1 ? mx.x : mn.x, i & 2 ? mx.y : mn.y, i & 4 ? mx.z : mn.z);
        static const int e[12][2] = { {0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7} };
        for (auto& ed : e) line(c[ed[0]], c[ed[1]], col, thick);
    };
    if (tool == Tool::Select) {
        for (ObjectId id : selectionRoots()) box(id, IM_COL32(61, 224, 255, 200), 1.4f * s);
        if (hoverObject && !isSelected(hoverObject)) box(hoverObject, IM_COL32(220, 226, 240, 90), 1.0f * s);

        if (const SceneObject* p = gizmo.dragging() ? scene.find(primaryObject()) : nullptr) {   // while dragging: its name (the action bar shows it otherwise)
            glm::vec3 mn, mx;
            glm::vec2 sp;
            if (scene.worldBounds(p->id, mn, mx) && v.project(glm::vec3((mn.x + mx.x) * 0.5f, mx.y + 0.4f, (mn.z + mx.z) * 0.5f), sp)) {
                pushFont(fonts.small);
                std::string label = p->name;
                if (selectionRoots().size() > 1) label += "  +" + std::to_string(selectionRoots().size() - 1);
                const ImVec2 ts = ImGui::CalcTextSize(label.c_str());
                const ImVec2 a(sp.x - ts.x * 0.5f - 6 * s, sp.y - ts.y - 10 * s);
                dl->AddRectFilled(a, ImVec2(a.x + ts.x + 12 * s, a.y + ts.y + 6 * s), IM_COL32(11, 12, 16, 210), 5 * s);
                dl->AddText(ImVec2(a.x + 6 * s, a.y + 3 * s), col::text, label.c_str());
                popFont();
            }
        }
        if (!selection.empty() && !previewMotion && placingAsset.empty()) gizmo.draw(dl, v, gizmoMode, gizmoHover);
    }

    if (bp.placing) {
        drawBlueprintOverlay(dl, v, s);
    } else if (!placingAsset.empty() && placingKit()) {
        drawKitGuides(dl, v, s);
        pushFont(fonts.small);
        char text[260];
        std::snprintf(text, sizeof text, "%s  -  %s     click: build   drag: a run   R: turn   wheel or [ ]: storey   Shift+click: remove   Esc: stop",
                      niceName(placingAsset).c_str(), kitLevelLabel(ghostLevel).c_str());
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const ImVec2 a(viewRect.x + (viewRect.w - ts.x) * 0.5f - 10 * s, viewRect.y + viewRect.h - ts.y - 40 * s);
        dl->AddRectFilled(a, ImVec2(a.x + ts.x + 20 * s, a.y + ts.y + 12 * s), IM_COL32(11, 12, 16, 225), 8 * s);
        dl->AddText(ImVec2(a.x + 10 * s, a.y + 6 * s), col::text, text);
        popFont();
    } else if (!placingAsset.empty()) {
        if (ghostValid) {
            // A ring on the ground where it will land, sized to the model.
            const AssetPtr a = assets.get(placingAsset);
            const float r = a ? std::max(0.8f, std::max(a->extent().x, a->extent().z) * 0.5f * placeScale) : 1.0f;
            glm::vec3 u = std::fabs(ghostNormal.y) < 0.95f ? glm::normalize(glm::cross(ghostNormal, glm::vec3(0, 1, 0))) : glm::vec3(1, 0, 0);
            const glm::vec3 w = glm::cross(ghostNormal, u);
            glm::vec2 prev(0.0f); bool have = false;
            for (int i = 0; i <= 40; ++i) {
                const float t = float(i) / 40.0f * glm::two_pi<float>();
                glm::vec2 sp;
                const bool ok = v.project(ghostPos + (u * std::cos(t) + w * std::sin(t)) * r + ghostNormal * 0.05f, sp);
                if (ok && have) dl->AddLine(ImVec2(prev.x, prev.y), ImVec2(sp.x, sp.y), IM_COL32(90, 220, 255, 220), 2.0f * s);
                prev = sp; have = ok;
            }
        }
        pushFont(fonts.small);
        char text[200];
        std::snprintf(text, sizeof text, "Click to place %s     wheel: turn     Shift+wheel: resize     Esc: stop", niceName(placingAsset).c_str());
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const ImVec2 a(viewRect.x + (viewRect.w - ts.x) * 0.5f - 10 * s, viewRect.y + viewRect.h - ts.y - 40 * s);
        dl->AddRectFilled(a, ImVec2(a.x + ts.x + 20 * s, a.y + ts.y + 12 * s), IM_COL32(11, 12, 16, 225), 8 * s);
        dl->AddText(ImVec2(a.x + 10 * s, a.y + 6 * s), col::text, text);
        popFont();
    }
}


// ------------------------------------------------------------------ self test (--demo objselftest)

// Runs the editor's own functions the way the mouse and keyboard do, without a window, and prints
// "[objtest] ok / FAIL" lines. This is what proves the pieces work together, not just alone.
void Application::runObjectSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[objtest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto near3 = [](const glm::vec3& a, const glm::vec3& b, float e = 1e-3f) { return glm::length(a - b) <= e; };

    setMode(Mode::Editor);
    tool = Tool::Select;
    gizmoMode = GizmoMode::Move;
    gizmoSpace = GizmoSpace::World;
    gizmoSnap.on = false;
    placingAsset.clear();
    previewMotion = false;
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();

    RayHit th;
    const float dist = world.raycast(camera.position, camera.front(), 300.0f, th) ? th.distance * 0.5f : 15.0f;
    const glm::vec3 at = camera.position + camera.front() * dist;

    const ObjectId id = placeObject("lamp_post", at, 0.0f, 1.0f);
    check(id != 0 && selection.size() == 1 && selection[0] == id, "placing an object selects it");
    check(scene.undoLabel().rfind("Place", 0) == 0 && undoLog.size() == 1 && undoLog.back() == 'S', "placing is one undo step");
    updateObjects(0.0f);
    check(near3(gizmo.pivot, at, 0.05f), "the handles sit on the selected object");

    auto handleAt = [&](int want, glm::vec2& out) {
        const GizmoView v = gizmoView();
        glm::vec2 c;
        if (!v.project(gizmo.pivot, c)) return false;
        for (int r = 6; r < 300; r += 3)
            for (int a = 0; a < 360; a += 5) {
                const glm::vec2 p = c + glm::vec2(std::cos(glm::radians(float(a))), std::sin(glm::radians(float(a)))) * float(r);
                if (gizmo.pick(v, gizmoMode, p) == want) { out = p; return true; }
            }
        return false;
    };
    auto grab = [&](int want) {
        glm::vec2 p;
        if (!handleAt(want, p)) return false;
        mouseX = p.x; mouseY = p.y;
        gizmoHover = want;
        selectToolMouseDown(false);
        return gizmo.dragging();
    };
    auto dragBy = [&](float dx, float dy) { mouseX += dx; mouseY += dy; updateGizmoDrag(); };

    // ---- move along X
    check(grab(0), "the X arrow can be grabbed");
    dragBy(60.0f, 0.0f);
    {
        const glm::vec3 p = scene.find(id)->position;
        check(std::fabs(p.x - at.x) > 0.3f && std::fabs(p.y - at.y) < 1e-3f && std::fabs(p.z - at.z) < 1e-3f, "dragging the X arrow moves along X only");
    }
    check(scene.dirtySinceCommit(), "a drag in progress is not a finished step");
    objectsMouseUp();
    const glm::vec3 moved = scene.find(id)->position;
    check(!gizmo.dragging() && scene.undoLabel().rfind("Move", 0) == 0 && undoLog.size() == 2, "letting go records one 'Move' step");

    cmdUndo();
    check(near3(scene.find(id)->position, at), "undo puts it back");
    cmdRedo();
    check(near3(scene.find(id)->position, moved), "redo moves it again");

    // ---- Esc cancels a drag
    updateObjects(0.0f);
    check(grab(1), "the Y arrow can be grabbed");
    dragBy(0.0f, -50.0f);
    check(std::fabs(scene.find(id)->position.y - moved.y) > 0.2f, "dragging the Y arrow lifts it");
    scene.discardUncommitted(); gizmo.end(); gdrag.start.clear();      // what Esc does
    check(near3(scene.find(id)->position, moved) && undoLog.size() == 2, "Esc cancels the drag and records nothing");

    // ---- turn
    gizmoMode = GizmoMode::Rotate;
    updateObjects(0.0f);
    check(grab(1), "the turn ring (around Y) can be grabbed");
    dragBy(70.0f, 20.0f);
    const bool turned = glm::length(scene.find(id)->rotation) > 1.0f;
    objectsMouseUp();
    check(turned, "dragging the ring turns the object");
    check(near3(scene.find(id)->position, moved, 0.01f), "turning keeps it in place");

    // ---- resize
    gizmoMode = GizmoMode::Scale;
    updateObjects(0.0f);
    check(grab(Gizmo::kCentre), "the size handle can be grabbed");
    dragBy(60.0f, 0.0f);
    const float sc = scene.find(id)->scale;
    objectsMouseUp();
    check(sc > 1.05f || sc < 0.95f, "dragging the size handle changes the size");
    cmdUndo(); cmdUndo(); cmdUndo();
    check(near3(scene.find(id)->position, at) && scene.find(id)->scale == 1.0f && glm::length(scene.find(id)->rotation) < 1e-3f, "three undos return to where it was placed");
    check(canRedo(), "and redo is available");
    cmdRedo(); cmdRedo(); cmdRedo();
    check(scene.find(id)->scale == sc, "three redos bring it all back");

    // ---- pick with a click
    gizmoMode = GizmoMode::Move;
    selectObject(0);
    updateObjects(0.0f);
    if (const Evaluated* e = scene.evaluatedFor(id)) {
        const GizmoView v = gizmoView();
        glm::vec2 s;
        check(v.project(e->centre, s), "the object is in view");
        mouseX = s.x; mouseY = s.y; gizmoHover = Gizmo::kNone;
        selectToolMouseDown(false);
        check(isSelected(id), "clicking an object selects it");
        mouseX = v.x + 3.0f; mouseY = v.y + 3.0f;                      // the sky in the corner
        selectToolMouseDown(false);
        check(selection.empty(), "clicking empty space deselects");
        selectObject(id);
    }

    // ---- copies, groups, delete
    cmdDuplicateSelection();
    check(scene.size() == 2 && selection.size() == 1 && selection[0] != id, "duplicate adds a copy and selects it");
    setSelection({ id, selection[0] });
    cmdGroupSelection();
    check(scene.size() == 3 && !selection.empty() && scene.find(selection[0])->isGroup(), "group wraps the selection");
    cmdUngroupSelection();
    check(scene.size() == 2, "ungroup removes the group again");
    setSelection({ id });
    cmdDeleteSelection();
    check(!scene.find(id) && scene.size() == 1, "delete removes the object");
    cmdUndo();
    check(scene.find(id) && scene.size() == 2, "undo brings it back");

    // ---- terrain and objects share one history, in the order things happened
    const size_t before = undoLog.size();
    const glm::vec3 dig = world.raycast(camera.position, camera.front(), 300.0f, th) ? th.position : at;
    const glm::vec3 probe = dig - glm::vec3(0.0f, 2.0f, 0.0f);
    const float solid0 = world.density(probe);
    world.applySphere(dig, 3.5f, CsgMode::Subtract);
    check(undoLog.size() == before + 1 && undoLog.back() == 'T', "a terrain edit joins the same history");
    check(world.density(probe) > 0.0f && solid0 < 0.0f, "the digging really changed the ground");
    const ObjectId second = placeObject("crate", at + glm::vec3(3, 0, 0), 0.0f, 1.0f);
    cmdUndo();
    check(!scene.find(second) && world.density(probe) > 0.0f, "undo takes back the newest thing first (the object, not the digging)");
    cmdUndo();
    check(scene.find(id) && world.density(probe) < 0.0f, "then the digging, leaving the older object alone");
    cmdRedo(); cmdRedo();
    check(scene.find(second) && world.density(probe) > 0.0f, "redo replays both in order");

    // ---- the player stands on objects (the crate is in mid-air, so only the object can hold the player up)
    check(player.extraSolids == &worldSolids && worldSolids.app == this, "the player is told about the scene (and the trees)");
    {
        updateObjects(0.0f);
        const glm::vec3 crate = scene.find(second)->position;
        player.position = crate + glm::vec3(0.0f, 12.0f, 0.0f);
        player.velocity = glm::vec3(0.0f);
        for (int i = 0; i < 240; ++i) player.update(world, glm::vec3(0.0f), false, false, 1.0f / 60.0f);
        check(player.grounded && player.position.y > crate.y + 3.5f && player.position.y < crate.y + 5.5f, "the player lands on top of the crate");
    }

    // ---- save and load the world file with its objects (the real world file is put back afterwards, so the next run
    // starts from the same world)
    {
        std::error_code fec;
        const std::string worldFile = worldSavePath(), keep = worldFile + ".objtest";
        const bool hadWorld = std::filesystem::exists(worldFile, fec);
        if (hadWorld) std::filesystem::copy_file(worldFile, keep, std::filesystem::copy_options::overwrite_existing, fec);
        struct Restore {
            std::string file, keep; bool had;
            ~Restore() { std::error_code e; if (had) { std::filesystem::copy_file(keep, file, std::filesystem::copy_options::overwrite_existing, e); std::filesystem::remove(keep, e); } else std::filesystem::remove(file, e); }
        } restore{ worldFile, keep, hadWorld };
        const size_t count = scene.size();
        cmdSave();
        scene.clear();
        check(scene.empty(), "(cleared the scene)");
        cmdLoad();
        check(scene.size() == count && selection.empty(), "loading the world brings the objects back");
        check(!canUndo() || !undoLog.empty() || world.canUndo(), "(history state is consistent after loading)");
        updateObjects(0.0f);
        check(scene.evaluated().size() == count, "and they are placed in the scene again");
    }

    std::cerr << "[objtest] " << (fails ? "FAILED" : "ALL OK") << " (" << fails << " failures)\n";
}

} // namespace px
