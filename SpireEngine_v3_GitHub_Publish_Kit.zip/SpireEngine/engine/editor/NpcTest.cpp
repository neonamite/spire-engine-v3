// --demo npc_...: screenshots of people living their lives (v0.20), and a self test that drives the real code (giving
// someone a life in Properties, clicking out a patrol path, playing, meeting them) and prints "[npctest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "character/BodyParts.h"
#include <cmath>
#include <iostream>
#include <string>

namespace px {

namespace {
template <class Cam>
void aimAt(Cam& cam, const glm::vec3& from, const glm::vec3& at) {
    const glm::vec3 d = at - from;
    cam.position = from;
    cam.yaw = glm::degrees(std::atan2(d.z, d.x));
    cam.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
}
glm::vec3 onGround(const ChunkManager& world, float x, float z) { return glm::vec3(x, demospot::groundHeight(world, x, z), z); }
} // namespace

// A little village square: people wandering, a guard at the gate, a smith at work, someone on patrol, two to talk to.
std::vector<ObjectId> Application::buildNpcVillage(const glm::vec3& c) {
    world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 8.0f), 18.0f);
    world.paint(glm::vec3(c.x, c.y, c.z - 8.0f), 11.0f, MAT_DIRT);
    std::vector<ObjectId> ids;
    auto person = [&](std::uint32_t seed, float x, float z, float yaw, const NpcSettings& st) {
        const ObjectId id = placeCharacter(crowdName(CrowdStyle::Villagers, seed), onGround(world, c.x + x, c.z + z), yaw);
        if (id) { setNpcSettings(id, st, "Village"); ids.push_back(id); }
        return id;
    };
    NpcSettings wander; wander.role = NpcRole::Wander; wander.radius = 6.0f; wander.reaction = NpcReaction::Friendly;
    wander.lines = { "Morning!", "Have you seen my cat?", "Market's busy today." };
    for (int i = 0; i < 6; ++i) person(3000 + std::uint32_t(i), float(i % 3) * 3.0f - 3.0f, -9.0f - float(i / 3) * 3.0f, float(i * 60), wander);
    NpcSettings guard; guard.role = NpcRole::Guard; guard.radius = 6.0f; guard.lines = { "Halt! State your business." };
    {
        const ObjectId g = placeCharacter(crowdName(CrowdStyle::Soldiers, 77), onGround(world, c.x + 7.0f, c.z - 5.0f), 200.0f);
        if (g) { setNpcSettings(g, guard, "Village"); ids.push_back(g); }
    }
    NpcSettings smith; smith.role = NpcRole::Work; smith.reaction = NpcReaction::Ignore; smith.hasWorkSpot = true;
    smith.workSpot = onGround(world, c.x - 6.5f, c.z - 6.0f);
    person(3100, -5.0f, -8.0f, 90.0f, smith);
    NpcSettings patrol; patrol.role = NpcRole::Patrol; patrol.reaction = NpcReaction::Ignore;
    patrol.path = { onGround(world, c.x - 8.0f, c.z - 14.0f), onGround(world, c.x + 8.0f, c.z - 14.0f), onGround(world, c.x + 8.0f, c.z - 3.0f),
                    onGround(world, c.x - 8.0f, c.z - 3.0f) };
    person(3200, -8.0f, -14.0f, 90.0f, patrol);
    NpcSettings chatty; chatty.role = NpcRole::Stand; chatty.reaction = NpcReaction::Friendly; chatty.notice = 5.0f;
    chatty.lines = { "Welcome to Millbrook! The inn is just past the well." };
    person(3300, 0.4f, -3.0f, 180.0f, chatty);
    NpcSettings shy; shy.role = NpcRole::Stand; shy.reaction = NpcReaction::Shy; shy.lines = { "Oh! Um... hello." };
    person(3301, -2.6f, -4.0f, 160.0f, shy);
    return ids;
}

void Application::setupNpcDemo() {
    if (demo == "npc_selftest") { runNpcSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    showHints = false;
    const glm::vec3 c = demospot::calmSpot(world);
    const std::vector<ObjectId> ids = buildNpcVillage(c);
    toasts.clear();
    if (demo == "npc_village" || demo == "npc_third") {
        // Play: you stand at the edge of the square; the people get on with things for a while.
        aimAt(camera, glm::vec3(c.x, demospot::groundHeight(world, c.x, c.z) + 1.7f, c.z), glm::vec3(c.x, c.y + 1.3f, c.z - 8.0f));
        setMode(Mode::Play);
        if (demo == "npc_third") thirdPerson = true;
        player.position = onGround(world, c.x, c.z + 6.0f);                       // far enough that nobody has noticed you yet
        for (int i = 0; i < 150; ++i) update(1.0f / 30.0f);
        player.position = onGround(world, c.x, c.z);                              // then walk up to the square
        for (int i = 0; i < 20; ++i) update(1.0f / 30.0f);
        aimAt(camera, player.eye(), glm::vec3(c.x, c.y + 1.3f, c.z - 8.0f));
        npcsFrozen = true;
        toasts.clear();
        return;
    }
    if (demo == "npc_editor") {
        // The editor: the patrolling one selected, with their path, and the Behaviour section showing.
        ObjectId who = 0;
        for (ObjectId id : ids) if (npcSettingsOf(id).role == NpcRole::Patrol) who = id;
        tool = Tool::Select;
        selectObject(who);
        settleFronts = { "Details" }; settleFrames = 5;
        aimAt(camera, glm::vec3(c.x + 2.0f, c.y + 11.0f, c.z + 5.0f), glm::vec3(c.x, c.y, c.z - 8.5f));
        for (int i = 0; i < 10; ++i) updateObjects(1.0f / 30.0f);
        uiHidden = false;
        return;
    }
}

void Application::runNpcSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[npctest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto key = [&](SDL_Keycode k) {
        SDL_Event e{};
        e.type = SDL_EVENT_KEY_DOWN; e.key.key = k; e.key.down = true;
        handleEvent(e);
    };
    setMode(Mode::Editor);
    tool = Tool::Select;
    uiHidden = false;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;

    const glm::vec3 c = demospot::calmSpot(world);
    world.flatten(glm::vec3(c.x, c.y + 0.05f, c.z - 8.0f), 16.0f);
    const glm::vec3 home = onGround(world, c.x, c.z - 8.0f);
    const ObjectId bo = placeCharacter("Explorer", home, 0.0f);
    check(bo != 0 && scene.find(bo)->npc.empty(), "a placed person starts with no behaviour");

    // ---- giving them a life, one undo step
    NpcSettings life; life.role = NpcRole::Wander; life.radius = 5.0f; life.reaction = NpcReaction::Ignore;
    setNpcSettings(bo, life, "Give Bo a life");
    check(npcSettingsOf(bo).role == NpcRole::Wander, "Give them a life: they wander");
    cmdUndo();
    check(scene.find(bo) && scene.find(bo)->npc.empty(), "Ctrl+Z takes it back");
    cmdRedo();
    check(npcSettingsOf(bo).role == NpcRole::Wander, "...and Ctrl+Y gives it again");

    // ---- clicking out a patrol path
    camera.position = home + glm::vec3(0.0f, 14.0f, 0.0f); camera.yaw = -90.0f; camera.pitch = -89.0f;
    updateObjects(0.0f);
    auto clickAt = [&](const glm::vec3& p) {
        glm::vec2 sp;
        gizmoView().project(p, sp);
        mouseX = sp.x; mouseY = sp.y;
        updateObjects(1.0f / 60.0f);
        selectToolMouseDown(false);
    };
    selectObject(bo);
    npcPicking = bo; npcPickingWork = false;
    clickAt(home + glm::vec3(4.0f, 0.0f, 0.0f));
    clickAt(home + glm::vec3(4.0f, 0.0f, 4.0f));
    clickAt(home + glm::vec3(0.0f, 0.0f, 4.0f));
    const NpcSettings withPath = npcSettingsOf(bo);
    check(withPath.path.size() == 3 && withPath.role == NpcRole::Patrol, "clicks in the world make a patrol path (and they patrol it)");
    check(withPath.path.size() == 3 && glm::length(glm::vec2(withPath.path[1].x - home.x - 4.0f, withPath.path[1].z - home.z - 4.0f)) < 0.3f, "...the points are where you clicked");
    check(selection.size() == 1 && selection[0] == bo, "...and clicking does not select something else");
    key(SDLK_ESCAPE);
    check(npcPicking == 0 && selection.size() == 1, "Esc finishes the path");
    cmdUndo();
    check(npcSettingsOf(bo).path.size() == 2, "each point is its own undo step");
    cmdRedo();

    // a friendly one to talk to
    NpcSettings chat; chat.role = NpcRole::Stand; chat.reaction = NpcReaction::Friendly; chat.notice = 4.0f; chat.lines = { "Nice to meet you!" };
    const glm::vec3 chatHome = onGround(world, c.x + 8.0f, c.z - 2.0f);
    const ObjectId al = placeCharacter("Scientist", chatHome, 180.0f);
    setNpcSettings(al, chat, "Al");
    {
        Scene again;
        check(again.fromText(scene.toText()) && again.find(bo) && again.find(bo)->npc == scene.find(bo)->npc, "what they do is saved with the world");
    }

    // ---- playing: they get on with it
    camera.position = onGround(world, c.x - 12.0f, c.z + 6.0f) + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -60.0f; camera.pitch = 0.0f;
    setMode(Mode::Play);
    float maxFromHome = 0.0f;
    float nearPoint[3] = { 1e9f, 1e9f, 1e9f };
    for (int i = 0; i < 30 * 25; ++i) {
        update(1.0f / 30.0f);
        if (const Evaluated* e = scene.evaluatedFor(bo)) {
            const glm::vec3 p(e->world[3]);
            maxFromHome = std::max(maxFromHome, glm::length(glm::vec2(p.x - home.x, p.z - home.z)));
            for (int k = 0; k < 3; ++k) nearPoint[k] = std::min(nearPoint[k], glm::length(glm::vec2(p.x - withPath.path[size_t(k)].x, p.z - withPath.path[size_t(k)].z)));
        }
    }
    check(maxFromHome > 3.0f, "playing: they walk their path");
    check(nearPoint[0] < 0.6f && nearPoint[1] < 0.6f && nearPoint[2] < 0.6f, "...visiting every point");
    check(scene.find(bo)->position == home, "...without changing where you put them");
    check(npcStateOf(bo) && lastCharacterDraws > 0, "...and they are drawn walking");
    // meeting someone
    player.position = chatHome + glm::vec3(0.0f, 0.0f, -2.5f);
    player.velocity = glm::vec3(0.0f);
    std::string heard;
    for (int i = 0; i < 30; ++i) { update(1.0f / 30.0f); if (const NpcState* st = npcStateOf(al); st && !st->speech.empty()) heard = st->speech; }
    check(heard == "Nice to meet you!", "come close to a friendly person and they say hello");
    check(npcStateOf(al) && npcStateOf(al)->lookAtPlayer && (npcStateOf(al)->mood == Mood::Happy || npcStateOf(al)->mood == Mood::Talking), "...looking at you, smiling");
    const NpcState* alState = npcStateOf(al);
    check(alState && std::fabs(glm::length(glm::vec2(alState->position.x - chatHome.x, alState->position.z - chatHome.z))) < 0.3f, "...and they stay where they are to talk");

    // ---- stop playing: everyone back where they were put
    setMode(Mode::Editor);
    updateObjects(1.0f / 60.0f);
    const Evaluated* e = scene.evaluatedFor(bo);
    check(e && glm::length(glm::vec3(e->world[3]) - home) < 1e-3f && npcLive.empty(), "back in the editor, everyone is where you put them");

    // ---- the schedule: at 19:00 the patroller goes home
    {
        NpcSettings day = npcSettingsOf(bo);
        day.schedule = { { 8.0f, NpcRole::Patrol }, { 18.0f, NpcRole::Stand } };
        setNpcSettings(bo, day, "Bo's day");
        timeOfDay = 19.0f;
        camera.position = onGround(world, c.x - 12.0f, c.z + 6.0f) + glm::vec3(0.0f, 1.7f, 0.0f);
        setMode(Mode::Play);
        for (int i = 0; i < 30 * 8; ++i) update(1.0f / 30.0f);
        const Evaluated* ev = scene.evaluatedFor(bo);
        check(ev && glm::length(glm::vec2(ev->world[3].x - home.x, ev->world[3].z - home.z)) < 0.5f && npcStateOf(bo)->role == NpcRole::Stand,
              "in the evening (by their schedule) they stay home");
        setMode(Mode::Editor);
        timeOfDay = 10.0f;
    }
    std::cerr << "[npctest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
