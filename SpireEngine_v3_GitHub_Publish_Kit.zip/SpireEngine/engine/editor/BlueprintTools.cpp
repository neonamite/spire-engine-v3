// The Blueprint Tool in the editor (v0.17): a window with a floor plan you draw rooms on, and the building it makes,
// following the cursor until you click it into the world. The rules that turn a plan into pieces are in scene/Blueprint.*;
// this file is the window, the mouse and the placing. Every building it makes is an ordinary Building group of kit pieces,
// so you can hand-edit it with the Kits panel, swap its style, move it, or open its plan again and rebuild it.
#include "core/Application.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <imgui.h>

namespace px {

using namespace ui;

const char* bpToolLabel(BpTool t) {
    switch (t) {
    case BpTool::Room: return "Room";
    case BpTool::Erase: return "Erase";
    case BpTool::Door: return "Door";
    case BpTool::Window: return "Window";
    case BpTool::Wall: return "Wall";
    case BpTool::Open: return "Open";
    case BpTool::Auto: return "Auto";
    case BpTool::Stairs: return "Stairs";
    case BpTool::Count: break;
    }
    return "";
}

const char* bpToolHint(BpTool t) {
    switch (t) {
    case BpTool::Room: return "Drag a rectangle to make a room.  Shift+drag adds to the room picked in the list.  Right-click picks a room.";
    case BpTool::Erase: return "Drag over cells to take them out of the building.";
    case BpTool::Door: return "Click or drag along edges to put doors in.";
    case BpTool::Window: return "Click or drag along edges to put windows in.";
    case BpTool::Wall: return "Click or drag along edges for a plain wall (inside a room too).";
    case BpTool::Open: return "Click or drag along edges for no wall at all: arches, open sides, porches.";
    case BpTool::Auto: return "Click or drag along edges to hand them back to the automatic rules.";
    case BpTool::Stairs: return "Click a cell to put stairs there (they climb the way the arrow points; R turns it).  Click stairs to take them away.";
    case BpTool::Count: break;
    }
    return "";
}

namespace {

ImU32 roomColour(int id, float alpha) {
    static const ImU32 palette[] = {
        IM_COL32(110, 160, 230, 255), IM_COL32(230, 160, 90, 255), IM_COL32(120, 200, 130, 255), IM_COL32(210, 120, 180, 255),
        IM_COL32(220, 210, 110, 255), IM_COL32(120, 210, 210, 255), IM_COL32(190, 140, 110, 255), IM_COL32(160, 130, 220, 255),
        IM_COL32(230, 120, 120, 255), IM_COL32(150, 190, 90, 255), IM_COL32(110, 130, 170, 255), IM_COL32(200, 170, 150, 255) };
    return withAlpha(palette[size_t((id - 1) % int(sizeof palette / sizeof palette[0]))], alpha);
}

const char* dirArrow(int d) {
    switch (((d % 4) + 4) % 4) { case 0: return "right"; case 1: return "down (to the front)"; case 2: return "left"; default: return "up (to the back)"; }
}

// The ground under a point: what a ray from above reaches.
float groundUnder(const ChunkManager& world, float x, float z) {
    RayHit h;
    const float guess = world.terrain().surfaceHeight(x, z);
    if (world.raycast(glm::vec3(x, guess + 60.0f, z), glm::vec3(0, -1, 0), 160.0f, h)) return h.position.y;
    return guess;
}

std::vector<std::string> savedBlueprints() {
    std::vector<std::string> out;
    std::error_code ec;
    for (const auto& e : std::filesystem::directory_iterator("blueprints", ec))
        if (e.path().extension() == ".pxblueprint") out.push_back(e.path().stem().string());
    std::sort(out.begin(), out.end());
    return out;
}

} // namespace

// ------------------------------------------------------------------ the plan and its history

void Application::bpPushUndo(const Blueprint& before) {
    bp.undo.push_back(before);
    if (bp.undo.size() > 100) bp.undo.erase(bp.undo.begin());
    bp.redo.clear();
}

void Application::bpChange() { bpPushUndo(bp.plan); }

void Application::bpUndo() {
    if (bp.undo.empty()) return;
    bp.redo.push_back(bp.plan);
    bp.plan = bp.undo.back();
    bp.undo.pop_back();
    bp.level = std::clamp(bp.level, 0, bp.plan.storeys() - 1);
}

void Application::bpRedo() {
    if (bp.redo.empty()) return;
    bp.undo.push_back(bp.plan);
    bp.plan = bp.redo.back();
    bp.redo.pop_back();
    bp.level = std::clamp(bp.level, 0, bp.plan.storeys() - 1);
}

void Application::bpLoadPlan(const Blueprint& plan, const std::string& why) {
    if (!(plan == bp.plan)) bpChange();
    bp.plan = plan;
    bp.plan.tidy();
    bp.level = 0;
    bp.room = 1;
    bp.started = true;
    if (!why.empty()) toast(why);
}

void Application::bpPaintRect(int level, glm::ivec2 a, glm::ivec2 b, int mode) {
    Blueprint& p = bp.plan;
    if (level < 0 || level >= p.storeys()) return;
    const Blueprint before = p;
    int id = 0;
    if (mode == 0) {
        id = p.addRoom("");
        if (!id) { toast("A blueprint can have " + std::to_string(kBpMaxRooms) + " rooms at most", Toast::Kind::Warning); return; }
    } else if (mode == 1) {
        id = std::clamp(bp.room, 1, std::max(1, int(p.rooms.size())));
        if (p.rooms.empty()) id = p.addRoom("");
    }
    p.fillRect(level, a.x, a.y, b.x, b.y, id);
    // Stairs standing on a cell that was taken out go too.
    auto& st = p.levels[size_t(level)].stairs;
    st.erase(std::remove_if(st.begin(), st.end(), [&](const BpStairs& s) {
        const glm::ivec2 c = glm::ivec2(s.x, s.z) + bpDir(s.dir);
        return !p.inside(level, s.x, s.z) || !p.inside(level, c.x, c.y);
    }), st.end());
    // A room that lost all its cells everywhere is forgotten (new rooms keep their ids until then).
    for (int r = int(p.rooms.size()); r >= 1; --r) {
        bool used = false;
        for (int l = 0; l < p.storeys() && !used; ++l) used = p.cellCount(l, r) > 0;
        if (!used) { if (bp.room > r) --bp.room; p.removeRoom(r); }
    }
    if (mode == 0 && id) bp.room = std::min(id, int(p.rooms.size()));
    if (!(p == before)) bpPushUndo(before);
}

void Application::bpSetEdge(int level, int o, int x, int z, BpEdge e) { bp.plan.setEdge(level, o, x, z, e); }

void Application::bpToggleStairs(int level, int x, int z, int dir) {
    Blueprint& p = bp.plan;
    if (level < 0 || level >= p.storeys()) return;
    auto& st = p.levels[size_t(level)].stairs;
    for (size_t i = 0; i < st.size(); ++i) {
        const glm::ivec2 a(st[i].x, st[i].z), b = a + bpDir(st[i].dir);
        if (a == glm::ivec2(x, z) || b == glm::ivec2(x, z)) {
            bpChange();
            st.erase(st.begin() + long(i));
            return;
        }
    }
    const glm::ivec2 b = glm::ivec2(x, z) + bpDir(dir);
    if (!p.inGrid(x, z) || !p.inGrid(b.x, b.y)) { toast("Stairs need two cells: there is no room that way", Toast::Kind::Warning); return; }
    if (level + 1 >= p.storeys()) { toast("Stairs go up to the storey above: add a storey first", Toast::Kind::Warning); return; }
    bpChange();
    st.push_back({ x, z, dir });
}

void Application::bpRefreshPreview() {
    if (bp.previewValid && bp.previewOf == bp.plan) return;
    bp.preview = generateBlueprint(bp.plan, 0);
    bp.previewOf = bp.plan;
    bp.previewValid = true;
}

// ------------------------------------------------------------------ opening it

void Application::openBlueprintEditor() {
    if (!bp.started) {
        const auto& presets = blueprintPresets();
        bp.plan = presets.size() > 1 ? presets[1] : presets.front();
        bp.started = true;
        bp.room = 1;
    }
    kits.update(assets);
    if (!kits.find(bp.plan.style) && !kits.styles().empty()) bp.plan.style = kits.styles()[0].name;
    bp.open = true;
    bp.focus = true;
    if (bp.placing) bpStopPlacing(false);
    stopPlacing();
}

ObjectId Application::blueprintBuildingOf(ObjectId id) const {
    for (const SceneObject* o = scene.find(id); o; o = o->parent ? scene.find(o->parent) : nullptr)
        if (o->isGroup() && !o->blueprint.empty()) return o->id;
    return 0;
}

void Application::editBuildingBlueprint(ObjectId id) {
    const ObjectId g = blueprintBuildingOf(id);
    const SceneObject* o = g ? scene.find(g) : nullptr;
    if (!o) { toast("That was not made with a blueprint", Toast::Kind::Warning); return; }
    Json j;
    Blueprint plan;
    std::string err;
    if (!Json::parse(o->blueprint, j, &err) || !blueprintFromJson(j, plan, &err)) { toast("Its plan could not be read: " + err, Toast::Kind::Warning); return; }
    openBlueprintEditor();
    bpLoadPlan(plan, "");
    bp.target = g;
    bp.turns = ((j.get("turns").integer(0) % 4) + 4) % 4;
    toast("Editing the plan of " + o->name + ". Rebuild puts the changes in place.");
}

// ------------------------------------------------------------------ placing it

void Application::bpStartPlacing() {
    if (bp.plan.empty()) { toast("Draw a room first", Toast::Kind::Warning); return; }
    stopPlacing();
    selection.clear();
    tool = Tool::Select;
    bp.placing = true;
    bp.spotValid = false;
    bp.lastAim = glm::vec3(1e9f);
    bp.ghostTurns = -1;
    toast("Click to build " + bp.plan.name + ".  R or the wheel turns it, Shift+click builds another, Esc goes back to the plan.");
}

void Application::bpStopPlacing(bool reopen) {
    bp.placing = false;
    bp.spotValid = false;
    if (reopen) { bp.open = true; bp.focus = true; }
}

bool Application::bpSpotUnderCursor(glm::vec3& spot) {
    glm::vec3 pos, n;
    if (!findPlacementSpot(pos, n)) return false;
    const glm::ivec2 fp = blueprintFootprint(bp.plan, bp.turns);
    const float sx = std::round((pos.x - float(fp.x) * kKitCell * 0.5f) / kKitCell) * kKitCell;
    const float sz = std::round((pos.z - float(fp.y) * kKitCell * 0.5f) / kKitCell) * kKitCell;
    const glm::vec3 aim(sx, float(fp.x * 100 + fp.y), sz);                 // the ground is measured again only when the footprint moves
    if (aim != bp.lastAim) {
        float y = -1e9f;
        for (int j = 0; j <= fp.y; ++j)
            for (int i = 0; i <= fp.x; ++i) y = std::max(y, groundUnder(world, sx + float(i) * kKitCell, sz + float(j) * kKitCell));
        bp.spot = glm::vec3(sx, std::round(y * 4.0f) / 4.0f, sz);
        bp.lastAim = aim;
    }
    spot = bp.spot;
    return true;
}

void Application::bpGhostDraws(std::vector<ObjectDraw>& draws) {
    const ImGuiIO& io = ImGui::GetIO();
    bp.spotValid = !io.WantCaptureMouse && !uiHidden && !looking && bpSpotUnderCursor(bp.spot);
    if (!(bp.ghostOf == bp.plan) || bp.ghostTurns != bp.turns) {
        bp.ghost = generateBlueprint(bp.plan, bp.turns);
        bp.ghostOf = bp.plan;
        bp.ghostTurns = bp.turns;
    }
    if (!bp.spotValid) return;
    kits.update(assets);
    AssetPtr byRole[kKitRoleCount];
    for (int r = 1; r < kKitRoleCount; ++r) byRole[r] = assets.get(kits.piece(bp.plan.style, KitRole(r)));
    draws.reserve(draws.size() + bp.ghost.pieces.size());
    for (const BpPiece& p : bp.ghost.pieces) {
        const AssetPtr& a = byRole[int(p.role)];
        if (!a) continue;
        ObjectDraw d;
        d.asset = a;
        d.model = composeTransform(bp.spot + p.position, glm::vec3(0.0f, p.yaw, 0.0f), 1.0f);
        d.highlight = glm::vec4(0.25f, 0.85f, 1.0f, 0.75f);
        draws.push_back(std::move(d));
    }
}

void Application::drawBlueprintOverlay(ImDrawList* dl, const GizmoView& v, float s) {
    if (bp.spotValid) {
        // The footprint on the ground, and the grid lines it covers.
        const glm::vec2 size(2.0f * float(bp.ghost.footprint.x), 2.0f * float(bp.ghost.footprint.y));
        const float y = bp.spot.y + 0.05f;
        auto seg = [&](glm::vec3 a, glm::vec3 b, ImU32 c, float t) {
            glm::vec2 pa, pb;
            if (v.project(a, pa) && v.project(b, pb)) dl->AddLine(ImVec2(pa.x, pa.y), ImVec2(pb.x, pb.y), c, t);
        };
        const glm::vec3 o(bp.spot.x, y, bp.spot.z);
        const ImU32 edge = IM_COL32(120, 230, 255, 235), grid = IM_COL32(120, 230, 255, 90);
        for (float x = 2.0f; x < size.x - 0.01f; x += 2.0f) seg(o + glm::vec3(x, 0, 0), o + glm::vec3(x, 0, size.y), grid, 1.0f * s);
        for (float z = 2.0f; z < size.y - 0.01f; z += 2.0f) seg(o + glm::vec3(0, 0, z), o + glm::vec3(size.x, 0, z), grid, 1.0f * s);
        seg(o, o + glm::vec3(size.x, 0, 0), edge, 2.0f * s);
        seg(o + glm::vec3(size.x, 0, 0), o + glm::vec3(size.x, 0, size.y), edge, 2.0f * s);
        seg(o + glm::vec3(size.x, 0, size.y), o + glm::vec3(0, 0, size.y), edge, 2.0f * s);
        seg(o + glm::vec3(0, 0, size.y), o, edge, 2.0f * s);
    }
    pushFont(fonts.small);
    char text[300];
    std::snprintf(text, sizeof text, "%s  -  %d pieces, %.0f x %.0f m     click: build   R or wheel: turn   Shift+click: build and keep going   Esc: back to the plan",
                  bp.plan.name.c_str(), int(bp.ghost.pieces.size()), double(bp.ghost.size.x), double(bp.ghost.size.z));
    const ImVec2 ts = ImGui::CalcTextSize(text);
    const ImVec2 a(viewRect.x + (viewRect.w - ts.x) * 0.5f - 10 * s, viewRect.y + viewRect.h - ts.y - 40 * s);
    dl->AddRectFilled(a, ImVec2(a.x + ts.x + 20 * s, a.y + ts.y + 12 * s), IM_COL32(11, 12, 16, 225), 8 * s);
    dl->AddText(ImVec2(a.x + 10 * s, a.y + 6 * s), col::text, text);
    popFont();
}

ObjectId Application::bpBuild(const Blueprint& plan, const glm::vec3& spot, int turns, ObjectId rebuild, bool levelGround) {
    kits.update(assets);
    const BpResult r = generateBlueprint(plan, turns);
    if (r.pieces.empty()) return 0;
    const SceneObject* target = rebuild ? scene.find(rebuild) : nullptr;
    if (rebuild && (!target || !target->isGroup())) return 0;

    if (levelGround && !rebuild) {
        // One flatten that covers the whole footprint at full strength (it fades out beyond); the ground ends up just under the slab.
        const glm::vec2 size(2.0f * float(r.footprint.x), 2.0f * float(r.footprint.y));
        const float halfDiag = 0.5f * std::sqrt(size.x * size.x + size.y * size.y);
        world.flatten(glm::vec3(spot.x + size.x * 0.5f, spot.y + 0.1f, spot.z + size.y * 0.5f), std::max(3.0f, halfDiag / 0.55f + 0.5f));
    }

    // The plan rides along with the building, with where it stands, so it can be opened and rebuilt later.
    Json saved = blueprintToJson(plan);
    saved.set("origin", Json::array({ spot.x, spot.y, spot.z }));
    saved.set("turns", ((turns % 4) + 4) % 4);

    ObjectId group = rebuild;
    if (rebuild) {
        for (ObjectId c : scene.children(rebuild)) scene.remove(c);
        SceneObject* g = scene.mutate(rebuild);
        g->blueprint = saved.dump(-1);
    } else {
        SceneObject g;
        g.name = plan.name.empty() ? "Building" : plan.name;
        g.solid = false;
        g.blueprint = saved.dump(-1);
        group = scene.add(g);
    }
    std::string missing;
    for (const BpPiece& p : r.pieces) {
        std::string asset = kits.piece(plan.style, p.role);
        if (asset.empty()) {                                   // a kit of your own may lack a piece: borrow the brick one
            asset = kits.piece("Brick house", p.role);
            if (missing.empty()) missing = kitRoleLabel(p.role);
        }
        if (asset.empty()) continue;
        SceneObject o;
        o.asset = asset;
        o.name = asset;
        o.parent = group;
        o.position = spot + p.position;
        o.rotation = glm::vec3(0.0f, p.yaw, 0.0f);
        scene.add(o);
    }
    commitScene((rebuild ? "Rebuild " : "Build ") + plan.name);
    // Hand-building with the Kits panel carries on where this left off.
    kitGroup = group;
    kitBaseY = spot.y;
    kitBaseSet = true;
    kitStyle = plan.style;
    if (!missing.empty()) toast("The " + plan.style + " kit has no " + missing + " piece: the Brick house one is used instead", Toast::Kind::Warning);
    return group;
}

bool Application::bpRebuildTarget() {
    const SceneObject* g = bp.target ? scene.find(bp.target) : nullptr;
    if (!g || g->blueprint.empty()) { bp.target = 0; return false; }
    Json j;
    if (!Json::parse(g->blueprint, j)) return false;
    const Json& o = j.get("origin");
    const glm::vec3 spot(float(o.at(0).num()), float(o.at(1).num()), float(o.at(2).num()));
    const int turns = ((j.get("turns").integer(0) % 4) + 4) % 4;
    const std::string name = g->name;
    if (!bpBuild(bp.plan, spot, turns, bp.target, false)) return false;
    toast("Rebuilt " + name + " (" + std::to_string(generateBlueprint(bp.plan, turns).pieces.size()) + " pieces)", Toast::Kind::Success);
    playSfxAt("stamp", spot, 0.9f);
    return true;
}

void Application::bpClickBuild(bool keepPlacing) {
    glm::vec3 spot;
    if (!bpSpotUnderCursor(spot)) return;
    const ObjectId g = bpBuild(bp.plan, spot, bp.turns, 0, bp.levelGround);
    if (!g) return;
    const size_t n = bp.ghost.pieces.size();
    playSfxAt("stamp", spot, 1.0f, 0.85f);
    bp.target = g;
    bp.lastAim = glm::vec3(1e9f);                              // levelling changed the ground
    toast("Built " + bp.plan.name + ": " + std::to_string(n) + " pieces. Select it and press Edit the building's blueprint to change it.", Toast::Kind::Success);
    if (!keepPlacing) bpStopPlacing(false);
}

// ------------------------------------------------------------------ the window

void Application::drawBlueprintWindow() {
    if (!bp.open || bp.placing) { bp.windowFocused = false; return; }
    const float s = scale();
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowSize(ImVec2(std::min(1040 * s, vp->WorkSize.x - 40 * s), std::min(660 * s, vp->WorkSize.y - 40 * s)), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.5f, vp->WorkPos.y + vp->WorkSize.y * 0.5f), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSizeConstraints(ImVec2(680 * s, 440 * s), ImVec2(FLT_MAX, FLT_MAX));
    if (bp.focus) { ImGui::SetNextWindowFocus(); bp.focus = false; }
    const std::string title = "Blueprint  -  " + bp.plan.name + "###blueprint";
    if (!ImGui::Begin(title.c_str(), &bp.open, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar)) {
        bp.windowFocused = false;
        ImGui::End();
        return;
    }
    bp.windowFocused = ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows);
    bp.level = std::clamp(bp.level, 0, bp.plan.storeys() - 1);
    bpRefreshPreview();

    // ---- the toolbar: tools on the left, history on the right
    for (int t = 0; t < int(BpTool::Count); ++t) {
        if (t) ImGui::SameLine(0, (t == int(BpTool::Door) || t == int(BpTool::Stairs)) ? 14 * s : 4 * s);
        const bool on = bp.tool == BpTool(t);
        if (on) pushSelectedButton();
        char label[48];
        std::snprintf(label, sizeof label, "%s##bptool%d", bpToolLabel(BpTool(t)), t);
        if (ImGui::Button(label)) bp.tool = BpTool(t);
        if (on) popSelectedButton();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", bpToolHint(BpTool(t)));
    }
    if (bp.tool == BpTool::Stairs) {
        ImGui::SameLine(0, 8 * s);
        char lab[64];
        std::snprintf(lab, sizeof lab, "Climb: %s##dir", dirArrow(bp.stairsDir));
        if (ImGui::SmallButton(lab)) bp.stairsDir = (bp.stairsDir + 1) % 4;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Which way new stairs climb.  R turns it.");
    }
    {
        const float bw = 64 * s;
        ImGui::SameLine(ImGui::GetWindowContentRegionMax().x - bw * 2 - 4 * s);
        ImGui::BeginDisabled(bp.undo.empty());
        if (ImGui::Button("Undo", ImVec2(bw, 0))) bpUndo();
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("Undo a change to the plan  (Ctrl+Z)");
        ImGui::SameLine(0, 4 * s);
        ImGui::BeginDisabled(bp.redo.empty());
        if (ImGui::Button("Redo", ImVec2(bw, 0))) bpRedo();
        ImGui::EndDisabled();
    }
    if (bp.windowFocused && !ImGui::GetIO().WantTextInput && ImGui::IsKeyPressed(ImGuiKey_R, false)) bp.stairsDir = (bp.stairsDir + 1) % 4;

    // ---- the storeys
    for (int l = 0; l < bp.plan.storeys(); ++l) {
        if (l) ImGui::SameLine(0, 4 * s);
        const bool on = bp.level == l;
        if (on) pushSelectedButton();
        const std::string lab = kitLevelLabel(l) + "##lvl" + std::to_string(l);
        if (ImGui::Button(lab.c_str())) bp.level = l;
        if (on) popSelectedButton();
    }
    ImGui::SameLine(0, 10 * s);
    ImGui::BeginDisabled(bp.plan.storeys() >= kBpMaxLevels);
    if (ImGui::Button("+ Storey")) { bpChange(); bp.plan.setStoreys(bp.plan.storeys() + 1); bp.level = bp.plan.storeys() - 1; }
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("A storey on top, starting with the outline of the one below.  Up to %d.", kBpMaxLevels);
    ImGui::SameLine(0, 4 * s);
    ImGui::BeginDisabled(bp.plan.storeys() <= 1);
    if (ImGui::Button("- Storey")) { bpChange(); bp.plan.setStoreys(bp.plan.storeys() - 1); bp.level = std::min(bp.level, bp.plan.storeys() - 1); }
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("Takes the top storey away");

    // ---- the plan and the side bar
    const float sideW = 300 * s;
    const ImVec2 avail = ImGui::GetContentRegionAvail();
    ImGui::BeginChild("##bpplan", ImVec2(avail.x - sideW - 8 * s, avail.y), ImGuiChildFlags_None, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    drawBlueprintCanvas(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y);
    ImGui::EndChild();
    ImGui::SameLine(0, 8 * s);
    ImGui::BeginChild("##bpside", ImVec2(sideW, avail.y), ImGuiChildFlags_None);
    drawBlueprintSidebar();
    ImGui::EndChild();
    ImGui::End();
}

void Application::drawBlueprintCanvas(float width, float height) {
    const float s = scale();
    Blueprint& p = bp.plan;
    const int L = bp.level;
    const float hintH = ImGui::GetFontSize() * 2.2f;
    const ImVec2 c0 = ImGui::GetCursorScreenPos();
    const ImVec2 size(std::max(width, 100.0f), std::max(height - hintH, 100.0f));
    ImGui::InvisibleButton("##canvas", size, ImGuiButtonFlags_MouseButtonLeft | ImGuiButtonFlags_MouseButtonRight);
    const bool hovered = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(c0, ImVec2(c0.x + size.x, c0.y + size.y), IM_COL32(21, 26, 36, 255), 8 * s);

    // Cells as big as fit, up to a comfortable size; the plan in the middle, the front at the bottom.
    const float pad = 26 * s;
    const float cp = std::floor(std::min({ (size.x - 2 * pad) / float(p.width), (size.y - 2 * pad) / float(p.depth), 96 * s }));
    const ImVec2 o(std::floor(c0.x + (size.x - cp * float(p.width)) * 0.5f), std::floor(c0.y + (size.y - cp * float(p.depth)) * 0.5f));
    auto P = [&](float x, float z) { return ImVec2(o.x + x * cp, o.y + z * cp); };
    const ImVec2 mouse = ImGui::GetIO().MousePos;
    const float fx = (mouse.x - o.x) / cp, fz = (mouse.y - o.y) / cp;
    const glm::ivec2 cell(int(std::floor(fx)), int(std::floor(fz)));
    const bool onCell = p.inGrid(cell.x, cell.y);
    auto clampCell = [&](glm::ivec2 c) { return glm::clamp(c, glm::ivec2(0), glm::ivec2(p.width - 1, p.depth - 1)); };

    // The edge nearest the mouse (for the edge tools).
    int eo = -1, ex = 0, ez = 0;
    {
        const float rx = std::round(fx), rz = std::round(fz);
        const float dx = std::fabs(fx - rx), dz = std::fabs(fz - rz);
        if (dz <= dx && dz < 0.32f && fx >= 0 && fx < float(p.width) && rz >= 0 && rz <= float(p.depth)) { eo = 0; ex = int(std::floor(fx)); ez = int(rz); }
        else if (dx < 0.32f && fz >= 0 && fz < float(p.depth) && rx >= 0 && rx <= float(p.width)) { eo = 1; ex = int(rx); ez = int(std::floor(fz)); }
    }
    const bool edgeTool = bp.tool == BpTool::Door || bp.tool == BpTool::Window || bp.tool == BpTool::Wall || bp.tool == BpTool::Open || bp.tool == BpTool::Auto;
    auto toolEdge = [&]() {
        switch (bp.tool) {
        case BpTool::Door: return BpEdge::Door;
        case BpTool::Window: return BpEdge::Window;
        case BpTool::Wall: return BpEdge::Wall;
        case BpTool::Open: return BpEdge::Open;
        default: return BpEdge::Auto;
        }
    };

    // ---- the mouse
    if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Right) && onCell) {
        if (int r = p.room(L, cell.x, cell.y)) { bp.room = r; toast("Picked " + p.roomName(r)); }
    }
    if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
        if (bp.tool == BpTool::Room || bp.tool == BpTool::Erase) {
            if (onCell) { bp.dragging = true; bp.dragFrom = bp.dragTo = cell; bp.dragAdd = ImGui::GetIO().KeyShift; }
        } else if (edgeTool) {
            if (eo >= 0) {
                bpChange();
                bp.edgeStroke = true;
                bp.lastEdge = 0xFFFFFFFFu;
            }
        } else if (bp.tool == BpTool::Stairs && onCell) {
            bpToggleStairs(L, cell.x, cell.y, bp.stairsDir);
        }
    }
    if (bp.dragging) {
        bp.dragTo = clampCell(cell);
        if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            bp.dragging = false;
            bpPaintRect(L, bp.dragFrom, bp.dragTo, bp.tool == BpTool::Erase ? 2 : bp.dragAdd && !p.rooms.empty() ? 1 : 0);
        }
    }
    if (bp.edgeStroke) {
        if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            bp.edgeStroke = false;
            if (!bp.undo.empty() && bp.undo.back() == p) bp.undo.pop_back();      // a click that changed nothing leaves no step
        } else if (eo >= 0) {
            const std::uint32_t key = bpEdgeKey(eo, ex, ez);
            if (key != bp.lastEdge) { bp.lastEdge = key; bpSetEdge(L, eo, ex, ez, toolEdge()); }
        }
    }
    bpRefreshPreview();
    const BpResult& pr = bp.preview;

    // ---- the storey below, faintly, so you can see what you are building on
    if (L > 0)
        for (int z = 0; z < p.depth; ++z)
            for (int x = 0; x < p.width; ++x)
                if (p.inside(L - 1, x, z)) dl->AddRectFilled(P(float(x), float(z)), P(float(x + 1), float(z + 1)), IM_COL32(255, 255, 255, 14));

    // ---- rooms
    std::vector<int> holes(size_t(p.width) * size_t(p.depth), 0);
    for (const BpStairsOut& st : pr.stairs)
        if (st.level + 1 == L) {
            const glm::ivec2 a(st.s.x, st.s.z), b = a + bpDir(st.s.dir);
            holes[size_t(a.x) + size_t(a.y) * size_t(p.width)] = 1;
            holes[size_t(b.x) + size_t(b.y) * size_t(p.width)] = 1;
        }
    for (int z = 0; z < p.depth; ++z)
        for (int x = 0; x < p.width; ++x) {
            const int r = p.room(L, x, z);
            if (!r) continue;
            const bool sel = r == bp.room;
            dl->AddRectFilled(P(float(x), float(z)), P(float(x + 1), float(z + 1)), roomColour(r, sel ? 0.62f : 0.42f));
            if (holes[size_t(x) + size_t(z) * size_t(p.width)]) {     // open to the stairs below
                const ImVec2 a = P(float(x), float(z)), b = P(float(x + 1), float(z + 1));
                dl->AddRectFilled(ImVec2(a.x + 3 * s, a.y + 3 * s), ImVec2(b.x - 3 * s, b.y - 3 * s), IM_COL32(10, 12, 16, 230), 3 * s);
                for (int k = 1; k < 4; ++k) dl->AddLine(ImVec2(a.x + (b.x - a.x) * float(k) / 4.0f, a.y + 3 * s), ImVec2(a.x + 3 * s, a.y + (b.y - a.y) * float(k) / 4.0f), IM_COL32(255, 255, 255, 40), 1.0f);
            }
        }
    // grid
    for (int x = 0; x <= p.width; ++x) dl->AddLine(P(float(x), 0), P(float(x), float(p.depth)), IM_COL32(255, 255, 255, 26), 1.0f);
    for (int z = 0; z <= p.depth; ++z) dl->AddLine(P(0, float(z)), P(float(p.width), float(z)), IM_COL32(255, 255, 255, 26), 1.0f);

    // ---- stairs
    for (const BpStairsOut& st : pr.stairs) {
        if (st.level != L) continue;
        const glm::ivec2 a(st.s.x, st.s.z), d = bpDir(st.s.dir), b = a + d;
        const glm::ivec2 lo = glm::min(a, b), hi = glm::max(a, b);
        const ImVec2 pa = P(float(lo.x) + 0.1f, float(lo.y) + 0.1f), pb = P(float(hi.x + 1) - 0.1f, float(hi.y + 1) - 0.1f);
        dl->AddRectFilled(pa, pb, st.automatic ? IM_COL32(120, 95, 70, 200) : IM_COL32(150, 110, 70, 235), 3 * s);
        for (int k = 1; k < 8; ++k) {                          // treads
            const float t = float(k) / 8.0f;
            if (d.x != 0) { const float x = pa.x + (pb.x - pa.x) * t; dl->AddLine(ImVec2(x, pa.y), ImVec2(x, pb.y), IM_COL32(40, 30, 20, 160), 1.0f); }
            else          { const float y = pa.y + (pb.y - pa.y) * t; dl->AddLine(ImVec2(pa.x, y), ImVec2(pb.x, y), IM_COL32(40, 30, 20, 160), 1.0f); }
        }
        const ImVec2 from = P(float(a.x) + 0.5f, float(a.y) + 0.5f), to = P(float(b.x) + 0.5f + float(d.x) * 0.3f, float(b.y) + 0.5f + float(d.y) * 0.3f);
        dl->AddLine(from, to, IM_COL32(255, 245, 230, 230), 2.0f * s);
        const ImVec2 dir(float(d.x), float(d.y)), side(-float(d.y), float(d.x));
        const float hs = 7 * s;
        dl->AddTriangleFilled(ImVec2(to.x + dir.x * hs, to.y + dir.y * hs), ImVec2(to.x - dir.x * hs + side.x * hs, to.y - dir.y * hs + side.y * hs),
                              ImVec2(to.x - dir.x * hs - side.x * hs, to.y - dir.y * hs - side.y * hs), IM_COL32(255, 245, 230, 230));
        if (st.automatic) {
            pushFont(fonts.small);
            dl->AddText(ImVec2(pa.x + 3 * s, pa.y + 1 * s), IM_COL32(255, 255, 255, 170), "auto");
            popFont();
        }
    }

    // ---- walls, windows, doors
    for (const BpEdgeOut& e : pr.edges) {
        if (e.level != L) continue;
        const ImVec2 a = P(float(e.x), float(e.z)), b = e.o == 0 ? P(float(e.x + 1), float(e.z)) : P(float(e.x), float(e.z + 1));
        auto lerp = [&](float t) { return ImVec2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t); };
        const float th = (e.exterior ? 5.0f : 3.5f) * s;
        const ImU32 wall = e.manual ? IM_COL32(255, 205, 120, 255) : IM_COL32(232, 236, 244, 255);
        switch (e.role) {
        case KitRole::Wall: dl->AddLine(a, b, wall, th); break;
        case KitRole::Window:
            dl->AddLine(a, b, wall, th);
            dl->AddLine(lerp(0.22f), lerp(0.78f), IM_COL32(120, 200, 255, 255), th * 0.6f);
            break;
        case KitRole::Doorway: {
            dl->AddLine(a, lerp(0.2f), wall, th);
            dl->AddLine(lerp(0.8f), b, wall, th);
            // the door's swing, into the building (or into the second room)
            const int rA = e.o == 0 ? p.room(L, e.x, e.z - 1) : p.room(L, e.x - 1, e.z);
            const bool intoA = e.exterior && rA != 0;
            const ImVec2 hinge = lerp(0.2f);
            const float r = cp * 0.6f, q = 1.5707963f;
            const float a0 = e.o == 0 ? 0.0f : q, a1 = e.o == 0 ? (intoA ? -q : q) : (intoA ? 2.0f * q : 0.0f);
            dl->PathLineTo(hinge);
            dl->PathArcTo(hinge, r, a0, a1, 10);
            dl->PathStroke(IM_COL32(255, 190, 90, 200), ImDrawFlags_None, 1.4f * s);
            break;
        }
        default:                                                     // open: a dotted line where the wall would be
            for (int k = 0; k < 6; ++k) dl->AddLine(lerp((float(k) + 0.25f) / 6.0f), lerp((float(k) + 0.75f) / 6.0f), IM_COL32(255, 190, 90, 220), 2.0f * s);
            break;
        }
    }

    // ---- room names
    pushFont(fonts.small);
    for (int r = 1; r <= int(p.rooms.size()); ++r) {
        glm::vec2 sum(0.0f), mn(1e9f), mx(-1e9f);
        int n = 0;
        for (int z = 0; z < p.depth; ++z) for (int x = 0; x < p.width; ++x) if (p.room(L, x, z) == r) { sum += glm::vec2(float(x) + 0.5f, float(z) + 0.5f); mn = glm::min(mn, glm::vec2(float(x), float(z))); mx = glm::max(mx, glm::vec2(float(x + 1), float(z + 1))); ++n; }
        if (!n) continue;
        glm::vec2 c = sum / float(n);
        // keep the label on a cell of the room (an L-shaped room's middle can be outside it)
        if (p.room(L, int(std::floor(c.x)), int(std::floor(c.y))) != r) {
            float best = 1e9f;
            for (int z = 0; z < p.depth; ++z) for (int x = 0; x < p.width; ++x)
                if (p.room(L, x, z) == r) { const glm::vec2 q(float(x) + 0.5f, float(z) + 0.5f); const float d = glm::length(q - c); if (d < best) { best = d; c = q; } }
        }
        const std::string name = p.roomName(r);
        const ImVec2 ts = ImGui::CalcTextSize(name.c_str());
        const ImVec2 at = P(c.x, c.y);
        if (ts.x < (mx.x - mn.x) * cp - 6 * s) dl->AddText(ImVec2(at.x - ts.x * 0.5f, at.y - ts.y * 0.5f), IM_COL32(255, 255, 255, 235), name.c_str());
        else { const char init[2] = { name[0], 0 }; const ImVec2 t2 = ImGui::CalcTextSize(init); dl->AddText(ImVec2(at.x - t2.x * 0.5f, at.y - t2.y * 0.5f), IM_COL32(255, 255, 255, 235), init); }
    }
    // the front
    {
        const char* front = "FRONT";
        const ImVec2 ts = ImGui::CalcTextSize(front);
        dl->AddText(ImVec2(o.x + cp * float(p.width) * 0.5f - ts.x * 0.5f, o.y + cp * float(p.depth) + 6 * s), col::textDim, front);
        char dims[64];
        std::snprintf(dims, sizeof dims, "%d x %d m", p.width * 2, p.depth * 2);
        dl->AddText(ImVec2(o.x, o.y - ts.y - 6 * s), col::textDim, dims);
    }
    popFont();

    // ---- what the mouse would do
    if (bp.dragging) {
        const glm::ivec2 lo = glm::min(bp.dragFrom, bp.dragTo), hi = glm::max(bp.dragFrom, bp.dragTo);
        const ImU32 c = bp.tool == BpTool::Erase ? col::danger : bp.dragAdd ? roomColour(bp.room, 1.0f) : col::accent;
        dl->AddRectFilled(P(float(lo.x), float(lo.y)), P(float(hi.x + 1), float(hi.y + 1)), withAlpha(c, 0.25f));
        dl->AddRect(P(float(lo.x), float(lo.y)), P(float(hi.x + 1), float(hi.y + 1)), c, 0.0f, 0, 2.0f * s);
        char t[48];
        std::snprintf(t, sizeof t, "%d x %d m", (hi.x - lo.x + 1) * 2, (hi.y - lo.y + 1) * 2);
        dl->AddText(ImVec2(mouse.x + 14 * s, mouse.y + 10 * s), IM_COL32(255, 255, 255, 230), t);
    } else if (hovered && edgeTool && eo >= 0) {
        const ImVec2 a = P(float(ex), float(ez)), b = eo == 0 ? P(float(ex + 1), float(ez)) : P(float(ex), float(ez + 1));
        dl->AddLine(a, b, withAlpha(col::accent, 0.9f), 7.0f * s);
    } else if (hovered && onCell && (bp.tool == BpTool::Room || bp.tool == BpTool::Erase)) {
        dl->AddRect(P(float(cell.x), float(cell.y)), P(float(cell.x + 1), float(cell.y + 1)), bp.tool == BpTool::Erase ? col::danger : col::accent, 0.0f, 0, 2.0f * s);
    } else if (hovered && onCell && bp.tool == BpTool::Stairs) {
        const glm::ivec2 b = cell + bpDir(bp.stairsDir);
        const glm::ivec2 lo = glm::min(cell, b), hi = glm::max(cell, b);
        dl->AddRect(P(float(lo.x), float(lo.y)), P(float(hi.x + 1), float(hi.y + 1)), p.inGrid(b.x, b.y) ? col::accent : col::danger, 3 * s, 0, 2.0f * s);
    }
    if (hovered && onCell && !bp.dragging) {
        const int r = p.room(L, cell.x, cell.y);
        ImGui::SetTooltip("%s", r ? p.roomName(r).c_str() : "Outside");
    }

    // ---- the hint under the plan
    ImGui::SetCursorScreenPos(ImVec2(c0.x + 4 * s, c0.y + size.y + 6 * s));
    pushFont(fonts.small);
    ImGui::PushTextWrapPos(c0.x + size.x);
    ImGui::TextDisabled("%s", bpToolHint(bp.tool));
    ImGui::PopTextWrapPos();
    popFont();
}

void Application::drawBlueprintSidebar() {
    const float s = scale();
    Blueprint& p = bp.plan;
    const Blueprint frameStart = p;                          // what one-click controls push onto the undo list when they change something
    bool clicked = false;                                    // a one-click control changed the plan
    auto track = [&]() {                                     // sliders and text boxes: one undo step per grab, not per frame
        if (ImGui::IsItemActivated()) bp.sliderBefore = frameStart;
        if (ImGui::IsItemDeactivatedAfterEdit() && !(bp.sliderBefore == p)) bpPushUndo(bp.sliderBefore);
    };
    kits.update(assets);

    section("Building");
    if (beginProps("##bpmain", 84.0f)) {
        prop("Name");
        char name[64];
        std::snprintf(name, sizeof name, "%s", p.name.c_str());
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::InputText("##bpname", name, sizeof name) && name[0]) p.name = name;
        track();
        prop("Kit", "The building kit the pieces come from (Kits panel)");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##bpkit", p.style.c_str())) {
            for (const KitStyleEntry& e : kits.styles())
                if (ImGui::Selectable(e.name.c_str(), e.name == p.style) && e.name != p.style) { p.style = e.name; clicked = true; }
            ImGui::EndCombo();
        }
        prop("Width", "Cells across (2 m each)");
        int w = p.width, d = p.depth;
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (sliderInt("##bpw", &w, 1, kBpMaxSize, "%d cells")) p.resize(w, p.depth);
        track();
        prop("Depth", "Cells from back to front (2 m each)");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (sliderInt("##bpd", &d, 1, kBpMaxSize, "%d cells")) p.resize(p.width, d);
        track();
        prop("Roof");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##bproof", bpRoofLabel(p.roof))) {
            for (BpRoof r : { BpRoof::Pitched, BpRoof::Flat, BpRoof::None })
                if (ImGui::Selectable(bpRoofLabel(r), p.roof == r) && p.roof != r) { p.roof = r; clicked = true; }
            ImGui::EndCombo();
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Pitched: ridges along the long side, lean-tos against taller parts.\nFlat: a floor laid on the walls.\nNone: open to the sky.");
        prop("Windows", "How many outside walls get a window");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##bpwin", bpWindowsLabel(p.windows))) {
            for (BpWindows wv : { BpWindows::None, BpWindows::Some, BpWindows::Many })
                if (ImGui::Selectable(bpWindowsLabel(wv), p.windows == wv) && p.windows != wv) { p.windows = wv; clicked = true; }
            ImGui::EndCombo();
        }
        endProps();
    }
    {
        if (ImGui::Checkbox("Front door", &p.frontDoor)) clicked = true;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("A door on the ground floor, at the front, unless you drew one yourself");
        ImGui::SameLine(150 * s);
        if (ImGui::Checkbox("Doors inside", &p.roomDoors)) clicked = true;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("A doorway between every two rooms that touch");
        if (ImGui::Checkbox("Stairs for me", &p.autoStairs)) clicked = true;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Stairs up to every storey you did not draw stairs for");
        ImGui::SameLine(150 * s);
        if (ImGui::Checkbox("Corner posts", &p.cornerPosts)) clicked = true;
    }

    // ---- rooms
    section("Rooms");
    {
        const float rowH = ImGui::GetFrameHeight();
        for (int r = 1; r <= int(p.rooms.size()); ++r) {
            ImGui::PushID(r);
            const int here = p.cellCount(bp.level, r);
            const ImVec2 at = ImGui::GetCursorScreenPos();
            ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(at.x, at.y + 3 * s), ImVec2(at.x + rowH - 6 * s, at.y + rowH - 3 * s), roomColour(r, 0.9f), 3 * s);
            ImGui::Dummy(ImVec2(rowH - 2 * s, rowH));
            ImGui::SameLine(0, 4 * s);
            const float areaX = ImGui::GetContentRegionMax().x - 82 * s;
            const float nameW = areaX - (ImGui::GetCursorPosX()) - 6 * s;
            if (r == bp.room) {
                char nm[48];
                std::snprintf(nm, sizeof nm, "%s", p.rooms[size_t(r - 1)].c_str());
                ImGui::SetNextItemWidth(nameW);
                if (ImGui::InputText("##rn", nm, sizeof nm)) p.rooms[size_t(r - 1)] = nm;
                track();
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("The picked room: Shift+drag on the plan adds to it.  Type to rename it.");
            } else {
                const std::string label = p.roomName(r);
                if (ImGui::Selectable(label.c_str(), false, 0, ImVec2(nameW, rowH))) bp.room = r;
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("Pick this room (Shift+drag on the plan adds to it)");
            }
            ImGui::SameLine(areaX);
            ImGui::AlignTextToFramePadding();
            if (here) ImGui::TextDisabled("%d m2", here * 4);
            else ImGui::TextDisabled("%s", "other floor");
            ImGui::SameLine(ImGui::GetContentRegionMax().x - 18 * s);
            if (ImGui::SmallButton("x")) { bpChange(); p.removeRoom(r); bp.room = std::max(1, std::min(bp.room, int(p.rooms.size()))); ImGui::PopID(); break; }
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Take this room out of the plan");
            ImGui::PopID();
        }
        if (p.rooms.empty()) { pushFont(fonts.small); ImGui::TextDisabled("Pick the Room tool and drag on the plan."); popFont(); }
    }

    // ---- what it makes
    section("What it makes");
    bpRefreshPreview();
    const BpResult& pr = bp.preview;
    {
        pushFont(fonts.small);
        ImGui::Text("%d pieces    %.0f x %.0f m, %.1f m tall", int(pr.pieces.size()), double(pr.size.x), double(pr.size.z), double(pr.size.y));
        ImGui::TextDisabled("%d walls  %d windows  %d doors  %d floors  %d roof  %d stairs",
                            pr.count(KitRole::Wall), pr.count(KitRole::Window), pr.count(KitRole::Doorway), pr.count(KitRole::Floor), pr.count(KitRole::Roof), pr.count(KitRole::Stairs));
        ImGui::PushTextWrapPos(0.0f);
        for (const std::string& wmsg : pr.warnings) { ImGui::PushStyleColor(ImGuiCol_Text, col::warning); ImGui::TextUnformatted(("!  " + wmsg).c_str()); ImGui::PopStyleColor(); }
        ImGui::PopTextWrapPos();
        popFont();
    }

    // ---- plans to start from, and files
    section("Plans");
    {
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##bppreset", "Start from a ready-made plan...")) {
            for (const Blueprint& pre : blueprintPresets()) {
                const std::string label = pre.name + "   (" + std::to_string(pre.width * 2) + " x " + std::to_string(pre.depth * 2) + " m, " +
                                          std::to_string(pre.storeys()) + (pre.storeys() == 1 ? " storey)" : " storeys)");
                if (ImGui::Selectable(label.c_str())) { bpLoadPlan(pre, "Plan: " + pre.name + ". Ctrl+Z in this window puts your old one back."); bp.target = 0; }
            }
            ImGui::EndCombo();
        }
        const float bw = (ImGui::GetContentRegionAvail().x - 8 * s) / 3.0f;
        if (ImGui::Button("New", ImVec2(bw, 0))) {
            Blueprint b;
            b.style = p.style;
            bpLoadPlan(b, "");
            bp.target = 0;
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("An empty plan");
        ImGui::SameLine(0, 4 * s);
        if (ImGui::Button("Save", ImVec2(bw, 0))) {
            std::string err;
            const std::string path = "blueprints/" + blueprintFileName(p.name) + ".pxblueprint";
            if (saveBlueprintFile(p, path, &err)) toast("Saved " + path, Toast::Kind::Success);
            else toast("Could not save: " + err, Toast::Kind::Warning);
        }
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("blueprints/%s.pxblueprint", blueprintFileName(p.name).c_str());
        ImGui::SameLine(0, 4 * s);
        if (ImGui::Button("Open...", ImVec2(bw, 0))) ImGui::OpenPopup("##bpopen");
        if (ImGui::BeginPopup("##bpopen")) {
            const std::vector<std::string> files = savedBlueprints();
            if (files.empty()) ImGui::TextDisabled("No saved blueprints yet");
            for (const std::string& f : files)
                if (ImGui::Selectable(f.c_str())) {
                    Blueprint b;
                    std::string err;
                    if (loadBlueprintFile("blueprints/" + f + ".pxblueprint", b, &err)) { bpLoadPlan(b, "Opened " + f); bp.target = 0; }
                    else toast("Could not open " + f + ": " + err, Toast::Kind::Warning);
                }
            ImGui::EndPopup();
        }
    }

    // ---- into the world
    section("Build it");
    const SceneObject* target = bp.target ? scene.find(bp.target) : nullptr;
    if (bp.target && !target) bp.target = 0;
    ImGui::Checkbox("Level the ground under it", &bp.levelGround);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Flattens the terrain under the footprint first (its own undo step).");
    ImGui::BeginDisabled(p.empty());
    if (target) {
        const std::string label = "Rebuild " + target->name;
        if (primaryButton(label.c_str())) bpRebuildTarget();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Replaces its pieces with what this plan makes, in the same place.\nChanges made to it by hand are replaced too.");
        const float bw = (ImGui::GetContentRegionAvail().x - 4 * s) * 0.5f;
        if (ImGui::Button("Place a copy", ImVec2(bw, 0))) { bp.target = 0; bpStartPlacing(); }
        ImGui::SameLine(0, 4 * s);
        if (ImGui::Button("Stop editing it", ImVec2(bw, 0))) bp.target = 0;
    } else {
        if (primaryButton("Place in the world")) bpStartPlacing();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("The building follows the mouse; click to build it.  R turns it.");
    }
    ImGui::EndDisabled();
    if (clicked && !(frameStart == p)) bpPushUndo(frameStart);
}

} // namespace px
