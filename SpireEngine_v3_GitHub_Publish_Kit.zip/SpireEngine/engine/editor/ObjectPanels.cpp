// The panels for working with objects: Scene (what is in the world, as a tree) and Details (the selected
// object). The Shelf (what you can place) is in editor/Shell.cpp.
#include "core/Application.h"
#include "editor/Panels.h"
#include "rules/Gadgets.h"
#include "scene/Thumbnail.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cctype>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <unordered_map>
#include <unordered_set>
#include <glad/glad.h>
#include <imgui.h>

namespace px {

using namespace ui;

namespace {

ImTextureRef texRef(unsigned glTex) { return ImTextureRef(ImTextureID(std::uintptr_t(glTex))); }

bool containsNoCase(const std::string& hay, const char* needle) {
    if (!*needle) return true;
    const size_t n = std::strlen(needle);
    for (size_t i = 0; i + n <= hay.size(); ++i) {
        size_t k = 0;
        while (k < n && std::tolower(static_cast<unsigned char>(hay[i + k])) == std::tolower(static_cast<unsigned char>(needle[k]))) ++k;
        if (k == n) return true;
    }
    return false;
}

std::string niceName(std::string s) {
    std::replace(s.begin(), s.end(), '_', ' ');
    if (!s.empty()) s[0] = char(std::toupper(static_cast<unsigned char>(s[0])));
    return s;
}

// ---------------------------------------------------------------- thumbnails on the GPU

struct ThumbTexture { unsigned tex = 0; std::uint32_t version = 0; const Asset* asset = nullptr; int triangles = 0; };
std::unordered_map<std::string, ThumbTexture>& thumbCache() { static std::unordered_map<std::string, ThumbTexture> c; return c; }

unsigned thumbnailFor(Application& app, const std::string& name) {
    AssetPtr a = app.assets.get(name);
    if (!a) return 0;
    ThumbTexture& t = thumbCache()[name];
    if (t.tex && t.version == a->version && t.asset == a.get()) return t.tex;
    const Thumbnail img = renderThumbnail(*a, 96);
    if (!t.tex) glGenTextures(1, &t.tex);
    glBindTexture(GL_TEXTURE_2D, t.tex);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, img.size, img.size, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.rgba.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    t.version = a->version; t.asset = a.get(); t.triangles = int(a->mesh.size() / 3);
    return t.tex;
}

// ---------------------------------------------------------------- outliner state

struct OutlinerState {
    std::unordered_set<ObjectId> collapsed;
    std::vector<ObjectId> lastOrder;       // the rows as drawn last frame, for Shift-click ranges
    ObjectId renaming = 0;
    char renameBuf[128] = {};
    bool renameFocus = false;
    char search[64] = {};
};
OutlinerState& outliner() { static OutlinerState s; return s; }

struct PendingDrop { ObjectId dragged = 0, target = 0; int zone = 0; };     // zone: -1 before, 0 into, +1 after

} // namespace

unsigned assetThumbnailTexture(Application& app, const std::string& assetName) { return thumbnailFor(app, assetName); }

void releaseAssetThumbnails() {
    for (auto& [_, t] : thumbCache()) if (t.tex) glDeleteTextures(1, &t.tex);
    thumbCache().clear();
}

// ================================================================ OUTLINER

void Application::drawOutliner() {
    if (!beginPanel("Scene", &showOutliner, settleFront("Scene"))) return;
    const float s = scale();
    OutlinerState& st = outliner();
    const bool filtering = st.search[0] != 0;

    // ---- header: search and quick actions
    {
        const float btn = ImGui::GetFrameHeight();
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - (btn + 6 * s) * 2);
        ImGui::InputTextWithHint("##search", "Search objects", st.search, sizeof st.search);
        ImGui::SameLine(0, 6 * s);
        const ImVec2 p0 = ImGui::GetCursorScreenPos();
        if (ImGui::Button("##newgroup", ImVec2(btn, btn))) {
            glm::vec3 at = camera.position + camera.front() * 8.0f, n;
            findPlacementSpot(at, n);
            SceneObject g; g.name = "Group"; g.position = at;
            const ObjectId id = scene.add(g);
            commitScene("New group");
            selectObject(id);
            st.renaming = id; st.renameFocus = true; std::snprintf(st.renameBuf, sizeof st.renameBuf, "%s", scene.find(id)->name.c_str());
        }
        drawIcon(ImGui::GetWindowDrawList(), Icon::Plus, ImVec2(p0.x + btn * 0.5f, p0.y + btn * 0.5f), btn * 0.5f, col::text);
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("New empty group");
        ImGui::SameLine(0, 6 * s);
        const ImVec2 p1 = ImGui::GetCursorScreenPos();
        ImGui::BeginDisabled(selection.empty());
        if (ImGui::Button("##del", ImVec2(btn, btn))) cmdDeleteSelection();
        drawIcon(ImGui::GetWindowDrawList(), Icon::Trash, ImVec2(p1.x + btn * 0.5f, p1.y + btn * 0.5f), btn * 0.5f, selection.empty() ? col::textDim : col::text);
        ImGui::EndDisabled();
        if (ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled)) ImGui::SetTooltip("Delete the selection  (Del)");
    }

    if (scene.empty()) {
        ImGui::Dummy(ImVec2(0, 18 * s));
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("Nothing placed yet.");
        ImGui::TextDisabled("Pick something on the shelf below, then click in the world to put it there.");
        ImGui::PopTextWrapPos();
        ImGui::End();
        return;
    }

    // children of every object, once per frame
    std::unordered_map<ObjectId, std::vector<ObjectId>> kids;
    std::vector<ObjectId> tops;
    for (const SceneObject& o : scene.objects()) (o.parent ? kids[o.parent] : tops).push_back(o.id);

    PendingDrop drop;
    enum class Act { None, Delete, Duplicate, Group, Ungroup, Focus, Rename } act = Act::None;
    std::vector<ObjectId> order;
    const float rowH = ImGui::GetFrameHeight() + 2 * s;
    const bool windowFocused = ImGui::IsWindowFocused(ImGuiFocusedFlags_RootAndChildWindows);

    ImGui::BeginChild("##rows", ImVec2(0, 0), false);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    auto drawRow = [&](auto&& self, ObjectId id, int depth) -> void {
        const SceneObject* o = scene.find(id);
        if (!o) return;
        const bool hasKids = !filtering && kids.count(id) && !kids[id].empty();
        const bool collapsed = st.collapsed.count(id) > 0;
        const bool sel = isSelected(id);
        order.push_back(id);

        ImGui::PushID(int(id));
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float w = ImGui::GetContentRegionAvail().x;
        ImGui::InvisibleButton("##row", ImVec2(w, rowH));
        const bool hov = ImGui::IsItemHovered();
        const float indent = (filtering ? 0 : depth) * 15 * s;
        const float arrowX = p.x + 4 * s + indent, eyeX = p.x + w - rowH * 2, lockX = p.x + w - rowH;

        if (ImGui::IsItemClicked(0)) {
            const float mx = ImGui::GetMousePos().x;
            if (mx >= lockX) { scene.mutate(id)->locked = !o->locked; commitScene((scene.find(id)->locked ? "Lock " : "Unlock ") + o->name); }
            else if (mx >= eyeX) { scene.mutate(id)->visible = !o->visible; commitScene((scene.find(id)->visible ? "Show " : "Hide ") + o->name); }
            else if (hasKids && mx >= arrowX - 2 * s && mx <= arrowX + 14 * s) { if (collapsed) st.collapsed.erase(id); else st.collapsed.insert(id); }
            else {
                const ImGuiIO& io = ImGui::GetIO();
                if (io.KeyShift && outlinerAnchor && scene.find(outlinerAnchor)) {
                    const auto& prev = st.lastOrder;
                    auto a = std::find(prev.begin(), prev.end(), outlinerAnchor), b = std::find(prev.begin(), prev.end(), id);
                    if (a != prev.end() && b != prev.end()) {
                        if (a > b) std::swap(a, b);
                        std::vector<ObjectId> range(a, b + 1);
                        if (!io.KeyCtrl) setSelection(range);
                        else for (ObjectId r : range) if (!isSelected(r)) selection.push_back(r);
                        selection.erase(std::remove(selection.begin(), selection.end(), id), selection.end());
                        selection.push_back(id);
                    }
                } else if (io.KeyCtrl) { selectObject(id, true); outlinerAnchor = id; }
                else { selectObject(id); outlinerAnchor = id; }
                tool = Tool::Select;
            }
        }
        if (ImGui::IsItemClicked(1) && !sel) { selectObject(id); outlinerAnchor = id; }
        if (hov && ImGui::IsMouseDoubleClicked(0) && ImGui::GetMousePos().x < eyeX) {
            st.renaming = id; st.renameFocus = true;
            std::snprintf(st.renameBuf, sizeof st.renameBuf, "%s", o->name.c_str());
        }

        // drag to re-parent or reorder
        if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
            ObjectId pid = id;
            ImGui::SetDragDropPayload("PX_OBJECT", &pid, sizeof pid);
            ImGui::TextUnformatted(o->name.c_str());
            ImGui::EndDragDropSource();
        }
        int dropZone = 99;
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("PX_OBJECT", ImGuiDragDropFlags_AcceptBeforeDelivery | ImGuiDragDropFlags_AcceptNoDrawDefaultRect)) {
                const ObjectId dragged = *static_cast<const ObjectId*>(pl->Data);
                const float t = (ImGui::GetMousePos().y - p.y) / rowH;
                int zone = t < 0.25f ? -1 : t > 0.75f ? 1 : 0;
                if (filtering) zone = 0;
                const bool legal = dragged != id && !scene.isAncestor(dragged, id);
                if (legal) {
                    dropZone = zone;
                    if (pl->IsDelivery()) drop = { dragged, id, zone };
                }
            }
            ImGui::EndDragDropTarget();
        }

        // look
        if (sel) {
            dl->AddRectFilled(p, ImVec2(p.x + w, p.y + rowH), id == primaryObject() ? withAlpha(col::accent, 0.16f) : withAlpha(col::accent, 0.09f), 4 * s);
            if (id == primaryObject()) dl->AddRectFilled(p, ImVec2(p.x + 2 * s, p.y + rowH), col::accent);
        }
        else if (hov) dl->AddRectFilled(p, ImVec2(p.x + w, p.y + rowH), IM_COL32(255, 255, 255, 12), 4 * s);
        if (dropZone == 0) dl->AddRect(p, ImVec2(p.x + w, p.y + rowH), col::accent, 4 * s, 0, 1.6f * s);
        if (dropZone == -1) dl->AddLine(ImVec2(p.x, p.y), ImVec2(p.x + w, p.y), col::accent, 2.5f * s);
        if (dropZone == 1) dl->AddLine(ImVec2(p.x, p.y + rowH), ImVec2(p.x + w, p.y + rowH), col::accent, 2.5f * s);

        const float cy = p.y + rowH * 0.5f;
        if (hasKids) {
            const ImU32 ac = col::textDim;
            const float ax = arrowX + 5 * s;
            if (collapsed) dl->AddTriangleFilled(ImVec2(ax - 2.5f * s, cy - 4 * s), ImVec2(ax - 2.5f * s, cy + 4 * s), ImVec2(ax + 3.5f * s, cy), ac);
            else dl->AddTriangleFilled(ImVec2(ax - 4 * s, cy - 2.5f * s), ImVec2(ax + 4 * s, cy - 2.5f * s), ImVec2(ax, cy + 3.5f * s), ac);
        }
        const bool dim = !o->visible;
        const ImU32 textCol = dim ? withAlpha(col::textDim, 0.6f) : (sel ? IM_COL32(255, 255, 255, 255) : col::text);
        const float iconX = arrowX + 22 * s;
        drawIcon(dl, o->isGroup() ? Icon::Open : !o->character.empty() ? Icon::User : Icon::Box, ImVec2(iconX, cy), 14 * s, dim ? withAlpha(col::textDim, 0.5f) : sel ? col::accent : IM_COL32(106, 112, 128, 255));
        const float textX = iconX + 14 * s;
        if (st.renaming == id) {
            ImGui::SetCursorScreenPos(ImVec2(textX - 4 * s, p.y));
            ImGui::SetNextItemWidth(std::max(60.0f * s, eyeX - textX - 4 * s));
            if (st.renameFocus) { ImGui::SetKeyboardFocusHere(); st.renameFocus = false; }
            const bool enter = ImGui::InputText("##rename", st.renameBuf, sizeof st.renameBuf, ImGuiInputTextFlags_EnterReturnsTrue | ImGuiInputTextFlags_AutoSelectAll);
            const bool done = enter || ImGui::IsItemDeactivated();
            if (done) {
                if (!ImGui::IsKeyPressed(ImGuiKey_Escape) && st.renameBuf[0] && o->name != st.renameBuf) {
                    scene.mutate(id)->name = scene.uniqueName(st.renameBuf);
                    commitScene("Rename " + o->name);
                }
                st.renaming = 0;
            }
        } else {
            dl->PushClipRect(p, ImVec2(eyeX, p.y + rowH), true);
            dl->AddText(ImVec2(textX, cy - ImGui::GetFontSize() * 0.5f), textCol, o->name.c_str());
            dl->PopClipRect();
        }
        // visibility and lock
        const bool showIcons = hov || !o->visible || o->locked || sel;
        if (showIcons) {
            drawIcon(dl, o->visible ? Icon::Eye : Icon::EyeOff, ImVec2(eyeX + rowH * 0.5f, cy), 13 * s, o->visible ? col::textDim : col::warning);
            if (o->locked || hov) drawIcon(dl, o->locked ? Icon::Lock : Icon::Unlock, ImVec2(lockX + rowH * 0.5f, cy), 13 * s, o->locked ? col::warning : withAlpha(col::textDim, 0.5f));
        }

        // right-click menu
        if (ImGui::BeginPopupContextItem("##ctx")) {
            if (ImGui::MenuItem("Rename", "F2")) act = Act::Rename;
            if (ImGui::MenuItem("Duplicate", "Ctrl+D")) act = Act::Duplicate;
            if (ImGui::MenuItem("Delete", "Del")) act = Act::Delete;
            ImGui::Separator();
            if (ImGui::MenuItem("Group selection", "Ctrl+G")) act = Act::Group;
            if (ImGui::MenuItem("Ungroup", "Ctrl+Shift+G", false, o->isGroup())) act = Act::Ungroup;
            ImGui::Separator();
            if (ImGui::MenuItem("Focus", "F")) act = Act::Focus;
            if (ImGui::MenuItem(o->visible ? "Hide" : "Show")) { scene.mutate(id)->visible = !o->visible; commitScene((scene.find(id)->visible ? "Show " : "Hide ") + o->name); }
            if (ImGui::MenuItem(o->locked ? "Unlock" : "Lock")) { scene.mutate(id)->locked = !o->locked; commitScene((scene.find(id)->locked ? "Lock " : "Unlock ") + o->name); }
            ImGui::EndPopup();
        }
        ImGui::PopID();

        if (hasKids && !collapsed)
            for (ObjectId c : kids[id]) self(self, c, depth + 1);
    };

    if (filtering) {
        for (const SceneObject& o : scene.objects())
            if (containsNoCase(o.name, st.search) || containsNoCase(o.asset, st.search)) drawRow(drawRow, o.id, 0);
        if (order.empty()) { ImGui::Dummy(ImVec2(0, 8 * s)); ImGui::TextDisabled("No object matches."); }
    } else {
        for (ObjectId id : tops) drawRow(drawRow, id, 0);
    }

    // The space below the rows: drop here to take an object out of its group; click to clear the selection.
    {
        const float rest = std::max(24.0f * s, ImGui::GetContentRegionAvail().y);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##empty", ImVec2(-FLT_MIN, rest));
        if (ImGui::IsItemClicked(0)) selectObject(0);
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("PX_OBJECT", ImGuiDragDropFlags_AcceptBeforeDelivery | ImGuiDragDropFlags_AcceptNoDrawDefaultRect)) {
                dl->AddRect(p, ImVec2(p.x + ImGui::GetContentRegionAvail().x, p.y + rest), withAlpha(col::accent, 0.6f), 4 * s, 0, 1.4f * s);
                if (pl->IsDelivery()) drop = { *static_cast<const ObjectId*>(pl->Data), 0, 0 };
            }
            ImGui::EndDragDropTarget();
        }
    }
    ImGui::EndChild();
    st.lastOrder = order;

    // ---- things that change the tree, done once the rows are drawn
    if (drop.dragged) {
        std::vector<ObjectId> moving;
        if (isSelected(drop.dragged)) moving = selectionRoots(); else moving = { drop.dragged };
        bool changed = false;
        std::string name = scene.find(drop.dragged) ? scene.find(drop.dragged)->name : std::string();
        for (ObjectId m : moving) {
            if (!scene.find(m) || m == drop.target) continue;
            if (drop.target == 0) { changed |= scene.setParent(m, 0, true); continue; }
            if (drop.zone == 0) { changed |= scene.setParent(m, drop.target, true); continue; }
            const SceneObject* t = scene.find(drop.target);
            if (!t || !scene.setParent(m, t->parent, true)) continue;
            std::vector<ObjectId> sib = scene.children(t->parent);
            sib.erase(std::remove(sib.begin(), sib.end(), m), sib.end());
            const auto at = std::find(sib.begin(), sib.end(), drop.target);
            scene.moveInOrder(m, int(at - sib.begin()) + (drop.zone > 0 ? 1 : 0));
            changed = true;
        }
        if (changed) commitScene(drop.target == 0 ? "Move " + name + " to the top level" : drop.zone == 0 ? "Put " + name + " into " + scene.find(drop.target)->name : "Reorder " + name);
    }
    if (windowFocused && !ImGui::GetIO().WantTextInput && ImGui::IsKeyPressed(ImGuiKey_F2, false) && primaryObject()) act = Act::Rename;
    switch (act) {
    case Act::Delete: cmdDeleteSelection(); break;
    case Act::Duplicate: cmdDuplicateSelection(); break;
    case Act::Group: cmdGroupSelection(); break;
    case Act::Ungroup: cmdUngroupSelection(); break;
    case Act::Focus: cmdFocusSelection(); break;
    case Act::Rename:
        if (const SceneObject* o = scene.find(primaryObject())) {
            st.renaming = o->id; st.renameFocus = true;
            std::snprintf(st.renameBuf, sizeof st.renameBuf, "%s", o->name.c_str());
        }
        break;
    case Act::None: break;
    }
    ImGui::End();
}

// ================================================================ DETAILS
// What is selected; with nothing selected (or a shaping tool in hand), the tool's own settings. The settings people
// change most are in Essentials; the rest fold away into drawers, each one click deep.

void Application::drawProperties() {
    if (!beginPanel("Details", &showProperties, forceInspectorTab == 0 || settleFront("Details"))) return;
    const float s = scale();
    static std::string editLabel;           // what the pending change is called in the undo list

    SceneObject* o = nullptr;
    if (const SceneObject* c = scene.find(primaryObject())) o = const_cast<SceneObject*>(c);
    if (!o || tool != Tool::Select) {
        drawToolDetails();
        ImGui::End();
        return;
    }
    const ObjectId id = o->id;
    auto edit = [&](const char* what) { editLabel = std::string(what) + " " + o->name; };

    // ---- who: a picture, the name (type to rename), what it is; hide and lock on the right
    {
        ImGui::Dummy(ImVec2(0, 2 * s));
        const float pic = 42 * s;
        const ImVec2 p = ImGui::GetCursorScreenPos();
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(p, ImVec2(p.x + pic, p.y + pic), col::field, 8 * s);
        if (!o->isGroup() && o->character.empty()) {
            if (const unsigned tex = assetThumbnailTexture(*this, o->asset))
                dl->AddImageRounded(texRef(tex), ImVec2(p.x + 1, p.y + 1), ImVec2(p.x + pic - 1, p.y + pic - 1), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 7 * s);
        } else {
            drawIcon(dl, o->isGroup() ? Icon::Open : Icon::User, ImVec2(p.x + pic * 0.5f, p.y + pic * 0.5f), pic * 0.5f, col::textDim);
        }
        dl->AddRect(p, ImVec2(p.x + pic, p.y + pic), col::border, 8 * s);
        ImGui::Dummy(ImVec2(pic, pic));
        ImGui::SameLine(0, 10 * s);
        ImGui::BeginGroup();
        const float iconsW = 2 * 28 * s + 4 * s;
        char buf[128];
        std::snprintf(buf, sizeof buf, "%s", o->name.c_str());
        pushFont(fonts.title);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(0, 0, 0, 0));
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(2 * s, 1 * s));
        ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - iconsW);
        if (ImGui::InputText("##name", buf, sizeof buf, ImGuiInputTextFlags_EnterReturnsTrue) && buf[0]) { edit("Rename"); scene.mutate(id)->name = scene.uniqueName(buf); }
        if (ImGui::IsItemHovered() && !ImGui::IsItemActive()) ImGui::SetTooltip("Click to rename");
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(2);
        popFont();
        pushFont(fonts.small);
        std::string what = o->isGroup() ? std::string("Group") : !o->character.empty() ? std::string("Person") : niceName(o->asset);
        if (const GadgetPreset* g = gadgetFor(o->asset)) what = std::string("Gadget \xC2\xB7 ") + g->label;
        if (selection.size() > 1) what += "  \xC2\xB7  +" + std::to_string(selection.size() - 1) + " more selected";
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 2 * s);
        ImGui::TextDisabled("%s", what.c_str());
        popFont();
        ImGui::EndGroup();
        ImGui::SameLine(ImGui::GetWindowContentRegionMax().x - iconsW + 4 * s);
        ImGui::BeginGroup();
        o = const_cast<SceneObject*>(scene.find(id));
        if (iconButton("##vis", o->visible ? Icon::Eye : Icon::EyeOff, 28 * s, o->visible ? "Hide it" : "Show it", false, o->visible ? 0 : col::warning)) {
            scene.mutate(id)->visible = !o->visible; commitScene((scene.find(id)->visible ? "Show " : "Hide ") + o->name);
        }
        ImGui::SameLine(0, 4 * s);
        o = const_cast<SceneObject*>(scene.find(id));
        if (iconButton("##lock", o->locked ? Icon::Lock : Icon::Unlock, 28 * s, o->locked ? "Unlock it" : "Lock it: the mouse can't pick or move it", false, o->locked ? col::warning : 0)) {
            scene.mutate(id)->locked = !o->locked; commitScene((scene.find(id)->locked ? "Lock " : "Unlock ") + o->name);
        }
        ImGui::EndGroup();
        ImGui::Dummy(ImVec2(0, 6 * s));
    }
    o = const_cast<SceneObject*>(scene.find(id));

    // ---- Essentials: where it is, which way it faces, how big
    if (foldSection("Essentials", true)) {
        if (beginProps("##transform", 64)) {
            prop("Position", o->parent ? "Relative to the group it is in" : "Metres from the world's centre");
            glm::vec3 pos = o->position;
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (axisDrag3("##pos", &pos.x, 0.05f, 0.0f, 0.0f, "%.2f")) { edit("Move"); scene.mutate(id)->position = pos; }
            prop("Turn", "Degrees around each axis: Y turns it, X tilts it, Z rolls it");
            glm::vec3 rot = o->rotation;
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (axisDrag3("##rot", &rot.x, 0.5f, -360.0f, 360.0f, "%.1f")) { edit("Rotate"); scene.mutate(id)->rotation = rot; }
            prop("Size", "1 = the size it was made at");
            float sc = o->scale;
            ImGui::SetNextItemWidth(-FLT_MIN);
            pushFont(fonts.mono);
            if (ImGui::DragFloat("##scale", &sc, 0.01f, 0.05f, 40.0f, "%.2fx", ImGuiSliderFlags_AlwaysClamp)) { edit("Resize"); scene.mutate(id)->scale = sc; }
            popFont();
            endProps();
        }
        ImGui::Dummy(ImVec2(0, 2 * s));
        const float w = (ImGui::GetContentRegionAvail().x - 6 * s) * 0.5f;
        if (ImGui::Button("Drop to ground", ImVec2(w, 0))) cmdDropToGround();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Move it straight down onto the ground below");
        ImGui::SameLine(0, 6 * s);
        if (ImGui::Button("Reset turn and size", ImVec2(-FLT_MIN, 0))) {
            SceneObject* m = scene.mutate(id);
            m->rotation = glm::vec3(0.0f); m->scale = 1.0f;
            commitScene("Reset " + m->name);
        }
        if (blueprintBuildingOf(id)) {
            if (ImGui::Button("Edit the floor plan", ImVec2(-FLT_MIN, 0))) editBuildingBlueprint(id);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Change the plan and rebuild it in the same place.");
        }
        if (!o->character.empty()) {
            const std::string who = o->character;
            if (ImGui::Button(("Edit " + characters.get(who).name + " in the Character Studio").c_str(), ImVec2(-FLT_MIN, 0))) openCharacterStudio(who);
            if (playerCharacter != who) { if (ImGui::Button("Play as them", ImVec2(-FLT_MIN, 0))) setPlayerCharacter(who); }
        } else if (!o->isGroup()) {
            if (ImGui::Button(assets.isUserMade(o->asset) ? "Edit in the Asset Workshop" : "Make my own version in the Workshop", ImVec2(-FLT_MIN, 0))) editAssetInWorkshop(o->asset);
        }
        ImGui::Dummy(ImVec2(0, 4 * s));
    }
    o = const_cast<SceneObject*>(scene.find(id));
    if (!o) { ImGui::End(); return; }

    // ---- Behaviour (people), Rules, Motion, Options, About: drawers
    if (!o->character.empty()) {
        if (foldSection("Behaviour", true, o->npc.empty() ? "Stands still" : "Has a life")) drawNpcPanel(id);
        o = const_cast<SceneObject*>(scene.find(id));
        if (!o) { ImGui::End(); return; }
    }
    if (!o->isGroup() || !o->rules.empty()) {
        if (openRulesFold) { ImGui::GetStateStorage()->SetBool(ImGui::GetID("Rules"), true); openRulesFold = false; }
        const RuleSet* rs = rulesOf(id);
        const size_t n = rs ? rs->rules.size() : 0;
        const std::string summary = n == 0 ? std::string("None yet") : n == 1 ? std::string("1 rule") : std::to_string(n) + " rules";
        if (foldSection("Rules", n > 0, summary.c_str())) drawRulesPanel(id);
        o = const_cast<SceneObject*>(scene.find(id));
        if (!o) { ImGui::End(); return; }
    }
    if (foldSection("Motion", false, motionName(o->motion.kind))) {
        if (beginProps("##motion")) {
            MotionSettings m = o->motion;
            prop("Moves", "Played in Play mode, or with Motion on over the view");
            ImGui::SetNextItemWidth(-FLT_MIN);
            const char* current = motionName(m.kind);
            if (ImGui::BeginCombo("##kind", current)) {
                for (int k = 0; k <= int(MotionSettings::Kind::Slide); ++k) {
                    const auto kind = MotionSettings::Kind(k);
                    if (ImGui::Selectable(motionName(kind), kind == m.kind)) {
                        m.kind = kind;
                        if (kind == MotionSettings::Kind::Spin) { m.speed = 45.0f; m.axis = glm::vec3(0, 1, 0); }
                        if (kind == MotionSettings::Kind::Bob) { m.speed = 0.5f; m.amount = 0.5f; m.axis = glm::vec3(0, 1, 0); }
                        if (kind == MotionSettings::Kind::Sway) { m.speed = 0.4f; m.amount = 8.0f; m.axis = glm::vec3(0, 0, 1); }
                        if (kind == MotionSettings::Kind::Slide) { m.speed = 0.25f; m.amount = 4.0f; m.axis = glm::vec3(1, 0, 0); }
                        scene.mutate(id)->motion = m;
                        commitScene("Motion for " + o->name);
                    }
                }
                ImGui::EndCombo();
            }
            if (m.kind != MotionSettings::Kind::None) {
                const bool spin = m.kind == MotionSettings::Kind::Spin;
                prop(spin ? "Around" : m.kind == MotionSettings::Kind::Sway ? "Tilts around" : "Direction", "Relative to the object");
                ImGui::SetNextItemWidth(-FLT_MIN);
                if (axisDrag3("##maxis", &m.axis.x, 0.02f, -1.0f, 1.0f, "%.2f")) { edit("Motion axis of"); scene.mutate(id)->motion = m; }
                prop(spin ? "Speed" : "Cycles per second", spin ? "Degrees per second" : nullptr);
                ImGui::SetNextItemWidth(-FLT_MIN);
                if (ImGui::DragFloat("##mspeed", &m.speed, spin ? 1.0f : 0.01f, spin ? -720.0f : 0.02f, spin ? 720.0f : 4.0f, spin ? "%.0f deg/s" : "%.2f /s")) { edit("Motion speed of"); scene.mutate(id)->motion = m; }
                if (!spin) {
                    prop(m.kind == MotionSettings::Kind::Sway ? "Angle" : "Distance");
                    ImGui::SetNextItemWidth(-FLT_MIN);
                    if (ImGui::DragFloat("##mamount", &m.amount, 0.05f, 0.0f, m.kind == MotionSettings::Kind::Sway ? 90.0f : 40.0f, m.kind == MotionSettings::Kind::Sway ? "%.1f deg" : "%.2f m")) { edit("Motion size of"); scene.mutate(id)->motion = m; }
                }
                prop("Head start", "Offsets the cycle so neighbours don't move in step");
                ImGui::SetNextItemWidth(-FLT_MIN);
                if (ImGui::SliderFloat("##mphase", &m.phase, 0.0f, 1.0f, "%.2f")) { edit("Motion offset of"); scene.mutate(id)->motion = m; }
            }
            endProps();
        }
        if (o->motion.kind != MotionSettings::Kind::None) {
            if (ImGui::Checkbox("Preview motion", &previewMotion)) sceneClock = 0.0;
        }
    }
    {
        std::string summary = std::string(o->solid ? "Solid" : "Passable") + (o->visible ? "" : " \xC2\xB7 hidden") + (o->locked ? " \xC2\xB7 locked" : "");
        if (foldSection("Options", false, summary.c_str()) && beginProps("##options")) {
            auto flag = [&](const char* label, const char* tip, bool SceneObject::*field, const char* verbOn, const char* verbOff) {
                prop(label, tip);
                bool v = o->*field;
                if (ImGui::Checkbox((std::string("##") + label).c_str(), &v)) {
                    for (ObjectId sid : selection) if (scene.find(sid)) scene.mutate(sid)->*field = v;
                    commitScene(std::string(v ? verbOn : verbOff) + " " + o->name);
                }
            };
            flag("Visible", "Hidden objects are not drawn and are not solid", &SceneObject::visible, "Show", "Hide");
            flag("Locked", "A locked object can't be picked or moved with the mouse", &SceneObject::locked, "Lock", "Unlock");
            flag("Solid", "Characters walk on it and bump into it", &SceneObject::solid, "Make solid", "Make passable");
            endProps();
        }
    }
    if (AssetPtr a = o->isGroup() ? nullptr : assets.get(o->asset)) {
        char summary[64];
        std::snprintf(summary, sizeof summary, "%.1f x %.1f x %.1f m", double(a->extent().x), double(a->extent().y), double(a->extent().z));
        if (foldSection("About", false, summary)) {
            pushFont(fonts.small);
            ImGui::TextDisabled("Made at %.1f x %.1f x %.1f m,  %d triangles", double(a->extent().x), double(a->extent().y), double(a->extent().z), int(a->mesh.size() / 3));
            ImGui::TextDisabled("Asset: %s", o->asset.c_str());
            popFont();
        }
    }

    // A change made with a drag or typing becomes one undo step when the widget is let go.
    if (!editLabel.empty() && !ImGui::IsAnyItemActive() && !gizmo.dragging()) {
        commitScene(editLabel);
        editLabel.clear();
    }
    ImGui::End();
}

// ================================================================ the Select tool with nothing selected

void Application::drawObjectsToolSection() {
    const float s = scale();
    ImGui::Dummy(ImVec2(0, 4 * s));
    ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
    if (!placingAsset.empty()) {
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::accent), "Placing %s", niceName(placingAsset).c_str());
        ImGui::TextDisabled("Click in the world to put it there. The mouse wheel turns it, Shift + wheel resizes it.");
        if (ImGui::Button("Stop placing  (Esc)")) stopPlacing();
    } else {
        ImGui::TextDisabled("Click something in the world to select it (Ctrl or Shift adds more). Its details show here.");
        ImGui::Dummy(ImVec2(0, 4 * s));
        ImGui::TextDisabled("To put something new in the world, pick it on the shelf below.");
    }
    ImGui::PopTextWrapPos();
}

} // namespace px
