// The Asset Workshop screen: menu bar, tool rail, side panel, status bar, dialogs and the overlay
// drawn over the 3D view (floor grid, the ghost of the shape under the cursor, mirror planes,
// sockets). Behaviour is in editor/WorkshopTools.cpp.
#include "workshop/KitPieces.h"
#include "core/Application.h"
#include "editor/Panels.h"
#include "editor/WorkshopCommon.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <glm/gtc/constants.hpp>

namespace px {

using namespace ui;
using namespace wsui;

namespace {

float gMenuH = 30.0f;     // height of the menu bar, measured while it is drawn

Icon toolIcon(WTool t) {
    switch (t) {
    case WTool::Add: return Icon::Build;
    case WTool::Carve: return Icon::Carve;
    case WTool::Paint: return Icon::Paint;
    case WTool::Smooth: return Icon::Smooth;
    case WTool::Socket: return Icon::Pin;
    case WTool::Count: break;
    }
    return Icon::Build;
}

std::string cm(float metres) {
    char b[32];
    const float c = metres * 100.0f;
    if (c >= 100.0f) std::snprintf(b, sizeof b, "%.2f m", double(metres));
    else if (c >= 10.0f) std::snprintf(b, sizeof b, "%.0f cm", double(c));
    else std::snprintf(b, sizeof b, "%.1f cm", double(c));
    return b;
}

// A toggle button that lights up when on.
bool toggleButton(const char* label, bool on, ImVec2 size = ImVec2(0, 0)) {
    ImGui::PushStyleColor(ImGuiCol_Button, on ? col::accentDim : col::panelAlt);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, on ? withAlpha(col::accent, 0.35f) : IM_COL32(35, 39, 51, 255));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, withAlpha(col::accent, 0.5f));
    ImGui::PushStyleColor(ImGuiCol_Text, on ? IM_COL32(255, 255, 255, 255) : col::textDim);
    if (on) { ImGui::PushStyleColor(ImGuiCol_Border, col::accent); ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.5f * scale()); }
    const bool r = ImGui::Button(label, size);
    if (on) { ImGui::PopStyleVar(); ImGui::PopStyleColor(); }
    ImGui::PopStyleColor(4);
    return r;
}

// A button with a small picture of a shape on it.
bool shapeButton(Shape sh, bool selected, ImVec2 size) {
    ImGui::PushID(int(sh));
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton("##shape", size);
    const bool hov = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float s = scale();
    const ImVec2 q(p.x + size.x, p.y + size.y);
    dl->AddRectFilled(p, q, selected ? col::accentDim : (hov ? IM_COL32(35, 39, 51, 255) : col::panelAlt), 6 * s);
    if (selected) dl->AddRect(p, q, col::accent, 6 * s, 0, 1.5f * s);
    const ImU32 c = selected ? IM_COL32(255, 255, 255, 255) : (hov ? col::text : col::textDim);
    const float r = size.x * 0.2f, th = 1.6f * s;
    const ImVec2 m(p.x + size.x * 0.5f, p.y + size.y * 0.42f);
    auto ellipse = [&](ImVec2 at, float rx, float ry) {
        for (int i = 0; i <= 20; ++i) {
            const float t = float(i) / 20.0f * glm::two_pi<float>();
            dl->PathLineTo(ImVec2(at.x + std::cos(t) * rx, at.y + std::sin(t) * ry));
        }
        dl->PathStroke(c, 0, th);
    };
    switch (sh) {
    case Shape::Box: dl->AddRect(ImVec2(m.x - r, m.y - r), ImVec2(m.x + r, m.y + r), c, 1.5f * s, 0, th); break;
    case Shape::Sphere: dl->AddCircle(m, r * 1.1f, c, 24, th); break;
    case Shape::Cylinder:
        ellipse(ImVec2(m.x, m.y - r * 0.8f), r, r * 0.4f);
        ellipse(ImVec2(m.x, m.y + r * 0.8f), r, r * 0.4f);
        dl->AddLine(ImVec2(m.x - r, m.y - r * 0.8f), ImVec2(m.x - r, m.y + r * 0.8f), c, th);
        dl->AddLine(ImVec2(m.x + r, m.y - r * 0.8f), ImVec2(m.x + r, m.y + r * 0.8f), c, th);
        break;
    case Shape::Cone:
        ellipse(ImVec2(m.x, m.y + r * 0.8f), r, r * 0.4f);
        dl->AddLine(ImVec2(m.x - r, m.y + r * 0.8f), ImVec2(m.x, m.y - r * 1.1f), c, th);
        dl->AddLine(ImVec2(m.x + r, m.y + r * 0.8f), ImVec2(m.x, m.y - r * 1.1f), c, th);
        break;
    case Shape::Wedge:
        dl->AddTriangle(ImVec2(m.x - r, m.y + r), ImVec2(m.x - r, m.y - r), ImVec2(m.x + r, m.y + r), c, th);
        break;
    }
    pushFont(fonts.small);
    const char* label = shapeLabel(sh);
    const float tw = ImGui::CalcTextSize(label).x;
    dl->AddText(ImVec2(p.x + (size.x - tw) * 0.5f, p.y + size.y * 0.74f), selected ? col::text : col::textDim, label);
    popFont();
    if (hov) ImGui::SetTooltip("%s", shapeLabel(sh));
    ImGui::PopID();
    return pressed;
}

const char* kDetailName[] = { "Chunky", "Normal", "Fine", "Very fine", "Tiny details" };
const float kDetailSize[] = { 0.5f, 0.25f, 0.125f, 0.0625f, 0.03125f };

} // namespace

// ================================================================ menu bar

void Application::drawWorkshopMenuBar() {
    const float s = scale();
    const bool have = ws.model.asset.valid();
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10 * s, 7 * s));
    if (ImGui::BeginMainMenuBar()) {
        gMenuH = ImGui::GetWindowHeight();
        screenHeader("Asset Workshop");

        if (ImGui::BeginMenu("File")) {
            if (ImGui::MenuItem("New Asset...")) workshopLeaveWith("new");
            ImGui::Separator();
            if (ImGui::MenuItem("Save", "Ctrl+S", false, have)) workshopSave();
            if (ImGui::MenuItem("Save and Place in the World", "Ctrl+Shift+S", false, have)) workshopSaveAndPlace();
            ImGui::Separator();
            if (ImGui::MenuItem("Close Workshop")) requestLeaveWorkshop();
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Edit")) {
            const std::string u = ws.model.undoLabel(), r = ws.model.redoLabel();
            if (ImGui::MenuItem(u.empty() ? "Undo" : ("Undo " + u).c_str(), "Ctrl+Z", false, ws.model.canUndo())) workshopUndo();
            if (ImGui::MenuItem(r.empty() ? "Redo" : ("Redo " + r).c_str(), "Ctrl+Y", false, ws.model.canRedo())) workshopRedo();
            ImGui::Separator();
            if (ImGui::BeginMenu("Mirror")) {
                ImGui::MenuItem("Across the middle, left / right (X)", "X", &ws.mirror.x);
                ImGui::MenuItem("Across the middle, up / down (Y)", "Y", &ws.mirror.y);
                ImGui::MenuItem("Across the middle, front / back (Z)", "Z", &ws.mirror.z);
                ImGui::EndMenu();
            }
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Tools")) {
            for (int i = 0; i < int(WTool::Count); ++i)
                if (ImGui::MenuItem(toolName(WTool(i)), toolKey(WTool(i)), ws.tool == WTool(i), have)) workshopSetTool(WTool(i));
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("View")) {
            if (ImGui::MenuItem("Frame the Model", "F", false, have)) workshopFrame();
            ImGui::Separator();
            ImGui::MenuItem("Floor Grid", "G", &ws.showGrid);
            ImGui::MenuItem("Work Area Box", nullptr, &ws.showBounds);
            ImGui::MenuItem("Person for Scale", nullptr, &ws.showFigure);
            ImGui::MenuItem("Wireframe", nullptr, &ws.wireframe);
            ImGui::Separator();
            ImGui::MenuItem("Shortcut Hints", "F1", &showHints);
            ImGui::EndMenu();
        }

        // Right side: Save and Done
        const float bh = ImGui::GetFontSize() + 8 * s;
        const float doneW = ImGui::CalcTextSize("Done").x + 38 * s;
        const float saveW = ImGui::CalcTextSize("Save").x + 34 * s;
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - doneW - saveW - 24 * s);
        ImGui::SetCursorPosY((ImGui::GetWindowHeight() - bh) * 0.5f);
        ImGui::BeginDisabled(!have);
        const bool modified = have && workshopModified();
        if (ImGui::Button(modified ? "Save *" : "Save", ImVec2(saveW + (modified ? 10 * s : 0), bh))) workshopSave();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Save this asset so it can be placed in worlds  (Ctrl+S)");
        ImGui::EndDisabled();
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - doneW - 12 * s);
        ImGui::SetCursorPosY((ImGui::GetWindowHeight() - bh) * 0.5f);
        if (primaryButton("Done", ImVec2(doneW, bh))) requestLeaveWorkshop();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Back to the world");
        ImGui::EndMainMenuBar();
    }
    ImGui::PopStyleVar();
}

// ================================================================ tool rail

void Application::drawWorkshopRail(float top, float bottom) {
    const float s = scale();
    const float railW = 58 * s;
    ImGui::SetNextWindowPos(ImVec2(0, top));
    ImGui::SetNextWindowSize(ImVec2(railW, bottom - top));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(7 * s, 10 * s));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 6 * s));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, col::bg);
    if (ImGui::Begin("##wsrail", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                                              ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus)) {
        const float b = std::max(30.0f * s, ImGui::GetContentRegionAvail().x);
        const bool have = ws.model.asset.valid();
        ImGui::BeginDisabled(!have || ws.rangeOn);
        for (int i = 0; i < int(WTool::Count); ++i) {
            const WTool t = WTool(i);
            if (toolButton(toolName(t), toolIcon(t), ws.tool == t, b, toolName(t), toolKey(t))) workshopSetTool(t);
        }
        ImGui::Dummy(ImVec2(0, 8 * s));
        ImGui::Separator();
        ImGui::Dummy(ImVec2(0, 4 * s));
        ImGui::BeginDisabled(!ws.model.canUndo());
        if (toolButton("Undo", Icon::Undo, false, b, "Undo", "Ctrl+Z")) workshopUndo();
        ImGui::EndDisabled();
        ImGui::BeginDisabled(!ws.model.canRedo());
        if (toolButton("Redo", Icon::Redo, false, b, "Redo", "Ctrl+Y")) workshopRedo();
        ImGui::EndDisabled();
        ImGui::EndDisabled();
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(3);
}

// ================================================================ side panel

void Application::drawWorkshopPanel(float top, float bottom) {
    const float s = scale();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const float w = 330 * s;
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x - w, top));
    ImGui::SetNextWindowSize(ImVec2(w, bottom - top));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(14 * s, 10 * s));
    if (!ImGui::Begin("##wspanel", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                                ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus)) {
        ImGui::End();
        ImGui::PopStyleVar(2);
        return;
    }
    if (!ws.model.asset.valid()) {
        ImGui::Dummy(ImVec2(0, 20 * s));
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("Choose what to make in the New Asset window.");
        ImGui::PopTextWrapPos();
        ImGui::End();
        ImGui::PopStyleVar(2);
        return;
    }
    Asset& a = ws.model.asset;

    // ---- the asset
    section("Asset");
    if (beginProps("##asset", 96)) {
        prop("Name", "What it is called in the Assets panel. Saving with a new name makes a new asset.");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::InputText("##name", ws.nameBuf, sizeof ws.nameBuf)) ws.model.setName(ws.nameBuf);
        prop("Type", "What kind of thing it is. Games use this to decide where it can go.");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##type", assetTypeName(a.type))) {
            for (int t = 0; t < kAssetTypeCount; ++t)
                if (ImGui::Selectable(assetTypeName(AssetType(t)), a.type == AssetType(t))) ws.model.setType(AssetType(t));
            ImGui::EndCombo();
        }
        prop("Tags", "Words to find it by, separated by commas");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::InputText("##tags", ws.tagBuf, sizeof ws.tagBuf)) {
            std::vector<std::string> tags;
            std::string cur;
            for (const char* p = ws.tagBuf;; ++p) {
                if (*p == ',' || *p == 0) {
                    size_t b = cur.find_first_not_of(' '), e = cur.find_last_not_of(' ');
                    if (b != std::string::npos) tags.push_back(cur.substr(b, e - b + 1));
                    cur.clear();
                    if (!*p) break;
                } else cur += *p;
            }
            ws.model.setTags(tags);
        }
        endProps();
    }
    {
        std::string why;
        pushFont(fonts.small);
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        if (workshopNameProblem(&why)) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::danger), "%s", why.c_str());
        else if (a.name != ws.originalName && assets.get(a.name)) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "Saving will replace your asset '%s'.", a.name.c_str());
        else if (ws.copyOfBuiltin) ImGui::TextDisabled("A copy of a built-in asset. Saving keeps it as your own.");
        ImGui::PopTextWrapPos();
        popFont();

        static std::uint64_t cachedRev = ~0ull; static const Asset* cachedFor = nullptr; static size_t cachedSolid = 0;
        if (cachedRev != ws.model.revision() || cachedFor != &a) { cachedSolid = ws.model.solidVoxels(); cachedRev = ws.model.revision(); cachedFor = &a; }
        const glm::vec3 ext = a.mesh.empty() ? glm::vec3(0.0f) : a.extent();
        pushFont(fonts.small);
        ImGui::TextDisabled("Size  %s x %s x %s", cm(ext.x).c_str(), cm(ext.y).c_str(), cm(ext.z).c_str());
        ImGui::TextDisabled("Voxels  %s   (%d x %d x %d)", cm(a.voxelSize).c_str(), a.size.x, a.size.y, a.size.z);
        ImGui::TextDisabled("%zu solid voxels   %zu triangles", cachedSolid, a.mesh.size() / 3);
        popFont();
    }

    // ---- things that are items get a second tab: the Item Builder
    if (a.type == AssetType::Item) {
        ImGui::Dummy(ImVec2(0, 4 * s));
        const float gap = 6 * s, bw = (ImGui::GetContentRegionAvail().x - gap) * 0.5f;
        if (toggleButton("Model", ws.panelTab == 0, ImVec2(bw, 0))) { if (ws.rangeOn) workshopLeaveRange(); ws.panelTab = 0; }
        ImGui::SameLine(0, gap);
        if (toggleButton("Item", ws.panelTab == 1, ImVec2(bw, 0))) ws.panelTab = 1;
        if (ws.panelTab == 1) {
            drawWorkshopItemPanel();
            ImGui::End();
            ImGui::PopStyleVar(2);
            return;
        }
    } else {
        if (ws.rangeOn) workshopLeaveRange();
        ws.panelTab = 0;
    }

    // ---- the current tool
    const WTool tl = ws.tool;
    section(toolName(tl));
    if (tl != WTool::Socket) {
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("%s", toolBlurb(tl));
        ImGui::PopTextWrapPos();
        ImGui::Dummy(ImVec2(0, 2 * s));
    }
    float lo, hi;
    workshopSizeRange(lo, hi);

    if (tl == WTool::Add || tl == WTool::Carve || tl == WTool::Paint) {
        const float gap = 6 * s;
        const float bw = (ImGui::GetContentRegionAvail().x - gap * 4) / 5.0f;
        for (int i = 0; i < kShapeCount; ++i) {
            if (i) ImGui::SameLine(0, gap);
            if (shapeButton(Shape(i), ws.shape == Shape(i), ImVec2(bw, bw * 1.15f))) ws.shape = Shape(i);
        }
        ImGui::Dummy(ImVec2(0, 4 * s));
        if (beginProps("##brush", 96)) {
            const char* axisName[3] = { "Width", "Height", "Depth" };
            for (int i = 0; i < 3; ++i) {
                prop(axisName[i], i == 0 ? "Shift+mouse wheel or [ ] change all three at once" : nullptr);
                ImGui::SetNextItemWidth(-FLT_MIN);
                float v = ws.size[i];
                const float before = v;
                ImGui::PushID(i);
                if (sliderFloatLog("##size", &v, lo, hi, "%.3f m")) {
                    ws.size[i] = v;
                    if (ws.linkSize && before > 0.0f) {
                        const float f = v / before;
                        for (int j = 0; j < 3; ++j) if (j != i) ws.size[j] = std::clamp(ws.size[j] * f, lo, hi);
                    }
                }
                ImGui::PopID();
            }
            prop("Keep shape", "Resize width, height and depth together");
            ImGui::Checkbox("##link", &ws.linkSize);
            if (tl != WTool::Paint) {
                if (ws.shape != Shape::Sphere) {
                    prop("Rounded edges", "Rounds the shape's corners");
                    ImGui::SetNextItemWidth(-FLT_MIN);
                    const float maxRound = std::min(ws.size.x, std::min(ws.size.y, ws.size.z)) * 0.5f;
                    ws.round = std::min(ws.round, maxRound);
                    sliderFloat("##round", &ws.round, 0.0f, std::max(maxRound, 0.001f), "%.3f m");
                }
                prop("Soft blend", "How smoothly it melts into what is already there");
                ImGui::SetNextItemWidth(-FLT_MIN);
                sliderFloat("##blend", &ws.blend, 0.0f, std::max(ws.size.x, std::max(ws.size.y, ws.size.z)) * 0.5f, "%.3f m");
            }
            prop("Turn", "Spin the shape around the up axis.  R / Shift+R, or Ctrl+mouse wheel");
            ImGui::SetNextItemWidth(-FLT_MIN);
            sliderFloat("##yaw", &ws.yaw, 0.0f, 360.0f, "%.0f deg");
            prop("Snap", "Place shapes on a grid so edges line up");
            ImGui::Checkbox("##snap", &ws.snap);
            if (ws.snap) {
                ImGui::SameLine();
                ImGui::SetNextItemWidth(-FLT_MIN);
                char fmt[40];
                std::snprintf(fmt, sizeof fmt, "%%d voxels = %s", cm(a.voxelSize * float(ws.snapVoxels)).c_str());
                sliderInt("##snapv", &ws.snapVoxels, 1, 16, fmt);
            }
            if (tl == WTool::Paint) {
                prop("Fill patch", "Recolour a whole connected patch in one click. Hold Shift to do this just once.");
                ImGui::Checkbox("##fill", &ws.paintFill);
            }
            endProps();
        }
    } else if (tl == WTool::Smooth) {
        if (beginProps("##smooth", 96)) {
            prop("Radius", "Shift+mouse wheel or [ ] change it");
            ImGui::SetNextItemWidth(-FLT_MIN);
            sliderFloatLog("##sr", &ws.smoothRadius, lo, hi * 0.5f, "%.3f m");
            prop("Strength");
            ImGui::SetNextItemWidth(-FLT_MIN);
            sliderFloat("##ss", &ws.smoothStrength, 0.05f, 1.0f, "%.2f");
            endProps();
        }
    } else {
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("Mark where things attach: a grip, a muzzle, a seat. Click the model to put a socket there, drag one to move it. Games find sockets by name.");
        ImGui::PopTextWrapPos();
    }

    // ---- material
    if (tl == WTool::Add || tl == WTool::Paint) {
        section("Material");
        materialPalette(renderer, ws.material, false);
    }

    // ---- mirror
    section("Mirror");
    {
        const float gap = 6 * s;
        const float bw = (ImGui::GetContentRegionAvail().x - gap * 2) / 3.0f;
        pushFont(fonts.small);
        if (toggleButton("Left / right", ws.mirror.x, ImVec2(bw, 0))) ws.mirror.x = !ws.mirror.x;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Mirror left / right  (X)");
        ImGui::SameLine(0, gap);
        if (toggleButton("Up / down", ws.mirror.y, ImVec2(bw, 0))) ws.mirror.y = !ws.mirror.y;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Mirror up / down  (Y)");
        ImGui::SameLine(0, gap);
        if (toggleButton("Front / back", ws.mirror.z, ImVec2(bw, 0))) ws.mirror.z = !ws.mirror.z;
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Mirror front / back  (Z)");
        popFont();
        pushFont(fonts.small);
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled(ws.mirror.any() ? "Everything you do is copied across the model's middle." : "Switch one on and every edit is copied across the model's middle.");
        ImGui::PopTextWrapPos();
        popFont();
    }

    // ---- sockets
    section("Sockets");
    {
        if (a.sockets.empty()) {
            ImGui::TextDisabled("None yet. Use the Socket tool (5).");
        }
        for (const Socket& sk : a.sockets) {
            ImGui::PushID(sk.name.c_str());
            const bool sel = sk.name == ws.selectedSocket;
            if (ImGui::Selectable(sk.name.c_str(), sel, 0, ImVec2(0, 0))) { ws.selectedSocket = sk.name; }
            ImGui::PopID();
        }
        if (const Socket* sk = ws.model.findSocket(ws.selectedSocket)) {
            ImGui::Dummy(ImVec2(0, 4 * s));
            static char renameBuf[64]; static std::string renameFor;
            if (renameFor != sk->name) { std::snprintf(renameBuf, sizeof renameBuf, "%s", sk->name.c_str()); renameFor = sk->name; }
            if (beginProps("##socket", 96)) {
                prop("Name", "Press Enter to rename");
                ImGui::SetNextItemWidth(-FLT_MIN);
                if (ImGui::InputText("##sname", renameBuf, sizeof renameBuf, ImGuiInputTextFlags_EnterReturnsTrue) && renameBuf[0]) {
                    if (ws.model.renameSocket(sk->name, renameBuf)) { ws.selectedSocket = renameBuf; renameFor = renameBuf; }
                    else toast("There is already a socket with that name", Toast::Kind::Warning);
                }
                endProps();
            }
            ImGui::TextDisabled("Points");
            {
                const Socket sc = *sk;
                const struct { const char* n; glm::vec3 d; } dirs[] = { { "Up", { 0, 1, 0 } }, { "Front", { 0, 0, 1 } }, { "Right", { 1, 0, 0 } },
                                                                          { "Down", { 0, -1, 0 } }, { "Back", { 0, 0, -1 } }, { "Left", { -1, 0, 0 } } };
                const float gap = 4 * s;
                const float bw = (ImGui::GetContentRegionAvail().x - gap * 2) / 3.0f;
                for (int i = 0; i < 6; ++i) {
                    if (i % 3) ImGui::SameLine(0, gap);
                    ImGui::PushID(i);
                    if (toggleButton(dirs[i].n, glm::dot(sc.direction, dirs[i].d) > 0.98f, ImVec2(bw, 0))) ws.model.moveSocket(sc.name, sc.position, dirs[i].d);
                    ImGui::PopID();
                }
            }
            ImGui::Dummy(ImVec2(0, 2 * s));
            if (dangerButton("Delete socket")) { ws.model.removeSocket(ws.selectedSocket); ws.selectedSocket.clear(); }
        }
    }

    // ---- view
    section("View");
    if (beginProps("##view", 96)) {
        prop("Light", "Time of day for the light in this window. It doesn't change the world.");
        ImGui::SetNextItemWidth(-FLT_MIN);
        char fmt[24];
        const int mins = int(ws.lightTime * 60.0f) % (24 * 60);
        std::snprintf(fmt, sizeof fmt, "%02d:%02d", mins / 60, mins % 60);
        sliderFloat("##light", &ws.lightTime, 6.5f, 19.5f, fmt);
        endProps();
    }
    ImGui::Checkbox("Floor grid", &ws.showGrid); ImGui::SameLine(0, 14 * s);
    ImGui::Checkbox("Work area", &ws.showBounds);
    ImGui::Checkbox("Person for scale", &ws.showFigure); ImGui::SameLine(0, 14 * s);
    ImGui::Checkbox("Wireframe", &ws.wireframe);
    ImGui::Dummy(ImVec2(0, 4 * s));
    if (ImGui::Button("Frame the model", ImVec2(-FLT_MIN, 0))) workshopFrame();
    ImGui::Dummy(ImVec2(0, 12 * s));

    ImGui::End();
    ImGui::PopStyleVar(2);
}

// ================================================================ status bar

void Application::drawWorkshopStatus(float y, float height) {
    const float s = scale();
    const ImGuiIO& io = ImGui::GetIO();
    ImGui::SetNextWindowPos(ImVec2(0, y));
    ImGui::SetNextWindowSize(ImVec2(io.DisplaySize.x, height));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10 * s, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, col::bg);
    if (ImGui::Begin("##wsstatus", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                                                ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoScrollbar)) {
        ImGui::SetCursorPosY((height - ImGui::GetFrameHeight()) * 0.5f);
        pill("WORKSHOP", col::accentDim, col::accent);
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        if (ws.model.asset.valid()) {
            ImGui::TextUnformatted(ws.model.asset.name.c_str());
            if (workshopModified()) { ImGui::SameLine(0, 4 * s); ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "*"); }
            ImGui::SameLine();
            ImGui::TextDisabled("|  %s", ws.rangeOn ? "Firing range" : toolName(ws.tool));
        }
        ImGui::SameLine();
        ImGui::TextDisabled("|");
        ImGui::SameLine();
        ImGui::TextUnformatted(status.c_str());

        char right[160];
        if (ws.hoverValid) std::snprintf(right, sizeof right, "%.0f FPS     %s, %s, %s", io.Framerate, cm(ws.hover.point.x).c_str(), cm(ws.hover.point.y).c_str(), cm(ws.hover.point.z).c_str());
        else std::snprintf(right, sizeof right, "%.0f FPS", io.Framerate);
        const float rw = ImGui::CalcTextSize(right).x;
        ImGui::SameLine(ImGui::GetWindowWidth() - rw - 14 * s);
        ImGui::TextDisabled("%s", right);
    }
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar(3);
}

// ================================================================ dialogs

void Application::drawWorkshopDialogs() {
    const float s = scale();
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const ImVec2 centre(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.5f);

    // ---------------- new asset
    static bool newWasOpen = false;
    static char dlgName[96] = "New asset";
    if (ws.askNew) {
        if (!newWasOpen) { std::snprintf(dlgName, sizeof dlgName, "%s", ws.nameBuf[0] ? ws.nameBuf : "New asset"); newWasOpen = true; }
        if (!ImGui::IsPopupOpen("New asset")) ImGui::OpenPopup("New asset");
    } else newWasOpen = false;
    ImGui::SetNextWindowPos(centre, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(640 * s, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(20 * s, 16 * s));
    if (ImGui::BeginPopupModal("New asset", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize)) {
        if (!ws.askNew) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); ImGui::PopStyleVar(); return; }
        pushFont(fonts.title); ImGui::TextUnformatted("New asset"); popFont();
        ImGui::TextDisabled("Pick a starting point. You can change everything afterwards except the level of detail.");
        ImGui::Dummy(ImVec2(0, 6 * s));

        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted("Name");
        ImGui::SameLine(70 * s);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        ImGui::InputText("##newname", dlgName, sizeof dlgName);
        ImGui::Dummy(ImVec2(0, 6 * s));

        const int count = int(WorkshopTemplate::Count);
        const int cols = 3;
        const float gap = 8 * s;
        const float cw = (ImGui::GetContentRegionAvail().x - gap * (cols - 1)) / cols;
        const float ch = 92 * s;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        for (int i = 0; i < count; ++i) {
            if (i % cols) ImGui::SameLine(0, gap);
            ImGui::PushID(i);
            const ImVec2 p = ImGui::GetCursorScreenPos();
            if (ImGui::InvisibleButton("##tmpl", ImVec2(cw, ch))) ws.spec.tmpl = WorkshopTemplate(i);
            const bool sel = ws.spec.tmpl == WorkshopTemplate(i), hov = ImGui::IsItemHovered();
            dl->AddRectFilled(p, ImVec2(p.x + cw, p.y + ch), sel ? col::accentDim : (hov ? IM_COL32(35, 39, 51, 255) : col::panelAlt), 8 * s);
            if (sel) dl->AddRect(p, ImVec2(p.x + cw, p.y + ch), col::accent, 8 * s, 0, 2.0f * s);
            pushFont(fonts.bold);
            dl->AddText(ImVec2(p.x + 10 * s, p.y + 8 * s), col::text, templateName(WorkshopTemplate(i)));
            popFont();
            pushFont(fonts.small);
            dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), ImVec2(p.x + 10 * s, p.y + 8 * s + ImGui::GetFontSize() + 8 * s), col::textDim,
                        templateInfo(WorkshopTemplate(i)), nullptr, cw - 20 * s);
            popFont();
            ImGui::PopID();
        }
        ImGui::Dummy(ImVec2(0, 8 * s));

        static char kitNameBuf[64] = "My kit";
        if (ws.spec.tmpl == WorkshopTemplate::KitPiece) {
            section("Kit piece");
            ImGui::TextDisabled("Which piece of a building kit is this? It is made to the building grid (2 m cells, 2.5 m storeys).");
            const float g2 = 4 * s;
            const float bw = (ImGui::GetContentRegionAvail().x - g2 * 6) / 7.0f;
            for (int r = 1; r < kKitRoleCount; ++r) {
                if (r > 1) ImGui::SameLine(0, g2);
                char label[48];
                std::snprintf(label, sizeof label, "%s##role%d", kitRoleLabel(KitRole(r)), r);
                const bool on = ws.spec.kitRole == KitRole(r);
                if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::ColorConvertU32ToFloat4(col::accentDim));
                if (ImGui::Button(label, ImVec2(bw, 0))) ws.spec.kitRole = KitRole(r);
                if (on) ImGui::PopStyleColor();
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", kitRoleInfo(KitRole(r)));
            }
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted("Kit name");
            ImGui::SameLine(80 * s);
            ImGui::SetNextItemWidth(-FLT_MIN);
            ImGui::InputText("##kitname", kitNameBuf, sizeof kitNameBuf);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Pieces with the same kit name are shown together in the Kits panel.\nA built-in name (Brick house, Timber cabin...) starts from that look.");
            pushFont(fonts.small);
            ImGui::TextDisabled("Leave the name above as it is to call it \"%s\".", kitPieceName(kitNameBuf[0] ? kitNameBuf : "My kit", ws.spec.kitRole).c_str());
            popFont();
            ImGui::Dummy(ImVec2(0, 6 * s));
        }

        if (ws.spec.tmpl == WorkshopTemplate::Blank) {
            section("Space");
            ImGui::TextDisabled("Detail: how small a voxel is. Finer detail needs a smaller space.");
            const float g2 = 6 * s;
            const float bw = (ImGui::GetContentRegionAvail().x - g2 * 4) / 5.0f;
            for (int i = 0; i < 5; ++i) {
                if (i) ImGui::SameLine(0, g2);
                char label[48];
                std::snprintf(label, sizeof label, "%s##d%d", kDetailName[i], i);
                if (toggleButton(label, std::fabs(ws.spec.voxelSize - kDetailSize[i]) < 1e-5f, ImVec2(bw, 0))) ws.spec.voxelSize = kDetailSize[i];
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("Voxels of %s", cm(kDetailSize[i]).c_str());
            }
            ImGui::Dummy(ImVec2(0, 2 * s));
            if (beginProps("##space", 70)) {
                const char* nm[3] = { "Width", "Height", "Depth" };
                for (int i = 0; i < 3; ++i) {
                    prop(nm[i]);
                    ImGui::SetNextItemWidth(-FLT_MIN);
                    ImGui::PushID(i);
                    sliderFloat("##sp", &ws.spec.sizeMetres[i], 0.5f, 24.0f, "%.1f m");
                    ImGui::PopID();
                }
                endProps();
            }
            const glm::ivec3 g = Workshop::gridFor(ws.spec.sizeMetres, ws.spec.voxelSize);
            const glm::vec3 real = glm::vec3(g) * ws.spec.voxelSize;
            pushFont(fonts.small);
            if (std::fabs(real.x - ws.spec.sizeMetres.x) > ws.spec.voxelSize * 1.5f || std::fabs(real.y - ws.spec.sizeMetres.y) > ws.spec.voxelSize * 1.5f ||
                std::fabs(real.z - ws.spec.sizeMetres.z) > ws.spec.voxelSize * 1.5f)
                ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "Too big at this detail: the space shrinks to %.1f x %.1f x %.1f m.", double(real.x), double(real.y), double(real.z));
            else ImGui::TextDisabled("%d x %d x %d voxels", g.x, g.y, g.z);
            popFont();
            ImGui::Dummy(ImVec2(0, 4 * s));
        }

        const float bw = 130 * s;
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - 2 * bw - 20 * s - 6 * s);
        if (ImGui::Button("Cancel", ImVec2(bw, 0))) {
            ws.askNew = false;
            ImGui::CloseCurrentPopup();
            if (!ws.model.asset.valid()) leaveWorkshop();
        }
        ImGui::SameLine(0, 6 * s);
        if (primaryButton("Create", ImVec2(bw, 0)) || (ImGui::IsKeyPressed(ImGuiKey_Enter) && !ImGui::IsItemActive() && false)) {
            ws.spec.name = dlgName[0] ? dlgName : templateName(ws.spec.tmpl);
            if (ws.spec.tmpl == WorkshopTemplate::KitPiece) {
                ws.spec.kitStyle = kitNameBuf[0] ? kitNameBuf : "My kit";
                if (!dlgName[0] || std::string(dlgName) == "New asset") ws.spec.name = kitPieceName(ws.spec.kitStyle, ws.spec.kitRole);
            }
            ImGui::CloseCurrentPopup();
            enterWorkshopWith(ws.spec);
        }
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar();

    // ---------------- unsaved changes
    if (ws.askLeave && !ImGui::IsPopupOpen("Unsaved changes")) ImGui::OpenPopup("Unsaved changes");
    ImGui::SetNextWindowPos(centre, ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(440 * s, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(20 * s, 16 * s));
    if (ImGui::BeginPopupModal("Unsaved changes", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize)) {
        if (!ws.askLeave) { ImGui::CloseCurrentPopup(); ImGui::EndPopup(); ImGui::PopStyleVar(); return; }
        pushFont(fonts.title); ImGui::TextUnformatted("Save your changes?"); popFont();
        ImGui::Dummy(ImVec2(0, 4 * s));
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("'%s' has changes that aren't saved yet.", ws.model.asset.name.c_str());
        ImGui::PopTextWrapPos();
        ImGui::Dummy(ImVec2(0, 10 * s));
        const float bw = (ImGui::GetContentRegionAvail().x - 12 * s) / 3.0f;
        if (primaryButton("Save", ImVec2(bw, 0))) {
            const std::string after = ws.afterLeave;
            if (workshopSave()) { ImGui::CloseCurrentPopup(); workshopRunAfter(after); }
        }
        ImGui::SameLine(0, 6 * s);
        if (dangerButton("Don't save", ImVec2(bw, 0))) { const std::string after = ws.afterLeave; ImGui::CloseCurrentPopup(); workshopRunAfter(after); }
        ImGui::SameLine(0, 6 * s);
        if (ImGui::Button("Keep working", ImVec2(bw, 0))) { ws.askLeave = false; ws.afterLeave.clear(); ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
    ImGui::PopStyleVar();
}

// ================================================================ the view overlay

void Application::drawWorkshopOverlay() {
    if (ws.rangeOn) { drawWorkshopRange(); return; }
    if (!ws.model.asset.valid()) return;
    const float s = scale();
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    dl->PushClipRect(ImVec2(viewRect.x, viewRect.y), ImVec2(viewRect.x + viewRect.w, viewRect.y + viewRect.h), true);
    const View v = workshopView();
    auto line = [&](const glm::vec3& a, const glm::vec3& b, ImU32 c, float th) {
        ImVec2 pa, pb;
        if (v.line(a, b, pa, pb)) dl->AddLine(pa, pb, c, th);
    };
    const glm::vec3 lo = ws.model.gridMin(), hi = ws.model.gridMax();

    // ---- floor grid
    if (ws.showGrid) {
        const float longest = std::max(hi.x - lo.x, hi.z - lo.z);
        static const float steps[] = { 0.0125f, 0.025f, 0.05f, 0.1f, 0.25f, 0.5f, 1.0f, 2.0f, 5.0f, 10.0f };
        float step = steps[9];
        for (float f : steps) if (longest / f <= 40.0f) { step = f; break; }
        const ImU32 minor = IM_COL32(255, 255, 255, 22), major = IM_COL32(255, 255, 255, 44);
        for (int i = int(std::ceil(lo.x / step - 1e-4f)); float(i) * step <= hi.x + 1e-4f; ++i) {
            const float x = float(i) * step;
            line(glm::vec3(x, 0.003f, lo.z), glm::vec3(x, 0.003f, hi.z), i == 0 ? IM_COL32(80, 130, 255, 120) : (i % 5 == 0 ? major : minor), (i == 0 ? 1.6f : 1.0f) * s);
        }
        for (int i = int(std::ceil(lo.z / step - 1e-4f)); float(i) * step <= hi.z + 1e-4f; ++i) {
            const float z = float(i) * step;
            line(glm::vec3(lo.x, 0.003f, z), glm::vec3(hi.x, 0.003f, z), i == 0 ? IM_COL32(240, 90, 90, 120) : (i % 5 == 0 ? major : minor), (i == 0 ? 1.6f : 1.0f) * s);
        }
    }

    // ---- work area
    if (ws.showBounds) {
        const ImU32 c = IM_COL32(120, 170, 255, 70);
        glm::vec3 k[8];
        for (int i = 0; i < 8; ++i) k[i] = glm::vec3(i & 1 ? hi.x : lo.x, i & 2 ? hi.y : lo.y, i & 4 ? hi.z : lo.z);
        static const int e[12][2] = { {0,1},{2,3},{4,5},{6,7},{0,2},{1,3},{4,6},{5,7},{0,4},{1,5},{2,6},{3,7} };
        for (auto& ed : e) line(k[ed[0]], k[ed[1]], c, 1.0f * s);
    }

    // ---- mirror planes
    if (ws.mirror.any()) {
        const glm::vec3 m = ws.model.mirrorCentre();
        auto plane = [&](int axis) {
            glm::vec3 q[4];
            const int a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
            for (int i = 0; i < 4; ++i) {
                glm::vec3 p = m;
                p[a1] = (i & 1) ? hi[a1] : lo[a1];
                p[a2] = (i & 2) ? hi[a2] : lo[a2];
                q[i] = p;
            }
            ImVec2 sp[4];
            bool ok = true;
            for (int i = 0; i < 4; ++i) ok = ok && v.point(q[i], sp[i]);
            if (ok) { const ImVec2 quad[4] = { sp[0], sp[1], sp[3], sp[2] }; dl->AddConvexPolyFilled(quad, 4, IM_COL32(255, 200, 80, 22)); }
            line(q[0], q[1], IM_COL32(255, 200, 80, 120), 1.2f * s); line(q[1], q[3], IM_COL32(255, 200, 80, 120), 1.2f * s);
            line(q[3], q[2], IM_COL32(255, 200, 80, 120), 1.2f * s); line(q[2], q[0], IM_COL32(255, 200, 80, 120), 1.2f * s);
        };
        if (ws.mirror.x) plane(0);
        if (ws.mirror.y) plane(1);
        if (ws.mirror.z) plane(2);
    }

    // ---- the ghost under the cursor
    const bool shapeTool = ws.tool == WTool::Add || ws.tool == WTool::Carve || ws.tool == WTool::Paint;
    if (ws.hoverValid && !ws.askNew && !ws.askLeave && !ws.orbiting && !ws.panning) {
        const ImU32 base = ws.tool == WTool::Add ? col::success : ws.tool == WTool::Carve ? col::danger : ws.tool == WTool::Paint ? IM_COL32(240, 240, 248, 255) : col::accent;
        if (shapeTool) {
            std::vector<Seg> segs;
            shapeWire(workshopStamp(ws.hoverCentre), segs);
            for (int bits = 0; bits < 8; ++bits) {
                if (((bits & 1) && !ws.mirror.x) || ((bits & 2) && !ws.mirror.y) || ((bits & 4) && !ws.mirror.z)) continue;
                const ImU32 c = withAlpha(base, bits ? 0.45f : 0.95f);
                for (const Seg& sg : segs)
                    line(ws.model.mirrorPoint(sg.first, ws.mirror, bits), ws.model.mirrorPoint(sg.second, ws.mirror, bits), c, (bits ? 1.2f : 1.8f) * s);
            }
        } else if (ws.tool == WTool::Smooth) {
            const glm::vec3 n = ws.hover.normal;
            const glm::vec3 u = std::fabs(n.y) < 0.95f ? glm::normalize(glm::cross(n, glm::vec3(0, 1, 0))) : glm::vec3(1, 0, 0);
            const glm::vec3 w = glm::cross(n, u);
            for (int bits = 0; bits < 8; ++bits) {
                if (((bits & 1) && !ws.mirror.x) || ((bits & 2) && !ws.mirror.y) || ((bits & 4) && !ws.mirror.z)) continue;
                glm::vec3 prev(0.0f);
                for (int i = 0; i <= 36; ++i) {
                    const float t = float(i) / 36.0f * glm::two_pi<float>();
                    const glm::vec3 p = ws.model.mirrorPoint(ws.hover.point + (u * std::cos(t) + w * std::sin(t)) * ws.smoothRadius + n * (ws.model.asset.voxelSize * 0.2f), ws.mirror, bits);
                    if (i) line(prev, p, withAlpha(base, bits ? 0.45f : 0.95f), (bits ? 1.2f : 1.8f) * s);
                    prev = p;
                }
            }
        }
        ImVec2 hp;
        if (v.point(ws.hover.point, hp)) dl->AddCircleFilled(hp, 2.5f * s, IM_COL32(255, 255, 255, 220));

        // a size label next to the pointer
        char label[96] = {};
        if (shapeTool) std::snprintf(label, sizeof label, "%s x %s x %s", cm(ws.size.x).c_str(), cm(ws.size.y).c_str(), cm(ws.size.z).c_str());
        else if (ws.tool == WTool::Smooth) std::snprintf(label, sizeof label, "Radius %s", cm(ws.smoothRadius).c_str());
        else if (ws.tool == WTool::Socket && !ws.draggingSocket) std::snprintf(label, sizeof label, "Click to add a socket");
        if (label[0]) {
            pushFont(fonts.small);
            const ImVec2 ts = ImGui::CalcTextSize(label);
            const ImVec2 a(mouseX + 16 * s, mouseY + 18 * s);
            dl->AddRectFilled(ImVec2(a.x - 6 * s, a.y - 3 * s), ImVec2(a.x + ts.x + 6 * s, a.y + ts.y + 3 * s), IM_COL32(11, 12, 16, 215), 5 * s);
            dl->AddText(a, col::text, label);
            popFont();
        }
    }

    // ---- sockets
    {
        const float arrow = std::clamp(0.5f * glm::length(hi - lo) * 0.08f, ws.model.asset.voxelSize * 3.0f, 0.5f);
        for (const Socket& sk : ws.model.asset.sockets) {
            const bool sel = sk.name == ws.selectedSocket;
            glm::vec3 pos = sk.position, dir = sk.direction;
            if (sel && ws.draggingSocket) { pos = ws.socketDragPos; dir = ws.socketDragDir; }
            const ImU32 c = sel ? IM_COL32(255, 170, 50, 255) : IM_COL32(90, 220, 255, 235);
            ImVec2 sp;
            if (!v.point(pos, sp)) continue;
            line(pos, pos + dir * arrow, c, 2.0f * s);
            dl->AddCircleFilled(sp, 5.5f * s, withAlpha(IM_COL32(11, 12, 16, 255), 0.85f));
            dl->AddCircle(sp, 5.5f * s, c, 16, 2.0f * s);
            ImVec2 tip;
            if (v.point(pos + dir * arrow, tip)) dl->AddCircleFilled(tip, 2.5f * s, c);
            if (sel || ws.tool == WTool::Socket) {
                pushFont(fonts.small);
                const ImVec2 ts = ImGui::CalcTextSize(sk.name.c_str());
                const ImVec2 a(sp.x + 10 * s, sp.y - ts.y - 6 * s);
                dl->AddRectFilled(ImVec2(a.x - 5 * s, a.y - 2 * s), ImVec2(a.x + ts.x + 5 * s, a.y + ts.y + 2 * s), IM_COL32(11, 12, 16, 215), 4 * s);
                dl->AddText(a, c, sk.name.c_str());
                popFont();
            }
        }
    }

    // ---- hints
    if (showHints) {
        pushFont(fonts.small);
        const char* text = ws.tool == WTool::Socket
            ? "Click: add a socket     Drag a socket: move it     Del: remove     Right-drag: orbit     Middle-drag: pan     Wheel: zoom"
            : ws.tool == WTool::Smooth
            ? "Hold and drag to smooth     Shift+wheel: radius     X Y Z: mirror     Right-drag: orbit     Middle-drag: pan     Wheel: zoom"
            : "Click or drag     Shift+wheel: size     R: turn     X Y Z: mirror     Right-drag: orbit     Middle-drag: pan     Wheel: zoom     F: frame";
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const ImVec2 a(viewRect.x + (viewRect.w - ts.x) * 0.5f, viewRect.y + viewRect.h - ts.y - 16 * s);
        dl->AddRectFilled(ImVec2(a.x - 10 * s, a.y - 5 * s), ImVec2(a.x + ts.x + 10 * s, a.y + ts.y + 5 * s), IM_COL32(11, 12, 16, 200), 8 * s);
        dl->AddText(a, col::textDim, text);
        popFont();
    }
    dl->PopClipRect();
}

// ================================================================ the whole screen

void Application::drawWorkshopUI() {
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    const float s = scale();
    drawWorkshopMenuBar();
    const float statusH = ImGui::GetFontSize() + 14 * s;
    const float top = gMenuH, bottom = vp->Pos.y + vp->Size.y - statusH;
    const float railW = 58 * s, panelW = 330 * s;
    viewRect = { vp->Pos.x + railW, top, std::max(8.0f, vp->Size.x - railW - panelW), std::max(8.0f, bottom - top) };

    drawWorkshopOverlay();
    drawWorkshopRail(top, bottom);
    drawWorkshopPanel(top, bottom);
    drawWorkshopStatus(bottom, statusH);
    drawWorkshopDialogs();
    drawToasts(toasts, top + 12 * s);
}

} // namespace px
