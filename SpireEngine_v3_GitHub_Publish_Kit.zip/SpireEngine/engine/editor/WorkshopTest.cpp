// --demo ws...: scripted Workshop sessions for screenshots, and the Workshop self test.
#include "core/Application.h"
#include "editor/ItemRange.h"
#include "editor/WorkshopCommon.h"
#include "scene/AssetFile.h"
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <iostream>

namespace px {

void Application::setupWorkshopDemo() {
    if (demo == "wsselftest") { runWorkshopSelfTest(); return; }
    int w = 1200, h = 700;
    SDL_GetWindowSize(window, &w, &h);
    showHints = true;
    NewAssetSpec spec;
    // Puts the pointer over a point in the model's space, the way the layout of the real screen will have it.
    auto aim = [&](const glm::vec3& p) {
        viewRect = { 58.0f, 30.0f, float(w) - 58.0f - 330.0f, float(h) - 30.0f - 28.0f };
        workshopApplyCamera();
        const wsui::View v = workshopView();
        ImVec2 sp(0, 0);
        if (v.point(p, sp)) { mouseX = sp.x; mouseY = sp.y; }
    };

    if (demo == "wsnew") { enterWorkshopNew(); ws.spec.tmpl = WorkshopTemplate::Blank; return; }
    if (demo == "wsnewtemplate") { enterWorkshopNew(); ws.spec.tmpl = WorkshopTemplate::Sword; return; }

    if (demo == "wsmannequin" || demo == "wsmirror") {
        spec.tmpl = WorkshopTemplate::Mannequin;
        enterWorkshopWith(spec);
        ws.tool = WTool::Add;
        ws.shape = Shape::Box;
        ws.size = glm::vec3(0.22f, 0.12f, 0.16f);
        ws.mirror.x = true;
        ws.material = MAT_METAL;
        ws.lightTime = 11.0f;
        aim(glm::vec3(0.0f, 1.2f, 0.0f));
        return;
    }
    if (demo == "wssword" || demo == "wssockets") {
        spec.tmpl = WorkshopTemplate::Sword;
        enterWorkshopWith(spec);
        ws.tool = WTool::Socket;
        if (!ws.model.asset.sockets.empty()) ws.selectedSocket = ws.model.asset.sockets.front().name;
        ws.lightTime = 12.0f;
        aim(glm::vec3(0.0f, 0.12f, 0.0f));
        return;
    }
    if (demo == "wslantern" || demo == "wsmaterials") {                 // the lantern, finished with the new materials and lit at dusk
        spec.name = "Garden lantern";
        spec.voxelSize = 0.0625f;
        spec.sizeMetres = glm::vec3(3.0f, 4.0f, 3.0f);
        enterWorkshopWith(spec);
        auto put = [&](Shape sh, glm::vec3 c, glm::vec3 half, MaterialId m, float round = 0.0f, StampMode mode = StampMode::Add) {
            Stamp st; st.shape = sh; st.centre = c; st.half = half; st.material = m; st.round = round; st.mode = mode;
            ws.model.stamp(st);
        };
        put(Shape::Cylinder, { 0, 0.12f, 0 }, { 0.55f, 0.12f, 0.55f }, MAT_TILE, 0.04f);
        put(Shape::Cylinder, { 0, 1.2f, 0 }, { 0.08f, 1.0f, 0.08f }, MAT_PAINT_BLACK);
        put(Shape::Box, { 0, 2.55f, 0 }, { 0.3f, 0.34f, 0.3f }, MAT_PAINT_BLACK, 0.04f);
        for (int i = 0; i < 4; ++i) {
            const float a = glm::radians(90.0f * float(i));
            put(Shape::Box, { std::cos(a) * 0.3f, 2.58f, std::sin(a) * 0.3f }, { 0.12f, 0.17f, 0.12f }, MAT_STONE, 0.0f, StampMode::Carve);
        }
        put(Shape::Sphere, { 0, 2.55f, 0 }, { 0.2f, 0.24f, 0.2f }, MAT_LAMP);                       // the light inside
        put(Shape::Cone, { 0, 3.1f, 0 }, { 0.5f, 0.24f, 0.5f }, MAT_PAINT_RED, 0.02f);
        put(Shape::Sphere, { 0, 3.42f, 0 }, { 0.09f, 0.09f, 0.09f }, MAT_CRYSTAL);
        put(Shape::Sphere, { 0.7f, 0.3f, 0.2f }, { 0.22f, 0.22f, 0.22f }, MAT_LAVA);
        put(Shape::Sphere, { -0.75f, 0.28f, 0.1f }, { 0.2f, 0.2f, 0.2f }, MAT_ICE);
        put(Shape::Box, { 0.3f, 0.2f, -0.8f }, { 0.25f, 0.2f, 0.25f }, MAT_CLOTH, 0.05f);
        put(Shape::Box, { -0.4f, 0.17f, -0.8f }, { 0.22f, 0.17f, 0.22f }, MAT_PAINT_TEAL, 0.05f);
        ws.model.setName("Garden lantern");
        ws.model.markSaved();
        workshopSyncInfo();
        ws.model.remesh();
        workshopFrame();
        ws.tool = WTool::Paint;
        ws.shape = Shape::Sphere;
        ws.size = glm::vec3(0.3f);
        ws.material = MAT_PAINT_BLUE;
        ws.lightTime = 18.0f;
        aim(glm::vec3(0.0f, 2.55f, 0.3f));
        if (demo == "wslantern") { ws.showGrid = false; ws.showBounds = false; showHints = false; mouseX = mouseY = -1000.0f; }
        return;
    }
    if (demo == "wskit" || demo == "wskitnew") {                         // a kit piece in the Workshop, and the dialog that starts one
        if (demo == "wskitnew") {
            enterWorkshopNew();
            ws.spec.tmpl = WorkshopTemplate::KitPiece;
            ws.spec.kitRole = KitRole::Window;
            return;
        }
        spec.tmpl = WorkshopTemplate::KitPiece;
        spec.kitRole = KitRole::Window;
        spec.kitStyle = "Cottage";
        spec.name = "Cottage window";
        enterWorkshopWith(spec);
        auto put = [&](Shape sh, glm::vec3 c, glm::vec3 half, MaterialId m, float round = 0.0f) {
            Stamp st; st.shape = sh; st.centre = c; st.half = half; st.material = m; st.round = round;
            ws.model.stamp(st);
        };
        put(Shape::Box, { 0.0f, 0.74f, 0.22f }, { 0.62f, 0.07f, 0.1f }, MAT_WOOD, 0.02f);                   // a flower box under the sill
        for (int i = 0; i < 5; ++i) put(Shape::Sphere, { -0.46f + 0.23f * float(i), 0.88f, 0.22f }, { 0.07f, 0.07f, 0.07f }, i % 2 ? MAT_PAINT_PINK : MAT_PAINT_YELLOW);
        for (int i = 0; i < 5; ++i) put(Shape::Cone, { -0.46f + 0.23f * float(i), 0.80f, 0.22f }, { 0.04f, 0.06f, 0.04f }, MAT_PAINT_GREEN);
        ws.model.markSaved();
        workshopSyncInfo();
        ws.model.remesh();
        workshopFrame();
        ws.tool = WTool::Add;
        ws.shape = Shape::Box;
        ws.size = glm::vec3(0.1f);
        ws.material = MAT_WOOD;
        ws.lightTime = 11.0f;
        aim(glm::vec3(0.0f, 1.0f, 0.1f));
        return;
    }
    if (demo == "wsbuild" || demo == "wsbuildclean" || demo == "wspaint") {
        spec.name = "Garden lantern";
        spec.voxelSize = 0.0625f;
        spec.sizeMetres = glm::vec3(3.0f, 4.0f, 3.0f);
        enterWorkshopWith(spec);
        auto put = [&](Shape sh, glm::vec3 c, glm::vec3 half, MaterialId m, float round = 0.0f, StampMode mode = StampMode::Add) {
            Stamp s; s.shape = sh; s.centre = c; s.half = half; s.material = m; s.round = round; s.mode = mode;
            ws.model.stamp(s);
        };
        put(Shape::Cylinder, { 0, 0.12f, 0 }, { 0.55f, 0.12f, 0.55f }, MAT_STONE, 0.04f);
        put(Shape::Cylinder, { 0, 1.2f, 0 }, { 0.08f, 1.0f, 0.08f }, MAT_METAL);
        put(Shape::Box, { 0, 2.55f, 0 }, { 0.3f, 0.34f, 0.3f }, MAT_WOOD, 0.04f);
        for (int i = 0; i < 4; ++i) {
            const float a = glm::radians(90.0f * float(i));
            put(Shape::Box, { std::cos(a) * 0.3f, 2.58f, std::sin(a) * 0.3f }, { 0.12f, 0.17f, 0.12f }, MAT_STONE, 0.0f, StampMode::Carve);
        }
        put(Shape::Cone, { 0, 3.1f, 0 }, { 0.5f, 0.24f, 0.5f }, MAT_BRICK, 0.02f);
        put(Shape::Sphere, { 0, 3.42f, 0 }, { 0.09f, 0.09f, 0.09f }, MAT_METAL);
        ws.model.setName("Garden lantern");
        ws.model.markSaved();
        workshopSyncInfo();
        ws.model.remesh();
        workshopFrame();
        ws.tool = demo == "wspaint" ? WTool::Paint : WTool::Add;
        ws.shape = demo == "wspaint" ? Shape::Sphere : Shape::Box;
        ws.size = glm::vec3(demo == "wspaint" ? 0.3f : 0.4f);
        ws.material = demo == "wspaint" ? MAT_SAND : MAT_WOOD;
        ws.lightTime = 15.5f;
        aim(demo == "wspaint" ? glm::vec3(0.0f, 2.55f, 0.3f) : glm::vec3(0.8f, 0.0f, 0.5f));
        if (demo == "wsbuildclean") { ws.showGrid = false; ws.showBounds = false; showHints = false; mouseX = mouseY = -1000.0f; }
        return;
    }
    if (demo == "wsedit") {                                  // a built-in asset, copied onto a finer grid
        editAssetInWorkshop("stone_arch");
        ws.tool = WTool::Carve;
        ws.shape = Shape::Sphere;
        ws.lightTime = 13.0f;
        aim(glm::vec3(-4.5f, 3.0f, 0.0f));
        return;
    }
    if (demo == "wsitem" || demo == "wsrange" || demo == "wsrangerocket" || demo == "wsrangedig") {
        int vw = w, vh = h;
        viewRect = { 58.0f, 30.0f, float(vw) - 58.0f - 330.0f, float(vh) - 30.0f - 28.0f };
        if (demo == "wsrangerocket") editAssetInWorkshop("rocket_launcher");
        else if (demo == "wsrangedig") editAssetInWorkshop("terraformer");
        else { spec.tmpl = WorkshopTemplate::Pistol; spec.name = "Blaster"; enterWorkshopWith(spec); }
        ws.lightTime = 12.0f;
        ws.panelTab = 1;
        if (demo == "wsitem") return;

        workshopEnterRange();
        ws.rangeCaptured = true;
        ItemRange& r = *ws.range;
        auto aimAt = [&](glm::vec3 p) {
            const glm::vec3 d = p - r.eye();
            camera.yaw = glm::degrees(std::atan2(d.z, d.x));
            camera.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
        };
        auto step = [&](float seconds) {
            for (float t = 0.0f; t < seconds; t += 1.0f / 60.0f) {
                r.setDraft(ws.item, AssetPtr(AssetPtr(), &ws.model.asset));
                r.update(1.0f / 60.0f, camera.yaw, camera.pitch, 0.0f, 0.0f, false);
                camera.pitch = glm::clamp(camera.pitch + r.takeViewKick(), -89.0f, 89.0f);
            }
        };
        step(0.6f);
        if (demo == "wsrange") {
            ws.item.stats.automatic = true;
            aimAt({ 2.2f, 1.45f, 8.0f });
            r.items.pressTrigger(0);
            step(0.5f);
            aimAt({ 0.0f, 1.2f, 11.0f });
            step(0.45f);
            r.items.releaseTrigger(0);
            step(0.12f);
        } else if (demo == "wsrangerocket") {
            aimAt({ 0.0f, 1.0f, 11.0f });
            r.items.pressTrigger(0);
            step(0.05f);
            r.items.releaseTrigger(0);
            const int boom = r.items.totals.explosions;
            for (int i = 0; i < 400 && r.items.totals.explosions == boom; ++i) step(1.0f / 60.0f);
            step(0.12f);
        } else {
            aimAt({ -12.0f, 0.4f, 12.0f });
            r.items.pressTrigger(0);
            step(0.4f);
            r.items.releaseTrigger(0);
            r.items.pressTrigger(1);
            step(0.25f);
            r.items.releaseTrigger(1);
            step(0.05f);
        }
        itemsFrozen = true;
        return;
    }
    if (demo == "wsleave") {
        spec.tmpl = WorkshopTemplate::Wall;
        enterWorkshopWith(spec);
        ws.model.setName("Brick wall");
        workshopLeaveWith("close");
        return;
    }
}

// Drives the Workshop the way the mouse and keyboard do (events, hover, strokes, saving), without a person.
void Application::runWorkshopSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[wstest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    namespace fs = std::filesystem;
    using namespace wsui;

    setMode(Mode::Editor);
    const std::string savedDir = assets.directory;
    const fs::path tmp = fs::temp_directory_path() / "pxws_selftest";
    std::error_code ec;
    fs::remove_all(tmp, ec);
    assets.directory = tmp.string();
    const Camera cameraBefore = camera;
    const float timeBefore = timeOfDay;

    // ---- opening
    enterWorkshopNew();
    check(ws.active && ws.askNew && !ws.model.asset.valid(), "the Workshop opens with the New Asset dialog");
    NewAssetSpec spec;
    spec.name = "Selftest piece";
    spec.voxelSize = 0.125f;
    spec.sizeMetres = glm::vec3(4.0f, 3.0f, 4.0f);
    enterWorkshopWith(spec);
    check(ws.active && !ws.askNew && ws.model.asset.valid() && !ws.model.modified(), "creating starts an unmodified asset");
    check(renderSettings.drawWorld == false, "the world is not drawn while the Workshop is open");
    check(ws.model.asset.size == glm::ivec3(32, 24, 32), "a 4 x 3 x 4 m space at 12.5 cm has 32 x 24 x 32 voxels");

    int sw = 1200, sh = 700;
    SDL_GetWindowSize(window, &sw, &sh);
    viewRect = { 58.0f, 30.0f, float(sw) - 58.0f - 330.0f, float(sh) - 30.0f - 28.0f };
    workshopFrame();
    updateWorkshop(0.016f);

    auto send = [&](SDL_Event e) { workshopHandleEvent(e); };
    auto key = [&](SDL_Keycode k) { SDL_Event e{}; e.type = SDL_EVENT_KEY_DOWN; e.key.key = k; send(e); };
    auto moveTo = [&](const glm::vec3& p) {
        const View v = workshopView();
        ImVec2 sp(0, 0);
        const bool ok = v.point(p, sp);
        SDL_Event e{}; e.type = SDL_EVENT_MOUSE_MOTION; e.motion.x = sp.x; e.motion.y = sp.y;
        send(e);
        updateWorkshop(0.016f);
        return ok;
    };
    auto button = [&](bool down) { SDL_Event e{}; e.type = down ? SDL_EVENT_MOUSE_BUTTON_DOWN : SDL_EVENT_MOUSE_BUTTON_UP; e.button.button = SDL_BUTTON_LEFT; send(e); updateWorkshop(0.016f); };
    auto click = [&](const glm::vec3& p) { moveTo(p); button(true); button(false); };

    // ---- Add a shape: click on the floor
    check(ws.tool == WTool::Add, "Add is the first tool");
    check(moveTo(glm::vec3(0.0f, 0.0f, 0.0f)) && ws.hoverValid && ws.hover.floor, "the pointer over the floor finds the floor");
    size_t solid0 = ws.model.solidVoxels();
    click(glm::vec3(0.0f, 0.0f, 0.0f));
    size_t solid1 = ws.model.solidVoxels();
    check(solid1 > solid0 + 20, "clicking adds a shape");
    check(ws.model.undoLabel() == "Add Box" && ws.model.modified(), "that is one undo step, and the asset is modified");
    check(ws.model.asset.density(glm::vec3(0.0f, 0.1f, 0.0f)) < 0.0f && ws.model.asset.boundsMin.y > -0.15f, "it rests on the floor");
    workshopUndo();
    check(ws.model.solidVoxels() == solid0 && !ws.model.modified(), "undo takes it away again");
    workshopRedo();
    check(ws.model.solidVoxels() == solid1, "redo brings it back");

    // ---- a drag draws a line of shapes as one step
    moveTo(glm::vec3(-1.0f, 0.0f, 1.0f));
    button(true);
    for (int i = 1; i <= 12; ++i) moveTo(glm::vec3(-1.0f + 2.0f * float(i) / 12.0f, 0.0f, 1.0f));
    button(false);
    const size_t solid2 = ws.model.solidVoxels();
    check(solid2 > solid1 + 150 && ws.model.undoLabel() == "Add Box", "dragging draws a row of shapes");
    workshopUndo();
    check(ws.model.solidVoxels() == solid1, "the whole drag is one undo step");
    workshopRedo();

    // ---- Esc during a stroke cancels it
    moveTo(glm::vec3(1.0f, 0.0f, -1.0f));
    button(true);
    moveTo(glm::vec3(1.5f, 0.0f, -1.0f));
    check(ws.stroking, "a stroke is in progress while the button is held");
    key(SDLK_ESCAPE);
    button(false);
    check(!ws.stroking && ws.model.solidVoxels() == solid2, "Esc cancels the stroke that is in progress");

    // ---- Carve
    key(SDLK_2);
    check(ws.tool == WTool::Carve, "key 2 chooses Carve");
    ws.shape = Shape::Sphere;
    glm::vec3 top(0.0f, ws.model.asset.boundsMax.y, 0.0f);
    moveTo(top + glm::vec3(0.0f, 0.02f, 0.0f));
    check(ws.hoverValid && !ws.hover.floor, "the pointer over the model finds the model");
    const size_t beforeCarve = ws.model.solidVoxels();
    click(top + glm::vec3(0.0f, 0.02f, 0.0f));
    check(ws.model.solidVoxels() < beforeCarve && ws.model.undoLabel() == "Carve Sphere", "Carve takes material away");
    workshopUndo();
    check(ws.model.solidVoxels() == beforeCarve, "and undo puts it back");

    // ---- Mirror
    key(SDLK_1);
    ws.shape = Shape::Box;
    key(SDLK_X);
    check(ws.mirror.x && !ws.mirror.y, "X turns the left / right mirror on");
    const float mx = ws.model.mirrorCentre().x;
    click(glm::vec3(mx + 1.3f, 0.0f, -1.2f));
    check(ws.model.asset.density(glm::vec3(mx + 1.3f, 0.1f, -1.2f)) < 0.0f && ws.model.asset.density(glm::vec3(mx - 1.3f, 0.1f, -1.2f)) < 0.0f, "with the mirror on, an edit appears on both sides");
    key(SDLK_X);

    // ---- Paint
    key(SDLK_3);
    ws.shape = Shape::Sphere;
    ws.size = glm::vec3(0.9f);
    ws.material = MAT_BRICK;
    const size_t beforePaint = ws.model.solidVoxels();
    moveTo(top + glm::vec3(0.0f, 0.02f, 0.0f));
    const glm::vec3 paintAt = ws.hover.point;
    click(top + glm::vec3(0.0f, 0.02f, 0.0f));
    check(ws.model.solidVoxels() == beforePaint && ws.model.asset.materialNear(paintAt) == MAT_BRICK, "Paint changes the material and not the shape");
    check(ws.model.undoLabel() == "Paint", "painting is an undo step");
    ws.paintFill = true;
    ws.material = MAT_WOOD;
    auto count = [&](MaterialId m) { size_t n = 0; for (size_t i = 0; i < ws.model.asset.materials.size(); ++i) if (ws.model.asset.grid[i] < 0.0f && ws.model.asset.materials[i] == m) ++n; return n; };
    const size_t brickBefore = count(MAT_BRICK), woodBefore = count(MAT_WOOD);
    click(top + glm::vec3(0.0f, 0.02f, 0.0f));
    check(ws.model.undoLabel() == "Fill" && count(MAT_WOOD) > woodBefore, "with Fill on, one click recolours a whole patch, as one step");
    check(brickBefore > 0 && count(MAT_BRICK) < brickBefore / 2, "(the painted brick patch is now wood)");
    ws.paintFill = false;

    // ---- Smooth
    key(SDLK_4);
    check(ws.tool == WTool::Smooth, "key 4 chooses Smooth");
    const std::uint64_t revBefore = ws.model.revision();
    moveTo(top + glm::vec3(0.0f, 0.02f, 0.0f));
    button(true);
    for (int i = 0; i < 6; ++i) updateWorkshop(0.06f);
    button(false);
    check(ws.model.revision() != revBefore && ws.model.undoLabel() == "Smooth", "holding Smooth changes the model, as one step");

    // ---- Sockets
    key(SDLK_5);
    check(ws.tool == WTool::Socket, "key 5 chooses Socket");
    const glm::vec3 socketAt = top + glm::vec3(0.0f, 0.02f, 0.0f);
    moveTo(socketAt);
    const glm::vec3 hoverPoint = ws.hover.point;
    button(true); button(false);
    check(ws.model.asset.sockets.size() == 1 && ws.selectedSocket == "socket", "clicking the model adds a socket and selects it");
    check(glm::distance(ws.model.asset.sockets[0].position, hoverPoint) < 0.01f, "the socket sits where the pointer was");
    ws.model.renameSocket("socket", "grip");
    ws.selectedSocket = "grip";
    // drag it to the floor
    moveTo(ws.model.asset.sockets[0].position);
    button(true);
    check(ws.draggingSocket, "pressing on a socket picks it up");
    moveTo(glm::vec3(1.2f, 0.0f, 1.4f));
    button(false);
    check(!ws.draggingSocket && glm::distance(ws.model.asset.sockets[0].position, hoverPoint) > 0.2f, "letting go puts it down somewhere else");
    check(ws.model.undoLabel().rfind("Move socket", 0) == 0, "moving it is one undo step");
    key(SDLK_DELETE);
    check(ws.model.asset.sockets.empty(), "Delete removes the selected socket");
    workshopUndo();
    check(ws.model.asset.sockets.size() == 1, "and undo brings it back");

    // ---- camera
    {
        SDL_Event e{}; e.type = SDL_EVENT_MOUSE_WHEEL; e.wheel.y = 3.0f;
        const float d0 = ws.distance;
        send(e);
        check(ws.distance < d0, "the wheel zooms in");
        e.type = SDL_EVENT_MOUSE_BUTTON_DOWN; e.button.button = SDL_BUTTON_RIGHT; send(e);
        const float yaw0 = camera.yaw;
        SDL_Event m{}; m.type = SDL_EVENT_MOUSE_MOTION; m.motion.xrel = 40.0f; m.motion.x = mouseX + 40.0f; m.motion.y = mouseY; send(m);
        e.type = SDL_EVENT_MOUSE_BUTTON_UP; send(e);
        check(std::fabs(camera.yaw - yaw0) > 1.0f && !ws.orbiting, "dragging with the right button orbits");
        check(glm::distance(camera.position + camera.front() * ws.distance, ws.target) < 0.01f, "and the camera still looks at the target");
        workshopFrame();
    }

    // ---- saving
    ws.model.setName("Selftest piece");
    workshopSyncInfo();
    check(ws.model.modified(), "there is something to save");
    check(workshopSave(), "saving works");
    size_t solidSaved = ws.model.solidVoxels();
    check(!ws.model.modified() && fs::exists(tmp / "Selftest_piece.pxasset"), "it is written as a .pxasset file and the asset is no longer modified");
    {
        AssetPtr loaded = assets.get("Selftest piece");
        check(loaded && assets.isUserMade("Selftest piece") && loaded->sockets.size() == 1 && loaded->sockets[0].name == "grip", "the library has it, with its socket");
        std::string err;
        AssetPtr fromFile = loadAssetFile((tmp / "Selftest_piece.pxasset").string(), &err);
        check(fromFile && fromFile->mesh.size() == ws.model.asset.mesh.size(), "the file reads back to the same model (" + err + ")");
    }
    ws.model.setName("crate");
    std::string why;
    bool problem = workshopNameProblem(&why);
    check(problem, "a built-in asset's name can't be taken: " + why);
    ws.model.setName("");
    problem = workshopNameProblem(&why);
    check(problem, "an empty name can't be saved: " + why);
    ws.model.setName("Selftest piece");

    // ---- leaving
    key(SDLK_1);
    click(glm::vec3(0.0f, 0.0f, -1.6f));
    check(ws.model.modified(), "another edit leaves unsaved work");
    requestLeaveWorkshop();
    check(ws.active && ws.askLeave, "closing with unsaved work asks first");
    check(workshopSave(), "(saving again)");
    solidSaved = ws.model.solidVoxels();
    workshopSaveAndPlace();
    check(!ws.active && placingAsset == "Selftest piece", "Save and Place leaves the Workshop and starts placing the asset");
    check(renderSettings.drawWorld && glm::distance(camera.position, cameraBefore.position) < 1e-3f && std::fabs(timeOfDay - timeBefore) < 1e-3f, "the editor's camera, time and world drawing are back as they were");
    stopPlacing();
    {
        const size_t n = scene.size();
        const ObjectId id = placeObject("Selftest piece", camera.position + camera.front() * 12.0f, 0.0f, 1.0f);
        updateObjects(0.0f);
        check(id != 0 && scene.size() == n + 1 && scene.evaluated().size() >= 1, "the new asset can be placed in the world");
        cmdUndo();
    }

    // ---- editing what exists
    editAssetInWorkshop("Selftest piece");
    check(ws.active && ws.model.asset.valid() && ws.originalName == "Selftest piece" && !ws.model.modified() && ws.model.solidVoxels() == solidSaved,
          "editing your own asset opens it as it was saved");
    leaveWorkshop();
    editAssetInWorkshop("crate");
    check(ws.active && ws.copyOfBuiltin && ws.model.asset.name == "crate (mine)", "a built-in asset opens as your own copy");
    check(ws.model.asset.voxelSize <= 0.5f && ws.model.solidVoxels() > 200, "...on a finer grid, with the shape kept");
    {
        const AssetPtr orig = assets.get("crate");
        check(ws.model.gridMax().x > orig->extent().x * 0.5f + 0.5f, "...and with room to build around it");
    }
    leaveWorkshop();

    fs::remove_all(tmp, ec);
    assets.directory = savedDir;
    assets.forget("Selftest piece");
    std::cerr << "[wstest] " << (fails ? "FAILED" : "ALL OK") << " (" << fails << " failures)\n";
}

} // namespace px
