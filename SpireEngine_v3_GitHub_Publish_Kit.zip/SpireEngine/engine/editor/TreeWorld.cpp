// The world's trees (1.3): drawn from the trees each chunk planted, thinned and culled by the settings, kept out of
// buildings and anything else placed, in two levels of detail; their trunks are solid for the player.
#include "core/Application.h"
#include <cmath>
#include <glm/gtc/matrix_transform.hpp>

namespace px {

namespace {
std::int64_t trunkCell(float x, float z) {
    const std::int64_t cx = std::int64_t(std::floor(x / 8.0f)), cz = std::int64_t(std::floor(z / 8.0f));
    return (cx << 32) ^ (cz & 0xFFFFFFFF);
}
} // namespace

void Application::treeDraws(std::vector<ObjectDraw>& draws) {
    trunkGrid.clear();
    const RenderSettings& rs = renderSettings;
    if (treesForcedOff || !rs.trees || !rs.drawWorld || rs.treeDensity <= 0.0f || !treeModels.ready()) return;

    // Where placed objects stand (their boxes), refreshed when the scene changes.
    if (scene.revision() != treeClearRev) {
        treeClearRev = scene.revision();
        treeClears.clear();
        for (const Evaluated& e : scene.evaluated()) {
            if (!e.asset || !e.visible || e.asset->mesh.empty()) continue;
            if (!scene.objects()[size_t(e.index)].character.empty()) continue;
            glm::vec3 lo(1e9f), hi(-1e9f);
            for (int i = 0; i < 8; ++i) {
                const glm::vec3 c((i & 1) ? e.asset->boundsMax.x : e.asset->boundsMin.x, (i & 2) ? e.asset->boundsMax.y : e.asset->boundsMin.y,
                                  (i & 4) ? e.asset->boundsMax.z : e.asset->boundsMin.z);
                const glm::vec3 w = glm::vec3(e.world * glm::vec4(c, 1.0f));
                lo = glm::min(lo, w); hi = glm::max(hi, w);
            }
            treeClears.push_back({ lo, hi });
        }
    }

    const glm::vec3 cam = camera.position;
    const float reach = rs.treeDistance;
    const int threshold = int(std::lround(rs.treeDensity * 255.0f));
    for (const auto& [coord, chunk] : world.chunks()) {
        if (!chunk || chunk->trees.empty()) continue;
        const glm::vec3 centre = glm::vec3(chunk->origin()) + glm::vec3(float(CHUNK_SIZE) * 0.5f);
        if (glm::length(glm::vec2(centre.x - cam.x, centre.z - cam.z)) > reach + float(CHUNK_SIZE)) continue;
        for (const TreeInstance& t : chunk->trees) {
            if (int(t.rand) >= threshold) continue;
            const glm::vec3 base(t.x, t.y, t.z);
            const float dist = glm::length(base - cam);
            if (dist > reach) continue;
            if (rs.water && t.y < rs.waterLevel + 0.3f) continue;
            const TreeKind kind = TreeKind(std::min<int>(t.kind, kTreeKinds - 1));
            const float room = kind == TreeKind::Bush ? 0.8f : 2.2f;
            bool blocked = false;
            for (const TreeClear& c : treeClears)
                if (t.x > c.lo.x - room && t.x < c.hi.x + room && t.z > c.lo.z - room && t.z < c.hi.z + room && t.y > c.lo.y - 4.0f && t.y < c.hi.y + 1.0f) { blocked = true; break; }
            if (blocked) continue;
            AssetPtr a = treeModels.get(kind, t.variant, dist < 55.0f ? 0 : 1);
            if (!a) continue;
            ObjectDraw d;
            d.asset = std::move(a);
            d.model = glm::translate(glm::mat4(1.0f), base - glm::vec3(0.0f, 0.06f, 0.0f)) *
                      glm::rotate(glm::mat4(1.0f), float(t.yaw) / 256.0f * 6.2831853f, glm::vec3(0.0f, 1.0f, 0.0f)) *
                      glm::scale(glm::mat4(1.0f), glm::vec3(t.scale));
            d.scale = t.scale;
            d.foliage = true;
            draws.push_back(std::move(d));
            if (kind != TreeKind::Bush) trunkGrid[trunkCell(t.x, t.z)].push_back({ base, treeTrunkRadius(kind) * t.scale, treeTrunkHeight(kind) * t.scale });
        }
    }
}

float Application::trunkDensity(const glm::vec3& p) const {
    float best = 1e9f;
    for (int dz = -1; dz <= 1; ++dz)
        for (int dx = -1; dx <= 1; ++dx) {
            auto it = trunkGrid.find(trunkCell(p.x + float(dx) * 8.0f, p.z + float(dz) * 8.0f));
            if (it == trunkGrid.end()) continue;
            for (const Trunk& t : it->second) {
                const float y = std::clamp(p.y, t.base.y - 0.5f, t.base.y + t.height);
                best = std::min(best, glm::length(p - glm::vec3(t.base.x, y, t.base.z)) - t.radius);
            }
        }
    return best;
}

float Application::WorldSolids::density(const glm::vec3& p) const {
    return std::min(app->scene.density(p), app->trunkDensity(p));
}

glm::vec3 Application::WorldSolids::gradient(const glm::vec3& p) const {
    const float trunk = app->trunkDensity(p);
    if (trunk >= app->scene.density(p)) return app->scene.gradient(p);
    const float e = 0.05f;
    const glm::vec3 g(app->trunkDensity(p + glm::vec3(e, 0, 0)) - app->trunkDensity(p - glm::vec3(e, 0, 0)),
                      app->trunkDensity(p + glm::vec3(0, e, 0)) - app->trunkDensity(p - glm::vec3(0, e, 0)),
                      app->trunkDensity(p + glm::vec3(0, 0, e)) - app->trunkDensity(p - glm::vec3(0, 0, e)));
    const float l = glm::length(g);
    return l > 1e-6f ? g / l : glm::vec3(0, 1, 0);
}

} // namespace px
