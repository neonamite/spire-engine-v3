#include <map>
// The editor's frame (the 1.1 layout): the top bar, the tool strip, the status bar, the controls over the 3D view,
// the action bar above a selection, the quick wheel and the shelf.
//
// It is laid out around doing less work:
//  - Play, the tools and the menu sit against the screen edges, where the pointer can't overshoot them.
//  - Four modes (Shape, Build, People, Logic) each show only their own few tools and their own shelf.
//  - Selecting something puts its common actions right above it, where you are already looking.
//  - The shelf shows pictures of things, Recent first; every tool shows its name and key.
//  - Hold Space for the quick wheel: flick toward an action, let go.
#include "scene/BuiltinProps.h"
#include "scene/Trees.h"
#include "core/Application.h"
#include <filesystem>
#include <system_error>
#include "character/BodyParts.h"
#include "character/HumanBody.h"
#include "editor/Panels.h"
#include "scene/Thumbnail.h"
#include "rules/Gadgets.h"
#include "ui/UiKit.h"
#include <imgui_internal.h>      // viewport side bars
#include <algorithm>
#include <cctype>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>
#include <glad/glad.h>

namespace px {

using namespace ui;

namespace {

enum ShelfFilter { ShelfRecent, ShelfAll, ShelfBuildings, ShelfGadgets, ShelfItems, ShelfPeople, ShelfYours, ShelfCount };
const char* const kShelfNames[ShelfCount] = { "Recent", "All", "Building kits", "Gadgets", "Items", "People", "Made by you" };

ImTextureRef texRef(unsigned glTex) { return ImTextureRef(ImTextureID(std::uintptr_t(glTex))); }

std::string niceName(std::string s) {
    std::replace(s.begin(), s.end(), '_', ' ');
    if (!s.empty()) s[0] = char(std::toupper(static_cast<unsigned char>(s[0])));
    return s;
}

bool containsNoCase(const std::string& hay, const char* needle) {
    if (!*needle) return true;
    const size_t n = std::strlen(needle);
    for (size_t i = 0; i + n <= hay.size(); ++i) {
        size_t k = 0;
        while (k < n && std::tolower(static_cast<unsigned char>(hay[i + k])) == std::tolower(static_cast<unsigned char>(needle[k]))) ++k;
        if (k == n) return true;
    }
    return false;
}

const char* modeName(Application::EditMode m) {
    switch (m) {
    case Application::EditMode::Shape:  return "Shape";
    case Application::EditMode::Build:  return "Build";
    case Application::EditMode::People: return "People";
    case Application::EditMode::Logic:  return "Logic";
    }
    return "";
}
Icon modeIcon(Application::EditMode m) {
    switch (m) {
    case Application::EditMode::Shape:  return Icon::Mountain;
    case Application::EditMode::Build:  return Icon::House;
    case Application::EditMode::People: return Icon::User;
    case Application::EditMode::Logic:  return Icon::Bolt;
    }
    return Icon::Select;
}
const char* modeTip(Application::EditMode m) {
    switch (m) {
    case Application::EditMode::Shape:  return "Shape the ground: carve, add, smooth, flatten, paint";
    case Application::EditMode::Build:  return "Put things in the world: objects, building kits, whole houses";
    case Application::EditMode::People: return "People: place them, dress them, give them a life";
    case Application::EditMode::Logic:  return "Make it a game: gadgets, rules, goals";
    }
    return "";
}

struct ShapeTool { Tool tool; Icon icon; const char* label; const char* key; const char* tip; };
const ShapeTool kShapeTools[] = {
    { Tool::Carve,   Icon::Carve,   "Carve",   "1", "Carve: dig into the ground" },
    { Tool::Build,   Icon::Build,   "Add",     "2", "Add: build up ground in a material" },
    { Tool::Smooth,  Icon::Smooth,  "Smooth",  "3", "Smooth: soften bumps and sharp edges" },
    { Tool::Flatten, Icon::Flatten, "Flatten", "4", "Flatten: level the ground to where you click" },
    { Tool::Paint,   Icon::Paint,   "Paint",   "5", "Paint: change what the ground is made of" },
    { Tool::Stamp,   Icon::Stamp,   "Stamp",   "6", "Stamp: press a saved shape into the ground" },
    { Tool::Bake,    Icon::Bake,    "Bake",    "7", "Bake: save a sculpture as a shape to stamp" },
};

// The quick wheel's eight directions, clockwise from the top. They never move, so they become muscle memory.
struct WheelSlot { const char* label; const char* key; Icon icon; bool needsSelection; };
const WheelSlot kWheel[8] = {
    { "Place",  "P",      Icon::Box,    false },
    { "Copy",   "Ctrl D", Icon::Copy,   true  },
    { "Turn",   "E",      Icon::Rotate, true  },
    { "Resize", "R",      Icon::Scale,  true  },
    { "Focus",  "F",      Icon::Camera, true  },
    { "Paint",  "5",      Icon::Paint,  false },
    { "Move",   "W",      Icon::Move,   true  },
    { "Rules",  "",       Icon::Bolt,   true  },
};

const ImGuiWindowFlags kBarFlags = ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
                                   ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollWithMouse;
const ImGuiWindowFlags kOverlayFlags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings |
                                       ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoMove;

void pushBarStyle(ImU32 bg) {
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, bg);
}
void popBarStyle() { ImGui::PopStyleColor(); ImGui::PopStyleVar(4); }

// A dark rounded panel floating over the 3D view.
void pushOverlayStyle(float s) {
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 9 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(5 * s, 5 * s));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(2 * s, 2 * s));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1);
    ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(16, 18, 23, 236));
    ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(42, 47, 59, 255));
}
void popOverlayStyle() { ImGui::PopStyleColor(2); ImGui::PopStyleVar(4); }

void vSeparator(float s) {
    ImGui::SameLine(0, 4 * s);
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float h = ImGui::GetFrameHeight();
    ImGui::GetWindowDrawList()->AddLine(ImVec2(p.x, p.y + h * 0.22f), ImVec2(p.x, p.y + h * 0.78f), IM_COL32(42, 47, 59, 255), 1.0f);
    ImGui::Dummy(ImVec2(1, h));
    ImGui::SameLine(0, 4 * s);
}

// A text button for the overlays: an icon, a label, neon when on.
bool overlayButton(const char* id, Icon icon, const char* label, bool on, const char* tip) {
    const float s = scale();
    pushFont(fonts.small);
    const ImVec2 ts = ImGui::CalcTextSize(label);
    const float h = ImGui::GetFrameHeight();
    const float iconW = 14 * s;
    const ImVec2 size(10 * s + iconW + (label[0] ? 6 * s + ts.x : 0.0f) + 10 * s, h);
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const bool pressed = ImGui::InvisibleButton(id, size);
    const bool hov = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (on) dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), col::accentDim, 6 * s);
    else if (hov) dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), IM_COL32(255, 255, 255, 14), 6 * s);
    const ImU32 c = on ? col::accent : hov ? col::text : IM_COL32(197, 202, 214, 255);
    drawIcon(dl, icon, ImVec2(p.x + 10 * s + iconW * 0.5f, p.y + h * 0.5f), iconW, c);
    if (label[0]) dl->AddText(ImVec2(p.x + 10 * s + iconW + 6 * s, p.y + (h - ts.y) * 0.5f), c, label);
    popFont();
    if (tip && hov) ImGui::SetTooltip("%s", tip);
    return pressed;
}

// A person's portrait for the shelf: standing still, drawn by the same little rasteriser as the asset pictures.
struct PersonThumb { unsigned tex = 0; };
std::unordered_map<std::string, PersonThumb>& personThumbs() { static std::unordered_map<std::string, PersonThumb> c; return c; }

unsigned personThumbnail(Application& app, const std::string& name) {
    PersonThumb& t = personThumbs()[name];
    if (t.tex) return t.tex;
    if (!app.characters.has(name)) return 0;
    const CharacterDef def = app.characters.get(name);
    const Skeleton sk = buildSkeleton(def.shape);
    CharacterAnimator an;
    AnimInput in;
    in.position = glm::vec3(0.0f);
    in.facing = glm::vec3(0.0f, 0.0f, 1.0f);
    in.style = def.move;
    in.idleFidgets = false;
    an.reset(0.0f);
    an.update(sk, in, 0.0f);
    std::vector<ObjectDraw> draws;
    std::vector<ThumbPart> parts;
    std::vector<std::shared_ptr<Asset>> posed;              // realistic bodies, posed on the CPU, one piece per material and colour
    if (usesHumanBody(def)) {
        characterDraws(def, sk, an.output(), app.assets, draws);
        bool body = false;
        for (const ObjectDraw& d : draws) body = body || (d.skin && !d.cards);
        if (!body) return 0;                                  // not built yet (a crowd of thumbnails at once): next frame
        for (const ObjectDraw& d : draws) {
            if (d.asset) { parts.push_back({ d.asset.get(), d.model, d.tint }); continue; }
            if (!d.skin || !d.bones) continue;
            const SkinnedMesh& m = *d.skin;
            std::map<std::pair<int, std::uint32_t>, std::shared_ptr<Asset>> pieces;
            std::map<std::pair<int, std::uint32_t>, glm::vec3> tints;
            std::vector<glm::vec3> at(m.vertices.size());
            for (size_t i = 0; i < m.vertices.size(); ++i) {
                const SkinVertex& v = m.vertices[i];
                glm::mat4 k(0.0f);
                for (int j = 0; j < 4; ++j) k += (*d.bones)[v.bones[j]] * (float(v.weights[j]) / 255.0f);
                at[i] = glm::vec3(d.model * k * glm::vec4(v.v.position, 1.0f));
            }
            for (size_t t = 0; t + 2 < m.indices.size(); t += 3) {
                const SkinVertex& a = m.vertices[m.indices[t]];
                const int mode = m.extra.size() == m.vertices.size() ? int(m.extra[m.indices[t]].w + 0.5f) : 0;
                int mat = a.v.layers[0] + 1;
                glm::vec3 tint(float(a.tint[0]) / 255.0f, float(a.tint[1]) / 255.0f, float(a.tint[2]) / 255.0f);
                if (mode == int(SurfaceMode::Eye) || mode == int(SurfaceMode::Teeth)) { mat = MAT_MARBLE; tint = glm::vec3(1.0f); }
                if (mode == int(SurfaceMode::Tongue) || mode == int(SurfaceMode::Lashes)) { mat = MAT_PAINT_BLACK; tint = glm::vec3(1.0f); }
                if (mode == int(SurfaceMode::HairCard) || mat == MAT_HAIR) { mat = MAT_HAIR; tint = glm::vec3(d.hairTint); }
                const std::uint32_t key = std::uint32_t(std::lround(tint.x * 255)) << 16 | std::uint32_t(std::lround(tint.y * 255)) << 8 | std::uint32_t(std::lround(tint.z * 255));
                auto& piece = pieces[{ mat, key }];
                if (!piece) { piece = std::make_shared<Asset>(); tints[{ mat, key }] = tint; }
                for (int c = 0; c < 3; ++c) {
                    Vertex v = m.vertices[m.indices[t + size_t(c)]].v;
                    v.position = at[m.indices[t + size_t(c)]];
                    v.layers[0] = v.layers[1] = v.layers[2] = std::uint8_t(mat - 1);
                    piece->mesh.push_back(v);
                }
            }
            for (auto& [k, a] : pieces) { posed.push_back(a); parts.push_back({ a.get(), glm::mat4(1.0f), tints[k] }); }
        }
    } else {
        characterDraws(def, sk, an.output(), app.assets, draws, glm::vec4(0.0f), nullptr, true);   // separate parts: thumbnails are drawn on the CPU
        for (const ObjectDraw& d : draws) if (d.asset) parts.push_back({ d.asset.get(), d.model, d.tint });
    }
    const Thumbnail img = renderThumbnail(parts, 96, true);
    glGenTextures(1, &t.tex);
    glBindTexture(GL_TEXTURE_2D, t.tex);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, img.size, img.size, 0, GL_RGBA, GL_UNSIGNED_BYTE, img.rgba.data());
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    return t.tex;
}

} // namespace

void forgetPersonThumbnails() {
    for (auto& [_, t] : personThumbs()) if (t.tex) glDeleteTextures(1, &t.tex);
    personThumbs().clear();
}

// ============================================================== modes

void Application::setEditMode(EditMode m) {
    editMode = m;
    if (m == EditMode::Shape) {
        stopPlacing();
        if (tool == Tool::Select) tool = lastShapeTool;
    } else {
        if (tool != Tool::Select) { lastShapeTool = tool; tool = Tool::Select; }
        if (m == EditMode::People) shelfFilter = ShelfPeople;
        else if (m == EditMode::Logic) shelfFilter = ShelfGadgets;
        else if (shelfFilter == ShelfPeople || shelfFilter == ShelfGadgets) shelfFilter = ShelfAll;
    }
}

void Application::showShelf(int filter, bool focusSearch) {
    showAssets = true;
    if (filter >= 0) shelfFilter = filter;
    if (focusSearch) shelfFocusSearch = true;
    ImGui::SetWindowFocus("Shelf");
}

// ============================================================== top bar

void Application::drawTopBar() {
    const float s = scale();
    const float h = 46 * s;
    pushBarStyle(col::bar);
    ImGuiViewport* vp = ImGui::GetMainViewport();
    if (ImGui::BeginViewportSideBar("##topbar", vp, ImGuiDir_Up, h, kBarFlags | ImGuiWindowFlags_NoTitleBar)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 o = ImGui::GetWindowPos();
        const float W = ImGui::GetWindowWidth();
        dl->AddLine(ImVec2(o.x, o.y + h - 1), ImVec2(o.x + W, o.y + h - 1), col::line, 1.0f);

        // ---- the mark and the wordmark, over the tool strip
        drawSpireMark(dl, ImVec2(o.x + 32 * s, o.y + h - 9 * s), 28 * s, col::text);
        float x = 64 * s;
        pushFont(fonts.brand);
        const ImVec2 ws = ImGui::CalcTextSize("SPIRE");
        dl->AddText(ImVec2(o.x + x, o.y + (h - ws.y) * 0.5f), col::text, "SPIRE");
        popFont();
        x += ws.x + 14 * s;

        // ---- the project menu: everything File / Edit / View used to hold
        {
            const std::string name = playerMode ? playerManifest.name : gameInfo ? gameInfo->name : std::string("Sandbox");
            const ImVec2 ns = ImGui::CalcTextSize(name.c_str());
            const ImVec2 bsz(ns.x + 36 * s, 30 * s);
            ImGui::SetCursorScreenPos(ImVec2(o.x + x, o.y + (h - bsz.y) * 0.5f));
            if (ImGui::InvisibleButton("##project", bsz)) ImGui::OpenPopup("##mainmenu");
            const bool hov = ImGui::IsItemHovered(), open = ImGui::IsPopupOpen("##mainmenu");
            const ImVec2 p = ImGui::GetItemRectMin();
            if (hov || open) dl->AddRectFilled(p, ImVec2(p.x + bsz.x, p.y + bsz.y), IM_COL32(255, 255, 255, 14), 6 * s);
            dl->AddText(ImVec2(p.x + 10 * s, p.y + (bsz.y - ns.y) * 0.5f), IM_COL32(197, 202, 214, 255), name.c_str());
            drawIcon(dl, Icon::ChevronDown, ImVec2(p.x + bsz.x - 14 * s, p.y + bsz.y * 0.5f), 11 * s, col::textDim);
            if (hov && !open) ImGui::SetTooltip("Menu: files, edit, view, help");
            ImGui::SetNextWindowPos(ImVec2(p.x, o.y + h + 2 * s));
            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(8 * s, 8 * s));
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8 * s, 6 * s));
            if (ImGui::BeginPopup("##mainmenu")) { drawMainMenus(); ImGui::EndPopup(); }
            ImGui::PopStyleVar(2);
            x += bsz.x + 10 * s;
        }
        dl->AddLine(ImVec2(o.x + x, o.y + 12 * s), ImVec2(o.x + x, o.y + h - 12 * s), col::line, 1.0f);
        x += 6 * s;

        // ---- the four modes
        for (int i = 0; i < 4; ++i) {
            const EditMode m = EditMode(i);
            const char* label = modeName(m);
            pushFont(fonts.bold);
            const ImVec2 ts = ImGui::CalcTextSize(label);
            popFont();
            const ImVec2 bsz(ts.x + 16 * s + 26 * s, h - 1);
            ImGui::SetCursorScreenPos(ImVec2(o.x + x, o.y));
            ImGui::PushID(i);
            if (ImGui::InvisibleButton("##mode", bsz)) setEditMode(m);
            const bool hov = ImGui::IsItemHovered();
            if (hov) ImGui::SetTooltip("%s", modeTip(m));
            ImGui::PopID();
            const bool on = editMode == m;
            const ImVec2 p(o.x + x, o.y);
            if (on) {
                dl->AddRectFilledMultiColor(ImVec2(p.x, p.y + h * 0.35f), ImVec2(p.x + bsz.x, p.y + h - 1),
                                            IM_COL32(61, 224, 255, 0), IM_COL32(61, 224, 255, 0), IM_COL32(61, 224, 255, 30), IM_COL32(61, 224, 255, 30));
                dl->AddRectFilled(ImVec2(p.x, p.y + h - 3 * s), ImVec2(p.x + bsz.x, p.y + h - 1), col::accent);
            } else if (hov) {
                dl->AddRectFilled(p, ImVec2(p.x + bsz.x, p.y + h - 1), IM_COL32(255, 255, 255, 8));
            }
            const ImU32 c = on ? col::text : hov ? col::text : col::textDim;
            drawIcon(dl, modeIcon(m), ImVec2(p.x + 8 * s + 9 * s, p.y + h * 0.5f), 16 * s, on ? col::accent : c);
            pushFont(fonts.bold);
            dl->AddText(ImVec2(p.x + 8 * s + 24 * s, p.y + (h - ts.y) * 0.5f), c, label);
            popFont();
            x += bsz.x;
        }
        const float leftEnd = o.x + x;

        // ---- Play: dead centre of the top edge, the one fuse-coloured thing
        {
            pushFont(fonts.bold);
            const ImVec2 ps = ImGui::CalcTextSize("Play");
            popFont();
            const float keyW = keyCapWidth("Tab");
            const ImVec2 bsz(14 * s + 12 * s + 8 * s + ps.x + 8 * s + keyW + 10 * s, 32 * s);
            float bx = o.x + (W - bsz.x) * 0.5f;
            bx = std::max(bx, leftEnd + 16 * s);
            const ImVec2 p(bx, o.y + (h - bsz.y) * 0.5f);
            dl->AddRectFilled(ImVec2(p.x - 4 * s, p.y - 4 * s), ImVec2(p.x + bsz.x + 4 * s, p.y + bsz.y + 4 * s), col::bg, 10 * s);
            dl->AddRect(ImVec2(p.x - 4 * s, p.y - 4 * s), ImVec2(p.x + bsz.x + 4 * s, p.y + bsz.y + 4 * s), col::border, 10 * s);
            ImGui::SetCursorScreenPos(p);
            const bool pressed = ImGui::InvisibleButton("##play", bsz);
            const bool hov = ImGui::IsItemHovered(), held = ImGui::IsItemActive();
            for (int g = 3; g >= 1; --g)                                   // a soft glow, like a lit fuse
                dl->AddRectFilled(ImVec2(p.x - g * 3 * s, p.y - g * 3 * s), ImVec2(p.x + bsz.x + g * 3 * s, p.y + bsz.y + g * 3 * s), withAlpha(col::fuse, hov ? 0.07f : 0.04f), 8 * s + g * 3 * s);
            dl->AddRectFilled(p, ImVec2(p.x + bsz.x, p.y + bsz.y), held ? IM_COL32(232, 104, 32, 255) : hov ? IM_COL32(255, 146, 82, 255) : col::fuse, 7 * s);
            drawIcon(dl, Icon::Play, ImVec2(p.x + 14 * s + 6 * s, p.y + bsz.y * 0.5f), 13 * s, col::onFuse);
            pushFont(fonts.bold);
            dl->AddText(ImVec2(p.x + 14 * s + 12 * s + 8 * s, p.y + (bsz.y - ps.y) * 0.5f), col::onFuse, "Play");
            popFont();
            pushFont(fonts.mono);
            const ImVec2 ks = ImGui::CalcTextSize("Tab");
            dl->AddText(ImVec2(p.x + bsz.x - 10 * s - ks.x, p.y + (bsz.y - ks.y) * 0.5f), withAlpha(col::onFuse, 0.6f), "Tab");
            popFont();
            if (hov) ImGui::SetTooltip("Play your world from here  (Tab, and Tab again to come back)");
            if (pressed) setMode(Mode::Play);
        }

        // ---- right: find anything, share, settings
        {
            float rx = o.x + W - 10 * s;
            const float bh = 30 * s, by = o.y + (h - bh) * 0.5f;
            rx -= bh;
            ImGui::SetCursorScreenPos(ImVec2(rx, by));
            if (iconButton("##settings", Icon::Gear, bh, "Settings")) openSettings = true;
            pushFont(fonts.body);
            const ImVec2 ss = ImGui::CalcTextSize("Share");
            popFont();
            const float shareW = 12 * s + 14 * s + 7 * s + ss.x + 12 * s;
            rx -= shareW + 8 * s;
            ImGui::SetCursorScreenPos(ImVec2(rx, by));
            if (ImGui::InvisibleButton("##share", ImVec2(shareW, bh))) share.open = true;
            {
                const bool hov = ImGui::IsItemHovered();
                const ImVec2 p = ImGui::GetItemRectMin();
                if (hov) dl->AddRectFilled(p, ImVec2(p.x + shareW, p.y + bh), IM_COL32(255, 255, 255, 12), 7 * s);
                dl->AddRect(p, ImVec2(p.x + shareW, p.y + bh), IM_COL32(42, 47, 59, 255), 7 * s);
                drawIcon(dl, Icon::Share, ImVec2(p.x + 12 * s + 7 * s, p.y + bh * 0.5f), 14 * s, col::text);
                dl->AddText(ImVec2(p.x + 12 * s + 14 * s + 7 * s, p.y + (bh - ss.y) * 0.5f), col::text, "Share");
                if (hov) ImGui::SetTooltip("Pack your game into a folder anyone can play");
            }
            const float findW = std::min(250 * s, std::max(0.0f, rx - 8 * s - (leftEnd + 200 * s)));
            if (findW > 120 * s) {
                rx -= findW + 8 * s;
                ImGui::SetCursorScreenPos(ImVec2(rx, by));
                if (ImGui::InvisibleButton("##find", ImVec2(findW, bh))) { paletteOpen = true; paletteFocus = true; paletteQuery[0] = 0; paletteSel = 0; }
                const bool hov = ImGui::IsItemHovered();
                const ImVec2 p = ImGui::GetItemRectMin();
                dl->AddRectFilled(p, ImVec2(p.x + findW, p.y + bh), col::bg, 7 * s);
                dl->AddRect(p, ImVec2(p.x + findW, p.y + bh), hov ? IM_COL32(58, 64, 77, 255) : col::border, 7 * s);
                drawIcon(dl, Icon::Search, ImVec2(p.x + 16 * s, p.y + bh * 0.5f), 13 * s, col::faint);
                dl->AddText(ImVec2(p.x + 30 * s, p.y + (bh - ImGui::GetFontSize()) * 0.5f), col::faint, "Find anything...");
                const float kw = keyCapWidth("Ctrl K");
                keyCap(dl, ImVec2(p.x + findW - kw - 7 * s, p.y + 6 * s), "Ctrl K", col::faint);
                if (hov) ImGui::SetTooltip("Every command, tool and panel: type a few letters");
            }
        }
    }
    ImGui::End();
    popBarStyle();
}

// File / Edit / Tools / View / Game / Help, as submenus of the project menu.
void Application::drawMainMenus() {
    if (ImGui::BeginMenu("File")) {
        if (ImGui::BeginMenu("Switch Game")) {
            for (const auto& g : gameRegistry())
                if (ImGui::MenuItem(g.name.c_str(), nullptr, gameInfo == &g)) requestOpenGame(&g);
            if (ImGui::MenuItem("Empty Sandbox", nullptr, gameInfo == nullptr)) requestSandbox();
            ImGui::EndMenu();
        }
        if (ImGui::MenuItem("Back to Project Hub")) requestCloseGame();
        ImGui::Separator();
        if (ImGui::MenuItem("New Project / World Wizard...")) openNewProjectWizard();
        if (ImGui::MenuItem("New Blank Construction Canvas")) cmdNewBlankCanvas();
        if (ImGui::MenuItem("New Generated Terrain (Advanced)")) cmdNewWorld();
        if (ImGui::MenuItem("Create Planet... (Experimental)")) openPlanetCreator();
        if (ImGui::BeginMenu("Open Planet")) {
            const std::filesystem::path planetDir = "worlds/sandbox/planets";
            std::vector<std::filesystem::path> saved;
            std::error_code ec;
            for (const auto& entry : std::filesystem::directory_iterator(planetDir, ec)) {
                if (entry.is_regular_file() && entry.path().extension() == ".vxplanet")
                    saved.push_back(entry.path());
            }
            std::sort(saved.begin(), saved.end());
            if (saved.empty()) ImGui::TextDisabled("No saved planets yet");
            for (const auto& path : saved)
                if (ImGui::MenuItem(path.stem().string().c_str())) requestOpenPlanet(path.string());
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Save World", "Ctrl+S")) cmdSave();
        if (ImGui::MenuItem("Load World", "Ctrl+O")) cmdLoad();
        if (ImGui::BeginMenu("Open Autosave", !autosave.list().empty())) {
            for (const auto& a : autosave.list()) {
                char label[96];
                std::snprintf(label, sizeof label, "%s   (%.1f MB)", a.label.c_str(), double(a.bytes) / 1.0e6);
                if (ImGui::MenuItem(label)) cmdOpenAutosave(a.path);
            }
            ImGui::EndMenu();
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Screenshot", "F12")) cmdScreenshot();
        if (ImGui::MenuItem("Share Game...")) share.open = true;
        if (ImGui::MenuItem("Settings...")) openSettings = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Exit")) cmdQuit();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        if (ImGui::MenuItem("Undo", "Ctrl+Z", false, canUndo())) cmdUndo();
        if (ImGui::MenuItem("Redo", "Ctrl+Y", false, canRedo())) cmdRedo();
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicate", "Ctrl+D", false, !selection.empty())) cmdDuplicateSelection();
        if (ImGui::MenuItem("Delete", "Del", false, !selection.empty())) cmdDeleteSelection();
        if (ImGui::MenuItem("Group", "Ctrl+G", false, !selection.empty())) cmdGroupSelection();
        if (ImGui::MenuItem("Ungroup", "Ctrl+Shift+G", false, !selection.empty())) cmdUngroupSelection();
        if (ImGui::MenuItem("Select All Objects", "Ctrl+A", false, !scene.empty())) { cmdSelectAll(); tool = Tool::Select; }
        if (ImGui::MenuItem("Focus Selection", "F", false, !selection.empty())) cmdFocusSelection();
        ImGui::Separator();
        if (ImGui::MenuItem("Clear All Edits")) {
            if (world.isPlanetaryPrototype()) { world.clearPlanetEdits(); clearSceneState(); }
            else world.clearEdits();
            toast("All edits cleared");
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Tools")) {
        if (ImGui::MenuItem("Asset Workshop...", "Ctrl+Shift+W")) enterWorkshopNew();
        if (ImGui::MenuItem("Blueprint...", "B")) openBlueprintEditor();
        if (ImGui::MenuItem("Character Studio...", "Ctrl+Shift+C")) openCharacterStudio();
        if (ImGui::BeginMenu("Place a Character")) {
            for (const std::string& n : characters.names()) if (ImGui::MenuItem(n.c_str())) startPlacingCharacter(n);
            ImGui::EndMenu();
        }
        if (ImGui::MenuItem("Make a Crowd...")) crowd.open = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Game Rules...")) showGameRules = true;
        if (ImGui::BeginMenu("New Game From Template")) {
            for (int t = 0; t < int(GameTemplate::Count); ++t) {
                if (ImGui::MenuItem(gameTemplateLabel(GameTemplate(t)))) buildGameTemplate(GameTemplate(t));
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", gameTemplateHint(GameTemplate(t)));
            }
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Gadgets")) {
            for (const GadgetPreset& g : gadgetPresets()) {
                if (ImGui::MenuItem(g.label)) startPlacing(g.asset);
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", g.hint);
            }
            ImGui::EndMenu();
        }
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("View")) {
        if (ImGui::MenuItem("Find Anything...", "Ctrl+K")) { paletteOpen = true; paletteFocus = true; paletteQuery[0] = 0; paletteSel = 0; }
        ImGui::Separator();
        if (ImGui::BeginMenu("Panels")) {
            ImGui::MenuItem("Tool Strip", nullptr, &showToolbar);
            ImGui::MenuItem("Scene", nullptr, &showOutliner);
            ImGui::MenuItem("Details", nullptr, &showProperties);
            ImGui::MenuItem("World", nullptr, &showWorldPanel);
            ImGui::MenuItem("Sky", nullptr, &showEnvPanel);
            ImGui::MenuItem("Shelf", nullptr, &showAssets);
            ImGui::MenuItem("Kits", nullptr, &showKits);
            if (game) ImGui::MenuItem(game->name(), nullptr, &showGamePanel);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Layout")) {
            if (ImGui::MenuItem("Default")) applyLayout(Layout::Default);
            if (ImGui::MenuItem("Stacked (everything on the right)")) applyLayout(Layout::Stacked);
            if (ImGui::MenuItem("Two sides (Scene on the left)")) applyLayout(Layout::TwoSides);
            if (ImGui::MenuItem("Objects (Scene and Shelf on the left)")) applyLayout(Layout::Objects);
            const auto saved = savedLayouts();
            if (!saved.empty()) {
                ImGui::Separator();
                for (const auto& n : saved) if (ImGui::MenuItem(n.c_str())) loadLayout(n);
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Save Current Layout...")) openSaveLayout = true;
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Camera Bookmarks")) {
            for (int i = 0; i < EditorState::kBookmarks; ++i) {
                char label[96], key[16];
                std::snprintf(label, sizeof label, "%d  %s", i + 1, bookmarks[size_t(i)].used ? bookmarks[size_t(i)].name.c_str() : "(empty)");
                std::snprintf(key, sizeof key, "Ctrl+%d", i + 1);
                if (ImGui::MenuItem(label, key, false, bookmarks[size_t(i)].used)) gotoBookmark(i);
            }
            ImGui::Separator();
            for (int i = 0; i < EditorState::kBookmarks; ++i) {
                char label[48], key[24];
                std::snprintf(label, sizeof label, "Save view as %d", i + 1);
                std::snprintf(key, sizeof key, "Ctrl+Shift+%d", i + 1);
                if (ImGui::MenuItem(label, key)) saveBookmark(i);
            }
            ImGui::EndMenu();
        }
        ImGui::Separator();
        ImGui::MenuItem("All Shortcuts", "F1", &showShortcutList);
        if (ImGui::MenuItem("Tutorial")) startTutorial();
        ImGui::Separator();
        ImGui::MenuItem("Wireframe", nullptr, &renderSettings.wireframe);
        ImGui::MenuItem("Shadows", nullptr, &renderSettings.shadows);
        ImGui::Separator();
        if (ImGui::MenuItem("Hide All UI", "H")) uiHidden = true;
        ImGui::EndMenu();
    }
    if (game && ImGui::BeginMenu("Game")) {
        ImGui::TextDisabled("%s", game->name());
        ImGui::Separator();
        if (ImGui::MenuItem("Play", "Tab")) setMode(Mode::Play);
        game->drawGameMenu(*this);
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Help")) {
        ImGui::MenuItem("All Shortcuts", "F1", &showShortcutList);
        if (ImGui::MenuItem("Tutorial")) startTutorial();
        if (ImGui::MenuItem("About Spire Engine")) openAbout = true;
        ImGui::EndMenu();
    }
}

// ============================================================== tool strip

void Application::drawToolStrip() {
    if (!showToolbar) return;
    const float s = scale();
    const float w = 64 * s;
    // Keep the mode in step with the tool, whatever chose it (number keys, the command palette, a test).
    if (tool != Tool::Select) { lastShapeTool = tool; if (editMode != EditMode::Shape) editMode = EditMode::Shape; }
    else if (editMode == EditMode::Shape) editMode = EditMode::Build;

    pushBarStyle(col::bar);
    if (ImGui::BeginViewportSideBar("##strip", ImGui::GetMainViewport(), ImGuiDir_Left, w, kBarFlags | ImGuiWindowFlags_NoTitleBar)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 o = ImGui::GetWindowPos();
        const float H = ImGui::GetWindowHeight();
        dl->AddLine(ImVec2(o.x + w - 1, o.y), ImVec2(o.x + w - 1, o.y + H), col::line, 1.0f);
        const ImVec2 bsz(w - 1, 58 * s);
        auto selectButton = [&] {
            if (stripButton("select", Icon::Select, "Select", "V", tool == Tool::Select && placingAsset.empty() && !bp.placing, bsz,
                            "Select: click things to move, turn or resize them"))
            { stopPlacing(); tool = Tool::Select; }
        };
        switch (editMode) {
        case EditMode::Shape:
            for (const ShapeTool& t : kShapeTools)
                if (stripButton(t.label, t.icon, t.label, t.key, tool == t.tool, bsz, t.tip)) tool = t.tool;
            break;
        case EditMode::Build:
            selectButton();
            if (stripButton("place", Icon::Box, "Place", "P", !placingAsset.empty() && !placingKit(), bsz, "Place: pick something on the shelf, then click in the world"))
                showShelf(-1, true);
            if (stripButton("kits", Icon::Grid, "Kits", "K", placingKit(), bsz, "Building kits: snap-together walls, floors, roofs and stairs"))
            { showKits = true; ImGui::SetWindowFocus("Kits"); }
            if (stripButton("blueprint", Icon::Blueprint, "Blueprint", "B", bp.open, bsz, "Blueprint: draw rooms on a floor plan, get the whole building"))
                openBlueprintEditor();
            if (stripButton("workshop", Icon::Hammer, "Workshop", "", false, bsz, "Asset Workshop: build your own objects and items from fine voxels  (Ctrl+Shift+W)"))
                enterWorkshopNew();
            break;
        case EditMode::People:
            selectButton();
            if (stripButton("person", Icon::User, "Person", "", !placingCharacter.empty(), bsz, "Put a person in the world"))
                ImGui::OpenPopup("##people");
            if (stripButton("studio", Icon::Wand, "Studio", "", false, bsz, "Character Studio: faces, clothes, how they move  (Ctrl+Shift+C)"))
                openCharacterStudio();
            if (stripButton("crowd", Icon::Crowd, "Crowd", "", crowd.open, bsz, "Make a Crowd: dozens of different people in one click"))
                crowd.open = !crowd.open;
            if (ImGui::BeginPopup("##people")) {
                ImGui::TextDisabled("Click one, then click in the world");
                for (const std::string& n : characters.names()) if (ImGui::MenuItem(n.c_str())) startPlacingCharacter(n);
                ImGui::EndPopup();
            }
            break;
        case EditMode::Logic:
            selectButton();
            if (stripButton("gadgets", Icon::Pin, "Gadgets", "G", false, bsz, "Gadgets: doors, coins, plates, teleporters, each with its rules"))
                showShelf(ShelfGadgets, false);
            if (stripButton("rules", Icon::Flag, "Goal", "", showGameRules, bsz, "Game rules: the goal, time limit, lives, where you start"))
                showGameRules = !showGameRules;
            if (stripButton("templates", Icon::Wand, "Starters", "", false, bsz, "Start from a ready-made game"))
                ImGui::OpenPopup("##templates");
            if (ImGui::BeginPopup("##templates")) {
                ImGui::TextDisabled("Builds it in front of you (one undo step)");
                for (int t = 0; t < int(GameTemplate::Count); ++t) {
                    if (ImGui::MenuItem(gameTemplateLabel(GameTemplate(t)))) buildGameTemplate(GameTemplate(t));
                    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", gameTemplateHint(GameTemplate(t)));
                }
                ImGui::EndPopup();
            }
            break;
        }

        // undo and redo stay at the bottom in every mode
        const ImVec2 ub(w - 1, 48 * s);
        ImGui::SetCursorScreenPos(ImVec2(o.x, o.y + H - ub.y * 2 - 6 * s));
        ImGui::BeginDisabled(!canUndo());
        if (stripButton("undo", Icon::Undo, "Undo", "", false, ub, "Undo  (Ctrl+Z)")) cmdUndo();
        ImGui::EndDisabled();
        ImGui::BeginDisabled(!canRedo());
        if (stripButton("redo", Icon::Redo, "Redo", "", false, ub, "Redo  (Ctrl+Y)")) cmdRedo();
        ImGui::EndDisabled();
    }
    ImGui::End();
    popBarStyle();
}

// ============================================================== status bar

void Application::drawStatusBar() {
    const float s = scale();
    const ImGuiIO& io = ImGui::GetIO();
    const float h = 24 * s;
    pushBarStyle(col::bg);
    if (ImGui::BeginViewportSideBar("##status", ImGui::GetMainViewport(), ImGuiDir_Down, h, kBarFlags | ImGuiWindowFlags_NoTitleBar)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        const ImVec2 o = ImGui::GetWindowPos();
        const float W = ImGui::GetWindowWidth();
        dl->AddLine(o, ImVec2(o.x + W, o.y), col::line, 1.0f);
        pushFont(fonts.mono);
        const float ty = o.y + (h - ImGui::GetFontSize()) * 0.5f;
        float x = o.x + 12 * s;
        auto put = [&](const std::string& t, ImU32 c) {
            dl->AddText(ImVec2(x, ty), c, t.c_str());
            x += ImGui::CalcTextSize(t.c_str()).x + 18 * s;
        };
        std::string where = std::string(modeName(editMode));
        const char* toolName = tool == Tool::Select ? (!placingAsset.empty() ? "Placing" : "Select") : kShapeTools[std::min(int(tool), 6)].label;
        where += std::string(" \xC2\xB7 ") + toolName;
        for (char& c : where) c = char(std::toupper(static_cast<unsigned char>(c)));
        put(where, col::accent);
        if (game) put(game->name(), col::textDim);
        if (!selection.empty()) put(std::to_string(selection.size()) + " selected", col::textDim);
        dl->PushClipRect(ImVec2(x, o.y), ImVec2(o.x + W * 0.62f, o.y + h), true);
        put(status, IM_COL32(197, 202, 214, 255));
        dl->PopClipRect();

        char right[200];
        std::snprintf(right, sizeof right, "%s    %.0f fps    %zu chunks%s    %.2fM tris    %.0f, %.0f, %.0f",
                      timeOfDayText().c_str(), double(io.Framerate), world.chunks().size(), world.pendingCount() ? " (loading)" : "",
                      renderer.triangleCount() / 1.0e6, double(camera.position.x), double(camera.position.y), double(camera.position.z));
        const float rw = ImGui::CalcTextSize(right).x;
        dl->AddText(ImVec2(o.x + W - rw - 12 * s, ty), col::faint, right);
        popFont();
    }
    ImGui::End();
    popBarStyle();
}

// ============================================================== over the 3D view

void Application::drawViewportControls() {
    const float s = scale();
    // ---- top-left: snapping, axes, camera
    ImGui::SetNextWindowPos(ImVec2(viewRect.x + 10 * s, viewRect.y + 10 * s));
    pushOverlayStyle(s);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(6 * s, 5 * s));
    if (ImGui::Begin("##viewctl", nullptr, kOverlayFlags)) {
      if (editMode != EditMode::Shape) {             // snapping, axes and motion are about objects
        char snapLabel[32];
        std::snprintf(snapLabel, sizeof snapLabel, gizmoSnap.on ? "Snap %g m" : "Snap", double(gizmoSnap.move));
        if (overlayButton("##snap", Icon::Magnet, snapLabel, gizmoSnap.on, "Round moves, turns and sizes to neat steps (right-click for the steps)"))
            gizmoSnap.on = !gizmoSnap.on;
        if (ImGui::IsItemClicked(ImGuiMouseButton_Right)) ImGui::OpenPopup("##snapsteps");
        if (ImGui::BeginPopup("##snapsteps")) {
            ImGui::TextDisabled("Snap steps");
            static const float moves[] = { 0.25f, 0.5f, 1.0f, 2.0f, 4.0f };
            for (float m : moves) { char l[32]; std::snprintf(l, sizeof l, "Move %g m", double(m)); if (ImGui::MenuItem(l, nullptr, std::fabs(gizmoSnap.move - m) < 1e-3f)) { gizmoSnap.move = m; gizmoSnap.on = true; } }
            ImGui::Separator();
            static const float turns[] = { 5.0f, 15.0f, 45.0f, 90.0f };
            for (float t : turns) { char l[32]; std::snprintf(l, sizeof l, "Turn %g\xC2\xB0", double(t)); if (ImGui::MenuItem(l, nullptr, std::fabs(gizmoSnap.rotate - t) < 1e-3f)) { gizmoSnap.rotate = t; gizmoSnap.on = true; } }
            ImGui::Separator();
            static const float sizes[] = { 0.1f, 0.25f, 0.5f };
            for (float z : sizes) { char l[32]; std::snprintf(l, sizeof l, "Size %gx", double(z)); if (ImGui::MenuItem(l, nullptr, std::fabs(gizmoSnap.scale - z) < 1e-3f)) { gizmoSnap.scale = z; gizmoSnap.on = true; } }
            ImGui::EndPopup();
        }
        ImGui::SameLine();
        if (overlayButton("##axes", Icon::Globe, gizmoSpace == GizmoSpace::World ? "World axes" : "Own axes", false,
                          "Move along the world's axes or the object's own  (X)"))
            gizmoSpace = gizmoSpace == GizmoSpace::World ? GizmoSpace::Local : GizmoSpace::World;
        ImGui::SameLine();
        if (overlayButton("##motion", Icon::Play, "Motion", previewMotion, "Preview motion: things that move, move as they will when you play"))
        { previewMotion = !previewMotion; sceneClock = 0.0; }
        vSeparator(s);
      }
        if (overlayButton("##cam", Icon::Camera, "Camera", ImGui::IsPopupOpen("##campop"), "Fly speed, field of view, saved views")) ImGui::OpenPopup("##campop");
        ImGui::SetNextWindowSize(ImVec2(300 * s, 0));
        if (ImGui::BeginPopup("##campop")) {
            if (beginProps("##camprops", 96)) {
                prop("Fly speed", "Hold Shift to fly 3x faster");
                sliderFloat("##fly", &flySpeed, 5.0f, 150.0f, "%.0f m/s");
                prop("Field of view");
                if (sliderFloat("##fov", &settings.fov, 50.0f, 110.0f, "%.0f deg")) applySettings();
                endProps();
            }
            section("Saved views");
            pushFont(fonts.small);
            ImGui::TextDisabled("Ctrl+1..9 flies there. Ctrl+Shift+1..9 saves this view.");
            popFont();
            for (int i = 0; i < EditorState::kBookmarks; ++i) {
                CameraBookmark& b = bookmarks[size_t(i)];
                ImGui::PushID(i);
                char label[80];
                std::snprintf(label, sizeof label, "%d   %s", i + 1, b.used ? b.name.c_str() : "empty");
                if (b.used) { if (ImGui::Selectable(label, false, ImGuiSelectableFlags_NoAutoClosePopups)) gotoBookmark(i); }
                else { ImGui::TextDisabled("%s", label); ImGui::SameLine(ImGui::GetContentRegionMax().x - ImGui::CalcTextSize("Save here").x - 4 * s); if (ImGui::SmallButton("Save here")) saveBookmark(i); }
                ImGui::PopID();
            }
            ImGui::EndPopup();
        }
    }
    ImGui::End();
    ImGui::PopStyleVar();
    popOverlayStyle();

    // ---- top-right: which way is which (drawn, not clickable)
    {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        const float r = 26 * s;
        const ImVec2 c(viewRect.x + viewRect.w - r - 14 * s, viewRect.y + r + 12 * s);
        dl->AddCircleFilled(c, r + 2 * s, IM_COL32(11, 12, 16, 150), 32);
        const glm::vec3 f = camera.front(), rt = camera.right(), up = glm::normalize(glm::cross(rt, f));
        struct Ax { int i; float depth; ImVec2 tip; };
        Ax ax[3];
        for (int i = 0; i < 3; ++i) {
            glm::vec3 a(0.0f); a[i] = 1.0f;
            ax[i] = { i, glm::dot(a, f), ImVec2(c.x + glm::dot(a, rt) * r * 0.78f, c.y - glm::dot(a, up) * r * 0.78f) };
        }
        std::sort(ax, ax + 3, [](const Ax& a, const Ax& b) { return a.depth > b.depth; });   // far ones first
        pushFont(fonts.bold);
        const float fs = ImGui::GetFontSize() * 0.66f;
        for (const Ax& a : ax) {
            const ImU32 colr = axisColour(a.i);
            dl->AddLine(c, a.tip, colr, 2.0f * s);
            dl->AddCircleFilled(a.tip, 6.5f * s, colr, 16);
            const char* n = a.i == 0 ? "X" : a.i == 1 ? "Y" : "Z";
            const ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0, n);
            dl->AddText(ImGui::GetFont(), fs, ImVec2(a.tip.x - ts.x * 0.5f, a.tip.y - ts.y * 0.5f), IM_COL32(12, 12, 16, 255), n);
        }
        popFont();
    }

    // ---- bottom-left: the few keys worth knowing (F1 lists them all)
    if (!showShortcutList && !tutorial.active) {
        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        struct Chip { const char* key; const char* what; };
        const Chip chipsSelect[] = { { "Space", "hold for quick wheel" }, { "F", "focus" }, { "F1", "all shortcuts" } };
        const Chip chipsBrush[] = { { "Wheel", "brush size" }, { "Ctrl Z", "undo" }, { "F1", "all shortcuts" } };
        const Chip* chips = tool == Tool::Select ? chipsSelect : chipsBrush;
        float x = viewRect.x + 10 * s;
        const float y = viewRect.y + viewRect.h - 34 * s;
        for (int i = 0; i < 3; ++i) {
            pushFont(fonts.small);
            const ImVec2 ts = ImGui::CalcTextSize(chips[i].what);
            popFont();
            const float kw = keyCapWidth(chips[i].key);
            const float w = 8 * s + kw + 7 * s + ts.x + 10 * s;
            dl->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + 26 * s), IM_COL32(11, 12, 16, 200), 6 * s);
            keyCap(dl, ImVec2(x + 8 * s, y + 4 * s), chips[i].key, col::text);
            pushFont(fonts.small);
            dl->AddText(ImVec2(x + 8 * s + kw + 7 * s, y + (26 * s - ts.y) * 0.5f), IM_COL32(197, 202, 214, 255), chips[i].what);
            popFont();
            x += w + 6 * s;
        }
    }
}

// The common actions for what is selected, floating just above it.
void Application::drawContextBar() {
    if (tool != Tool::Select || selection.empty() || !placingAsset.empty() || bp.placing || looking || gizmo.dragging() || wheel.open) return;
    const float s = scale();
    const GizmoView v = gizmoView();
    float minX = FLT_MAX, minY = FLT_MAX, maxX = -FLT_MAX;
    bool any = false;
    for (ObjectId id : selectionRoots()) {
        glm::vec3 mn, mx;
        if (!scene.worldBounds(id, mn, mx)) continue;
        for (int i = 0; i < 8; ++i) {
            glm::vec2 p;
            if (!v.project(glm::vec3(i & 1 ? mx.x : mn.x, i & 2 ? mx.y : mn.y, i & 4 ? mx.z : mn.z), p)) continue;
            minX = std::min(minX, p.x); maxX = std::max(maxX, p.x); minY = std::min(minY, p.y);
            any = true;
        }
    }
    if (!any) return;
    const SceneObject* primary = scene.find(primaryObject());
    if (!primary) return;

    const float barH = 42 * s;
    float cx = (minX + maxX) * 0.5f;
    float top = minY - barH - 14 * s;
    top = std::clamp(top, viewRect.y + 52 * s, viewRect.y + viewRect.h - barH - 60 * s);
    ImGui::SetNextWindowPos(ImVec2(std::clamp(cx, viewRect.x + 160 * s, viewRect.x + viewRect.w - 160 * s), top), ImGuiCond_Always, ImVec2(0.5f, 0.0f));
    pushOverlayStyle(s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 10 * s);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6 * s, 6 * s));
    if (ImGui::Begin("##contextbar", nullptr, kOverlayFlags)) {
        const float b = 30 * s;
        // whose bar this is
        {
            std::string label = primary->name;
            if (selectionRoots().size() > 1) label += "  +" + std::to_string(selectionRoots().size() - 1);
            pushFont(fonts.bold);
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + (b - ImGui::GetFontSize()) * 0.5f);
            ImGui::TextUnformatted(label.c_str());
            popFont();
            ImGui::SameLine(0, 8 * s);
            ImGui::SetCursorPosY(ImGui::GetStyle().WindowPadding.y);
        }
        vSeparator(s);
        if (iconButton("##m", Icon::Move, b, "Move  (W)", gizmoMode == GizmoMode::Move)) cmdSetGizmoMode(GizmoMode::Move);
        ImGui::SameLine();
        if (iconButton("##r", Icon::Rotate, b, "Turn  (E)", gizmoMode == GizmoMode::Rotate)) cmdSetGizmoMode(GizmoMode::Rotate);
        ImGui::SameLine();
        if (iconButton("##s", Icon::Scale, b, "Resize  (R)", gizmoMode == GizmoMode::Scale)) cmdSetGizmoMode(GizmoMode::Scale);
        vSeparator(s);
        if (iconButton("##d", Icon::Copy, b, "Duplicate  (Ctrl+D)")) cmdDuplicateSelection();
        if (selection.size() > 1) { ImGui::SameLine(); if (iconButton("##g", Icon::Open, b, "Group  (Ctrl+G)")) cmdGroupSelection(); }
        if (!primary->isGroup()) {
            ImGui::SameLine();
            if (overlayButton("##rules", Icon::Bolt, "Rules", false, "What it does when something happens")) { showProperties = true; openRulesFold = true; ImGui::SetWindowFocus("Details"); }
        }
        ImGui::SameLine();
        if (iconButton("##f", Icon::Camera, b, "Focus  (F)")) cmdFocusSelection();
        vSeparator(s);
        if (iconButton("##x", Icon::Trash, b, "Delete  (Del)", false, col::danger)) cmdDeleteSelection();
    }
    ImGui::End();
    ImGui::PopStyleVar(2);
    popOverlayStyle();
}

// ============================================================== quick wheel

void Application::drawQuickWheel() {
    if (!wheel.open) return;
    if (mode != Mode::Editor || looking) { wheel.open = false; return; }
    const float s = scale();
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const ImVec2 c(wheel.x, wheel.y);
    const float r0 = 44 * s, r1 = 132 * s, rl = 90 * s;
    const float dx = mouseX - wheel.x, dy = mouseY - wheel.y;
    const float dist = std::sqrt(dx * dx + dy * dy);
    wheel.hover = -1;
    if (dist > r0 * 0.7f) {
        float a = std::atan2(dy, dx) + 3.14159265f * 0.5f;                 // 0 = up, clockwise
        if (a < 0) a += 6.2831853f;
        wheel.hover = int(std::floor((a + 0.3926991f) / 0.7853982f)) % 8;
        if (kWheel[wheel.hover].needsSelection && selection.empty()) wheel.hover = -1;
    }
    dl->AddCircleFilled(c, r1 + 40 * s, IM_COL32(7, 8, 11, 110), 64);
    for (int i = 0; i < 8; ++i) {
        const float mid = (-90.0f + i * 45.0f) * 3.14159265f / 180.0f, half = 20.5f * 3.14159265f / 180.0f;
        const bool on = wheel.hover == i;
        const bool off = kWheel[i].needsSelection && selection.empty();
        dl->PathArcTo(c, r1, mid - half, mid + half, 16);
        dl->PathArcTo(c, r0, mid + half, mid - half, 8);
        dl->PathFillConcave(on ? IM_COL32(61, 224, 255, 56) : IM_COL32(16, 18, 23, 236));
        dl->PathArcTo(c, r1, mid - half, mid + half, 16);
        dl->PathArcTo(c, r0, mid + half, mid - half, 8);
        dl->PathStroke(on ? col::accent : IM_COL32(42, 47, 59, 255), ImDrawFlags_Closed, 1.5f * s);
        const ImVec2 lc(c.x + std::cos(mid) * rl, c.y + std::sin(mid) * rl);
        const ImU32 tc = off ? withAlpha(col::textDim, 0.45f) : on ? col::accent : col::text;
        drawIcon(dl, kWheel[i].icon, ImVec2(lc.x, lc.y - 10 * s), 16 * s, tc);
        pushFont(fonts.bold);
        const ImVec2 ts = ImGui::CalcTextSize(kWheel[i].label);
        dl->AddText(ImVec2(lc.x - ts.x * 0.5f, lc.y + 2 * s), tc, kWheel[i].label);
        popFont();
        if (kWheel[i].key[0]) {
            pushFont(fonts.mono);
            const float fs = ImGui::GetFontSize() * 0.78f;
            const ImVec2 ks = ImGui::GetFont()->CalcTextSizeA(fs, FLT_MAX, 0, kWheel[i].key);
            dl->AddText(ImGui::GetFont(), fs, ImVec2(lc.x - ks.x * 0.5f, lc.y + 2 * s + ts.y + 1 * s), off ? withAlpha(col::faint, 0.5f) : col::faint, kWheel[i].key);
            popFont();
        }
    }
    dl->AddCircleFilled(c, r0 - 6 * s, IM_COL32(16, 18, 23, 245), 40);
    dl->AddCircle(c, r0 - 6 * s, IM_COL32(42, 47, 59, 255), 40, 1.5f * s);
    pushFont(fonts.small);
    const SceneObject* p = scene.find(primaryObject());
    const char* mid = p ? p->name.c_str() : "Nothing selected";
    const ImVec2 ms = ImGui::CalcTextSize(mid);
    const float maxW = (r0 - 10 * s) * 2;
    dl->PushClipRect(ImVec2(c.x - maxW * 0.5f, c.y - 20 * s), ImVec2(c.x + maxW * 0.5f, c.y + 20 * s), true);
    dl->AddText(ImVec2(c.x - std::min(ms.x, maxW) * 0.5f, c.y - ms.y * 0.5f), p ? col::text : col::textDim, mid);
    dl->PopClipRect();
    popFont();
    if (wheel.hover >= 0) dl->AddLine(c, ImVec2(mouseX, mouseY), withAlpha(col::accent, 0.7f), 2.0f * s);
}

void Application::quickWheelAction(int slot) {
    if (slot < 0 || slot >= 8) return;
    switch (slot) {
    case 0: setEditMode(EditMode::Build); showShelf(-1, true); break;
    case 1: cmdDuplicateSelection(); break;
    case 2: tool = Tool::Select; cmdSetGizmoMode(GizmoMode::Rotate); break;
    case 3: tool = Tool::Select; cmdSetGizmoMode(GizmoMode::Scale); break;
    case 4: cmdFocusSelection(); break;
    case 5: tool = Tool::Paint; break;
    case 6: tool = Tool::Select; cmdSetGizmoMode(GizmoMode::Move); break;
    case 7: showProperties = true; openRulesFold = true; ImGui::SetWindowFocus("Details"); break;
    default: break;
    }
}

// ============================================================== shelf

void Application::drawShelf() {
    if (!beginPanel("Shelf", &showAssets, settleFront("Shelf") || shelfFront > 0)) return;
    const float s = scale();

    // ---- filters and search on one line
    for (int f = 0; f < ShelfCount; ++f) {
        if (f) ImGui::SameLine(0, 4 * s);
        if (chip(kShelfNames[f], shelfFilter == f)) shelfFilter = f;
    }
    {
        const float sw = std::min(220 * s, ImGui::GetContentRegionAvail().x - 40 * s);
        ImGui::SameLine(std::max(ImGui::GetCursorPosX() + 8 * s, ImGui::GetWindowContentRegionMax().x - sw));
        if (shelfFocusSearch) { ImGui::SetKeyboardFocusHere(); shelfFocusSearch = false; }
        ImGui::SetNextItemWidth(sw);
        ImGui::InputTextWithHint("##shelfsearch", "Search the shelf", shelfSearch, sizeof shelfSearch);
    }
    ImGui::Dummy(ImVec2(0, 2 * s));

    // ---- what goes on it
    struct Card { std::string name; bool person; };
    std::vector<Card> cards;
    const bool searching = shelfSearch[0] != 0;
    auto matches = [&](const std::string& n) { return containsNoCase(n, shelfSearch) || containsNoCase(niceName(n), shelfSearch); };
    if (shelfFilter == ShelfPeople) {
        for (const std::string& n : characters.names()) if (matches(n)) cards.push_back({ n, true });
    } else if (shelfFilter == ShelfRecent) {
        for (const std::string& n : recentAssets) if (assets.get(n) && matches(n)) cards.push_back({ n, false });
    } else if (shelfFilter == ShelfGadgets) {
        for (const GadgetPreset& g : gadgetPresets()) if (matches(g.asset) || containsNoCase(g.label, shelfSearch)) cards.push_back({ g.asset, false });
    } else {
        for (const std::string& n : assets.names()) {
            if (!matches(n)) continue;
            const bool kit = kitRoleOfAsset(n) != KitRole::None;
            const bool gadget = gadgetFor(n) != nullptr;
            const bool item = itemLibrary.findByAsset(n) != nullptr;
            bool keep = false;
            switch (shelfFilter) {
            case ShelfAll:       keep = searching ? true : (!assets.isGenerated(n) || gadget || isBuiltinProp(n) || isTreeProp(n)); break;
            case ShelfBuildings: keep = kit; break;
            case ShelfItems:     keep = item; break;
            case ShelfYours:     keep = assets.isUserMade(n); break;
            default: break;
            }
            if (keep) cards.push_back({ n, false });
        }
    }

    const float gap = 10 * s;
    const float thumb = 84 * s, labelH = ImGui::GetFontSize() + 8 * s;
    const float cardW = thumb;
    const float availW = ImGui::GetContentRegionAvail().x;
    const int cols = std::max(1, int((availW + gap) / (cardW + gap)));
    std::string stampFor, editWorkshopFor, tryItem;
    ImGui::BeginChild("##shelfgrid", ImVec2(0, 0), ImGuiChildFlags_None);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    int shown = 0;
    for (const Card& c : cards) {
        if (shown % cols) ImGui::SameLine(0, gap);
        ++shown;
        ImGui::PushID(c.name.c_str());
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const bool placing = c.person ? placingCharacter == c.name : placingAsset == c.name;
        if (ImGui::InvisibleButton("##card", ImVec2(cardW, thumb + labelH))) {
            if (c.person) startPlacingCharacter(c.name);
            else if (placing) stopPlacing();
            else startPlacing(c.name);
        }
        const bool hov = ImGui::IsItemHovered();
        const ImVec2 a = p, b(p.x + thumb, p.y + thumb);
        dl->AddRectFilled(a, b, IM_COL32(24, 27, 34, 255), 8 * s);
        if (c.person) {
            if (const unsigned tex = personThumbnail(*this, c.name))
                dl->AddImageRounded(texRef(tex), ImVec2(a.x + 2 * s, a.y + 2 * s), ImVec2(b.x - 2 * s, b.y - 2 * s), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 7 * s);
            else drawIcon(dl, Icon::User, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), thumb * 0.42f, hov || placing ? col::text : col::textDim);
        } else if (const unsigned tex = assetThumbnailTexture(*this, c.name)) {
            dl->AddImageRounded(texRef(tex), ImVec2(a.x + 2 * s, a.y + 2 * s), ImVec2(b.x - 2 * s, b.y - 2 * s), ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 7 * s);
        }
        dl->AddRect(a, b, placing ? col::accent : hov ? IM_COL32(92, 98, 114, 255) : col::border, 8 * s, 0, placing ? 2.0f * s : 1.0f);
        if (!c.person && assets.isUserMade(c.name)) {                       // made in the Workshop
            dl->AddCircleFilled(ImVec2(a.x + 13 * s, a.y + 13 * s), 9 * s, IM_COL32(11, 12, 16, 215));
            drawIcon(dl, Icon::Hammer, ImVec2(a.x + 13 * s, a.y + 13 * s), 11 * s, col::accent);
        }
        const ItemDef* item = c.person ? nullptr : itemLibrary.findByAsset(c.name);
        if (item) {
            dl->AddCircleFilled(ImVec2(b.x - 13 * s, a.y + 13 * s), 9 * s, IM_COL32(11, 12, 16, 215));
            dl->AddCircle(ImVec2(b.x - 13 * s, a.y + 13 * s), 4.5f * s, col::warning, 16, 1.6f * s);
        }
        const GadgetPreset* gp = c.person ? nullptr : gadgetFor(c.name);
        std::string label = gp ? std::string(gp->label) : niceName(c.name);
        pushFont(fonts.small);
        dl->PushClipRect(ImVec2(p.x, p.y), ImVec2(p.x + cardW, p.y + thumb + labelH), true);
        dl->AddText(ImVec2(p.x + 1 * s, b.y + 5 * s), placing ? col::accent : hov ? col::text : IM_COL32(197, 202, 214, 255), label.c_str());
        dl->PopClipRect();
        popFont();
        if (hov) {
            ImGui::BeginTooltip();
            pushFont(fonts.bold); ImGui::TextUnformatted(label.c_str()); popFont();
            if (gp) ImGui::TextDisabled("%s", gp->hint);
            if (!c.person) if (AssetPtr ap = assets.get(c.name))
                ImGui::TextDisabled("%.1f x %.1f x %.1f m", double(ap->extent().x), double(ap->extent().y), double(ap->extent().z));
            if (item) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s: %s", item->name.c_str(), behaviourName(item->behaviour));
            ImGui::TextDisabled(placing ? "Click to stop placing" : "Click, then click in the world to put it there");
            ImGui::EndTooltip();
        }
        if (!c.person && ImGui::BeginPopupContextItem("##cardctx")) {
            if (ImGui::MenuItem("Place in the world")) startPlacing(c.name);
            if (ImGui::MenuItem("Stamp into the ground")) stampFor = c.name;
            if (item && ImGui::MenuItem("Try it in the world")) tryItem = item->name;
            ImGui::Separator();
            if (ImGui::MenuItem(assets.isUserMade(c.name) ? "Edit in the Asset Workshop" : "Make my own version in the Workshop")) editWorkshopFor = c.name;
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    if (!shown) {
        ImGui::Dummy(ImVec2(0, 8 * s));
        if (shelfFilter == ShelfRecent && !searching) ImGui::TextDisabled("Nothing placed yet. Things you put in the world show up here first.");
        else if (shelfFilter == ShelfYours && !searching) ImGui::TextDisabled("Nothing made yet. The Asset Workshop (Build > Workshop) is where you make your own.");
        else ImGui::TextDisabled("Nothing here matches.");
    }
    ImGui::EndChild();
    ImGui::End();

    if (!stampFor.empty()) { stampPrefab = stampFor; tool = Tool::Stamp; stopPlacing(); }
    if (!editWorkshopFor.empty()) editAssetInWorkshop(editWorkshopFor);
    if (!tryItem.empty()) startPlayingWith(tryItem);
}

} // namespace px
