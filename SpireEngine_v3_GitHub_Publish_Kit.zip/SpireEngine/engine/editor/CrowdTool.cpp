// Make a crowd (v0.19): pick a style (villagers, city folk, soldiers, a sci-fi crew, fantasy folk), how many and how
// spread out, and click. Everyone is a different person - their own body, face, clothes, hat, way of walking and name -
// made from a number, so the world saves just "crowd:villagers:1042" and they come back exactly the same.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "character/BodyParts.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <imgui.h>

namespace px {

using namespace ui;

glm::vec3 Application::crowdCentre() const {
    if (cursorHitValid) return cursorHit.position;
    const glm::vec3 ahead = camera.position + camera.flatFront() * (crowd.radius + 5.0f);
    return glm::vec3(ahead.x, demospot::groundHeight(world, ahead.x, ahead.z), ahead.z);
}

std::vector<ObjectId> Application::makeCrowd(CrowdStyle style, int count, const glm::vec3& centre, float radius, std::uint32_t firstSeed) {
    std::vector<ObjectId> ids;
    if (!assets.get(kCharacterStandIn)) return ids;
    const std::vector<glm::vec2> spots = crowdSpots(count, radius, firstSeed);
    for (size_t i = 0; i < spots.size(); ++i) {
        const std::uint32_t seed = firstSeed + std::uint32_t(i);
        const std::string name = crowdName(style, seed);
        const CharacterDef def = characters.get(name);
        const float x = centre.x + spots[i].x, z = centre.z + spots[i].y;
        SceneObject o;
        o.asset = kCharacterStandIn;
        o.character = name;
        o.name = def.name;
        o.position = glm::vec3(x, demospot::groundHeight(world, x, z), z);
        // most face roughly the middle (a crowd gathers), some look elsewhere
        const glm::vec2 in = -spots[i];
        float yaw = glm::length(in) > 0.3f ? glm::degrees(std::atan2(in.x, in.y)) : float(seed % 360u);
        yaw += float(int(seed * 2654435761u >> 8) % 90 - 45);
        o.rotation = glm::vec3(0.0f, yaw, 0.0f);
        o.scale = def.shape.height / 1.8f;
        ids.push_back(scene.add(o));
    }
    if (!ids.empty()) {
        char label[96];
        std::snprintf(label, sizeof label, "Make a crowd of %d %s", int(ids.size()), crowdStyleLabel(style));
        commitScene(label);
        setSelection(ids);
        playSfxAt("stamp", centre, 0.8f, 1.0f);
    }
    return ids;
}

void Application::drawCrowdWindow() {
    if (!crowd.open) return;
    const float s = scale();
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowSize(ImVec2(360 * s, 0), ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.5f, vp->WorkPos.y + 90 * s), ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.0f));
    if (!ImGui::Begin("Make a Crowd###crowdtool", &crowd.open, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::End();
        return;
    }
    ImGui::TextWrapped("Everyone is a different person: their own body, face, clothes and way of walking.");
    ImGui::Spacing();
    ImGui::TextUnformatted("Who");
    for (int i = 0; i < int(CrowdStyle::Count); ++i) {
        if (i % 3) ImGui::SameLine(0, 4 * s);
        const bool on = crowd.style == i;
        if (on) pushSelectedButton();
        char label[48];
        std::snprintf(label, sizeof label, "%s##crowdstyle%d", crowdStyleLabel(CrowdStyle(i)), i);
        if (ImGui::Button(label, ImVec2(108 * s, 0))) crowd.style = i;
        if (on) popSelectedButton();
    }
    ImGui::Spacing();
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderInt("##crowdcount", &crowd.count, 2, 60, "%d people");
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##crowdradius", &crowd.radius, 1.5f, 25.0f, "spread over %.1f m");
    // a taste of who you will get
    ImGui::TextDisabled("For example: %s, %s, %s...", personName(crowd.nextSeed).c_str(), personName(crowd.nextSeed + 1).c_str(),
                        personName(crowd.nextSeed + 2).c_str());
    ImGui::Spacing();
    const glm::vec3 at = crowdCentre();
    if (ImGui::Button("Make the crowd", ImVec2(-1, 34 * s))) {
        crowd.last = makeCrowd(CrowdStyle(crowd.style), crowd.count, at, crowd.radius, crowd.nextSeed);
        crowd.nextSeed += std::uint32_t(crowd.count) + 7;
        toast(crowd.last.empty() ? std::string("No room for a crowd there") : "Made " + std::to_string(crowd.last.size()) + " people.  Select one to edit them in the Character Studio.",
              crowd.last.empty() ? Toast::Kind::Warning : Toast::Kind::Success);
    }
    bool lastAlive = !crowd.last.empty();
    for (ObjectId id : crowd.last) lastAlive = lastAlive && scene.find(id);
    if (!lastAlive) ImGui::BeginDisabled();
    if (ImGui::Button("Try again with different people", ImVec2(-1, 0)) && lastAlive) {
        glm::vec3 c(0.0f);
        for (ObjectId id : crowd.last) c += scene.find(id)->position;
        c /= float(crowd.last.size());
        for (ObjectId id : crowd.last) scene.remove(id);
        crowd.last = makeCrowd(CrowdStyle(crowd.style), crowd.count, c, crowd.radius, crowd.nextSeed);
        crowd.nextSeed += std::uint32_t(crowd.count) + 7;
    }
    if (!lastAlive) ImGui::EndDisabled();
    ImGui::TextDisabled(cursorHitValid ? "They go where the cursor points." : "They go in front of you.");
    ImGui::End();
}

} // namespace px
