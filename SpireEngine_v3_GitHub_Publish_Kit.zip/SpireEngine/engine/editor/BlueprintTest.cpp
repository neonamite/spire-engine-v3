// --demo bp_...: screenshots of the Blueprint Tool (v0.17), and a self test that drives the real editor code (the same functions
// the plan window, the mouse and the keys reach) and prints "[bptest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include "editor/Panels.h"
#include <cmath>
#include <filesystem>
#include <iostream>
#include <string>

namespace px {

namespace {

const Blueprint& preset(const std::string& name) {
    for (const Blueprint& b : blueprintPresets()) if (b.name == name) return b;
    return blueprintPresets().front();
}

template <class Cam>
void aimAt(Cam& cam, const glm::vec3& from, const glm::vec3& at) {
    const glm::vec3 d = at - from;
    cam.position = from;
    cam.yaw = glm::degrees(std::atan2(d.z, d.x));
    cam.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
}

// A level spot on the 2 m grid and the ground there.
glm::vec3 gridSpot(const ChunkManager& world, float dx = 0.0f, float dz = 0.0f) {
    const glm::vec3 c = demospot::calmSpot(world);
    const float x = std::round((c.x + dx) / kKitCell) * kKitCell, z = std::round((c.z + dz) / kKitCell) * kKitCell;
    return glm::vec3(x, std::round(demospot::groundHeight(world, x, z) * 4.0f) / 4.0f, z);
}

} // namespace

void Application::setupBlueprintDemo() {
    if (demo == "bp_selftest") { runBlueprintSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.5f; timeFlowing = false;
    showHints = false;
    toasts.clear();

    if (demo == "bp_editor" || demo == "bp_upstairs" || demo == "bp_shop") {
        // The window with a plan in it, over the world.
        openBlueprintEditor();
        bpLoadPlan(preset(demo == "bp_shop" ? "Corner shop" : "Family house"), "");
        bp.undo.clear();
        bp.level = demo == "bp_upstairs" ? 1 : 0;
        bp.tool = demo == "bp_upstairs" ? BpTool::Door : BpTool::Room;
        bp.room = 1;
        const glm::vec3 g = gridSpot(world);
        aimAt(camera, g + glm::vec3(0.0f, 14.0f, 26.0f), g);
        toasts.clear();
        return;
    }
    if (demo == "bp_place") {
        // Placing: the ghost of the whole building following the cursor, the footprint, the hint.
        bp.started = true;
        bp.plan = preset("Family house");
        const glm::vec3 c = demospot::calmSpot(world);
        const glm::vec3 g = gridSpot(world, 0.0f, -20.0f);
        aimAt(camera, glm::vec3(c.x + 6.0f, std::max(c.y, g.y) + 9.0f, c.z + 2.0f), g + glm::vec3(0.0f, 1.0f, 0.0f));
        bpStartPlacing();
        glm::vec2 sp;
        if (gizmoView().project(g, sp)) { mouseX = sp.x; mouseY = sp.y; }
        toasts.clear();
        return;
    }
    if (demo == "bp_house" || demo == "bp_inside" || demo == "bp_dollhouse") {
        // The calm spot is level for forty metres towards -z: the house goes there, the camera stands on the spot.
        const Blueprint plan = preset("Family house");
        const glm::vec3 c = demospot::calmSpot(world);
        const glm::vec3 g = gridSpot(world, -float(plan.width), -24.0f);
        const glm::vec3 centre = g + glm::vec3(float(plan.width), 0.0f, float(plan.depth));
        world.flatten(glm::vec3(centre.x, g.y + 0.1f, centre.z + 6.0f), 28.0f);      // a garden in front of it, so the camera sees it whole
        bpBuild(plan, g, 0, 0, true);
        (void)c;
        if (demo == "bp_house") aimAt(camera, centre + glm::vec3(9.0f, 4.5f, 17.0f), centre + glm::vec3(0.0f, 2.6f, 0.0f));
        else if (demo == "bp_inside") {                       // in the living room, looking at the stairs
            aimAt(camera, g + glm::vec3(1.0f, 1.7f, 7.3f), g + glm::vec3(5.0f, 1.9f, 2.0f));
        } else {                                              // roofs and the top floor hidden: the rooms and the stairs from above
            for (const SceneObject& o : scene.objects())
                if (!o.isGroup()) {
                    const KitRole r = kitRoleOfAsset(o.asset);
                    if (r == KitRole::Roof || o.position.y > g.y + kKitStorey - 0.1f) scene.mutate(o.id)->visible = false;
                }
            aimAt(camera, centre + glm::vec3(2.0f, 12.0f, 8.0f), centre + glm::vec3(0.0f, 0.5f, 0.0f));
        }
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
    if (demo == "bp_street") {
        // A row of the ready-made plans, built with the real code, in their own kits, across the calm spot's view.
        const char* names[] = { "Cottage", "Corner shop", "Family house", "L-shaped house", "Watchtower" };
        const glm::vec3 c = demospot::calmSpot(world);
        const glm::vec3 g0 = gridSpot(world, 0.0f, -26.0f);
        world.flatten(glm::vec3(g0.x, g0.y + 0.1f, g0.z), 34.0f);
        float width = 0.0f;
        for (const char* n : names) width += float(preset(n).width) * 2.0f + 4.0f;
        float x = -width * 0.5f;
        for (const char* n : names) {
            const Blueprint plan = preset(n);
            const glm::vec3 spot(std::round((g0.x + x) / kKitCell) * kKitCell, g0.y, std::round((g0.z - float(plan.depth) * 2.0f) / kKitCell) * kKitCell + 4.0f);
            bpBuild(plan, spot, 0, 0, false);
            x += float(plan.width) * 2.0f + 4.0f;
        }
        aimAt(camera, glm::vec3(g0.x, g0.y + 9.0f, c.z + 10.0f), g0 + glm::vec3(0.0f, 2.0f, 0.0f));
        uiHidden = true; cursorHitValid = false; mouseX = mouseY = -1000.0f;
        return;
    }
}

void Application::runBlueprintSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[bptest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto groupChildren = [&](ObjectId g) { return scene.children(g).size(); };
    auto key = [&](SDL_Keycode k, SDL_Keymod mod = SDL_KMOD_NONE) {           // through the real event handler
        SDL_SetModState(mod);
        SDL_Event e{};
        e.type = SDL_EVENT_KEY_DOWN;
        e.key.key = k;
        e.key.mod = mod;
        e.key.down = true;
        e.key.repeat = false;
        handleEvent(e);
        SDL_SetModState(SDL_KMOD_NONE);
    };

    setMode(Mode::Editor);
    tool = Tool::Select;
    uiHidden = false;
    stopPlacing();
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    bp = BlueprintEditor{};

    // ---- opening the window
    key(SDLK_B, SDL_KMOD_CTRL);
    check(bp.open && bp.started && !bp.plan.empty(), "Ctrl+B opens the Blueprint window with a ready-made plan in it");
    check(bp.plan.name == "Family house", "...the family house");

    // ---- drawing a plan
    bpLoadPlan(Blueprint{}, "");
    check(bp.plan.empty() && bp.undo.size() == 1, "New gives an empty plan, and the old one can come back");
    bp.plan.resize(6, 4);
    bpPaintRect(0, { 0, 0 }, { 2, 3 }, 0);
    check(bp.plan.rooms.size() == 1 && bp.plan.cellCount(0, 1) == 12 && bp.room == 1, "dragging a rectangle makes a room");
    check(bp.plan.roomName(1) == "Living room", "...with a name to start with");
    bpPaintRect(0, { 3, 0 }, { 5, 1 }, 0);
    check(bp.plan.rooms.size() == 2 && bp.plan.cellCount(0, 2) == 6 && bp.room == 2, "another drag makes another room, and picks it");
    bp.room = 2;
    bpPaintRect(0, { 3, 2 }, { 4, 3 }, 1);
    check(bp.plan.cellCount(0, 2) == 10 && bp.plan.rooms.size() == 2, "Shift+drag adds cells to the picked room");
    bpPaintRect(0, { 4, 3 }, { 4, 3 }, 2);
    check(bp.plan.cellCount(0) == 21, "erasing takes cells out");
    const size_t undoSteps = bp.undo.size();
    bpUndo();
    check(bp.plan.cellCount(0) == 22 && bp.redo.size() == 1, "the plan has its own undo");
    bpRedo();
    check(bp.plan.cellCount(0) == 21 && bp.undo.size() == undoSteps, "...and redo");
    bpPaintRect(0, { 3, 0 }, { 5, 3 }, 2);
    bpPaintRect(0, { 3, 0 }, { 5, 3 }, 2);
    check(bp.plan.rooms.size() == 1, "a room that loses all its cells is forgotten");
    bpUndo();
    check(bp.plan.rooms.size() == 2, "...and comes back with undo");
    bpRefreshPreview();
    check(bp.preview.count(KitRole::Doorway) == 2 && bp.preview.warnings.empty(), "the plan already shows a front door and a door between the rooms");

    // ---- edges and stairs
    bpChange();
    bpSetEdge(0, 0, 0, 0, BpEdge::Door);
    bpRefreshPreview();
    check(bp.preview.count(KitRole::Doorway) == 2, "a door drawn by hand replaces the automatic front door");
    bpChange();
    bp.plan.setStoreys(2);
    bpRefreshPreview();
    check(bp.plan.storeys() == 2 && bp.preview.count(KitRole::Stairs) == 1, "a second storey gets stairs by itself");
    bpToggleStairs(0, 0, 0, 1);
    bpRefreshPreview();
    check(bp.plan.levels[0].stairs.size() == 1 && bp.preview.stairs.size() == 1 && !bp.preview.stairs[0].automatic, "stairs drawn by hand are used instead");
    bpToggleStairs(0, 0, 1, 1);
    check(bp.plan.levels[0].stairs.empty(), "clicking them again takes them away");
    bpToggleStairs(1, 0, 0, 1);
    check(bp.plan.levels[1].stairs.empty(), "there are no stairs up from the top storey");
    toasts.clear();

    // ---- placing it in the world
    const glm::vec3 g = gridSpot(world, 0.0f, -12.0f);
    world.flatten(glm::vec3(g.x, g.y + 0.1f, g.z), 22.0f);
    undoLog.clear(); redoLog.clear();
    auto lookDown = [&](const glm::vec3& at) {
        camera.position = at + glm::vec3(0.0f, 30.0f, 0.0f);
        camera.yaw = -90.0f; camera.pitch = -89.0f;
        updateObjects(0.0f);
        glm::vec2 sp;
        const bool ok = gizmoView().project(at, sp);
        mouseX = sp.x; mouseY = sp.y;
        return ok;
    };
    bp.levelGround = true;
    bpStartPlacing();
    check(bp.placing && placingAsset.empty(), "Place in the world starts placing the building");
    drawBlueprintWindow();
    check(!bp.windowFocused, "...and the window steps out of the way");
    check(lookDown(g), "the cursor is on the ground");
    updateObjects(0.0f);
    check(bp.spotValid, "the building follows the cursor");
    check(std::fmod(std::fabs(bp.spot.x), 2.0f) < 1e-3f && std::fmod(std::fabs(bp.spot.z), 2.0f) < 1e-3f, "...on the 2 m grid");
    check(std::fabs(bp.spot.x + 6.0f - g.x) <= 2.01f && std::fabs(bp.spot.z + 4.0f - g.z) <= 2.01f, "...centred on the cursor");
    check(bp.ghost.pieces.size() > 40 && bp.ghost.footprint == glm::ivec2(6, 4), "the ghost is the whole building");
    key(SDLK_R);
    updateObjects(0.0f);
    check(bp.turns == 1 && bp.ghost.footprint == glm::ivec2(4, 6), "R turns it a quarter");
    key(SDLK_R, SDL_KMOD_SHIFT);
    updateObjects(0.0f);
    check(bp.turns == 0, "Shift+R turns it back");
    const size_t ghostPieces = bp.ghost.pieces.size();
    const size_t before = scene.size();
    bpClickBuild(false);
    ObjectId house = 0;
    for (const SceneObject& o : scene.objects()) if (o.isGroup() && !o.blueprint.empty()) house = o.id;
    check(house != 0 && scene.size() == before + 1 + ghostPieces, "a click builds it: a Building group and every piece");
    check(house && groupChildren(house) == ghostPieces, "...all inside the group");
    check(!bp.placing && bp.target == house, "...placing stops, and the plan now belongs to that building");
    check(undoLog.size() == 2 && undoLog.back() == 'S' && undoLog.front() == 'T', "levelling the ground and building are two undo steps");
    check(kitGroup == house && kitBaseSet && std::fabs(kitBaseY - bp.spot.y) < 1e-3f && kitStyle == bp.plan.style, "the Kits panel carries on with this building");
    {
        bool onGrid = true, styled = true;
        for (ObjectId c : scene.children(house)) {
            const SceneObject* o = scene.find(c);
            std::string st;
            styled = styled && kitRoleOfAsset(o->asset, &st) != KitRole::None && st == bp.plan.style;
            if (kitRoleOfAsset(o->asset) == KitRole::Floor) onGrid = onGrid && std::fabs(std::fmod(std::fabs(o->position.x), 2.0f) - 1.0f) < 1e-3f;
        }
        check(styled, "every piece comes from the plan's kit");
        check(onGrid, "...and sits on the kit grid");
    }
    cmdUndo();
    check(!scene.find(house), "Ctrl+Z takes the building away in one go");
    cmdRedo();
    check(scene.find(house) && groupChildren(house) == ghostPieces, "...and Ctrl+Y puts it back");

    // ---- editing it later
    const ObjectId aPiece = scene.children(house).front();
    check(blueprintBuildingOf(aPiece) == house && blueprintBuildingOf(house) == house, "any piece leads back to its building's plan");
    const Blueprint built = bp.plan;
    bpLoadPlan(Blueprint{}, "");
    bp.target = 0;
    editBuildingBlueprint(aPiece);
    check(bp.target == house && bp.plan == built && bp.open, "Edit the building's blueprint opens its plan");
    bpChange();
    bp.plan.windows = BpWindows::None;
    bp.plan.style = "Stone keep";
    const size_t undoBefore = undoLog.size();
    check(bpRebuildTarget(), "Rebuild puts the new plan in its place");
    check(scene.find(house) && undoLog.size() == undoBefore + 1 && scene.undoLabel().rfind("Rebuild", 0) == 0, "...as one undo step, in the same group");
    {
        int windows = 0, keep = 0;
        for (ObjectId c : scene.children(house)) {
            std::string st;
            const KitRole r = kitRoleOfAsset(scene.find(c)->asset, &st);
            if (r == KitRole::Window) ++windows;
            if (st == "Stone keep") ++keep;
        }
        check(windows == 0 && keep == int(groupChildren(house)), "...with no windows, in stone");
    }
    cmdUndo();
    {
        std::string st;
        kitRoleOfAsset(scene.find(scene.children(house).front())->asset, &st);
        check(st == built.style && groupChildren(house) == ghostPieces, "undo gives the old building back");
    }
    cmdRedo();

    // ---- it survives saving
    {
        Scene again;
        check(again.fromText(scene.toText()), "the scene with the building saves as text");
        const SceneObject* g2 = again.find(house);
        Json j;
        Blueprint plan;
        check(g2 && Json::parse(g2->blueprint, j) && blueprintFromJson(j, plan) && plan.style == "Stone keep", "...and its plan comes back with it");
    }

    // ---- moving the group, then rebuilding, keeps it where it was moved to
    {
        scene.mutate(house)->position += glm::vec3(10.0f, 0.0f, 0.0f);
        commitScene("Move");
        updateObjects(0.0f);
        glm::vec3 mn1, mx1; scene.worldBounds(house, mn1, mx1);
        editBuildingBlueprint(house);
        bpRebuildTarget();
        updateObjects(0.0f);
        glm::vec3 mn2, mx2; scene.worldBounds(house, mn2, mx2);
        check(glm::length(mn1 - mn2) < 0.05f, "a building that was moved is rebuilt where it is now");
    }

    // ---- restyling works on blueprint buildings too
    {
        const int n = restyleObjects(kitBuildingOf(aPiece == 0 ? house : scene.children(house).front()), "Sci-fi");
        check(n == int(groupChildren(house)), "the Kits panel's Whole building swap changes every piece");
    }

    // ---- Esc while placing goes back to the plan
    bpStartPlacing();
    key(SDLK_ESCAPE);
    check(!bp.placing && bp.open, "Esc while placing goes back to the plan");
    // Shift+click keeps placing
    bp.target = 0;
    bp.levelGround = false;
    bpStartPlacing();
    lookDown(g + glm::vec3(0.0f, 0.0f, 30.0f));
    updateObjects(0.0f);
    const size_t groupsBefore = [&] { size_t n = 0; for (const SceneObject& o : scene.objects()) if (!o.blueprint.empty()) ++n; return n; }();
    bpClickBuild(true);
    size_t groupsAfter = 0;
    for (const SceneObject& o : scene.objects()) if (!o.blueprint.empty()) ++groupsAfter;
    check(groupsAfter == groupsBefore + 1 && bp.placing, "Shift+click builds one and keeps placing another");
    check(undoLog.back() == 'S' && undoLog[undoLog.size() - 2] != 'T', "...without levelling when that is turned off");
    bpStopPlacing();

    // ---- the plan's undo never touches the world, and the world's never touches the plan
    {
        const size_t sceneSize = scene.size();
        const Blueprint now = bp.plan;
        bpChange(); bp.plan.name = "Changed";
        bpUndo();
        check(scene.size() == sceneSize && bp.plan == now, "undoing the plan leaves the world alone");
        cmdUndo();
        check(bp.plan == now, "undoing the world leaves the plan alone");
        cmdRedo();
    }

    // ---- files
    {
        std::string err;
        const std::string path = "blueprints/bp_selftest.pxblueprint";
        Blueprint saved = bp.plan; saved.name = "bp selftest";
        check(saveBlueprintFile(saved, path, &err), "the plan saves as a .pxblueprint file");
        Blueprint loaded;
        check(loadBlueprintFile(path, loaded, &err) && loaded == saved, "...and opens again the same");
        std::error_code ec;
        std::filesystem::remove(path, ec);
    }

    std::cerr << "[bptest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
