// --demo game_...: screenshots of game rules and the starter templates (v0.22), and a self test that builds every
// template and plays it through (collecting, falling, checkpoints, capturing, being caught, running out of time) and
// prints "[gametest] ok / FAIL" lines.
#include "core/Application.h"
#include "core/DemoSpot.h"
#include <cmath>
#include <iostream>
#include <string>

namespace px {

void Application::setupGameDemo() {
    if (demo == "game_selftest") { runGameSelfTest(); return; }
    setMode(Mode::Editor);
    scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
    timeOfDay = 10.0f; timeFlowing = false;
    showHints = false;
    const glm::vec3 c = demospot::calmSpot(world);
    camera.position = c + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    GameTemplate t = GameTemplate::Parkour;
    if (demo == "game_coinhunt") t = GameTemplate::CoinHunt;
    if (demo == "game_ctf" || demo == "game_ctfplay") t = GameTemplate::CaptureTheFlag;
    if (demo == "game_survival") t = GameTemplate::Survival;
    buildGameTemplate(t);
    toasts.clear();
    if (demo == "game_rules" || demo == "game_ctf") {
        // the editor: the template from above, with the Game Rules window open
        const GameRules g = gameRulesOf();
        camera.position = g.spawn + glm::vec3(-14.0f, 16.0f, -6.0f);
        const glm::vec3 d = (g.spawn + glm::vec3(std::cos(glm::radians(g.spawnYaw)), 0.0f, std::sin(glm::radians(g.spawnYaw))) * 14.0f) - camera.position;
        camera.yaw = glm::degrees(std::atan2(d.z, d.x)); camera.pitch = glm::degrees(std::atan2(d.y, std::sqrt(d.x * d.x + d.z * d.z)));
        showGameRules = demo == "game_rules";
        for (int i = 0; i < 6; ++i) updateObjects(1.0f / 30.0f);
        return;
    }
    // play it a little
    setMode(Mode::Play);
    for (int i = 0; i < (t == GameTemplate::Survival ? 140 : 40); ++i) update(1.0f / 30.0f);
    if (t == GameTemplate::Parkour) {
        // look up the tower
        camera.pitch = 8.0f;
    }
    npcsFrozen = true;
    toasts.clear();
}

void Application::runGameSelfTest() {
    int fails = 0;
    auto check = [&](bool ok, const std::string& what) { std::cerr << "[gametest] " << (ok ? "ok   " : "FAIL ") << what << "\n"; if (!ok) ++fails; };
    auto key = [&](SDL_Keycode k) { SDL_Event e{}; e.type = SDL_EVENT_KEY_DOWN; e.key.key = k; e.key.down = true; handleEvent(e); };
    auto standAt = [&](const glm::vec3& p, int frames) {
        for (int i = 0; i < frames; ++i) { player.position = p; player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); }
    };
    auto fresh = [&]() {
        setMode(Mode::Editor);
        scene.clear(); scene.resetHistory(); selection.clear(); undoLog.clear(); redoLog.clear();
        const glm::vec3 c = demospot::calmSpot(world);
        camera.position = c + glm::vec3(0.0f, 1.7f, 0.0f); camera.yaw = -90.0f; camera.pitch = 0.0f;
    };
    auto objectsCalled = [&](const std::string& asset) {
        std::vector<ObjectId> out;
        for (const SceneObject& o : scene.objects()) if (o.asset == asset) out.push_back(o.id);
        return out;
    };
    auto top = [&](ObjectId id) {
        glm::vec3 mn, mx;
        scene.worldBounds(id, mn, mx);
        return glm::vec3((mn.x + mx.x) * 0.5f, mx.y + 0.02f, (mn.z + mx.z) * 0.5f);
    };
    timeOfDay = 10.0f; timeFlowing = false;

    // ---- Coin Hunt: everything to collect, against the clock
    fresh();
    buildGameTemplate(GameTemplate::CoinHunt);
    const size_t coins = objectsCalled("gadget coin").size() + objectsCalled("gadget gem").size();
    GameRules g = gameRulesOf();
    check(coins >= 15 && g.goal == GameGoal::CollectAll && g.timeLimit > 0.0f && g.hasSpawn, "Coin Hunt: coins and gems to find, a clock, a start");
    const size_t built = scene.size();
    cmdUndo();
    check(scene.empty() && scene.gameRules().empty(), "one Ctrl+Z takes the whole template away");
    cmdRedo();
    check(scene.size() == built && gameRulesOf().goal == GameGoal::CollectAll, "...and Ctrl+Y brings it back");
    setMode(Mode::Play);
    standAt(g.spawn, 2);
    check(gameState.collectTotal == int(coins) && !gameOver && glm::length(glm::vec2(player.position.x - g.spawn.x, player.position.z - g.spawn.z)) < 0.05f, "playing: you start at the start, with everything to find");
    for (ObjectId id : objectsCalled("gadget coin")) standAt(glm::vec3(scene.find(id)->position) + glm::vec3(0, 0.0f, 0), 2);
    check(!gameOver && gameState.collected == int(objectsCalled("gadget coin").size()), "collecting the coins...");
    for (ObjectId id : objectsCalled("gadget gem")) standAt(glm::vec3(scene.find(id)->position), 2);
    check(gameOver && gameWon && gameOverText == "You found everything!", "...and the gems: you win");

    // ---- running out of time
    fresh();
    {
        GameRules quick; quick.goal = GameGoal::Points; quick.points = 50; quick.timeLimit = 2.0f;
        setGameRules(quick, "Quick");
        setMode(Mode::Play);
        for (int i = 0; i < 70; ++i) update(1.0f / 30.0f);
        check(gameOver && !gameWon && gameOverText == "Out of time!", "a 2 second limit runs out: you lose");
        key(SDLK_R);
        update(1.0f / 30.0f);
        check(!gameOver && gameState.time < 0.1f, "R: again, the clock starts over");
    }

    // ---- Parkour: start on top, fall back to the last checkpoint, reach the flag
    fresh();
    buildGameTemplate(GameTemplate::Parkour);
    g = gameRulesOf();
    check(g.goal == GameGoal::Finish && g.fallLimit > 0.0f && objectsCalled("gadget finish flag").size() == 1, "Parkour: blocks to the flag, falling sends you back");
    setMode(Mode::Play);
    standAt(g.spawn, 2);
    const glm::vec3 spawnAt = g.spawn;
    for (int i = 0; i < 10; ++i) { player.position = spawnAt - glm::vec3(0.0f, 12.0f, 0.0f); player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); if (glm::length(player.position - spawnAt) < 0.5f) break; }
    check(glm::length(player.position - spawnAt) < 0.5f && !gameOver, "fall off: back at the start");
    ObjectId checkpoint = 0;
    for (const SceneObject& o : scene.objects()) if (o.name == "Checkpoint 1") checkpoint = o.id;
    standAt(top(checkpoint), 3);
    check(checkpoint && glm::length(gameState.restart - top(checkpoint)) < 0.6f, "touch a checkpoint: that is where you go back to now");
    for (int i = 0; i < 10; ++i) { player.position = spawnAt - glm::vec3(0.0f, 30.0f, 0.0f); player.velocity = glm::vec3(0.0f); update(1.0f / 30.0f); if (glm::length(player.position - gameState.restart) < 0.5f) break; }
    check(glm::length(player.position - gameState.restart) < 0.5f && glm::length(player.position - spawnAt) > 1.0f, "fall again: back at the checkpoint");
    standAt(top(objectsCalled("gadget finish flag")[0]) - glm::vec3(0.45f, 1.0f, 0.0f), 3);
    check(gameOver && gameWon, "reach the flag: you win");

    // ---- Capture the Flag: take theirs, bring it home; the guards catch you
    fresh();
    buildGameTemplate(GameTemplate::CaptureTheFlag);
    g = gameRulesOf();
    ObjectId theirs = 0, base = 0;
    std::vector<ObjectId> guards;
    for (const SceneObject& o : scene.objects()) {
        if (o.name == "Their flag") theirs = o.id;
        if (o.name == "Home base") base = o.id;
        if (!o.character.empty()) guards.push_back(o.id);
    }
    check(theirs && base && guards.size() == 3 && g.lives == 3, "Capture the Flag: their flag, your base, three guards, three lives");
    setMode(Mode::Play);
    standAt(g.spawn, 2);
    check(ruleEngine.hidden(base), "your base only shows once you have their flag");
    // caught: walk up to a guard
    const glm::vec3 guardAt = glm::vec3(scene.evaluatedFor(guards[0])->world[3]);
    standAt(guardAt + glm::vec3(1.2f, 0.0f, 0.0f), 1);
    check(gameState.lives == 2 && glm::length(glm::vec2(player.position.x - gameState.restart.x, player.position.z - gameState.restart.z)) < 0.5f, "a guard catches you: a life lost, back to base");
    // take the flag (the guards are busy elsewhere for the test)
    npcsFrozen = true;
    standAt(top(theirs) - glm::vec3(0.45f, 2.9f, 0.0f), 2);
    check(ruleEngine.hidden(theirs) && !ruleEngine.hidden(base), "touch their flag: you have it, and your base appears");
    standAt(top(base), 2);
    check(gameOver && gameWon && gameOverText == "Flag captured!", "bring it home: flag captured");
    npcsFrozen = false;

    // ---- Survival: hunters, a clock that wins
    fresh();
    buildGameTemplate(GameTemplate::Survival);
    g = gameRulesOf();
    int hunters = 0;
    for (const SceneObject& o : scene.objects()) if (!o.character.empty() && npcSettingsOf(o.id).role == NpcRole::Guard) ++hunters;
    check(g.goal == GameGoal::Survive && g.timeLimit == 90.0f && hunters == 4, "Survival: four hunters, 90 seconds");
    {
        GameRules quick = g; quick.timeLimit = 3.0f;
        setGameRules(quick, "Quick");
    }
    setMode(Mode::Play);
    standAt(g.spawn, 2);
    float closest = 1e9f;
    for (int i = 0; i < 100 && !gameOver; ++i) {
        player.position = g.spawn; player.velocity = glm::vec3(0.0f);
        update(1.0f / 30.0f);
        for (const SceneObject& o : scene.objects())
            if (!o.character.empty()) if (const Evaluated* e = scene.evaluatedFor(o.id)) closest = std::min(closest, glm::length(glm::vec3(e->world[3]) - g.spawn));
    }
    check(closest < 16.0f, "the hunters come for you");
    check(gameOver && gameWon && gameOverText == "You survived!", "last until the clock runs out: you survived");

    // ---- Sandbox: no rules
    setMode(Mode::Editor);
    buildGameTemplate(GameTemplate::Sandbox);
    check(scene.gameRules().empty(), "Sandbox: the game rules are gone, the objects stay");
    setMode(Mode::Editor);
    std::cerr << "[gametest] " << (fails == 0 ? "ALL OK" : "FAILED") << " (" << fails << " failures)\n";
}

} // namespace px
