// Project Hub: the first screen of the engine. The live world keeps rendering behind it with a slow camera orbit.
//
// Built so the first click is the obvious one: "Start something" puts a playable starting point in front of you
// in one click; your games sit below with Play (fuse) and Open side by side. Making a game in C++ is a quiet link
// at the bottom, for the people who want it.
#include "core/Application.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cfloat>
#include <cstdio>
#include <filesystem>
#include <vector>
#include <system_error>
#include <string>

namespace px {

using namespace ui;

namespace {

const ImGuiWindowFlags kOverlay = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                                  ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoBringToFrontOnFocus;

void sectionLabel(const char* text) {
    pushFont(fonts.mono);
    ImGui::PushStyleColor(ImGuiCol_Text, col::faint);
    ImGui::TextUnformatted(text);
    ImGui::PopStyleColor();
    popFont();
    ImGui::Dummy(ImVec2(0, 2 * scale()));
}

// A "start something" tile: an icon, a name, a line about it. Returns true when clicked.
bool startTile(const char* id, Icon icon, const char* name, const char* blurb, ImVec2 size, bool lead) {
    const float s = scale();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const bool clicked = ImGui::InvisibleButton(id, size);
    const bool hov = ImGui::IsItemHovered();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), hov ? IM_COL32(27, 30, 38, 245) : IM_COL32(19, 21, 27, 235), 10 * s);
    dl->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), hov ? col::accent : lead ? withAlpha(col::accent, 0.45f) : col::border, 10 * s, 0, hov ? 1.5f * s : 1.0f);
    const float badge = 34 * s;
    const ImVec2 bp(p.x + 16 * s, p.y + 16 * s);
    dl->AddRectFilled(bp, ImVec2(bp.x + badge, bp.y + badge), hov || lead ? col::accentDim : IM_COL32(255, 255, 255, 10), 8 * s);
    drawIcon(dl, icon, ImVec2(bp.x + badge * 0.5f, bp.y + badge * 0.5f), badge * 0.52f, hov || lead ? col::accent : col::textDim);
    pushFont(fonts.bold);
    dl->AddText(ImVec2(p.x + 16 * s, bp.y + badge + 12 * s), col::text, name);
    popFont();
    pushFont(fonts.small);
    dl->AddText(nullptr, 0.0f, ImVec2(p.x + 16 * s, bp.y + badge + 32 * s), col::textDim, blurb, nullptr, size.x - 32 * s);
    popFont();
    return clicked;
}

// One of your games. Returns 1 = open in the editor, 2 = play.
int gameCard(const char* id, const char* name, const char* tagline, ImU32 accent, ImVec2 size, bool canPlay) {
    const float s = scale();
    int result = 0;
    ImGui::PushID(id);
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const bool hov = ImGui::IsMouseHoveringRect(p, ImVec2(p.x + size.x, p.y + size.y));
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), IM_COL32(19, 21, 27, 240), 12 * s);
    dl->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), hov ? IM_COL32(58, 64, 77, 255) : col::border, 12 * s);
    dl->AddRectFilled(ImVec2(p.x + 18 * s, p.y + 20 * s), ImVec2(p.x + 22 * s, p.y + 44 * s), accent, 2 * s);          // the game's own colour
    pushFont(fonts.title);
    dl->AddText(ImVec2(p.x + 32 * s, p.y + 22 * s), col::text, name);
    popFont();
    dl->AddText(nullptr, 0.0f, ImVec2(p.x + 18 * s, p.y + 56 * s), col::textDim, tagline, nullptr, size.x - 36 * s);

    const float bh = 34 * s;
    const float inner = size.x - 36 * s;
    const float bw = canPlay ? (inner - 8 * s) * 0.5f : inner;
    const ImVec2 row(p.x + 18 * s, p.y + size.y - bh - 18 * s);
    ImGui::SetCursorScreenPos(row);
    if (canPlay) {
        const ImVec2 pp = ImGui::GetCursorScreenPos();
        if (fuseButton("##play", ImVec2(bw, bh))) result = 2;
        pushFont(fonts.bold);
        const float tw = ImGui::CalcTextSize("Play").x + 20 * s;
        const float x0 = pp.x + (bw - tw) * 0.5f;
        drawIcon(dl, Icon::Play, ImVec2(x0 + 6 * s, pp.y + bh * 0.5f), ImGui::GetFontSize() * 0.75f, col::onFuse);
        dl->AddText(ImVec2(x0 + 18 * s, pp.y + (bh - ImGui::GetFontSize()) * 0.5f), col::onFuse, "Play");
        popFont();
        ImGui::SetCursorScreenPos(ImVec2(row.x + bw + 8 * s, row.y));
    }
    pushFont(fonts.bold);
    if (ImGui::Button("Open in editor", ImVec2(bw, bh))) result = 1;
    popFont();
    ImGui::SetCursorScreenPos(p);
    ImGui::Dummy(size);
    ImGui::PopID();
    return result;
}

} // namespace

void Application::drawHubUI() {
    const ImGuiIO& io = ImGui::GetIO();
    const float s = scale();
    const ImVec2 ds = io.DisplaySize;

    // Darken the left side so text reads over the live world.
    ImDrawList* bg = ImGui::GetBackgroundDrawList();
    const float fade = std::min(ds.x, 1180 * s);
    bg->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(fade, ds.y), IM_COL32(11, 12, 16, 248), IM_COL32(11, 12, 16, 90), IM_COL32(11, 12, 16, 90), IM_COL32(11, 12, 16, 248));
    if (ds.x > fade) bg->AddRectFilled(ImVec2(fade, 0), ds, IM_COL32(11, 12, 16, 90));

    const float pad = 64 * s;
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ds);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(pad, 48 * s));
    ImGui::Begin("##hub", nullptr, kOverlay);
    ImDrawList* dl = ImGui::GetWindowDrawList();

    // ---- the mark and the name
    {
        const ImVec2 p = ImGui::GetCursorScreenPos();
        drawSpireMark(dl, ImVec2(p.x + 14 * s, p.y + 58 * s), 58 * s, col::text);
        ImGui::PushFont(fonts.brand, 44 * s);
        dl->AddText(ImVec2(p.x + 44 * s, p.y + 4 * s), col::text, "SPIRE");
        popFont();
        pushFont(fonts.mono);
        char line[96];
        std::snprintf(line, sizeof line, "ENGINE  \xC2\xB7  %s  \xC2\xB7  BLACK SPIRE STUDIOS", kEngineVersion);
        dl->AddText(ImVec2(p.x + 46 * s, p.y + 56 * s), col::faint, line);
        popFont();
        ImGui::Dummy(ImVec2(0, 96 * s));
    }

    const float contentW = std::min(ds.x - pad * 2, 1080 * s);

    // ---- creator-first entry: manual sculpting and asset placement lead; generation is optional
    sectionLabel("WORLD BUILDER  /  START CREATING");
    if (ImGui::Button("+ New Project / World Wizard", ImVec2(315 * s, 44 * s))) openNewProjectWizard();
    ImGui::Dummy(ImVec2(0, 12 * s));
    {
        struct Start { Icon icon; const char* name; const char* blurb; int tmpl; };
        const Start starts[] = {
            { Icon::Mountain, "Blank World Builder", "Start on flat land. Sculpt, paint, and construct.", -2 },
            { Icon::Flag,     "Parkour",          "A run of platforms to a finish flag.",               int(GameTemplate::Parkour) },
            { Icon::Pin,      "Coin Hunt",        "Coins hidden around; collect them all to win.",      int(GameTemplate::CoinHunt) },
            { Icon::Crowd,    "Capture the Flag", "Take their flag home before they take yours.",       int(GameTemplate::CaptureTheFlag) },
            { Icon::Bolt,     "Survival",         "Hunters close in. Last until the clock runs out.",   int(GameTemplate::Survival) },
        };
        const int n = int(sizeof starts / sizeof starts[0]);
        const float gap = 12 * s;
        const int cols = std::max(2, std::min(n, int((contentW + gap) / (180 * s + gap))));
        const float tw = (contentW - gap * (cols - 1)) / cols;
        for (int i = 0; i < n; ++i) {
            if (i % cols) ImGui::SameLine(0, gap);
            ImGui::PushID(i);
            if (startTile("##start", starts[i].icon, starts[i].name, starts[i].blurb, ImVec2(tw, 128 * s), i == 0)) requestSandbox(starts[i].tmpl);
            if (ImGui::IsItemHovered()) ImGui::SetTooltip(starts[i].tmpl == -2 ? "New flat construction canvas; no generated hills, water, caves, or scattered props" : "Open a starter template in the editor");
            ImGui::PopID();
        }
    }
    ImGui::TextDisabled("Blank canvas by default. To generate hills later: World > Advanced Procedural Terrain.");
    // Planet editor entry is intentionally separate from playable templates:
    // gravity/character physics and orbit-scale rendering are not ready yet.
    ImGui::Dummy(ImVec2(0, 12 * s));
    if (ImGui::Button("Create Planet... (Experimental)", ImVec2(290 * s, 38 * s))) openPlanetCreator();
    ImGui::SameLine(0, 12 * s);
    ImGui::TextDisabled("Spherical voxel editor - flight mode only");
    // Open an existing planet without changing the sandbox's .vxworld save.
    {
        const std::filesystem::path planetDir = "worlds/sandbox/planets";
        std::vector<std::filesystem::path> saved;
        std::error_code ec;
        for (const auto& entry : std::filesystem::directory_iterator(planetDir, ec)) {
            if (entry.is_regular_file() && entry.path().extension() == ".vxplanet")
                saved.push_back(entry.path());
        }
        std::sort(saved.begin(), saved.end());
        if (!saved.empty() && ImGui::BeginCombo("Open saved planet", "Select .vxplanet...")) {
            for (const auto& path : saved)
                if (ImGui::Selectable(path.stem().string().c_str())) requestOpenPlanet(path.string());
            ImGui::EndCombo();
        }
    }
    ImGui::Dummy(ImVec2(0, 22 * s));

    // ---- your games
    sectionLabel("YOUR GAMES");
    {
        const float gap = 14 * s;
        const int cols = std::max(1, int((contentW + gap) / (330 * s + gap)));
        const ImVec2 card((contentW - gap * (cols - 1)) / cols, 168 * s);
        int i = 0;
        for (const auto& g : gameRegistry()) {
            if (i % cols) ImGui::SameLine(0, gap);
            ++i;
            const int r = gameCard(g.id.c_str(), g.name.c_str(), g.tagline.c_str(), g.accent, card, true);
            if (r == 1) requestOpenGame(&g, false);
            if (r == 2) requestOpenGame(&g, true);
        }
        if (i == 0) ImGui::TextDisabled("No games built in yet.");
    }

    // ---- footer: the C++ way, the docs
    {
        pushFont(fonts.small);
        const float y = ds.y - 40 * s;
        ImGui::SetCursorScreenPos(ImVec2(pad, y - 4 * s));
        ImGui::PushStyleColor(ImGuiCol_Text, col::textDim);
        if (ImGui::TextLink("Make a game in C++")) ImGui::OpenPopup("Make a game in C++");
        ImGui::PopStyleColor();
        ImGui::SameLine(0, 18 * s);
        ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::faint), "Docs: docs/ENGINE.md  \xC2\xB7  docs/CREATION.md  \xC2\xB7  docs/ROADMAP.md");
        popFont();

        ImGui::SetNextWindowPos(ImVec2(ds.x * 0.5f, ds.y * 0.5f), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(560 * s, 0));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(22 * s, 18 * s));
        if (ImGui::BeginPopupModal("Make a game in C++", nullptr, ImGuiWindowFlags_NoResize)) {
            ImGui::TextWrapped("Games with their own code are C++ folders built into SpireEngine.exe. Making one takes about two minutes:");
            ImGui::Dummy(ImVec2(0, 4 * s));
            const char* steps[] = {
                "Copy  games/template  to  games/mygame",
                "In  TemplateGame.cpp  rename the class and change the PX_REGISTER_GAME line (id, name, tagline, colour)",
                "Add  add_subdirectory(games/mygame)  to the root CMakeLists.txt",
                "Rebuild. Your game appears here in the Project Hub.",
            };
            for (int n = 0; n < 4; ++n) {
                pushFont(fonts.mono);
                ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::accent), "%d", n + 1);
                popFont();
                ImGui::SameLine(30 * s);
                ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
                ImGui::TextUnformatted(steps[n]);
                ImGui::PopTextWrapPos();
            }
            ImGui::Dummy(ImVec2(0, 4 * s));
            pushFont(fonts.small);
            ImGui::TextDisabled("No code needed for most games: rules, gadgets and game rules are all in the editor.");
            popFont();
            ImGui::Dummy(ImVec2(0, 8 * s));
            if (primaryButton("Got it")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        ImGui::PopStyleVar();
    }

    // ---- top-right: settings and quit, in the corner where they are easy to hit and out of the way
    {
        const float b = 34 * s;
        ImGui::SetCursorScreenPos(ImVec2(ds.x - pad - b * 2 - 6 * s, 48 * s));
        if (iconButton("##hubsettings", Icon::Gear, b, "Settings")) openSettings = true;
        ImGui::SameLine(0, 6 * s);
        if (iconButton("##hubquit", Icon::Power, b, "Quit to desktop")) cmdQuit();
    }

    drawSettingsModal(*this);
    ImGui::End();
    ImGui::PopStyleVar();
}

} // namespace px
