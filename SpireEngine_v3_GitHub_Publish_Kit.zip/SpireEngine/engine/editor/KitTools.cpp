// Building kits in the editor (v0.16): pick a piece in the Kits panel, point at the ground or at a building, and it snaps
// to the grid of scene/BuildKit.h. Hold the button and drag to build a run, Shift to take pieces away, R to turn, the wheel
// (or [ and ]) to change storey. Everything placed is an ordinary object, grouped under a "Building", and a drag is one undo step.
#include "core/Application.h"
#include "editor/Panels.h"
#include "ui/UiKit.h"
#include "workshop/KitPieces.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstdio>
#include <imgui.h>

namespace px {

using namespace ui;

namespace {
ImTextureRef texRef(unsigned glTex) { return ImTextureRef(ImTextureID(std::uintptr_t(glTex))); }

bool isIdentity(const SceneObject& o) {
    return o.position == glm::vec3(0.0f) && o.rotation == glm::vec3(0.0f) && o.scale == 1.0f;
}
float yawOf(const glm::mat4& m) { return decomposeTransform(m).rotation.y; }
float angleDiff(float a, float b) {          // degrees, 0..180
    float d = std::fmod(std::fabs(a - b), 360.0f);
    return d > 180.0f ? 360.0f - d : d;
}
} // namespace

// ------------------------------------------------------------------ what is a kit piece

KitRole Application::kitRoleOfAsset(const std::string& asset, std::string* style) const {
    if (asset.empty()) return KitRole::None;
    std::vector<std::string> tags;
    std::string st; KitRole r = KitRole::None;
    if (!assets.tagsOf(asset, tags) || !kitParseTags(tags, st, r)) return KitRole::None;
    if (style) *style = st;
    return r;
}

void Application::startPlacingKit(KitRole role) {
    kits.update(assets);
    const std::string name = kits.piece(kitStyle, role);
    if (name.empty()) { toast("The " + kitStyle + " kit has no " + kitRoleLabel(role) + " piece yet", Toast::Kind::Warning); return; }
    const int keepTurns = kitTurns;
    startPlacing(name);
    kitTurns = keepTurns;
}

// ------------------------------------------------------------------ where a piece goes

bool Application::kitSpotUnderCursor(KitRole role, KitSpot& spot, float* planeOut, ObjectId* hitOut, const float* forcePlane) const {
    glm::vec3 pos, n;
    ObjectId hit = 0;
    if (!findPlacementSpot(pos, n, &hit)) return false;
    float plane = 0.0f;
    bool onKit = false;
    if (forcePlane) {
        plane = *forcePlane;
    } else {
        if (hit) {                                                  // pointing at a piece: build on its storey
            if (const SceneObject* o = scene.find(hit)) {
                const KitRole r = kitRoleOfAsset(o->asset);
                if (r != KitRole::None) {
                    const Evaluated* e = scene.evaluatedFor(hit);
                    const float y = e ? e->world[3].y : o->position.y;
                    plane = kitPlaneAt(kitPlaneOf(r, y), pos.y);
                    onKit = true;
                }
            }
        }
        if (!onKit) {
            const float base = kitBaseSet ? kitBaseY : std::round(pos.y * 4.0f) / 4.0f;      // until the first piece, the ground under the cursor
            plane = base + float(kitLevel) * kKitStorey;
        }
    }
    spot = kitSnap(role, pos, plane, kitTurns);
    if (planeOut) *planeOut = plane;
    if (hitOut) *hitOut = onKit ? hit : 0;
    return true;
}

std::vector<ObjectId> Application::kitClash(KitRole role, const KitSpot& spot) const {
    std::vector<ObjectId> out;
    for (const SceneObject& o : scene.objects()) {
        if (o.isGroup()) continue;
        const KitRole r = kitRoleOfAsset(o.asset);
        if (r == KitRole::None) continue;
        const glm::mat4 m = scene.restWorld(o.id);
        if (kitSameSlot(role, spot.position, spot.yaw, r, glm::vec3(m[3]), yawOf(m))) out.push_back(o.id);
    }
    return out;
}

bool Application::kitPlaceAt(const std::string& asset, KitRole role, const KitSpot& spot) {
    if (!assets.get(asset)) return false;
    const std::vector<ObjectId> clash = kitClash(role, spot);
    if (clash.size() == 1) {                                        // the very same piece, already there: nothing to do
        if (const SceneObject* c = scene.find(clash[0]); c && c->asset == asset) {
            const glm::mat4 m = scene.restWorld(c->id);
            if (glm::length(glm::vec3(m[3]) - spot.position) < 0.02f && angleDiff(yawOf(m), spot.yaw) < 0.5f) return false;
        }
    }
    for (ObjectId id : clash) scene.remove(id);

    const SceneObject* g = kitGroup ? scene.find(kitGroup) : nullptr;
    if (!g || !g->isGroup() || g->parent != 0 || !isIdentity(*g)) {        // a building starts as a group, so the Outliner stays tidy
        SceneObject grp;
        grp.name = "Building";
        grp.solid = false;
        kitGroup = scene.add(grp);
    }
    SceneObject o;
    o.asset = asset;
    o.name = asset;
    o.parent = kitGroup;
    o.position = spot.position;
    o.rotation = glm::vec3(0.0f, spot.yaw, 0.0f);
    scene.add(o);
    return true;
}

bool Application::kitRemoveUnderCursor() {
    RayHit th;
    const glm::vec3 d = cursorRay();
    const bool terrain = world.raycast(camera.position, d, 400.0f, th);
    Scene::Hit h;
    if (!scene.raycast(camera.position, d, terrain ? th.distance : 400.0f, h)) return false;
    const SceneObject* o = scene.find(h.id);
    if (!o || kitRoleOfAsset(o->asset) == KitRole::None) return false;     // only kit pieces: a click never takes a tree away by accident
    scene.remove(h.id);
    return true;
}

// ------------------------------------------------------------------ mouse

void Application::kitDragStep(bool buttonHeld) {
    if (!kitDragging) return;
    if (!buttonHeld) { kitStrokeEnd(); return; }                    // the button went up somewhere we did not see
    if (looking || ImGui::GetIO().WantCaptureMouse) return;
    bool changed = false;
    if (kitErasing) {
        changed = kitRemoveUnderCursor();
    } else {
        const KitRole role = placingKitRole();
        KitSpot spot;
        if (role != KitRole::None && kitSpotUnderCursor(role, spot, nullptr, nullptr, &kitDragPlane)) {
            char key[96];
            std::snprintf(key, sizeof key, "%d %.2f %.2f %.2f %.0f", int(role), double(spot.position.x), double(spot.position.y), double(spot.position.z), double(spot.yaw));
            if (kitLastKey != key) {
                kitLastKey = key;
                changed = kitPlaceAt(placingAsset, role, spot);
            }
        }
    }
    if (changed) ++kitStrokeCount;
}

void Application::kitStrokeEnd() {
    if (!kitDragging) return;
    kitDragging = false;
    if (kitStrokeCount > 0) {
        std::string label;
        if (kitErasing) label = kitStrokeCount == 1 ? "Remove a building piece" : "Remove " + std::to_string(kitStrokeCount) + " building pieces";
        else label = kitStrokeCount == 1 ? "Place " + placingAsset : "Build " + std::to_string(kitStrokeCount) + " pieces";
        commitScene(label);
        if (!kitErasing) playSfxAt("stamp", ghostPos, 0.9f);
    }
    kitStrokeCount = 0;
    kitLastKey.clear();
}

// ------------------------------------------------------------------ changing style

std::vector<ObjectId> Application::kitBuildingOf(ObjectId id) const {
    std::vector<ObjectId> out;
    const SceneObject* o = scene.find(id);
    if (!o) return out;
    ObjectId top = id;
    while (const SceneObject* p = scene.find(top)) { if (!p->parent) break; top = p->parent; }
    if (const SceneObject* t = scene.find(top); t && t->isGroup()) {
        for (ObjectId d : scene.descendants(top)) out.push_back(d);
    } else {
        out.push_back(id);
    }
    return out;
}

int Application::restyleObjects(const std::vector<ObjectId>& ids, const std::string& style) {
    kits.update(assets);
    int changed = 0;
    for (ObjectId id : ids) {
        const SceneObject* c = scene.find(id);
        if (!c || c->isGroup()) continue;
        const std::string target = kits.restyle(assets, c->asset, style);
        if (target.empty() || target == c->asset) continue;
        SceneObject* o = scene.mutate(id);
        const bool autoNamed = o->name.rfind(o->asset, 0) == 0;
        o->asset = target;
        if (autoNamed) o->name = scene.uniqueName(target);
        ++changed;
    }
    if (changed) commitScene(changed == 1 ? "Restyle a piece to " + style : "Restyle " + std::to_string(changed) + " pieces to " + style);
    return changed;
}

// ------------------------------------------------------------------ on the screen

void Application::drawKitGuides(ImDrawList* dl, const GizmoView& v, float s) {
    if (!ghostValid) return;
    // A small patch of the grid around the cursor, on the storey being built, fading with distance.
    const int R = 3;
    const float c0x = std::floor(ghostPos.x / kKitCell) * kKitCell, c0z = std::floor(ghostPos.z / kKitCell) * kKitCell;
    const float y = ghostPlane + 0.03f;
    auto fade = [&](const glm::vec3& p) {
        const float d = std::sqrt((p.x - ghostPos.x) * (p.x - ghostPos.x) + (p.z - ghostPos.z) * (p.z - ghostPos.z));
        return std::clamp(1.0f - d / (kKitCell * float(R) + 1.0f), 0.0f, 1.0f);
    };
    auto seg = [&](const glm::vec3& a, const glm::vec3& b) {
        glm::vec2 pa, pb;
        const float f = fade((a + b) * 0.5f);
        if (f <= 0.02f) return;
        if (v.project(a, pa) && v.project(b, pb)) dl->AddLine(ImVec2(pa.x, pa.y), ImVec2(pb.x, pb.y), IM_COL32(140, 215, 255, int(150.0f * f)), 1.3f * s);
    };
    for (int i = -R; i <= R + 1; ++i)
        for (int j = -R; j <= R; ++j) {
            const float xi = c0x + float(i) * kKitCell, zj = c0z + float(j) * kKitCell;
            seg(glm::vec3(xi, y, zj), glm::vec3(xi, y, zj + kKitCell));                       // a line along z
            const float zi = c0z + float(i) * kKitCell, xj = c0x + float(j) * kKitCell;
            seg(glm::vec3(xj, y, zi), glm::vec3(xj + kKitCell, y, zi));                       // and one along x
        }
    // Where the piece will stand: a ring on the grid point it snapped to.
    glm::vec2 sp;
    if (v.project(glm::vec3(ghostPos.x, ghostPlane + 0.03f, ghostPos.z), sp))
        dl->AddCircle(ImVec2(sp.x, sp.y), 6.0f * s, ghostKitState == 1 ? IM_COL32(255, 190, 80, 235) : IM_COL32(120, 230, 255, 235), 20, 2.0f * s);
}

void Application::drawKitPanel() {
    if (!beginPanel("Kits", &showKits, settleFront("Kits"))) return;
    const float s = scale();
    kits.update(assets);
    const std::vector<KitStyleEntry>& styles = kits.styles();
    if (!kits.find(kitStyle) && !styles.empty()) kitStyle = styles[0].name;
    if (kitRestyleTarget.empty() || !kits.find(kitRestyleTarget)) kitRestyleTarget = kitStyle;

    ImGui::TextDisabled("Snap-together walls, floors, roofs and stairs.");
    ImGui::Dummy(ImVec2(0, 2 * s));
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted("Kit");
    ImGui::SameLine(44 * s);
    ImGui::SetNextItemWidth(-FLT_MIN);
    bool styleChanged = false;
    if (ImGui::BeginCombo("##kitstyle", kitStyle.c_str())) {
        for (const KitStyleEntry& e : styles) {
            const std::string label = e.builtin ? e.name : e.name + "   (yours)";
            if (ImGui::Selectable(label.c_str(), e.name == kitStyle)) { if (kitStyle != e.name) styleChanged = true; kitStyle = e.name; }
        }
        ImGui::EndCombo();
    }
    if (const KitStyle* bs = findKitStyle(kitStyle)) {
        pushFont(fonts.small); ImGui::PushTextWrapPos(0.0f); ImGui::TextDisabled("%s", bs->blurb); ImGui::PopTextWrapPos(); popFont();
    } else if (const KitStyleEntry* e = kits.find(kitStyle)) {
        pushFont(fonts.small); ImGui::TextDisabled("Your own kit: %d of 7 pieces.", e->pieces()); popFont();
    }
    ImGui::Dummy(ImVec2(0, 4 * s));

    // ---- the pieces
    const KitStyleEntry* cur = kits.find(kitStyle);
    const float gap = 6 * s, cardW = 76 * s, thumb = cardW - 8 * s, labelH = ImGui::GetFontSize() + 6 * s;
    const int cols = std::max(1, int((ImGui::GetContentRegionAvail().x + gap) / (cardW + gap)));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    KitRole startRole = KitRole::None;
    const KitRole placingRole = placingKitRole();
    std::string placingStyle;
    kitRoleOfAsset(placingAsset, &placingStyle);
    for (int r = 1; r < kKitRoleCount; ++r) {
        const KitRole role = KitRole(r);
        const std::string name = cur ? cur->piece[size_t(r)] : std::string();
        if ((r - 1) % cols) ImGui::SameLine(0, gap);
        ImGui::PushID(r);
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const bool have = !name.empty();
        const bool active = have && placingAsset == name;
        ImGui::BeginDisabled(!have);
        if (ImGui::InvisibleButton("##piece", ImVec2(cardW, cardW + labelH))) {
            if (active) stopPlacing(); else startRole = role;
        }
        ImGui::EndDisabled();
        const bool hov = ImGui::IsItemHovered(ImGuiHoveredFlags_AllowWhenDisabled);
        dl->AddRectFilled(p, ImVec2(p.x + cardW, p.y + cardW + labelH), active ? col::accentDim : col::panelAlt, 8 * s);
        if (have) if (const unsigned tex = assetThumbnailTexture(*this, name))
            dl->AddImage(texRef(tex), ImVec2(p.x + 4 * s, p.y + 4 * s), ImVec2(p.x + 4 * s + thumb, p.y + 4 * s + thumb));
        if (active || (hov && have)) dl->AddRect(p, ImVec2(p.x + cardW, p.y + cardW + labelH), active ? col::accent : col::border, 8 * s, 0, active ? 2.0f * s : 1.5f * s);
        pushFont(fonts.small);
        const char* label = kitRoleLabel(role);
        const float tw = ImGui::CalcTextSize(label).x;
        dl->AddText(ImVec2(p.x + (cardW - tw) * 0.5f, p.y + cardW - 1 * s), have ? (active ? col::text : col::textDim) : col::border, label);
        popFont();
        if (hov) {
            ImGui::BeginTooltip();
            pushFont(fonts.bold); ImGui::TextUnformatted(have ? name.c_str() : (std::string(kitRoleLabel(role)) + " (not in this kit)").c_str()); popFont();
            ImGui::TextDisabled("%s", kitRoleInfo(role));
            ImGui::EndTooltip();
        }
        ImGui::PopID();
    }
    if (styleChanged && placingRole != KitRole::None) startRole = placingRole;      // keep building, in the new look
    if (startRole != KitRole::None) {
        if (styleChanged || !(placingKit() && placingKitRole() == startRole)) startPlacingKit(startRole);
    }
    ImGui::Dummy(ImVec2(0, 4 * s));

    // ---- how it snaps
    section("Building");
    ImGui::Checkbox("Snap to the grid", &kitSnapOn);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Off: kit pieces are placed like any other asset, anywhere.");
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted("Storey");
    ImGui::SameLine(70 * s);
    if (ImGui::Button("-##lvl")) kitLevelStep(-1);
    ImGui::SameLine();
    ImGui::TextUnformatted(kitLevelLabel(kitLevel).c_str());
    ImGui::SameLine();
    if (ImGui::Button("+##lvl")) kitLevelStep(1);
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Mouse wheel or [ ] while placing.\nPointing at a piece builds on its own storey.");
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted("Ground");
    ImGui::SameLine(70 * s);
    if (kitBaseSet) {
        ImGui::Text("%.2f m", double(kitBaseY));
        ImGui::SameLine();
        if (ImGui::SmallButton("Lower")) kitBaseY -= 0.25f;
        ImGui::SameLine();
        if (ImGui::SmallButton("Raise")) kitBaseY += 0.25f;
        ImGui::SameLine();
        if (ImGui::SmallButton("Follow the ground")) kitBaseSet = false;
    } else {
        ImGui::TextDisabled("follows the ground");
    }
    if (ImGui::Button("Draw a whole building with a Blueprint...", ImVec2(-FLT_MIN, 0))) openBlueprintEditor();
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Draw rooms on a floor plan; the walls, doors, windows, stairs and roof are made for you.  (Ctrl+B)");
    if (ImGui::Button("Rotate  (R)")) kitRotate();
    ImGui::SameLine();
    if (ImGui::Button("New building")) { kitGroup = 0; toast("The next piece starts a new building"); }
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Pieces are grouped under a Building in the Outliner.\nThis starts a fresh group for the next piece.");
    ImGui::Dummy(ImVec2(0, 4 * s));

    // ---- changing the look of what is built
    section("Change the look");
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted("Swap to");
    ImGui::SameLine(70 * s);
    ImGui::SetNextItemWidth(-FLT_MIN);
    if (ImGui::BeginCombo("##restyle", kitRestyleTarget.c_str())) {
        for (const KitStyleEntry& e : styles) if (ImGui::Selectable(e.name.c_str(), e.name == kitRestyleTarget)) kitRestyleTarget = e.name;
        ImGui::EndCombo();
    }
    const std::vector<ObjectId> roots = selectionRoots();
    std::vector<ObjectId> picked;
    for (ObjectId id : roots) { picked.push_back(id); for (ObjectId d : scene.descendants(id)) picked.push_back(d); }
    ImGui::BeginDisabled(picked.empty());
    const float bw = (ImGui::GetContentRegionAvail().x - 6 * s) * 0.5f;
    if (ImGui::Button("Selected pieces", ImVec2(bw, 0))) {
        const int n = restyleObjects(picked, kitRestyleTarget);
        toast(n ? "Swapped " + std::to_string(n) + (n == 1 ? " piece" : " pieces") + " to " + kitRestyleTarget : "Nothing selected has a match in " + kitRestyleTarget, n ? Toast::Kind::Success : Toast::Kind::Warning);
    }
    ImGui::SameLine(0, 6 * s);
    if (ImGui::Button("Whole building", ImVec2(bw, 0))) {
        const int n = restyleObjects(kitBuildingOf(primaryObject()), kitRestyleTarget);
        toast(n ? "Swapped " + std::to_string(n) + (n == 1 ? " piece" : " pieces") + " to " + kitRestyleTarget : "Nothing in that building has a match in " + kitRestyleTarget, n ? Toast::Kind::Success : Toast::Kind::Warning);
    }
    ImGui::EndDisabled();
    if (picked.empty()) { pushFont(fonts.small); ImGui::TextDisabled("Select a piece (or a Building) first."); popFont(); }
    ImGui::Dummy(ImVec2(0, 4 * s));

    section("Your own pieces");
    ImGui::PushTextWrapPos(0.0f);
    pushFont(fonts.small);
    ImGui::TextDisabled("Open any piece in the Workshop to change it, or start a kit piece of your own. Pieces with the tags kit:<name> and role:<piece> join the list.");
    popFont();
    ImGui::PopTextWrapPos();
    if (ImGui::Button("New kit piece in the Workshop", ImVec2(-FLT_MIN, 0))) {
        enterWorkshopNew();
        ws.spec.tmpl = WorkshopTemplate::KitPiece;
    }
    ImGui::End();
}

} // namespace px

// ---------------------------------------------------------------- grass

namespace px {

// Grass is planted by the terrain, not by the scene, so a floor laid on a lawn would have blades poking through it.
// Floors, doorways and stairs at ground level tell the renderer where not to grow any (merged into as few patches as
// the shader can take).
void Application::updateGrassClearings() {
    if (clearSceneRev == scene.revision() && clearAssetRev == assets.revision()) return;
    clearSceneRev = scene.revision();
    clearAssetRev = assets.revision();

    struct Patch { float x0, z0, x1, z1, y0, y1; };
    std::vector<Patch> patches;
    for (const SceneObject& o : scene.objects()) {
        if (o.asset.empty() || !o.visible) continue;
        const KitRole r = kitRoleOfAsset(o.asset);
        if (r != KitRole::Floor && r != KitRole::Doorway && r != KitRole::Stairs) continue;
        glm::vec3 mn, mx;
        if (!scene.worldBounds(o.id, mn, mx)) continue;
        patches.push_back({ mn.x, mn.z, mx.x, mx.z, mn.y - 0.8f, mn.y + 0.35f });
    }

    // Join neighbours that line up exactly into one bigger patch (a 4 x 4 m room is one box, not four).
    auto near = [](float a, float b, float t) { return std::fabs(a - b) < t; };
    bool merged = true;
    while (merged && patches.size() > 1) {
        merged = false;
        for (size_t i = 0; i < patches.size() && !merged; ++i) {
            for (size_t j = i + 1; j < patches.size() && !merged; ++j) {
                Patch& a = patches[i]; const Patch& b = patches[j];
                if (!near(a.y0, b.y0, 0.05f) || !near(a.y1, b.y1, 0.05f)) continue;
                const bool alongX = near(a.x0, b.x0, 0.03f) && near(a.x1, b.x1, 0.03f) && a.z0 <= b.z1 + 0.15f && b.z0 <= a.z1 + 0.15f;
                const bool alongZ = near(a.z0, b.z0, 0.03f) && near(a.z1, b.z1, 0.03f) && a.x0 <= b.x1 + 0.15f && b.x0 <= a.x1 + 0.15f;
                if (!alongX && !alongZ) continue;
                a.x0 = std::min(a.x0, b.x0); a.x1 = std::max(a.x1, b.x1);
                a.z0 = std::min(a.z0, b.z0); a.z1 = std::max(a.z1, b.z1);
                patches.erase(patches.begin() + long(j));
                merged = true;
            }
        }
    }

    renderSettings.grassClear.clear();
    for (size_t i = 0; i < patches.size() && int(i) < RenderSettings::kMaxGrassClearings; ++i) {
        const Patch& p = patches[i];
        renderSettings.grassClear.push_back(glm::vec4(p.x0, p.z0, p.x1, p.z1));
        renderSettings.grassClear.push_back(glm::vec4(p.y0, p.y1, 0.0f, 0.0f));
    }
}

} // namespace px
