#pragma once
// Move / rotate / scale handles for the selected objects. What is under the mouse and how far
// a drag has gone is plain maths on rays and planes (testable without a window); drawing is a
// separate function that paints the handles with an ImGui draw list.
#include <glm/glm.hpp>
#include "core/Camera.h"

struct ImDrawList;

namespace px {

enum class GizmoMode { Move, Rotate, Scale };
enum class GizmoSpace { World, Local };

struct GizmoSnap {
    bool  on = false;
    float move = 1.0f;       // metres
    float rotate = 15.0f;    // degrees
    float scale = 0.25f;     // steps of the size factor
};

// The 3D view the handles live in (window points, like the mouse).
struct GizmoView {
    const Camera* camera = nullptr;
    float x = 0, y = 0, w = 1, h = 1;
    float uiScale = 1.0f;                                         // pick tolerance and line widths
    glm::mat4 viewProj{ 1.0f };
    void update();                                                // after changing camera / x y w h
    bool project(const glm::vec3& world, glm::vec2& out) const;   // false behind the camera
    void ray(const glm::vec2& mouse, glm::vec3& origin, glm::vec3& dir) const;
};

class Gizmo {
public:
    // Handles: 0..2 = the X / Y / Z axis (arrow, ring or scale cube); 3..5 = the plane square
    // perpendicular to X / Y / Z (move only); 6 = the centre (move in the view plane, or scale evenly).
    static constexpr int kNone = -1, kCentre = 6;

    glm::vec3 pivot{ 0.0f };
    glm::mat3 axes{ 1.0f };         // columns = the three handle directions, unit length and at right angles

    // How long the handles are in the world so they keep about the same size on screen.
    float handleLength(const GizmoView& v) const;
    int pick(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse) const;

    // What a drag has done so far, measured from where it began.
    struct Delta {
        glm::vec3 translate{ 0.0f };
        glm::vec3 axis{ 0.0f, 1.0f, 0.0f };   // rotation axis (world)
        float     angle = 0.0f;                // radians, accumulated (can pass a full turn)
        float     scale = 1.0f;                // factor
    };
    bool begin(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse, int handle);
    Delta drag(const GizmoView& v, GizmoMode mode, const glm::vec2& mouse, const GizmoSnap& snap);
    void end() { active = false; handle = kNone; }
    bool dragging() const { return active; }
    int  activeHandle() const { return handle; }

    // Paints the handles. `hover` is the handle under the mouse (kNone for none); the active one is lit while dragging.
    void draw(ImDrawList* dl, const GizmoView& v, GizmoMode mode, int hover) const;

private:
    bool active = false;
    int  handle = kNone;
    float len0 = 1.0f, t0 = 0.0f, lastRaw = 0.0f, accum = 0.0f;
    glm::vec3 p0{ 0.0f };
    glm::vec2 mouse0{ 0.0f };
    glm::vec3 planeNormal{ 0, 1, 0 };
};

} // namespace px
