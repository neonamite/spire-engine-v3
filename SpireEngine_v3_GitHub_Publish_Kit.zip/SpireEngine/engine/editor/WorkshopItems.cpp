// The Item Builder inside the Asset Workshop: the Item tab of the side panel (behaviour, stats, what it does to
// the world, how it feels, how it sits in the hand), the firing range that tests it, and saving the .pxitem
// that goes with the asset. The item rules themselves are in items/; the range is editor/ItemRange.cpp.
#include "core/Application.h"
#include "editor/ItemRange.h"
#include "editor/Panels.h"
#include "editor/WorkshopCommon.h"
#include "ui/UiKit.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace px {

using namespace ui;
using namespace wsui;

namespace {

struct ClipChoice { const char* clip; const char* label; };
const ClipChoice kFireClips[] = { { "", "Silent" }, { "shot", "Gunshot" }, { "launch", "Launcher thump" }, { "whoosh", "Whoosh" }, { "zap", "Zap" },
                                  { "boom", "Boom" }, { "dig", "Dig" }, { "build", "Build" }, { "stamp", "Thud" }, { "reload", "Click-clack" } };
const ClipChoice kHitClips[] = { { "", "By material (default)" }, { "bullet_hit", "Bullet hit" }, { "dig", "Dig" }, { "stamp", "Thud" },
                                 { "zap", "Zap" }, { "boom", "Boom" }, { "whoosh", "Whoosh" } };

template <size_t N>
bool clipCombo(Application& app, const char* id, std::string& current, const ClipChoice (&list)[N]) {
    const char* shown = nullptr;
    for (const ClipChoice& c : list) if (current == c.clip) shown = c.label;
    bool changed = false;
    const float btn = ImGui::GetFrameHeight();
    ImGui::SetNextItemWidth(-btn - 6 * scale());
    if (ImGui::BeginCombo(id, shown ? shown : current.c_str())) {
        for (const ClipChoice& c : list)
            if (ImGui::Selectable(c.label, current == c.clip)) { current = c.clip; changed = true; }
        ImGui::EndCombo();
    }
    ImGui::SameLine(0, 6 * scale());
    ImGui::PushID(id);
    ImGui::BeginDisabled(current.empty() && &list[0] == &kFireClips[0]);
    if (ImGui::Button(">", ImVec2(btn, 0))) app.playUiSound(current.empty() ? "bullet_hit" : current.c_str(), 0.8f, 1.0f);
    ImGui::EndDisabled();
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("Hear it");
    ImGui::PopID();
    return changed;
}

std::vector<std::string> glance(const ItemDef& d) {
    const ItemStats& s = d.stats;
    std::vector<std::string> out;
    char b[200];
    switch (d.behaviour) {
    case Behaviour::Hitscan:
    case Behaviour::Projectile: {
        const float perUse = s.damage * float(d.behaviour == Behaviour::Hitscan ? std::max(1, s.pellets) : 1);
        std::snprintf(b, sizeof b, "%.0f damage a second %s", double(perUse * s.fireRate), s.automatic ? "while you hold the button" : "if you click as fast as it allows");
        out.push_back(b);
        if (s.magazine > 0) {
            const float empty = float(s.magazine) / std::max(0.1f, s.fireRate);
            std::snprintf(b, sizeof b, "%.0f a second counting reloads. Empties in %.1f s, reloads in %.1f s.", double(perUse * float(s.magazine) / (empty + s.reloadTime)), double(empty), double(s.reloadTime));
            out.push_back(b);
        } else out.push_back("Never needs reloading.");
        if (d.behaviour == Behaviour::Projectile) {
            std::snprintf(b, sizeof b, "Takes %.1f s to fly 50 m.", double(50.0f / std::max(1.0f, s.speed)));
            out.push_back(b);
        }
        break;
    }
    case Behaviour::Thrown:
        std::snprintf(b, sizeof b, "%.0f damage at the heart of the blast. %s", double(s.damage), s.fuse > 0.0f ? "Goes off after its fuse." : "Goes off when it hits something.");
        out.push_back(b);
        std::snprintf(b, sizeof b, "Carries %d, one every %.1f s.", s.magazine, double(1.0f / std::max(0.1f, s.fireRate)));
        out.push_back(b);
        break;
    case Behaviour::Melee:
        std::snprintf(b, sizeof b, "%.0f damage a second (%.1f swings a second). Reach %.1f m.", double(s.damage * s.fireRate), double(s.fireRate), double(s.range));
        out.push_back(b);
        break;
    case Behaviour::Tool:
        std::snprintf(b, sizeof b, "Works %.0f times a second, up to %.0f m away.", double(s.fireRate), double(s.range));
        out.push_back(b);
        break;
    }
    return out;
}

} // namespace

// ================================================================ loading and saving

void Application::workshopLoadItem() {
    const Asset& a = ws.model.asset;
    ws.itemLoaded = true;
    ws.itemEdited = false;

    const std::string source = ws.sourceAsset.empty() ? a.name : ws.sourceAsset;
    const ItemDef* found = nullptr;
    for (const std::string& n : itemLibrary.names()) {
        const ItemDef* d = itemLibrary.find(n);
        if (d && d->asset == source) { found = d; break; }
    }
    if (found) ws.item = *found;
    else {
        Behaviour b = Behaviour::Hitscan;
        for (const Socket& sk : a.sockets) if (sk.name == "blade_tip") b = Behaviour::Melee;
        ws.item = ItemDef::defaultsFor(b, a.name, a.name);
    }
    ws.item.name = a.name;
    ws.item.asset = a.name;
    ws.item.userMade = true;
}

bool Application::workshopSaveItem() {
    const Asset& a = ws.model.asset;
    if (assets.directory.empty()) assets.directory = "assets";
    if (a.type == AssetType::Item) {
        if (!ws.itemLoaded) workshopLoadItem();
        ws.item.name = a.name;
        ws.item.asset = a.name;
        if (!itemLibrary.save(ws.item, assets.directory)) {
            toast("Could not write " + assets.directory + "/" + ItemLibrary::fileNameFor(a.name) + ".pxitem", Toast::Kind::Warning);
            return false;
        }
        ws.itemEdited = false;
        return true;
    }
    // Not an item (any more): forget the item stats that used to go with it.
    const std::string name = a.name;
    if (const ItemDef* d = itemLibrary.find(name)) {
        if (d->userMade) { itemLibrary.deleteFile(name, assets.directory); itemLibrary.remove(name); }
    }
    ws.itemEdited = false;
    return true;
}

void Application::workshopTryInWorld() {
    if (!ws.model.asset.valid() || ws.model.asset.type != AssetType::Item) return;
    if (!workshopSave()) return;
    const std::string name = ws.item.name;
    startPlayingWith(name);
}

// ================================================================ the range

void Application::workshopEnterRange() {
    if (ws.rangeOn || !ws.model.asset.valid() || ws.model.asset.type != AssetType::Item) return;
    workshopFinishStroke();
    if (!ws.itemLoaded) workshopLoadItem();
    if (!ws.range) {
        ws.range = std::make_shared<ItemRange>();
        ws.range->onSound = [this](const std::string& clip, const glm::vec3& at, float volume, float pitch) { playSfxAt(clip, at, volume, pitch); };
    }
    ws.draggingSocket = ws.stroking = ws.orbiting = ws.panning = false;
    ws.orbitYaw = camera.yaw;
    ws.orbitPitch = camera.pitch;
    ws.rangeOn = true;
    ws.rangeCaptured = false;
    ws.panelTab = 1;
    SDL_SetWindowRelativeMouseMode(window, false);
    ws.item.name = ws.item.asset = ws.model.asset.name;
    ws.range->setDraft(ws.item, AssetPtr(AssetPtr(), &ws.model.asset));
    ws.range->reset();
    camera.yaw = 90.0f;
    camera.pitch = 0.0f;
    camera.position = ws.range->eye();
    status = "Firing range: click the view to take aim";
}

void Application::workshopLeaveRange() {
    if (!ws.rangeOn) return;
    ws.rangeOn = false;
    ws.rangeCaptured = false;
    SDL_SetWindowRelativeMouseMode(window, false);
    if (ws.range) {
        ws.range->items.releaseTrigger(0);
        ws.range->items.releaseTrigger(1);
        ws.range->clearDraft();
    }
    camera.yaw = ws.orbitYaw;
    camera.pitch = ws.orbitPitch;
    workshopApplyCamera();
    status = "Back to building";
}

bool Application::workshopRangeEvent(const SDL_Event& e) {
    if (!ws.range) return false;
    const ImGuiIO& io = ImGui::GetIO();
    ItemSystem& items = ws.range->items;
    auto inView = [&](float x, float y) { return x >= viewRect.x && x <= viewRect.x + viewRect.w && y >= viewRect.y && y <= viewRect.y + viewRect.h; };

    switch (e.type) {
    case SDL_EVENT_KEY_DOWN: {
        const SDL_Keycode k = e.key.key;
        const SDL_Keymod mod = SDL_GetModState();
        if (k == SDLK_F11 || k == SDLK_F12 || (k == SDLK_RETURN && (mod & SDL_KMOD_ALT))) return false;
        if (mod & SDL_KMOD_CTRL) return false;                       // Ctrl+S still saves
        if (io.WantTextInput) return false;
        if (k == SDLK_ESCAPE) {
            if (ws.rangeCaptured) { ws.rangeCaptured = false; SDL_SetWindowRelativeMouseMode(window, false); }
            else workshopLeaveRange();
            return true;
        }
        if (k == SDLK_R && !e.key.repeat) items.reload();
        return true;                                                 // the building shortcuts do nothing in here
    }
    case SDL_EVENT_MOUSE_MOTION:
        if (ws.rangeCaptured) { camera.look(e.motion.xrel, settings.invertY ? -e.motion.yrel : e.motion.yrel); return true; }
        return false;
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
        if (io.WantCaptureMouse || !inView(e.button.x, e.button.y)) return false;
        if (!ws.rangeCaptured) {
            ws.rangeCaptured = true;
            SDL_SetWindowRelativeMouseMode(window, true);
            status = "Left click: fire    R: reload    WASD: walk    Shift: run    Esc: let go of the mouse";
            return true;
        }
        if (e.button.button == SDL_BUTTON_LEFT) items.pressTrigger(0);
        else if (e.button.button == SDL_BUTTON_RIGHT) items.pressTrigger(1);
        return true;
    case SDL_EVENT_MOUSE_BUTTON_UP:
        if (e.button.button == SDL_BUTTON_LEFT) items.releaseTrigger(0);
        else if (e.button.button == SDL_BUTTON_RIGHT) items.releaseTrigger(1);
        return ws.rangeCaptured;
    case SDL_EVENT_MOUSE_WHEEL:
        return !io.WantCaptureMouse;
    default: return false;
    }
}

void Application::updateWorkshopRange(float dt) {
    timeFlowing = false;
    timeOfDay = ws.lightTime;
    updateSunDirection();
    renderSettings.wireframe = false;
    renderSettings.water = false;
    renderSettings.shadowRange = 90.0f;
    renderSettings.interactor = glm::vec4(0.0f, -1e5f, 0.0f, 0.0f);
    cursorHitValid = false;
    flyTo.cancel();
    if (!ws.range) { workshopLeaveRange(); return; }

    ItemRange& r = *ws.range;
    ws.item.name = ws.item.asset = ws.model.asset.name;
    r.setDraft(ws.item, AssetPtr(AssetPtr(), &ws.model.asset));

    float forward = 0.0f, strafe = 0.0f;
    bool run = false;
    if (ws.rangeCaptured && !ImGui::GetIO().WantTextInput) {
        const bool* keys = SDL_GetKeyboardState(nullptr);
        forward = (keys[SDL_SCANCODE_W] ? 1.0f : 0.0f) - (keys[SDL_SCANCODE_S] ? 1.0f : 0.0f);
        strafe = (keys[SDL_SCANCODE_D] ? 1.0f : 0.0f) - (keys[SDL_SCANCODE_A] ? 1.0f : 0.0f);
        run = keys[SDL_SCANCODE_LSHIFT] || keys[SDL_SCANCODE_RSHIFT];
    }
    if (!itemsFrozen) r.update(dt, camera.yaw, camera.pitch, forward, strafe, run);
    camera.pitch = glm::clamp(camera.pitch + r.takeViewKick(), -89.0f, 89.0f);
    camera.position = r.eye();
    ws.hoverValid = false;
    workshopSceneForRenderer();
}

void Application::drawWorkshopRange() {
    if (!ws.range) return;
    const float s = scale();
    ItemRange& r = *ws.range;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const ImVec2 a(viewRect.x, viewRect.y), b(viewRect.x + viewRect.w, viewRect.y + viewRect.h);
    dl->PushClipRect(a, b, true);

    View v;
    v.x = viewRect.x; v.y = viewRect.y; v.w = std::max(1.0f, viewRect.w); v.h = std::max(1.0f, viewRect.h);
    v.vp = viewProj;

    // distance marks across the floor
    for (int m = 5; m <= int(ItemRange::kFarZ) - 3; m += 5) {
        const float z = float(m);
        ImVec2 pa, pb;
        const bool major = m % 10 == 0;
        if (v.line(glm::vec3(-9.0f, 0.02f, z), glm::vec3(9.0f, 0.02f, z), pa, pb)) dl->AddLine(pa, pb, IM_COL32(255, 255, 255, major ? 70 : 38), (major ? 1.6f : 1.0f) * s);
        ImVec2 p;
        if (v.point(glm::vec3(9.0f, 0.02f, z), p)) {
            char t[16]; std::snprintf(t, sizeof t, "%d m", m);
            pushFont(fonts.small);
            dl->AddText(ImVec2(p.x + 6 * s, p.y - 8 * s), IM_COL32(255, 255, 255, major ? 170 : 110), t);
            popFont();
        }
    }

    // health bars on targets that have been hit
    for (const ItemRange::Target& t : r.targets()) {
        if (!t.alive() || t.health >= t.maxHealth) continue;
        ImVec2 p;
        if (!v.point(t.base + glm::vec3(0.0f, t.asset->boundsMax.y + 0.25f, 0.0f), p)) continue;
        const float w = 54.0f * s, h = 6.0f * s, f = std::clamp(t.health / t.maxHealth, 0.0f, 1.0f);
        dl->AddRectFilled(ImVec2(p.x - w * 0.5f - 1, p.y - 1), ImVec2(p.x + w * 0.5f + 1, p.y + h + 1), IM_COL32(11, 12, 16, 200), 3 * s);
        dl->AddRectFilled(ImVec2(p.x - w * 0.5f, p.y), ImVec2(p.x - w * 0.5f + w * f, p.y + h), f > 0.5f ? col::success : (f > 0.25f ? col::warning : col::danger), 3 * s);
    }

    // floating damage numbers
    for (const ItemRange::Number& n : r.numbers()) {
        ImVec2 p;
        if (!v.point(n.at + glm::vec3(0.0f, n.age * 0.9f, 0.0f), p)) continue;
        const float fade = 1.0f - std::clamp(n.age / 1.2f, 0.0f, 1.0f);
        char t[24]; std::snprintf(t, sizeof t, n.kill ? "%.0f!" : "%.0f", double(n.amount));
        pushFont(n.kill ? fonts.title : fonts.bold);
        const ImVec2 ts = ImGui::CalcTextSize(t);
        dl->AddText(ImVec2(p.x - ts.x * 0.5f + 1.5f * s, p.y + 1.5f * s), IM_COL32(0, 0, 0, int(160 * fade)), t);
        dl->AddText(ImVec2(p.x - ts.x * 0.5f, p.y), n.kill ? IM_COL32(255, 110, 100, int(255 * fade)) : IM_COL32(255, 238, 190, int(255 * fade)), t);
        popFont();
    }

    // tracers, flashes, sparks, blasts
    r.items.drawFx(dl, viewProj, r.view(), viewRect.x, viewRect.y, viewRect.w, viewRect.h, s);

    // crosshair and the item panel
    if (ws.rangeCaptured) drawItemCrosshair(dl, r.items, ImVec2(viewRect.x + viewRect.w * 0.5f, viewRect.y + viewRect.h * 0.5f), viewRect.h, s);
    drawItemPanel(dl, r.items, ImVec2(b.x - 250.0f * s - 20.0f * s, b.y - 106.0f * s), s);

    // what to do
    {
        pushFont(fonts.small);
        const char* text = ws.rangeCaptured
            ? "Left click: fire     Right click: second button     R: reload     WASD: walk     Shift: run     Esc: let go of the mouse"
            : "Click the view to take aim     Esc: back to building";
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const ImVec2 q(viewRect.x + (viewRect.w - ts.x) * 0.5f, viewRect.y + 16 * s);
        dl->AddRectFilled(ImVec2(q.x - 10 * s, q.y - 5 * s), ImVec2(q.x + ts.x + 10 * s, q.y + ts.y + 5 * s), IM_COL32(11, 12, 16, 200), 8 * s);
        dl->AddText(q, col::textDim, text);
        popFont();
    }
    dl->PopClipRect();
}

// ================================================================ the Item tab

void Application::drawWorkshopItemPanel() {
    const float s = scale();
    Asset& a = ws.model.asset;
    if (!ws.itemLoaded) workshopLoadItem();
    ItemDef& d = ws.item;
    d.name = a.name;
    d.asset = a.name;
    const ItemDef before = d;

    auto slider = [&](const char* label, const char* tip, const char* id, float* v, float lo, float hi, const char* fmt, bool logScale = false) {
        prop(label, tip);
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (logScale) sliderFloatLog(id, v, lo, hi, fmt); else sliderFloat(id, v, lo, hi, fmt);
    };
    auto islider = [&](const char* label, const char* tip, const char* id, int* v, int lo, int hi, const char* fmt) {
        prop(label, tip);
        ImGui::SetNextItemWidth(-FLT_MIN);
        sliderInt(id, v, lo, hi, fmt);
    };

    // ---- test
    section("Test");
    {
        if (!ws.rangeOn) {
            if (primaryButton("Enter the firing range")) workshopEnterRange();
            pushFont(fonts.small);
            ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
            ImGui::TextDisabled("Shoot targets, a wall and a block of sand with this model in your hand. Everything below changes while you play.");
            ImGui::PopTextWrapPos();
            popFont();
        } else {
            if (primaryButton("Back to building")) workshopLeaveRange();
            ImGui::Dummy(ImVec2(0, 2 * s));
            const ItemRange::Score sc = ws.range->score();
            char t[32];
            const float w = (ImGui::GetContentRegionAvail().x - 12 * s) / 3.0f;
            auto tile = [&](const char* label, const char* value, bool first) {
                if (!first) ImGui::SameLine(0, 6 * s);
                ImGui::BeginGroup();
                ImGui::Dummy(ImVec2(w, 0));
                statTile(label, value);
                ImGui::EndGroup();
            };
            std::snprintf(t, sizeof t, "%d", sc.shots);                    tile("Shots", t, true);
            std::snprintf(t, sizeof t, "%d", sc.hits);                     tile("Hits", t, false);
            std::snprintf(t, sizeof t, "%.0f%%", double(sc.accuracy() * 100.0f)); tile("Accuracy", t, false);
            ImGui::Dummy(ImVec2(0, 2 * s));
            std::snprintf(t, sizeof t, "%.0f", double(sc.damage));         tile("Damage", t, true);
            std::snprintf(t, sizeof t, "%.0f/s", double(sc.perSecond));    tile("Right now", t, false);
            std::snprintf(t, sizeof t, "%d", sc.down);                     tile("Knocked down", t, false);
            ImGui::Dummy(ImVec2(0, 4 * s));
            const float bw = (ImGui::GetContentRegionAvail().x - 6 * s) * 0.5f;
            if (ImGui::Button("Reset range", ImVec2(bw, 0))) ws.range->reset();
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("Targets stand up, the wall and the sand are rebuilt, the score and the ammo start over");
            ImGui::SameLine(0, 6 * s);
            if (ImGui::Button("Clear score", ImVec2(bw, 0))) ws.range->clearScore();
        }
        ImGui::Dummy(ImVec2(0, 4 * s));
        if (ImGui::Button("Save and try it in the world", ImVec2(-FLT_MIN, 0))) workshopTryInWorld();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Saves it, then starts playing with this item in your hand. Press 1-9 to switch to the others.");
    }

    // ---- behaviour
    section("Behaviour");
    {
        if (beginProps("##ibehaviour", 96)) {
            prop("Works like", "What pressing the button does");
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::BeginCombo("##behaviour", behaviourName(d.behaviour))) {
                for (int i = 0; i < kBehaviourCount; ++i) {
                    const Behaviour b = Behaviour(i);
                    if (ImGui::Selectable(behaviourName(b), d.behaviour == b) && b != d.behaviour) {
                        // a different behaviour means different numbers: start from its defaults, keep the name and the words
                        const std::string desc = d.description;
                        d = ItemDef::defaultsFor(b, a.name, a.name);
                        d.description = desc;
                        d.userMade = true;
                        ws.itemEdited = true;
                        if (ws.range) ws.range->items.reset();
                    }
                    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", behaviourInfo(b));
                }
                ImGui::EndCombo();
            }
            prop("Description", "A line for the Assets panel");
            char buf[200];
            std::snprintf(buf, sizeof buf, "%s", d.description.c_str());
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::InputText("##desc", buf, sizeof buf)) d.description = buf;
            endProps();
        }
        pushFont(fonts.small);
        ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
        ImGui::TextDisabled("%s", behaviourInfo(d.behaviour));
        ImGui::Dummy(ImVec2(0, 2 * s));
        for (const std::string& line : glance(d)) ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::accent), "%s", line.c_str());
        ImGui::PopTextWrapPos();
        popFont();

        bool hasMuzzle = false, hasGrip = false;
        for (const Socket& sk : a.sockets) { hasMuzzle |= sk.name == "muzzle" || sk.name == "blade_tip"; hasGrip |= sk.name == "grip"; }
        if (!hasGrip || (!hasMuzzle && d.behaviour != Behaviour::Thrown && d.behaviour != Behaviour::Tool)) {
            pushFont(fonts.small);
            ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
            ImGui::TextColored(ImGui::ColorConvertU32ToFloat4(col::warning), "%s",
                               !hasGrip ? "Add a socket named 'grip' where the hand holds it (Socket tool)."
                                        : d.behaviour == Behaviour::Melee ? "Add a socket named 'blade_tip' at the end it hits with." : "Add a socket named 'muzzle' where shots leave from.");
            ImGui::PopTextWrapPos();
            popFont();
        }
    }

    // ---- stats
    section("Stats");
    if (beginProps("##istats", 96)) {
        ItemStats& st = d.stats;
        const Behaviour b = d.behaviour;
        const bool gun = b == Behaviour::Hitscan || b == Behaviour::Projectile;
        if (b != Behaviour::Tool) slider("Damage", b == Behaviour::Hitscan ? "Per bullet" : "Per hit (a blast hurts less far from its middle)", "##dmg", &st.damage, 0.0f, 500.0f, "%.0f");
        slider(b == Behaviour::Melee ? "Swings" : b == Behaviour::Tool ? "Uses" : b == Behaviour::Thrown ? "Throws" : "Fire rate", "Per second", "##rate", &st.fireRate, 0.2f, 20.0f, "%.1f /s", true);
        if (gun) {
            prop("Automatic", "Hold the button to keep firing");
            ImGui::Checkbox("##auto", &st.automatic);
        }
        if (gun || b == Behaviour::Thrown) {
            islider(b == Behaviour::Thrown ? "Carries" : "Magazine", "How many before it needs reloading. 0 means never.", "##mag", &st.magazine, 0, 200, st.magazine == 0 ? "never reloads" : "%d");
            if (st.magazine > 0) slider("Reload", "Seconds to reload (press R, or it happens by itself when empty)", "##reload", &st.reloadTime, 0.1f, 6.0f, "%.1f s");
        }
        if (b == Behaviour::Hitscan) islider("Pellets", "Bullets in every shot. Many with a wide spread makes a shotgun.", "##pel", &st.pellets, 1, 16, "%d");
        if (gun) {
            slider("Spread", "How far a bullet can stray from where you aim", "##spread", &st.spread, 0.0f, 12.0f, "%.1f deg");
            slider("Recoil", "How far the view kicks up on every shot", "##recoil", &st.recoil, 0.0f, 12.0f, "%.1f deg");
        }
        if (b == Behaviour::Projectile || b == Behaviour::Thrown) {
            slider("Speed", "Metres per second it leaves at", "##speed", &st.speed, 3.0f, 200.0f, "%.0f m/s", true);
            slider("Gravity", "How fast it falls. 0 flies straight.", "##grav", &st.gravity, 0.0f, 40.0f, "%.0f");
        }
        if (b == Behaviour::Thrown) {
            slider("Fuse", "Seconds before it goes off. 0 means it goes off when it hits something.", "##fuse", &st.fuse, 0.0f, 10.0f, st.fuse < 0.05f ? "on impact" : "%.1f s");
            slider("Bounce", "How much speed a bounce keeps", "##bounce", &st.bounce, 0.0f, 0.9f, "%.2f");
        }
        if (b == Behaviour::Melee) {
            slider("Reach", "How far it hits", "##reach", &st.range, 0.8f, 6.0f, "%.1f m");
            slider("Swing", "How wide the swing is", "##arc", &st.swingArc, 20.0f, 200.0f, "%.0f deg");
        } else if (b == Behaviour::Tool) {
            slider("Reach", "How far away it works", "##reach", &st.range, 3.0f, 60.0f, "%.0f m", true);
        } else if (b == Behaviour::Hitscan) {
            slider("Range", "How far a bullet carries", "##range", &st.range, 10.0f, 400.0f, "%.0f m", true);
        } else {
            slider("Range", "How far it flies before it gives up", "##range", &st.range, 10.0f, 400.0f, "%.0f m", true);
        }
        endProps();
    }

    // ---- what it does to the world
    section("What it does to the world");
    if (beginProps("##ieffect", 96)) {
        ItemEffect& ef = d.effect;
        const bool blast = d.behaviour == Behaviour::Projectile || d.behaviour == Behaviour::Thrown;
        prop("Effect", "What a hit does to the ground and walls");
        ImGui::SetNextItemWidth(-FLT_MIN);
        if (ImGui::BeginCombo("##effect", ef.kind == WorldEffect::None ? "Nothing" : ef.kind == WorldEffect::Carve ? "Digs a hole" : "Builds a lump")) {
            if (ImGui::Selectable("Nothing", ef.kind == WorldEffect::None)) ef.kind = WorldEffect::None;
            if (ImGui::Selectable("Digs a hole", ef.kind == WorldEffect::Carve)) ef.kind = WorldEffect::Carve;
            if (ImGui::Selectable("Builds a lump", ef.kind == WorldEffect::Build)) ef.kind = WorldEffect::Build;
            ImGui::EndCombo();
        }
        if (ef.kind != WorldEffect::None) slider(blast ? "Blast size" : "Size", "Radius in metres", "##erad", &ef.radius, 0.1f, 12.0f, "%.1f m", true);
        if (blast) slider("Push", "How hard a blast shoves whoever is standing near it. Try a rocket jump.", "##epush", &ef.push, 0.0f, 40.0f, "%.0f");
        endProps();
        if (ef.kind == WorldEffect::Build) {
            pushFont(fonts.small); ImGui::TextDisabled("Made of"); popFont();
            materialPalette(renderer, ef.material, false);
        }
    }

    // ---- how it feels
    section("How it feels");
    if (beginProps("##ifeel", 96)) {
        ItemFeel& f = d.feel;
        prop("Sound", "What you hear when it goes off");
        clipCombo(*this, "##fire", f.fireSound, kFireClips);
        prop("Hit sound", "What you hear where it lands");
        clipCombo(*this, "##hit", f.impactSound, kHitClips);
        slider("Volume", nullptr, "##vol", &f.volume, 0.0f, 1.5f, "%.2f");
        slider("Pitch", "Lower is heavier, higher is snappier", "##pitch", &f.pitch, 0.4f, 2.0f, "%.2f");
        slider("Shake", "How much the view shakes when it goes off", "##shake", &f.shake, 0.0f, 3.0f, "%.2f");
        if (d.behaviour == Behaviour::Hitscan || d.behaviour == Behaviour::Projectile) {
            prop("Muzzle flash", nullptr);
            ImGui::Checkbox("##flash", &f.muzzleFlash);
        }
        if (d.behaviour == Behaviour::Hitscan) {
            prop("Tracer", "A streak of light along the shot");
            ImGui::Checkbox("##tracer", &f.tracer);
            if (f.tracer) { ImGui::SameLine(); ImGui::ColorEdit3("##tcol", &f.tracerColour.x, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel); }
        }
        endProps();
    }

    // ---- in the hand
    section("In the hand");
    if (beginProps("##ihold", 96)) {
        ItemHold& h = d.hold;
        slider("Right", "Sideways, from the middle of the view", "##hx", &h.offset.x, -0.7f, 0.7f, "%.2f m");
        slider("Up", nullptr, "##hy", &h.offset.y, -1.0f, 0.4f, "%.2f m");
        slider("Forward", "How far in front of you", "##hz", &h.offset.z, 0.1f, 1.4f, "%.2f m");
        slider("Turn", "Aim it left or right of straight ahead", "##hyaw", &h.rotation.y, -60.0f, 60.0f, "%.0f deg");
        slider("Tilt", "Point it up or down", "##hpitch", &h.rotation.x, -60.0f, 60.0f, "%.0f deg");
        slider("Roll", "Lean it over", "##hroll", &h.rotation.z, -90.0f, 90.0f, "%.0f deg");
        slider("Size", "Scales the model in the hand only", "##hscale", &h.scale, 0.3f, 2.5f, "%.2f", true);
        endProps();
        if (ImGui::Button("Reset the hold", ImVec2(-FLT_MIN, 0))) d.hold = ItemDef::defaultsFor(d.behaviour, d.name, d.asset).hold;
        if (!ws.rangeOn) {
            pushFont(fonts.small);
            ImGui::PushTextWrapPos(ImGui::GetContentRegionMax().x);
            ImGui::TextDisabled("Enter the firing range to see it in your hand while you adjust.");
            ImGui::PopTextWrapPos();
            popFont();
        }
    }
    ImGui::Dummy(ImVec2(0, 12 * s));

    d.clamp();
    if (!(d == before)) ws.itemEdited = true;
}

} // namespace px
