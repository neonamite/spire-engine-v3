## v2.0 Preview — Checkpoint C9 (2026-10-13)
- Planet-aware World inspector; hides flat-only regenerate settings in planet mode.
- Fly to Surface / Local Aerial View camera controls, save path, seed, radius and gravity details.
- Planet-safe Clear All Edits, preserving flat-world backups; flat-only sea command disabled for planet mode.
- Added a headless editor safety test and re-ran planet save/streaming/creator integration regressions.
- Windows editor runtime rendering still unverified. See docs/PLANETARY_MILESTONE_C9.md.

## v2.0 Preview — Checkpoint C8 (2026-10-13)
- Added Planet Creator dialog in Project Hub and File menu; generates real local spherical voxel worlds via ChunkManager.
- Added preset, seed, radius, gravity, relief and noise controls with prototype-safe bounds and editor-only mode.
- Added named, collision-safe .vxplanet saves and a saved-planet opening workflow, leaving legacy .vxworld data untouched.
- Added new CPU creator-model and creator-integration tests; syntax-checked new UI with bundled headers.
- Full Windows/graphics build and live rendered editor remain unverified. See docs/PLANETARY_MILESTONE_C8.md.

## v2.0 Milestone C5 (prototype) — Adaptive planetary tile selection — 2026-10-13

- Added deterministic CPU quadtree selection across six cube-sphere faces, refining terrain based on approximate projected screen error.
- Added optional horizon culling, level limits, and a hard active-tile budget to prevent unbounded allocations.
- Added `PlanetLodSelectorTests` for deterministic output, maximum LOD and tile budget, horizon behavior and invalid requests.
- Selection remains CPU-side and not connected to the GPU or voxel world streaming.

## v2.0 Milestone C4 (prototype) — Cube-sphere surface LOD patches — 2026-10-13

- Added an independent CPU `PlanetSurfacePatch` mesh generator using cube-face tile addresses and double-precision patch origins.
- Generated local float vertex offsets for large-radius planetary surfaces; optional skirts mask LOD gaps until full seam stitching exists.
- Tested all cube-face boundaries, normal lengths, skirts, large-radius and fine-resolution tile geometry.
- This is not yet connected to the live GPU renderer or the volumetric Marching Cubes pipeline.

## v2.0 Milestone C3 (prototype) — Experimental planet save format — 2026-10-13

- Added a separately versioned `.vxplanet`/`VXPL` binary format for prototype planet definitions, replayable terrain edits, and optional scene data.
- Added strict scalar encoding, bounded allocations, corrupt/truncated file validation, and transactional loading before world mutation.
- Connected editor Save/Load to `worlds/sandbox/local-planet.vxplanet` while a planet is active; normal `.vxworld` remains unchanged.
- Planet autosave remains off; runtime Windows build and UI persistence remain unverified.
- Added `PlanetPersistenceTests` to the headless CPU test suite.

## v2.0 Milestone C (prototype) — Local planet editor + radial camera — 2026-10-13

- Added an opt-in `--demo planet` / `planetclean` editor view using the real spherical voxel chunk worker pipeline.
- Added `PlanetChunkAddress` as a tested sector-local 64-bit chunk identity for a future live registry migration.
- Added a radial-up camera basis with backward-compatible flat-world yaw and movement.
- Prevented automatic legacy `.vxworld` saves while the experimental planet is active.
- Updated the marketing capture runner with explicitly labeled experimental planetary shots.
- Headless CPU tests pass with GCC and Clang; the full OpenGL editor runtime is **not** verified.

## v2.0 Milestone B (in development) — Planetary CPU voxel streaming — 2026-10-13

- Added opt-in `ChunkManager::startPlanetaryPrototype()` on the existing async chunk workers.
- Generated radial spherical terrain into padded `VoxelChunk` density/material arrays and Marching Cubes meshes.
- Introduced prototype 3D camera-neighborhood chunk streaming, radial up query, and edit-history isolation from flat worlds.
- Preserved legacy v1.6 flat generation and `.vxworld` version 3 save compatibility; planetary saves are explicitly blocked.
- Added headless `PlanetaryStreamingTests`, build script, and verification notes. No full editor build/launch claim.

# Changelog

Spire Engine (called Project X until 1.0), from the first rebuild to 1.6. Newest first. (Details of how each part works are in
[docs/ENGINE.md](docs/ENGINE.md); what comes next is in [docs/ROADMAP.md](docs/ROADMAP.md).)

## 1.6 — Clothes that hang, hair that moves

- **Clothes hang like clothes.** A top falls from the chest and shoulder blades instead of clinging to the waist;
  sleeves and trouser legs are round and loose; trousers fall straight from the knee and gather above the shoes.
  Folds bunch at the inside of the elbows and behind the knees. Every hem, cuff and collar is turned in, so the cloth
  has a thickness where it ends.
- **Skirts, robes and long coats are cloth**, not sculpted parts: they hang from the waist round the legs, flare and
  pleat toward the hem, and swing with each leg as people walk. A long coat opens down the front. Under a skirt or a
  robe the legs are bare.
- **Hair and hems move.** Each person has a sway: loose things lag when they start and stop, swing with each step,
  bob, and stir in a breeze. Long hair streams back when they run; short hair barely moves; a skirt's hem sways most.
  Done on the graphics card (no cost per vertex on the CPU), the same in the shadows.

## 1.5 — Realistic people

- **Real human bodies.** Every person is now the MakeHuman base human (released as CC0, free to ship and sell),
  shaped by MakeHuman's own body targets: **gender, age, muscle, weight** and three **heritages** (African, Asian,
  European, mixed), plus face shapes. Real proportions, real hands and feet, a real face. The skeleton now has those
  proportions too, and the body is fitted to it, so every animation, IK, held item and NPC works as before.
- **Skin** in the person's colour over detail maps baked on the body's own layout: lips, flushed cheeks, nose and
  ears, freckles and blotches, creases, a lash line, nails, and eyebrows hair by hair; with the Skin material's pores
  on top and light passing through it.
- **Eyes** are eyeballs with a real iris (in the person's eye colour) and a wet shine. Teeth and tongue are there.
- **Faces move.** Blinks, smiles, frowns, a pressed mouth, raised, angry and worried brows are shape changes mixed on
  the graphics card each frame, so moods show on the face, no head swapping.
- **Hair and beards are strands**: thousands of see-through cards grown over the scalp for each style (short,
  long, bun, ponytail, curly, spiky, mohawk) and over the jaw for beards (full, moustache, goatee), with a scalp layer
  under them. Under a hat only what shows below it is grown.
- **Clothes** are layers made from the body itself, smoothed so they pass over the body's details rather than cling,
  lifted off the skin with soft folds, with clean hems, cuffs and collars. Shoes, boots, skirts, robes, hats, glasses
  and backpacks are the parts they were, fitted onto the new body and head.
- **Character Studio:** new *Body* sliders (gender, age, muscle, weight), *Features*, *A new face*, and an eye colour.
  Characters saved before 1.5 get a body to match them (from their hair, build and skin). Thumbnails show the new
  people. `--voxel-people` draws people the 1.4 way.
- `tools/makehuman/convert.py` turns the MakeHuman data into the engine's pack (`engine/assets/human/`).

## 1.4 — Hands, feet and forests

- **Hands and feet are part of the body.** They are now fused into the one skinned surface, at finer detail than the
  rest (3.5 mm for hands, 5 mm for feet, against 8 mm for the body), so the line at the wrists and ankles is gone:
  the sleeve or forearm flows into the hand and the trouser or shin into the shoe.
- The head stays its own piece on purpose: the face changes shape with every blink, word and mood, which a fused
  body cannot do without rebuilding it. The join sits under the jaw, where it is hidden.
- **Trees.** The world now grows oaks, birches, pines and bushes on its grass by itself: pines thicken into
  forests towards the snow line, birches stand in groups, bushes fill in between. Three shapes of each, sculpted
  (bark with furrows and root flares, forking limbs, crowns of many leafy clumps, drooping tiers of needles, birch
  bark with its black marks), each with a detailed model up close and a lighter one in the distance. Built in the
  background as the editor opens.
- Trunks are solid (you walk round them), trees keep clear of water and of anything you build or place, and
  foliage casts soft shadows and lets light through.
- **Settings > Graphics** has **Trees** and **Tree distance** (part of the presets: 90 m on Low to 300 m on Ultra);
  **Environment > Trees** sets how many. The oak, pine, birch and bush are also on the Shelf as props.
- New material: **Needles** (for the pines).

## 1.3 — People in one piece

- **Smooth skinning.** A character's hips, torso, neck, arms and legs are now one continuous body that bends with
  the skeleton, instead of rigid pieces that part at the joints: knees, elbows, shoulders, hips and the waist bend
  and stretch like skin. Whatever they wear there (built-in clothes or parts you made in the Workshop) is fused
  into that one surface, keeping its materials and colours. The head, hands, feet, hair and accessories stay as
  their own pieces on their bones.
- Skinning runs on the graphics card (up to four bones per vertex), in shadows and ambient occlusion too, and the
  fine surface detail (weave, pores) turns with the body.
- Bodies are built once per look (about a tenth of a second) and remembered; a crowd that arrives all at once is
  spread over a few frames, drawn part by part until each body is ready.
- The parts are joined with a smooth blend, so where a thick thigh meets a slimmer shin, or a sleeve meets a forearm,
  the surface flows from one to the other. Bodies are built with the arms out and the legs apart, so a hanging hand
  never melts into the hips.
- Thumbnails still draw people part by part; `--rigid-characters` draws everyone that way (to compare).

## 1.2 — 2026 graphics: lighting, 4K materials, sculpted models

- **New lighting.** Physically based shading (GGX highlights, energy-correct reflections of the sky, metals that look
  like metal), **soft cascaded shadows** (four cascades, sharp up close and reaching far), **ambient occlusion** (soft
  contact shadow in corners, under things, between stones), and a better balance of sun and sky light.
- **4K materials.** Every material is a full physically based set (colour, normal, roughness, metalness, crevice
  shadow), generated at **512, 1K, 2K or 4K** per material (**Settings > Graphics > Surfaces > Texture detail**, part of
  the quality presets: Ultra is 4K), compressed on the graphics card, built in the background and cached on disk.
  Bricks are brick-sized, pebbles pebble-sized; terrain borders follow the ground instead of the triangles.
- **18 new materials:** Moss, Gravel, Mud, Sandstone, Cobblestone, Marble, Concrete, Slate, Roof tiles, Rust, Bark,
  Leaves, **Glass** (dark, reflects the sky), **Gold** and **Steel** (polished metals), and for people **Skin** (light
  passes through it, so faces are soft), **Hair** and **Leather**, which take a person's own colours.
- **Texture packs:** put your own photo textures in `textures/<pack>/<material>/` and pick the pack in Settings. See
  [docs/TEXTURE_PACKS.md](docs/TEXTURE_PACKS.md).
- **Buildings, rebuilt** (all five kits, at 4 cm detail): walls on a weathered plinth with a moulded cap; glazed sash
  windows (or big modern panes) set back in the wall with stone sills and lintels; doorways with linings,
  architraves, a cornice and a threshold; roofs with real thickness, eaves that overhang, stepped tile or slate
  courses, rafter tails, a fascia, a gutter and a ridge cap; stairs with nosings and stringers; classical columns,
  chamfered timber posts or steel columns. More realistic kit looks (Brick house: clay tiles and white sashes; Stone
  keep: coursed stone and slate; Modern: render, concrete and slim metal frames).
- **Props, rebuilt** in fine detail with the same names, sizes and origins, so existing worlds just look better: a
  fractured, weathered **boulder** with moss on top; a planked, braced **crate** with steel corners; a brick **stone
  arch** with dressed quoins, voussoirs and a keystone; monumental **steps** with nosings and cheek walls; a cast-iron
  **lamp post** with a fluted shaft and a glowing glazed lantern; a strata-banded **stone pillar** with grass on top.
  Gold coins (with a star and a milled edge), gold keys, brass door handles, a steel-barrelled rifle.
- **People, sculpted.** Every body part was re-modelled: a torso with a chest, shoulder blades, a waist and a sloping
  shoulder line; arms with biceps, triceps and a wrist; hands with four jointed fingers and a thumb; legs with a knee,
  calf and shin; trousers that fall straight and break over real shoes (sole, heel, laces); a belt. **Faces** have
  eyeballs in sockets under lids (the eye style now sets how open they are), brown irises, a nose with a bridge, a tip
  and nostrils, lips whose corners turn up or down (the mouth style), cheekbones, a jaw and chin, and ears.
  Eyebrows take the person's hair colour. Hair is combed, with a natural hairline. Face style names follow:
  Eyes *Natural / Round / Narrow / Sleepy / Wide*, Mouth *Relaxed / Smile / Pressed / Grin / Frown*.
- Fixed: shapes blended together in the Workshop could leave specks of the wrong material in the seam.
- Fixed: far-away flat ground could show faint bands of false shadow.

## 1.1 — Spire Engine, and a new editor

- **New name:** Project X is now **Spire Engine**, by Black Spire Studios. The program is `SpireEngine`; worlds, assets,
  people and shared games from 1.0 open as before.
- **A new editor layout**, built around doing less work to find things and do them:
  - **Four modes** (Shape, Build, People, Logic). Each shows only its own tools and its own shelf.
  - **Edges for the important things.** Play sits in the middle of the top edge; the tool strip runs down the left
    edge, every tool with its name and key.
  - **An action bar above whatever you select** (move, turn, resize, duplicate, Rules, focus, delete), where you are
    already looking.
  - **The quick wheel:** hold Space, flick, let go.
  - **The Shelf:** pictures of everything you can place, Recent first, with filters and search.
  - **Details:** what is selected, with the settings you change most up front and the rest in drawers that say what is
    inside while closed. With nothing selected it shows the current tool's settings.
  - **Find anything** (Ctrl+K), a project menu for File / Edit / View, and the X / Y / Z directions over the view.
- **A new look, "Obsidian & Neon":** near-black greys, a neon cyan that only ever means "selected / you are here", and a
  fuse orange that only ever means "live" (Play, and the glowing edge while you play from the editor). New fonts: Geist
  for the interface, Geist Mono for numbers, Unbounded for the wordmark. X / Y / Z fields are red, green and blue.
- **A new Project Hub:** start an empty world or a ready-made game (Parkour, Coin Hunt, Capture the Flag, Survival) in
  one click; Play and Open for each of your games.
- The Character Studio and the Asset Workshop share the new header; the tutorial follows the new layout.
- The panel layout is saved in `config/layout-1.1.ini`, so 1.0's saved layout is left alone.

## 1.0 — stable

- **Stability pass.** The whole engine was checked with AddressSanitizer, UndefinedBehaviorSanitizer and
  LeakSanitizer (unit tests and the end-to-end self tests): no memory errors, no undefined behaviour, no leaks.
- **Damaged files never crash it.** Every reader (worlds and scenes, rules, people, NPCs, game rules, blueprints,
  items, settings, `.pxasset` voxel files, shared-game files) is fed thousands of cut-off and scrambled copies in the
  tests; they are refused or mended, never a crash.
- **A soak test** (`--demo soak_selftest`): two minutes of being chased, a village through 24 hours, play started and
  stopped fifty times, 150 edits undone and redone; nothing drifts, leaks or turns into NaN.
- `tools/run_selftests.sh` / `.bat` run all thirteen end-to-end self tests in one go.
- Final docs: this changelog, the README's feature overview and known limits, the 1.0 engine status.

## 0.24 — polish

A first-run tutorial whose steps finish when you actually do each thing; rebindable keys and toggle run
(Settings > Controls); colour-blind friendly colours, a bigger crosshair and messages, captions for game sounds,
reduce motion (Settings > Accessibility).

## 0.23 — Share

File > Share Game packs a game into a folder that runs on its own: the program, the world, what you made, a
`game.pxgame` file and Play launchers. Started from such a folder the program goes straight into the game.

## 0.22 — game rules and templates

A goal (reach the finish, collect everything, get points, survive), a time limit, lives, falling and checkpoints,
where you start, start / win / lose messages. Five starter templates: Parkour, Coin Hunt, Capture the Flag, Survival,
Sandbox.

## 0.21 — "When this happens → do that"

Rules on any object, written as sentences with no code: 7 triggers, 17 actions, delays, "only the first time".
Ten gadgets with their rules (door, gate, pressure plate, button, coin, gem, key, sign, teleporter, finish flag).
E to use things, points, win and lose screens.

## 0.20 — NPCs that live

People wander, patrol, guard, follow you or go to work; they react when you come close (friendly, shy, scared), say
their lines in speech bubbles, wear name tags and follow a daily schedule.

## 0.19 — people with personality

Faces that blink and show moods; 34 clothes and accessories; accent and per-part colours; move styles and idle
habits; Surprise me; Make a Crowd.

## 0.18 — characters

The Character Studio, procedural animation with foot IK, people placed in the world, third person.

## 0.17 — Blueprint Tool

Draw rooms on a floor plan and get the whole building, roof and stairs included; edit and rebuild in place.

## 0.16 — Building Kits

Five kits of snap-together walls, windows, doorways, floors, roofs, stairs and pillars; restyle in one click.

## 0.15 — richer materials

Plaster, tile, cloth, ice, lava, lamps, crystal and nine paint colours.

## 0.14 — Item & Weapon Builder

Items with five behaviours, `.pxitem` files, a hotbar, the firing range.

## 0.13 — Asset Workshop

Build your own assets from fine voxels, saved as `.pxasset` files.

## 0.12 — objects

Place, move, turn, resize, group and animate objects; Outliner, Assets and Properties panels; one undo history.

## 0.11 and earlier

Graphics presets and display settings (0.11); dockable editor, command palette, autosave and crash recovery,
bookmarks (0.10); audio (0.9); water and grass (0.8); materials and painting (0.7); HDR, sky and day / night (0.6);
the Project Hub (0.5); engine and game separated (0.4); the real editor UI with undo (0.3); the clean rebuild (0.2).

## Spire v2.0 Checkpoint C6 (2026-10-13)
- Added asynchronous CPU planetary surface-tile streamer with bounded queue, obsolete-job cancellation, result collection and patch cache.
- Added headless tests for tile lifecycle, epoch invalidation, reuse, and failure recovery.
- No OpenGL editor rendering integration is claimed.

## Spire v2.0 Checkpoint C7 (2026-10-13)
- Added safe sector-precision camera-relative planetary draw-packet conversion (CPU-only).
- Added standalone draw-packet tests and finite-planet configuration validation.
- Added Windows smoke-test checklist; GPU upload and live orbital LOD remain future work.

## v2.0 Checkpoint C10 (2026-10-13)
- Added headless quadtree selection/streamer coordination with coherent parent fallback.
- Added C10 regression test and test target. Existing flat worlds unchanged.

## v2.0 Checkpoint C11 (2026-10-13)
- Experimental orbit-mode renderer-owned GPU patch buffer upload, camera-relative orbit shader, opt-in camera shortcut, and lifecycle in the editor.
- Critical limitation: orbital preview is a separate surface model, not edited voxel terrain. Full Windows graphics build unverified.

## WB11 — Linux graphics dependency bootstrap
- Added `tools/bootstrap_graphics_linux.sh` with Linux system prerequisites, vcpkg manifest bootstrapping, Ninja configuration, full build, and CTest fail-fast checks.
- Added `docs/LINUX_BUILD.md` for Debian/Ubuntu, custom vcpkg locations, offline restrictions, and verification boundaries.
- No gameplay, renderer, or editor C++ source was modified.
