# Spire Engine v3 — Windows application build and verification

This is a **build procedure**, not a declaration that an executable was built.

## Prerequisites

- Windows 10/11, Visual Studio 2022 with C++ desktop tools, CMake 3.21+, Git.
- vcpkg with the dependencies declared in `vcpkg.json` (GLM, SDL3, glad, ImGui and any manifest dependencies).
- Set `VCPKG_ROOT` to the directory that contains `scripts/buildsystems/vcpkg.cmake`.

## Configure, compile, test

Run the following in a **Developer PowerShell for VS 2022** from the repository root:

```powershell
python tools_build_preflight.py
cmake -S . -B build-v3 -G "Visual Studio 17 2022" -A x64 -DCMAKE_TOOLCHAIN_FILE="$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" -DPROJECTX_BUILD_TESTS=ON
cmake --build build-v3 --config Release --parallel
ctest --test-dir build-v3 -C Release --output-on-failure
```

The executable should be located at a path such as `build-v3/Release/SpireEngine.exe`, depending on the configured generator. **Do not distribute it unless the executable actually builds and runs.** Launch from the project root or configure asset working directories as required.

## Manual editor smoke test

1. Open the Project Hub. Select New Project → Blank World Builder, confirm a level canvas.
2. Use World Inspector brushes, roads, and construction workspaces.
3. Save, reopen, confirm scene and voxel edits persist; verify undo/redo.
4. Choose the optional generated terrain workflow and verify it creates a new world.
5. Create/open a small experimental planet and try its world inspector and flight camera.
6. Try exiting to Hub, switching back to blank worlds, and restoring a saved flat-world project.
7. Check console/logs for crashes, missing assets, and failed shader compilation.

## Optional headless syntax check

`python tools_source_integration_check.py --compiler g++ --include PATH_TO_NATIVE_DEPENDENCY_HEADERS`

This syntax-only check is useful before a full build, but cannot catch link errors, graphics-runtime faults, shader failures, or missing CMake package configs. On Linux, using headers from a Windows vcpkg tree is **not** a verified Linux build.
