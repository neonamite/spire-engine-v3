# Spire Engine — Marketing First + Revised Roadmap Update

**This is an additive documentation/marketing update, not a new engine build.** It is designed to be merged into your existing `SpireEngine` directory (including your newer uploaded Planetary Foundation A copy). No C++ files are changed.

## Apply

1. Back up your current project.
2. Extract this ZIP so the enclosed `SpireEngine/` directory merges with your existing `SpireEngine/`.
3. Allow `SpireEngine/docs/ROADMAP.md` to replace the old roadmap. The exact original roadmap from the most recent uploaded ZIP is included as `SpireEngine/docs/ROADMAP_v1.6_ARCHIVE.md`.
4. Open `SpireEngine/marketing/screenshots/concepts/00_concept_contact_sheet.jpg` to review the eight visibly labeled concept previews.
5. Use `SpireEngine/marketing/screenshots/SHOT_LIST.md` to capture genuine editor/game screenshots and place them under `captured/`.

## Why it ships as an additive update

The uploaded source archive included generated build output and third-party installed dependencies. This update avoids repackaging those caches and does not redistribute its bundled fonts, binary dependencies or other project assets. Your existing source tree remains authoritative.

## Verification completed

- Checked that all 200 master feature numbers appear exactly once and in order.
- Verified the current uploaded archive contains the isolated planetary-prototype headers and tests.
- Confirmed no actual engine screenshot images were packaged in the source archive.
- Created eight visibly labeled conceptual marketing panels; none are described as actual screenshots.
- No engine build or runtime tests were run as part of this marketing/docs update.
