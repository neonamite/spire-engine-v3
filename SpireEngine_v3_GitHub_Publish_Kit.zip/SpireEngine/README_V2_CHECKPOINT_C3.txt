SPIRE ENGINE v2.0 — MILESTONE C3 CHECKPOINT
October 13, 2026

This is a development SOURCE checkpoint, not a compiled game executable.

Patches and installation:
  - If you already have SpireEngine v2.0 Milestone B applied, merge the
    C3_Cumulative patch's SpireEngine/ directory into your existing folder.
  - C3 includes all files modified in C1 and C2. Do not apply those earlier
    incremental patches again after C3.
  - Keep a backup of your v1.6 world data and source folder first.
  - The optional consolidated source overlay excludes redistributable fonts,
    compiled binaries, vcpkg dependencies and build outputs. Keep these from
    your existing project. It is not intended to run as a standalone download.

What is new:
  - Opt-in local spherical terrain demo: --game sandbox --demo planet
  - Radial-up editor camera with E/Q along local up
  - High-precision sector-local chunk address math and tests
  - Optional experimental .vxplanet planet save/load (manual, autosave off)
  - Genuine screenshot capture tooling for planet demo (only after build)

Headless CPU verification:
  - PlanetaryFoundationTests             PASS (GCC, Clang)
  - PlanetChunkAddressTests              PASS (GCC, Clang)
  - PlanetCameraTests                    PASS (GCC, Clang)
  - PlanetaryStreamingTests              PASS (GCC, Clang)
  - PlanetPersistenceTests               PASS (GCC, Clang)

NOT verified: Windows/SDL3/OpenGL/ImGui full compile/link, GUI gameplay, actual
visual planet screenshots, orbital rendering, sector-local active registry,
planet-scale coordinates, advanced physics or network replication.

See docs/PLANETARY_MILESTONE_C1.md, C2.md, and C3.md for details.
