SPIRE ENGINE v2.0 — CHECKPOINT C4 (October 13, 2026)

C4 includes and supersedes C1, C2, and C3. It requires Milestone B as its
base if applying only the cumulative source patch.

SOURCE CHANGES SINCE MILESTONE B:
- Local opt-in planetary demo: --game sandbox --demo planet
- Radial-up editor camera and experimental manual .vxplanet save/load
- 64-bit sector-local chunk address math and high-range precision tests
- Cube-sphere quadtree surface patch geometry in double-origin/local-float format
- Surface skirts and CPU cross-face geometry seam tests
- Marketing capture runner with two experimental planet screenshot modes

HEADLESS TESTS:
Six CPU suites passed using GCC/C++20. New C4 geometry suite also passed using
Clang/C++20; earlier five suites passed on Clang at the C3 checkpoint.

NOT VERIFIED:
Compiled/running Windows SDL3/OpenGL editor, renderer integration of LOD
patches, full gameplay, planet-scale chunk registry or stable planet save format.

INSTALL:
Keep backups. Merge the patch's SpireEngine folder over Milestone B. If using
consolidated source overlay, merge into your existing project (it excludes
font binaries, downloaded build dependencies and executables).

IMPORTANT: v2.0 is a prototype. Default flat worlds and legacy `.vxworld`
serialization are intentionally preserved. Use the planet mode only for
experimentation, not your only copy of any world.

See docs/PLANETARY_MILESTONE_C1.md through C4.md.
