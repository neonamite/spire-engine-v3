# Spire Engine 1.6 — Voxel Game Engine

**Spire Engine** (formerly Project X), by Black Spire Studios, is a C++20 voxel game engine with a built-in editor, made so that anyone can make a game: infinite
streaming terrain with caves and overhangs, real-time sculpting, physically based materials up to 4K you can build with
and paint (or replace with your own photo textures), an HDR renderer with an atmospheric sky, day and night, soft
cascaded shadows, ambient occlusion, water, grass and forests, and a play mode you can drop into at any moment.

**What you can do with 1.6**

- **Shape worlds:** carve, build, smooth, flatten and paint the ground; water, grass, trees and forests, day and night.
- **See it in 2026 quality:** physically based lighting with soft cascaded shadows and ambient occlusion, 4K
  materials, your own photo texture packs, sculpted buildings and props (1.2), and **realistic people** (1.5): real
  human bodies with painted skin, real eyes, faces that move, hair and beards made of strands, and clothes that
  hang and swing (1.6).
- **Make things:** the **Asset Workshop** (build any object from fine voxels), the **Item Builder** (guns, launchers,
  grenades, swords, tools), **Building Kits** (snap-together walls, floors, roofs, stairs in five styles) and the
  **Blueprint Tool** (draw rooms, get the whole house).
- **Make people:** the **Character Studio** (body, face, hair, clothes, hats, glasses, beards, move style and habits),
  **Make a Crowd** (dozens of different people at once), and **NPCs that live** (wander, patrol, guard, follow, work,
  talk, react to you, keep a daily schedule).
- **Make it a game, without code:** **"When this happens → do that" rules** on any object, **gadgets** (doors, gates,
  plates, buttons, coins, gems, keys, signs, teleporters, finish flags), **game rules** (goal, clock, lives,
  checkpoints) and **starter templates** (Parkour, Coin Hunt, Capture the Flag, Survival).
- **Share it:** **File > Share Game** packs it into a folder anyone can run.
- **For everyone:** a first-run tutorial, rebindable keys, colour-blind friendly colours, captions, a bigger HUD,
  interface size and reduce motion.

What changed in each version is in **[CHANGELOG.md](CHANGELOG.md)**.

You run **SpireEngine.exe** (the engine). It opens the **Project Hub**, where you
pick a game to open in the editor or play. Games are built **on top of** the
engine, each in its own folder, and register themselves with the hub:

| | |
|---|---|
| `engine/` | **Spire Engine** (library + editor). Knows nothing about any specific game. |
| `games/vanguard/` | **Vanguard** (working title): superpowers and a living PvP world. See its [README](games/vanguard/README.md). |
| `games/template/` | The smallest possible game. Copy it to start a new one. |
| `tests/` | Engine tests. |

Docs:
- **[docs/ENGINE.md](docs/ENGINE.md)**: engine design and structure
- **[docs/ROADMAP.md](docs/ROADMAP.md)**: 188 planned engine features, prioritised
- **[docs/CREATION.md](docs/CREATION.md)**: how people, buildings and weapons will be made
- **[games/vanguard/README.md](games/vanguard/README.md)**: the Vanguard game design

---

## Build (Windows + Visual Studio)

You already have vcpkg at `E:\vcpkg` and CMake from the earlier setup. Dependencies
are listed in `vcpkg.json`, so **vcpkg installs them automatically** the first time
you configure. No manual `vcpkg install` needed.

1. Unzip this folder somewhere, e.g. `E:\SpireEngine`.
2. Open **CMake GUI**
   - *Where is the source code:* `E:/SpireEngine`
   - *Where to build the binaries:* `E:/SpireEngine/build`
3. **File → Delete Cache** (only matters if you reuse an old build folder).
4. **Configure** → pick *Visual Studio 18 2026* (or 17 2022), platform **x64** → Finish.
   The first configure takes several minutes while vcpkg builds SDL3, ImGui, etc.
5. **Generate**, then **Open Project**.
6. In Visual Studio press **F5**. **SpireEngine** is the startup project. It opens
   the Project Hub; click **Open in Editor** or **Play** on Vanguard.
   Skip the hub with a command argument: `--game vanguard` (or `--game sandbox`).
   In the editor, **File → Back to Project Hub** or **File → Switch Game** moves between games.
7. Optional: build **EngineTests** (or run `ctest` in the build folder) to check
   the engine still works after you change it. For an end-to-end check of the object editor
   (picking, handles, undo, saving) run `SpireEngine --game sandbox --demo objselftest --screenshot-and-exit 66`
   and look for `[objtest] ALL OK` in the console. The same for the Asset Workshop (mouse strokes, mirror, sockets,
   saving, editing built-ins): `--demo wsselftest`, then look for `[wstest] ALL OK`. And for items (hotbar, shooting,
   rockets, grenades, the Item tab, the firing range, saving `.pxitem` files): `--demo itemselftest`, then look for
   `[itemtest] ALL OK`. Building kits: `--demo kit_selftest` (`[kittest] ALL OK`); blueprints: `--demo bp_selftest`
   (`[bptest] ALL OK`); characters: `--demo cc_selftest` (`[cctest] ALL OK`).
   **All of them at once:** `tools\run_selftests.bat build\Release\SpireEngine.exe` (Windows) or
   `tools/run_selftests.sh build/SpireEngine` (Linux / macOS) runs all thirteen (objects, Workshop, items, kits,
   materials, blueprints, characters, NPCs, rules, game rules and templates, sharing, polish, and a long soak test)
   and says which passed.

If vcpkg is somewhere other than `E:\vcpkg`, set an environment variable
`VCPKG_ROOT` to its folder and the build picks it up.

---

## Controls

**Editor** (default: the god view / Director mode)
| Input | Action |
|---|---|
| Hold **Right mouse** | Look around + **WASD** fly, **Q/E** down/up, **Shift** faster |
| **Left mouse** | Use the current tool where the cursor points (hold to keep sculpting) |
| **Mouse wheel** or **[ ]** | Brush size |
| **1 – 7** · **V** | Carve / Add / Smooth / Flatten / Paint / Stamp / Bake (Shape mode) · **Select** |
| Hold **Space** | The quick wheel at the pointer: flick toward an action and let go |
| **P / K / B / G** | The shelf's search · Kits · Blueprint · Gadgets |
| **Ctrl+K** (or Ctrl+P) | Find anything: every command, tool and panel |
| Select tool: **click** an object | Select it (**Ctrl/Shift+click** adds more). Drag the coloured handles to move it · **W / E / R** = Move / Turn / Size · **X** world or local axes · **Esc** cancels a drag |
| **Ctrl+D / Del / Ctrl+G / F** | Duplicate / delete / group (**Ctrl+Shift+G** ungroups) / fly the camera to the selection |
| **Ctrl+Z / Ctrl+Y** | Undo / Redo |
| **Ctrl+S / Ctrl+O** | Save / Load world |
| **Tab** or the **Play** button | Play the game from the camera position |
| **H** | Hide all UI (for screenshots) · **F1** all shortcuts · **F12** screenshot |

**Asset Workshop** (opened from Build > Workshop, Tools > Asset Workshop, or **Ctrl+Shift+W**)
| Input | Action |
|---|---|
| **1 – 5** | Add / Carve / Paint / Smooth / Socket |
| **Left mouse** | Click, or drag, to use the tool where the cursor points |
| **Right-drag** · **Middle-drag** (or Shift+right-drag) · **wheel** | Orbit · pan · zoom (**F** frames the model) |
| **Shift+wheel** or **[ ]** | Shape size · **R** turns the shape (**Ctrl+wheel** too) · **X / Y / Z** mirror |
| **Del** / **Esc** | Remove the selected socket · cancel the stroke in progress |
| **Ctrl+Z / Ctrl+Y** · **Ctrl+S** · **Ctrl+Shift+S** | Undo / Redo · Save · Save and place in the world |

**Blueprint** (Build > Blueprint, **B**, or **Ctrl+B**)
| Input | Action |
|---|---|
| **Drag** on the plan | Room tool: a new room · **Shift+drag** adds to the picked room · Erase: take cells out · **right-click** picks a room |
| **Click / drag** along edges | Door, Window, Wall, Open or Auto, whichever tool is chosen |
| **Ctrl+Z / Ctrl+Y** | Undo / redo a change to the plan (while the window has focus) |
| Placing: **click** · **Shift+click** · **R** or wheel · **Esc** | Build it · build and keep going · turn it · back to the plan |

**Character Studio** (People > Studio, or **Ctrl+Shift+C**)
| Input | Action |
|---|---|
| **Right-drag** · **Middle-drag** · **wheel** · **Left-drag** | Orbit · pan · zoom · turn the character |
| **1 – 5** · **F** | Stand / Walk / Run / Jump / Look around · frame the character |
| Tabs: **Body · Look · Clothes · Personality · Parts** | Shape · face, hair, skin · outfit, hats, glasses, beards, back · how they move and their habits · your own parts |
| **Ctrl+Z / Ctrl+Y** · **Ctrl+S** · **Esc** | Undo / Redo · Save · back to the world |

**Firing range** (Item tab > Enter the firing range)
| Input | Action |
|---|---|
| **Click the view** | Take aim (the mouse looks around) |
| **Left mouse** · **Right mouse** · **R** | Use the item · its second button · reload |
| **WASD** · **Shift** | Walk · run |
| **Esc** | Let go of the mouse; again to go back to building |

**Play mode** (engine controls, the same in every game)
| Input | Action |
|---|---|
| **WASD** / **Space** / **Shift** | Walk / jump / sprint |
| **1 – 9** · **mouse wheel** | Pick an item from the hotbar (sandbox) |
| **Left mouse** · **Right mouse** · **R** | Use the item (the Terraformer's second button builds) · reload |
| **Esc** | Pause menu (Resume, Settings, Back to Editor, Quit) |
| **Tab** | Straight back to the Editor |
| **V** | First person / third person (you, as the character you chose in the Character Studio) |
| **E** | Use what you look at: open a door, press a button, talk (the prompt by the crosshair says what) |
| **R** | When the game is won or lost: play again |

**Vanguard** adds: **Left mouse / 1** = power slot 1, **Right mouse / 2** = power slot 2.

## The editor layout

Laid out (in 1.1) so the things you use most are the easiest to reach, and only the things you need right now are on
screen.

- **Top bar:** the Spire mark, the **project menu** (your world's name: File, Edit, Tools, View, Game, Help), the four
  **modes**, **Play** in the middle (fuse orange: the only orange thing in the editor), **Find anything** (Ctrl+K: every
  command, tool and panel by a few letters), **Share** and **Settings**.
- **Modes:** **Shape** (the ground), **Build** (objects, building kits, blueprints, the Workshop), **People** (place
  people, the Character Studio, Make a Crowd) and **Logic** (gadgets, the goal, starter games). Each one shows only its
  own tools on the strip and its own things on the shelf.
- **Tool strip (left edge):** the mode's tools, each with its name and key (Shape: 1-7; Build: **V** Select, **P** Place,
  **K** Kits, **B** Blueprint), and Undo / Redo at the bottom.
- **Over the 3D view:** Snap (right-click for the steps), world or own axes, motion preview and the Camera menu (fly
  speed, field of view, saved views) top left; which way X, Y and Z point top right; the few keys worth knowing bottom
  left (**F1** lists them all).
- **The action bar:** select something and its common actions sit right above it: move, turn, resize, duplicate,
  Rules, focus, delete.
- **The quick wheel:** hold **Space**, flick toward an action (Place, Copy, Turn, Resize, Focus, Paint, Move, Rules) and
  let go. The directions never move, so after a few goes you stop reading them.
- **Scene (right, top):** everything in the world as a tree: search, drag to re-parent, rename, hide, lock.
- **Details (right):** what is selected (Essentials open; Behaviour, Rules, Motion, Options and About fold away and
  say what is inside while folded), or with nothing selected, the current tool's settings. **World** (terrain, view
  distance, save / load) and **Sky** (time of day, sun, fog, colour, grass, water, sound) are the tabs beside it, with
  any tab the game adds (Vanguard: **Character**).
- **Shelf (bottom):** pictures of everything you can place, filtered by Recent, All, Building kits, Gadgets, Items,
  People and Made by you, with search. Click one, then click in the world. **Kits** is the tab beside it.
- **Status bar (bottom edge):** mode and tool, the last thing that happened, time, FPS, chunks, triangles, position.
- While you play from the editor the edge of the screen glows orange and **PLAYING · Tab to stop** sits top left.
- Panels dock, tab and float (View > Layout has four arrangements, and you can save your own).

## Objects

Objects are things you place in the world that are **not melted into the terrain**: you can
pick them up again, turn them, make them bigger or smaller, group them and make them move.

1. Open the **Assets** panel and click a prop (crate, arch, steps, lamp post, or any prefab you baked).
   A see-through preview follows the cursor; **click** to place it, **mouse wheel** turns it, **Esc** stops.
2. With the **Select** tool (8) click an object. Drag the arrows to move it, the rings to turn it, the
   box handles to resize it. **Snap** in the Tool panel rounds moves to whole metres and turns to 15 degrees.
3. In the **Scene** panel, drag one object onto another to attach it (it then follows its parent), use the
   eye and lock icons to hide or protect things, double-click to rename.
4. In **Details > Motion**, give an object a **motion** (Spin, Bob, Sway or Slide). Tick *Preview motion* to see it
   in the editor; in Play mode everything moves.
5. Objects are solid: the player can stand on them and walk into them. Untick *Solid* for decoration.

Everything is saved in the world file and undone with Ctrl+Z, together with your terrain edits.

## The Asset Workshop

The Workshop is where you make your own things: a sword, a lantern, a wall piece, a creature part. It is a
separate screen with a clean floor, so nothing in the world gets in the way, and it works in much finer
detail than terrain (the default voxel is 12.5 cm; you can go down to 3 cm).

1. In the **Assets** panel click **New** (or choose **Tools > Asset Workshop...**). Pick a starting point:
   *Blank* (choose the detail and the size of the space), a *humanoid mannequin*, a *sword*, a *pistol*, a
   *wall segment* or a *door frame*. To change something that already exists, right-click it on the shelf
   (**Edit in the Asset Workshop**, or **Make my own version** for the built-in ones).
2. **Add** sticks a shape on the model, **Carve** cuts one out, **Paint** changes the material without changing the
   shape (tick *Fill patch* to recolour a whole region in one click), **Smooth** softens bumps. Pick a *box, sphere,
   cylinder, cone or ramp*, then its size, rounded edges, soft blend, turn and snapping. A see-through copy of the
   shape follows the cursor and shows its size. Drag to draw with it; a whole drag is one undo step.
3. Switch on **Mirror** (X / Y / Z) and everything you do is copied across the model's middle, so faces,
   swords and vehicles come out even.
4. **Sockets** are named points where things attach or happen: a sword's `grip`, a pistol's `muzzle`, a chair's
   `seat`. Choose the Socket tool, click the model, drag to move one, rename it and set which way it points.
5. Give it a **name, type and tags** and press **Save** (Ctrl+S). It is written to `assets/<name>.pxasset`, appears in
   the shelf (Made by you) with a small hammer badge, and can be placed like any other asset. **Save and Place in the World**
   (Ctrl+Shift+S) does both. **Done** goes back to the world, asking first if there is unsaved work.

The `.pxasset` file is a readable JSON header followed by compressed voxel data, so assets can be shared by copying
the file.

## The Item Builder

Anything you can hold is an *item*: a model plus a behaviour and some numbers. Make the model in the Workshop (the
*pistol* and *sword* templates already come with a `grip` and a `muzzle` or `blade_tip` socket), set its type to **Item**
and a second tab, **Item**, appears at the top of the side panel.

1. **Works like**: *Melee* (a swing), *Hitscan gun* (a shot that lands at once; give it pellets for a shotgun),
   *Projectile launcher* (rockets, arrows), *Thrown* (grenades) or *Tool* (digs with the left button, builds with the
   right). Choosing one fills in sensible numbers, and a line under it tells you what that adds up to: damage a second,
   how long a magazine lasts.
2. **Stats** change with the behaviour: damage, fire rate, automatic, magazine and reload, pellets, spread, recoil,
   range, speed, gravity, fuse, bounce, reach, swing.
3. **What it does to the world**: nothing, dig a hole or build a lump, how big, what the lump is made of, and how hard a
   blast shoves whoever stands near it (a rocket jump is a rocket fired at your own feet).
4. **How it feels**: the sound it makes and the sound where it lands (press **>** to hear one), volume and pitch,
   muzzle flash, tracer and its colour, camera shake.
5. **In the hand**: where it sits in front of you, how it is turned, how big it looks.
6. **Enter the firing range** to test it. You stand at the line with the model in your hand: **click the view** to take
   aim, **left click** fires, **right click** is the second button, **R** reloads, **WASD** walks, **Shift** runs, **Esc**
   lets go of the mouse (press it again to leave). Target plates, training dummies and drums are scored and fall over
   when they run out of health, then stand up again; a brick wall and a block of sand really get holes in them. The side
   panel shows shots, hits, accuracy, damage and damage a second, and every number you change takes effect at once.
   **Reset range** rebuilds the wall and the sand.
7. **Save** writes `assets/<name>.pxasset` and `assets/<name>.pxitem` side by side. **Save and try it in the world**
   starts playing with it first in your hand. On the shelf items wear a small crosshair badge, and the right-click
   menu has **Try it in the world**.

Six items come with the engine (pistol, rifle, sword, rocket launcher, grenade, terraformer): right-click one in the
shelf and choose **Make my own version in the Workshop**, and its numbers come along. In play mode the sandbox puts
every item on a hotbar (keys **1 – 9**, mouse wheel); a game that wants its own controls leaves items off, or turns them on
with `app.inventory.enabled = true` and listens for hits in `Game::onItemHit`.

## Building kits

Build a house the way you would with toy bricks. Open the **Kits** tab (next to Assets; View menu, or the *Kits*
button in Assets) and pick a **kit**: *Brick house*, *Timber cabin*, *Stone keep*, *Modern* or *Sci-fi*. Each kit has
seven pieces: **Wall, Window, Doorway, Floor, Roof, Stairs, Pillar**.

1. Click a piece. A see-through copy follows the cursor and **snaps** to a 2 m grid: walls sit on the edge of a cell,
   floors and roofs fill a cell, pillars sit on corners. Cyan means a new piece, amber means it will replace the piece
   already there (a window swaps with a wall in the same place), faint means it is already there.
2. **Click** to place one piece, or **hold and drag** to lay a whole run of walls or floor in one go (one Ctrl+Z
   takes the whole run back). **Shift+click** or Shift+drag removes kit pieces.
3. **R** turns the piece. The **mouse wheel** or **[ ]** goes up and down a storey; pointing at the top of a wall builds
   the next storey on it. The first piece you place fixes the ground height (you can change it in the panel).
4. Pieces go into a **Building** group in the Scene panel, so a house moves, turns and resizes as one. Select pieces and
   press **Selected pieces** or **Whole building** in the Kits panel to swap them to another style in one click.
5. Stairs climb one storey over two cells; leave the floor above the top of the stairs open. Two roof tiles back to
   back make a ridge over a 4 m house.

Each piece is an ordinary asset, so you can open any of them in the Workshop and save your own version under the same
name (it replaces the built-in one). To make a whole new kit, use **New asset → Building kit piece** in the Workshop:
choose the role and give the kit a name, and every piece you make with that name shows up as a kit in the panel.
Grass does not grow through floors.

## Blueprints

The Blueprint Tool makes a whole building in one go. Draw the rooms; the walls, windows, doors, floors, stairs and roof
are worked out for you, from any building kit. Open it with **Tools > Blueprint...**, **Ctrl+B**, or the
*Draw a whole building* button in the Kits panel. The first time it shows a ready-made family house to play with.

1. **Draw rooms.** With the **Room** tool, drag a rectangle on the plan: that is a room (2 m cells, up to 16 x 16).
   Drag another for the next room. **Shift+drag** adds cells to the room picked in the list, **Erase** takes cells out,
   **right-click** picks the room under the mouse. Rename a room by clicking it in the list. The front is the bottom of
   the plan.
2. **Storeys.** Press **+ Storey**: the new storey starts with the outline of the one below; draw its rooms the same way.
   Up to four.
3. **What you get, without asking:** outside walls with windows spaced along them (*None / Some / Many*), a front door
   on the ground floor, a doorway between every two rooms that touch, a floor under every room, **stairs** to each
   storey (in a room long enough, landing in a room upstairs that leads to others; the floor above them is left open),
   and a **roof**: *Pitched* (ridges along the long side, lean-tos against a taller part, two ridges on an L-shape),
   *Flat* or *None*. Corner posts are one tick away.
4. **Change anything by hand.** The **Door, Window, Wall** and **Open** tools set single edges (click or drag along
   them): a back door, a picture window, a wall inside a room, an open arch or porch. **Auto** hands an edge back to the
   rules. The **Stairs** tool puts stairs exactly where you want them (**R** turns them).
5. **Check it.** The side panel counts the pieces and warns you about anything odd: a room with no way in, stairs that
   come up against a wall, a storey floating in the air.
6. **Build it.** Press **Place in the world**: the whole building follows the mouse on the kit grid. **R** or the wheel
   turns it, **click** builds it (the ground under it is levelled first, unless you untick that), **Shift+click** builds
   it and lets you build another, **Esc** goes back to the plan.

The result is an ordinary **Building** group of kit pieces: move it, swap its style in the Kits panel, or add pieces by
hand. Select any piece of it and press **Edit the floor plan** in Details to open its plan again; **Rebuild**
puts the changed plan back in the same place (one Ctrl+Z undoes it). Plans have their own undo (Ctrl+Z while the window
has focus), save to `blueprints/<name>.pxblueprint` (readable JSON), and there are seven ready-made ones to start from:
Cottage, Family house, Corner shop, L-shaped house, Watchtower, Barn and Outpost.

## Characters

The **Character Studio** is where you make people: **Tools > Character Studio...** or **Ctrl+Shift+C**. It is a screen
of its own; the person stands in the middle and moves while you change them.

1. **Body:** six sliders (height, build, shoulders, legs, arms, head size); the body itself: **gender** (feminine to
   masculine), **age** (child to old), **muscle** and **weight**; **features** (African, Asian, European, mixed as you
   like) and **A new face** (small differences in nose, mouth, chin, cheeks and ears). Or start from one of the six
   ready-made people (Explorer, Builder, Agent, Scientist, Kid, Giant).
2. **Look:** skin colour, eye colour, a **face** (5 kinds of eyes, 5 brows, 4 noses, 5 mouths), eight hair styles and
   hair colour. They **blink**, and their moods show on their faces.
3. **Clothes:** a top (shirt, stripes, jacket and tie, vest, long coat, armour), bare arms or sleeves, trousers, a
   skirt or a robe, long legs or shorts, shoes or boots; a **hat** (cap, beanie, top hat, helmet, cowboy hat, hood,
   crown), **glasses** (round, sunglasses, goggles, a glowing visor), a **beard** (full, moustache, goatee) and something
   **on the back** (backpack, cape, quiver, air tanks, a sword). Colours for the top, bottoms, shoes and an **accent**
   (hats, bags, armour), and any part can have a colour of its own.
4. **Personality:** how they move: Normal, March, Shuffle, Bouncy, Swagger, Sneak or Proud, or six sliders (stride,
   swagger, arm swing, bounce, posture, fidgety). Standing about, they do things: look around, shift their weight,
   cross their arms, put their hands on their hips, check a watch, stretch, scratch their head. *Try a habit* and
   *Mood* (happy, angry, scared, sad, talking) let you see them here.
5. **Surprise me** makes a whole new random person (your name stays; Ctrl+Z goes back).
6. **Parts:** swap any part (head, torso, arms, hands, legs, feet, hair) for one you made in the Asset Workshop (a
   head of your own makes that person the 1.4 kind, all voxel parts). The
   **...** button opens a part in the Workshop to make your own version; a part is any asset tagged `part:<slot>`, and
   its socket called `joint` is where it attaches.
7. **Preview:** the buttons at the bottom of the view (or keys **1-5**) make them stand, walk, run, jump or look around;
   *Holding* puts any item in their hands. Right-drag orbits, middle-drag pans, the wheel zooms, left-drag turns them.
8. **Save** (Ctrl+S) writes `characters/<name>.pxcharacter`. **Place in the world** puts them where you click (they
   breathe, turn to look at you, and stand with their feet on the real ground, even across a step). **Play as them**
   makes them you: press **V** in play mode for third person.

**People who live.** Select a person and, in **Details > Behaviour**, press **Give them a life**. Then pick:

- **What they do:** *Stand* (on their spot), *Wander* (stroll about near it), *Patrol* (walk a path: press **Path...**
  and click the points in the world, Esc when done), *Guard* (keep a post and walk up to anyone who comes close),
  *Follow* (come along with you) or *Work* (go to a **work spot** you click, and work there).
- **When you come close:** *Ignore*, *Friendly* (they stop, wave, smile and say a line), *Shy* (they back away) or
  *Scared* (they run).
- **What they say:** one line per meeting, in a speech bubble; and whether their **name tag** shows.
- **Their day:** *Add a time* to change what they do by the hour (for example work at 08:00, wander at 12:00, home at
  18:00); it follows the world's time of day.

They do all this while you play (they walk on the real ground, go round things in the way, and keep a little apart);
in the editor the selected person's range, path and work spot are drawn, and stopping play puts everyone back.

## Rules: "When this happens → do that"

Any object can have rules, written as sentences with no code: select it, and in **Details > Rules** (or the **Rules** button above it) press
**+ Add a rule**. A rule is *When* something happens, *do* one or more things, each straight away or after a delay,
every time or only the first time.

- **When:** the game starts · you touch it · you step off it · you come near (how near) · you press **E** on it ·
  every few seconds · it hears a message.
- **Do:** show a message · open / close / open-or-close (something) · hide / show (something) · collect it (+points) ·
  play a sound · teleport you to (something) · send a message · make someone say something · add points · win · lose.

Objects talk to each other with messages: a pressure plate *sends* "open the gate", and the gate, which *hears*
"open the gate", opens. Doors open by swinging, sliding, lifting or sinking.

**Gadgets** (Tools > Gadgets) come with their rules already: a **door** (E opens and shuts it), a **gate** (opens when
it hears "open the gate"), a **pressure plate** and a **button** (send it), **coins** and **gems** (collect them for
points), a **key**, a **sign** (shows its message when you come near), a **teleporter** and a **finish flag** (you
win). While playing, **E** uses what you look at (the prompt says what it will do), your points show at the top right,
and when you win or lose, **R** plays again and **Tab** goes back to the editor.

## Game rules and templates

**Tools > Game Rules...** says what the whole game is about: **just play**, **reach the finish** (touch something with
a *win* rule, like the finish flag), **collect everything**, **get points** (how many) or **survive** (how long). Add a
**time limit**, **lives**, **falling** (falling this far costs a life and puts you back at the start or your last
checkpoint), **where you start**, and what it says at the start, on winning and on losing. Rules on objects can also
*lose a life*, *save a checkpoint* and *add time*. While playing, the clock, your lives, what is left to collect and
your points show at the top.

**Tools > New Game From Template** builds a whole little game in front of you, from ordinary objects you can change:

- **Parkour:** a tower of blocks to jump up, with checkpoints and a flag at the top.
- **Coin Hunt:** find every coin and gem in two minutes.
- **Capture the Flag:** sneak past three guards, take their flag and bring it home (three lives).
- **Survival:** hunters come for you; last 90 seconds (gems take time off the clock).
- **Sandbox:** no goal and no clock.

Each is one undo step.

## Getting started, controls and accessibility

The first time you open a world, a short **tutorial** walks you through it (look around, shape the ground, place a
gadget, look at its rule, play it); each step finishes when you have actually done it. Skip it whenever you like, and
start it again from **Help > Tutorial**.

**Settings > Controls** lets you change the keys used while playing: click an action, press the key you want (a key
another action uses swaps over). **Toggle run** makes Run a tap instead of a hold.

**Settings > Accessibility:** colour-blind friendly colours (for good / careful / bad and the gizmo's arrows), a bigger
crosshair and bigger messages, the interface size, **captions** (words on screen for game sounds), and **reduce
motion** (no screen shake; bookmarks jump instead of gliding).

## Share your game

**File > Share Game...** packs the game into one folder that anyone can run: no editor, nothing to install. Give it a
name, who made it and a line about it, choose first or third person, and press **Make the game folder** (it goes in
`shared/<name>` unless you choose another folder). The folder has the program, the world, everything you made that the
world uses, a `game.pxgame` file, **Play.bat** (Windows), **play.sh** (Linux / macOS) and a read-me with the controls.
Zip it and send it: the player double-clicks Play and the game starts straight away. (The folder runs on the kind of
computer it was made on: make it on Windows for Windows players.)

**Make a crowd** (Tools > Make a Crowd...): pick who (villagers, city folk, soldiers, a sci-fi crew, fantasy folk, or
anyone), how many (2 to 60) and how spread out, and click **Make the crowd**. They go where the cursor points (or in
front of you). Every one is a different person, with their own body, face, clothes, hat, walk and name, and one Ctrl+Z
takes the whole crowd away. **Try again with different people** swaps them for new ones in the same place. The world
saves only `crowd:villagers:1042` for each, and they come back exactly the same; select one and *Edit in the Character
Studio* to make them a character of your own.

Animation is procedural: no animator needed. Walking and running follow how far you actually move, so feet don't slide;
jumping tucks the legs and landing dips; arms reach for whatever you hold with IK; and on slopes, stairs and rubble the
feet land on the ground under them.

## Materials

Every bit of the world remembers what it is made of. New terrain is **Natural**:
grass on flat ground, dirt on gentle slopes, rock on cliffs and in caves, sand in
low valleys and snow on high peaks. Dig down and you hit dirt, then stone.

- **Build** (2) adds matter in the material picked in the palette.
- **Paint** (5) changes the material without changing the shape. Paint
  *Natural* to give a spot its original look back.
- **Smooth** (3) softens bumps and the blobby look of sculpting.

All of these work with undo, saving and prefabs (a baked prefab keeps its materials).
The textures are generated by the engine at startup, so there are no image files
to manage; tint them in **Environment → Materials → Tint each material**.

The palette has six groups of material (the same palette is in the Asset Workshop):

| Group | Materials |
|---|---|
| **Terrain** | Grass, Dirt, Stone, Sand, Snow, Gravel, Mud, Sandstone |
| **Nature** | Moss, Bark, Leaves |
| **Building** | Wood, Metal, Brick, Plaster, Tile, Cloth, Ice, Cobblestone, Marble, Concrete, Slate, Roof tiles, Rust, **Glass**, **Gold**, **Steel** |
| **Glowing** | **Lava** (dark crust, glowing cracks that pulse), **Lamp** (warm light panel), **Crystal** (blue, faceted) |
| **Paint** | Red, Orange, Yellow, Green, Teal, Blue, Purple, Pink, Black (plaster with a colour) |
| **People** | **Skin**, **Hair** and **Leather**: they take a person's own skin, hair and shoe colours |

Every material is physically based: a colour map, a normal map (the bumps), and a surface map with roughness,
metalness and crevice shadow, all generated by the engine at the **Texture detail** you pick in Settings (512, 1K, 2K
or 4K per material). Glass is dark and reflects the sky; gold and steel are real metals; skin lets a little light
through, so faces are soft rather than plastic.

Glowing materials give off their own light, so they stay bright at night and bloom. They do not yet light the ground
around them (that is the point-light feature on the roadmap).

### Your own textures (texture packs)

Drop photo textures (from Poly Haven, ambientCG, your own camera...) into `textures/<pack name>/<material>/` and pick
the pack in **Settings > Graphics > Surfaces > Texture pack**. Only a colour picture is needed; normals, roughness,
height and ambient occlusion are used when they are there and worked out when they are not. See
**[docs/TEXTURE_PACKS.md](docs/TEXTURE_PACKS.md)**.

## Water, grass and trees

The world has a **sea level** (World tab → Terrain Generator → Sea). Every low
spot below it is water, with sandy beaches just above. Walk into water in play
mode and you wade, then swim (**Space** up, **Ctrl** or **C** dive). Dig a hole
below sea level and it fills with water.

Grass and flowers grow on every grass surface, including ground you paint with
the Grass material. They sway in the wind and part around the player. Wind, grass
density and draw distance, and the look of the water (clarity, waves, foam,
colours) are in **Environment → Grass & Wind / Water**.

Trees grow by themselves on grassy ground (1.4): oaks and birches in the lowlands, pines
thickening into forests towards the snow line, bushes in between. They come in several
shapes each, with a detailed model up close and a lighter one in the distance, and their
trunks are solid. They keep clear of water and of anything you build or place. **Environment
→ Trees** turns them on or off and sets how many there are and how far they are drawn; the
oak, pine, birch and bush are also on the **Shelf** to place by hand.

## Sound

The engine makes its own sounds, so there are no audio files to ship: footsteps
that change with the ground under you (grass, dirt, stone, sand, snow, wood,
metal, brick, shallow water), landing, jumping, splashing and swimming, a sound
for every tool and for game powers, and ambience that follows you: wind that
rises with altitude, water lapping near the shore, a drone and drips when you are
in a cave, crickets at night, birdsong by day. Under water everything goes dull.

Volumes (master, effects, ambience, music, interface) are in **Settings → Audio**,
and **Environment → Sound** shows what the world is playing. To use the sounds
yourself, `SpireEngine --export-sounds <folder>` writes all of them as `.wav` files.

For game code: `app.playSfxAt("boom", position)`, `app.playUiSound()`,
`app.audio.loadWav("name", "file.wav")`, and `app.ambience.zones.push_back({...})`
for a place with its own ambient sound (see `engine/audio/`).

## The editor

Every panel (Tool, World, Environment, and your game's own) is a window you can
rearrange: drag a tab to move it, drop it on an edge to split the screen, pull it
out to float it. **View → Layout** has three presets and saves your own; the layout
is remembered next time. The 3D view always fills the space that is left.

- **Command palette (Ctrl+P)**: type a few letters of anything (`carve`, `save`,
  `sunset`, `layout`) and press Enter. Recently used commands come first.
- **Camera bookmarks**: **Ctrl+Shift+1…9** saves the current view, **Ctrl+1…9**
  flies back to it. Name them in **Tool → Camera Bookmarks**; they are kept with the world.
- **Autosave**: every few minutes (Settings → Safety), but only if something changed.
  If Spire Engine ever closes unexpectedly, it offers the autosave back the next time you
  open that world. **File → Open Autosave** lists them.

## Graphics and display

**Settings** (the gear at the top right, or the project menu > File > Settings) has four tabs.

- **Graphics** has a quality preset (**Low, Medium, High, Ultra**) that sets everything on
  the page at once: 3D resolution (50–150%), edge smoothing, bloom, **texture detail** (512, 1K,
  2K or 4K per material; a new size is built in the background the first time and cached in
  `cache/textures/`), **ambient occlusion**, the **texture pack**, shadows (detail and distance),
  grass (amount and distance), trees (on/off and distance) and view distance. Change any one setting and the
  preset reads **Custom**. A small gauge shows roughly how heavy the mix is for your graphics
  card. The shadow, grass and view-distance sliders are the same ones as in the
  Environment and World tabs.
- **Display** has window mode (windowed, borderless fullscreen, exclusive fullscreen),
  monitor, resolution, V-Sync, a frame-rate limit, "slow down in background" (30 FPS while the
  window is not in front), interface size (75–200%) and field of view.
- **F11** (or **Alt+Enter**) switches between windowed and borderless fullscreen anywhere.
  **Ctrl +** and **Ctrl −** change the interface size, **Ctrl+0** resets it.
- Everything is saved automatically in `config/settings.cfg`, a plain text file you can edit
  or delete. The window also remembers its size. Run with `--no-settings` to ignore it.
- The command palette has the presets too: type `quality ultra`, `fullscreen`, `fps`.

## Making a prefab

1. Sculpt something with **Build** (and Carve to shape it).
2. Pick **Bake** (key 7), type a name, and set the capture size so the blue box covers it.
3. Click the base of your sculpture → saved to `prefabs/<name>.vxprefab`.
4. Pick **Stamp** (key 6), choose it in the Prefab Library, and click anywhere to place copies.

Prefabs are density data, not polygons, so stamped copies are fully destructible.

## Saving

**World → Save world** writes `worlds/world.vxworld`: the terrain settings plus
every edit you made. The terrain itself is regenerated from the seed, so saves
are tiny.

---

## Making a new game

1. Copy `games/template` to `games/mygame` and rename the class.
2. Edit the `PX_REGISTER_GAME(...)` line at the bottom: id, name, tagline, colour.
3. Add `add_subdirectory(games/mygame)` to the root `CMakeLists.txt` and rebuild.
   Your game now shows up in the Project Hub.
4. Implement the `px::Game` hooks you need (`engine/core/Game.h` lists them all):
   your HUD, input, per-frame logic, and extra editor tabs and menu items.

Each game gets its own world save in `worlds/<game id>/`, and reopens where you left off.

## Known limits in 1.6

- People steer round what is in front of them but don't plan routes yet (no pathfinding): a maze can stop them.
- Rules have no conditions yet ("only if you have the key"): use *Starts hidden* and *show* as a workaround (the
  Capture the Flag template does this).
- One player only: no multiplayer yet.
- Clothes are shaped from the body and hang, and skirts, coat tails and long hair swing as people move, but it is not
  a cloth simulation: nothing collides, and cloth does not catch on things. Shoes and boots are still sculpted parts.
  Fingers don't move.
- Hats, hair parts and glasses made for the 1.4 heads are fitted onto the new heads by size, so some sit a little off.
- Trees don't sway in the wind yet, can't be cut down, and leaves are solid clumps rather than single leaves.
- A shared game runs on the kind of computer it was made on, and on Windows a console window opens beside it.

## Project layout

```
engine/
  launcher/    main.cpp for SpireEngine.exe
  core/        Application (window, loop, hub/editor/play modes), Game interface + registry, camera, pause menu
  world/       chunks, materials, terrain generator, streaming, edit log, prefabs, saves
  render/      OpenGL renderer: shadows, HDR sky, triplanar terrain, post-processing, procedural textures
  physics/     character controller
  ui/          UiKit: the Obsidian & Neon theme, fonts, icons, shared widgets (restyle everything here)
  editor/      Project Hub + the editor: top bar, tool strip, Scene, Details, Shelf, action bar, quick wheel (Shell.cpp), the Asset Workshop screen
  workshop/    the Workshop's model: voxel stamps, mirror, undo, sockets, templates (no window code)
  items/       items: behaviours, stats, .pxitem files, the held-item runtime, the built-in kit (no window code)
  scene/       assets, .pxasset files, placed objects, the building-kit grid and snapping (BuildKit)
  third_party/ FastNoiseLite, Marching Cubes tables
  assets/      engine assets: fonts (SIL Open Font License), the human body (MakeHuman, CC0: see assets/human/LICENSE.txt)
games/
  vanguard/    Vanguard game: powers, profile, HUD, Character tab
  template/    minimal starting point for new games
tests/         engine tests (ctest)
prefabs/       your baked .vxprefab files
assets/        your .pxasset and .pxitem files from the Asset Workshop
docs/          ENGINE.md, ROADMAP.md, CREATION.md
```
