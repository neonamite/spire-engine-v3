# Spire Engine — Marketing capture automation and roadmap overlay

This ZIP contains documentation, marketing concept visuals, your v2.0–v5.5 roadmap, and capture automation only. It is an **overlay**, not a standalone C++ engine or a full source replacement.

Merge the `SpireEngine/` folder from this ZIP into your working project folder. This update does **not** replace engine C++ sources or existing Windows build artifacts.

## What is new since the previous marketing/roadmap ZIP

- `tools/capture_marketing.py` — records authentic, unedited BMPs from the compiled engine's 12 supported demo scenes.
- `tools/capture_marketing.bat` — Windows launcher.
- `marketing/screenshots/CAPTURE_RUNBOOK.md` — step-by-step capture instructions and source-backed scene list.
- `docs/VERIFICATION_CAPTURE_STATUS_2026-10-13.md` — scoped testing/build status.

## What is not included

No verified running-engine screenshot has been produced yet. Images under `marketing/screenshots/concepts/` are clearly labeled concept art. The `marketing/screenshots/captured/` directory is intentionally empty until the actual editor is run.

To capture the first screenshot on a Windows machine with a working engine executable, run:

```bat
tools\capture_marketing.bat --select objclean --exe build\Release\SpireEngine.exe
```

The helper requires Python 3. If Python 3 is not installed, use the manual command in `marketing/screenshots/CAPTURE_RUNBOOK.md`.
