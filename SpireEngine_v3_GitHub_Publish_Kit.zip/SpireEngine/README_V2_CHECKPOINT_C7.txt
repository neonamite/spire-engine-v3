SPIRE ENGINE v2.0 -- CHECKPOINT C7 (2026-10-13)

Includes C6 asynchronous CPU surface patch streaming plus C7 precision-aware
camera-relative draw packet generation, ready for a later main-thread GPU
uploader. It does NOT yet render the distant planetary quadtree in OpenGL.

For the safest path, unzip the C7 CONSOLIDATED SOURCE OVERLAY in a separate
folder. The small C7 incremental patch assumes you already applied C6.
Preserve your own build dependencies, assets and world saves.

Read docs/PLANETARY_MILESTONE_C7.md for changes and verification, and
        docs/TEST_LATER_WINDOWS_V2.md for the next Windows smoke test.
